# Simple Email Test
$ErrorActionPreference = "Stop"

Import-Module (Join-Path $PSScriptRoot 'Modules\Common.psm1') -Force

Write-Host "`nTesting Email Configuration..." -ForegroundColor Cyan

$configPath = Join-Path $PSScriptRoot "Config\notifications.json"
$config = Get-Content $configPath | ConvertFrom-Json

Write-Host "SMTP Server: $($config.SMTP.Server)" -ForegroundColor Yellow
Write-Host "Port: $($config.SMTP.Port)" -ForegroundColor Yellow
Write-Host "SSL: $($config.SMTP.EnableSSL)" -ForegroundColor Yellow
Write-Host "From: $($config.SMTP.From)" -ForegroundColor Yellow
Write-Host "To: $($config.Notifications.Recipients -join ', ')" -ForegroundColor Yellow
Write-Host "Windows Auth: $($config.SMTP.UseDefaultCredentials)" -ForegroundColor Yellow
Write-Host ""

try {
    Send-SqlMonitorEmail `
        -SmtpConfig $config.SMTP `
        -To $config.Notifications.Recipients `
        -Cc $config.Notifications.CCRecipients `
        -Subject "SQL Monitor Test Email" `
        -Body "This is a test email from SQL Monitor. If you received this, email notifications are working correctly!"

    Write-Host "SUCCESS! Email sent to $($config.Notifications.Recipients -join ', ')" -ForegroundColor Green
    Write-Host "Check your inbox now." -ForegroundColor Cyan
}
catch {
    Write-Host "FAILED: $(Get-SqlMonitorExceptionMessage -Exception $_.Exception)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting:" -ForegroundColor Yellow
    Write-Host "1. Verify SMTP server name with IT: $($config.SMTP.Server)" -ForegroundColor Gray
    Write-Host "2. Check if port $($config.SMTP.Port) is open" -ForegroundColor Gray
    Write-Host "3. Verify your machine is allowed to relay emails from this SMTP server" -ForegroundColor Gray
    Write-Host "4. If the error says the connection was closed, ask IT to confirm the SMTP service accepts mail from this host/service account" -ForegroundColor Gray
}
