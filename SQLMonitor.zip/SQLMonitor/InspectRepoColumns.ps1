Import-Module '.\Modules\Common.psm1' -Force
$instance = Get-SqlMonitorInstances | Select-Object -First 1
Write-Host "Repo: $($instance.RepositoryServer) $($instance.RepositoryDatabase)"
$tables = @('mon.DiskVolumeHistory','mon.ConfigHistory','mon.TempDBHistory','mon.IOFileHistory','mon.LongRunningHistory','mon.DBOptionsHistory','mon.KPIHistory')
foreach ($table in $tables) {
    Write-Host "--- $table ---"
    $cols = Get-MonitorTableColumns -ServerInstance $instance.RepositoryServer -Database $instance.RepositoryDatabase -TableName $table
    if ($cols.Count -eq 0) {
        Write-Host "  (no columns returned)"
    } else {
        foreach ($col in $cols) { Write-Host "  $col" }
    }
}
