IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');
GO

IF OBJECT_ID('mon.CentralSyncTables', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CentralSyncTables
    (
        SyncTableID      INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CentralSyncTables PRIMARY KEY,
        SchemaName       SYSNAME NOT NULL,
        TableName        SYSNAME NOT NULL,
        TimeColumn       SYSNAME NOT NULL,
        DedupeColumns    NVARCHAR(1000) NULL,
        IsEnabled        BIT NOT NULL CONSTRAINT DF_CentralSyncTables_IsEnabled DEFAULT 1,
        SyncOrder        INT NOT NULL CONSTRAINT DF_CentralSyncTables_SyncOrder DEFAULT 100,
        CreatedAt        DATETIME2 NOT NULL CONSTRAINT DF_CentralSyncTables_CreatedAt DEFAULT SYSDATETIME(),
        CONSTRAINT UQ_CentralSyncTables_Table UNIQUE (SchemaName, TableName)
    );
END;
GO

IF OBJECT_ID('mon.CentralSyncRuns', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CentralSyncRuns
    (
        SyncRunID              BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CentralSyncRuns PRIMARY KEY,
        StartedAt              DATETIME2 NOT NULL CONSTRAINT DF_CentralSyncRuns_StartedAt DEFAULT SYSDATETIME(),
        EndedAt                DATETIME2 NULL,
        CentralLinkedServer    SYSNAME NOT NULL,
        CentralDatabase        SYSNAME NOT NULL,
        LookbackMinutes        INT NOT NULL,
        Status                 NVARCHAR(30) NOT NULL CONSTRAINT DF_CentralSyncRuns_Status DEFAULT N'Started',
        ErrorMessage           NVARCHAR(MAX) NULL
    );
END;
GO

IF OBJECT_ID('mon.CentralSyncTableRuns', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CentralSyncTableRuns
    (
        SyncTableRunID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CentralSyncTableRuns PRIMARY KEY,
        SyncRunID      BIGINT NOT NULL,
        SchemaName     SYSNAME NOT NULL,
        TableName      SYSNAME NOT NULL,
        StartedAt      DATETIME2 NOT NULL CONSTRAINT DF_CentralSyncTableRuns_StartedAt DEFAULT SYSDATETIME(),
        EndedAt        DATETIME2 NULL,
        RowsInserted   INT NOT NULL CONSTRAINT DF_CentralSyncTableRuns_RowsInserted DEFAULT 0,
        Status         NVARCHAR(30) NOT NULL CONSTRAINT DF_CentralSyncTableRuns_Status DEFAULT N'Started',
        ErrorMessage   NVARCHAR(MAX) NULL,
        CONSTRAINT FK_CentralSyncTableRuns_Run FOREIGN KEY (SyncRunID) REFERENCES mon.CentralSyncRuns(SyncRunID)
    );
END;
GO

MERGE mon.CentralSyncTables AS target
USING (VALUES
    (N'mon', N'CollectionRuns', N'StartTime', N'ModuleName,Status', 1, 10),
    (N'mon', N'CPUHistory', N'CaptureTime', N'', 1, 20),
    (N'mon', N'MemoryHistory', N'CaptureTime', N'', 1, 20),
    (N'mon', N'KPIHistory', N'CaptureTime', N'', 1, 20),
    (N'mon', N'DiskVolumeHistory', N'CaptureTime', N'VolumeMountPoint,LogicalVolumeName', 1, 30),
    (N'mon', N'ConfigHistory', N'CaptureTime', N'', 1, 30),
    (N'mon', N'IOFileHistory', N'CaptureTime', N'DatabaseName,FileType,LogicalName,PhysicalName', 1, 30),
    (N'mon', N'TempDBHistory', N'CaptureTime', N'FileType,LogicalName,PhysicalName', 1, 30),
    (N'mon', N'DBOptionsHistory', N'CaptureTime', N'DatabaseName', 1, 30),
    (N'mon', N'BackupStatusHistory', N'CaptureTime', N'DatabaseName', 1, 30),
    (N'mon', N'BlockingHistory', N'CaptureTime', N'SessionID,BlockingSessionID,DatabaseName,WaitType', 1, 40),
    (N'mon', N'LongRunningHistory', N'CaptureTime', N'SessionID,DatabaseName,StartTime', 1, 40),
    (N'dbo', N'WaitStats', N'CollectionDateTime', N'WaitType', 1, 50),
    (N'dbo', N'TopQueries', N'CollectionDateTime', N'QueryID,PlanID', 1, 50),
    (N'dbo', N'MissingIndexes', N'CollectionDateTime', N'DatabaseName,ObjectName,EqualityColumns,InequalityColumns,IncludedColumns', 1, 50),
    (N'dbo', N'IndexFragmentation', N'CollectionDateTime', N'DatabaseName,ObjectName,IndexName', 1, 50),
    (N'mon', N'ExecutionPlansHistory', N'CaptureTime', N'DatabaseName,QueryHash,PlanHash', 1, 60),
    (N'mon', N'MemoryClerksHistory', N'CaptureTime', N'ClerkType', 1, 60),
    (N'mon', N'BufferPoolAnalysisHistory', N'CaptureTime', N'DatabaseName', 1, 60),
    (N'mon', N'AgentJobHistory', N'CaptureTime', N'JobName', 1, 70),
    (N'mon', N'AGOverviewHistory', N'CaptureTime', N'AGName', 1, 70),
    (N'mon', N'AGReplicaHistory', N'CaptureTime', N'AGName,ReplicaServer', 1, 70),
    (N'mon', N'AGDatabaseHistory', N'CaptureTime', N'AGName,DatabaseName,ReplicaServer', 1, 70),
    (N'mon', N'ListenerHistory', N'CaptureTime', N'ListenerName,DNSName,IPAddress', 1, 70),
    (N'mon', N'EndpointHistory', N'CaptureTime', N'EndpointName,EndpointType,Protocol', 1, 70),
    (N'mon', N'AlertHistory', N'AlertTime', N'ModuleName,AlertTitle,Severity', 1, 80)
) AS source (SchemaName, TableName, TimeColumn, DedupeColumns, IsEnabled, SyncOrder)
ON target.SchemaName = source.SchemaName AND target.TableName = source.TableName
WHEN MATCHED THEN
    UPDATE SET TimeColumn = source.TimeColumn,
               DedupeColumns = source.DedupeColumns,
               IsEnabled = source.IsEnabled,
               SyncOrder = source.SyncOrder
WHEN NOT MATCHED THEN
    INSERT (SchemaName, TableName, TimeColumn, DedupeColumns, IsEnabled, SyncOrder)
    VALUES (source.SchemaName, source.TableName, source.TimeColumn, source.DedupeColumns, source.IsEnabled, source.SyncOrder);
GO

CREATE OR ALTER PROCEDURE mon.usp_SyncRepositoryToCentral
    @CentralLinkedServer SYSNAME,
    @CentralDatabase SYSNAME = N'DBA_SQLMonitor',
    @LookbackMinutes INT = 1440,
    @TableName SYSNAME = NULL,
    @DryRun BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT OFF;

    IF @CentralLinkedServer IS NULL OR LTRIM(RTRIM(@CentralLinkedServer)) = N''
        THROW 51000, 'Central linked server name is required. Create a linked server to the central SQL Monitor repository first.', 1;

    IF @LookbackMinutes IS NULL OR @LookbackMinutes <= 0
        SET @LookbackMinutes = 1440;

    DECLARE @SyncRunID BIGINT;
    INSERT INTO mon.CentralSyncRuns (CentralLinkedServer, CentralDatabase, LookbackMinutes, Status)
    VALUES (@CentralLinkedServer, @CentralDatabase, @LookbackMinutes, N'Started');
    SET @SyncRunID = SCOPE_IDENTITY();

    BEGIN TRY
        DECLARE @centralPrefix NVARCHAR(600) = QUOTENAME(@CentralLinkedServer) + N'.' + QUOTENAME(@CentralDatabase) + N'.';
        DECLARE @windowStart DATETIME2 = DATEADD(MINUTE, -1 * @LookbackMinutes, SYSDATETIME());
        DECLARE @sql NVARCHAR(MAX);

        CREATE TABLE #InstanceMap
        (
            LocalInstanceID INT NOT NULL PRIMARY KEY,
            CentralInstanceID INT NOT NULL
        );

        SET @sql = N'
INSERT INTO ' + @centralPrefix + N'[mon].[MonitoredInstances] (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
SELECT l.ServerName, l.InstanceName, l.DisplayName, l.EnvironmentName, l.IsActive
FROM mon.MonitoredInstances AS l
WHERE NOT EXISTS (
    SELECT 1
    FROM ' + @centralPrefix + N'[mon].[MonitoredInstances] AS c
    WHERE c.DisplayName = l.DisplayName
);

UPDATE c
SET c.ServerName = l.ServerName,
    c.InstanceName = l.InstanceName,
    c.EnvironmentName = l.EnvironmentName,
    c.IsActive = l.IsActive
FROM ' + @centralPrefix + N'[mon].[MonitoredInstances] AS c
INNER JOIN mon.MonitoredInstances AS l ON c.DisplayName = l.DisplayName;

INSERT INTO #InstanceMap (LocalInstanceID, CentralInstanceID)
SELECT l.InstanceID, c.InstanceID
FROM mon.MonitoredInstances AS l
INNER JOIN ' + @centralPrefix + N'[mon].[MonitoredInstances] AS c ON c.DisplayName = l.DisplayName;';

        IF @DryRun = 0
            EXEC sys.sp_executesql @sql;

        DECLARE table_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT SchemaName, TableName, TimeColumn, ISNULL(DedupeColumns, N'')
            FROM mon.CentralSyncTables
            WHERE IsEnabled = 1
              AND (@TableName IS NULL OR TableName = @TableName OR SchemaName + N'.' + TableName = @TableName)
              AND OBJECT_ID(QUOTENAME(SchemaName) + N'.' + QUOTENAME(TableName), 'U') IS NOT NULL
            ORDER BY SyncOrder, SchemaName, TableName;

        DECLARE @schema SYSNAME, @table SYSNAME, @timeColumn SYSNAME, @dedupeColumns NVARCHAR(1000);
        OPEN table_cursor;
        FETCH NEXT FROM table_cursor INTO @schema, @table, @timeColumn, @dedupeColumns;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE @tableRunID BIGINT;
            INSERT INTO mon.CentralSyncTableRuns (SyncRunID, SchemaName, TableName, Status)
            VALUES (@SyncRunID, @schema, @table, N'Started');
            SET @tableRunID = SCOPE_IDENTITY();

            BEGIN TRY
                IF COL_LENGTH(@schema + N'.' + @table, @timeColumn) IS NULL
                    THROW 51001, 'Configured sync time column does not exist in local table.', 1;

                DECLARE @objectID INT = OBJECT_ID(QUOTENAME(@schema) + N'.' + QUOTENAME(@table), 'U');
                DECLARE @columnList NVARCHAR(MAX) = N'';
                DECLARE @selectList NVARCHAR(MAX) = N'';
                DECLARE @dedupePredicate NVARCHAR(MAX) = N'';

                SELECT @columnList = STUFF((
                    SELECT N', ' + QUOTENAME(c.name)
                    FROM sys.columns c
                    WHERE c.object_id = @objectID
                      AND c.is_identity = 0
                      AND c.is_computed = 0
                      AND c.name <> N'CollectorNodeID'
                    ORDER BY c.column_id
                    FOR XML PATH(''), TYPE
                ).value('.', 'nvarchar(max)'), 1, 2, N'');

                SELECT @selectList = STUFF((
                    SELECT N', ' + CASE WHEN c.name = N'InstanceID' THEN N'im.CentralInstanceID' ELSE N's.' + QUOTENAME(c.name) END
                    FROM sys.columns c
                    WHERE c.object_id = @objectID
                      AND c.is_identity = 0
                      AND c.is_computed = 0
                      AND c.name <> N'CollectorNodeID'
                    ORDER BY c.column_id
                    FOR XML PATH(''), TYPE
                ).value('.', 'nvarchar(max)'), 1, 2, N'');

                IF @columnList IS NULL OR @selectList IS NULL
                    THROW 51002, 'No insertable columns were found for sync table.', 1;

                SET @dedupePredicate = N't.[InstanceID] = im.CentralInstanceID AND t.' + QUOTENAME(@timeColumn) + N' = s.' + QUOTENAME(@timeColumn);

                SELECT @dedupePredicate = @dedupePredicate + N' AND ((t.' + QUOTENAME(LTRIM(RTRIM(value))) + N' = s.' + QUOTENAME(LTRIM(RTRIM(value))) + N') OR (t.' + QUOTENAME(LTRIM(RTRIM(value))) + N' IS NULL AND s.' + QUOTENAME(LTRIM(RTRIM(value))) + N' IS NULL))'
                FROM STRING_SPLIT(@dedupeColumns, N',') d
                INNER JOIN sys.columns c
                    ON c.object_id = @objectID
                   AND c.name = LTRIM(RTRIM(d.value))
                WHERE LTRIM(RTRIM(d.value)) <> N''
                  AND LTRIM(RTRIM(d.value)) <> N'InstanceID';

                SET @sql = N'
INSERT INTO ' + @centralPrefix + QUOTENAME(@schema) + N'.' + QUOTENAME(@table) + N' (' + @columnList + N')
SELECT ' + @selectList + N'
FROM ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table) + N' AS s
INNER JOIN #InstanceMap AS im ON s.InstanceID = im.LocalInstanceID
WHERE s.' + QUOTENAME(@timeColumn) + N' >= @WindowStart
  AND NOT EXISTS (
      SELECT 1
      FROM ' + @centralPrefix + QUOTENAME(@schema) + N'.' + QUOTENAME(@table) + N' AS t
      WHERE ' + @dedupePredicate + N'
  );

SET @RowsInserted = @@ROWCOUNT;';

                DECLARE @rowsInserted INT = 0;
                IF @DryRun = 0
                    EXEC sys.sp_executesql @sql, N'@WindowStart DATETIME2, @RowsInserted INT OUTPUT', @WindowStart = @windowStart, @RowsInserted = @rowsInserted OUTPUT;

                UPDATE mon.CentralSyncTableRuns
                SET EndedAt = SYSDATETIME(),
                    RowsInserted = @rowsInserted,
                    Status = CASE WHEN @DryRun = 1 THEN N'DryRun' ELSE N'Success' END
                WHERE SyncTableRunID = @tableRunID;
            END TRY
            BEGIN CATCH
                UPDATE mon.CentralSyncTableRuns
                SET EndedAt = SYSDATETIME(),
                    Status = N'Failed',
                    ErrorMessage = ERROR_MESSAGE()
                WHERE SyncTableRunID = @tableRunID;
            END CATCH;

            FETCH NEXT FROM table_cursor INTO @schema, @table, @timeColumn, @dedupeColumns;
        END;

        CLOSE table_cursor;
        DEALLOCATE table_cursor;

        UPDATE mon.CentralSyncRuns
        SET EndedAt = SYSDATETIME(),
            Status = CASE WHEN EXISTS (SELECT 1 FROM mon.CentralSyncTableRuns WHERE SyncRunID = @SyncRunID AND Status = N'Failed') THEN N'CompletedWithErrors' ELSE CASE WHEN @DryRun = 1 THEN N'DryRun' ELSE N'Success' END END
        WHERE SyncRunID = @SyncRunID;

        SELECT * FROM mon.CentralSyncRuns WHERE SyncRunID = @SyncRunID;
        SELECT * FROM mon.CentralSyncTableRuns WHERE SyncRunID = @SyncRunID ORDER BY SyncTableRunID;
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'table_cursor') >= -1
        BEGIN
            CLOSE table_cursor;
            DEALLOCATE table_cursor;
        END;

        UPDATE mon.CentralSyncRuns
        SET EndedAt = SYSDATETIME(),
            Status = N'Failed',
            ErrorMessage = ERROR_MESSAGE()
        WHERE SyncRunID = @SyncRunID;

        THROW;
    END CATCH;
END;
GO
