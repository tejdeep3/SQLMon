-- Update Retention Procedure to include ALL monitoring tables
-- Run this on DBA_SQLMonitor database

USE [DBA_SQLMonitor]
GO

CREATE OR ALTER PROCEDURE [mon].[usp_PurgeRetention]
    @RetentionDays INT = 90,
    @BatchSize INT = 5000,
    @Verbose BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CutoffDate DATETIME2 = DATEADD(DAY, -@RetentionDays, SYSDATETIME());
    DECLARE @DeletedCount INT = 0;
    DECLARE @TotalDeleted INT = 0;
    DECLARE @CurrentTable NVARCHAR(128);
    DECLARE @StartTime DATETIME = GETDATE();

    -- Create table to track deletion progress
    DECLARE @PurgeLog TABLE (
        TableName NVARCHAR(128),
        RowsDeleted INT,
        StartTime DATETIME,
        EndTime DATETIME,
        DurationSeconds INT
    );

    -- List of all tables with date columns to purge
    DECLARE @TablesToPurge TABLE (
        TableName NVARCHAR(128),
        DateColumn NVARCHAR(128),
        Processed BIT DEFAULT 0
    );

    INSERT INTO @TablesToPurge (TableName, DateColumn)
    VALUES
        -- Core collectors
        ('mon.KPIHistory', 'CaptureTime'),
        ('mon.DiskVolumeHistory', 'CaptureTime'),
        ('mon.ConfigHistory', 'CaptureTime'),
        ('mon.CPUHistory', 'CaptureTime'),
        ('mon.MemoryHistory', 'CaptureTime'),
        ('mon.IOFileHistory', 'CaptureTime'),
        ('mon.TempDBHistory', 'CaptureTime'),
        ('mon.DBOptionsHistory', 'CaptureTime'),
        ('mon.BackupStatusHistory', 'CaptureTime'),
        
        -- Advanced collectors
        ('dbo.WaitStats', 'CollectionDateTime'),
        ('dbo.TopQueries', 'CollectionDateTime'),
        ('dbo.MissingIndexes', 'CollectionDateTime'),
        ('mon.BlockingHistory', 'CaptureTime'),
        ('mon.LongRunningHistory', 'CaptureTime'),
        
        -- Daily collectors
        ('dbo.IndexFragmentation', 'CollectionDateTime'),
        ('mon.AgentJobHistory', 'CaptureTime'),
        ('mon.DeadlockHistory', 'DeadlockTime'),
        ('mon.AGOverviewHistory', 'CaptureTime'),
        ('mon.AGReplicaHistory', 'CaptureTime'),
        ('mon.AGDatabaseHistory', 'CaptureTime'),
        ('mon.ListenerHistory', 'CaptureTime'),
        ('mon.EndpointHistory', 'CaptureTime'),
        ('mon.AlertHistory', 'AlertTime');

    IF @Verbose = 1
        PRINT 'Starting retention purge at ' + CONVERT(VARCHAR(20), @StartTime, 120);
    IF @Verbose = 1
        PRINT 'Cutoff date: ' + CONVERT(VARCHAR(20), @CutoffDate, 120);

    -- Process each table
    WHILE EXISTS (SELECT 1 FROM @TablesToPurge WHERE Processed = 0)
    BEGIN
        SELECT TOP 1 @CurrentTable = TableName 
        FROM @TablesToPurge 
        WHERE Processed = 0;

        DECLARE @DateColumn NVARCHAR(128);
        SELECT @DateColumn = DateColumn FROM @TablesToPurge WHERE TableName = @CurrentTable;

        IF @Verbose = 1
            PRINT 'Purging ' + @CurrentTable + '...';

        -- Delete in batches to avoid long locks
        SET @DeletedCount = 1;
        WHILE @DeletedCount > 0
        BEGIN
            DECLARE @SQL NVARCHAR(MAX);
            SET @SQL = 'DELETE TOP (' + CAST(@BatchSize AS NVARCHAR(20)) + ') FROM ' + @CurrentTable + 
                      ' WHERE ' + @DateColumn + ' < @CutoffDate';

            BEGIN TRY
                EXEC sp_executesql @SQL, N'@CutoffDate DATETIME2', @CutoffDate;
                SET @DeletedCount = @@ROWCOUNT;
                SET @TotalDeleted = @TotalDeleted + @DeletedCount;
                
                IF @Verbose = 1 AND @DeletedCount > 0
                    PRINT '  Deleted ' + CAST(@DeletedCount AS VARCHAR(20)) + ' rows from ' + @CurrentTable;
            END TRY
            BEGIN CATCH
                IF @Verbose = 1
                    PRINT '  ERROR purging ' + @CurrentTable + ': ' + ERROR_MESSAGE();
                
                SET @DeletedCount = 0; -- Break loop on error
            END CATCH
        END;

        -- Log this table's purge
        INSERT INTO @PurgeLog (TableName, RowsDeleted, StartTime, EndTime, DurationSeconds)
        VALUES (@CurrentTable, @TotalDeleted, @StartTime, GETDATE(), DATEDIFF(SECOND, @StartTime, GETDATE()));

        -- Mark as processed
        UPDATE @TablesToPurge SET Processed = 1 WHERE TableName = @CurrentTable;
        SET @TotalDeleted = 0;
    END;

    -- Summary
    IF @Verbose = 1
    BEGIN
        PRINT '';
        PRINT '=== Purge Summary ===';
        PRINT 'Completed at: ' + CONVERT(VARCHAR(20), GETDATE(), 120);
        PRINT 'Total duration: ' + CAST(DATEDIFF(SECOND, @StartTime, GETDATE()) AS VARCHAR(20)) + ' seconds';
        PRINT '';
        
        SELECT 
            TableName,
            RowsDeleted,
            DurationSeconds
        FROM @PurgeLog
        WHERE RowsDeleted > 0
        ORDER BY RowsDeleted DESC;
    END;

    -- Log the purge operation
    INSERT INTO mon.CollectionRuns (InstanceID, ModuleName, StartTime, EndTime, Status)
    VALUES (
        0, -- System operation
        'RetentionPurge',
        @StartTime,
        GETDATE(),
        'Success'
    );
END;
GO

PRINT 'Retention procedure updated successfully';
PRINT 'Execute with: EXEC mon.usp_PurgeRetention @RetentionDays = 90, @Verbose = 1';
