-- ============================================================
-- Phase 18: Store Windows VM collection archive metadata
-- ============================================================
SET NOCOUNT ON;
USE [DBA_SQLMonitor];
GO

IF OBJECT_ID('mon.WindowsCollectionArchive', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsCollectionArchive (
        ArchiveID INT IDENTITY(1,1) PRIMARY KEY,
        TargetID INT NOT NULL,
        CollectedAt DATETIME2 NOT NULL CONSTRAINT DF_WindowsCollectionArchive_CollectedAt DEFAULT (SYSDATETIME()),
        ArchivePath NVARCHAR(260) NOT NULL,
        CONSTRAINT FK_WindowsCollectionArchive_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
    PRINT 'Created mon.WindowsCollectionArchive table';
END;
GO
