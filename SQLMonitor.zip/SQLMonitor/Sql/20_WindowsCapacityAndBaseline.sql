-- ============================================================
-- Phase 20: VM Capacity Forecasting & Baseline Anomaly Detection
-- ============================================================
SET NOCOUNT ON;

-- ============================================================
-- Table: mon.WindowsPerformanceBaseline
-- Purpose: Stores per-target rolling baselines for key metrics
--          (hourly averages, standard deviations, sample counts)
-- ============================================================
IF OBJECT_ID('mon.WindowsPerformanceBaseline', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsPerformanceBaseline
    (
        BaselineID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsPerformanceBaseline PRIMARY KEY,
        TargetID INT NOT NULL,
        MetricName NVARCHAR(60) NOT NULL,
        HourOfDay TINYINT NOT NULL,          -- 0-23, allows time-of-day patterns
        DayOfWeek TINYINT NOT NULL,          -- 1=Sun .. 7=Sat, allows weekday patterns
        AvgValue DECIMAL(18,4) NOT NULL,
        StdDevValue DECIMAL(18,4) NOT NULL,
        MinValue DECIMAL(18,4) NOT NULL,
        MaxValue DECIMAL(18,4) NOT NULL,
        SampleCount INT NOT NULL,
        LastCalculatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsPerfBaseline_LastCalc DEFAULT (SYSDATETIME()),
        CONSTRAINT FK_WindowsPerfBaseline_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID),
        CONSTRAINT UQ_WindowsPerfBaseline_Unique UNIQUE (TargetID, MetricName, HourOfDay, DayOfWeek)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsPerfBaseline_Target_Metric' AND object_id = OBJECT_ID('mon.WindowsPerformanceBaseline'))
    CREATE INDEX IX_WindowsPerfBaseline_Target_Metric ON mon.WindowsPerformanceBaseline(TargetID, MetricName);

-- ============================================================
-- Table: mon.WindowsCapacityForecast
-- Purpose: Stores capacity exhaustion forecasts per target/metric
-- ============================================================
IF OBJECT_ID('mon.WindowsCapacityForecast', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsCapacityForecast
    (
        ForecastID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsCapacityForecast PRIMARY KEY,
        TargetID INT NOT NULL,
        MetricName NVARCHAR(60) NOT NULL,
        CurrentValue DECIMAL(18,4) NOT NULL,
        GrowthRatePerDay DECIMAL(18,6) NOT NULL,  -- slope from linear regression
        ForecastExhaustionDate DATE NULL,           -- projected date when limit is hit
        DaysUntilExhaustion INT NULL,               -- derived: days from now until exhaustion
        ConfidencePercent DECIMAL(5,2) NULL,        -- R-squared of the regression fit
        RecommendedAction NVARCHAR(500) NULL,
        CalculatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsCapacityForecast_Calc DEFAULT (SYSDATETIME()),
        CONSTRAINT FK_WindowsCapacityForecast_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID),
        CONSTRAINT UQ_WindowsCapacityForecast_Unique UNIQUE (TargetID, MetricName)
    );
END;

-- ============================================================
-- Table: mon.WindowsAnomalyLog
-- Purpose: Records detected anomalies for historical tracking
-- ============================================================
IF OBJECT_ID('mon.WindowsAnomalyLog', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsAnomalyLog
    (
        AnomalyID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsAnomalyLog PRIMARY KEY,
        TargetID INT NOT NULL,
        MetricName NVARCHAR(60) NOT NULL,
        DetectedAt DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsAnomalyLog_Detected DEFAULT (SYSDATETIME()),
        ActualValue DECIMAL(18,4) NOT NULL,
        BaselineAvg DECIMAL(18,4) NOT NULL,
        BaselineStdDev DECIMAL(18,4) NOT NULL,
        DeviationMultiplier DECIMAL(8,2) NOT NULL,  -- how many stddevs from mean
        Severity NVARCHAR(20) NOT NULL CONSTRAINT DF_WindowsAnomalyLog_Severity DEFAULT (N'Warning'),
        IsAcknowledged BIT NOT NULL CONSTRAINT DF_WindowsAnomalyLog_IsAck DEFAULT (0),
        AcknowledgedBy NVARCHAR(128) NULL,
        AcknowledgedAt DATETIME2(0) NULL,
        Notes NVARCHAR(1000) NULL,
        CONSTRAINT FK_WindowsAnomalyLog_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsAnomalyLog_Target_Time' AND object_id = OBJECT_ID('mon.WindowsAnomalyLog'))
    CREATE INDEX IX_WindowsAnomalyLog_Target_Time ON mon.WindowsAnomalyLog(TargetID, DetectedAt DESC);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsAnomalyLog_Unack' AND object_id = OBJECT_ID('mon.WindowsAnomalyLog'))
    CREATE INDEX IX_WindowsAnomalyLog_Unack ON mon.WindowsAnomalyLog(IsAcknowledged, DetectedAt DESC) INCLUDE (TargetID, MetricName, Severity);

-- ============================================================
-- Stored Procedure: mon.usp_CalculateWindowsBaselines
-- Purpose: Computes per-target, per-metric baselines from
--          WindowsPerformanceSamples, grouped by hour-of-day
--          and day-of-week to capture time-of-day patterns.
--          Uses a configurable lookback window (default 30 days).
-- ============================================================
IF OBJECT_ID('mon.usp_CalculateWindowsBaselines', 'P') IS NULL
    EXEC(N'CREATE PROCEDURE mon.usp_CalculateWindowsBaselines AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE mon.usp_CalculateWindowsBaselines
    @TargetID INT = NULL,        -- NULL = all targets
    @LookbackDays INT = 30,
    @Metrics NVARCHAR(500) = N'CPUPercent,MemoryUsedPercent,DiskUsedPercent'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Cutoff DATETIME2(0) = DATEADD(DAY, -@LookbackDays, SYSDATETIME());
    DECLARE @Now DATETIME2(0) = SYSDATETIME();

    -- Parse metrics list into temp table
    CREATE TABLE #Metrics (MetricName NVARCHAR(60) NOT NULL);
    INSERT INTO #Metrics (MetricName)
    SELECT LTRIM(RTRIM(value))
    FROM STRING_SPLIT(@Metrics, ',');

    -- Calculate baselines per target, metric, hour-of-day, day-of-week
    ;WITH RawData AS (
        SELECT
            ps.TargetID,
            m.MetricName,
            DATEPART(HOUR, ps.CaptureTime) AS HourOfDay,
            DATEPART(WEEKDAY, ps.CaptureTime) AS DayOfWeek,
            CASE m.MetricName
                WHEN N'CPUPercent' THEN ps.CPUPercent
                WHEN N'MemoryUsedPercent' THEN ps.MemoryUsedPercent
                WHEN N'DiskUsedPercent' THEN ps.DiskUsedPercent
                WHEN N'ProcessCount' THEN CAST(ps.ProcessCount AS DECIMAL(18,4))
                WHEN N'ServiceStoppedCount' THEN CAST(ps.ServiceStoppedCount AS DECIMAL(18,4))
                WHEN N'NetworkBytesPerSec' THEN CAST(ps.NetworkBytesPerSec AS DECIMAL(18,4))
            END AS MetricValue
        FROM mon.WindowsPerformanceSamples ps
        CROSS JOIN #Metrics m
        WHERE ps.CaptureTime >= @Cutoff
          AND (@TargetID IS NULL OR ps.TargetID = @TargetID)
    ),
    Aggregated AS (
        SELECT
            TargetID,
            MetricName,
            HourOfDay,
            DayOfWeek,
            AVG(MetricValue) AS AvgValue,
            ISNULL(STDEV(MetricValue), 0) AS StdDevValue,
            MIN(MetricValue) AS MinValue,
            MAX(MetricValue) AS MaxValue,
            COUNT(*) AS SampleCount
        FROM RawData
        WHERE MetricValue IS NOT NULL
        GROUP BY TargetID, MetricName, HourOfDay, DayOfWeek
        HAVING COUNT(*) >= 3  -- minimum samples for meaningful baseline
    )
    MERGE mon.WindowsPerformanceBaseline AS target
    USING Aggregated AS source
        ON target.TargetID = source.TargetID
       AND target.MetricName = source.MetricName
       AND target.HourOfDay = source.HourOfDay
       AND target.DayOfWeek = source.DayOfWeek
    WHEN MATCHED THEN UPDATE SET
        AvgValue = source.AvgValue,
        StdDevValue = source.StdDevValue,
        MinValue = source.MinValue,
        MaxValue = source.MaxValue,
        SampleCount = source.SampleCount,
        LastCalculatedAt = @Now
    WHEN NOT MATCHED THEN INSERT
        (TargetID, MetricName, HourOfDay, DayOfWeek, AvgValue, StdDevValue, MinValue, MaxValue, SampleCount, LastCalculatedAt)
    VALUES
        (source.TargetID, source.MetricName, source.HourOfDay, source.DayOfWeek,
         source.AvgValue, source.StdDevValue, source.MinValue, source.MaxValue, source.SampleCount, @Now);

    DROP TABLE #Metrics;

    SELECT @@ROWCOUNT AS BaselinesUpdated;
END;
GO

-- ============================================================
-- Stored Procedure: mon.usp_DetectWindowsAnomalies
-- Purpose: Compares latest performance samples against baselines
--          and inserts anomalies into WindowsAnomalyLog.
--          Only flags deviations beyond the configured threshold
--          (default: 2.5 standard deviations from baseline).
-- ============================================================
IF OBJECT_ID('mon.usp_DetectWindowsAnomalies', 'P') IS NULL
    EXEC(N'CREATE PROCEDURE mon.usp_DetectWindowsAnomalies AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE mon.usp_DetectWindowsAnomalies
    @TargetID INT = NULL,
    @StdDevThreshold DECIMAL(8,2) = 2.5,
    @Metrics NVARCHAR(500) = N'CPUPercent,MemoryUsedPercent,DiskUsedPercent',
    @LookbackMinutes INT = 15
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Since DATETIME2(0) = DATEADD(MINUTE, -@LookbackMinutes, SYSDATETIME());

    -- Parse metrics list
    CREATE TABLE #Metrics (MetricName NVARCHAR(60) NOT NULL);
    INSERT INTO #Metrics (MetricName)
    SELECT LTRIM(RTRIM(value))
    FROM STRING_SPLIT(@Metrics, ',');

    -- Get latest sample per target
    ;WITH LatestSamples AS (
        SELECT
            ps.TargetID,
            ps.CaptureTime,
            ps.CPUPercent,
            ps.MemoryUsedPercent,
            ps.DiskUsedPercent,
            ps.ProcessCount,
            ps.ServiceStoppedCount,
            ps.NetworkBytesPerSec,
            ROW_NUMBER() OVER (PARTITION BY ps.TargetID ORDER BY ps.CaptureTime DESC) AS rn
        FROM mon.WindowsPerformanceSamples ps
        WHERE ps.CaptureTime >= @Since
          AND (@TargetID IS NULL OR ps.TargetID = @TargetID)
    ),
    Unpivoted AS (
        SELECT
            ls.TargetID,
            ls.CaptureTime,
            m.MetricName,
            CASE m.MetricName
                WHEN N'CPUPercent' THEN ls.CPUPercent
                WHEN N'MemoryUsedPercent' THEN ls.MemoryUsedPercent
                WHEN N'DiskUsedPercent' THEN ls.DiskUsedPercent
                WHEN N'ProcessCount' THEN CAST(ls.ProcessCount AS DECIMAL(18,4))
                WHEN N'ServiceStoppedCount' THEN CAST(ls.ServiceStoppedCount AS DECIMAL(18,4))
                WHEN N'NetworkBytesPerSec' THEN CAST(ls.NetworkBytesPerSec AS DECIMAL(18,4))
            END AS ActualValue
        FROM LatestSamples ls
        CROSS JOIN #Metrics m
        WHERE ls.rn = 1
    )
    INSERT INTO mon.WindowsAnomalyLog
        (TargetID, MetricName, DetectedAt, ActualValue, BaselineAvg, BaselineStdDev, DeviationMultiplier, Severity)
    SELECT
        u.TargetID,
        u.MetricName,
        u.CaptureTime,
        u.ActualValue,
        b.AvgValue,
        b.StdDevValue,
        CASE WHEN b.StdDevValue > 0 THEN ABS(u.ActualValue - b.AvgValue) / b.StdDevValue ELSE 0 END AS DeviationMultiplier,
        CASE
            WHEN b.StdDevValue > 0 AND ABS(u.ActualValue - b.AvgValue) / b.StdDevValue >= 4.0 THEN N'Critical'
            WHEN b.StdDevValue > 0 AND ABS(u.ActualValue - b.AvgValue) / b.StdDevValue >= 2.5 THEN N'Warning'
            ELSE N'Info'
        END AS Severity
    FROM Unpivoted u
    INNER JOIN mon.WindowsPerformanceBaseline b
        ON u.TargetID = b.TargetID
       AND u.MetricName = b.MetricName
       AND b.HourOfDay = DATEPART(HOUR, u.CaptureTime)
       AND b.DayOfWeek = DATEPART(WEEKDAY, u.CaptureTime)
    WHERE u.ActualValue IS NOT NULL
      AND b.StdDevValue > 0
      AND ABS(u.ActualValue - b.AvgValue) / b.StdDevValue >= @StdDevThreshold
      AND NOT EXISTS (
          -- Avoid duplicate anomalies within the lookback window
          SELECT 1 FROM mon.WindowsAnomalyLog existing
          WHERE existing.TargetID = u.TargetID
            AND existing.MetricName = u.MetricName
            AND existing.DetectedAt >= @Since
            AND existing.IsAcknowledged = 0
      );

    DROP TABLE #Metrics;

    SELECT @@ROWCOUNT AS AnomaliesDetected;
END;
GO

-- ============================================================
-- Stored Procedure: mon.usp_CalculateWindowsCapacityForecast
-- Purpose: Uses linear regression on 30/60/90 days of samples
--          to forecast when disk/memory will be exhausted.
--          Stores results in WindowsCapacityForecast.
-- ============================================================
IF OBJECT_ID('mon.usp_CalculateWindowsCapacityForecast', 'P') IS NULL
    EXEC(N'CREATE PROCEDURE mon.usp_CalculateWindowsCapacityForecast AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE mon.usp_CalculateWindowsCapacityForecast
    @TargetID INT = NULL,
    @LookbackDays INT = 90
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Cutoff DATETIME2(0) = DATEADD(DAY, -@LookbackDays, SYSDATETIME());
    DECLARE @Now DATETIME2(0) = SYSDATETIME();

    ;WITH DailyDisk AS (
        -- Daily max disk used percent per target
        SELECT
            TargetID,
            CAST(CaptureTime AS DATE) AS SampleDate,
            MAX(DiskUsedPercent) AS MaxDiskUsedPercent,
            MIN(DiskFreeGB) AS MinDiskFreeGB
        FROM mon.WindowsPerformanceSamples
        WHERE CaptureTime >= @Cutoff
          AND DiskUsedPercent IS NOT NULL
          AND (@TargetID IS NULL OR TargetID = @TargetID)
        GROUP BY TargetID, CAST(CaptureTime AS DATE)
    ),
    DailyMemory AS (
        -- Daily max memory used percent per target
        SELECT
            TargetID,
            CAST(CaptureTime AS DATE) AS SampleDate,
            MAX(MemoryUsedPercent) AS MaxMemoryUsedPercent
        FROM mon.WindowsPerformanceSamples
        WHERE CaptureTime >= @Cutoff
          AND MemoryUsedPercent IS NOT NULL
          AND (@TargetID IS NULL OR TargetID = @TargetID)
        GROUP BY TargetID, CAST(CaptureTime AS DATE)
    ),
    -- Linear regression for DiskUsedPercent: y = a + b*x
    DiskRegression AS (
        SELECT
            TargetID,
            COUNT(*) AS n,
            AVG(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT)) AS avg_x,
            AVG(CAST(MaxDiskUsedPercent AS FLOAT)) AS avg_y,
            SUM(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT)) AS sum_x,
            SUM(CAST(MaxDiskUsedPercent AS FLOAT)) AS sum_y,
            SUM(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT) * CAST(MaxDiskUsedPercent AS FLOAT)) AS sum_xy,
            SUM(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT) * CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT)) AS sum_xx,
            SUM(CAST(MaxDiskUsedPercent AS FLOAT) * CAST(MaxDiskUsedPercent AS FLOAT)) AS sum_yy,
            MAX(MaxDiskUsedPercent) AS CurrentValue,
            MIN(MinDiskFreeGB) AS CurrentFreeGB
        FROM DailyDisk
        GROUP BY TargetID
        HAVING COUNT(*) >= 2
    ),
    DiskForecast AS (
        SELECT
            TargetID,
            N'DiskUsedPercent' AS MetricName,
            CurrentValue,
            CurrentFreeGB,
            CASE
                WHEN (n * sum_xx - sum_x * sum_x) = 0 THEN 0
                ELSE (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x * sum_x)
            END AS Slope,
            avg_y - (CASE
                WHEN (n * sum_xx - sum_x * sum_x) = 0 THEN 0
                ELSE (n * sum_xy - sum_x * sum_y) / NULLIF(n * sum_xx - sum_x * sum_x, 0)
            END) * avg_x AS Intercept,
            -- R-squared
            CASE
                WHEN (n * sum_xx - sum_x * sum_x) = 0 THEN 0
                ELSE POWER(n * sum_xy - sum_x * sum_y, 2) /
                     NULLIF((n * sum_xx - sum_x * sum_x) * (n * sum_yy - sum_y * sum_y), 0)
            END AS RSquared,
            n
        FROM DiskRegression
    ),
    -- Linear regression for MemoryUsedPercent
    MemoryRegression AS (
        SELECT
            TargetID,
            COUNT(*) AS n,
            AVG(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT)) AS avg_x,
            AVG(CAST(MaxMemoryUsedPercent AS FLOAT)) AS avg_y,
            SUM(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT)) AS sum_x,
            SUM(CAST(MaxMemoryUsedPercent AS FLOAT)) AS sum_y,
            SUM(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT) * CAST(MaxMemoryUsedPercent AS FLOAT)) AS sum_xy,
            SUM(CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT) * CAST(DATEDIFF(DAY, @Cutoff, SampleDate) AS FLOAT)) AS sum_xx,
            SUM(CAST(MaxMemoryUsedPercent AS FLOAT) * CAST(MaxMemoryUsedPercent AS FLOAT)) AS sum_yy,
            MAX(MaxMemoryUsedPercent) AS CurrentValue
        FROM DailyMemory
        GROUP BY TargetID
        HAVING COUNT(*) >= 2
    ),
    MemoryForecast AS (
        SELECT
            TargetID,
            N'MemoryUsedPercent' AS MetricName,
            CurrentValue,
            NULL AS CurrentFreeGB,
            CASE
                WHEN (n * sum_xx - sum_x * sum_x) = 0 THEN 0
                ELSE (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x * sum_x)
            END AS Slope,
            avg_y - (CASE
                WHEN (n * sum_xx - sum_x * sum_x) = 0 THEN 0
                ELSE (n * sum_xy - sum_x * sum_y) / NULLIF(n * sum_xx - sum_x * sum_x, 0)
            END) * avg_x AS Intercept,
            CASE
                WHEN (n * sum_xx - sum_x * sum_x) = 0 THEN 0
                ELSE POWER(n * sum_xy - sum_x * sum_y, 2) /
                     NULLIF((n * sum_xx - sum_x * sum_x) * (n * sum_yy - sum_y * sum_y), 0)
            END AS RSquared,
            n
        FROM MemoryRegression
    ),
    Combined AS (
        SELECT TargetID, MetricName, CurrentValue, CurrentFreeGB, Slope, RSquared FROM DiskForecast
        UNION ALL
        SELECT TargetID, MetricName, CurrentValue, CurrentFreeGB, Slope, RSquared FROM MemoryForecast
    )
    MERGE mon.WindowsCapacityForecast AS target
    USING Combined AS source
        ON target.TargetID = source.TargetID
       AND target.MetricName = source.MetricName
    WHEN MATCHED THEN UPDATE SET
        CurrentValue = source.CurrentValue,
        GrowthRatePerDay = source.Slope,
        ForecastExhaustionDate = CASE
            WHEN source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope > 3650 THEN NULL  -- >10 years, not meaningful
            ELSE CAST(DATEADD(DAY, (100.0 - source.CurrentValue) / source.Slope, @Now) AS DATE)
        END,
        DaysUntilExhaustion = CASE
            WHEN source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope > 3650 THEN NULL
            ELSE CAST((100.0 - source.CurrentValue) / source.Slope AS INT)
        END,
        ConfidencePercent = ISNULL(source.RSquared * 100, 0),
        RecommendedAction = CASE
            WHEN source.Slope <= 0 THEN N'Stable — no action needed'
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 7 THEN N'URGENT: Capacity will be exhausted within 7 days'
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 30 THEN N'Plan capacity expansion within 30 days'
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 90 THEN N'Monitor closely — review within 90 days'
            ELSE N'Healthy — no immediate action'
        END,
        CalculatedAt = @Now
    WHEN NOT MATCHED THEN INSERT
        (TargetID, MetricName, CurrentValue, GrowthRatePerDay, ForecastExhaustionDate, DaysUntilExhaustion, ConfidencePercent, RecommendedAction, CalculatedAt)
    VALUES
        (source.TargetID, source.MetricName, source.CurrentValue, source.Slope,
         CASE
            WHEN source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope > 3650 THEN NULL
            ELSE CAST(DATEADD(DAY, (100.0 - source.CurrentValue) / source.Slope, @Now) AS DATE)
         END,
         CASE
            WHEN source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 0 THEN NULL
            WHEN (100.0 - source.CurrentValue) / source.Slope > 3650 THEN NULL
            ELSE CAST((100.0 - source.CurrentValue) / source.Slope AS INT)
         END,
         ISNULL(source.RSquared * 100, 0),
         CASE
            WHEN source.Slope <= 0 THEN N'Stable — no action needed'
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 7 THEN N'URGENT: Capacity will be exhausted within 7 days'
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 30 THEN N'Plan capacity expansion within 30 days'
            WHEN (100.0 - source.CurrentValue) / source.Slope <= 90 THEN N'Monitor closely — review within 90 days'
            ELSE N'Healthy — no immediate action'
         END,
         @Now);

    SELECT @@ROWCOUNT AS ForecastsUpdated;
END;
GO

-- ============================================================
-- View: mon.vw_WindowsAnomalySummary
-- Purpose: Returns current unacknowledged anomalies with
--          target details for the dashboard
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsAnomalySummary', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsAnomalySummary;
GO

EXEC(N'CREATE VIEW mon.vw_WindowsAnomalySummary AS
SELECT
    a.AnomalyID,
    a.TargetID,
    t.ComputerName,
    t.DisplayName,
    a.MetricName,
    a.DetectedAt,
    a.ActualValue,
    a.BaselineAvg,
    a.BaselineStdDev,
    a.DeviationMultiplier,
    a.Severity,
    a.IsAcknowledged,
    a.AcknowledgedBy,
    a.AcknowledgedAt,
    a.Notes
FROM mon.WindowsAnomalyLog a
INNER JOIN mon.WindowsTargets t ON a.TargetID = t.TargetID
WHERE a.IsAcknowledged = 0;');
GO

-- ============================================================
-- View: mon.vw_WindowsCapacityDashboard
-- Purpose: Returns capacity forecast data with target details
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsCapacityDashboard', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsCapacityDashboard;
GO

EXEC(N'CREATE VIEW mon.vw_WindowsCapacityDashboard AS
SELECT
    f.ForecastID,
    f.TargetID,
    t.ComputerName,
    t.DisplayName,
    f.MetricName,
    f.CurrentValue,
    f.GrowthRatePerDay,
    f.ForecastExhaustionDate,
    f.DaysUntilExhaustion,
    f.ConfidencePercent,
    f.RecommendedAction,
    f.CalculatedAt
FROM mon.WindowsCapacityForecast f
INNER JOIN mon.WindowsTargets t ON f.TargetID = t.TargetID;');
GO

-- ============================================================
-- View: mon.vw_WindowsBaselineSummary
-- Purpose: Returns latest baseline stats per target for dashboard
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsBaselineSummary', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsBaselineSummary;
GO

EXEC(N'CREATE VIEW mon.vw_WindowsBaselineSummary AS
WITH CurrentHour AS (
    SELECT
        TargetID,
        MetricName,
        AvgValue,
        StdDevValue,
        MinValue,
        MaxValue,
        SampleCount,
        LastCalculatedAt,
        ROW_NUMBER() OVER (PARTITION BY TargetID, MetricName ORDER BY ABS(HourOfDay - DATEPART(HOUR, SYSDATETIME()))) AS rn
    FROM mon.WindowsPerformanceBaseline
)
SELECT
    b.TargetID,
    t.ComputerName,
    t.DisplayName,
    b.MetricName,
    b.AvgValue AS CurrentHourAvg,
    b.StdDevValue AS CurrentHourStdDev,
    b.SampleCount,
    b.LastCalculatedAt
FROM CurrentHour b
INNER JOIN mon.WindowsTargets t ON b.TargetID = t.TargetID
WHERE b.rn = 1;');
GO

PRINT 'Phase 20: Capacity Forecasting & Baseline Anomaly Detection objects are ready.';
GO
