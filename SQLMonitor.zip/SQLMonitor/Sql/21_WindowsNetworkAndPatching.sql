-- ============================================================
-- Phase 21: VM Network Deep Dive & Patching Compliance
-- ============================================================
SET NOCOUNT ON;

-- ============================================================
-- Table: mon.WindowsNetworkConnectionSamples
-- Purpose: TCP connection state tracking per target
-- ============================================================
IF OBJECT_ID('mon.WindowsNetworkConnectionSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsNetworkConnectionSamples
    (
        ConnectionSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsNetworkConnSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsNetConnSamples_CaptureTime DEFAULT (SYSDATETIME()),
        LocalAddress NVARCHAR(64) NOT NULL,
        LocalPort INT NOT NULL,
        RemoteAddress NVARCHAR(64) NOT NULL,
        RemotePort INT NOT NULL,
        State NVARCHAR(30) NOT NULL,
        OwningProcessID INT NULL,
        CONSTRAINT FK_WindowsNetConnSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsNetConnSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsNetworkConnectionSamples'))
    CREATE INDEX IX_WindowsNetConnSamples_Target_Time ON mon.WindowsNetworkConnectionSamples(TargetID, CaptureTime DESC);

-- ============================================================
-- Table: mon.WindowsNetworkAdapterStats
-- Purpose: Per-adapter bandwidth utilization snapshots
-- ============================================================
IF OBJECT_ID('mon.WindowsNetworkAdapterStats', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsNetworkAdapterStats
    (
        AdapterStatsID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsNetAdapterStats PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsNetAdapterStats_CaptureTime DEFAULT (SYSDATETIME()),
        AdapterName NVARCHAR(256) NOT NULL,
        InterfaceDescription NVARCHAR(512) NULL,
        BytesReceivedPerSec BIGINT NULL,
        BytesSentPerSec BIGINT NULL,
        BytesTotalPerSec BIGINT NULL,
        CurrentBandwidth BIGINT NULL,
        LinkSpeed BIGINT NULL,
        CONSTRAINT FK_WindowsNetAdapterStats_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsNetAdapterStats_Target_Time' AND object_id = OBJECT_ID('mon.WindowsNetworkAdapterStats'))
    CREATE INDEX IX_WindowsNetAdapterStats_Target_Time ON mon.WindowsNetworkAdapterStats(TargetID, CaptureTime DESC);

-- ============================================================
-- Table: mon.WindowsFirewallStatus
-- Purpose: Windows Firewall profile status per target
-- ============================================================
IF OBJECT_ID('mon.WindowsFirewallStatus', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsFirewallStatus
    (
        FirewallStatusID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsFirewallStatus PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsFirewallStatus_CaptureTime DEFAULT (SYSDATETIME()),
        ProfileName NVARCHAR(60) NOT NULL,
        Enabled BIT NOT NULL,
        DefaultInboundAction NVARCHAR(20) NULL,
        DefaultOutboundAction NVARCHAR(20) NULL,
        LogAllowed BIT NULL,
        LogBlocked BIT NULL,
        CONSTRAINT FK_WindowsFirewallStatus_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

-- ============================================================
-- Table: mon.WindowsPatchBaseline
-- Purpose: Defines required/critical patches for compliance tracking
-- ============================================================
IF OBJECT_ID('mon.WindowsPatchBaseline', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsPatchBaseline
    (
        PatchBaselineID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsPatchBaseline PRIMARY KEY,
        HotFixID NVARCHAR(80) NOT NULL,
        Description NVARCHAR(512) NULL,
        Severity NVARCHAR(20) NOT NULL CONSTRAINT DF_WindowsPatchBaseline_Severity DEFAULT (N'Recommended'),
        IsRequired BIT NOT NULL CONSTRAINT DF_WindowsPatchBaseline_IsRequired DEFAULT (0),
        Category NVARCHAR(80) NULL,
        AddedAt DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsPatchBaseline_AddedAt DEFAULT (SYSDATETIME()),
        AddedBy NVARCHAR(128) NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_WindowsPatchBaseline_IsActive DEFAULT (1),
        CONSTRAINT UQ_WindowsPatchBaseline_HotFixID UNIQUE (HotFixID)
    );
END;

-- ============================================================
-- View: mon.vw_WindowsNetworkConnectionSummary
-- Purpose: Top remote connections per target with counts
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsNetworkConnectionSummary', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsNetworkConnectionSummary;
GO

CREATE VIEW mon.vw_WindowsNetworkConnectionSummary AS
WITH ranked AS (
    SELECT
        t.DisplayName,
        t.ComputerName,
        nc.LocalAddress,
        nc.LocalPort,
        nc.RemoteAddress,
        nc.RemotePort,
        nc.State,
        nc.CaptureTime,
        ROW_NUMBER() OVER (PARTITION BY nc.TargetID ORDER BY nc.CaptureTime DESC) AS rn
    FROM mon.WindowsNetworkConnectionSamples nc
    INNER JOIN mon.WindowsTargets t ON nc.TargetID = t.TargetID
)
SELECT
    DisplayName,
    ComputerName,
    LocalAddress,
    LocalPort,
    RemoteAddress,
    RemotePort,
    State,
    CaptureTime
FROM ranked
WHERE rn <= 50;
GO

-- ============================================================
-- View: mon.vw_WindowsNetworkAdapterUtilization
-- Purpose: Latest per-adapter bandwidth stats with utilization %
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsNetworkAdapterUtilization', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsNetworkAdapterUtilization;
GO

CREATE VIEW mon.vw_WindowsNetworkAdapterUtilization AS
WITH latest AS (
    SELECT
        t.DisplayName,
        t.ComputerName,
        ns.AdapterName,
        ns.InterfaceDescription,
        ns.BytesReceivedPerSec,
        ns.BytesSentPerSec,
        ns.BytesTotalPerSec,
        ns.CurrentBandwidth,
        ns.LinkSpeed,
        ns.CaptureTime,
        ROW_NUMBER() OVER (PARTITION BY ns.TargetID, ns.AdapterName ORDER BY ns.CaptureTime DESC) AS rn
    FROM mon.WindowsNetworkAdapterStats ns
    INNER JOIN mon.WindowsTargets t ON ns.TargetID = t.TargetID
)
SELECT
    DisplayName,
    ComputerName,
    AdapterName,
    InterfaceDescription,
    BytesReceivedPerSec,
    BytesSentPerSec,
    BytesTotalPerSec,
    CurrentBandwidth,
    LinkSpeed,
    CASE
        WHEN CurrentBandwidth > 0 AND BytesTotalPerSec IS NOT NULL
        THEN CAST(ROUND(CAST(BytesTotalPerSec AS FLOAT) / CurrentBandwidth * 100, 2) AS DECIMAL(6,2))
        ELSE NULL
    END AS UtilizationPercent,
    CaptureTime
FROM latest
WHERE rn = 1;
GO

-- ============================================================
-- View: mon.vw_WindowsFirewallDashboard
-- Purpose: Latest firewall status per target
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsFirewallDashboard', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsFirewallDashboard;
GO

CREATE VIEW mon.vw_WindowsFirewallDashboard AS
WITH latest AS (
    SELECT
        t.DisplayName,
        t.ComputerName,
        fw.ProfileName,
        fw.Enabled,
        fw.DefaultInboundAction,
        fw.DefaultOutboundAction,
        fw.LogAllowed,
        fw.LogBlocked,
        fw.CaptureTime,
        ROW_NUMBER() OVER (PARTITION BY fw.TargetID, fw.ProfileName ORDER BY fw.CaptureTime DESC) AS rn
    FROM mon.WindowsFirewallStatus fw
    INNER JOIN mon.WindowsTargets t ON fw.TargetID = t.TargetID
)
SELECT
    DisplayName,
    ComputerName,
    ProfileName,
    Enabled,
    DefaultInboundAction,
    DefaultOutboundAction,
    LogAllowed,
    LogBlocked,
    CaptureTime
FROM latest
WHERE rn = 1;
GO

-- ============================================================
-- View: mon.vw_WindowsPatchCompliance
-- Purpose: Patch compliance status per target against baseline
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsPatchCompliance', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsPatchCompliance;
GO

CREATE VIEW mon.vw_WindowsPatchCompliance AS
WITH installed AS (
    SELECT DISTINCT
        hf.TargetID,
        hf.HotFixID
    FROM mon.WindowsHotFixSamples hf
    INNER JOIN mon.WindowsTargets t ON hf.TargetID = t.TargetID
),
compliance AS (
    SELECT
        t.TargetID,
        t.DisplayName,
        t.ComputerName,
        pb.HotFixID,
        pb.Severity,
        pb.IsRequired,
        pb.Category,
        CASE WHEN i.HotFixID IS NOT NULL THEN 1 ELSE 0 END AS IsInstalled
    FROM mon.WindowsTargets t
    CROSS JOIN mon.WindowsPatchBaseline pb
    LEFT JOIN installed i ON t.TargetID = i.TargetID AND pb.HotFixID = i.HotFixID
    WHERE pb.IsActive = 1
),
scores AS (
    SELECT
        TargetID,
        DisplayName,
        ComputerName,
        COUNT(*) AS TotalRequiredPatches,
        SUM(IsInstalled) AS InstalledPatches,
        SUM(CASE WHEN IsRequired = 1 AND IsInstalled = 0 THEN 1 ELSE 0 END) AS MissingCriticalPatches,
        CASE
            WHEN COUNT(*) = 0 THEN 100.0
            ELSE CAST(ROUND(SUM(CAST(IsInstalled AS FLOAT)) / COUNT(*) * 100, 1) AS DECIMAL(5,1))
        END AS ComplianceScore
    FROM compliance
    GROUP BY TargetID, DisplayName, ComputerName
)
SELECT
    TargetID,
    DisplayName,
    ComputerName,
    TotalRequiredPatches,
    InstalledPatches,
    MissingCriticalPatches,
    ComplianceScore,
    CASE
        WHEN ComplianceScore >= 95 THEN N'Compliant'
        WHEN ComplianceScore >= 80 THEN N'Partial'
        ELSE N'Non-Compliant'
    END AS ComplianceStatus
FROM scores;
GO

-- ============================================================
-- View: mon.vw_WindowsMissingPatches
-- Purpose: Detailed list of missing patches per target
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsMissingPatches', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsMissingPatches;
GO

CREATE VIEW mon.vw_WindowsMissingPatches AS
WITH installed AS (
    SELECT DISTINCT hf.TargetID, hf.HotFixID
    FROM mon.WindowsHotFixSamples hf
)
SELECT
    t.DisplayName,
    t.ComputerName,
    pb.HotFixID,
    pb.Description,
    pb.Severity,
    pb.IsRequired,
    pb.Category,
    pb.AddedAt
FROM mon.WindowsPatchBaseline pb
CROSS JOIN mon.WindowsTargets t
LEFT JOIN installed i ON t.TargetID = i.TargetID AND pb.HotFixID = i.HotFixID
WHERE pb.IsActive = 1
  AND i.HotFixID IS NULL;
GO

-- ============================================================
-- View: mon.vw_WindowsPatchTimeline
-- Purpose: Patch installation timeline per target
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsPatchTimeline', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsPatchTimeline;
GO

CREATE VIEW mon.vw_WindowsPatchTimeline AS
SELECT
    t.DisplayName,
    t.ComputerName,
    hf.HotFixID,
    hf.Description,
    hf.InstalledOn,
    hf.CaptureTime AS LastSeenAt
FROM mon.WindowsHotFixSamples hf
INNER JOIN mon.WindowsTargets t ON hf.TargetID = t.TargetID
WHERE hf.CaptureTime >= DATEADD(DAY, -90, SYSDATETIME());
GO

-- ============================================================
-- Stored Procedure: mon.usp_RefreshWindowsPatchBaseline
-- Purpose: Syncs patch baseline from current hotfix inventory.
--          Adds any new hotfixes found across all targets as
--          recommended (non-required) baseline entries.
-- ============================================================
IF OBJECT_ID('mon.usp_RefreshWindowsPatchBaseline', 'P') IS NULL
    EXEC(N'CREATE PROCEDURE mon.usp_RefreshWindowsPatchBaseline AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE mon.usp_RefreshWindowsPatchBaseline
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO mon.WindowsPatchBaseline (HotFixID, Description, Severity, Category)
    SELECT DISTINCT
        hf.HotFixID,
        hf.Description,
        N'Recommended',
        N'Auto-Discovered'
    FROM mon.WindowsHotFixSamples hf
    WHERE hf.CaptureTime >= DATEADD(DAY, -30, SYSDATETIME())
      AND hf.HotFixID NOT IN (SELECT pb.HotFixID FROM mon.WindowsPatchBaseline pb WHERE pb.IsActive = 1);

    SELECT @@ROWCOUNT AS NewPatchesAdded;
END;
GO

PRINT 'Phase 21: Network Deep Dive & Patching Compliance objects are ready.';
GO
