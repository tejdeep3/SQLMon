USE [DBA_SQLMonitor]
GO

IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD RepeatCount INT NOT NULL
        CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
END
GO

IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD FirstAlertTime DATETIME2 NULL;
END
GO

IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD LastRepeatedAt DATETIME2 NULL;
END
GO

UPDATE mon.AlertHistory
SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
    LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
    RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
WHERE FirstAlertTime IS NULL
   OR LastRepeatedAt IS NULL
   OR ISNULL(RepeatCount, 0) < 1;
GO

-- ===================================================================
-- Base View: Latest Metrics for each Instance
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_Overview
AS
SELECT 
    i.InstanceID,
    i.DisplayName,
    cpu.CaptureTime AS CpuCaptureTime,
    ISNULL(cpu.SqlCPUPercent, 0) AS SqlCPUPercent,
    ISNULL(cpu.OtherCPUPercent, 0) AS OtherCPUPercent,
    ISNULL(cpu.IdleCPUPercent, 0) AS IdleCPUPercent,
    mem.CaptureTime AS MemoryCaptureTime,
    ISNULL(mem.TotalPhysicalMB, 0) AS TotalPhysicalMB,
    ISNULL(mem.AvailablePhysicalMB, 0) AS AvailablePhysicalMB,
    ISNULL(mem.SqlMemoryUsedGB, 0) AS SqlMemoryUsedGB,
    ISNULL(mem.PLESeconds, 0) AS PLESeconds,
    ISNULL(mem.BufferCacheHitRatio, 0) AS BufferCacheHitRatio
FROM mon.MonitoredInstances i
LEFT JOIN (
    SELECT c1.InstanceID, c1.SqlCPUPercent, c1.OtherCPUPercent, c1.IdleCPUPercent, c1.CaptureTime
    FROM mon.CPUHistory c1
    INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime
        FROM mon.CPUHistory
        GROUP BY InstanceID
    ) c2 ON c1.InstanceID = c2.InstanceID AND c1.CaptureTime = c2.MaxTime
) cpu ON i.InstanceID = cpu.InstanceID
LEFT JOIN (
    SELECT m1.InstanceID, m1.TotalPhysicalMB, m1.AvailablePhysicalMB, m1.SqlMemoryUsedGB, m1.PLESeconds, m1.BufferCacheHitRatio, m1.CaptureTime
    FROM mon.MemoryHistory m1
    INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime
        FROM mon.MemoryHistory
        GROUP BY InstanceID
    ) m2 ON m1.InstanceID = m2.InstanceID AND m1.CaptureTime = m2.MaxTime
) mem ON i.InstanceID = mem.InstanceID
WHERE i.IsActive = 1;
GO

-- ===================================================================
-- View: Latest Overview (Dashboard recommendation engine uses this)
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_LatestOverview
AS
SELECT * FROM mon.vw_Overview;
GO

-- ===================================================================
-- View: Overview with Alert Counts
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_OverviewWithAlerts
AS
SELECT 
    o.*,
    ISNULL(a.OpenAlertCount, 0) AS OpenAlertCount,
    ISNULL(a.CriticalAlertCount, 0) AS CriticalAlertCount,
    ISNULL(a.WarningAlertCount, 0) AS WarningAlertCount
FROM mon.vw_Overview o
LEFT JOIN (
    SELECT
        InstanceID,
        COUNT(*) AS OpenAlertCount,
        SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
        SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
    FROM
    (
        SELECT
            InstanceID,
            Severity,
            ROW_NUMBER() OVER (
                PARTITION BY InstanceID, ModuleName, AlertTitle
                ORDER BY CASE Severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, AlertTime DESC, AlertID DESC
            ) AS rn
        FROM mon.AlertHistory
        WHERE IsAcknowledged = 0
    ) x
    WHERE rn = 1
    GROUP BY InstanceID
) a ON o.InstanceID = a.InstanceID;
GO

-- ===================================================================
-- View: Alert History Detailed
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_AlertHistoryDetailed
AS
SELECT
    ah.AlertID,
    ah.InstanceID,
    mi.DisplayName,
    ah.AlertTime,
    ah.Severity,
    ah.ModuleName,
    ah.AlertTitle,
    ah.AlertDetails,
    ah.IsAcknowledged,
    ah.AcknowledgedOn AS AcknowledgedTime,
    ah.AcknowledgedBy,
    DATEDIFF(MINUTE, ah.AlertTime, GETDATE()) AS AgeMinutes
FROM mon.AlertHistory ah
INNER JOIN mon.MonitoredInstances mi
    ON ah.InstanceID = mi.InstanceID;
GO

-- ===================================================================
-- View: Open Alerts Detailed
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_OpenAlertsDetailed
AS
WITH ranked AS
(
    SELECT
        ah.AlertID,
        ah.InstanceID,
        mi.DisplayName,
        ah.AlertTime,
        ah.Severity,
        ah.ModuleName,
        ah.AlertTitle,
        ah.AlertDetails,
        ah.IsAcknowledged,
        SUM(ISNULL(ah.RepeatCount, 1)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS RepeatCount,
        MIN(COALESCE(ah.FirstAlertTime, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS FirstAlertTime,
        MAX(COALESCE(ah.LastRepeatedAt, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS LastRepeatedAt,
        ROW_NUMBER() OVER (
            PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle
            ORDER BY CASE ah.Severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, ah.AlertTime DESC, ah.AlertID DESC
        ) AS rn
    FROM mon.AlertHistory ah
    INNER JOIN mon.MonitoredInstances mi
        ON ah.InstanceID = mi.InstanceID
    WHERE ah.IsAcknowledged = 0
)
SELECT
    AlertID,
    InstanceID,
    DisplayName,
    AlertTime,
    DATEDIFF(MINUTE, FirstAlertTime, GETDATE()) AS AlertAgeMinutes,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    RepeatCount,
    FirstAlertTime,
    LastRepeatedAt
FROM ranked
WHERE rn = 1;
GO

-- ===================================================================
-- Backup Status Latest View
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_LatestBackupStatus
AS
WITH x AS
(
    SELECT
        b.*,
        ROW_NUMBER() OVER (PARTITION BY b.InstanceID, b.DatabaseName ORDER BY b.CaptureTime DESC) AS rn
    FROM mon.BackupStatusHistory b
)
SELECT *
FROM x
WHERE rn = 1;
GO

-- ===================================================================
-- Agent Jobs Latest View
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_LatestAgentJobs
AS
WITH x AS
(
    SELECT
        a.*,
        ROW_NUMBER() OVER (PARTITION BY a.InstanceID, a.JobName ORDER BY a.CaptureTime DESC) AS rn
    FROM mon.AgentJobHistory a
)
SELECT *
FROM x
WHERE rn = 1;
GO

-- ===================================================================
-- AG Overview Latest View
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_LatestAGOverview
AS
WITH x AS
(
    SELECT
        a.*,
        ROW_NUMBER() OVER (PARTITION BY a.InstanceID, a.AGName ORDER BY a.CaptureTime DESC) AS rn
    FROM mon.AGOverviewHistory a
)
SELECT *
FROM x
WHERE rn = 1;
GO

-- ===================================================================
-- Recent Deadlocks View
-- ===================================================================
CREATE OR ALTER VIEW mon.vw_RecentDeadlocks60Min
AS
SELECT
    InstanceID,
    COUNT(*) AS RecentDeadlocksCount
FROM mon.DeadlockHistory
WHERE DeadlockTime >= DATEADD(MINUTE, -60, SYSDATETIME())
GROUP BY InstanceID;
GO
