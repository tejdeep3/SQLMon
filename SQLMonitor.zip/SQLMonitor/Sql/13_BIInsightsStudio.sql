IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');

IF OBJECT_ID('mon.BIInsightDatasets', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightDatasets (
        DatasetKey NVARCHAR(80) NOT NULL CONSTRAINT PK_BIInsightDatasets PRIMARY KEY,
        DisplayName NVARCHAR(160) NOT NULL,
        Category NVARCHAR(80) NOT NULL,
        Description NVARCHAR(500) NULL,
        DefaultVisual NVARCHAR(40) NOT NULL CONSTRAINT DF_BIInsightDatasets_DefaultVisual DEFAULT ('table'),
        QueryName NVARCHAR(128) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_BIInsightDatasets_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightDatasets_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL
    );
END;

IF OBJECT_ID('mon.BIInsightReports', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightReports (
        ReportID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightReports PRIMARY KEY,
        ReportName NVARCHAR(160) NOT NULL,
        ReportDescription NVARCHAR(500) NULL,
        LayoutJson NVARCHAR(MAX) NOT NULL,
        FilterJson NVARCHAR(MAX) NULL,
        IsShared BIT NOT NULL CONSTRAINT DF_BIInsightReports_IsShared DEFAULT (0),
        CreatedBy NVARCHAR(128) NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightReports_CreatedAt DEFAULT (SYSDATETIME()),
        ModifiedAt DATETIME2(0) NULL
    );
END;

IF OBJECT_ID('mon.BIInsightBookmarks', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightBookmarks (
        BookmarkID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightBookmarks PRIMARY KEY,
        ReportID INT NOT NULL,
        BookmarkName NVARCHAR(160) NOT NULL,
        StateJson NVARCHAR(MAX) NOT NULL,
        CreatedBy NVARCHAR(128) NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightBookmarks_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT FK_BIInsightBookmarks_Reports FOREIGN KEY (ReportID) REFERENCES mon.BIInsightReports(ReportID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.BIInsightDataSources', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightDataSources (
        DataSourceKey NVARCHAR(80) NOT NULL CONSTRAINT PK_BIInsightDataSources PRIMARY KEY,
        DisplayName NVARCHAR(160) NOT NULL,
        SourceType NVARCHAR(80) NOT NULL,
        ConnectorType NVARCHAR(80) NOT NULL,
        ConnectionMode NVARCHAR(40) NOT NULL CONSTRAINT DF_BIInsightDataSources_ConnectionMode DEFAULT ('Repository'),
        IsActive BIT NOT NULL CONSTRAINT DF_BIInsightDataSources_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightDataSources_CreatedAt DEFAULT (SYSDATETIME())
    );
END;

IF OBJECT_ID('mon.BIInsightFields', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightFields (
        FieldID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightFields PRIMARY KEY,
        DatasetKey NVARCHAR(80) NOT NULL,
        FieldName NVARCHAR(160) NOT NULL,
        DataType NVARCHAR(40) NOT NULL,
        FieldRole NVARCHAR(40) NOT NULL,
        DisplayFolder NVARCHAR(160) NULL,
        IsHidden BIT NOT NULL CONSTRAINT DF_BIInsightFields_IsHidden DEFAULT (0),
        CONSTRAINT FK_BIInsightFields_Datasets FOREIGN KEY (DatasetKey) REFERENCES mon.BIInsightDatasets(DatasetKey) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.BIInsightRelationships', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightRelationships (
        RelationshipID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightRelationships PRIMARY KEY,
        FromDatasetKey NVARCHAR(80) NOT NULL,
        FromField NVARCHAR(160) NOT NULL,
        ToDatasetKey NVARCHAR(80) NOT NULL,
        ToField NVARCHAR(160) NOT NULL,
        Cardinality NVARCHAR(40) NOT NULL,
        CrossFilterDirection NVARCHAR(40) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_BIInsightRelationships_IsActive DEFAULT (1)
    );
END;

IF OBJECT_ID('mon.BIInsightMeasures', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightMeasures (
        MeasureID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightMeasures PRIMARY KEY,
        DatasetKey NVARCHAR(80) NOT NULL,
        MeasureName NVARCHAR(160) NOT NULL,
        ExpressionText NVARCHAR(MAX) NOT NULL,
        FormatString NVARCHAR(80) NULL,
        DisplayFolder NVARCHAR(160) NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_BIInsightMeasures_IsActive DEFAULT (1),
        CONSTRAINT FK_BIInsightMeasures_Datasets FOREIGN KEY (DatasetKey) REFERENCES mon.BIInsightDatasets(DatasetKey) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.BIInsightTransformations', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightTransformations (
        TransformationID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightTransformations PRIMARY KEY,
        DatasetKey NVARCHAR(80) NOT NULL,
        StepName NVARCHAR(160) NOT NULL,
        StepType NVARCHAR(80) NOT NULL,
        ExpressionText NVARCHAR(MAX) NULL,
        StepOrder INT NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_BIInsightTransformations_IsActive DEFAULT (1),
        CONSTRAINT FK_BIInsightTransformations_Datasets FOREIGN KEY (DatasetKey) REFERENCES mon.BIInsightDatasets(DatasetKey) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.BIInsightVisualTypes', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightVisualTypes (
        VisualTypeKey NVARCHAR(80) NOT NULL CONSTRAINT PK_BIInsightVisualTypes PRIMARY KEY,
        DisplayName NVARCHAR(160) NOT NULL,
        Category NVARCHAR(80) NOT NULL,
        SupportsDrillthrough BIT NOT NULL CONSTRAINT DF_BIInsightVisualTypes_SupportsDrillthrough DEFAULT (1),
        SupportsCrossFilter BIT NOT NULL CONSTRAINT DF_BIInsightVisualTypes_SupportsCrossFilter DEFAULT (1),
        IsActive BIT NOT NULL CONSTRAINT DF_BIInsightVisualTypes_IsActive DEFAULT (1)
    );
END;

IF OBJECT_ID('mon.BIInsightThemes', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightThemes (
        ThemeID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightThemes PRIMARY KEY,
        ThemeName NVARCHAR(160) NOT NULL,
        ThemeJson NVARCHAR(MAX) NOT NULL,
        IsDefault BIT NOT NULL CONSTRAINT DF_BIInsightThemes_IsDefault DEFAULT (0),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightThemes_CreatedAt DEFAULT (SYSDATETIME())
    );
END;

IF OBJECT_ID('mon.BIInsightReportPages', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightReportPages (
        PageID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightReportPages PRIMARY KEY,
        ReportID INT NOT NULL,
        PageName NVARCHAR(160) NOT NULL,
        PageOrder INT NOT NULL,
        LayoutJson NVARCHAR(MAX) NOT NULL,
        MobileLayoutJson NVARCHAR(MAX) NULL,
        CONSTRAINT FK_BIInsightReportPages_Reports FOREIGN KEY (ReportID) REFERENCES mon.BIInsightReports(ReportID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.BIInsightQAPrompts', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightQAPrompts (
        PromptID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightQAPrompts PRIMARY KEY,
        PromptText NVARCHAR(400) NOT NULL,
        AnswerTemplate NVARCHAR(MAX) NOT NULL,
        DatasetKey NVARCHAR(80) NULL,
        IsVerified BIT NOT NULL CONSTRAINT DF_BIInsightQAPrompts_IsVerified DEFAULT (0),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightQAPrompts_CreatedAt DEFAULT (SYSDATETIME())
    );
END;

IF OBJECT_ID('mon.BIInsightPerformanceRuns', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightPerformanceRuns (
        RunID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightPerformanceRuns PRIMARY KEY,
        ReportID INT NULL,
        DatasetKey NVARCHAR(80) NULL,
        DurationMs INT NOT NULL,
        [RowCount] INT NOT NULL,
        ExecutedBy NVARCHAR(128) NULL,
        ExecutedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightPerformanceRuns_ExecutedAt DEFAULT (SYSDATETIME())
    );
END;

IF OBJECT_ID('mon.BIInsightModuleVisuals', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightModuleVisuals (
        ModuleKey NVARCHAR(80) NOT NULL CONSTRAINT PK_BIInsightModuleVisuals PRIMARY KEY,
        ModuleTitle NVARCHAR(160) NOT NULL,
        VisualTitle NVARCHAR(160) NOT NULL,
        VisualType NVARCHAR(80) NOT NULL CONSTRAINT DF_BIInsightModuleVisuals_VisualType DEFAULT (N'line'),
        AxisField NVARCHAR(160) NULL,
        ValueField NVARCHAR(160) NULL,
        LegendField NVARCHAR(160) NULL,
        IsEnabled BIT NOT NULL CONSTRAINT DF_BIInsightModuleVisuals_IsEnabled DEFAULT (0),
        CreatedBy NVARCHAR(128) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightModuleVisuals_CreatedAt DEFAULT (SYSDATETIME()),
        ModifiedBy NVARCHAR(128) NULL,
        ModifiedAt DATETIME2(0) NULL
    );
END;

MERGE mon.BIInsightDatasets AS target
USING (VALUES
    (N'server-scorecard', N'Server Scorecard', N'Operations', N'Health, CPU, memory, open alerts, and repeat counts by SQL Server.', N'table', N'Get-BiInsights.Scorecard'),
    (N'alert-trends', N'Alert Trends', N'Alerts', N'Daily alert volume by severity for trending and SLA reporting.', N'stacked-bar', N'Get-BiInsights.AlertTrends'),
    (N'noisy-alerts', N'Noisy Alerts', N'Alerts', N'Most repeated alert fingerprints across monitored servers.', N'table', N'Get-BiInsights.NoisyAlerts'),
    (N'capacity-hotspots', N'Capacity Hotspots', N'Capacity', N'Disk volumes with highest utilization and lowest free space.', N'table', N'Get-BiInsights.Capacity'),
    (N'module-health', N'Collection Module Health', N'Collectors', N'Collection module status distribution across monitored servers.', N'table', N'Get-BiInsights.ModuleHealth'),
    (N'health-posture', N'Health Posture', N'Executive', N'Healthy, warning, and critical server posture distribution.', N'doughnut', N'Get-BiInsights.HealthPosture'),
    (N'ticket-status', N'Ticket Status', N'Tickets', N'Tickets by lifecycle status for service desk throughput and backlog reporting.', N'doughnut', N'Get-BiInsights.TicketStatus'),
    (N'ticket-severity', N'Ticket Severity', N'Tickets', N'Tickets by Critical, High, Medium, and Low severity with resolution timing.', N'column', N'Get-BiInsights.TicketSeverity'),
    (N'ticket-assignment', N'Ticket Assignment', N'Tickets', N'Ticket workload and closure volume by assigned user.', N'clustered-bar', N'Get-BiInsights.TicketAssignment'),
    (N'task-status', N'Task Status', N'Tasks', N'Tasks by workflow status including active, completed, and cancelled work.', N'doughnut', N'Get-BiInsights.TaskStatus'),
    (N'task-priority', N'Task Priority', N'Tasks', N'Tasks by Critical, High, Medium, and Low priority with overdue counts.', N'column', N'Get-BiInsights.TaskPriority'),
    (N'task-assignment', N'Task Assignment', N'Tasks', N'Task workload, completion, and overdue volume by assigned user.', N'clustered-bar', N'Get-BiInsights.TaskAssignment'),
    (N'application-groups', N'Application Server Groups', N'Applications', N'Application ownership groups, users, and server counts from access management.', N'table', N'Get-BiInsights.ApplicationGroups'),
    (N'application-scorecard', N'Application Scorecard', N'Applications', N'Application-owner view of server health, alerts, CPU, memory, and capacity.', N'table', N'Get-BiInsights.ApplicationScorecard'),
    (N'cpu-performance', N'CPU Performance', N'Performance', N'Average and peak SQL CPU by server over the selected range.', N'clustered-column', N'Get-BiInsights.CpuPerformance'),
    (N'memory-performance', N'Memory Performance', N'Performance', N'Lowest available memory and average SQL memory by server.', N'clustered-column', N'Get-BiInsights.MemoryPerformance'),
    (N'disk-capacity-trend', N'Disk Capacity Trend', N'Capacity', N'Disk utilization and free space by server and volume.', N'clustered-bar', N'Get-BiInsights.DiskCapacityTrend'),
    (N'backup-compliance', N'Backup Compliance', N'Operations', N'Latest backup age and status by database.', N'clustered-bar', N'Get-BiInsights.BackupCompliance'),
    (N'wait-profile', N'Wait Profile', N'Performance', N'Top SQL wait types by wait time from collected wait statistics.', N'clustered-bar', N'Get-BiInsights.WaitProfile'),
    (N'top-query-cpu', N'Top Query CPU', N'Performance', N'Highest CPU consuming queries for tuning review.', N'clustered-bar', N'Get-BiInsights.TopQueryCpu'),
    (N'vm-scorecard', N'VM Scorecard', N'VM Monitoring', N'Windows VM health, CPU, memory, disk, services, telemetry freshness, alerts, and tickets.', N'table', N'Get-BiInsights.VMScorecard'),
    (N'vm-alert-trends', N'VM Alert Trends', N'VM Monitoring', N'Windows VM alert volume by day, severity, and monitoring module.', N'stacked-column', N'Get-BiInsights.VMAlertTrends'),
    (N'vm-ticket-sla', N'VM Ticket SLA', N'VM Monitoring', N'VM Monitoring tickets by severity, assignment group, and SLA status.', N'clustered-bar', N'Get-BiInsights.VMTicketSla'),
    (N'vm-capacity', N'VM Capacity', N'VM Monitoring', N'Windows VM disk utilization and free-space risk by drive.', N'clustered-bar', N'Get-BiInsights.VMCapacity'),
    (N'vm-process-hotspots', N'VM Process Hotspots', N'VM Monitoring', N'Top Windows processes by CPU and working set memory.', N'clustered-bar', N'Get-BiInsights.VMProcessHotspots'),
    (N'vm-event-log', N'VM Event Log Insights', N'VM Monitoring', N'Windows event log volume by VM, log, level, and provider.', N'clustered-bar', N'Get-BiInsights.VMEventLog'),
    (N'vm-patch-posture', N'VM Patch Posture', N'VM Monitoring', N'Windows patch and hotfix recency by VM.', N'table', N'Get-BiInsights.VMPatchPosture')
) AS source (DatasetKey, DisplayName, Category, Description, DefaultVisual, QueryName)
ON target.DatasetKey = source.DatasetKey
WHEN MATCHED THEN
    UPDATE SET DisplayName = source.DisplayName,
               Category = source.Category,
               Description = source.Description,
               DefaultVisual = source.DefaultVisual,
               QueryName = source.QueryName,
               IsActive = 1,
               UpdatedAt = SYSDATETIME()
WHEN NOT MATCHED THEN
    INSERT (DatasetKey, DisplayName, Category, Description, DefaultVisual, QueryName)
    VALUES (source.DatasetKey, source.DisplayName, source.Category, source.Description, source.DefaultVisual, source.QueryName);

MERGE mon.BIInsightDataSources AS target
USING (VALUES
    (N'sqlmonitor-repository', N'SQL Monitor Repository', N'Database', N'SQL Server', N'Import/Direct Query'),
    (N'web-api', N'Web/API Connector', N'Web', N'JSON API', N'Extensible'),
    (N'file-import', N'File Import', N'File', N'CSV/JSON', N'Import')
) AS source (DataSourceKey, DisplayName, SourceType, ConnectorType, ConnectionMode)
ON target.DataSourceKey = source.DataSourceKey
WHEN MATCHED THEN UPDATE SET DisplayName = source.DisplayName, SourceType = source.SourceType, ConnectorType = source.ConnectorType, ConnectionMode = source.ConnectionMode, IsActive = 1
WHEN NOT MATCHED THEN INSERT (DataSourceKey, DisplayName, SourceType, ConnectorType, ConnectionMode) VALUES (source.DataSourceKey, source.DisplayName, source.SourceType, source.ConnectorType, source.ConnectionMode);

MERGE mon.BIInsightVisualTypes AS target
USING (VALUES
    (N'bar', N'Bar Chart', N'Charts'), (N'column', N'Column Chart', N'Charts'), (N'line', N'Line Chart', N'Charts'),
    (N'stacked-bar', N'Stacked Bar Chart', N'Charts'), (N'stacked-column', N'Stacked Column Chart', N'Charts'),
    (N'clustered-bar', N'Clustered Bar Chart', N'Charts'), (N'clustered-column', N'Clustered Column Chart', N'Charts'),
    (N'area', N'Area Chart', N'Charts'), (N'pie', N'Pie Chart', N'Charts'), (N'doughnut', N'Doughnut Chart', N'Charts'),
    (N'treemap', N'Treemap', N'Advanced'), (N'waterfall', N'Waterfall', N'Advanced'), (N'funnel', N'Funnel', N'Advanced'),
    (N'gauge', N'Gauge', N'KPI'), (N'kpi', N'KPI Card', N'KPI'), (N'table', N'Table', N'Tables'),
    (N'matrix', N'Matrix', N'Tables'), (N'slicer', N'Slicer', N'Filters'), (N'gantt', N'Gantt', N'Custom'),
    (N'scatter', N'Scatter Chart', N'Charts'), (N'bubble', N'Bubble Chart', N'Charts'), (N'card', N'Card', N'KPI')
) AS source (VisualTypeKey, DisplayName, Category)
ON target.VisualTypeKey = source.VisualTypeKey
WHEN MATCHED THEN UPDATE SET DisplayName = source.DisplayName, Category = source.Category, IsActive = 1
WHEN NOT MATCHED THEN INSERT (VisualTypeKey, DisplayName, Category) VALUES (source.VisualTypeKey, source.DisplayName, source.Category);

MERGE mon.BIInsightModuleVisuals AS target
USING (VALUES
    (N'cpu', N'CPU Trend', N'SQL CPU Percent', N'line', N'CaptureTime', N'SqlCPUPercent', N''),
    (N'memory', N'Memory Trend', N'Available Memory', N'line', N'CaptureTime', N'AvailablePhysicalMB', N''),
    (N'kpis', N'KPIs', N'Page Life Expectancy', N'line', N'CaptureTime', N'PageLifeExpectancy', N''),
    (N'waits', N'Wait Stats', N'Latest Wait Time by Type', N'clustered-bar', N'WaitType', N'WaitTimeMs', N''),
    (N'top-queries', N'Top Queries', N'Latest Top Query CPU', N'clustered-bar', N'QueryText', N'AvgCpuTime', N''),
    (N'execution-plans', N'Execution Plans', N'Execution Plan CPU', N'clustered-bar', N'QueryText', N'CpuTime', N''),
    (N'disks', N'Disks', N'Latest Disk Used Percent', N'clustered-bar', N'VolumeMountPoint', N'UsedPct', N''),
    (N'io', N'I/O Files', N'Latest I/O Stall by File', N'clustered-bar', N'LogicalName', N'TotalStallMS', N'FileType'),
    (N'tempdb', N'TempDB', N'Latest TempDB Percent Full', N'clustered-bar', N'LogicalName', N'PercentFull', N'FileType'),
    (N'backups', N'Backups', N'Latest Backup Age by Database', N'clustered-bar', N'DatabaseName', N'LastFullHours', N'StatusText'),
    (N'db-options', N'DB Options', N'Latest Database Size', N'clustered-bar', N'DatabaseName', N'SizeMB', N'State'),
    (N'missing-indexes', N'Missing Indexes', N'Latest Missing Index Benefit', N'clustered-bar', N'ObjectName', N'ImprovementMeasure', N'DatabaseName'),
    (N'fragmentation', N'Fragmentation', N'Latest Index Fragmentation', N'clustered-bar', N'ObjectName', N'AvgFragmentationPercent', N'DatabaseName'),
    (N'config', N'SQL Config', N'MaxDOP Setting Trend', N'line', N'CaptureTime', N'MaxDOPSetting', N''),
    (N'blocking', N'Blocking', N'Current Blocking Wait Time', N'clustered-bar', N'SessionID', N'WaitTimeMS', N'WaitType'),
    (N'long-running', N'Long Running', N'Current Long Running Duration', N'clustered-bar', N'SessionID', N'DurationMinutes', N'DatabaseName'),
    (N'ag', N'Availability Groups', N'Latest AG Sync Health', N'clustered-bar', N'AGName', N'FailureConditionLevel', N'SyncHealthDesc'),
    (N'listeners', N'Listeners', N'Latest Listeners by State', N'clustered-column', N'State', N'', N''),
    (N'agent-jobs', N'Agent Jobs', N'Latest Agent Job Success Percent', N'clustered-bar', N'JobName', N'SuccessPctRecent', N'LastStatus'),
    (N'deadlocks', N'Deadlocks', N'Deadlocks by Time', N'clustered-column', N'DeadlockTime', N'', N'')
) AS source (ModuleKey, ModuleTitle, VisualTitle, VisualType, AxisField, ValueField, LegendField)
ON target.ModuleKey = source.ModuleKey
WHEN MATCHED THEN
    UPDATE SET ModuleTitle = source.ModuleTitle
WHEN NOT MATCHED THEN
    INSERT (ModuleKey, ModuleTitle, VisualTitle, VisualType, AxisField, ValueField, LegendField, IsEnabled, CreatedBy)
    VALUES (source.ModuleKey, source.ModuleTitle, source.VisualTitle, source.VisualType, source.AxisField, source.ValueField, source.LegendField, 0, N'system');

MERGE mon.BIInsightFields AS target
USING (VALUES
    (N'server-scorecard', N'SqlInstance', N'text', N'Dimension', N'Server'),
    (N'server-scorecard', N'DisplayName', N'text', N'Dimension', N'Server'),
    (N'server-scorecard', N'EnvironmentName', N'text', N'Dimension', N'Server'),
    (N'server-scorecard', N'Environment', N'text', N'Dimension', N'Server'),
    (N'server-scorecard', N'HealthPosture', N'text', N'Dimension', N'Health'),
    (N'server-scorecard', N'OpenAlerts', N'number', N'Measure', N'Alerts'),
    (N'server-scorecard', N'CriticalAlerts', N'number', N'Measure', N'Alerts'),
    (N'server-scorecard', N'AlertRepeats', N'number', N'Measure', N'Alerts'),
    (N'server-scorecard', N'OpenAlertCount', N'number', N'Measure', N'Alerts'),
    (N'server-scorecard', N'RepeatCount', N'number', N'Measure', N'Alerts'),
    (N'server-scorecard', N'AvgCPU', N'number', N'Measure', N'Performance'),
    (N'server-scorecard', N'PeakCPU', N'number', N'Measure', N'Performance'),
    (N'server-scorecard', N'MinMemoryMB', N'number', N'Measure', N'Performance'),
    (N'server-scorecard', N'CpuPercent', N'number', N'Measure', N'Performance'),
    (N'server-scorecard', N'MemoryUsedPercent', N'number', N'Measure', N'Performance'),
    (N'alert-trends', N'AlertDate', N'date', N'Dimension', N'Time'),
    (N'alert-trends', N'Severity', N'text', N'Dimension', N'Alert'),
    (N'alert-trends', N'AlertCount', N'number', N'Measure', N'Alert'),
    (N'noisy-alerts', N'SqlInstance', N'text', N'Dimension', N'Server'),
    (N'noisy-alerts', N'AlertFingerprint', N'text', N'Dimension', N'Alert'),
    (N'noisy-alerts', N'RepeatCount', N'number', N'Measure', N'Alert'),
    (N'capacity-hotspots', N'SqlInstance', N'text', N'Dimension', N'Server'),
    (N'capacity-hotspots', N'DriveLetter', N'text', N'Dimension', N'Volume'),
    (N'capacity-hotspots', N'PeakUsedPct', N'number', N'Measure', N'Capacity'),
    (N'capacity-hotspots', N'MinFreeGB', N'number', N'Measure', N'Capacity'),
    (N'module-health', N'SqlInstance', N'text', N'Dimension', N'Server'),
    (N'module-health', N'ModuleName', N'text', N'Dimension', N'Collector'),
    (N'module-health', N'HealthStatus', N'text', N'Dimension', N'Collector'),
    (N'health-posture', N'Posture', N'text', N'Dimension', N'Health'),
    (N'health-posture', N'ServerCount', N'number', N'Measure', N'Health'),
    (N'ticket-status', N'TicketStatus', N'text', N'Dimension', N'Ticket'),
    (N'ticket-status', N'TicketCount', N'number', N'Measure', N'Ticket'),
    (N'ticket-status', N'AvgAgeMinutes', N'number', N'Measure', N'Ticket'),
    (N'ticket-severity', N'TicketSeverity', N'text', N'Dimension', N'Ticket'),
    (N'ticket-severity', N'TicketCount', N'number', N'Measure', N'Ticket'),
    (N'ticket-severity', N'AvgResolutionMinutes', N'number', N'Measure', N'Ticket'),
    (N'ticket-assignment', N'AssignedTo', N'text', N'Dimension', N'Assignment'),
    (N'ticket-assignment', N'TicketCount', N'number', N'Measure', N'Ticket'),
    (N'ticket-assignment', N'ClosedTicketCount', N'number', N'Measure', N'Ticket'),
    (N'task-status', N'TaskStatus', N'text', N'Dimension', N'Task'),
    (N'task-status', N'TaskCount', N'number', N'Measure', N'Task'),
    (N'task-status', N'OverdueCount', N'number', N'Measure', N'Task'),
    (N'task-priority', N'TaskPriority', N'text', N'Dimension', N'Task'),
    (N'task-priority', N'TaskCount', N'number', N'Measure', N'Task'),
    (N'task-priority', N'OverdueCount', N'number', N'Measure', N'Task'),
    (N'task-assignment', N'AssignedTo', N'text', N'Dimension', N'Assignment'),
    (N'task-assignment', N'TaskCount', N'number', N'Measure', N'Task'),
    (N'task-assignment', N'CompletedCount', N'number', N'Measure', N'Task'),
    (N'application-groups', N'ApplicationName', N'text', N'Dimension', N'Application'),
    (N'application-groups', N'GroupName', N'text', N'Dimension', N'Application'),
    (N'application-groups', N'OwnerName', N'text', N'Dimension', N'Application'),
    (N'application-groups', N'ServerCount', N'number', N'Measure', N'Application'),
    (N'application-groups', N'AssignedUserCount', N'number', N'Measure', N'Application'),
    (N'application-scorecard', N'ApplicationName', N'text', N'Dimension', N'Application'),
    (N'application-scorecard', N'GroupName', N'text', N'Dimension', N'Application'),
    (N'application-scorecard', N'DisplayName', N'text', N'Dimension', N'Server'),
    (N'application-scorecard', N'HealthPosture', N'text', N'Dimension', N'Health'),
    (N'application-scorecard', N'OpenAlerts', N'number', N'Measure', N'Alerts'),
    (N'application-scorecard', N'PeakCPU', N'number', N'Measure', N'Performance'),
    (N'application-scorecard', N'MinMemoryMB', N'number', N'Measure', N'Performance'),
    (N'cpu-performance', N'DisplayName', N'text', N'Dimension', N'Server'),
    (N'cpu-performance', N'AvgCPU', N'number', N'Measure', N'CPU'),
    (N'cpu-performance', N'PeakCPU', N'number', N'Measure', N'CPU'),
    (N'memory-performance', N'DisplayName', N'text', N'Dimension', N'Server'),
    (N'memory-performance', N'MinAvailableMB', N'number', N'Measure', N'Memory'),
    (N'memory-performance', N'AvgSqlMemoryGB', N'number', N'Measure', N'Memory'),
    (N'disk-capacity-trend', N'DisplayName', N'text', N'Dimension', N'Server'),
    (N'disk-capacity-trend', N'VolumeMountPoint', N'text', N'Dimension', N'Volume'),
    (N'disk-capacity-trend', N'PeakUsedPct', N'number', N'Measure', N'Capacity'),
    (N'disk-capacity-trend', N'MinFreeGB', N'number', N'Measure', N'Capacity'),
    (N'backup-compliance', N'DisplayName', N'text', N'Dimension', N'Server'),
    (N'backup-compliance', N'DatabaseName', N'text', N'Dimension', N'Database'),
    (N'backup-compliance', N'LastFullHours', N'number', N'Measure', N'Backup'),
    (N'backup-compliance', N'StatusText', N'text', N'Dimension', N'Backup'),
    (N'wait-profile', N'WaitType', N'text', N'Dimension', N'Waits'),
    (N'wait-profile', N'WaitTimeMs', N'number', N'Measure', N'Waits'),
    (N'wait-profile', N'WaitCount', N'number', N'Measure', N'Waits'),
    (N'top-query-cpu', N'DisplayName', N'text', N'Dimension', N'Server'),
    (N'top-query-cpu', N'QueryText', N'text', N'Dimension', N'Query'),
    (N'top-query-cpu', N'AvgCpuTime', N'number', N'Measure', N'Query'),
    (N'top-query-cpu', N'CountExecutions', N'number', N'Measure', N'Query'),
    (N'vm-scorecard', N'DisplayName', N'text', N'Dimension', N'VM'),
    (N'vm-scorecard', N'ComputerName', N'text', N'Dimension', N'VM'),
    (N'vm-scorecard', N'EnvironmentName', N'text', N'Dimension', N'VM'),
    (N'vm-scorecard', N'ApplicationName', N'text', N'Dimension', N'VM'),
    (N'vm-scorecard', N'HealthPosture', N'text', N'Dimension', N'Health'),
    (N'vm-scorecard', N'HealthScore', N'number', N'Measure', N'Health'),
    (N'vm-scorecard', N'CPUPercent', N'number', N'Measure', N'Performance'),
    (N'vm-scorecard', N'MemoryUsedPercent', N'number', N'Measure', N'Performance'),
    (N'vm-scorecard', N'DiskUsedPercent', N'number', N'Measure', N'Capacity'),
    (N'vm-scorecard', N'OpenAlerts', N'number', N'Measure', N'Alerts'),
    (N'vm-scorecard', N'OpenTickets', N'number', N'Measure', N'Tickets'),
    (N'vm-alert-trends', N'AlertDate', N'date', N'Dimension', N'Time'),
    (N'vm-alert-trends', N'Severity', N'text', N'Dimension', N'Alert'),
    (N'vm-alert-trends', N'ModuleName', N'text', N'Dimension', N'Alert'),
    (N'vm-alert-trends', N'AlertCount', N'number', N'Measure', N'Alert'),
    (N'vm-alert-trends', N'RepeatCount', N'number', N'Measure', N'Alert'),
    (N'vm-ticket-sla', N'TicketSeverity', N'text', N'Dimension', N'Ticket'),
    (N'vm-ticket-sla', N'Subcategory', N'text', N'Dimension', N'Ticket'),
    (N'vm-ticket-sla', N'AssignmentGroup', N'text', N'Dimension', N'Assignment'),
    (N'vm-ticket-sla', N'SLAStatus', N'text', N'Dimension', N'SLA'),
    (N'vm-ticket-sla', N'TicketCount', N'number', N'Measure', N'Ticket'),
    (N'vm-capacity', N'DisplayName', N'text', N'Dimension', N'VM'),
    (N'vm-capacity', N'DriveLetter', N'text', N'Dimension', N'Volume'),
    (N'vm-capacity', N'PeakUsedPercent', N'number', N'Measure', N'Capacity'),
    (N'vm-capacity', N'MinFreeGB', N'number', N'Measure', N'Capacity'),
    (N'vm-process-hotspots', N'DisplayName', N'text', N'Dimension', N'VM'),
    (N'vm-process-hotspots', N'RankingType', N'text', N'Dimension', N'Process'),
    (N'vm-process-hotspots', N'ProcessName', N'text', N'Dimension', N'Process'),
    (N'vm-process-hotspots', N'PeakCPUPercent', N'number', N'Measure', N'Process'),
    (N'vm-process-hotspots', N'PeakWorkingSetMB', N'number', N'Measure', N'Process'),
    (N'vm-event-log', N'DisplayName', N'text', N'Dimension', N'VM'),
    (N'vm-event-log', N'LogName', N'text', N'Dimension', N'Event Log'),
    (N'vm-event-log', N'LevelName', N'text', N'Dimension', N'Event Log'),
    (N'vm-event-log', N'ProviderName', N'text', N'Dimension', N'Event Log'),
    (N'vm-event-log', N'EventCount', N'number', N'Measure', N'Event Log'),
    (N'vm-patch-posture', N'DisplayName', N'text', N'Dimension', N'VM'),
    (N'vm-patch-posture', N'HotFixCount', N'number', N'Measure', N'Patch'),
    (N'vm-patch-posture', N'LastInstalledOn', N'date', N'Dimension', N'Patch'),
    (N'vm-patch-posture', N'DaysSinceLastPatch', N'number', N'Measure', N'Patch')
) AS source (DatasetKey, FieldName, DataType, FieldRole, DisplayFolder)
ON target.DatasetKey = source.DatasetKey AND target.FieldName = source.FieldName
WHEN MATCHED THEN UPDATE SET DataType = source.DataType, FieldRole = source.FieldRole, DisplayFolder = source.DisplayFolder, IsHidden = 0
WHEN NOT MATCHED THEN INSERT (DatasetKey, FieldName, DataType, FieldRole, DisplayFolder) VALUES (source.DatasetKey, source.FieldName, source.DataType, source.FieldRole, source.DisplayFolder);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightRelationships)
    INSERT INTO mon.BIInsightRelationships (FromDatasetKey, FromField, ToDatasetKey, ToField, Cardinality, CrossFilterDirection)
    VALUES
        (N'server-scorecard', N'SqlInstance', N'noisy-alerts', N'SqlInstance', N'One-to-many', N'Single'),
        (N'server-scorecard', N'SqlInstance', N'capacity-hotspots', N'SqlInstance', N'One-to-many', N'Single'),
        (N'server-scorecard', N'SqlInstance', N'module-health', N'SqlInstance', N'One-to-many', N'Single');

MERGE mon.BIInsightRelationships AS target
USING (VALUES
    (N'server-scorecard', N'DisplayName', N'noisy-alerts', N'DisplayName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'capacity-hotspots', N'DisplayName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'ticket-assignment', N'AssignedTo', N'Many-to-many', N'Both'),
    (N'server-scorecard', N'DisplayName', N'task-assignment', N'AssignedTo', N'Many-to-many', N'Both'),
    (N'application-groups', N'ApplicationName', N'application-scorecard', N'ApplicationName', N'One-to-many', N'Single'),
    (N'application-groups', N'GroupName', N'application-scorecard', N'GroupName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'application-scorecard', N'DisplayName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'cpu-performance', N'DisplayName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'memory-performance', N'DisplayName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'disk-capacity-trend', N'DisplayName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'backup-compliance', N'DisplayName', N'One-to-many', N'Single'),
    (N'server-scorecard', N'DisplayName', N'top-query-cpu', N'DisplayName', N'One-to-many', N'Single'),
    (N'vm-scorecard', N'DisplayName', N'vm-capacity', N'DisplayName', N'One-to-many', N'Single'),
    (N'vm-scorecard', N'DisplayName', N'vm-process-hotspots', N'DisplayName', N'One-to-many', N'Single'),
    (N'vm-scorecard', N'DisplayName', N'vm-event-log', N'DisplayName', N'One-to-many', N'Single'),
    (N'vm-scorecard', N'DisplayName', N'vm-patch-posture', N'DisplayName', N'One-to-many', N'Single')
) AS source (FromDatasetKey, FromField, ToDatasetKey, ToField, Cardinality, CrossFilterDirection)
ON target.FromDatasetKey = source.FromDatasetKey
   AND target.FromField = source.FromField
   AND target.ToDatasetKey = source.ToDatasetKey
   AND target.ToField = source.ToField
WHEN MATCHED THEN
    UPDATE SET Cardinality = source.Cardinality,
               CrossFilterDirection = source.CrossFilterDirection,
               IsActive = 1
WHEN NOT MATCHED THEN
    INSERT (FromDatasetKey, FromField, ToDatasetKey, ToField, Cardinality, CrossFilterDirection)
    VALUES (source.FromDatasetKey, source.FromField, source.ToDatasetKey, source.ToField, source.Cardinality, source.CrossFilterDirection);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightMeasures WHERE MeasureName = N'Health Score')
    INSERT INTO mon.BIInsightMeasures (DatasetKey, MeasureName, ExpressionText, FormatString, DisplayFolder)
    VALUES (N'server-scorecard', N'Health Score', N'AVERAGEX(ServerScorecard, SWITCH([HealthPosture], "Healthy", 100, "Warning", 60, "Critical", 15, 40))', N'0%', N'Executive KPIs');

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightMeasures WHERE MeasureName = N'Noise Index')
    INSERT INTO mon.BIInsightMeasures (DatasetKey, MeasureName, ExpressionText, FormatString, DisplayFolder)
    VALUES (N'noisy-alerts', N'Noise Index', N'SUM([RepeatCount]) + COUNTROWS(NoisyAlerts)', N'0', N'Alert Noise');

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightMeasures WHERE MeasureName = N'Capacity Risk')
    INSERT INTO mon.BIInsightMeasures (DatasetKey, MeasureName, ExpressionText, FormatString, DisplayFolder)
    VALUES (N'capacity-hotspots', N'Capacity Risk', N'MAX([PeakUsedPct]) - MIN([MinFreeGB])', N'0.0', N'Capacity');

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightMeasures WHERE MeasureName = N'VM Health Score')
    INSERT INTO mon.BIInsightMeasures (DatasetKey, MeasureName, ExpressionText, FormatString, DisplayFolder)
    VALUES (N'vm-scorecard', N'VM Health Score', N'AVERAGE([HealthScore])', N'0', N'VM Executive KPIs');

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightMeasures WHERE MeasureName = N'VM SLA Breach Count')
    INSERT INTO mon.BIInsightMeasures (DatasetKey, MeasureName, ExpressionText, FormatString, DisplayFolder)
    VALUES (N'vm-ticket-sla', N'VM SLA Breach Count', N'CALCULATE(SUM([TicketCount]), [SLAStatus] = "Breached")', N'0', N'VM Service Desk');

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightTransformations WHERE DatasetKey = N'alert-trends')
    INSERT INTO mon.BIInsightTransformations (DatasetKey, StepName, StepType, ExpressionText, StepOrder)
    VALUES (N'alert-trends', N'Filter date range', N'Filter Rows', N'AlertTime >= selected range', 1),
           (N'alert-trends', N'Group by day and severity', N'Group By', N'AlertDate, Severity, AlertCount', 2);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightTransformations WHERE DatasetKey = N'noisy-alerts')
    INSERT INTO mon.BIInsightTransformations (DatasetKey, StepName, StepType, ExpressionText, StepOrder)
    VALUES (N'noisy-alerts', N'Detect alert fingerprint', N'Conditional Column', N'Instance + Module + Title + Severity', 1),
           (N'noisy-alerts', N'Group repeats', N'Group By', N'AlertFingerprint, RepeatCount, FirstSeen, LastSeen', 2);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightTransformations WHERE DatasetKey = N'capacity-hotspots')
    INSERT INTO mon.BIInsightTransformations (DatasetKey, StepName, StepType, ExpressionText, StepOrder)
    VALUES (N'capacity-hotspots', N'Calculate free GB', N'Custom Column', N'FreeMB / 1024.0', 1),
           (N'capacity-hotspots', N'Sort by risk', N'Sort Rows', N'PeakUsedPct DESC, MinFreeGB ASC', 2);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightTransformations WHERE DatasetKey = N'vm-scorecard')
    INSERT INTO mon.BIInsightTransformations (DatasetKey, StepName, StepType, ExpressionText, StepOrder)
    VALUES (N'vm-scorecard', N'Load latest VM sample', N'Filter Rows', N'Use latest WindowsPerformanceSamples per target', 1),
           (N'vm-scorecard', N'Join alert and ticket posture', N'Merge Queries', N'Join Windows open alerts and VM Monitoring tickets by target mapping', 2);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightTransformations WHERE DatasetKey = N'vm-ticket-sla')
    INSERT INTO mon.BIInsightTransformations (DatasetKey, StepName, StepType, ExpressionText, StepOrder)
    VALUES (N'vm-ticket-sla', N'Filter VM tickets', N'Filter Rows', N'Category = VM Monitoring', 1),
           (N'vm-ticket-sla', N'Classify SLA status', N'Conditional Column', N'Breached, Due Soon, Within SLA, Closed, No SLA', 2);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightThemes WHERE ThemeName = N'SQL Monitor Default')
    INSERT INTO mon.BIInsightThemes (ThemeName, ThemeJson, IsDefault)
    VALUES (N'SQL Monitor Default', N'{"colors":["#0969da","#198754","#f2a900","#d73a49"],"fontFamily":"Segoe UI"}', 1);

IF NOT EXISTS (SELECT 1 FROM mon.BIInsightQAPrompts WHERE PromptText = N'Which servers are critical?')
    INSERT INTO mon.BIInsightQAPrompts (PromptText, AnswerTemplate, DatasetKey, IsVerified)
    VALUES (N'Which servers are critical?', N'Show servers where HealthPosture = Critical, sorted by open alerts.', N'server-scorecard', 1),
           (N'What are the noisiest alerts?', N'Show noisy-alerts sorted by RepeatCount descending.', N'noisy-alerts', 1),
           (N'Which disks are near full?', N'Show capacity-hotspots sorted by PeakUsedPct descending.', N'capacity-hotspots', 1);

MERGE mon.BIInsightQAPrompts AS target
USING (VALUES
    (N'Which tickets are most severe?', N'Use Ticket Severity and sort by TicketCount, then AvgResolutionMinutes.', N'ticket-severity', 1),
    (N'Which tasks are overdue by priority?', N'Use Task Priority and focus on OverdueCount by Critical and High priority.', N'task-priority', 1),
    (N'What can each application owner see?', N'Use Application Server Groups and Application Scorecard filtered by ApplicationName or GroupName.', N'application-scorecard', 1),
    (N'Which applications have the most alerts?', N'Use Application Scorecard sorted by OpenAlerts and HealthPosture.', N'application-scorecard', 1),
    (N'Which servers have backup risk?', N'Use Backup Compliance filtered to failed or stale StatusText values.', N'backup-compliance', 1),
    (N'Which Windows VMs are unhealthy?', N'Use VM Scorecard filtered to Critical or Warning HealthPosture and sort by OpenAlerts.', N'vm-scorecard', 1),
    (N'Which VM tickets are breaching SLA?', N'Use VM Ticket SLA filtered to SLAStatus = Breached or Due Soon.', N'vm-ticket-sla', 1),
    (N'Which VM drives are near full?', N'Use VM Capacity sorted by PeakUsedPercent descending and MinFreeGB ascending.', N'vm-capacity', 1)
) AS source (PromptText, AnswerTemplate, DatasetKey, IsVerified)
ON target.PromptText = source.PromptText
WHEN MATCHED THEN
    UPDATE SET AnswerTemplate = source.AnswerTemplate,
               DatasetKey = source.DatasetKey,
               IsVerified = source.IsVerified
WHEN NOT MATCHED THEN
    INSERT (PromptText, AnswerTemplate, DatasetKey, IsVerified)
    VALUES (source.PromptText, source.AnswerTemplate, source.DatasetKey, source.IsVerified);

PRINT 'BI Insights Studio schema is ready.';
