-- ============================================================
-- Phase 19: Dedicated stored procedures for VM Memory Trend
-- ============================================================
SET NOCOUNT ON;

-- ============================================================
-- Stored Procedure: mon.usp_InsertWindowsPerformanceSample
-- Purpose: Inserts a single performance sample (CPU, Memory, Disk)
--          into mon.WindowsPerformanceSamples with validation
-- ============================================================
IF OBJECT_ID('mon.usp_InsertWindowsPerformanceSample', 'P') IS NULL
    EXEC(N'CREATE PROCEDURE mon.usp_InsertWindowsPerformanceSample AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE mon.usp_InsertWindowsPerformanceSample
    @TargetID INT,
    @CaptureTime DATETIME2(0) = NULL,
    @CPUPercent DECIMAL(6,2) = NULL,
    @MemoryUsedPercent DECIMAL(6,2) = NULL,
    @MemoryAvailableGB DECIMAL(18,2) = NULL,
    @DiskUsedPercent DECIMAL(6,2) = NULL,
    @DiskFreeGB DECIMAL(18,2) = NULL,
    @NetworkBytesPerSec BIGINT = NULL,
    @ProcessCount INT = NULL,
    @ServiceStoppedCount INT = NULL,
    @HealthScore INT = NULL,
    @HealthPosture NVARCHAR(30) = NULL,
    @SampleID BIGINT = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate required parameters
    IF @TargetID IS NULL OR @TargetID <= 0
        THROW 51000, 'TargetID is required and must be a positive integer.', 1;

    -- Use current time if not provided
    SET @CaptureTime = ISNULL(@CaptureTime, SYSDATETIME());

    -- Validate HealthPosture
    IF @HealthPosture IS NOT NULL AND @HealthPosture NOT IN (N'Healthy', N'Warning', N'Critical')
        SET @HealthPosture = NULL;

    -- Validate ranges
    IF @CPUPercent IS NOT NULL
        SET @CPUPercent = CASE
            WHEN @CPUPercent < 0 THEN 0
            WHEN @CPUPercent > 100 THEN 100
            ELSE @CPUPercent
        END;

    IF @MemoryUsedPercent IS NOT NULL
        SET @MemoryUsedPercent = CASE
            WHEN @MemoryUsedPercent < 0 THEN 0
            WHEN @MemoryUsedPercent > 100 THEN 100
            ELSE @MemoryUsedPercent
        END;

    IF @DiskUsedPercent IS NOT NULL
        SET @DiskUsedPercent = CASE
            WHEN @DiskUsedPercent < 0 THEN 0
            WHEN @DiskUsedPercent > 100 THEN 100
            ELSE @DiskUsedPercent
        END;

    IF @HealthScore IS NOT NULL
        SET @HealthScore = CASE
            WHEN @HealthScore < 0 THEN 0
            WHEN @HealthScore > 100 THEN 100
            ELSE @HealthScore
        END;

    -- Validate MemoryAvailableGB is not negative
    IF @MemoryAvailableGB IS NOT NULL AND @MemoryAvailableGB < 0
        SET @MemoryAvailableGB = 0;

    -- Validate DiskFreeGB is not negative
    IF @DiskFreeGB IS NOT NULL AND @DiskFreeGB < 0
        SET @DiskFreeGB = 0;

    -- Validate ProcessCount is not negative
    IF @ProcessCount IS NOT NULL AND @ProcessCount < 0
        SET @ProcessCount = 0;

    -- Validate ServiceStoppedCount is not negative
    IF @ServiceStoppedCount IS NOT NULL AND @ServiceStoppedCount < 0
        SET @ServiceStoppedCount = 0;

    -- Insert the sample
    INSERT INTO mon.WindowsPerformanceSamples
        (TargetID, CaptureTime, CPUPercent, MemoryUsedPercent, MemoryAvailableGB,
         DiskUsedPercent, DiskFreeGB, NetworkBytesPerSec, ProcessCount,
         ServiceStoppedCount, HealthScore, HealthPosture)
    VALUES
        (@TargetID, @CaptureTime, @CPUPercent, @MemoryUsedPercent, @MemoryAvailableGB,
         @DiskUsedPercent, @DiskFreeGB, @NetworkBytesPerSec, @ProcessCount,
         @ServiceStoppedCount, @HealthScore, @HealthPosture);

    SET @SampleID = SCOPE_IDENTITY();
END;
GO

-- ============================================================
-- Stored Procedure: mon.usp_GetWindowsMemoryTrend
-- Purpose: Returns memory trend data for VM Monitoring charts
--          Returns latest 240 samples with MemoryUsedPercent trend
-- ============================================================
IF OBJECT_ID('mon.usp_GetWindowsMemoryTrend', 'P') IS NULL
    EXEC(N'CREATE PROCEDURE mon.usp_GetWindowsMemoryTrend AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE mon.usp_GetWindowsMemoryTrend
    @TopSamples INT = 240,
    @TargetID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @TargetID IS NOT NULL AND @TargetID > 0
    BEGIN
        -- Return trend for a specific target
        SELECT TOP (@TopSamples)
            t.DisplayName,
            ps.CaptureTime,
            ps.MemoryUsedPercent,
            ps.MemoryAvailableGB,
            ps.HealthScore,
            ps.HealthPosture
        FROM mon.WindowsPerformanceSamples ps
        INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
        WHERE ps.TargetID = @TargetID
        ORDER BY ps.CaptureTime DESC;
    END
    ELSE
    BEGIN
        -- Return trend for all targets (used by VM Performance view)
        SELECT TOP (@TopSamples)
            t.DisplayName,
            ps.CaptureTime,
            ps.MemoryUsedPercent,
            ps.MemoryAvailableGB,
            ps.CPUPercent,
            ps.DiskUsedPercent,
            ps.HealthScore,
            ps.HealthPosture
        FROM mon.WindowsPerformanceSamples ps
        INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
        ORDER BY ps.CaptureTime DESC;
    END;
END;
GO

-- ============================================================
-- Stored Procedure: mon.usp_GetWindowsPerformanceTrend
-- Purpose: Returns complete performance trend data (CPU, Memory, Disk)
--          for VM Performance charts (replaces inline query in web server)
-- ============================================================
IF OBJECT_ID('mon.usp_GetWindowsPerformanceTrend', 'P') IS NULL
    EXEC(N'CREATE PROCEDURE mon.usp_GetWindowsPerformanceTrend AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE mon.usp_GetWindowsPerformanceTrend
    @TopSamples INT = 240,
    @TargetID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (@TopSamples)
        t.DisplayName,
        ps.CaptureTime,
        ps.CPUPercent,
        ps.MemoryUsedPercent,
        ps.MemoryAvailableGB,
        ps.DiskUsedPercent,
        ps.DiskFreeGB,
        ps.HealthScore,
        ps.HealthPosture,
        ps.ProcessCount,
        ps.ServiceStoppedCount,
        ps.NetworkBytesPerSec
    FROM mon.WindowsPerformanceSamples ps
    INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
    WHERE (@TargetID IS NULL OR @TargetID <= 0 OR ps.TargetID = @TargetID)
    ORDER BY ps.CaptureTime DESC;
END;
GO

-- ============================================================
-- View: mon.vw_WindowsMemoryTrend (for direct querying)
-- ============================================================
IF OBJECT_ID('mon.vw_WindowsMemoryTrend', 'V') IS NOT NULL
    DROP VIEW mon.vw_WindowsMemoryTrend;
GO

EXEC(N'CREATE VIEW mon.vw_WindowsMemoryTrend AS
WITH ranked AS (
    SELECT
        t.DisplayName,
        ps.CaptureTime,
        ps.MemoryUsedPercent,
        ps.MemoryAvailableGB,
        ps.HealthScore,
        t.TargetID,
        ROW_NUMBER() OVER (PARTITION BY ps.TargetID ORDER BY ps.CaptureTime DESC) AS rn
    FROM mon.WindowsPerformanceSamples ps
    INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
    WHERE ps.MemoryUsedPercent IS NOT NULL
)
SELECT
    DisplayName,
    CaptureTime,
    MemoryUsedPercent,
    MemoryAvailableGB,
    HealthScore,
    TargetID
FROM ranked
WHERE rn <= 240;');
GO

PRINT 'VM Memory Trend stored procedures and view are ready.';
GO