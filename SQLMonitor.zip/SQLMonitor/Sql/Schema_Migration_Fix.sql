-- Schema Migration Script - Fix All Missing Tables and Columns
-- Run this script to align database schema with collector expectations

USE [DBA_SQLMonitor]
GO

PRINT 'Starting schema migration...'
GO

-- =====================================================
-- 1. DISK VOLUME HISTORY TABLE
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DiskVolumeHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'mon'))
BEGIN
    PRINT 'Creating mon.DiskVolumeHistory...'
    CREATE TABLE [mon].[DiskVolumeHistory] (
        [DiskHistoryID] [int] IDENTITY(1,1) NOT NULL,
        [InstanceID] [int] NOT NULL,
        [CaptureTime] [datetime2](7) NOT NULL,
        [MountPoint] [nvarchar](256) NULL,
        [VolumeMountPoint] [nvarchar](256) NULL,
        [VolumeName] [nvarchar](128) NULL,
        [LogicalVolumeName] [nvarchar](128) NULL,
        [TotalSizeMB] [bigint] NULL,
        [FreeSizeMB] [bigint] NULL,
        [TotalGB] [decimal](18, 2) NULL,
        [FreeGB] [decimal](18, 2) NULL,
        [UsedGB] [decimal](18, 2) NULL,
        [UsedPct] [decimal](18, 2) NULL,
        CONSTRAINT [PK_DiskVolumeHistory] PRIMARY KEY CLUSTERED ([DiskHistoryID] ASC)
    ) ON [PRIMARY]
    
    ALTER TABLE [mon].[DiskVolumeHistory]
    ADD CONSTRAINT [FK_DiskVolumeHistory_Instance]
    FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
    
    CREATE NONCLUSTERED INDEX [IX_DiskVolumeHistory_InstanceTime] 
    ON [mon].[DiskVolumeHistory] ([InstanceID], [CaptureTime] DESC)
    
    PRINT 'Created mon.DiskVolumeHistory'
END
ELSE
BEGIN
    PRINT 'mon.DiskVolumeHistory already exists'
END
GO

-- =====================================================
-- 2. I/O FILE HISTORY TABLE
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='IOFileHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'mon'))
BEGIN
    PRINT 'Creating mon.IOFileHistory...'
    CREATE TABLE [mon].[IOFileHistory] (
        [IOHistoryID] [int] IDENTITY(1,1) NOT NULL,
        [InstanceID] [int] NOT NULL,
        [CaptureTime] [datetime2](7) NOT NULL,
        [DatabaseName] [nvarchar](128) NOT NULL,
        [FileType] [nvarchar](20) NOT NULL,
        [LogicalFileName] [nvarchar](256) NOT NULL,
        [FilePath] [nvarchar](512) NOT NULL,
        [FileSizeMB] [bigint] NULL,
        [AvgReadLatencyMS] [float] NULL,
        [AvgWriteLatencyMS] [float] NULL,
        [TotalStallMS] [float] NULL,
        CONSTRAINT [PK_IOFileHistory] PRIMARY KEY CLUSTERED ([IOHistoryID] ASC)
    ) ON [PRIMARY]
    
    ALTER TABLE [mon].[IOFileHistory]
    ADD CONSTRAINT [FK_IOFileHistory_Instance]
    FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
    
    CREATE NONCLUSTERED INDEX [IX_IOFileHistory_InstanceTime] 
    ON [mon].[IOFileHistory] ([InstanceID], [CaptureTime] DESC)
    
    PRINT 'Created mon.IOFileHistory'
END
ELSE
BEGIN
    PRINT 'mon.IOFileHistory already exists'
    
    -- Add missing columns if they don't exist
    IF NOT EXISTS (SELECT * FROM syscolumns WHERE id=OBJECT_ID('mon.IOFileHistory') AND name='AvgReadLatencyMS')
    BEGIN
        PRINT 'Adding AvgReadLatencyMS to mon.IOFileHistory...'
        ALTER TABLE [mon].[IOFileHistory] ADD [AvgReadLatencyMS] [float] NULL
    END
    
    IF NOT EXISTS (SELECT * FROM syscolumns WHERE id=OBJECT_ID('mon.IOFileHistory') AND name='AvgWriteLatencyMS')
    BEGIN
        PRINT 'Adding AvgWriteLatencyMS to mon.IOFileHistory...'
        ALTER TABLE [mon].[IOFileHistory] ADD [AvgWriteLatencyMS] [float] NULL
    END
END
GO

-- =====================================================
-- 3. TEMPDB HISTORY TABLE
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TempDBHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'mon'))
BEGIN
    PRINT 'Creating mon.TempDBHistory...'
    CREATE TABLE [mon].[TempDBHistory] (
        [TempDBHistoryID] [int] IDENTITY(1,1) NOT NULL,
        [InstanceID] [int] NOT NULL,
        [CaptureTime] [datetime2](7) NOT NULL,
        [FileCount] [int] NULL,
        [TotalSizeMB] [bigint] NULL,
        [UsedMB] [bigint] NULL,
        CONSTRAINT [PK_TempDBHistory] PRIMARY KEY CLUSTERED ([TempDBHistoryID] ASC)
    ) ON [PRIMARY]
    
    ALTER TABLE [mon].[TempDBHistory]
    ADD CONSTRAINT [FK_TempDBHistory_Instance]
    FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
    
    CREATE NONCLUSTERED INDEX [IX_TempDBHistory_InstanceTime] 
    ON [mon].[TempDBHistory] ([InstanceID], [CaptureTime] DESC)
    
    PRINT 'Created mon.TempDBHistory'
END
ELSE
BEGIN
    PRINT 'mon.TempDBHistory already exists'
END
GO

-- =====================================================
-- 4. BLOCKING HISTORY TABLE
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='BlockingHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'mon'))
BEGIN
    PRINT 'Creating mon.BlockingHistory...'
    CREATE TABLE [mon].[BlockingHistory] (
        [BlockingHistoryID] [int] IDENTITY(1,1) NOT NULL,
        [InstanceID] [int] NOT NULL,
        [CaptureTime] [datetime2](7) NOT NULL,
        [SPID] [int] NULL,
        [BlockedBySPID] [int] NULL,
        [DatabaseName] [nvarchar](128) NULL,
        [WaitType] [nvarchar](128) NULL,
        [WaitTimeMS] [bigint] NULL,
        [LoginName] [nvarchar](128) NULL,
        [HostName] [nvarchar](128) NULL,
        [CommandType] [nvarchar](64) NULL,
        [StatementText] [nvarchar](max) NULL,
        CONSTRAINT [PK_BlockingHistory] PRIMARY KEY CLUSTERED ([BlockingHistoryID] ASC)
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    
    ALTER TABLE [mon].[BlockingHistory]
    ADD CONSTRAINT [FK_BlockingHistory_Instance]
    FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
    
    CREATE NONCLUSTERED INDEX [IX_BlockingHistory_InstanceTime] 
    ON [mon].[BlockingHistory] ([InstanceID], [CaptureTime] DESC)
    
    PRINT 'Created mon.BlockingHistory'
END
ELSE
BEGIN
    PRINT 'mon.BlockingHistory already exists'
END
GO

-- =====================================================
-- 5. LONG RUNNING HISTORY TABLE
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='LongRunningHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'mon'))
BEGIN
    PRINT 'Creating mon.LongRunningHistory...'
    CREATE TABLE [mon].[LongRunningHistory] (
        [LongRunningHistoryID] [int] IDENTITY(1,1) NOT NULL,
        [InstanceID] [int] NOT NULL,
        [CaptureTime] [datetime2](7) NOT NULL,
        [SPID] [int] NULL,
        [DatabaseName] [nvarchar](128) NULL,
        [StartTime] [datetime2](7) NULL,
        [DurationMS] [bigint] NULL,
        [Status] [nvarchar](60) NULL,
        [WaitType] [nvarchar](128) NULL,
        [CPUTimeMS] [bigint] NULL,
        [LogicalReads] [bigint] NULL,
        [PhysicalReads] [bigint] NULL,
        [LogicalWrites] [bigint] NULL,
        [CommandType] [nvarchar](64) NULL,
        [HostName] [nvarchar](128) NULL,
        [LoginName] [nvarchar](128) NULL,
        [QueryText] [nvarchar](max) NULL,
        CONSTRAINT [PK_LongRunningHistory] PRIMARY KEY CLUSTERED ([LongRunningHistoryID] ASC)
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    
    ALTER TABLE [mon].[LongRunningHistory]
    ADD CONSTRAINT [FK_LongRunningHistory_Instance]
    FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
    
    CREATE NONCLUSTERED INDEX [IX_LongRunningHistory_InstanceTime] 
    ON [mon].[LongRunningHistory] ([InstanceID], [CaptureTime] DESC)
    
    PRINT 'Created mon.LongRunningHistory'
END
ELSE
BEGIN
    PRINT 'mon.LongRunningHistory already exists'
END
GO

-- =====================================================
-- 6. UPDATE EXISTING TABLES WITH MISSING COLUMNS
-- =====================================================

-- Check if DBOptionsHistory is missing MDFUsedMB and LDFUsedMB columns
IF EXISTS (SELECT * FROM sysobjects WHERE name='DBOptionsHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'mon'))
BEGIN
    IF NOT EXISTS (SELECT * FROM syscolumns WHERE id=OBJECT_ID('mon.DBOptionsHistory') AND name='MDFUsedMB')
    BEGIN
        PRINT 'Adding MDFUsedMB to mon.DBOptionsHistory...'
        ALTER TABLE [mon].[DBOptionsHistory] ADD [MDFUsedMB] [numeric](12,2) NULL
    END
    
    IF NOT EXISTS (SELECT * FROM syscolumns WHERE id=OBJECT_ID('mon.DBOptionsHistory') AND name='LDFUsedMB')
    BEGIN
        PRINT 'Adding LDFUsedMB to mon.DBOptionsHistory...'
        ALTER TABLE [mon].[DBOptionsHistory] ADD [LDFUsedMB] [numeric](12,2) NULL
    END
END
GO

PRINT 'Schema migration completed successfully!'
PRINT ''
PRINT 'Tables created/verified:'
PRINT '  - mon.DiskVolumeHistory'
PRINT '  - mon.IOFileHistory'
PRINT '  - mon.TempDBHistory'
PRINT '  - mon.BlockingHistory'
PRINT '  - mon.LongRunningHistory'
PRINT '  - mon.DBOptionsHistory (updated with missing columns)'
GO
