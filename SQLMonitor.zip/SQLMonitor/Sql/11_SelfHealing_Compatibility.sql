USE [DBA_SQLMonitor];
GO

-- Safe repository upgrade fixes. All additions are nullable so existing data is preserved.

IF OBJECT_ID('mon.AlertHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.AlertHistory', 'AlertDetails') IS NULL ALTER TABLE mon.AlertHistory ADD AlertDetails NVARCHAR(MAX) NULL;
    IF COL_LENGTH('mon.AlertHistory', 'IsAcknowledged') IS NULL ALTER TABLE mon.AlertHistory ADD IsAcknowledged BIT NULL;
    IF COL_LENGTH('mon.AlertHistory', 'AcknowledgedBy') IS NULL ALTER TABLE mon.AlertHistory ADD AcknowledgedBy NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.AlertHistory', 'AcknowledgedOn') IS NULL ALTER TABLE mon.AlertHistory ADD AcknowledgedOn DATETIME2 NULL;
    IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL ALTER TABLE mon.AlertHistory ADD RepeatCount INT NOT NULL CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
    IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL ALTER TABLE mon.AlertHistory ADD FirstAlertTime DATETIME2 NULL;
    IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL ALTER TABLE mon.AlertHistory ADD LastRepeatedAt DATETIME2 NULL;
    IF COL_LENGTH('mon.AlertHistory', 'IsTicketCreated') IS NULL ALTER TABLE mon.AlertHistory ADD IsTicketCreated BIT NOT NULL CONSTRAINT DF_AlertHistory_IsTicketCreated DEFAULT (0);

    UPDATE mon.AlertHistory
    SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
        LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
        RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
    WHERE FirstAlertTime IS NULL
       OR LastRepeatedAt IS NULL
       OR ISNULL(RepeatCount, 0) < 1;
END;
GO

IF OBJECT_ID('mon.AlertThresholds', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.AlertThresholds', 'IsActive') IS NULL ALTER TABLE mon.AlertThresholds ADD IsActive BIT NULL;
END;
GO

IF OBJECT_ID('mon.TaskComments', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.TaskComments', 'ModifiedBy') IS NULL ALTER TABLE mon.TaskComments ADD ModifiedBy NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.TaskComments', 'ModifiedDate') IS NULL ALTER TABLE mon.TaskComments ADD ModifiedDate DATETIME2(7) NULL;
    IF COL_LENGTH('mon.TaskComments', 'IsEdited') IS NULL ALTER TABLE mon.TaskComments ADD IsEdited BIT NOT NULL CONSTRAINT DF_TaskComments_IsEdited DEFAULT (0);
END;
GO

IF OBJECT_ID('mon.DashboardUsers', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.DashboardUsers', 'DisplayName') IS NULL ALTER TABLE mon.DashboardUsers ADD DisplayName NVARCHAR(200) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'PasswordSalt') IS NULL ALTER TABLE mon.DashboardUsers ADD PasswordSalt VARBINARY(16) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'PasswordHash') IS NULL ALTER TABLE mon.DashboardUsers ADD PasswordHash VARBINARY(32) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'RoleName') IS NULL ALTER TABLE mon.DashboardUsers ADD RoleName NVARCHAR(20) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'IsActive') IS NULL ALTER TABLE mon.DashboardUsers ADD IsActive BIT NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'MustChangePassword') IS NULL ALTER TABLE mon.DashboardUsers ADD MustChangePassword BIT NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'FailedLoginCount') IS NULL ALTER TABLE mon.DashboardUsers ADD FailedLoginCount INT NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'LastFailedLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastFailedLoginAt DATETIME2(0) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'LockoutUntil') IS NULL ALTER TABLE mon.DashboardUsers ADD LockoutUntil DATETIME2(0) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'PasswordChangedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD PasswordChangedAt DATETIME2(0) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'CreatedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD CreatedAt DATETIME2(0) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'UpdatedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD UpdatedAt DATETIME2(0) NULL;
    IF COL_LENGTH('mon.DashboardUsers', 'LastLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastLoginAt DATETIME2(0) NULL;
END;
GO

IF OBJECT_ID('mon.DashboardUserInstanceAccess', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.DashboardUserInstanceAccess', 'CreatedAt') IS NULL ALTER TABLE mon.DashboardUserInstanceAccess ADD CreatedAt DATETIME2(0) NULL;
END;
GO

IF OBJECT_ID('mon.DashboardAuditLog', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.DashboardAuditLog', 'UserName') IS NULL ALTER TABLE mon.DashboardAuditLog ADD UserName NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.DashboardAuditLog', 'Details') IS NULL ALTER TABLE mon.DashboardAuditLog ADD Details NVARCHAR(1000) NULL;
    IF COL_LENGTH('mon.DashboardAuditLog', 'ClientHost') IS NULL ALTER TABLE mon.DashboardAuditLog ADD ClientHost NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.DashboardAuditLog', 'CreatedAt') IS NULL ALTER TABLE mon.DashboardAuditLog ADD CreatedAt DATETIME2(0) NULL;
END;
GO

PRINT 'Self-healing compatibility checks complete.';
GO
