-- Add BackupStatusHistory table for backup monitoring
-- Run this script on the repository database

USE DBA_SQLMonitor;
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'mon')
BEGIN
    EXEC('CREATE SCHEMA mon');
END
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'BackupStatusHistory' AND schema_id = SCHEMA_ID('mon'))
BEGIN
    CREATE TABLE mon.BackupStatusHistory (
        [BackupHistoryID] [int] IDENTITY(1,1) NOT NULL,
        [InstanceID] [int] NOT NULL,
        [CaptureTime] [datetime2](7) NOT NULL,
        [DatabaseName] [nvarchar](128) NOT NULL,
        [RecoveryModel] [nvarchar](20) NULL,
        [LastFullBackup] [datetime2](7) NULL,
        [HoursSinceFullBackup] [int] NULL,
        [LastDiffBackup] [datetime2](7) NULL,
        [HoursSinceDiffBackup] [int] NULL,
        [LastLogBackup] [datetime2](7) NULL,
        [HoursSinceLogBackup] [int] NULL,
        [BackupStatus] [nvarchar](50) NULL,
        CONSTRAINT [PK_BackupStatusHistory] PRIMARY KEY CLUSTERED ([BackupHistoryID] ASC)
    );

    -- Add foreign key constraint
    ALTER TABLE mon.BackupStatusHistory
    ADD CONSTRAINT [FK_BackupStatusHistory_Instance]
    FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID]);

    -- Create index for efficient queries
    CREATE NONCLUSTERED INDEX [IX_BackupStatusHistory_InstanceTime]
    ON [mon].[BackupStatusHistory] ([InstanceID], [CaptureTime] DESC);

    PRINT 'Created mon.BackupStatusHistory table successfully';
END
ELSE
BEGIN
    PRINT 'Table mon.BackupStatusHistory already exists';
END
GO
