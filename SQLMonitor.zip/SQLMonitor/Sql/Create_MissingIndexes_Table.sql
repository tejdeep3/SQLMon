-- Create dbo.MissingIndexes table for storing missing index recommendations
USE [DBA_SQLMonitor]
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'MissingIndexes' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE [dbo].[MissingIndexes] (
        [MissingIndexID] [int] IDENTITY(1,1) NOT NULL,
        [InstanceID] [int] NOT NULL,
        [CollectionDateTime] [datetime2](7) NOT NULL,
        [DatabaseName] [nvarchar](128) NOT NULL,
        [ObjectName] [nvarchar](128) NOT NULL,
        [EqualityColumns] [nvarchar](max) NULL,
        [InequalityColumns] [nvarchar](max) NULL,
        [IncludedColumns] [nvarchar](max) NULL,
        [UserSeeks] [bigint] NULL,
        [UserScans] [bigint] NULL,
        [UserLookups] [bigint] NULL,
        [UserUpdates] [bigint] NULL,
        [AvgTotalUserCost] [float] NULL,
        [AvgUserImpact] [float] NULL,
        [UniqueCompiles] [bigint] NULL,
        [ImprovementMeasure] [float] NULL,
        CONSTRAINT [PK_MissingIndexes] PRIMARY KEY CLUSTERED ([MissingIndexID] ASC)
            WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, 
                  ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) 
            ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    
    ALTER TABLE [dbo].[MissingIndexes] WITH CHECK 
        ADD CONSTRAINT [FK_MissingIndexes_Instances] 
        FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
    
    ALTER TABLE [dbo].[MissingIndexes] CHECK CONSTRAINT [FK_MissingIndexes_Instances]
    
    PRINT 'MissingIndexes table created successfully'
END
ELSE
BEGIN
    PRINT 'MissingIndexes table already exists'
END
GO
