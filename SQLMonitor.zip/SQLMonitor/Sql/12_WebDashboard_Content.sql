IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');
GO

IF OBJECT_ID('mon.SOPs', 'U') IS NULL
BEGIN
    CREATE TABLE mon.SOPs (
        SopID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SOPs PRIMARY KEY,
        IssueID INT NULL,
        Title NVARCHAR(200) NOT NULL,
        Category NVARCHAR(100) NULL,
        Severity NVARCHAR(20) NULL,
        Description NVARCHAR(MAX) NULL,
        SOPText NVARCHAR(MAX) NULL,
        Frequency NVARCHAR(50) NULL,
        Owner NVARCHAR(100) NULL,
        Tags NVARCHAR(400) NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_SOPs_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_SOPs_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastUpdatedBy NVARCHAR(128) NULL
    );
END;
GO

IF COL_LENGTH('mon.SOPs', 'IssueID') IS NULL ALTER TABLE mon.SOPs ADD IssueID INT NULL;
IF COL_LENGTH('mon.SOPs', 'Title') IS NULL ALTER TABLE mon.SOPs ADD Title NVARCHAR(200) NULL;
IF COL_LENGTH('mon.SOPs', 'Category') IS NULL ALTER TABLE mon.SOPs ADD Category NVARCHAR(100) NULL;
IF COL_LENGTH('mon.SOPs', 'Severity') IS NULL ALTER TABLE mon.SOPs ADD Severity NVARCHAR(20) NULL;
IF COL_LENGTH('mon.SOPs', 'Description') IS NULL ALTER TABLE mon.SOPs ADD Description NVARCHAR(MAX) NULL;
IF COL_LENGTH('mon.SOPs', 'SOPText') IS NULL ALTER TABLE mon.SOPs ADD SOPText NVARCHAR(MAX) NULL;
IF COL_LENGTH('mon.SOPs', 'Frequency') IS NULL ALTER TABLE mon.SOPs ADD Frequency NVARCHAR(50) NULL;
IF COL_LENGTH('mon.SOPs', 'Owner') IS NULL ALTER TABLE mon.SOPs ADD Owner NVARCHAR(100) NULL;
IF COL_LENGTH('mon.SOPs', 'Tags') IS NULL ALTER TABLE mon.SOPs ADD Tags NVARCHAR(400) NULL;
IF COL_LENGTH('mon.SOPs', 'IsActive') IS NULL ALTER TABLE mon.SOPs ADD IsActive BIT NOT NULL CONSTRAINT DF_SOPs_IsActive_Upgrade DEFAULT (1);
IF COL_LENGTH('mon.SOPs', 'CreatedAt') IS NULL ALTER TABLE mon.SOPs ADD CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_SOPs_CreatedAt_Upgrade DEFAULT (SYSDATETIME());
IF COL_LENGTH('mon.SOPs', 'UpdatedAt') IS NULL ALTER TABLE mon.SOPs ADD UpdatedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.SOPs', 'LastUpdatedBy') IS NULL ALTER TABLE mon.SOPs ADD LastUpdatedBy NVARCHAR(128) NULL;
GO

IF NOT EXISTS (SELECT 1 FROM mon.SOPs WHERE IsActive = 1)
BEGIN
    INSERT INTO mon.SOPs (IssueID, Title, Category, Severity, Description, SOPText, Frequency, Owner, Tags, IsActive, LastUpdatedBy)
    VALUES
    (1, N'High CPU Utilization (>90%)', N'Performance', N'Critical', N'SQL Server CPU usage is consistently high.', N'Identify top CPU queries, inspect plans, check missing indexes, review parameterization, and validate host CPU capacity.', N'High', N'DBA Team', N'Performance', 1, N'System'),
    (2, N'Low Page Life Expectancy', N'Memory', N'Critical', N'Pages are being flushed from memory too quickly.', N'Review memory grants, buffer pressure, max server memory, and expensive queries. Add memory if pressure is sustained.', N'Medium', N'DBA Team', N'Memory', 1, N'System'),
    (3, N'Transaction Log Full', N'Storage', N'High', N'Transaction log has reached capacity.', N'Run log backup, check log backup schedule, review long transactions, and right-size growth settings.', N'Medium', N'DBA Team', N'Storage', 1, N'System'),
    (4, N'Always On AG Synchronization Issues', N'Availability', N'Critical', N'Availability Group databases are not synchronizing.', N'Check replica health, SQL error logs, endpoint connectivity, disk space, and failover readiness.', N'Low', N'DBA Team', N'Availability', 1, N'System'),
    (5, N'Excessive Blocking', N'Performance', N'High', N'Queries are blocked for extended periods.', N'Find head blocker, inspect transaction scope, tune query/indexes, and review isolation level.', N'High', N'DBA Team', N'Performance', 1, N'System'),
    (6, N'Failed Backup Jobs', N'Backup', N'Critical', N'Database backup jobs are failing.', N'Review SQL Agent job history, destination permissions, disk space, and verify backup integrity.', N'Medium', N'DBA Team', N'Backup', 1, N'System'),
    (7, N'Failed Login Attempts', N'Security', N'High', N'Repeated authentication failures were detected.', N'Review error logs, validate application connection strings, account policy, and possible brute force attempts.', N'High', N'DBA Team', N'Security', 1, N'System'),
    (8, N'High Disk I/O Latency', N'Storage', N'Medium', N'Disk operations are taking too long.', N'Use virtual file stats, check storage tier, tempdb placement, and reduce I/O through tuning/indexing.', N'Medium', N'DBA Team', N'Storage', 1, N'System');
END;
GO
