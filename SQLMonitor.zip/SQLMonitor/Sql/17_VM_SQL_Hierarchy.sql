-- ============================================================
-- Phase 17: VM → SQL Server Hierarchy
-- Establishes parent-child relationship between Windows VMs
-- (mon.WindowsTargets) and SQL Server instances (mon.MonitoredInstances)
-- ============================================================
SET NOCOUNT ON;
USE [DBA_SQLMonitor];
GO

-- ============================================================
-- 1. Add ParentVMID column to mon.MonitoredInstances
-- ============================================================
IF COL_LENGTH('mon.MonitoredInstances', 'ParentVMID') IS NULL
BEGIN
    ALTER TABLE mon.MonitoredInstances
    ADD ParentVMID INT NULL;
    PRINT 'Added ParentVMID column to mon.MonitoredInstances';
END;
GO

-- Add foreign key constraint (idempotent)
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys
    WHERE name = 'FK_MonitoredInstances_ParentVM'
      AND parent_object_id = OBJECT_ID('mon.MonitoredInstances')
)
BEGIN
    ALTER TABLE mon.MonitoredInstances
    ADD CONSTRAINT FK_MonitoredInstances_ParentVM
        FOREIGN KEY (ParentVMID) REFERENCES mon.WindowsTargets(TargetID);
    PRINT 'Added FK_MonitoredInstances_ParentVM constraint';
END;
GO

-- Index for fast lookups by parent VM
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_MonitoredInstances_ParentVMID'
      AND object_id = OBJECT_ID('mon.MonitoredInstances')
)
BEGIN
    CREATE INDEX IX_MonitoredInstances_ParentVMID
        ON mon.MonitoredInstances(ParentVMID)
        INCLUDE (DisplayName, ServerName, InstanceName, IsActive);
    PRINT 'Created IX_MonitoredInstances_ParentVMID index';
END;
GO

-- ============================================================
-- 2. Add IsVMHost flag to mon.WindowsTargets
-- ============================================================
IF COL_LENGTH('mon.WindowsTargets', 'IsVMHost') IS NULL
BEGIN
    ALTER TABLE mon.WindowsTargets
    ADD IsVMHost BIT NOT NULL CONSTRAINT DF_WindowsTargets_IsVMHost DEFAULT (1);
    PRINT 'Added IsVMHost column to mon.WindowsTargets';
END;
GO

-- ============================================================
-- 3. View: VM with aggregated SQL instance health
-- ============================================================
CREATE OR ALTER VIEW mon.vw_VMWithSQLInstances
AS
SELECT
    t.TargetID AS VMID,
    t.ComputerName AS VMComputerName,
    t.DisplayName AS VMDisplayName,
    t.EnvironmentName AS VMEnvironment,
    t.IsEnabled AS VMIsEnabled,
    t.IsVMHost,
    mi.InstanceID AS SQLInstanceID,
    mi.DisplayName AS SQLDisplayName,
    mi.ServerName AS SQLServerName,
    mi.InstanceName AS SQLInstanceName,
    mi.EnvironmentName AS SQLEnvironment,
    mi.IsActive AS SQLIsActive,
    mi.CreatedOn AS SQLCreatedOn
FROM mon.WindowsTargets t
LEFT JOIN mon.MonitoredInstances mi
    ON mi.ParentVMID = t.TargetID
WHERE t.IsEnabled = 1;
GO

-- ============================================================
-- 4. View: VM health summary with SQL instance counts
-- ============================================================
CREATE OR ALTER VIEW mon.vw_VMSummary
AS
SELECT
    t.TargetID,
    t.ComputerName,
    t.DisplayName,
    t.EnvironmentName,
    t.IsEnabled,
    t.IsVMHost,
    t.CollectionMode,
    t.CollectionIntervalMinutes,
    t.CreatedAt,
    t.LastUpdatedAt,
    ISNULL(inv.OSName, '') AS OSName,
    ISNULL(inv.OSVersion, '') AS OSVersion,
    ISNULL(inv.TotalMemoryGB, 0) AS TotalMemoryGB,
    ISNULL(inv.LogicalProcessorCount, 0) AS LogicalProcessorCount,
    ISNULL(inv.LastBootTime, NULL) AS LastBootTime,
    ISNULL(inv.LastInventoryAt, NULL) AS LastInventoryAt,
    ISNULL(latestPerf.CPUPercent, 0) AS CPUPercent,
    ISNULL(latestPerf.MemoryUsedPercent, 0) AS MemoryUsedPercent,
    ISNULL(latestPerf.DiskUsedPercent, 0) AS DiskUsedPercent,
    ISNULL(latestPerf.HealthScore, 0) AS VMHealthScore,
    ISNULL(latestPerf.HealthPosture, 'Unknown') AS VMHealthPosture,
    ISNULL(latestPerf.CaptureTime, NULL) AS VMLastSampleAt,
    ISNULL(sqlCounts.TotalSQLInstances, 0) AS TotalSQLInstances,
    ISNULL(sqlCounts.ActiveSQLInstances, 0) AS ActiveSQLInstances,
    ISNULL(sqlCounts.HealthySQLInstances, 0) AS HealthySQLInstances,
    ISNULL(sqlCounts.WarningSQLInstances, 0) AS WarningSQLInstances,
    ISNULL(sqlCounts.CriticalSQLInstances, 0) AS CriticalSQLInstances,
    ISNULL(sqlAlerts.TotalOpenAlerts, 0) AS TotalOpenAlerts,
    ISNULL(sqlAlerts.CriticalAlerts, 0) AS CriticalAlerts,
    ISNULL(sqlAlerts.WarningAlerts, 0) AS WarningAlerts,
    -- Overall posture: worst of VM and SQL
    CASE
        WHEN ISNULL(latestPerf.HealthPosture, '') = 'Critical'
            OR ISNULL(sqlCounts.CriticalSQLInstances, 0) > 0
            OR ISNULL(sqlAlerts.CriticalAlerts, 0) > 0
            THEN 'Critical'
        WHEN ISNULL(latestPerf.HealthPosture, '') = 'Warning'
            OR ISNULL(sqlCounts.WarningSQLInstances, 0) > 0
            OR ISNULL(sqlAlerts.WarningAlerts, 0) > 0
            THEN 'Warning'
        WHEN ISNULL(latestPerf.HealthPosture, '') = 'Healthy'
            OR (ISNULL(sqlCounts.ActiveSQLInstances, 0) > 0 AND ISNULL(sqlCounts.WarningSQLInstances, 0) = 0 AND ISNULL(sqlCounts.CriticalSQLInstances, 0) = 0)
            THEN 'Healthy'
        WHEN ISNULL(sqlCounts.ActiveSQLInstances, 0) = 0 AND t.IsVMHost = 1
            THEN 'NoSQL'
        ELSE ISNULL(latestPerf.HealthPosture, 'Unknown')
    END AS OverallPosture
FROM mon.WindowsTargets t
LEFT JOIN mon.WindowsInventory inv ON t.TargetID = inv.TargetID
LEFT JOIN (
    SELECT ps1.TargetID, ps1.CPUPercent, ps1.MemoryUsedPercent, ps1.DiskUsedPercent,
           ps1.HealthScore, ps1.HealthPosture, ps1.CaptureTime
    FROM mon.WindowsPerformanceSamples ps1
    INNER JOIN (
        SELECT TargetID, MAX(CaptureTime) AS MaxTime
        FROM mon.WindowsPerformanceSamples
        GROUP BY TargetID
    ) ps2 ON ps1.TargetID = ps2.TargetID AND ps1.CaptureTime = ps2.MaxTime
) latestPerf ON t.TargetID = latestPerf.TargetID
LEFT JOIN (
    SELECT
        mi.ParentVMID,
        COUNT(*) AS TotalSQLInstances,
        SUM(CASE WHEN mi.IsActive = 1 THEN 1 ELSE 0 END) AS ActiveSQLInstances,
        SUM(CASE WHEN mi.IsActive = 1 AND ISNULL(alert_summary.CriticalAlertCount, 0) = 0 AND ISNULL(alert_summary.WarningAlertCount, 0) = 0 THEN 1 ELSE 0 END) AS HealthySQLInstances,
        SUM(CASE WHEN mi.IsActive = 1 AND ISNULL(alert_summary.WarningAlertCount, 0) > 0 AND ISNULL(alert_summary.CriticalAlertCount, 0) = 0 THEN 1 ELSE 0 END) AS WarningSQLInstances,
        SUM(CASE WHEN mi.IsActive = 1 AND ISNULL(alert_summary.CriticalAlertCount, 0) > 0 THEN 1 ELSE 0 END) AS CriticalSQLInstances
    FROM mon.MonitoredInstances mi
    LEFT JOIN (
        SELECT InstanceID,
               SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
               SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
        FROM mon.AlertHistory
        WHERE IsAcknowledged = 0
        GROUP BY InstanceID
    ) alert_summary ON mi.InstanceID = alert_summary.InstanceID
    WHERE mi.ParentVMID IS NOT NULL
    GROUP BY mi.ParentVMID
) sqlCounts ON t.TargetID = sqlCounts.ParentVMID
LEFT JOIN (
    SELECT
        mi.ParentVMID,
        SUM(ISNULL(alert_summary.OpenAlertCount, 0)) AS TotalOpenAlerts,
        SUM(ISNULL(alert_summary.CriticalAlerts, 0)) AS CriticalAlerts,
        SUM(ISNULL(alert_summary.WarningAlerts, 0)) AS WarningAlerts
    FROM mon.MonitoredInstances mi
    LEFT JOIN (
        SELECT InstanceID,
               COUNT(*) AS OpenAlertCount,
               SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlerts,
               SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlerts
        FROM mon.AlertHistory
        WHERE IsAcknowledged = 0
        GROUP BY InstanceID
    ) alert_summary ON mi.InstanceID = alert_summary.InstanceID
    WHERE mi.ParentVMID IS NOT NULL AND mi.IsActive = 1
    GROUP BY mi.ParentVMID
) sqlAlerts ON t.TargetID = sqlAlerts.ParentVMID
WHERE t.IsEnabled = 1;
GO

-- ============================================================
-- 5. View: SQL Instances with VM context
-- ============================================================
CREATE OR ALTER VIEW mon.vw_SQLInstancesWithVM
AS
SELECT
    mi.InstanceID,
    mi.DisplayName,
    mi.ServerName,
    mi.InstanceName,
    mi.EnvironmentName,
    mi.IsActive,
    mi.CreatedOn,
    mi.ParentVMID,
    t.ComputerName AS VMComputerName,
    t.DisplayName AS VMDisplayName,
    t.IsVMHost,
    ISNULL(latestPerf.HealthPosture, 'Unknown') AS VMHealthPosture,
    ISNULL(latestPerf.HealthScore, 0) AS VMHealthScore,
    ISNULL(latestPerf.CPUPercent, 0) AS VMCPUPercent,
    ISNULL(latestPerf.MemoryUsedPercent, 0) AS VMMemoryUsedPercent,
    ISNULL(latestPerf.DiskUsedPercent, 0) AS VMDiskUsedPercent
FROM mon.MonitoredInstances mi
LEFT JOIN mon.WindowsTargets t ON mi.ParentVMID = t.TargetID
LEFT JOIN (
    SELECT ps1.TargetID, ps1.CPUPercent, ps1.MemoryUsedPercent, ps1.DiskUsedPercent,
           ps1.HealthScore, ps1.HealthPosture
    FROM mon.WindowsPerformanceSamples ps1
    INNER JOIN (
        SELECT TargetID, MAX(CaptureTime) AS MaxTime
        FROM mon.WindowsPerformanceSamples
        GROUP BY TargetID
    ) ps2 ON ps1.TargetID = ps2.TargetID AND ps1.CaptureTime = ps2.MaxTime
) latestPerf ON t.TargetID = latestPerf.TargetID;
GO

-- ============================================================
-- 6. View: Combined Overview (VMs + standalone SQL instances)
-- ============================================================
CREATE OR ALTER VIEW mon.vw_HierarchyOverview
AS
-- VMs with their SQL instances
SELECT
    'VM' AS NodeType,
    CAST(t.TargetID AS NVARCHAR(20)) AS NodeID,
    t.DisplayName AS NodeName,
    t.ComputerName AS ComputerName,
    '' AS InstanceName,
    t.EnvironmentName AS Environment,
    t.IsEnabled AS IsActive,
    NULL AS ParentID,
    t.DisplayName AS ParentName,
    ISNULL(latestPerf.HealthPosture, 'Unknown') AS HealthPosture,
    ISNULL(latestPerf.HealthScore, 0) AS HealthScore,
    ISNULL(latestPerf.CPUPercent, 0) AS CPUPercent,
    ISNULL(latestPerf.MemoryUsedPercent, 0) AS MemoryUsedPercent,
    ISNULL(latestPerf.DiskUsedPercent, 0) AS DiskUsedPercent,
    ISNULL(latestPerf.CaptureTime, NULL) AS LastSampleAt,
    ISNULL(sqlCounts.ActiveSQLInstances, 0) AS ChildCount,
    ISNULL(sqlAlerts.TotalOpenAlerts, 0) AS OpenAlertCount,
    ISNULL(sqlAlerts.CriticalAlerts, 0) AS CriticalAlertCount,
    ISNULL(sqlAlerts.WarningAlerts, 0) AS WarningAlertCount
FROM mon.WindowsTargets t
LEFT JOIN (
    SELECT ps1.TargetID, ps1.CPUPercent, ps1.MemoryUsedPercent, ps1.DiskUsedPercent,
           ps1.HealthScore, ps1.HealthPosture, ps1.CaptureTime
    FROM mon.WindowsPerformanceSamples ps1
    INNER JOIN (
        SELECT TargetID, MAX(CaptureTime) AS MaxTime
        FROM mon.WindowsPerformanceSamples
        GROUP BY TargetID
    ) ps2 ON ps1.TargetID = ps2.TargetID AND ps1.CaptureTime = ps2.MaxTime
) latestPerf ON t.TargetID = latestPerf.TargetID
LEFT JOIN (
    SELECT mi.ParentVMID,
           SUM(CASE WHEN mi.IsActive = 1 THEN 1 ELSE 0 END) AS ActiveSQLInstances
    FROM mon.MonitoredInstances mi
    WHERE mi.ParentVMID IS NOT NULL
    GROUP BY mi.ParentVMID
) sqlCounts ON t.TargetID = sqlCounts.ParentVMID
LEFT JOIN (
    SELECT mi.ParentVMID,
           SUM(ISNULL(a.OpenAlertCount, 0)) AS TotalOpenAlerts,
           SUM(ISNULL(a.CriticalAlerts, 0)) AS CriticalAlerts,
           SUM(ISNULL(a.WarningAlerts, 0)) AS WarningAlerts
    FROM mon.MonitoredInstances mi
    LEFT JOIN (
        SELECT InstanceID,
               COUNT(*) AS OpenAlertCount,
               SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlerts,
               SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlerts
        FROM mon.AlertHistory
        WHERE IsAcknowledged = 0
        GROUP BY InstanceID
    ) a ON mi.InstanceID = a.InstanceID
    WHERE mi.ParentVMID IS NOT NULL AND mi.IsActive = 1
    GROUP BY mi.ParentVMID
) sqlAlerts ON t.TargetID = sqlAlerts.ParentVMID
WHERE t.IsEnabled = 1

UNION ALL

-- Standalone SQL instances (no parent VM)
SELECT
    'SQL' AS NodeType,
    CAST(mi.InstanceID AS NVARCHAR(20)) AS NodeID,
    mi.DisplayName AS NodeName,
    mi.ServerName AS ComputerName,
    mi.InstanceName AS InstanceName,
    mi.EnvironmentName AS Environment,
    mi.IsActive,
    NULL AS ParentID,
    NULL AS ParentName,
    CASE
        WHEN ISNULL(alerts.CriticalAlertCount, 0) > 0 THEN 'Critical'
        WHEN ISNULL(alerts.WarningAlertCount, 0) > 0 THEN 'Warning'
        ELSE 'Healthy'
    END AS HealthPosture,
    CASE
        WHEN ISNULL(alerts.CriticalAlertCount, 0) > 0 THEN 30
        WHEN ISNULL(alerts.WarningAlertCount, 0) > 0 THEN 60
        ELSE 95
    END AS HealthScore,
    ISNULL(cpu.SqlCPUPercent, 0) AS CPUPercent,
    CASE WHEN ISNULL(mem.TotalPhysicalMB, 0) > 0
         THEN CAST((1.0 - ISNULL(mem.AvailablePhysicalMB, 0) * 1.0 / mem.TotalPhysicalMB) * 100 AS DECIMAL(6,2))
         ELSE 0
    END AS MemoryUsedPercent,
    0 AS DiskUsedPercent,
    ISNULL(cpu.CaptureTime, NULL) AS LastSampleAt,
    0 AS ChildCount,
    ISNULL(alerts.OpenAlertCount, 0) AS OpenAlertCount,
    ISNULL(alerts.CriticalAlertCount, 0) AS CriticalAlertCount,
    ISNULL(alerts.WarningAlertCount, 0) AS WarningAlertCount
FROM mon.MonitoredInstances mi
LEFT JOIN (
    SELECT c1.InstanceID, c1.SqlCPUPercent, c1.CaptureTime
    FROM mon.CPUHistory c1
    INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime
        FROM mon.CPUHistory
        GROUP BY InstanceID
    ) c2 ON c1.InstanceID = c2.InstanceID AND c1.CaptureTime = c2.MaxTime
) cpu ON mi.InstanceID = cpu.InstanceID
LEFT JOIN (
    SELECT m1.InstanceID, m1.TotalPhysicalMB, m1.AvailablePhysicalMB
    FROM mon.MemoryHistory m1
    INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime
        FROM mon.MemoryHistory
        GROUP BY InstanceID
    ) m2 ON m1.InstanceID = m2.InstanceID AND m1.CaptureTime = m2.MaxTime
) mem ON mi.InstanceID = mem.InstanceID
LEFT JOIN (
    SELECT InstanceID,
           COUNT(*) AS OpenAlertCount,
           SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
           SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
    FROM mon.AlertHistory
    WHERE IsAcknowledged = 0
    GROUP BY InstanceID
) alerts ON mi.InstanceID = alerts.InstanceID
WHERE mi.IsActive = 1 AND mi.ParentVMID IS NULL;
GO

-- ============================================================
-- 7. Stored Procedure: Get VM tree with SQL children
-- ============================================================
CREATE OR ALTER PROCEDURE mon.usp_GetVMTree
    @VMID INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- Return VMs
    SELECT
        t.TargetID AS VMID,
        t.ComputerName,
        t.DisplayName,
        t.EnvironmentName,
        t.IsEnabled,
        ISNULL(latestPerf.HealthPosture, 'Unknown') AS HealthPosture,
        ISNULL(latestPerf.HealthScore, 0) AS HealthScore,
        ISNULL(latestPerf.CPUPercent, 0) AS CPUPercent,
        ISNULL(latestPerf.MemoryUsedPercent, 0) AS MemoryUsedPercent,
        ISNULL(latestPerf.DiskUsedPercent, 0) AS DiskUsedPercent,
        ISNULL(latestPerf.CaptureTime, NULL) AS LastSampleAt
    FROM mon.WindowsTargets t
    LEFT JOIN (
        SELECT ps1.TargetID, ps1.CPUPercent, ps1.MemoryUsedPercent, ps1.DiskUsedPercent,
               ps1.HealthScore, ps1.HealthPosture, ps1.CaptureTime
        FROM mon.WindowsPerformanceSamples ps1
        INNER JOIN (
            SELECT TargetID, MAX(CaptureTime) AS MaxTime
            FROM mon.WindowsPerformanceSamples
            GROUP BY TargetID
        ) ps2 ON ps1.TargetID = ps2.TargetID AND ps1.CaptureTime = ps2.MaxTime
    ) latestPerf ON t.TargetID = latestPerf.TargetID
    WHERE t.IsEnabled = 1
      AND (@VMID IS NULL OR t.TargetID = @VMID)
    ORDER BY t.DisplayName;

    -- Return SQL instances for the VM(s)
    SELECT
        mi.InstanceID,
        mi.DisplayName,
        mi.ServerName,
        mi.InstanceName,
        mi.EnvironmentName,
        mi.IsActive,
        mi.ParentVMID,
        CASE
            WHEN ISNULL(alerts.CriticalAlertCount, 0) > 0 THEN 'Critical'
            WHEN ISNULL(alerts.WarningAlertCount, 0) > 0 THEN 'Warning'
            ELSE 'Healthy'
        END AS HealthPosture,
        ISNULL(cpu.SqlCPUPercent, 0) AS CPUPercent,
        ISNULL(mem.AvailablePhysicalMB, 0) AS AvailableMemoryMB,
        ISNULL(mem.PLESeconds, 0) AS PLESeconds,
        ISNULL(alerts.OpenAlertCount, 0) AS OpenAlertCount,
        ISNULL(alerts.CriticalAlertCount, 0) AS CriticalAlertCount,
        ISNULL(alerts.WarningAlertCount, 0) AS WarningAlertCount
    FROM mon.MonitoredInstances mi
    LEFT JOIN (
        SELECT c1.InstanceID, c1.SqlCPUPercent
        FROM mon.CPUHistory c1
        INNER JOIN (
            SELECT InstanceID, MAX(CaptureTime) AS MaxTime
            FROM mon.CPUHistory
            GROUP BY InstanceID
        ) c2 ON c1.InstanceID = c2.InstanceID AND c1.CaptureTime = c2.MaxTime
    ) cpu ON mi.InstanceID = cpu.InstanceID
    LEFT JOIN (
        SELECT m1.InstanceID, m1.AvailablePhysicalMB, m1.PLESeconds
        FROM mon.MemoryHistory m1
        INNER JOIN (
            SELECT InstanceID, MAX(CaptureTime) AS MaxTime
            FROM mon.MemoryHistory
            GROUP BY InstanceID
        ) m2 ON m1.InstanceID = m2.InstanceID AND m1.CaptureTime = m2.MaxTime
    ) mem ON mi.InstanceID = mem.InstanceID
    LEFT JOIN (
        SELECT InstanceID,
               COUNT(*) AS OpenAlertCount,
               SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
               SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
        FROM mon.AlertHistory
        WHERE IsAcknowledged = 0
        GROUP BY InstanceID
    ) alerts ON mi.InstanceID = alerts.InstanceID
    WHERE mi.IsActive = 1
      AND mi.ParentVMID IN (
          SELECT TargetID FROM mon.WindowsTargets
          WHERE IsEnabled = 1 AND (@VMID IS NULL OR TargetID = @VMID)
      )
    ORDER BY mi.DisplayName;

    -- Return standalone SQL instances (no parent VM)
    SELECT
        mi.InstanceID,
        mi.DisplayName,
        mi.ServerName,
        mi.InstanceName,
        mi.EnvironmentName,
        mi.IsActive,
        mi.ParentVMID,
        CASE
            WHEN ISNULL(alerts.CriticalAlertCount, 0) > 0 THEN 'Critical'
            WHEN ISNULL(alerts.WarningAlertCount, 0) > 0 THEN 'Warning'
            ELSE 'Healthy'
        END AS HealthPosture,
        ISNULL(cpu.SqlCPUPercent, 0) AS CPUPercent,
        ISNULL(mem.AvailablePhysicalMB, 0) AS AvailableMemoryMB,
        ISNULL(mem.PLESeconds, 0) AS PLESeconds,
        ISNULL(alerts.OpenAlertCount, 0) AS OpenAlertCount,
        ISNULL(alerts.CriticalAlertCount, 0) AS CriticalAlertCount,
        ISNULL(alerts.WarningAlertCount, 0) AS WarningAlertCount
    FROM mon.MonitoredInstances mi
    LEFT JOIN (
        SELECT c1.InstanceID, c1.SqlCPUPercent
        FROM mon.CPUHistory c1
        INNER JOIN (
            SELECT InstanceID, MAX(CaptureTime) AS MaxTime
            FROM mon.CPUHistory
            GROUP BY InstanceID
        ) c2 ON c1.InstanceID = c2.InstanceID AND c1.CaptureTime = c2.MaxTime
    ) cpu ON mi.InstanceID = cpu.InstanceID
    LEFT JOIN (
        SELECT m1.InstanceID, m1.AvailablePhysicalMB, m1.PLESeconds
        FROM mon.MemoryHistory m1
        INNER JOIN (
            SELECT InstanceID, MAX(CaptureTime) AS MaxTime
            FROM mon.MemoryHistory
            GROUP BY InstanceID
        ) m2 ON m1.InstanceID = m2.InstanceID AND m1.CaptureTime = m2.MaxTime
    ) mem ON mi.InstanceID = mem.InstanceID
    LEFT JOIN (
        SELECT InstanceID,
               COUNT(*) AS OpenAlertCount,
               SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
               SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
        FROM mon.AlertHistory
        WHERE IsAcknowledged = 0
        GROUP BY InstanceID
    ) alerts ON mi.InstanceID = alerts.InstanceID
    WHERE mi.IsActive = 1 AND mi.ParentVMID IS NULL
    ORDER BY mi.DisplayName;
END;
GO

-- ============================================================
-- 8. Stored Procedure: Link SQL instance to VM
-- ============================================================
CREATE OR ALTER PROCEDURE mon.usp_LinkSQLInstanceToVM
    @InstanceID INT,
    @VMID INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE mon.MonitoredInstances
    SET ParentVMID = @VMID
    WHERE InstanceID = @InstanceID;
END;
GO

-- ============================================================
-- 9. Stored Procedure: Auto-link SQL instances to VMs by ServerName
-- ============================================================
CREATE OR ALTER PROCEDURE mon.usp_AutoLinkSQLInstancesToVMs
AS
BEGIN
    SET NOCOUNT ON;

    -- Link SQL instances to VMs where ServerName matches ComputerName
    UPDATE mi
    SET mi.ParentVMID = t.TargetID
    FROM mon.MonitoredInstances mi
    INNER JOIN mon.WindowsTargets t
        ON mi.ServerName = t.ComputerName
    WHERE mi.ParentVMID IS NULL
      AND t.IsEnabled = 1;

    -- Return count of linked instances
    SELECT @@ROWCOUNT AS LinkedCount;
END;
GO

PRINT 'Phase 17: VM → SQL Server Hierarchy schema updates completed.';
GO
