-- SQL migration to update Users and SOPs related tables
USE [DBA_SQLMonitor];
GO

PRINT 'Starting migration to update Users and SOPs related tables...';

--------------------------------------------------------------------------------
-- 1. Update mon.DashboardUsers table
--------------------------------------------------------------------------------
IF OBJECT_ID('mon.DashboardUsers', 'U') IS NOT NULL
BEGIN
    PRINT 'Updating mon.DashboardUsers table...';

    -- Add EmailAddress if it doesn't exist
    IF COL_LENGTH('mon.DashboardUsers', 'EmailAddress') IS NULL
    BEGIN
        ALTER TABLE mon.DashboardUsers ADD EmailAddress NVARCHAR(256) NULL;
        PRINT 'Added EmailAddress column to mon.DashboardUsers.';
    END

    -- Add PhoneNumber if it doesn't exist
    IF COL_LENGTH('mon.DashboardUsers', 'PhoneNumber') IS NULL
    BEGIN
        ALTER TABLE mon.DashboardUsers ADD PhoneNumber NVARCHAR(20) NULL;
        PRINT 'Added PhoneNumber column to mon.DashboardUsers.';
    END

    -- Add Department if it doesn't exist
    IF COL_LENGTH('mon.DashboardUsers', 'Department') IS NULL
    BEGIN
        ALTER TABLE mon.DashboardUsers ADD Department NVARCHAR(100) NULL;
        PRINT 'Added Department column to mon.DashboardUsers.';
    END
END
ELSE
BEGIN
    PRINT 'WARNING: mon.DashboardUsers table not found.';
END
GO

--------------------------------------------------------------------------------
-- 2. Create or Update SOPs/Issues related tables
--------------------------------------------------------------------------------
-- Based on the Web/SOPs.html structure, we should have a table to store these.
-- Since no existing table was found, we will create mon.SOPs.

IF OBJECT_ID('mon.SOPs', 'U') IS NULL
BEGIN
    PRINT 'Creating mon.SOPs table...';
    CREATE TABLE mon.SOPs (
        SopID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SOPs PRIMARY KEY,
        IssueID INT NULL,
        Title NVARCHAR(200) NOT NULL,
        Category NVARCHAR(100) NULL,
        Severity NVARCHAR(20) NULL,
        Description NVARCHAR(MAX) NULL,
        SOPText NVARCHAR(MAX) NULL,
        Frequency NVARCHAR(50) NULL,
        Owner NVARCHAR(100) NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_SOPs_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_SOPs_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastUpdatedBy NVARCHAR(128) NULL
    );
    PRINT 'Created mon.SOPs table.';
END
ELSE
BEGIN
    PRINT 'mon.SOPs table already exists.';
    -- Add columns if they are missing (for future proofing)
    IF COL_LENGTH('mon.SOPs', 'Frequency') IS NULL ALTER TABLE mon.SOPs ADD Frequency NVARCHAR(50) NULL;
    IF COL_LENGTH('mon.SOPs', 'Owner') IS NULL ALTER TABLE mon.SOPs ADD Owner NVARCHAR(100) NULL;
END
GO

--------------------------------------------------------------------------------
-- 3. Seed SOPs table from the HTML content
--------------------------------------------------------------------------------
PRINT 'Seeding mon.SOPs table...';

-- Example seeding based on SOPs.html
-- Note: In a real scenario, we might parse the HTML, but here we insert the known rows.

MERGE INTO mon.SOPs AS target
USING (SELECT * FROM (VALUES
    (1, 'High CPU Utilization (>90%)', 'Performance', 'Critical', 'SQL Server CPU usage is consistently high.', '1. Identify top CPU-consuming queries... 2. Inspect execution plans... 3. Check missing index DMVs...', 'High', 'John Doe'),
    (2, 'Low Page Life Expectancy', 'Memory', 'Critical', 'Pages are being flushed from memory too quickly.', '1. Monitor PLE... 2. Query memory grants... 3. Verify max server memory...', 'Medium', 'Jane Smith'),
    (3, 'Transaction Log Full', 'Storage', 'High', 'Transaction log has reached capacity.', '1. Perform log backup... 2. Ensure regular backups... 3. Identify long-running transactions...', 'Medium', 'DBA Team'),
    (4, 'Always On AG Synchronization Issues', 'Availability', 'Critical', 'Availability group databases are not synchronizing.', '1. Check replica health... 2. Review error logs... 3. Validate connectivity...', 'Low', 'Ops Lead'),
    (5, 'Excessive Blocking', 'Performance', 'High', 'Queries are blocked for extended periods.', '1. Identify blocker... 2. Capture statement/plan... 3. Optimize query...', 'High', 'Support'),
    (6, 'Failed Backup Jobs', 'Backup', 'Critical', 'Database backup jobs are failing.', '1. Inspect job history... 2. Verify permissions... 3. Check disk space...', 'Medium', 'Backup Admin'),
    (7, 'Failed Login Attempts', 'Security', 'High', 'Repeated authentication failures were detected.', '1. Search error logs... 2. Validate connection strings... 3. Check login policy...', 'High', 'Security Team'),
    (8, 'High Disk I/O Latency', 'Storage', 'Medium', 'Disk operations are taking too long.', '1. Gather I/O stats... 2. Confirm storage tier... 3. Place TempDB on fast storage...', 'Medium', 'Infra Team')
) AS s(IssueID, Title, Category, Severity, Description, SOPText, Frequency, Owner)) AS source
ON target.IssueID = source.IssueID
WHEN MATCHED THEN
    UPDATE SET 
        Title = source.Title,
        Category = source.Category,
        Severity = source.Severity,
        Description = source.Description,
        SOPText = source.SOPText,
        Frequency = source.Frequency,
        Owner = source.Owner,
        UpdatedAt = SYSDATETIME()
WHEN NOT MATCHED THEN
    INSERT (IssueID, Title, Category, Severity, Description, SOPText, Frequency, Owner)
    VALUES (source.IssueID, source.Title, source.Category, source.Severity, source.Description, source.SOPText, source.Frequency, source.Owner);

PRINT 'Seeding completed.';
GO

PRINT 'Migration completed successfully.';
