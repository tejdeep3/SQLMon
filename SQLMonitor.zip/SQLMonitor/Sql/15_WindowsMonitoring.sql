SET NOCOUNT ON;

IF SCHEMA_ID(N'mon') IS NULL
    EXEC(N'CREATE SCHEMA mon');

IF OBJECT_ID('mon.WindowsTargets', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsTargets
    (
        TargetID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsTargets PRIMARY KEY,
        ComputerName NVARCHAR(256) NOT NULL,
        DisplayName NVARCHAR(256) NOT NULL,
        EnvironmentName NVARCHAR(100) NULL,
        ApplicationName NVARCHAR(128) NULL,
        SiteName NVARCHAR(128) NULL,
        IsEnabled BIT NOT NULL CONSTRAINT DF_WindowsTargets_IsEnabled DEFAULT (1),
        CollectionMode NVARCHAR(30) NOT NULL CONSTRAINT DF_WindowsTargets_CollectionMode DEFAULT (N'Lightweight'),
        CollectionIntervalMinutes INT NOT NULL CONSTRAINT DF_WindowsTargets_Interval DEFAULT (5),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsTargets_CreatedAt DEFAULT (SYSDATETIME()),
        LastUpdatedAt DATETIME2(0) NULL,
        CONSTRAINT UQ_WindowsTargets_ComputerName UNIQUE (ComputerName)
    );
END;

IF OBJECT_ID('mon.WindowsInventory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsInventory
    (
        TargetID INT NOT NULL CONSTRAINT PK_WindowsInventory PRIMARY KEY,
        ComputerName NVARCHAR(256) NOT NULL,
        DomainName NVARCHAR(256) NULL,
        OSName NVARCHAR(256) NULL,
        OSVersion NVARCHAR(80) NULL,
        OSBuild NVARCHAR(80) NULL,
        Manufacturer NVARCHAR(256) NULL,
        Model NVARCHAR(256) NULL,
        ProcessorName NVARCHAR(256) NULL,
        LogicalProcessorCount INT NULL,
        TotalMemoryGB DECIMAL(18,2) NULL,
        LastBootTime DATETIME2(0) NULL,
        LastInventoryAt DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsInventory_LastInventoryAt DEFAULT (SYSDATETIME()),
        CONSTRAINT FK_WindowsInventory_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF OBJECT_ID('mon.WindowsPerformanceSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsPerformanceSamples
    (
        SampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsPerformanceSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsPerformanceSamples_CaptureTime DEFAULT (SYSDATETIME()),
        CPUPercent DECIMAL(6,2) NULL,
        MemoryUsedPercent DECIMAL(6,2) NULL,
        MemoryAvailableGB DECIMAL(18,2) NULL,
        DiskUsedPercent DECIMAL(6,2) NULL,
        DiskFreeGB DECIMAL(18,2) NULL,
        NetworkBytesPerSec BIGINT NULL,
        ProcessCount INT NULL,
        ServiceStoppedCount INT NULL,
        HealthScore INT NULL,
        HealthPosture NVARCHAR(30) NULL,
        CONSTRAINT FK_WindowsPerformanceSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsPerformanceSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsPerformanceSamples'))
    CREATE INDEX IX_WindowsPerformanceSamples_Target_Time ON mon.WindowsPerformanceSamples(TargetID, CaptureTime DESC);

IF OBJECT_ID('mon.WindowsDiskSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsDiskSamples
    (
        DiskSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsDiskSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsDiskSamples_CaptureTime DEFAULT (SYSDATETIME()),
        DriveLetter NVARCHAR(20) NOT NULL,
        VolumeName NVARCHAR(256) NULL,
        TotalGB DECIMAL(18,2) NULL,
        FreeGB DECIMAL(18,2) NULL,
        UsedPercent DECIMAL(6,2) NULL,
        CONSTRAINT FK_WindowsDiskSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsDiskSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsDiskSamples'))
    CREATE INDEX IX_WindowsDiskSamples_Target_Time ON mon.WindowsDiskSamples(TargetID, CaptureTime DESC);

IF OBJECT_ID('mon.WindowsServiceSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsServiceSamples
    (
        ServiceSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsServiceSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsServiceSamples_CaptureTime DEFAULT (SYSDATETIME()),
        ServiceName NVARCHAR(256) NOT NULL,
        DisplayName NVARCHAR(512) NULL,
        StartMode NVARCHAR(40) NULL,
        StateName NVARCHAR(40) NULL,
        IsCritical BIT NOT NULL CONSTRAINT DF_WindowsServiceSamples_IsCritical DEFAULT (0),
        CONSTRAINT FK_WindowsServiceSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsServiceSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsServiceSamples'))
    CREATE INDEX IX_WindowsServiceSamples_Target_Time ON mon.WindowsServiceSamples(TargetID, CaptureTime DESC);

IF OBJECT_ID('mon.WindowsHotFixSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsHotFixSamples
    (
        HotFixSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsHotFixSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsHotFixSamples_CaptureTime DEFAULT (SYSDATETIME()),
        HotFixID NVARCHAR(80) NULL,
        InstalledOn DATETIME2(0) NULL,
        Description NVARCHAR(512) NULL,
        CONSTRAINT FK_WindowsHotFixSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsHotFixSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsHotFixSamples'))
    CREATE INDEX IX_WindowsHotFixSamples_Target_Time ON mon.WindowsHotFixSamples(TargetID, CaptureTime DESC);

IF OBJECT_ID('mon.WindowsProcessSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsProcessSamples
    (
        ProcessSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsProcessSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsProcessSamples_CaptureTime DEFAULT (SYSDATETIME()),
        RankingType NVARCHAR(20) NOT NULL,
        ProcessName NVARCHAR(256) NULL,
        ProcessID INT NULL,
        CPUPercent DECIMAL(9,2) NULL,
        WorkingSetMB DECIMAL(18,2) NULL,
        VirtualMemoryMB DECIMAL(18,2) NULL,
        CONSTRAINT FK_WindowsProcessSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsProcessSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsProcessSamples'))
    CREATE INDEX IX_WindowsProcessSamples_Target_Time ON mon.WindowsProcessSamples(TargetID, CaptureTime DESC, RankingType);

IF OBJECT_ID('mon.WindowsEventSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsEventSamples
    (
        EventSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsEventSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsEventSamples_CaptureTime DEFAULT (SYSDATETIME()),
        EventTime DATETIME2(0) NULL,
        LogName NVARCHAR(80) NULL,
        EventID INT NULL,
        LevelName NVARCHAR(40) NULL,
        ProviderName NVARCHAR(256) NULL,
        Message NVARCHAR(1000) NULL,
        CONSTRAINT FK_WindowsEventSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsEventSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsEventSamples'))
    CREATE INDEX IX_WindowsEventSamples_Target_Time ON mon.WindowsEventSamples(TargetID, CaptureTime DESC, EventTime DESC);

IF OBJECT_ID('mon.WindowsNetworkAdapterSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsNetworkAdapterSamples
    (
        NetworkAdapterSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsNetworkAdapterSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsNetworkAdapterSamples_CaptureTime DEFAULT (SYSDATETIME()),
        AdapterName NVARCHAR(256) NULL,
        InterfaceDescription NVARCHAR(512) NULL,
        StatusName NVARCHAR(80) NULL,
        LinkSpeed NVARCHAR(80) NULL,
        MacAddress NVARCHAR(80) NULL,
        CONSTRAINT FK_WindowsNetworkAdapterSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsNetworkAdapterSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsNetworkAdapterSamples'))
    CREATE INDEX IX_WindowsNetworkAdapterSamples_Target_Time ON mon.WindowsNetworkAdapterSamples(TargetID, CaptureTime DESC);

IF OBJECT_ID('mon.WindowsPerfCounterSamples', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsPerfCounterSamples
    (
        PerfCounterSampleID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsPerfCounterSamples PRIMARY KEY,
        TargetID INT NOT NULL,
        CaptureTime DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsPerfCounterSamples_CaptureTime DEFAULT (SYSDATETIME()),
        CounterPath NVARCHAR(512) NOT NULL,
        CookedValue FLOAT NULL,
        CounterTime DATETIME2(0) NULL,
        CONSTRAINT FK_WindowsPerfCounterSamples_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID)
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_WindowsPerfCounterSamples_Target_Time' AND object_id = OBJECT_ID('mon.WindowsPerfCounterSamples'))
    CREATE INDEX IX_WindowsPerfCounterSamples_Target_Time ON mon.WindowsPerfCounterSamples(TargetID, CaptureTime DESC);

EXEC(N'DROP VIEW IF EXISTS mon.vw_WindowsLatestHealth;');
EXEC(N'CREATE VIEW mon.vw_WindowsLatestHealth AS
WITH latest AS (
    SELECT ps.*, ROW_NUMBER() OVER (PARTITION BY ps.TargetID ORDER BY ps.CaptureTime DESC, ps.SampleID DESC) AS rn
    FROM mon.WindowsPerformanceSamples ps
)
SELECT
    t.TargetID,
    t.ComputerName,
    t.DisplayName,
    t.EnvironmentName,
    t.ApplicationName,
    t.SiteName,
    t.IsEnabled,
    inv.OSName,
    inv.OSVersion,
    inv.TotalMemoryGB,
    inv.LastBootTime,
    latest.CaptureTime,
    latest.CPUPercent,
    latest.MemoryUsedPercent,
    latest.MemoryAvailableGB,
    latest.DiskUsedPercent,
    latest.DiskFreeGB,
    latest.ProcessCount,
    latest.ServiceStoppedCount,
    latest.HealthScore,
    latest.HealthPosture,
    DATEDIFF(MINUTE, latest.CaptureTime, SYSDATETIME()) AS MinutesSinceLastSample
FROM mon.WindowsTargets t
LEFT JOIN mon.WindowsInventory inv ON inv.TargetID = t.TargetID
LEFT JOIN latest ON latest.TargetID = t.TargetID AND latest.rn = 1;');
-- GO removed for compatibility

EXEC(N'DROP PROCEDURE IF EXISTS mon.usp_UpsertWindowsTarget;');
EXEC(N'CREATE PROCEDURE mon.usp_UpsertWindowsTarget
    @ComputerName NVARCHAR(256),
    @DisplayName NVARCHAR(256) = NULL,
    @EnvironmentName NVARCHAR(100) = NULL,
    @ApplicationName NVARCHAR(128) = NULL,
    @SiteName NVARCHAR(128) = NULL,
    @TargetID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @DisplayName = COALESCE(NULLIF(@DisplayName, N''''), @ComputerName);
    MERGE mon.WindowsTargets AS target
    USING (SELECT @ComputerName AS ComputerName) AS source
        ON target.ComputerName = source.ComputerName
    WHEN MATCHED THEN
        UPDATE SET
            DisplayName = @DisplayName,
            EnvironmentName = COALESCE(@EnvironmentName, target.EnvironmentName),
            ApplicationName = COALESCE(@ApplicationName, target.ApplicationName),
            SiteName = COALESCE(@SiteName, target.SiteName),
            LastUpdatedAt = SYSDATETIME()
    WHEN NOT MATCHED THEN
        INSERT (ComputerName, DisplayName, EnvironmentName, ApplicationName, SiteName)
        VALUES (@ComputerName, @DisplayName, @EnvironmentName, @ApplicationName, @SiteName);
    SELECT @TargetID = TargetID FROM mon.WindowsTargets WHERE ComputerName = @ComputerName;
END;');
GO

DECLARE @machineName NVARCHAR(256);
SET @machineName = CONVERT(NVARCHAR(256), SERVERPROPERTY('MachineName'));

IF NOT EXISTS (SELECT 1 FROM mon.WindowsTargets WHERE ComputerName = @machineName)
BEGIN
    DECLARE @localTargetId INT;
    EXEC mon.usp_UpsertWindowsTarget
        @ComputerName = @machineName,
        @DisplayName = @machineName,
        @EnvironmentName = N'Production',
        @ApplicationName = N'Infrastructure',
        @SiteName = NULL,
        @TargetID = @localTargetId OUTPUT;
END;

PRINT 'Windows/VM monitoring schema is ready.';
