SET NOCOUNT ON;

IF SCHEMA_ID(N'mon') IS NULL
    EXEC(N'CREATE SCHEMA mon');

IF OBJECT_ID('mon.AlertHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL
        ALTER TABLE mon.AlertHistory ADD RepeatCount INT NOT NULL CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
    IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL
        ALTER TABLE mon.AlertHistory ADD FirstAlertTime DATETIME2 NULL;
    IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL
        ALTER TABLE mon.AlertHistory ADD LastRepeatedAt DATETIME2 NULL;
    IF COL_LENGTH('mon.AlertHistory', 'IsTicketCreated') IS NULL
        ALTER TABLE mon.AlertHistory ADD IsTicketCreated BIT NOT NULL CONSTRAINT DF_AlertHistory_IsTicketCreated DEFAULT (0);

    UPDATE mon.AlertHistory
    SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
        LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
        RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
    WHERE FirstAlertTime IS NULL
       OR LastRepeatedAt IS NULL
       OR ISNULL(RepeatCount, 0) < 1;
END;

IF OBJECT_ID('mon.Tickets', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.Tickets', 'TicketType') IS NULL ALTER TABLE mon.Tickets ADD TicketType NVARCHAR(50) NOT NULL CONSTRAINT DF_Tickets_TicketType DEFAULT (N'SQL Server');
    IF COL_LENGTH('mon.Tickets', 'Category') IS NULL ALTER TABLE mon.Tickets ADD Category NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'Subcategory') IS NULL ALTER TABLE mon.Tickets ADD Subcategory NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'Impact') IS NULL ALTER TABLE mon.Tickets ADD Impact NVARCHAR(40) NULL;
    IF COL_LENGTH('mon.Tickets', 'Urgency') IS NULL ALTER TABLE mon.Tickets ADD Urgency NVARCHAR(40) NULL;
    IF COL_LENGTH('mon.Tickets', 'AssignmentGroup') IS NULL ALTER TABLE mon.Tickets ADD AssignmentGroup NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'ContactType') IS NULL ALTER TABLE mon.Tickets ADD ContactType NVARCHAR(60) NULL;
    IF COL_LENGTH('mon.Tickets', 'ExternalReference') IS NULL ALTER TABLE mon.Tickets ADD ExternalReference NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'SLADueDate') IS NULL ALTER TABLE mon.Tickets ADD SLADueDate DATETIME2(7) NULL;
    IF COL_LENGTH('mon.Tickets', 'WorkNotes') IS NULL ALTER TABLE mon.Tickets ADD WorkNotes NVARCHAR(MAX) NULL;
    IF COL_LENGTH('mon.Tickets', 'EscalationLevelID') IS NULL ALTER TABLE mon.Tickets ADD EscalationLevelID INT NULL;

    UPDATE t
    SET TicketType = N'VM'
    FROM mon.Tickets t
    WHERE t.TicketType = N'SQL Server'
      AND (t.Category = N'VM Monitoring' OR EXISTS (SELECT 1 FROM mon.AlertHistory ah WHERE ah.AlertID = t.AlertID AND ah.ModuleName LIKE N'VM:%'));
END;
GO

IF OBJECT_ID('mon.WindowsTargetInstanceMap', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsTargetInstanceMap
    (
        TargetID INT NOT NULL CONSTRAINT PK_WindowsTargetInstanceMap PRIMARY KEY,
        InstanceID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_WindowsTargetInstanceMap_CreatedAt DEFAULT (SYSDATETIME()),
        LastUpdatedAt DATETIME2(0) NULL,
        CONSTRAINT FK_WindowsTargetInstanceMap_Target FOREIGN KEY (TargetID) REFERENCES mon.WindowsTargets(TargetID),
        CONSTRAINT FK_WindowsTargetInstanceMap_Instance FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID)
    );
END;

IF OBJECT_ID('mon.WindowsAlertRules', 'U') IS NULL
BEGIN
    CREATE TABLE mon.WindowsAlertRules
    (
        RuleID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_WindowsAlertRules PRIMARY KEY,
        RuleKey NVARCHAR(80) NOT NULL CONSTRAINT UQ_WindowsAlertRules_RuleKey UNIQUE,
        Category NVARCHAR(80) NOT NULL,
        Subcategory NVARCHAR(80) NOT NULL,
        ModuleName NVARCHAR(100) NOT NULL,
        MetricName NVARCHAR(100) NOT NULL,
        WarningThreshold DECIMAL(18,2) NULL,
        CriticalThreshold DECIMAL(18,2) NULL,
        ComparisonOperator NVARCHAR(10) NOT NULL CONSTRAINT DF_WindowsAlertRules_Comparison DEFAULT (N'>='),
        WarningSeverity NVARCHAR(20) NOT NULL CONSTRAINT DF_WindowsAlertRules_WarningSeverity DEFAULT (N'High'),
        CriticalSeverity NVARCHAR(20) NOT NULL CONSTRAINT DF_WindowsAlertRules_CriticalSeverity DEFAULT (N'Critical'),
        WarningSlaMinutes INT NOT NULL CONSTRAINT DF_WindowsAlertRules_WarningSla DEFAULT (240),
        CriticalSlaMinutes INT NOT NULL CONSTRAINT DF_WindowsAlertRules_CriticalSla DEFAULT (60),
        AssignmentGroup NVARCHAR(128) NOT NULL CONSTRAINT DF_WindowsAlertRules_Assignment DEFAULT (N'Infrastructure Operations'),
        IsAutoTicketEnabled BIT NOT NULL CONSTRAINT DF_WindowsAlertRules_AutoTicket DEFAULT (1),
        IsActive BIT NOT NULL CONSTRAINT DF_WindowsAlertRules_IsActive DEFAULT (1)
    );
END;

MERGE mon.WindowsAlertRules AS target
USING (VALUES
    (N'VM_CPU_HIGH', N'Performance', N'CPU', N'VM:CPU', N'CPUPercent', 75.00, 90.00, N'>=', N'High', N'Critical', 240, 60),
    (N'VM_MEMORY_HIGH', N'Performance', N'Memory', N'VM:Memory', N'MemoryUsedPercent', 80.00, 90.00, N'>=', N'High', N'Critical', 240, 60),
    (N'VM_DISK_HIGH', N'Capacity', N'Disk', N'VM:Disk', N'DiskUsedPercent', 85.00, 95.00, N'>=', N'High', N'Critical', 480, 120),
    (N'VM_HEALTH_LOW', N'Availability', N'Health Score', N'VM:Health', N'HealthScore', 85.00, 60.00, N'<=', N'High', N'Critical', 240, 60),
    (N'VM_STOPPED_SERVICE', N'Availability', N'Windows Service', N'VM:Service', N'ServiceStoppedCount', 1.00, 3.00, N'>=', N'High', N'Critical', 240, 60),
    (N'VM_STALE_SAMPLE', N'Collection', N'Telemetry Freshness', N'VM:Collection', N'MinutesSinceLastSample', 15.00, 30.00, N'>=', N'Medium', N'High', 480, 240),
    (N'VM_EVENT_CRITICAL', N'Event Log', N'Critical Event', N'VM:EventLog', N'CriticalEventCount', 1.00, 3.00, N'>=', N'High', N'Critical', 240, 60),
    (N'VM_EVENT_ERROR', N'Event Log', N'Error Event', N'VM:EventLog', N'ErrorEventCount', 5.00, 15.00, N'>=', N'Medium', N'High', 480, 240)
) AS source (RuleKey, Category, Subcategory, ModuleName, MetricName, WarningThreshold, CriticalThreshold, ComparisonOperator, WarningSeverity, CriticalSeverity, WarningSlaMinutes, CriticalSlaMinutes)
ON target.RuleKey = source.RuleKey
WHEN MATCHED THEN UPDATE SET
    Category = source.Category,
    Subcategory = source.Subcategory,
    ModuleName = source.ModuleName,
    MetricName = source.MetricName,
    WarningThreshold = source.WarningThreshold,
    CriticalThreshold = source.CriticalThreshold,
    ComparisonOperator = source.ComparisonOperator,
    WarningSeverity = source.WarningSeverity,
    CriticalSeverity = source.CriticalSeverity,
    WarningSlaMinutes = source.WarningSlaMinutes,
    CriticalSlaMinutes = source.CriticalSlaMinutes,
    IsActive = 1
WHEN NOT MATCHED THEN
    INSERT (RuleKey, Category, Subcategory, ModuleName, MetricName, WarningThreshold, CriticalThreshold, ComparisonOperator, WarningSeverity, CriticalSeverity, WarningSlaMinutes, CriticalSlaMinutes)
    VALUES (source.RuleKey, source.Category, source.Subcategory, source.ModuleName, source.MetricName, source.WarningThreshold, source.CriticalThreshold, source.ComparisonOperator, source.WarningSeverity, source.CriticalSeverity, source.WarningSlaMinutes, source.CriticalSlaMinutes);
GO

CREATE OR ALTER PROCEDURE mon.usp_EnsureWindowsTargetInstance
    @TargetID INT,
    @InstanceID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT @InstanceID = InstanceID
    FROM mon.WindowsTargetInstanceMap
    WHERE TargetID = @TargetID;

    IF @InstanceID IS NOT NULL RETURN;

    DECLARE @ComputerName NVARCHAR(256), @DisplayName NVARCHAR(256), @EnvironmentName NVARCHAR(100);
    SELECT
        @ComputerName = ComputerName,
        @DisplayName = COALESCE(NULLIF(DisplayName, N''), ComputerName),
        @EnvironmentName = COALESCE(EnvironmentName, N'Production')
    FROM mon.WindowsTargets
    WHERE TargetID = @TargetID;

    IF @ComputerName IS NULL
        THROW 51010, 'Windows target was not found.', 1;

    SELECT TOP (1) @InstanceID = InstanceID
    FROM mon.MonitoredInstances
    WHERE DisplayName = @DisplayName
       OR ServerName = @ComputerName
    ORDER BY CASE WHEN DisplayName = @DisplayName THEN 0 ELSE 1 END, InstanceID;

    IF @InstanceID IS NULL
    BEGIN
        INSERT INTO mon.MonitoredInstances (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
        VALUES (@ComputerName, N'Windows', @DisplayName, @EnvironmentName, 1);
        SET @InstanceID = SCOPE_IDENTITY();
    END;

    INSERT INTO mon.WindowsTargetInstanceMap (TargetID, InstanceID)
    VALUES (@TargetID, @InstanceID);
END;
GO

CREATE OR ALTER PROCEDURE mon.usp_UpsertWindowsAlert
    @TargetID INT,
    @Severity NVARCHAR(20),
    @ModuleName NVARCHAR(100),
    @AlertTitle NVARCHAR(300),
    @AlertDetails NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @InstanceID INT;
    EXEC mon.usp_EnsureWindowsTargetInstance @TargetID = @TargetID, @InstanceID = @InstanceID OUTPUT;

    DECLARE @ExistingAlertID BIGINT;
    SELECT TOP (1) @ExistingAlertID = AlertID
    FROM mon.AlertHistory
    WHERE InstanceID = @InstanceID
      AND ModuleName = @ModuleName
      AND AlertTitle = @AlertTitle
      AND IsAcknowledged = 0
    ORDER BY AlertTime DESC, AlertID DESC;

    IF @ExistingAlertID IS NOT NULL
    BEGIN
        UPDATE mon.AlertHistory
        SET Severity = @Severity,
            AlertDetails = @AlertDetails,
            RepeatCount = ISNULL(RepeatCount, 1) + 1,
            LastRepeatedAt = SYSDATETIME()
        WHERE AlertID = @ExistingAlertID;
        SELECT @ExistingAlertID AS AlertID, CAST(1 AS BIT) AS IsExistingAlert;
        RETURN;
    END;

    INSERT INTO mon.AlertHistory
        (InstanceID, AlertTime, Severity, ModuleName, AlertTitle, AlertDetails, IsAcknowledged, RepeatCount, FirstAlertTime, LastRepeatedAt, IsTicketCreated)
    VALUES
        (@InstanceID, SYSDATETIME(), @Severity, @ModuleName, @AlertTitle, @AlertDetails, 0, 1, SYSDATETIME(), SYSDATETIME(), 0);

    SELECT SCOPE_IDENTITY() AS AlertID, CAST(0 AS BIT) AS IsExistingAlert;
END;
GO

CREATE OR ALTER PROCEDURE mon.usp_EvaluateWindowsVMAlerts
    @TargetID INT = NULL,
    @AutoCreateTickets BIT = 1,
    @CreatedBy NVARCHAR(128) = N'vm-alert-engine',
    @TicketsCreated INT = 0 OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @TicketsCreated = 0;

    DECLARE @events TABLE
    (
        TargetID INT,
        Severity NVARCHAR(20),
        ModuleName NVARCHAR(100),
        AlertTitle NVARCHAR(300),
        AlertDetails NVARCHAR(MAX)
    );

    INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
    SELECT h.TargetID,
           CASE WHEN h.CPUPercent >= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
           r.ModuleName,
           CONCAT(N'VM CPU high: ', h.DisplayName),
           CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; CPU=', h.CPUPercent, N'%; Warning=', r.WarningThreshold, N'%; Critical=', r.CriticalThreshold, N'%; SLA=', CASE WHEN h.CPUPercent >= r.CriticalThreshold THEN r.CriticalSlaMinutes ELSE r.WarningSlaMinutes END, N' minutes.')
    FROM mon.vw_WindowsLatestHealth h
    CROSS JOIN mon.WindowsAlertRules r
    WHERE r.RuleKey = N'VM_CPU_HIGH' AND r.IsActive = 1
      AND (@TargetID IS NULL OR h.TargetID = @TargetID)
      AND h.CPUPercent >= r.WarningThreshold;

    INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
    SELECT h.TargetID,
           CASE WHEN h.MemoryUsedPercent >= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
           r.ModuleName,
           CONCAT(N'VM memory high: ', h.DisplayName),
           CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; MemoryUsed=', h.MemoryUsedPercent, N'%; AvailableGB=', h.MemoryAvailableGB, N'; Warning=', r.WarningThreshold, N'%; Critical=', r.CriticalThreshold, N'%; SLA=', CASE WHEN h.MemoryUsedPercent >= r.CriticalThreshold THEN r.CriticalSlaMinutes ELSE r.WarningSlaMinutes END, N' minutes.')
    FROM mon.vw_WindowsLatestHealth h
    CROSS JOIN mon.WindowsAlertRules r
    WHERE r.RuleKey = N'VM_MEMORY_HIGH' AND r.IsActive = 1
      AND (@TargetID IS NULL OR h.TargetID = @TargetID)
      AND h.MemoryUsedPercent >= r.WarningThreshold;

    INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
    SELECT h.TargetID,
           CASE WHEN h.DiskUsedPercent >= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
           r.ModuleName,
           CONCAT(N'VM disk capacity high: ', h.DisplayName),
           CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; DiskUsed=', h.DiskUsedPercent, N'%; FreeGB=', h.DiskFreeGB, N'; Warning=', r.WarningThreshold, N'%; Critical=', r.CriticalThreshold, N'%; SLA=', CASE WHEN h.DiskUsedPercent >= r.CriticalThreshold THEN r.CriticalSlaMinutes ELSE r.WarningSlaMinutes END, N' minutes.')
    FROM mon.vw_WindowsLatestHealth h
    CROSS JOIN mon.WindowsAlertRules r
    WHERE r.RuleKey = N'VM_DISK_HIGH' AND r.IsActive = 1
      AND (@TargetID IS NULL OR h.TargetID = @TargetID)
      AND h.DiskUsedPercent >= r.WarningThreshold;

    INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
    SELECT h.TargetID,
           CASE WHEN h.HealthScore <= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
           r.ModuleName,
           CONCAT(N'VM health score degraded: ', h.DisplayName),
           CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; HealthScore=', h.HealthScore, N'; Posture=', h.HealthPosture, N'; WarningBelow=', r.WarningThreshold, N'; CriticalBelow=', r.CriticalThreshold, N'; SLA=', CASE WHEN h.HealthScore <= r.CriticalThreshold THEN r.CriticalSlaMinutes ELSE r.WarningSlaMinutes END, N' minutes.')
    FROM mon.vw_WindowsLatestHealth h
    CROSS JOIN mon.WindowsAlertRules r
    WHERE r.RuleKey = N'VM_HEALTH_LOW' AND r.IsActive = 1
      AND (@TargetID IS NULL OR h.TargetID = @TargetID)
      AND h.HealthScore <= r.WarningThreshold;

    INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
    SELECT h.TargetID,
           CASE WHEN h.ServiceStoppedCount >= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
           r.ModuleName,
           CONCAT(N'VM stopped automatic services: ', h.DisplayName),
           CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; StoppedAutomaticServices=', h.ServiceStoppedCount, N'; Warning=', r.WarningThreshold, N'; Critical=', r.CriticalThreshold, N'; SLA=', CASE WHEN h.ServiceStoppedCount >= r.CriticalThreshold THEN r.CriticalSlaMinutes ELSE r.WarningSlaMinutes END, N' minutes.')
    FROM mon.vw_WindowsLatestHealth h
    CROSS JOIN mon.WindowsAlertRules r
    WHERE r.RuleKey = N'VM_STOPPED_SERVICE' AND r.IsActive = 1
      AND (@TargetID IS NULL OR h.TargetID = @TargetID)
      AND h.ServiceStoppedCount >= r.WarningThreshold;

    INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
    SELECT h.TargetID,
           CASE WHEN h.MinutesSinceLastSample >= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
           r.ModuleName,
           CONCAT(N'VM telemetry stale: ', h.DisplayName),
           CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; MinutesSinceLastSample=', h.MinutesSinceLastSample, N'; Warning=', r.WarningThreshold, N'; Critical=', r.CriticalThreshold, N'; SLA=', CASE WHEN h.MinutesSinceLastSample >= r.CriticalThreshold THEN r.CriticalSlaMinutes ELSE r.WarningSlaMinutes END, N' minutes.')
    FROM mon.vw_WindowsLatestHealth h
    CROSS JOIN mon.WindowsAlertRules r
    WHERE r.RuleKey = N'VM_STALE_SAMPLE' AND r.IsActive = 1
      AND (@TargetID IS NULL OR h.TargetID = @TargetID)
      AND h.MinutesSinceLastSample >= r.WarningThreshold;

    IF OBJECT_ID(N'mon.WindowsEventSamples', N'U') IS NOT NULL
    BEGIN
        WITH recent AS
        (
            SELECT t.TargetID, t.DisplayName,
                   SUM(CASE WHEN es.LevelName = N'Critical' THEN 1 ELSE 0 END) AS CriticalEventCount,
                   SUM(CASE WHEN es.LevelName = N'Error' THEN 1 ELSE 0 END) AS ErrorEventCount
            FROM mon.WindowsTargets t
            INNER JOIN mon.WindowsEventSamples es ON es.TargetID = t.TargetID
            WHERE es.EventTime >= DATEADD(HOUR, -1, SYSDATETIME())
              AND (@TargetID IS NULL OR t.TargetID = @TargetID)
            GROUP BY t.TargetID, t.DisplayName
        )
        INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
        SELECT recent.TargetID,
               CASE WHEN recent.CriticalEventCount >= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
               r.ModuleName,
               CONCAT(N'VM critical Windows events: ', recent.DisplayName),
               CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; CriticalEventsLastHour=', recent.CriticalEventCount, N'; Warning=', r.WarningThreshold, N'; Critical=', r.CriticalThreshold, N'.')
        FROM recent
        CROSS JOIN mon.WindowsAlertRules r
        WHERE r.RuleKey = N'VM_EVENT_CRITICAL' AND r.IsActive = 1
          AND recent.CriticalEventCount >= r.WarningThreshold;

        WITH recent AS
        (
            SELECT t.TargetID, t.DisplayName,
                   SUM(CASE WHEN es.LevelName = N'Error' THEN 1 ELSE 0 END) AS ErrorEventCount
            FROM mon.WindowsTargets t
            INNER JOIN mon.WindowsEventSamples es ON es.TargetID = t.TargetID
            WHERE es.EventTime >= DATEADD(HOUR, -1, SYSDATETIME())
              AND (@TargetID IS NULL OR t.TargetID = @TargetID)
            GROUP BY t.TargetID, t.DisplayName
        )
        INSERT INTO @events (TargetID, Severity, ModuleName, AlertTitle, AlertDetails)
        SELECT recent.TargetID,
               CASE WHEN recent.ErrorEventCount >= r.CriticalThreshold THEN r.CriticalSeverity ELSE r.WarningSeverity END,
               r.ModuleName,
               CONCAT(N'VM Windows error event volume: ', recent.DisplayName),
               CONCAT(N'Category=', r.Category, N'; Subcategory=', r.Subcategory, N'; ErrorEventsLastHour=', recent.ErrorEventCount, N'; Warning=', r.WarningThreshold, N'; Critical=', r.CriticalThreshold, N'.')
        FROM recent
        CROSS JOIN mon.WindowsAlertRules r
        WHERE r.RuleKey = N'VM_EVENT_ERROR' AND r.IsActive = 1
          AND recent.ErrorEventCount >= r.WarningThreshold;
    END;

    DECLARE @TargetAlertID INT, @Severity NVARCHAR(20), @ModuleName NVARCHAR(100), @AlertTitle NVARCHAR(300), @AlertDetails NVARCHAR(MAX);
    DECLARE alert_cursor CURSOR FAST_FORWARD FOR
        SELECT TargetID, Severity, ModuleName, AlertTitle, AlertDetails FROM @events;

    OPEN alert_cursor;
    FETCH NEXT FROM alert_cursor INTO @TargetAlertID, @Severity, @ModuleName, @AlertTitle, @AlertDetails;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC mon.usp_UpsertWindowsAlert
            @TargetID = @TargetAlertID,
            @Severity = @Severity,
            @ModuleName = @ModuleName,
            @AlertTitle = @AlertTitle,
            @AlertDetails = @AlertDetails;
        FETCH NEXT FROM alert_cursor INTO @TargetAlertID, @Severity, @ModuleName, @AlertTitle, @AlertDetails;
    END;
    CLOSE alert_cursor;
    DEALLOCATE alert_cursor;

    IF @AutoCreateTickets = 1
        EXEC mon.usp_AutoConvertAlertsToTickets @HoursBack = 24, @CreatedBy = @CreatedBy, @TicketsCreated = @TicketsCreated OUTPUT;

    SELECT COUNT(1) AS AlertsEvaluated, @TicketsCreated AS TicketsCreated FROM @events;
END;
GO

CREATE OR ALTER PROCEDURE mon.usp_CreateTicketFromAlert
    @AlertID BIGINT,
    @CreatedBy NVARCHAR(128),
    @TicketSeverityID INT = 3,
    @AssignedTo NVARCHAR(128) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @InstanceID INT, @AlertTitle NVARCHAR(300), @AlertDetails NVARCHAR(MAX), @ModuleName NVARCHAR(100), @Severity NVARCHAR(20);
    DECLARE @ExistingTicketID BIGINT, @ExistingTicketNumber NVARCHAR(50);

    SELECT
        @InstanceID = InstanceID,
        @AlertTitle = AlertTitle,
        @AlertDetails = AlertDetails,
        @ModuleName = ModuleName,
        @Severity = Severity
    FROM mon.AlertHistory
    WHERE AlertID = @AlertID;

    IF @InstanceID IS NULL
        THROW 51000, 'AlertID was not found.', 1;

    SELECT TOP (1)
        @ExistingTicketID = t.TicketID,
        @ExistingTicketNumber = t.TicketNumber
    FROM mon.Tickets t
    INNER JOIN mon.AlertHistory ah ON t.AlertID = ah.AlertID
    WHERE t.IsActive = 1
      AND t.TicketStatusID IN (1, 2, 3, 6)
      AND ah.InstanceID = @InstanceID
      AND ah.ModuleName = @ModuleName
      AND ah.AlertTitle = @AlertTitle
    ORDER BY t.CreatedDate DESC, t.TicketID DESC;

    IF @ExistingTicketID IS NOT NULL
    BEGIN
        UPDATE ah
        SET IsTicketCreated = 1
        FROM mon.AlertHistory ah
        WHERE ah.IsAcknowledged = 0
          AND ah.InstanceID = @InstanceID
          AND ah.ModuleName = @ModuleName
          AND ah.AlertTitle = @AlertTitle;

        SELECT @ExistingTicketID AS TicketID, @ExistingTicketNumber AS TicketNumber, CAST(1 AS BIT) AS IsExistingTicket;
        RETURN;
    END;

    DECLARE @TicketNumber NVARCHAR(50);
    EXEC mon.usp_GetNextTicketNumber @TicketNumber OUTPUT;
    DECLARE @Category NVARCHAR(128) = CASE WHEN @ModuleName LIKE N'VM:%' THEN N'VM Monitoring' ELSE N'SQL Monitoring' END;
    DECLARE @Subcategory NVARCHAR(128) = CASE WHEN @ModuleName LIKE N'VM:%' THEN REPLACE(@ModuleName, N'VM:', N'') ELSE @ModuleName END;
    DECLARE @Impact NVARCHAR(40) = CASE WHEN @TicketSeverityID = 1 THEN N'High' WHEN @TicketSeverityID = 2 THEN N'Medium' ELSE N'Low' END;
    DECLARE @Urgency NVARCHAR(40) = CASE WHEN @TicketSeverityID = 1 THEN N'High' WHEN @TicketSeverityID = 2 THEN N'High' WHEN @TicketSeverityID = 3 THEN N'Medium' ELSE N'Low' END;
    DECLARE @SlaMinutes INT = CASE WHEN @TicketSeverityID = 1 THEN 60 WHEN @TicketSeverityID = 2 THEN 240 WHEN @TicketSeverityID = 3 THEN 480 ELSE 1440 END;
    DECLARE @AssignmentGroup NVARCHAR(128) = CASE WHEN @ModuleName LIKE N'VM:%' THEN N'Infrastructure Operations' ELSE N'Database Operations' END;

    INSERT INTO mon.Tickets
        (AlertID, TicketNumber, TicketType, InstanceID, ErrorDescription, TicketSeverityID, CreatedBy, AssignedTo,
         Category, Subcategory, Impact, Urgency, AssignmentGroup, ContactType, ExternalReference, SLADueDate, WorkNotes, EscalationLevelID)
    VALUES
        (@AlertID, @TicketNumber, N'VM', @InstanceID, N'Alert: ' + @AlertTitle + CHAR(13) + CHAR(10) + ISNULL(@AlertDetails, N''),
         @TicketSeverityID, @CreatedBy, @AssignedTo, @Category, @Subcategory, @Impact, @Urgency, @AssignmentGroup,
         N'Monitoring', CONCAT(N'AlertID:', @AlertID), DATEADD(MINUTE, @SlaMinutes, SYSDATETIME()),
         CONCAT(N'Created from ', @Category, N' alert. Severity=', COALESCE(@Severity, N''), N'; SLA=', @SlaMinutes, N' minutes.'), NULL);

    DECLARE @TicketID BIGINT = SCOPE_IDENTITY();

    UPDATE ah
    SET IsTicketCreated = 1
    FROM mon.AlertHistory ah
    WHERE ah.IsAcknowledged = 0
      AND ah.InstanceID = @InstanceID
      AND ah.ModuleName = @ModuleName
      AND ah.AlertTitle = @AlertTitle;

    SELECT @TicketID AS TicketID, @TicketNumber AS TicketNumber, CAST(0 AS BIT) AS IsExistingTicket;
END;
GO

CREATE OR ALTER VIEW mon.vw_WindowsOpenAlerts AS
SELECT
    ah.AlertID,
    map.TargetID,
    wt.ComputerName,
    wt.DisplayName,
    ah.InstanceID,
    ah.AlertTime,
    DATEDIFF(MINUTE, COALESCE(ah.FirstAlertTime, ah.AlertTime), SYSDATETIME()) AS AlertAgeMinutes,
    ah.Severity,
    ah.ModuleName,
    ah.AlertTitle,
    ah.AlertDetails,
    ah.RepeatCount,
    ah.FirstAlertTime,
    ah.LastRepeatedAt,
    ah.IsTicketCreated,
    t.TicketID,
    t.TicketNumber,
    t.SLADueDate,
    t.EscalationLevelID
FROM mon.AlertHistory ah
INNER JOIN mon.WindowsTargetInstanceMap map ON map.InstanceID = ah.InstanceID
INNER JOIN mon.WindowsTargets wt ON wt.TargetID = map.TargetID
LEFT JOIN mon.Tickets t ON t.AlertID = ah.AlertID AND t.IsActive = 1
WHERE ah.IsAcknowledged = 0
  AND ah.ModuleName LIKE N'VM:%';
GO
