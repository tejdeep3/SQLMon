-- SQL Monitor Extended Schema - Additional Views
-- Created: Phase 7 - Comprehensive Coverage
-- Views to support the 19-section monitoring framework

USE [DBA_SQLMonitor]
GO

-- ===================================================================
-- KPI VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestKPIs]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    k.CaptureTime,
    k.PageLifeExpectancy,
    k.BufferCacheHitRatio,
    k.VisibleOnlineCPUs,
    k.MAXDOP,
    k.CostThresholdForParallelism,
    k.MaxServerMemoryMB,
    k.MinServerMemoryMB
FROM mon.KPIHistory k
INNER JOIN mon.MonitoredInstances m ON k.InstanceID = m.InstanceID
WHERE k.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.KPIHistory WHERE InstanceID = k.InstanceID)
GO

-- ===================================================================
-- DISK VIEWS (Latest)
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestDisks]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    d.CaptureTime,
    d.VolumeMountPoint,
    d.VolumeMountPoint AS MountPoint,
    d.LogicalVolumeName,
    d.LogicalVolumeName AS VolumeName,
    d.TotalGB,
    d.FreeGB,
    d.UsedGB,
    d.UsedPct,
    CAST(d.TotalGB * 1024.0 AS NUMERIC(18,2)) AS TotalSizeMB,
    CAST(d.FreeGB * 1024.0 AS NUMERIC(18,2)) AS FreeSizeMB,
    COALESCE(d.UsedPct, CAST((d.UsedGB * 100.0) / NULLIF(d.TotalGB, 0) AS NUMERIC(5,2))) AS UtilizationPercent
FROM mon.DiskVolumeHistory d
INNER JOIN mon.MonitoredInstances m ON d.InstanceID = m.InstanceID
WHERE d.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.DiskVolumeHistory WHERE InstanceID = d.InstanceID)
GO

-- ===================================================================
-- CONFIG VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestConfig]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    c.CaptureTime,
    c.MachineName,
    c.InstanceName,
    c.ServerVersion,
    c.Edition,
    c.BuildNumber,
    c.ProcessorCount,
    c.PhysicalMemoryMB,
    c.MaxDOPSetting,
    c.CostThresholdSetting,
    c.MaxServerMemorySetting,
    c.MinServerMemorySetting,
    c.TraceFlags
FROM mon.ConfigHistory c
INNER JOIN mon.MonitoredInstances m ON c.InstanceID = m.InstanceID
WHERE c.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.ConfigHistory WHERE InstanceID = c.InstanceID)
GO

-- ===================================================================
-- I/O VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestIO]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    i.CaptureTime,
    i.DatabaseName,
    i.FileType,
    i.LogicalName,
    i.LogicalName AS LogicalFileName,
    i.PhysicalName,
    i.PhysicalName AS FilePath,
    i.SizeMB,
    i.SizeMB AS FileSizeMB,
    i.AvgReadMS,
    i.AvgReadMS AS AvgReadLatencyMS,
    i.AvgWriteMS,
    i.AvgWriteMS AS AvgWriteLatencyMS,
    i.TotalStallMS
FROM mon.IOFileHistory i
INNER JOIN mon.MonitoredInstances m ON i.InstanceID = m.InstanceID
WHERE i.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.IOFileHistory WHERE InstanceID = i.InstanceID)
GO

-- ===================================================================
-- TEMPDB VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestTempDB]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    t.CaptureTime,
    t.FileType,
    t.LogicalName,
    t.PhysicalName,
    t.TempDBDataFileCount,
    t.TempDBDataFileCount AS FileCount,
    t.RecommendedFileCount,
    t.SizeMB,
    t.SizeMB AS TotalSizeMB,
    t.UsedMB,
    COALESCE(t.PercentFull, CAST(t.UsedMB * 100.0 / NULLIF(t.SizeMB, 0) AS NUMERIC(5,2))) AS PercentFull
FROM mon.TempDBHistory t
INNER JOIN mon.MonitoredInstances m ON t.InstanceID = m.InstanceID
WHERE t.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.TempDBHistory WHERE InstanceID = t.InstanceID)
GO

-- ===================================================================
-- DB OPTIONS VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestDBOptions]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    d.CaptureTime,
    d.DatabaseName,
    d.State,
    d.RecoveryModel,
    d.PageVerify,
    d.IsAutoClose,
    d.IsAutoClose AS AutoClose,
    d.IsAutoShrink,
    d.IsAutoShrink AS AutoShrink,
    d.IsAutoCreateStatistics,
    d.IsAutoUpdateStatistics,
    d.CompatibilityLevel,
    d.IsEncrypted,
    d.IsReadOnly,
    d.Collation,
    d.SizeMB,
    d.AvailableSpaceMB,
    d.LogSizeMB,
    d.SizeMB AS MDFSizeMB,
    d.SizeMB - ISNULL(d.AvailableSpaceMB, 0) AS MDFUsedMB,
    d.LogSizeMB AS LDFSizeMB,
    CAST(NULL AS BIGINT) AS LDFUsedMB
FROM mon.DBOptionsHistory d
INNER JOIN mon.MonitoredInstances m ON d.InstanceID = m.InstanceID
WHERE d.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.DBOptionsHistory WHERE InstanceID = d.InstanceID)
GO

-- ===================================================================
-- BLOCKING VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_CurrentBlocking]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    b.CaptureTime,
    b.SessionID,
    b.SessionID AS SPID,
    b.BlockingSessionID,
    b.BlockingSessionID AS BlockedBySPID,
    b.DatabaseName,
    b.WaitType,
    b.WaitTimeMS,
    b.LoginName,
    b.HostName,
    b.CommandText,
    b.CommandText AS CommandType,
    b.StatementText
FROM mon.BlockingHistory b
INNER JOIN mon.MonitoredInstances m ON b.InstanceID = m.InstanceID
WHERE b.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.BlockingHistory WHERE InstanceID = b.InstanceID)
AND b.BlockingSessionID IS NOT NULL
GO

-- ===================================================================
-- LONG RUNNING VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LongRunningCurrent]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    l.CaptureTime,
    l.SessionID,
    l.SessionID AS SPID,
    l.DatabaseName,
    l.StartTime,
    l.DurationMinutes,
    l.DurationMinutes * 60000 AS DurationMS,
    l.StatusText,
    l.StatusText AS Status,
    l.WaitType,
    l.CPUms,
    l.CPUms AS CPUTimeMS,
    l.Reads,
    l.Reads AS LogicalReads,
    CAST(NULL AS BIGINT) AS PhysicalReads,
    l.Writes,
    l.Writes AS LogicalWrites,
    l.CommandText,
    l.CommandText AS CommandType,
    l.StatementText
FROM mon.LongRunningHistory l
INNER JOIN mon.MonitoredInstances m ON l.InstanceID = m.InstanceID
WHERE l.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.LongRunningHistory WHERE InstanceID = l.InstanceID)
AND l.DurationMinutes > 1
GO

-- ===================================================================
-- TOP QUERIES VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestTopQueries]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    t.CollectionDateTime,
    t.QueryID,
    t.PlanID,
    t.QueryText,
    t.AvgCpuTime,
    t.AvgDuration,
    t.AvgLogicalIOReads,
    t.AvgLogicalIOWrites,
    t.CountExecutions,
    ROW_NUMBER() OVER (PARTITION BY m.InstanceID ORDER BY t.AvgCpuTime DESC) AS CPURank,
    ROW_NUMBER() OVER (PARTITION BY m.InstanceID ORDER BY t.AvgLogicalIOReads DESC) AS ReadsRank
FROM dbo.TopQueries t
INNER JOIN mon.MonitoredInstances m ON t.InstanceID = m.InstanceID
WHERE t.CollectionDateTime = (SELECT MAX(CollectionDateTime) FROM dbo.TopQueries WHERE InstanceID = t.InstanceID)
GO

-- ===================================================================
-- MISSING INDEXES VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestMissingIndexes]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    mi.CollectionDateTime,
    mi.DatabaseName,
    mi.ObjectName,
    mi.EqualityColumns,
    mi.InequalityColumns,
    mi.IncludedColumns,
    mi.UserSeeks,
    mi.UserScans,
    mi.UserLookups,
    mi.UserUpdates,
    mi.ImprovementMeasure
FROM dbo.MissingIndexes mi
INNER JOIN mon.MonitoredInstances m ON mi.InstanceID = m.InstanceID
WHERE mi.CollectionDateTime = (SELECT MAX(CollectionDateTime) FROM dbo.MissingIndexes WHERE InstanceID = mi.InstanceID)
GO

-- ===================================================================
-- INDEX FRAGMENTATION VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestIndexFragmentation]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    f.CollectionDateTime,
    f.DatabaseName,
    f.ObjectName,
    f.IndexName,
    f.IndexType,
    f.AvgFragmentationPercent,
    f.AvgPageSpaceUsedPercent,
    f.RecordCount,
    CASE 
        WHEN f.AvgFragmentationPercent > 30 THEN 'REBUILD'
        WHEN f.AvgFragmentationPercent > 10 THEN 'REORGANIZE'
        ELSE 'HEALTHY'
    END AS RecommendedAction
FROM dbo.IndexFragmentation f
INNER JOIN mon.MonitoredInstances m ON f.InstanceID = m.InstanceID
WHERE f.CollectionDateTime = (SELECT MAX(CollectionDateTime) FROM dbo.IndexFragmentation WHERE InstanceID = f.InstanceID)
GO

-- ===================================================================
-- ALWAYS ON REPLICAS VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestAGReplicas]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    r.CaptureTime,
    r.AGName,
    r.AGName AS AvailabilityGroupName,
    r.ReplicaServer,
    r.ReplicaServer AS ReplicaName,
    r.IsLocal,
    r.AvailabilityModeDesc,
    r.AvailabilityModeDesc AS AvailabilityMode,
    r.FailoverModeDesc,
    r.FailoverModeDesc AS FailoverMode,
    r.RoleDesc,
    r.RoleDesc AS ReplicaRole,
    r.ConnectedStateDesc,
    r.ConnectedStateDesc AS ConnectionState,
    r.SyncHealthDesc,
    r.SyncHealthDesc AS SynchronizationHealth
FROM mon.AGReplicaHistory r
INNER JOIN mon.MonitoredInstances m ON r.InstanceID = m.InstanceID
WHERE r.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.AGReplicaHistory WHERE InstanceID = r.InstanceID)
GO

-- ===================================================================
-- ALWAYS ON DATABASES VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestAGDatabases]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    d.CaptureTime,
    d.AGName,
    d.AGName AS AvailabilityGroupName,
    d.ReplicaServer,
    d.DatabaseName,
    d.IsPrimaryReplica,
    d.SyncStateDesc,
    d.SyncStateDesc AS ReplState,
    d.SyncHealthDesc,
    d.SyncHealthDesc AS SyncHealth,
    d.LogSendQueueMB,
    d.RedoQueueMB,
    d.LastCommitTime,
    CAST(CASE WHEN d.SyncHealthDesc = 'HEALTHY' THEN 1 ELSE 0 END AS BIT) AS IsFailoverReady
FROM mon.AGDatabaseHistory d
INNER JOIN mon.MonitoredInstances m ON d.InstanceID = m.InstanceID
WHERE d.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.AGDatabaseHistory WHERE InstanceID = d.InstanceID)
GO

-- ===================================================================
-- LISTENER VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestListeners]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    l.CaptureTime,
    l.DNSName,
    l.DNSName AS ListenerName,
    l.AGName,
    l.AGName AS AvailabilityGroupName,
    l.Port,
    l.IPAddress,
    l.SubnetMask,
    l.State,
    CAST(CASE WHEN l.State IN ('ONLINE', 'Online', 'Running') THEN 1 ELSE 0 END AS BIT) AS IsOnline
FROM mon.ListenerHistory l
INNER JOIN mon.MonitoredInstances m ON l.InstanceID = m.InstanceID
WHERE l.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.ListenerHistory WHERE InstanceID = l.InstanceID)
GO

-- ===================================================================
-- ENDPOINT VIEWS
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestEndpoints]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    e.CaptureTime,
    e.EndpointName,
    e.EndpointType,
    e.Protocol,
    e.Protocol AS ProtocolType,
    e.Encryption,
    e.State,
    e.Port,
    e.Owner
FROM mon.EndpointHistory e
INNER JOIN mon.MonitoredInstances m ON e.InstanceID = m.InstanceID
WHERE e.CaptureTime = (SELECT MAX(CaptureTime) FROM mon.EndpointHistory WHERE InstanceID = e.InstanceID)
GO

-- ===================================================================
-- WAITS VIEWS (Latest)
-- ===================================================================
CREATE OR ALTER VIEW [mon].[vw_LatestWaits]
AS
SELECT 
    m.InstanceID,
    m.DisplayName,
    w.CollectionDateTime,
    w.WaitType,
    w.WaitingTasksCount,
    w.WaitTimeMs,
    w.MaxWaitTimeMs,
    w.SignalWaitTimeMs
FROM dbo.WaitStats w
INNER JOIN mon.MonitoredInstances m ON w.InstanceID = m.InstanceID
WHERE w.CollectionDateTime = (SELECT MAX(CollectionDateTime) FROM dbo.WaitStats WHERE InstanceID = w.InstanceID)
GO

PRINT 'Extended schema views created successfully'
GO
