-- Phase 7: Complete Monitoring Schema for All 19 Sections
-- This script creates all remaining tables, views, and procedures
-- Tables: KPOHistory, ConfigHistory, DBOptionsHistory, ListenerHistory, EndpointHistory + Views for each

USE DBA_SQLMonitor;
GO

-- ============================================================================
-- 1. KPI HISTORY TABLE
-- ============================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='KPIHistory' AND xtype='U')
CREATE TABLE mon.KPIHistory (
    [KPIHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [PageLifeExpectancy] [bigint] NOT NULL,
    [BufferCacheHitRatio] [float] NOT NULL,
    [AvailablePhysicalMemoryMB] [bigint] NOT NULL,
    [TotalPhysicalMemoryMB] [bigint] NOT NULL,
    [ProcessMemoryMB] [bigint] NOT NULL,
    [VisibleOnlineCPUs] [int] NOT NULL,
    [MaxDOP] [int] NOT NULL,
    [CostThresholdForParallelism] [int] NOT NULL,
    [MaxServerMemoryMB] [int] NOT NULL,
    [MinServerMemoryMB] [int] NOT NULL,
    CONSTRAINT [PK_KPIHistory] PRIMARY KEY CLUSTERED ([KPIHistoryID] ASC)
) ON [PRIMARY]
GO

-- ============================================================================
-- 2. CONFIGURATION HISTORY TABLE
-- ============================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ConfigHistory' AND xtype='U')
CREATE TABLE mon.ConfigHistory (
    [ConfigHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [MachineName] [nvarchar](128) NOT NULL,
    [InstanceName] [nvarchar](128) NOT NULL,
    [ServerVersion] [nvarchar](128) NOT NULL,
    [Edition] [nvarchar](128) NOT NULL,
    [BuildNumber] [int] NOT NULL,
    [ProcessorCount] [int] NOT NULL,
    [PhysicalMemoryMB] [bigint] NOT NULL,
    [MaxDOPSetting] [int] NOT NULL,
    [CostThresholdSetting] [int] NOT NULL,
    [MaxServerMemorySetting] [int] NOT NULL,
    [MinServerMemorySetting] [int] NOT NULL,
    [TraceFlags] [nvarchar](max) NULL,
    CONSTRAINT [PK_ConfigHistory] PRIMARY KEY CLUSTERED ([ConfigHistoryID] ASC)
) ON [PRIMARY]
GO

-- ============================================================================
-- 3. DATABASE OPTIONS HISTORY TABLE
-- ============================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DBOptionsHistory' AND xtype='U')
CREATE TABLE mon.DBOptionsHistory (
    [DBOptionsID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [State] [nvarchar](60) NOT NULL,
    [RecoveryModel] [nvarchar](60) NOT NULL,
    [PageVerify] [nvarchar](60) NOT NULL,
    [IsAutoClose] [bit] NOT NULL,
    [IsAutoShrink] [bit] NOT NULL,
    [IsAutoCreateStatistics] [bit] NOT NULL,
    [IsAutoUpdateStatistics] [bit] NOT NULL,
    [IsEncrypted] [bit] NOT NULL,
    [IsReadOnly] [bit] NOT NULL,
    [Collation] [nvarchar](128) NOT NULL,
    [CompatibilityLevel] [int] NOT NULL,
    [SizeMB] [bigint] NOT NULL,
    [AvailableSpaceMB] [bigint] NOT NULL,
    [LogSizeMB] [bigint] NOT NULL,
    CONSTRAINT [PK_DBOptionsHistory] PRIMARY KEY CLUSTERED ([DBOptionsID] ASC)
) ON [PRIMARY]
GO

-- ============================================================================
-- 4. LISTENER HISTORY TABLE
-- ============================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ListenerHistory' AND xtype='U')
CREATE TABLE mon.ListenerHistory (
    [ListenerID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [DNSName] [nvarchar](256) NOT NULL,
    [IPAddress] [nvarchar](45) NOT NULL,
    [Port] [int] NOT NULL,
    [SubnetMask] [nvarchar](45) NULL,
    [State] [nvarchar](60) NOT NULL,
    [AGName] [nvarchar](128) NOT NULL,
    CONSTRAINT [PK_ListenerHistory] PRIMARY KEY CLUSTERED ([ListenerID] ASC)
) ON [PRIMARY]
GO

-- ============================================================================
-- 5. ENDPOINT HISTORY TABLE
-- ============================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EndpointHistory' AND xtype='U')
CREATE TABLE mon.EndpointHistory (
    [EndpointID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [EndpointName] [nvarchar](256) NOT NULL,
    [EndpointType] [nvarchar](60) NOT NULL,
    [Protocol] [nvarchar](60) NOT NULL,
    [Port] [int] NOT NULL,
    [Encryption] [nvarchar](60) NULL,
    [State] [nvarchar](60) NOT NULL,
    [Owner] [nvarchar](128) NULL,
    CONSTRAINT [PK_EndpointHistory] PRIMARY KEY CLUSTERED ([EndpointID] ASC)
) ON [PRIMARY]
GO

-- ============================================================================
-- Compatibility upgrades for repositories where earlier deployment scripts
-- created these history tables with a narrower extended-schema column set.
-- ============================================================================
IF OBJECT_ID('mon.KPIHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.KPIHistory', 'AvailablePhysicalMemoryMB') IS NULL ALTER TABLE mon.KPIHistory ADD AvailablePhysicalMemoryMB BIGINT NULL;
    IF COL_LENGTH('mon.KPIHistory', 'TotalPhysicalMemoryMB') IS NULL ALTER TABLE mon.KPIHistory ADD TotalPhysicalMemoryMB BIGINT NULL;
    IF COL_LENGTH('mon.KPIHistory', 'ProcessMemoryMB') IS NULL ALTER TABLE mon.KPIHistory ADD ProcessMemoryMB BIGINT NULL;
    IF COL_LENGTH('mon.KPIHistory', 'VisibleOnlineCPUs') IS NULL ALTER TABLE mon.KPIHistory ADD VisibleOnlineCPUs INT NULL;
    IF COL_LENGTH('mon.KPIHistory', 'MaxDOP') IS NULL ALTER TABLE mon.KPIHistory ADD MaxDOP INT NULL;
    IF COL_LENGTH('mon.KPIHistory', 'CostThresholdForParallelism') IS NULL ALTER TABLE mon.KPIHistory ADD CostThresholdForParallelism INT NULL;
END;
GO

IF OBJECT_ID('mon.ConfigHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.ConfigHistory', 'MachineName') IS NULL ALTER TABLE mon.ConfigHistory ADD MachineName NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'InstanceName') IS NULL ALTER TABLE mon.ConfigHistory ADD InstanceName NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'ServerVersion') IS NULL ALTER TABLE mon.ConfigHistory ADD ServerVersion NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'Edition') IS NULL ALTER TABLE mon.ConfigHistory ADD Edition NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'BuildNumber') IS NULL ALTER TABLE mon.ConfigHistory ADD BuildNumber INT NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'ProcessorCount') IS NULL ALTER TABLE mon.ConfigHistory ADD ProcessorCount INT NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'PhysicalMemoryMB') IS NULL ALTER TABLE mon.ConfigHistory ADD PhysicalMemoryMB BIGINT NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'MaxDOPSetting') IS NULL ALTER TABLE mon.ConfigHistory ADD MaxDOPSetting INT NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'CostThresholdSetting') IS NULL ALTER TABLE mon.ConfigHistory ADD CostThresholdSetting INT NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'MaxServerMemorySetting') IS NULL ALTER TABLE mon.ConfigHistory ADD MaxServerMemorySetting INT NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'MinServerMemorySetting') IS NULL ALTER TABLE mon.ConfigHistory ADD MinServerMemorySetting INT NULL;
    IF COL_LENGTH('mon.ConfigHistory', 'TraceFlags') IS NULL ALTER TABLE mon.ConfigHistory ADD TraceFlags NVARCHAR(MAX) NULL;
END;
GO

IF OBJECT_ID('mon.DBOptionsHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.DBOptionsHistory', 'IsAutoClose') IS NULL ALTER TABLE mon.DBOptionsHistory ADD IsAutoClose BIT NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'IsAutoShrink') IS NULL ALTER TABLE mon.DBOptionsHistory ADD IsAutoShrink BIT NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'IsAutoCreateStatistics') IS NULL ALTER TABLE mon.DBOptionsHistory ADD IsAutoCreateStatistics BIT NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'IsAutoUpdateStatistics') IS NULL ALTER TABLE mon.DBOptionsHistory ADD IsAutoUpdateStatistics BIT NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'Collation') IS NULL ALTER TABLE mon.DBOptionsHistory ADD Collation NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'SizeMB') IS NULL ALTER TABLE mon.DBOptionsHistory ADD SizeMB DECIMAL(18,2) NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'AvailableSpaceMB') IS NULL ALTER TABLE mon.DBOptionsHistory ADD AvailableSpaceMB DECIMAL(18,2) NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'LogSizeMB') IS NULL ALTER TABLE mon.DBOptionsHistory ADD LogSizeMB DECIMAL(18,2) NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'MDFSizeMB') IS NULL ALTER TABLE mon.DBOptionsHistory ADD MDFSizeMB DECIMAL(18,2) NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'MDFUsedMB') IS NULL ALTER TABLE mon.DBOptionsHistory ADD MDFUsedMB DECIMAL(18,2) NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'LDFSizeMB') IS NULL ALTER TABLE mon.DBOptionsHistory ADD LDFSizeMB DECIMAL(18,2) NULL;
    IF COL_LENGTH('mon.DBOptionsHistory', 'LDFUsedMB') IS NULL ALTER TABLE mon.DBOptionsHistory ADD LDFUsedMB DECIMAL(18,2) NULL;
END;
GO

IF OBJECT_ID('mon.ListenerHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.ListenerHistory', 'DNSName') IS NULL ALTER TABLE mon.ListenerHistory ADD DNSName NVARCHAR(256) NULL;
    IF COL_LENGTH('mon.ListenerHistory', 'AGName') IS NULL ALTER TABLE mon.ListenerHistory ADD AGName NVARCHAR(128) NULL;
    IF COL_LENGTH('mon.ListenerHistory', 'State') IS NULL ALTER TABLE mon.ListenerHistory ADD State NVARCHAR(60) NULL;
END;
GO

IF OBJECT_ID('mon.EndpointHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.EndpointHistory', 'Protocol') IS NULL ALTER TABLE mon.EndpointHistory ADD Protocol NVARCHAR(60) NULL;
    IF COL_LENGTH('mon.EndpointHistory', 'Encryption') IS NULL ALTER TABLE mon.EndpointHistory ADD Encryption NVARCHAR(60) NULL;
    IF COL_LENGTH('mon.EndpointHistory', 'Owner') IS NULL ALTER TABLE mon.EndpointHistory ADD Owner NVARCHAR(128) NULL;
END;
GO

-- ============================================================================
-- VIEWS FOR ALL HISTORY TABLES
-- ============================================================================

-- KPI Latest View
DROP VIEW IF EXISTS mon.vw_LatestKPIs
GO
CREATE VIEW mon.vw_LatestKPIs AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, PageLifeExpectancy, BufferCacheHitRatio,
    AvailablePhysicalMemoryMB, TotalPhysicalMemoryMB, ProcessMemoryMB,
    VisibleOnlineCPUs, MaxDOP, CostThresholdForParallelism
FROM mon.KPIHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- Config Latest View
DROP VIEW IF EXISTS mon.vw_LatestConfig
GO
CREATE VIEW mon.vw_LatestConfig AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, MachineName, InstanceName, ServerVersion,
    Edition, BuildNumber, ProcessorCount, PhysicalMemoryMB
FROM mon.ConfigHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- DB Options Latest View
DROP VIEW IF EXISTS mon.vw_LatestDBOptions
GO
CREATE VIEW mon.vw_LatestDBOptions AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, DatabaseName, State, RecoveryModel,
    PageVerify, IsAutoClose, IsAutoShrink, IsEncrypted, IsReadOnly,
    SizeMB, AvailableSpaceMB, LogSizeMB
FROM mon.DBOptionsHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- Listeners Latest View
DROP VIEW IF EXISTS mon.vw_LatestListeners
GO
CREATE VIEW mon.vw_LatestListeners AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, DNSName, IPAddress, Port, AGName, State
FROM mon.ListenerHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- Endpoints Latest View
DROP VIEW IF EXISTS mon.vw_LatestEndpoints
GO
CREATE VIEW mon.vw_LatestEndpoints AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, EndpointName, EndpointType, Protocol,
    Port, Encryption, State, Owner
FROM mon.EndpointHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- I/O Latest View
DROP VIEW IF EXISTS mon.vw_LatestIO
GO
CREATE VIEW mon.vw_LatestIO AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, DatabaseName, FileType, LogicalName,
    PhysicalName, SizeMB, AvgReadMS, AvgWriteMS, TotalStallMS
FROM mon.IOFileHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- TempDB Latest View
DROP VIEW IF EXISTS mon.vw_LatestTempDB
GO
CREATE VIEW mon.vw_LatestTempDB AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, FileType, LogicalName, PhysicalName, SizeMB, UsedMB, PercentFull, TempDBDataFileCount
FROM mon.TempDBHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- Waits Latest View (use dbo.WaitStats table)
DROP VIEW IF EXISTS mon.vw_LatestWaits
GO
CREATE VIEW mon.vw_LatestWaits AS
SELECT TOP 1 WITH TIES
    InstanceID, CollectionDateTime AS CaptureTime, WaitType, WaitingTasksCount, WaitTimeMs, SignalWaitTimeMs
FROM dbo.WaitStats
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CollectionDateTime DESC)
GO

-- Latest Top Queries View
DROP VIEW IF EXISTS mon.vw_LatestTopQueries
GO
CREATE VIEW mon.vw_LatestTopQueries AS
SELECT TOP 1 WITH TIES
    InstanceID, CollectionDateTime AS CaptureTime, QueryID, QueryText, AvgCpuTime,
    AvgDuration, AvgLogicalIOReads, CountExecutions
FROM dbo.TopQueries
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CollectionDateTime DESC)
GO

-- Latest Missing Indexes View
DROP VIEW IF EXISTS mon.vw_LatestMissingIndexes
GO
CREATE VIEW mon.vw_LatestMissingIndexes AS
SELECT TOP 1 WITH TIES
    InstanceID, CollectionDateTime AS CaptureTime, DatabaseName, ObjectName, ImprovementMeasure,
    UserSeeks, UserScans, UserLookups, EqualityColumns, IncludedColumns
FROM dbo.MissingIndexes
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CollectionDateTime DESC)
GO

-- Latest Index Fragmentation View
DROP VIEW IF EXISTS mon.vw_LatestIndexFragmentation
GO
CREATE VIEW mon.vw_LatestIndexFragmentation AS
SELECT TOP 1 WITH TIES
    InstanceID, CollectionDateTime AS CaptureTime, DatabaseName, ObjectName, IndexName,
    AvgFragmentationPercent, RecordCount
FROM dbo.IndexFragmentation
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CollectionDateTime DESC)
GO

-- AG Overview Latest View
DROP VIEW IF EXISTS mon.vw_LatestAGOverview
GO
CREATE VIEW mon.vw_LatestAGOverview AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, AGName, PrimaryReplica, SyncHealthDesc,
    BackupPreferenceDesc, FailureConditionLevel, ClusterTypeDesc
FROM mon.AGOverviewHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- AG Replicas Latest View
DROP VIEW IF EXISTS mon.vw_LatestAGReplicas
GO
CREATE VIEW mon.vw_LatestAGReplicas AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, AGName, ReplicaServer, IsLocal,
    RoleDesc, AvailabilityModeDesc, FailoverModeDesc, SyncHealthDesc, ConnectedStateDesc
FROM mon.AGReplicaHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

-- AG Databases Latest View
DROP VIEW IF EXISTS mon.vw_LatestAGDatabases
GO
CREATE VIEW mon.vw_LatestAGDatabases AS
SELECT TOP 1 WITH TIES
    InstanceID, CaptureTime, AGName, DatabaseName, ReplicaServer,
    IsPrimaryReplica, SyncStateDesc, SyncHealthDesc
FROM mon.AGDatabaseHistory
ORDER BY ROW_NUMBER() OVER (PARTITION BY InstanceID ORDER BY CaptureTime DESC)
GO

PRINT 'Phase 7 Schema - All tables and views created successfully'
GO
