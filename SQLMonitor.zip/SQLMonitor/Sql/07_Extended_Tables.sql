-- SQL Monitor Extended Schema - Additional Tables
-- Created: Phase 7 - Comprehensive Coverage
-- This script creates all repository tables for the 19-section monitoring framework

USE [DBA_SQLMonitor]
GO

-- ===================================================================
-- KPI HISTORY TABLE
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='KPIHistory' AND xtype='U')
CREATE TABLE [mon].[KPIHistory] (
    [KPIHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [PageLifeExpectancy] [bigint] NULL,
    [BufferCacheHitRatio] [float] NULL,
    [VisibleOnlineCPUs] [int] NULL,
    [MAXDOP] [int] NULL,
    [CostThresholdForParallelism] [int] NULL,
    [MaxServerMemoryMB] [int] NULL,
    [MinServerMemoryMB] [int] NULL,
    CONSTRAINT [PK_KPIHistory] PRIMARY KEY CLUSTERED ([KPIHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_KPIHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY]
GO

-- ===================================================================
-- CONFIG HISTORY TABLE
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ConfigHistory' AND xtype='U')
CREATE TABLE [mon].[ConfigHistory] (
    [ConfigHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [ConfigName] [nvarchar](128) NOT NULL,
    [ConfigValue] [nvarchar](max) NULL,
    [ConfigDescription] [nvarchar](max) NULL,
    CONSTRAINT [PK_ConfigHistory] PRIMARY KEY CLUSTERED ([ConfigHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_ConfigHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- ===================================================================
-- DB OPTIONS HISTORY TABLE
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DBOptionsHistory' AND xtype='U')
CREATE TABLE [mon].[DBOptionsHistory] (
    [DBOptionsHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [State] [nvarchar](60) NULL,
    [RecoveryModel] [nvarchar](60) NULL,
    [PageVerify] [nvarchar](60) NULL,
    [AutoClose] [bit] NULL,
    [AutoShrink] [bit] NULL,
    [CompatibilityLevel] [int] NULL,
    [IsEncrypted] [bit] NULL,
    [IsReadOnly] [bit] NULL,
    [MDFSizeMB] [float] NULL,
    [MDFUsedMB] [float] NULL,
    [LDFSizeMB] [float] NULL,
    [LDFUsedMB] [float] NULL,
    CONSTRAINT [PK_DBOptionsHistory] PRIMARY KEY CLUSTERED ([DBOptionsHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_DBOptionsHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY]
GO

-- ===================================================================
-- LISTENER HISTORY TABLE
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ListenerHistory' AND xtype='U')
CREATE TABLE [mon].[ListenerHistory] (
    [ListenerHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [ListenerName] [nvarchar](256) NOT NULL,
    [AvailabilityGroupName] [nvarchar](256) NOT NULL,
    [Port] [int] NULL,
    [IPAddress] [nvarchar](45) NULL,
    [SubnetMask] [nvarchar](45) NULL,
    [IsOnline] [bit] NULL,
    CONSTRAINT [PK_ListenerHistory] PRIMARY KEY CLUSTERED ([ListenerHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_ListenerHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY]
GO

-- ===================================================================
-- ENDPOINT HISTORY TABLE
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EndpointHistory' AND xtype='U')
CREATE TABLE [mon].[EndpointHistory] (
    [EndpointHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [EndpointName] [nvarchar](256) NOT NULL,
    [EndpointType] [nvarchar](60) NOT NULL,
    [ProtocolType] [nvarchar](60) NULL,
    [State] [nvarchar](60) NULL,
    [Port] [int] NULL,
    CONSTRAINT [PK_EndpointHistory] PRIMARY KEY CLUSTERED ([EndpointHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_EndpointHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY]
GO

-- ===================================================================
-- BLOCKING HISTORY TABLE (Enhanced)
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='BlockingHistory' AND xtype='U')
CREATE TABLE [mon].[BlockingHistory] (
    [BlockingHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [SPID] [int] NOT NULL,
    [BlockedBySPID] [int] NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [WaitTimeMS] [int] NULL,
    [LoginName] [nvarchar](128) NULL,
    [HostName] [nvarchar](128) NULL,
    [CommandType] [nvarchar](60) NULL,
    [StatementText] [nvarchar](max) NULL,
    CONSTRAINT [PK_BlockingHistory] PRIMARY KEY CLUSTERED ([BlockingHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_BlockingHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- ===================================================================
-- LONG RUNNING HISTORY TABLE (Enhanced)
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='LongRunningHistory' AND xtype='U')
CREATE TABLE [mon].[LongRunningHistory] (
    [LongRunningHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [SPID] [int] NOT NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [StartTime] [datetime2](7) NULL,
    [DurationMS] [int] NULL,
    [Status] [nvarchar](60) NULL,
    [WaitType] [nvarchar](60) NULL,
    [CPUTimeMS] [int] NULL,
    [LogicalReads] [bigint] NULL,
    [PhysicalReads] [bigint] NULL,
    [LogicalWrites] [bigint] NULL,
    [CommandType] [nvarchar](60) NULL,
    [StatementText] [nvarchar](max) NULL,
    CONSTRAINT [PK_LongRunningHistory] PRIMARY KEY CLUSTERED ([LongRunningHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_LongRunningHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- ===================================================================
-- EXECUTION PLANS HISTORY TABLE (UNIQUE FEATURE)
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ExecutionPlansHistory' AND xtype='U')
CREATE TABLE [mon].[ExecutionPlansHistory] (
    [ExecutionPlansHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [SessionId] [int] NOT NULL,
    [StartTime] [datetime2](7) NULL,
    [Status] [nvarchar](60) NULL,
    [Command] [nvarchar](60) NULL,
    [CpuTime] [int] NULL,
    [ElapsedTime] [int] NULL,
    [Reads] [bigint] NULL,
    [Writes] [bigint] NULL,
    [LogicalReads] [bigint] NULL,
    [WaitType] [nvarchar](60) NULL,
    [WaitTime] [int] NULL,
    [SqlText] [nvarchar](max) NULL,
    [QueryPlanXml] [xml] NULL,
    [Recommendations] [nvarchar](max) NULL,
    CONSTRAINT [PK_ExecutionPlansHistory] PRIMARY KEY CLUSTERED ([ExecutionPlansHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_ExecutionPlansHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- ===================================================================
-- MEMORY CLERKS HISTORY TABLE (UNIQUE FEATURE)
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='MemoryClerksHistory' AND xtype='U')
CREATE TABLE [mon].[MemoryClerksHistory] (
    [MemoryClerksHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [Type] [nvarchar](60) NOT NULL,
    [Name] [nvarchar](256) NOT NULL,
    [MemoryNodeId] [int] NULL,
    [PagesKB] [bigint] NULL,
    [VirtualMemoryReservedKB] [bigint] NULL,
    [VirtualMemoryCommittedKB] [bigint] NULL,
    [AweAllocatedKB] [bigint] NULL,
    [SharedMemoryReservedKB] [bigint] NULL,
    [SharedMemoryCommittedKB] [bigint] NULL,
    [SinglePagesKB] [bigint] NULL,
    [MultiPagesKB] [bigint] NULL,
    [CachedPagesKB] [bigint] NULL,
    [TotalPhysicalMemoryKB] [bigint] NULL,
    [AvailablePhysicalMemoryKB] [bigint] NULL,
    [SystemMemoryState] [nvarchar](60) NULL,
    [PressureLevel] [nvarchar](20) NULL,
    [Recommendations] [nvarchar](max) NULL,
    CONSTRAINT [PK_MemoryClerksHistory] PRIMARY KEY CLUSTERED ([MemoryClerksHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_MemoryClerksHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- ===================================================================
-- BUFFER POOL ANALYSIS HISTORY TABLE (UNIQUE FEATURE)
-- ===================================================================
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='BufferPoolAnalysisHistory' AND xtype='U')
CREATE TABLE [mon].[BufferPoolAnalysisHistory] (
    [BufferPoolAnalysisHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [SizeMB] [float] NULL,
    [PageCount] [bigint] NULL,
    [DirtyPages] [bigint] NULL,
    [OldPages] [bigint] NULL,
    [AvgSecondsSinceAccess] [float] NULL,
    [CleanPages] [bigint] NULL,
    [FreshPages] [bigint] NULL,
    [Recommendations] [nvarchar](max) NULL,
    CONSTRAINT [PK_BufferPoolAnalysisHistory] PRIMARY KEY CLUSTERED ([BufferPoolAnalysisHistoryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
    CONSTRAINT [FK_BufferPoolAnalysisHistory_InstanceID] FOREIGN KEY([InstanceID]) REFERENCES [mon].[MonitoredInstances] ([InstanceID])
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

PRINT 'Extended schema tables created successfully'
GO
