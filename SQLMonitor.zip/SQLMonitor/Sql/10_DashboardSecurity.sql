USE [DBA_SQLMonitor];

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');

IF OBJECT_ID('mon.DashboardUsers', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUsers (
        UserID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardUsers PRIMARY KEY,
        UserName NVARCHAR(128) NOT NULL,
        DisplayName NVARCHAR(200) NULL,
        EmailAddress NVARCHAR(256) NULL,
        PhoneNumber NVARCHAR(20) NULL,
        Department NVARCHAR(100) NULL,
        PasswordSalt VARBINARY(16) NOT NULL,
        PasswordHash VARBINARY(32) NOT NULL,
        RoleName NVARCHAR(20) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_DashboardUsers_IsActive DEFAULT (1),
        MustChangePassword BIT NOT NULL CONSTRAINT DF_DashboardUsers_MustChangePassword DEFAULT (0),
        FailedLoginCount INT NOT NULL CONSTRAINT DF_DashboardUsers_FailedLoginCount DEFAULT (0),
        LastFailedLoginAt DATETIME2(0) NULL,
        LockoutUntil DATETIME2(0) NULL,
        PasswordChangedAt DATETIME2(0) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUsers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastLoginAt DATETIME2(0) NULL,
        CONSTRAINT UQ_DashboardUsers_UserName UNIQUE (UserName),
        CONSTRAINT CK_DashboardUsers_RoleName CHECK (RoleName IN ('Admin', 'AppOwner', 'ViewOnly', 'Limited'))
    );
END;

IF OBJECT_ID('mon.DashboardUserInstanceAccess', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUserInstanceAccess (
        UserID INT NOT NULL,
        InstanceID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUserInstanceAccess_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardUserInstanceAccess PRIMARY KEY (UserID, InstanceID),
        CONSTRAINT FK_DashboardUserInstanceAccess_Users FOREIGN KEY (UserID) REFERENCES mon.DashboardUsers(UserID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardUserInstanceAccess_Instances FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.DashboardServerGroups', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardServerGroups (
        GroupID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardServerGroups PRIMARY KEY,
        GroupName NVARCHAR(160) NOT NULL,
        ApplicationName NVARCHAR(160) NULL,
        OwnerName NVARCHAR(160) NULL,
        Description NVARCHAR(500) NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_DashboardServerGroups_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardServerGroups_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        CONSTRAINT UQ_DashboardServerGroups_GroupName UNIQUE (GroupName)
    );
END;

IF OBJECT_ID('mon.DashboardServerGroupMembers', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardServerGroupMembers (
        GroupID INT NOT NULL,
        InstanceID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardServerGroupMembers_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardServerGroupMembers PRIMARY KEY (GroupID, InstanceID),
        CONSTRAINT FK_DashboardServerGroupMembers_Groups FOREIGN KEY (GroupID) REFERENCES mon.DashboardServerGroups(GroupID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardServerGroupMembers_Instances FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.DashboardUserServerGroupAccess', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUserServerGroupAccess (
        UserID INT NOT NULL,
        GroupID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUserServerGroupAccess_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardUserServerGroupAccess PRIMARY KEY (UserID, GroupID),
        CONSTRAINT FK_DashboardUserServerGroupAccess_Users FOREIGN KEY (UserID) REFERENCES mon.DashboardUsers(UserID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardUserServerGroupAccess_Groups FOREIGN KEY (GroupID) REFERENCES mon.DashboardServerGroups(GroupID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.DashboardAuditLog', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardAuditLog (
        AuditID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardAuditLog PRIMARY KEY,
        UserID INT NULL,
        UserName NVARCHAR(128) NULL,
        ActionName NVARCHAR(100) NOT NULL,
        Details NVARCHAR(1000) NULL,
        ClientHost NVARCHAR(128) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardAuditLog_CreatedAt DEFAULT (SYSDATETIME())
    );
END;

IF NOT EXISTS (SELECT 1 FROM mon.DashboardUsers)
BEGIN
    DECLARE @Salt VARBINARY(16) = 0x53514C4D4F4E41444D494E30303031;
    DECLARE @Password NVARCHAR(128) = N'Admin@123';

    INSERT INTO mon.DashboardUsers
        (UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword)
    VALUES
        (N'admin', N'Dashboard Administrator', @Salt, HASHBYTES('SHA2_256', @Salt + CONVERT(VARBINARY(MAX), @Password)), N'Admin', 1, 1);
END;

IF COL_LENGTH('mon.DashboardUsers', 'FailedLoginCount') IS NULL ALTER TABLE mon.DashboardUsers ADD FailedLoginCount INT NOT NULL CONSTRAINT DF_DashboardUsers_FailedLoginCount_Upgrade DEFAULT (0);
IF COL_LENGTH('mon.DashboardUsers', 'LastFailedLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastFailedLoginAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'LockoutUntil') IS NULL ALTER TABLE mon.DashboardUsers ADD LockoutUntil DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'PasswordChangedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD PasswordChangedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'UpdatedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD UpdatedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'LastLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastLoginAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'EmailAddress') IS NULL ALTER TABLE mon.DashboardUsers ADD EmailAddress NVARCHAR(256) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'PhoneNumber') IS NULL ALTER TABLE mon.DashboardUsers ADD PhoneNumber NVARCHAR(20) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'Department') IS NULL ALTER TABLE mon.DashboardUsers ADD Department NVARCHAR(100) NULL;

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_DashboardUsers_RoleName' AND parent_object_id = OBJECT_ID('mon.DashboardUsers'))
    ALTER TABLE mon.DashboardUsers DROP CONSTRAINT CK_DashboardUsers_RoleName;
ALTER TABLE mon.DashboardUsers ADD CONSTRAINT CK_DashboardUsers_RoleName CHECK (RoleName IN ('Admin', 'AppOwner', 'ViewOnly', 'Limited'));

PRINT 'Dashboard security schema is ready. Default bootstrap login, if created: admin / Admin@123';
