-- Phase 7: Complete Schema - All Monitoring Tables & Views
-- Creates remaining tables, views, and procedures for comprehensive monitoring

USE [DBA_SQLMonitor]
GO

-- =====================================================
-- KPI MONITORING
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='KPIHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'dbo'))
CREATE TABLE [mon].[KPIHistory] (
    [KPIHistoryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [PageLifeExpectancy] [int] NULL,
    [BufferCacheHitRatio] [float] NULL,
    [VisibleOnlineCPUs] [int] NULL,
    [MAXDOP] [int] NULL,
    [CostThresholdForParallelism] [int] NULL,
    [ServerMemoryMB] [bigint] NULL,
    CONSTRAINT [PK_KPIHistory] PRIMARY KEY CLUSTERED ([KPIHistoryID] ASC)
) ON [PRIMARY]
GO

-- =====================================================
-- CONFIGURATION MONITORING
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ConfigHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'dbo'))
CREATE TABLE [mon].[ConfigHistory] (
    [ConfigID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [ServerName] [nvarchar](128) NOT NULL,
    [ProcessorCount] [int] NULL,
    [VisibleOnlineCPUs] [int] NULL,
    [PhysicalMemoryMB] [bigint] NULL,
    [MaxServerMemoryMB] [bigint] NULL,
    [MinServerMemoryMB] [bigint] NULL,
    [MAXDOP] [int] NULL,
    [CostThresholdForParallelism] [int] NULL,
    [CTLF_Value] [int] NULL,
    CONSTRAINT [PK_ConfigHistory] PRIMARY KEY CLUSTERED ([ConfigID] ASC)
) ON [PRIMARY]
GO

-- =====================================================
-- DATABASE OPTIONS MONITORING
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DBOptionsHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'dbo'))
CREATE TABLE [mon].[DBOptionsHistory] (
    [DBOptionID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [State] [nvarchar](60) NULL,
    [RecoveryModel] [nvarchar](60) NULL,
    [PageVerify] [nvarchar](60) NULL,
    [AutoClose] [bit] NULL,
    [AutoShrink] [bit] NULL,
    [CompatibilityLevel] [int] NULL,
    [IsEncrypted] [bit] NULL,
    [IsReadOnly] [bit] NULL,
    [MDFSizeMB] [numeric](12,2) NULL,
    [LDFSizeMB] [numeric](12,2) NULL,
    CONSTRAINT [PK_DBOptionsHistory] PRIMARY KEY CLUSTERED ([DBOptionID] ASC)
) ON [PRIMARY]
GO

-- =====================================================
-- LISTENER & ENDPOINTS MONITORING
-- =====================================================

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='ListenerHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'dbo'))
CREATE TABLE [mon].[ListenerHistory] (
    [ListenerID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [ListenerName] [nvarchar](256) NOT NULL,
    [AvailabilityGroupName] [nvarchar](256) NOT NULL,
    [Port] [int] NULL,
    [State] [nvarchar](60) NULL,
    [UpdatedTime] [datetime2](7) NULL,
    CONSTRAINT [PK_ListenerHistory] PRIMARY KEY CLUSTERED ([ListenerID] ASC)
) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EndpointHistory' AND xtype='U' AND uid = (SELECT uid FROM sysusers WHERE name = 'dbo'))
CREATE TABLE [mon].[EndpointHistory] (
    [EndpointID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CaptureTime] [datetime2](7) NOT NULL,
    [EndpointName] [nvarchar](256) NOT NULL,
    [EndpointType] [nvarchar](60) NULL,
    [State] [nvarchar](60) NULL,
    [Protocol] [nvarchar](60) NULL,
    [Port] [int] NULL,
    [UpdatedTime] [datetime2](7) NULL,
    CONSTRAINT [PK_EndpointHistory] PRIMARY KEY CLUSTERED ([EndpointID] ASC)
) ON [PRIMARY]
GO

-- =====================================================
-- VIEWS FOR LATEST SNAPSHOTS
-- =====================================================

CREATE OR ALTER VIEW [mon].[vw_LatestKPIs]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.PageLifeExpectancy,
    h.BufferCacheHitRatio,
    h.VisibleOnlineCPUs,
    h.MAXDOP,
    h.CostThresholdForParallelism,
    h.ServerMemoryMB
FROM mon.KPIHistory h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestConfig]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.ServerName,
    h.ProcessorCount,
    h.VisibleOnlineCPUs,
    h.PhysicalMemoryMB,
    h.MaxServerMemoryMB,
    h.MinServerMemoryMB,
    h.MAXDOP,
    h.CostThresholdForParallelism,
    h.CTLF_Value
FROM mon.ConfigHistory h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestDBOptions]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.DatabaseName,
    h.State,
    h.RecoveryModel,
    h.PageVerify,
    h.AutoClose,
    h.AutoShrink,
    h.CompatibilityLevel,
    h.IsEncrypted,
    h.IsReadOnly,
    h.MDFSizeMB,
    h.LDFSizeMB
FROM mon.DBOptionsHistory h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID, h.DatabaseName ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestListeners]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.ListenerName,
    h.AvailabilityGroupName,
    h.Port,
    h.State
FROM mon.ListenerHistory h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID, h.ListenerName ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestEndpoints]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.EndpointName,
    h.EndpointType,
    h.State,
    h.Protocol,
    h.Port
FROM mon.EndpointHistory h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID, h.EndpointName ORDER BY h.CaptureTime DESC)
GO

-- =====================================================
-- ENHANCED VIEWS FOR EXISTING TABLES
-- =====================================================

CREATE OR ALTER VIEW [mon].[vw_LatestIO]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.DatabaseName,
    h.LogicalName,
    h.PhysicalName,
    h.FileType,
    h.FileSizeMB,
    h.AvgReadLatencyMs,
    h.AvgWriteLatencyMs,
    h.ReadLatencyStallMs,
    h.WriteLatencyStallMs
FROM mon.IOFileHistory h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestTempDB]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.FileCount,
    h.TotalSizeMB,
    h.UsedSpaceMB,
    h.PercentFull,
    h.ContentionLevel,
    h.RecommendedActions
FROM mon.TempDBHistory h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_CurrentBlocking]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.BlockingSessionID,
    h.BlockedSessionID,
    h.DatabaseName,
    h.WaitType,
    h.WaitTimeMs,
    h.HostName,
    h.LoginName,
    h.LastCommand,
    h.LastStatement
FROM mon.BlockingHistory h
WHERE h.CaptureTime >= DATEADD(HOUR, -1, SYSDATETIME())
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LongRunningCurrent]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.SPID,
    h.DatabaseName,
    h.DurationSeconds,
    h.CPUTimeMs,
    h.LogicalReads,
    h.LogicalWrites,
    h.HostName,
    h.LoginName,
    h.LastCommand,
    h.QueryText
FROM mon.LongRunningHistory h
WHERE h.CaptureTime >= DATEADD(HOUR, -1, SYSDATETIME())
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestWaits]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.WaitType,
    h.WaitingTasksCount,
    h.WaitTimeMs,
    h.SignalWaitTimeMs,
    CAST(h.WaitTimeMs * 100.0 / NULLIF(h.WaitTimeMs + h.SignalWaitTimeMs, 0) AS NUMERIC(5,2)) AS WaitTimePercent
FROM dbo.WaitStats h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestTopQueries]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.QueryID,
    h.PlanID,
    h.QueryText,
    h.AvgCpuTime,
    h.AvgDuration,
    h.AvgLogicalIOReads,
    h.CountExecutions,
    'CPU_Heavy' AS QueryType
FROM dbo.TopQueries h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestMissingIndexes]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.DatabaseName,
    h.ObjectName,
    h.EqualityColumns,
    h.InequalityColumns,
    h.IncludedColumns,
    h.ImprovementMeasure,
    h.UserSeeks,
    h.UserScans,
    h.UserLookups
FROM dbo.MissingIndexes h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

CREATE OR ALTER VIEW [mon].[vw_LatestIndexFragmentation]
AS
SELECT TOP 1 WITH TIES
    h.InstanceID,
    h.CaptureTime,
    h.DatabaseName,
    h.ObjectName,
    h.IndexName,
    h.AvgFragmentationPercent,
    CASE 
        WHEN h.AvgFragmentationPercent < 10 THEN 'HEALTHY'
        WHEN h.AvgFragmentationPercent < 30 THEN 'REORGANIZE'
        ELSE 'REBUILD'
    END AS RecommendedAction
FROM dbo.IndexFragmentation h
ORDER BY ROW_NUMBER() OVER (PARTITION BY h.InstanceID ORDER BY h.CaptureTime DESC)
GO

-- =====================================================
-- FOREIGN KEY ADDITIONS
-- =====================================================

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_KPIHistory_Instance')
ALTER TABLE [mon].[KPIHistory]
ADD CONSTRAINT [FK_KPIHistory_Instance]
FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ConfigHistory_Instance')
ALTER TABLE [mon].[ConfigHistory]
ADD CONSTRAINT [FK_ConfigHistory_Instance]
FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_DBOptionsHistory_Instance')
ALTER TABLE [mon].[DBOptionsHistory]
ADD CONSTRAINT [FK_DBOptionsHistory_Instance]
FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_ListenerHistory_Instance')
ALTER TABLE [mon].[ListenerHistory]
ADD CONSTRAINT [FK_ListenerHistory_Instance]
FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EndpointHistory_Instance')
ALTER TABLE [mon].[EndpointHistory]
ADD CONSTRAINT [FK_EndpointHistory_Instance]
FOREIGN KEY ([InstanceID]) REFERENCES [mon].[MonitoredInstances]([InstanceID])
GO

-- =====================================================
-- INDEXING
-- =====================================================

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_KPIHistory_InstanceTime')
CREATE NONCLUSTERED INDEX [IX_KPIHistory_InstanceTime] ON [mon].[KPIHistory] ([InstanceID], [CaptureTime] DESC)
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ConfigHistory_InstanceTime')
CREATE NONCLUSTERED INDEX [IX_ConfigHistory_InstanceTime] ON [mon].[ConfigHistory] ([InstanceID], [CaptureTime] DESC)
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_DBOptionsHistory_InstanceTime')
CREATE NONCLUSTERED INDEX [IX_DBOptionsHistory_InstanceTime] ON [mon].[DBOptionsHistory] ([InstanceID], [CaptureTime] DESC)
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ListenerHistory_InstanceTime')
CREATE NONCLUSTERED INDEX [IX_ListenerHistory_InstanceTime] ON [mon].[ListenerHistory] ([InstanceID], [CaptureTime] DESC)
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EndpointHistory_InstanceTime')
CREATE NONCLUSTERED INDEX [IX_EndpointHistory_InstanceTime] ON [mon].[EndpointHistory] ([InstanceID], [CaptureTime] DESC)
GO

PRINT 'Phase 7: Complete schema created successfully'
GO