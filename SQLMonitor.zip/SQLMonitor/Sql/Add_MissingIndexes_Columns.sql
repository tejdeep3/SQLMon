-- Add missing columns to dbo.MissingIndexes table
-- This script adds the AvgTotalUserCost, AvgUserImpact, UniqueCompiles, and ImprovementMeasure columns
-- that were missing from the original table creation.

USE [DBA_SQLMonitor]
GO

-- Check if the table exists
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'MissingIndexes' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    -- Add AvgTotalUserCost column if it doesn't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('dbo.MissingIndexes') AND name = 'AvgTotalUserCost')
    BEGIN
        ALTER TABLE [dbo].[MissingIndexes] ADD [AvgTotalUserCost] [float] NULL;
        PRINT 'Added column AvgTotalUserCost to dbo.MissingIndexes';
    END
    ELSE
    BEGIN
        PRINT 'Column AvgTotalUserCost already exists in dbo.MissingIndexes';
    END

    -- Add AvgUserImpact column if it doesn't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('dbo.MissingIndexes') AND name = 'AvgUserImpact')
    BEGIN
        ALTER TABLE [dbo].[MissingIndexes] ADD [AvgUserImpact] [float] NULL;
        PRINT 'Added column AvgUserImpact to dbo.MissingIndexes';
    END
    ELSE
    BEGIN
        PRINT 'Column AvgUserImpact already exists in dbo.MissingIndexes';
    END

    -- Add UniqueCompiles column if it doesn't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('dbo.MissingIndexes') AND name = 'UniqueCompiles')
    BEGIN
        ALTER TABLE [dbo].[MissingIndexes] ADD [UniqueCompiles] [bigint] NULL;
        PRINT 'Added column UniqueCompiles to dbo.MissingIndexes';
    END
    ELSE
    BEGIN
        PRINT 'Column UniqueCompiles already exists in dbo.MissingIndexes';
    END

    -- Add ImprovementMeasure column if it doesn't exist
    IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('dbo.MissingIndexes') AND name = 'ImprovementMeasure')
    BEGIN
        ALTER TABLE [dbo].[MissingIndexes] ADD [ImprovementMeasure] [float] NULL;
        PRINT 'Added column ImprovementMeasure to dbo.MissingIndexes';
    END
    ELSE
    BEGIN
        PRINT 'Column ImprovementMeasure already exists in dbo.MissingIndexes';
    END

    PRINT 'Column addition check completed for dbo.MissingIndexes';
END
ELSE
BEGIN
    PRINT 'Table dbo.MissingIndexes does not exist. Please run Create_MissingIndexes_Table.sql first.';
END
GO