-- Collection Health Monitoring Views and Procedures
-- Run this on DBA_SQLMonitor database

USE [DBA_SQLMonitor]
GO

-- ============================================
-- View: Collection Health Dashboard
-- Shows last collection time and status for each module
-- ============================================
CREATE OR ALTER VIEW mon.vw_CollectionHealth
AS
SELECT 
    i.InstanceID,
    i.DisplayName AS InstanceName,
    i.ServerName,
    i.InstanceName AS SQLInstance,
    Modules.ModuleName,
    cr.Status AS LastStatus,
    cr.StartTime AS LastCollectionTime,
    cr.EndTime AS LastEndTime,
    DATEDIFF(SECOND, cr.StartTime, cr.EndTime) AS DurationSeconds,
    cr.ErrorMessage,
    CASE 
        WHEN cr.StartTime IS NULL THEN 'Never Collected'
        WHEN Modules.ModuleName IN ('KPIs', 'Disks', 'Config', 'CPU', 'Memory', 'IO', 'TempDB', 'DBOptions', 'Backups', 'Blocking', 'LongRunning')
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 10 THEN 'Healthy'
        WHEN Modules.ModuleName IN ('KPIs', 'Disks', 'Config', 'CPU', 'Memory', 'IO', 'TempDB', 'DBOptions', 'Backups', 'Blocking', 'LongRunning')
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 30 THEN 'Warning'
        WHEN Modules.ModuleName IN ('Waits', 'TopQueries', 'MissingIndexes')
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 35 THEN 'Healthy'
        WHEN Modules.ModuleName IN ('Waits', 'TopQueries', 'MissingIndexes')
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 60 THEN 'Warning'
        WHEN Modules.ModuleName IN ('Fragmentation', 'AgentJobs', 'Deadlocks', 'AlwaysOn', 'ListenersEndpoints')
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 1500 THEN 'Healthy'
        WHEN Modules.ModuleName IN ('Fragmentation', 'AgentJobs', 'Deadlocks', 'AlwaysOn', 'ListenersEndpoints')
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 2880 THEN 'Warning'
        WHEN Modules.ModuleName = 'AlertEngine'
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 5 THEN 'Healthy'
        WHEN Modules.ModuleName = 'AlertEngine'
             AND DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME()) <= 15 THEN 'Warning'
        ELSE 'Critical'
    END AS HealthStatus,
    CASE 
        WHEN cr.StartTime IS NULL THEN 0
        ELSE DATEDIFF(MINUTE, cr.StartTime, SYSDATETIME())
    END AS MinutesAgo
FROM mon.MonitoredInstances i
CROSS JOIN (
    VALUES ('KPIs'), ('Disks'), ('Config'), ('CPU'), ('Memory'), 
           ('IO'), ('TempDB'), ('DBOptions'), ('Backups'),
           ('Blocking'), ('LongRunning'), ('Waits'),
           ('TopQueries'), ('MissingIndexes'),
            ('Fragmentation'), ('AgentJobs'), ('Deadlocks'),
            ('AlwaysOn'), ('ListenersEndpoints'),
           ('AlertEngine')
) AS Modules(ModuleName)
LEFT JOIN (
    SELECT 
        InstanceID,
        ModuleName,
        Status,
        StartTime,
        EndTime,
        ErrorMessage,
        ROW_NUMBER() OVER (PARTITION BY InstanceID, ModuleName ORDER BY StartTime DESC) AS rn
    FROM mon.CollectionRuns
    WHERE ModuleName <> 'RetentionPurge'
) cr ON i.InstanceID = cr.InstanceID 
    AND Modules.ModuleName = cr.ModuleName 
    AND cr.rn = 1;
GO

-- ============================================
-- View: Collection Gaps (Missing data)
-- Identifies collectors that haven't run recently
-- ============================================
CREATE OR ALTER VIEW mon.vw_CollectionGaps
AS
SELECT 
    InstanceID,
    InstanceName,
    ServerName,
    SQLInstance,
    ModuleName,
    LastCollectionTime,
    MinutesAgo,
    LastStatus,
    ErrorMessage,
    CASE 
        WHEN ModuleName IN ('KPIs', 'Disks', 'Config', 'CPU', 'Memory') AND MinutesAgo > 10 THEN 'Core collector overdue'
        WHEN ModuleName IN ('IO', 'TempDB', 'DBOptions', 'Backups', 'Blocking', 'LongRunning') AND MinutesAgo > 10 THEN 'Core collector overdue'
        WHEN ModuleName IN ('Waits', 'TopQueries', 'MissingIndexes') AND MinutesAgo > 35 THEN 'Advanced collector overdue'
        WHEN ModuleName IN ('Fragmentation', 'AgentJobs', 'Deadlocks', 'AlwaysOn', 'ListenersEndpoints') AND MinutesAgo > 1440 THEN 'Daily collector overdue'
        WHEN ModuleName = 'AlertEngine' AND MinutesAgo > 5 THEN 'Alert engine overdue'
        WHEN LastStatus = 'Failed' THEN 'Collector failing'
        WHEN LastCollectionTime IS NULL THEN 'Never collected'
        ELSE 'OK'
    END AS IssueDescription,
    CASE 
        WHEN ModuleName IN ('KPIs', 'Disks', 'Config', 'CPU', 'Memory') AND MinutesAgo > 10 THEN 3
        WHEN ModuleName IN ('IO', 'TempDB', 'DBOptions', 'Backups', 'Blocking', 'LongRunning') AND MinutesAgo > 10 THEN 3
        WHEN ModuleName IN ('Waits', 'TopQueries', 'MissingIndexes') AND MinutesAgo > 35 THEN 2
        WHEN ModuleName IN ('Fragmentation', 'AgentJobs', 'Deadlocks', 'AlwaysOn', 'ListenersEndpoints') AND MinutesAgo > 1440 THEN 1
        WHEN ModuleName = 'AlertEngine' AND MinutesAgo > 5 THEN 2
        WHEN LastStatus = 'Failed' THEN 3
        WHEN LastCollectionTime IS NULL THEN 2
        ELSE 0
    END AS Severity
FROM mon.vw_CollectionHealth
WHERE HealthStatus IN ('Warning', 'Critical', 'Never Collected')
   OR LastStatus = 'Failed';
GO

-- ============================================
-- View: Collection Performance Summary
-- Shows average collection times and trends
-- ============================================
CREATE OR ALTER VIEW mon.vw_CollectionPerformance
AS
SELECT 
    i.DisplayName AS InstanceName,
    cr.ModuleName,
    COUNT(*) AS TotalRuns,
    AVG(DATEDIFF(SECOND, cr.StartTime, cr.EndTime)) AS AvgDurationSeconds,
    MAX(DATEDIFF(SECOND, cr.StartTime, cr.EndTime)) AS MaxDurationSeconds,
    MIN(DATEDIFF(SECOND, cr.StartTime, cr.EndTime)) AS MinDurationSeconds,
    SUM(CASE WHEN cr.Status = 'Success' THEN 1 ELSE 0 END) AS SuccessCount,
    SUM(CASE WHEN cr.Status = 'Failed' THEN 1 ELSE 0 END) AS FailureCount,
    CAST(SUM(CASE WHEN cr.Status = 'Success' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS SuccessRate,
    MAX(cr.StartTime) AS LastRunTime,
    MIN(cr.StartTime) AS FirstRunTime
FROM mon.CollectionRuns cr
INNER JOIN mon.MonitoredInstances i ON cr.InstanceID = i.InstanceID
WHERE cr.ModuleName <> 'RetentionPurge'
    AND cr.EndTime IS NOT NULL
GROUP BY i.DisplayName, cr.ModuleName;
GO

-- ============================================
-- Stored Procedure: Check Collection Health
-- Returns health status and alerts for collectors
-- ============================================
CREATE OR ALTER PROCEDURE mon.usp_CheckCollectionHealth
    @InstanceID INT = NULL,
    @IncludeOK BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        InstanceName,
        ServerName,
        SQLInstance,
        ModuleName,
        HealthStatus,
        LastCollectionTime,
        MinutesAgo,
        LastStatus,
        DurationSeconds,
        ErrorMessage,
        CASE 
            WHEN HealthStatus = 'Critical' THEN '🔴'
            WHEN HealthStatus = 'Warning' THEN '🟡'
            WHEN HealthStatus = 'Healthy' THEN '🟢'
            ELSE '⚪'
        END AS StatusIcon
    FROM mon.vw_CollectionHealth
    WHERE (@InstanceID IS NULL OR InstanceID = @InstanceID)
        AND (@IncludeOK = 1 OR HealthStatus <> 'Healthy')
    ORDER BY 
        CASE HealthStatus 
            WHEN 'Critical' THEN 1 
            WHEN 'Warning' THEN 2 
            WHEN 'Healthy' THEN 3 
            ELSE 4 
        END,
        MinutesAgo DESC;
END;
GO

-- ============================================
-- View: Instance Health Summary
-- Overall health score per instance
-- ============================================
CREATE OR ALTER VIEW mon.vw_InstanceHealthSummary
AS
SELECT 
    InstanceID,
    InstanceName,
    ServerName,
    SQLInstance,
    COUNT(*) AS TotalModules,
    SUM(CASE WHEN HealthStatus = 'Healthy' THEN 1 ELSE 0 END) AS HealthyModules,
    SUM(CASE WHEN HealthStatus = 'Warning' THEN 1 ELSE 0 END) AS WarningModules,
    SUM(CASE WHEN HealthStatus = 'Critical' THEN 1 ELSE 0 END) AS CriticalModules,
    SUM(CASE WHEN LastCollectionTime IS NULL THEN 1 ELSE 0 END) AS NeverCollected,
    CAST(SUM(CASE WHEN HealthStatus = 'Healthy' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS HealthScore,
    MAX(MinutesAgo) AS MaxMinutesAgo,
    MIN(LastCollectionTime) AS OldestCollection
FROM mon.vw_CollectionHealth
GROUP BY InstanceID, InstanceName, ServerName, SQLInstance;
GO

PRINT 'Collection health monitoring views and procedures created successfully';
PRINT '';
PRINT 'Usage:';
PRINT '  SELECT * FROM mon.vw_CollectionHealth ORDER BY MinutesAgo DESC;';
PRINT '  SELECT * FROM mon.vw_CollectionGaps ORDER BY Severity DESC;';
PRINT '  SELECT * FROM mon.vw_InstanceHealthSummary ORDER BY HealthScore;';
PRINT '  EXEC mon.usp_CheckCollectionHealth @IncludeOK = 0;';
