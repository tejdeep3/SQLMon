IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');

IF OBJECT_ID('mon.MonitoredInstances', 'U') IS NULL
BEGIN
    CREATE TABLE mon.MonitoredInstances
    (
        InstanceID            INT IDENTITY(1,1) PRIMARY KEY,
        ServerName            NVARCHAR(128) NOT NULL,
        InstanceName          NVARCHAR(128) NULL,
        DisplayName           NVARCHAR(200) NOT NULL,
        EnvironmentName       NVARCHAR(50) NULL,
        IsActive              BIT NOT NULL DEFAULT 1,
        CreatedOn             DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    );
END;

IF OBJECT_ID('mon.CollectionRuns', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CollectionRuns
    (
        RunID                 BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        ModuleName            NVARCHAR(100) NOT NULL,
        StartTime             DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        EndTime               DATETIME2 NULL,
        Status                NVARCHAR(20) NOT NULL DEFAULT 'Started',
        ErrorMessage          NVARCHAR(MAX) NULL
    );
END;

IF OBJECT_ID('mon.CollectorNodes', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CollectorNodes
    (
        CollectorNodeID       INT IDENTITY(1,1) PRIMARY KEY,
        NodeName              NVARCHAR(128) NOT NULL,
        HostName              NVARCHAR(128) NOT NULL,
        DeploymentRole        NVARCHAR(30) NOT NULL DEFAULT N'Collector',
        SiteName              NVARCHAR(128) NULL,
        Tags                  NVARCHAR(400) NULL,
        VersionText           NVARCHAR(50) NULL,
        IsEnabled             BIT NOT NULL DEFAULT 1,
        RegisteredAt          DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        LastHeartbeat         DATETIME2 NULL,
        LastSeenStatus        NVARCHAR(40) NULL,
        Notes                 NVARCHAR(1000) NULL,
        CONSTRAINT UQ_CollectorNodes_NodeName UNIQUE (NodeName)
    );
END;

IF OBJECT_ID('mon.CollectorAssignments', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CollectorAssignments
    (
        AssignmentID          INT IDENTITY(1,1) PRIMARY KEY,
        CollectorNodeID       INT NOT NULL,
        InstanceID            INT NOT NULL,
        CollectorGroup        NVARCHAR(30) NOT NULL DEFAULT N'All',
        Priority              INT NOT NULL DEFAULT 100,
        IsEnabled             BIT NOT NULL DEFAULT 1,
        AssignedAt            DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        AssignedBy            NVARCHAR(128) NULL,
        Notes                 NVARCHAR(1000) NULL,
        CONSTRAINT FK_CollectorAssignments_Node FOREIGN KEY (CollectorNodeID) REFERENCES mon.CollectorNodes(CollectorNodeID),
        CONSTRAINT FK_CollectorAssignments_Instance FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID)
    );
END;

IF OBJECT_ID('mon.CollectorNodeHeartbeat', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CollectorNodeHeartbeat
    (
        HeartbeatID           BIGINT IDENTITY(1,1) PRIMARY KEY,
        CollectorNodeID       INT NOT NULL,
        HeartbeatTime         DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        Status                NVARCHAR(40) NOT NULL,
        CollectorGroup        NVARCHAR(30) NULL,
        InstanceCount         INT NULL,
        MessageText           NVARCHAR(1000) NULL,
        CONSTRAINT FK_CollectorNodeHeartbeat_Node FOREIGN KEY (CollectorNodeID) REFERENCES mon.CollectorNodes(CollectorNodeID)
    );
END;

IF COL_LENGTH('mon.CollectionRuns', 'CollectorNodeID') IS NULL
BEGIN
    ALTER TABLE mon.CollectionRuns ADD CollectorNodeID INT NULL;
END;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_CollectionRuns_CollectorNode')
BEGIN
    ALTER TABLE mon.CollectionRuns
        ADD CONSTRAINT FK_CollectionRuns_CollectorNode FOREIGN KEY (CollectorNodeID) REFERENCES mon.CollectorNodes(CollectorNodeID);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CollectorAssignments_NodeInstance' AND object_id = OBJECT_ID('mon.CollectorAssignments'))
BEGIN
    CREATE UNIQUE INDEX IX_CollectorAssignments_NodeInstance
        ON mon.CollectorAssignments (CollectorNodeID, InstanceID, CollectorGroup)
        WHERE IsEnabled = 1;
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CollectorNodeHeartbeat_NodeTime' AND object_id = OBJECT_ID('mon.CollectorNodeHeartbeat'))
BEGIN
    CREATE INDEX IX_CollectorNodeHeartbeat_NodeTime
        ON mon.CollectorNodeHeartbeat (CollectorNodeID, HeartbeatTime DESC);
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CollectionRuns_CollectorNode' AND object_id = OBJECT_ID('mon.CollectionRuns'))
BEGIN
    CREATE INDEX IX_CollectionRuns_CollectorNode
        ON mon.CollectionRuns (CollectorNodeID, StartTime DESC)
        WHERE CollectorNodeID IS NOT NULL;
END;

IF OBJECT_ID('mon.CPUHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.CPUHistory
    (
        CPUHistoryID          BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        SqlCPUPercent         DECIMAL(5,2) NULL,
        OtherCPUPercent       DECIMAL(5,2) NULL,
        IdleCPUPercent        DECIMAL(5,2) NULL
    );
END;

IF OBJECT_ID('mon.MemoryHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.MemoryHistory
    (
        MemoryHistoryID       BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        TotalPhysicalMB       BIGINT NULL,
        AvailablePhysicalMB   BIGINT NULL,
        SqlMemoryUsedGB       DECIMAL(18,2) NULL,
        PLESeconds            BIGINT NULL,
        BufferCacheHitRatio   DECIMAL(10,2) NULL
    );
END;

IF OBJECT_ID('mon.DiskVolumeHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DiskVolumeHistory
    (
        DiskHistoryID         BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        VolumeMountPoint      NVARCHAR(260) NOT NULL,
        LogicalVolumeName     NVARCHAR(260) NULL,
        TotalGB               DECIMAL(18,2) NULL,
        FreeGB                DECIMAL(18,2) NULL,
        UsedGB                DECIMAL(18,2) NULL,
        UsedPct               DECIMAL(6,2) NULL
    );
END;

IF OBJECT_ID('mon.IOFileHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.IOFileHistory
    (
        IOHistoryID           BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        DatabaseName          SYSNAME NULL,
        FileType              NVARCHAR(10) NULL,
        LogicalName           SYSNAME NULL,
        PhysicalName          NVARCHAR(260) NULL,
        SizeMB                DECIMAL(18,2) NULL,
        AvgReadMS             DECIMAL(18,2) NULL,
        AvgWriteMS            DECIMAL(18,2) NULL,
        TotalStallMS          BIGINT NULL
    );
END;

IF OBJECT_ID('mon.TempDBHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.TempDBHistory
    (
        TempDBHistoryID       BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        FileType              NVARCHAR(10) NULL,
        LogicalName           SYSNAME NULL,
        PhysicalName          NVARCHAR(260) NULL,
        SizeMB                DECIMAL(18,2) NULL,
        UsedMB                DECIMAL(18,2) NULL,
        PercentFull           DECIMAL(6,2) NULL,
        TempDBDataFileCount   INT NULL,
        RecommendedFileCount  INT NULL
    );
END;

IF OBJECT_ID('mon.BackupStatusHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BackupStatusHistory
    (
        BackupHistoryID       BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        DatabaseName          SYSNAME NOT NULL,
        LastFullHours         INT NULL,
        LastDiffHours         INT NULL,
        LastLogHours          INT NULL,
        StatusText            NVARCHAR(50) NULL
    );
END;

IF OBJECT_ID('mon.BlockingHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BlockingHistory
    (
        BlockingHistoryID     BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        SessionID             INT NULL,
        BlockingSessionID     INT NULL,
        DatabaseName          SYSNAME NULL,
        WaitType              NVARCHAR(120) NULL,
        WaitTimeMS            BIGINT NULL,
        LoginName             NVARCHAR(128) NULL,
        HostName              NVARCHAR(128) NULL,
        CommandText           NVARCHAR(64) NULL,
        StatementText         NVARCHAR(MAX) NULL
    );
END;

IF OBJECT_ID('mon.LongRunningHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.LongRunningHistory
    (
        LongRunHistoryID      BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        CaptureTime           DATETIME2 NOT NULL,
        SessionID             INT NULL,
        DatabaseName          SYSNAME NULL,
        StartTime             DATETIME2 NULL,
        DurationMinutes       INT NULL,
        StatusText            NVARCHAR(60) NULL,
        WaitType              NVARCHAR(120) NULL,
        CPUms                 BIGINT NULL,
        Reads                 BIGINT NULL,
        Writes                BIGINT NULL,
        CommandText           NVARCHAR(64) NULL,
        StatementText         NVARCHAR(MAX) NULL
    );
END;

IF OBJECT_ID('mon.AlertHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.AlertHistory
    (
        AlertID               BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID            INT NOT NULL,
        AlertTime             DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        Severity              NVARCHAR(20) NOT NULL,
        ModuleName            NVARCHAR(100) NOT NULL,
        AlertTitle            NVARCHAR(300) NOT NULL,
        AlertDetails          NVARCHAR(MAX) NULL,
        IsAcknowledged        BIT NOT NULL DEFAULT 0,
        AcknowledgedBy        NVARCHAR(128) NULL,
        AcknowledgedOn        DATETIME2 NULL
    );
END;

IF OBJECT_ID('mon.AlertThresholds', 'U') IS NULL
BEGIN
    CREATE TABLE mon.AlertThresholds
    (
        ThresholdID           INT IDENTITY(1,1) PRIMARY KEY,
        ModuleName            NVARCHAR(100) NOT NULL,
        MetricName            NVARCHAR(100) NOT NULL,
        WarningValue          DECIMAL(18,2) NULL,
        CriticalValue         DECIMAL(18,2) NULL,
        IsActive              BIT NOT NULL DEFAULT 1
    );
END;
