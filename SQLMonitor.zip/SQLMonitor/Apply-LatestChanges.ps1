param(
    [string]$RepositoryServer = "",
    [string]$RepositoryDatabase = "DBA_SQLMonitor",
    [string]$SourcePath = (Split-Path -Parent $MyInvocation.MyCommand.Path),
    [string]$InstallPath = (Split-Path -Parent $MyInvocation.MyCommand.Path),
    [switch]$UpdateSqlAgentJobs,
    [switch]$ConfigurePerInstanceJobs,
    [switch]$ConfigureWindowsTasks,
    [ValidateSet("System", "CurrentUser")]
    [string]$WindowsTaskRunAs = "System",
    [int]$WebDashboardPort = 8090,
    [switch]$Json
)

$ErrorActionPreference = "Stop"

function Write-UpdateLog {
    param([string]$Message, [string]$Level = "Info")
    if ($Json) { return }
    $color = switch ($Level) {
        "Success" { "Green" }
        "Warning" { "Yellow" }
        "Error" { "Red" }
        default { "Gray" }
    }
    Write-Host $Message -ForegroundColor $color
}

function Resolve-UpdatePath {
    param([string]$Path, [string]$Name)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw "$Name path is required." }
    $item = Get-Item -LiteralPath $Path -ErrorAction Stop
    if (-not $item.PSIsContainer) { throw "$Name path must be a directory: $Path" }
    return $item.FullName
}

try {
    $SourcePath = Resolve-UpdatePath -Path $SourcePath -Name "Source"
    if (-not (Test-Path -LiteralPath $InstallPath -PathType Container)) {
        New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    }
    $InstallPath = Resolve-UpdatePath -Path $InstallPath -Name "Install"

    $deployScript = Join-Path $SourcePath "Deploy-SQLMonitor.ps1"
    if (-not (Test-Path -LiteralPath $deployScript -PathType Leaf)) {
        throw "Deploy-SQLMonitor.ps1 was not found in source path: $SourcePath"
    }

    if ([string]::IsNullOrWhiteSpace($RepositoryServer)) {
        $commonModule = Join-Path $SourcePath "Modules\Common.psm1"
        if (Test-Path -LiteralPath $commonModule -PathType Leaf) {
            Import-Module $commonModule -Force -WarningAction SilentlyContinue
            $settings = Get-SqlMonitorRepositorySettings
            $RepositoryServer = $settings.RepositoryServer
            if ([string]::IsNullOrWhiteSpace($RepositoryDatabase)) { $RepositoryDatabase = $settings.RepositoryDatabase }
        }
    }
    if ([string]::IsNullOrWhiteSpace($RepositoryServer)) { throw "RepositoryServer is required." }
    if ([string]::IsNullOrWhiteSpace($RepositoryDatabase)) { $RepositoryDatabase = "DBA_SQLMonitor" }

    $arguments = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", $deployScript,
        "-RepositoryServer", $RepositoryServer,
        "-RepositoryDatabase", $RepositoryDatabase,
        "-InstallPath", $InstallPath,
        "-DeployDatabase",
        "-DeployScripts",
        "-SkipInstanceConfiguration",
        "-WebDashboardPort", ([string]$WebDashboardPort),
        "-Force"
    )
    if ($UpdateSqlAgentJobs) { $arguments += "-ConfigureSqlAgentJobs" }
    if ($ConfigurePerInstanceJobs) { $arguments += "-ConfigurePerInstanceJobs" }
    if ($ConfigureWindowsTasks) {
        $arguments += "-ConfigureWindowsTasks"
        $arguments += "-WindowsTaskRunAs"
        $arguments += $WindowsTaskRunAs
    }

    Write-UpdateLog "Applying latest SQL Monitor changes in place..."
    Write-UpdateLog "Source: $SourcePath"
    Write-UpdateLog "Install: $InstallPath"
    Write-UpdateLog "Repository: $RepositoryServer / $RepositoryDatabase"

    $output = & powershell.exe @arguments 2>&1
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) {
        throw "Apply latest changes failed with exit code $exitCode. $($output -join [Environment]::NewLine)"
    }

    $summary = [pscustomobject]@{
        ok = $true
        SourcePath = $SourcePath
        InstallPath = $InstallPath
        RepositoryServer = $RepositoryServer
        RepositoryDatabase = $RepositoryDatabase
        UpdatedDatabase = $true
        UpdatedApplicationFiles = $true
        UpdatedSqlAgentJobs = [bool]$UpdateSqlAgentJobs
        Output = ($output -join [Environment]::NewLine)
    }

    if ($Json) { $summary | ConvertTo-Json -Depth 5 }
    else {
        if ($output) { $output | ForEach-Object { Write-Host $_ } }
        Write-UpdateLog "Latest changes applied successfully." "Success"
    }
}
catch {
    if ($Json) {
        [pscustomobject]@{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Depth 3
    }
    else {
        Write-UpdateLog $_.Exception.Message "Error"
    }
    exit 1
}
