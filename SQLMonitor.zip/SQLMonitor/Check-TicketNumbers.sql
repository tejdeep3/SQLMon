-- Check the ticket number generation issue
SELECT TicketNumber, COUNT(*) AS Count
FROM mon.Tickets
GROUP BY TicketNumber
ORDER BY TicketNumber;

-- Check the stored procedure for ticket number generation
SELECT OBJECT_DEFINITION(OBJECT_ID('mon.usp_CreateTicketFromAlert')) AS Definition;
