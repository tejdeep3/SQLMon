-- Phase 8: Stored Procedures and Views for Task, Ticketing, and Escalation
USE [DBA_SQLMonitor]
GO

-- Prerequisites used by ticket procedures. Keep this early so fresh installs
-- can compile procedures that reference alert-to-ticket integration columns.
IF OBJECT_ID('mon.AlertHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.AlertHistory', 'IsTicketCreated') IS NULL
    BEGIN
        ALTER TABLE mon.AlertHistory
        ADD [IsTicketCreated] BIT NOT NULL
            CONSTRAINT DF_AlertHistory_IsTicketCreated DEFAULT (0);
    END;
END;
GO

IF OBJECT_ID('mon.Tickets', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.Tickets', 'BusinessService') IS NULL ALTER TABLE mon.Tickets ADD BusinessService NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'TicketType') IS NULL ALTER TABLE mon.Tickets ADD TicketType NVARCHAR(50) NOT NULL CONSTRAINT DF_Tickets_TicketType DEFAULT (N'SQL Server');
    IF COL_LENGTH('mon.Tickets', 'Category') IS NULL ALTER TABLE mon.Tickets ADD Category NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'Subcategory') IS NULL ALTER TABLE mon.Tickets ADD Subcategory NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'Impact') IS NULL ALTER TABLE mon.Tickets ADD Impact NVARCHAR(40) NULL;
    IF COL_LENGTH('mon.Tickets', 'Urgency') IS NULL ALTER TABLE mon.Tickets ADD Urgency NVARCHAR(40) NULL;
    IF COL_LENGTH('mon.Tickets', 'AssignmentGroup') IS NULL ALTER TABLE mon.Tickets ADD AssignmentGroup NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'ContactType') IS NULL ALTER TABLE mon.Tickets ADD ContactType NVARCHAR(60) NULL;
    IF COL_LENGTH('mon.Tickets', 'ExternalReference') IS NULL ALTER TABLE mon.Tickets ADD ExternalReference NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'SLADueDate') IS NULL ALTER TABLE mon.Tickets ADD SLADueDate DATETIME2(7) NULL;
    IF COL_LENGTH('mon.Tickets', 'CloseCode') IS NULL ALTER TABLE mon.Tickets ADD CloseCode NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'WorkNotes') IS NULL ALTER TABLE mon.Tickets ADD WorkNotes NVARCHAR(MAX) NULL;

    UPDATE t
    SET TicketType = N'VM'
    FROM mon.Tickets t
    WHERE t.TicketType = N'SQL Server'
      AND (t.Category = N'VM Monitoring' OR EXISTS (SELECT 1 FROM mon.AlertHistory ah WHERE ah.AlertID = t.AlertID AND ah.ModuleName LIKE N'VM:%'));
END;
GO

-- =============================================
-- TASK MANAGEMENT STORED PROCEDURES
-- =============================================

-- Create new task
CREATE OR ALTER PROCEDURE [mon].[usp_CreateTask]
    @TaskTitle NVARCHAR(255),
    @TaskDescription NVARCHAR(MAX) = NULL,
    @CreatedBy NVARCHAR(128),
    @AssignedTo NVARCHAR(128) = NULL,
    @TaskPriorityID INT = 3,
    @InstanceID INT = NULL,
    @DueDate DATETIME2(7) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO [mon].[Tasks] ([TaskTitle], [TaskDescription], [CreatedBy], [AssignedTo], 
                                 [TaskPriorityID], [InstanceID], [DueDate])
    VALUES (@TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, 
            @TaskPriorityID, @InstanceID, @DueDate);
    
    DECLARE @TaskID INT = SCOPE_IDENTITY();
    
    -- Log activity
    INSERT INTO [mon].[TaskActivities] ([TaskID], [ActivityType], [ActivityDescription], [CreatedBy])
    VALUES (@TaskID, 'Created', 'Task created: ' + @TaskTitle, @CreatedBy);
    
    SELECT @TaskID AS TaskID;
END
GO

-- Update task
CREATE OR ALTER PROCEDURE [mon].[usp_UpdateTask]
    @TaskID INT,
    @TaskTitle NVARCHAR(255) = NULL,
    @TaskDescription NVARCHAR(MAX) = NULL,
    @AssignedTo NVARCHAR(128) = NULL,
    @TaskStatusID INT = NULL,
    @TaskPriorityID INT = NULL,
    @DueDate DATETIME2(7) = NULL,
    @ModifiedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @OldStatusID INT, @OldAssignedTo NVARCHAR(128), @OldPriorityID INT;
    DECLARE @ActivityDesc NVARCHAR(MAX) = '';
    
    SELECT @OldStatusID = TaskStatusID, @OldAssignedTo = AssignedTo, @OldPriorityID = TaskPriorityID
    FROM [mon].[Tasks] WHERE TaskID = @TaskID;
    
    UPDATE [mon].[Tasks]
    SET 
        [TaskTitle] = ISNULL(@TaskTitle, [TaskTitle]),
        [TaskDescription] = ISNULL(@TaskDescription, [TaskDescription]),
        [AssignedTo] = ISNULL(@AssignedTo, [AssignedTo]),
        [TaskStatusID] = ISNULL(@TaskStatusID, [TaskStatusID]),
        [TaskPriorityID] = ISNULL(@TaskPriorityID, [TaskPriorityID]),
        [DueDate] = ISNULL(@DueDate, [DueDate]),
        [ModifiedDate] = SYSDATETIME(),
        [CompletedDate] = CASE WHEN @TaskStatusID = 4 THEN SYSDATETIME() ELSE [CompletedDate] END
    WHERE [TaskID] = @TaskID;
    
    -- Log status change
    IF @TaskStatusID IS NOT NULL AND @TaskStatusID <> @OldStatusID
    BEGIN
        SELECT @ActivityDesc = 'Status changed to: ' + [StatusName] 
        FROM [mon].[TaskStatus] WHERE TaskStatusID = @TaskStatusID;
        
        INSERT INTO [mon].[TaskActivities] ([TaskID], [ActivityType], [ActivityDescription], [CreatedBy])
        VALUES (@TaskID, 'StatusChanged', @ActivityDesc, @ModifiedBy);
    END
    
    -- Log assignment change
    IF @AssignedTo IS NOT NULL AND @AssignedTo <> @OldAssignedTo
    BEGIN
        INSERT INTO [mon].[TaskActivities] ([TaskID], [ActivityType], [ActivityDescription], [CreatedBy])
        VALUES (@TaskID, 'Reassigned', 'Task reassigned to: ' + @AssignedTo, @ModifiedBy);
    END
    
    SELECT @@ROWCOUNT AS RowsUpdated;
END
GO

-- Add task comment
CREATE OR ALTER PROCEDURE [mon].[usp_AddTaskComment]
    @TaskID INT,
    @CommentText NVARCHAR(MAX),
    @CreatedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO [mon].[TaskComments] ([TaskID], [CommentText], [CreatedBy])
    VALUES (@TaskID, @CommentText, @CreatedBy);
    
    -- Log activity
    INSERT INTO [mon].[TaskActivities] ([TaskID], [ActivityType], [ActivityDescription], [CreatedBy])
    VALUES (@TaskID, 'CommentAdded', 'Comment added by ' + @CreatedBy, @CreatedBy);
    
    SELECT SCOPE_IDENTITY() AS CommentID;
END
GO

-- Update task comment
CREATE OR ALTER PROCEDURE [mon].[usp_UpdateTaskComment]
    @CommentID INT,
    @CommentText NVARCHAR(MAX),
    @ModifiedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE [mon].[TaskComments]
    SET [CommentText] = @CommentText,
        [ModifiedBy] = @ModifiedBy,
        [ModifiedDate] = SYSDATETIME(),
        [IsEdited] = 1
    WHERE [CommentID] = @CommentID
      AND [IsActive] = 1;

    SELECT @@ROWCOUNT AS RowsUpdated;
END
GO

-- Get tasks with filters
CREATE OR ALTER PROCEDURE [mon].[usp_GetTasks]
    @AssignedTo NVARCHAR(128) = NULL,
    @CreatedBy NVARCHAR(128) = NULL,
    @TaskStatusID INT = NULL,
    @TaskPriorityID INT = NULL,
    @InstanceID INT = NULL,
    @IncludeCompleted BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        t.[TaskID],
        t.[TaskTitle],
        t.[TaskDescription],
        t.[CreatedBy],
        t.[AssignedTo],
        ts.[StatusName] AS TaskStatus,
        tp.[PriorityName] AS TaskPriority,
        tp.[PriorityOrder],
        mi.[DisplayName] AS InstanceName,
        t.[DueDate],
        t.[StartDate],
        t.[CompletedDate],
        t.[CreatedDate],
        t.[ModifiedDate],
        CASE
            WHEN t.[DueDate] < SYSDATETIME() AND t.[TaskStatusID] NOT IN (4, 5) THEN 1
            ELSE 0
        END AS IsOverdue
    FROM [mon].[Tasks] t
    INNER JOIN [mon].[TaskStatus] ts ON t.[TaskStatusID] = ts.[TaskStatusID]
    INNER JOIN [mon].[TaskPriority] tp ON t.[TaskPriorityID] = tp.[TaskPriorityID]
    LEFT JOIN [mon].[MonitoredInstances] mi ON t.[InstanceID] = mi.[InstanceID]
    WHERE t.[IsActive] = 1
      AND (@AssignedTo IS NULL OR t.[AssignedTo] = @AssignedTo)
      AND (@CreatedBy IS NULL OR t.[CreatedBy] = @CreatedBy)
      AND (@TaskStatusID IS NULL OR t.[TaskStatusID] = @TaskStatusID)
      AND (@TaskPriorityID IS NULL OR t.[TaskPriorityID] = @TaskPriorityID)
      AND (@InstanceID IS NULL OR t.[InstanceID] = @InstanceID)
      AND (@IncludeCompleted = 1 OR t.[TaskStatusID] NOT IN (4, 5))
    ORDER BY tp.[PriorityOrder], t.[DueDate];
END
GO

-- =============================================
-- TICKETING SYSTEM STORED PROCEDURES
-- =============================================

-- Generate ticket number
CREATE OR ALTER FUNCTION [mon].[ufn_GenerateTicketNumber]()
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @Year NVARCHAR(4) = YEAR(GETDATE());
    DECLARE @LastNumber INT = 0;

    SELECT @LastNumber = ISNULL(MAX(CAST(SUBSTRING([TicketNumber], LEN([TicketNumber]) - 3, 4) AS INT)), 0)
    FROM [mon].[Tickets]
    WHERE [TicketNumber] LIKE 'TKT-' + @Year + '-%';

    RETURN 'TKT-' + @Year + '-' + RIGHT('0000' + CAST(@LastNumber + 1 AS NVARCHAR(4)), 4);
END
GO

CREATE OR ALTER PROCEDURE [mon].[usp_GetNextTicketNumber]
    @TicketNumber NVARCHAR(50) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Year NVARCHAR(4) = YEAR(GETDATE());

    IF EXISTS (SELECT 1 FROM sys.sequences WHERE object_id = OBJECT_ID(N'mon.seq_TicketNumber'))
    BEGIN
        DECLARE @NextNumber BIGINT = NEXT VALUE FOR mon.seq_TicketNumber;
        SET @TicketNumber = 'TKT-' + @Year + '-' + RIGHT('000000' + CAST(@NextNumber AS NVARCHAR(10)), 6);
    END
    ELSE
    BEGIN
        DECLARE @LastNumber INT = 0;
        SELECT @LastNumber = ISNULL(MAX(CAST(SUBSTRING([TicketNumber], LEN([TicketNumber]) - 3, 4) AS INT)), 0)
        FROM [mon].[Tickets]
        WHERE [TicketNumber] LIKE 'TKT-' + @Year + '-%';
        SET @TicketNumber = 'TKT-' + @Year + '-' + RIGHT('0000' + CAST(@LastNumber + 1 AS NVARCHAR(4)), 4);
    END
END
GO

-- Create ticket from alert
CREATE OR ALTER PROCEDURE [mon].[usp_CreateTicketFromAlert]
    @AlertID BIGINT,
    @CreatedBy NVARCHAR(128),
    @TicketSeverityID INT = 3,
    @AssignedTo NVARCHAR(128) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @InstanceID INT, @AlertTitle NVARCHAR(300), @AlertDetails NVARCHAR(MAX), @ModuleName NVARCHAR(100);
    DECLARE @ExistingTicketID BIGINT, @ExistingTicketNumber NVARCHAR(50);
    
    SELECT
        @InstanceID = [InstanceID],
        @AlertTitle = [AlertTitle],
        @AlertDetails = [AlertDetails],
        @ModuleName = [ModuleName]
    FROM [mon].[AlertHistory]
    WHERE [AlertID] = @AlertID;

    IF @InstanceID IS NULL
        THROW 51000, 'AlertID was not found.', 1;

    DECLARE @TicketType NVARCHAR(50) = CASE WHEN @ModuleName LIKE N'VM:%' THEN N'VM' ELSE N'SQL Server' END;

    SELECT TOP (1)
        @ExistingTicketID = t.[TicketID],
        @ExistingTicketNumber = t.[TicketNumber]
    FROM [mon].[Tickets] t
    INNER JOIN [mon].[AlertHistory] ah ON t.[AlertID] = ah.[AlertID]
    WHERE t.[IsActive] = 1
      AND t.[TicketStatusID] IN (1, 2, 3, 6)
      AND ah.[InstanceID] = @InstanceID
      AND ah.[ModuleName] = @ModuleName
      AND ah.[AlertTitle] = @AlertTitle
    ORDER BY t.[CreatedDate] DESC, t.[TicketID] DESC;

    IF @ExistingTicketID IS NOT NULL
    BEGIN
        UPDATE ah
        SET [IsTicketCreated] = 1
        FROM [mon].[AlertHistory] ah
        WHERE ah.[IsAcknowledged] = 0
          AND ah.[InstanceID] = @InstanceID
          AND ah.[ModuleName] = @ModuleName
          AND ah.[AlertTitle] = @AlertTitle;

        SELECT @ExistingTicketID AS TicketID, @ExistingTicketNumber AS TicketNumber, CAST(1 AS BIT) AS IsExistingTicket;
        RETURN;
    END;
    
    DECLARE @TicketNumber NVARCHAR(50);
    EXEC mon.usp_GetNextTicketNumber @TicketNumber OUTPUT;
    
    INSERT INTO [mon].[Tickets] ([AlertID], [TicketNumber], [TicketType], [InstanceID], [ErrorDescription], 
                                   [TicketSeverityID], [CreatedBy], [AssignedTo])
    VALUES (@AlertID, @TicketNumber, @TicketType, @InstanceID, 
            'Alert: ' + @AlertTitle + CHAR(13) + CHAR(10) + @AlertDetails,
            @TicketSeverityID, @CreatedBy, @AssignedTo);
    
    DECLARE @TicketID BIGINT = SCOPE_IDENTITY();
    
    -- Update alert to mark as ticketed
    UPDATE ah
    SET [IsTicketCreated] = 1
    FROM [mon].[AlertHistory] ah
    WHERE ah.[IsAcknowledged] = 0
      AND ah.[InstanceID] = @InstanceID
      AND ah.[ModuleName] = @ModuleName
      AND ah.[AlertTitle] = @AlertTitle;
    
    SELECT @TicketID AS TicketID, @TicketNumber AS TicketNumber, CAST(0 AS BIT) AS IsExistingTicket;
END
GO

-- Create manual ticket
CREATE OR ALTER PROCEDURE [mon].[usp_CreateManualTicket]
    @ErrorDescription NVARCHAR(MAX),
    @CreatedBy NVARCHAR(128),
    @InstanceID INT = NULL,
    @TicketSeverityID INT = 3,
    @AssignedTo NVARCHAR(128) = NULL,
    @TicketType NVARCHAR(50) = N'SQL Server'
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @TicketNumber NVARCHAR(50);
    EXEC mon.usp_GetNextTicketNumber @TicketNumber OUTPUT;
    
    INSERT INTO [mon].[Tickets] ([TicketNumber], [TicketType], [InstanceID], [ErrorDescription], 
                                   [TicketSeverityID], [CreatedBy], [AssignedTo])
    VALUES (@TicketNumber, @TicketType, @InstanceID, @ErrorDescription, 
            @TicketSeverityID, @CreatedBy, @AssignedTo);
    
    DECLARE @TicketID BIGINT = SCOPE_IDENTITY();
    
    SELECT @TicketID AS TicketID, @TicketNumber AS TicketNumber;
END
GO

-- Acknowledge ticket
CREATE OR ALTER PROCEDURE [mon].[usp_AcknowledgeTicket]
    @TicketID BIGINT,
    @AcknowledgedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @InstanceID INT, @ModuleName NVARCHAR(100), @AlertTitle NVARCHAR(300);

    SELECT
        @InstanceID = ah.InstanceID,
        @ModuleName = ah.ModuleName,
        @AlertTitle = ah.AlertTitle
    FROM [mon].[Tickets] t
    LEFT JOIN [mon].[AlertHistory] ah ON t.[AlertID] = ah.[AlertID]
    WHERE t.[TicketID] = @TicketID;
    
    UPDATE [mon].[Tickets]
    SET 
        [TicketStatusID] = 2, -- Acknowledged
        [AcknowledgedBy] = @AcknowledgedBy,
        [AcknowledgedDate] = SYSDATETIME(),
        [ModifiedDate] = SYSDATETIME()
    WHERE [TicketID] = @TicketID AND [TicketStatusID] = 1; -- Only acknowledge 'New' tickets
    
    SELECT @@ROWCOUNT AS RowsUpdated;
END
GO

CREATE OR ALTER PROCEDURE [mon].[usp_UpdateTicketDetails]
    @TicketID BIGINT,
    @AssignedTo NVARCHAR(128) = NULL,
    @TicketStatusID INT = NULL,
    @TicketSeverityID INT = NULL,
    @BusinessService NVARCHAR(160) = NULL,
    @Category NVARCHAR(80) = NULL,
    @Subcategory NVARCHAR(80) = NULL,
    @Impact NVARCHAR(40) = NULL,
    @Urgency NVARCHAR(40) = NULL,
    @AssignmentGroup NVARCHAR(160) = NULL,
    @ContactType NVARCHAR(60) = NULL,
    @CloseCode NVARCHAR(80) = NULL,
    @ExternalReference NVARCHAR(160) = NULL,
    @SLADueDate DATETIME2(7) = NULL,
    @WorkNotes NVARCHAR(MAX) = NULL,
    @ModifiedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OldAssignedTo NVARCHAR(128), @OldStatusID INT;
    SELECT @OldAssignedTo = AssignedTo, @OldStatusID = TicketStatusID
    FROM [mon].[Tickets]
    WHERE [TicketID] = @TicketID;

    UPDATE [mon].[Tickets]
    SET [AssignedTo] = @AssignedTo,
        [TicketStatusID] = ISNULL(@TicketStatusID, [TicketStatusID]),
        [TicketSeverityID] = ISNULL(@TicketSeverityID, [TicketSeverityID]),
        [BusinessService] = @BusinessService,
        [Category] = @Category,
        [Subcategory] = @Subcategory,
        [Impact] = @Impact,
        [Urgency] = @Urgency,
        [AssignmentGroup] = @AssignmentGroup,
        [ContactType] = @ContactType,
        [CloseCode] = @CloseCode,
        [ExternalReference] = @ExternalReference,
        [SLADueDate] = @SLADueDate,
        [WorkNotes] = @WorkNotes,
        [ModifiedDate] = SYSDATETIME()
    WHERE [TicketID] = @TicketID;

    SELECT @@ROWCOUNT AS RowsUpdated,
           @OldAssignedTo AS PreviousAssignedTo,
           @OldStatusID AS PreviousStatusID;
END
GO

-- Resolve ticket
CREATE OR ALTER PROCEDURE [mon].[usp_ResolveTicket]
    @TicketID BIGINT,
    @ResolvedBy NVARCHAR(128),
    @ResolutionNotes NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @InstanceID INT, @ModuleName NVARCHAR(100), @AlertTitle NVARCHAR(300);

    SELECT
        @InstanceID = ah.[InstanceID],
        @ModuleName = ah.[ModuleName],
        @AlertTitle = ah.[AlertTitle]
    FROM [mon].[Tickets] t
    LEFT JOIN [mon].[AlertHistory] ah ON t.[AlertID] = ah.[AlertID]
    WHERE t.[TicketID] = @TicketID;
    
    UPDATE [mon].[Tickets]
    SET 
        [TicketStatusID] = 4, -- Resolved
        [ResolvedBy] = @ResolvedBy,
        [ResolvedDate] = SYSDATETIME(),
        [ResolutionNotes] = @ResolutionNotes,
        [ModifiedDate] = SYSDATETIME()
    WHERE [TicketID] = @TicketID;

    DECLARE @RowsUpdated INT = @@ROWCOUNT;
    DECLARE @AlertsClosed INT = 0;

    IF @RowsUpdated > 0 AND @InstanceID IS NOT NULL
    BEGIN
        UPDATE ah
        SET [IsAcknowledged] = 1,
            [AcknowledgedOn] = SYSDATETIME(),
            [AcknowledgedBy] = @ResolvedBy
        FROM [mon].[AlertHistory] ah
        WHERE ISNULL(ah.[IsAcknowledged], 0) = 0
          AND ah.[InstanceID] = @InstanceID
          AND ah.[ModuleName] = @ModuleName
          AND ah.[AlertTitle] = @AlertTitle;

        SET @AlertsClosed = @@ROWCOUNT;
    END;
    
    SELECT @RowsUpdated AS RowsUpdated, @AlertsClosed AS AlertsClosed;
END
GO

-- Add ticket comment
CREATE OR ALTER PROCEDURE [mon].[usp_AddTicketComment]
    @TicketID BIGINT,
    @CommentText NVARCHAR(MAX),
    @CreatedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO [mon].[TicketComments] ([TicketID], [CommentText], [CreatedBy])
    VALUES (@TicketID, @CommentText, @CreatedBy);
    
    SELECT SCOPE_IDENTITY() AS CommentID;
END
GO

-- Get tickets with filters
CREATE OR ALTER PROCEDURE [mon].[usp_GetTickets]
    @AssignedTo NVARCHAR(128) = NULL,
    @TicketStatusID INT = NULL,
    @TicketSeverityID INT = NULL,
    @InstanceID INT = NULL,
    @IncludeClosed BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        t.[TicketID],
        t.[TicketNumber],
        mi.[DisplayName] AS InstanceName,
        t.[ErrorDescription],
        ts.[StatusName] AS TicketStatus,
        tsv.[SeverityName] AS TicketSeverity,
        tsv.[SeverityOrder],
        t.[CreatedBy],
        t.[AssignedTo],
        t.[AcknowledgedBy],
        t.[AcknowledgedDate],
        t.[ResolvedBy],
        t.[ResolvedDate],
        t.[CreatedDate],
        t.[ModifiedDate]
    FROM [mon].[Tickets] t
    INNER JOIN [mon].[TicketStatus] ts ON t.[TicketStatusID] = ts.[TicketStatusID]
    INNER JOIN [mon].[TicketSeverity] tsv ON t.[TicketSeverityID] = tsv.[TicketSeverityID]
    LEFT JOIN [mon].[MonitoredInstances] mi ON t.[InstanceID] = mi.[InstanceID]
    WHERE t.[IsActive] = 1
      AND (@AssignedTo IS NULL OR t.[AssignedTo] = @AssignedTo)
      AND (@TicketStatusID IS NULL OR t.[TicketStatusID] = @TicketStatusID)
      AND (@TicketSeverityID IS NULL OR t.[TicketSeverityID] = @TicketSeverityID)
      AND (@InstanceID IS NULL OR t.[InstanceID] = @InstanceID)
      AND (@IncludeClosed = 1 OR t.[TicketStatusID] <> 5)
    ORDER BY tsv.[SeverityOrder], t.[CreatedDate] DESC;
END
GO

-- =============================================
-- ESCALATION STORED PROCEDURES
-- =============================================

-- Configure escalation rule
CREATE OR ALTER PROCEDURE [mon].[usp_ConfigureEscalation]
    @TicketSeverityID INT,
    @EscalationLevelID INT,
    @EscalationTimeMinutes INT,
    @EscalationTo NVARCHAR(256),
    @NotificationTemplate NVARCHAR(MAX) = NULL,
    @IsActive BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    
    MERGE [mon].[EscalationMatrix] AS tgt
    USING (SELECT @TicketSeverityID AS TicketSeverityID, @EscalationLevelID AS EscalationLevelID) AS src
    ON tgt.[TicketSeverityID] = src.[TicketSeverityID] AND tgt.[EscalationLevelID] = src.[EscalationLevelID]
    WHEN MATCHED THEN
        UPDATE SET 
            [EscalationTimeMinutes] = @EscalationTimeMinutes,
            [EscalationTo] = @EscalationTo,
            [NotificationTemplate] = ISNULL(@NotificationTemplate, tgt.[NotificationTemplate]),
            [IsActive] = @IsActive
    WHEN NOT MATCHED THEN
        INSERT ([TicketSeverityID], [EscalationLevelID], [EscalationTimeMinutes], [EscalationTo], [NotificationTemplate], [IsActive])
        VALUES (@TicketSeverityID, @EscalationLevelID, @EscalationTimeMinutes, @EscalationTo, @NotificationTemplate, @IsActive);
    
    SELECT @@ROWCOUNT AS RowsAffected;
END
GO

-- Record escalation
CREATE OR ALTER PROCEDURE [mon].[usp_RecordEscalation]
    @TicketID BIGINT,
    @EscalationLevelID INT,
    @EscalatedTo NVARCHAR(256),
    @EscalatedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;
    
    INSERT INTO [mon].[EscalationHistory] ([TicketID], [EscalationLevelID], [EscalatedTo], [EscalatedBy])
    VALUES (@TicketID, @EscalationLevelID, @EscalatedTo, @EscalatedBy);
    
    SELECT SCOPE_IDENTITY() AS EscalationHistoryID;
END
GO

-- Get escalation rules
CREATE OR ALTER PROCEDURE [mon].[usp_GetEscalationRules]
    @TicketSeverityID INT = NULL,
    @IsActive BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        em.[EscalationMatrixID],
        tsv.[SeverityName],
        el.[LevelName],
        em.[EscalationTimeMinutes],
        em.[EscalationTo],
        em.[NotificationTemplate],
        em.[IsActive]
    FROM [mon].[EscalationMatrix] em
    INNER JOIN [mon].[TicketSeverity] tsv ON em.[TicketSeverityID] = tsv.[TicketSeverityID]
    INNER JOIN [mon].[EscalationLevels] el ON em.[EscalationLevelID] = el.[EscalationLevelID]
    WHERE (@TicketSeverityID IS NULL OR em.[TicketSeverityID] = @TicketSeverityID)
      AND (@IsActive IS NULL OR em.[IsActive] = @IsActive)
    ORDER BY tsv.[SeverityOrder], el.[LevelOrder];
END
GO

-- =============================================
-- VIEWS
-- =============================================

-- Task details view
CREATE OR ALTER VIEW [mon].[vw_TaskDetails]
AS
SELECT
    t.[TaskID],
    t.[InstanceID],
    t.[TaskTitle],
    t.[TaskDescription],
    t.[CreatedBy],
    t.[AssignedTo],
    ts.[StatusName] AS TaskStatus,
    ts.[TaskStatusID],
    tp.[PriorityName] AS TaskPriority,
    tp.[TaskPriorityID],
    tp.[PriorityOrder],
    mi.[DisplayName] AS InstanceName,
    mi.[ServerName] AS SqlInstance,
    t.[DueDate],
    t.[StartDate],
    t.[CompletedDate],
    t.[CreatedDate],
    t.[ModifiedDate],
    CASE 
        WHEN t.[DueDate] < SYSDATETIME() AND t.[TaskStatusID] <> 4 THEN 1 
        ELSE 0 
    END AS IsOverdue
FROM [mon].[Tasks] t
INNER JOIN [mon].[TaskStatus] ts ON t.[TaskStatusID] = ts.[TaskStatusID]
INNER JOIN [mon].[TaskPriority] tp ON t.[TaskPriorityID] = tp.[TaskPriorityID]
LEFT JOIN [mon].[MonitoredInstances] mi ON t.[InstanceID] = mi.[InstanceID]
WHERE t.[IsActive] = 1;
GO

-- Open tasks view (not completed or cancelled)
CREATE OR ALTER VIEW [mon].[vw_OpenTasks]
AS
SELECT *
FROM [mon].[vw_TaskDetails]
WHERE [TaskStatusID] NOT IN (4, 5); -- Not Completed or Cancelled
GO

-- Overdue tasks view
CREATE OR ALTER VIEW [mon].[vw_OverdueTasks]
AS
SELECT *
FROM [mon].[vw_TaskDetails]
WHERE [IsOverdue] = 1 AND [TaskStatusID] NOT IN (4, 5);
GO

-- Ticket details view
CREATE OR ALTER VIEW [mon].[vw_TicketDetails]
AS
SELECT
    t.[TicketID],
    t.[InstanceID],
    t.[TicketNumber],
    t.[TicketType],
    t.[AlertID],
    ah.[AlertTitle],
    mi.[DisplayName] AS InstanceName,
    mi.[ServerName] AS SqlInstance,
    t.[ErrorDescription],
    ts.[StatusName] AS TicketStatus,
    ts.[TicketStatusID],
    tsv.[SeverityName] AS TicketSeverity,
    tsv.[TicketSeverityID],
    tsv.[SeverityOrder],
    t.[CreatedBy],
    t.[AssignedTo],
    t.[BusinessService],
    t.[Category],
    t.[Subcategory],
    t.[Impact],
    t.[Urgency],
    t.[AssignmentGroup],
    t.[ContactType],
    t.[ExternalReference],
    t.[SLADueDate],
    t.[CloseCode],
    t.[WorkNotes],
    t.[AcknowledgedBy],
    t.[AcknowledgedDate],
    t.[ResolvedBy],
    t.[ResolvedDate],
    t.[ResolutionNotes],
    t.[CreatedDate],
    t.[ModifiedDate],
    DATEDIFF(MINUTE, t.[CreatedDate], COALESCE(t.[ResolvedDate], SYSDATETIME())) AS AgeMinutes,
    CASE 
        WHEN t.[AcknowledgedDate] IS NOT NULL 
        THEN DATEDIFF(MINUTE, t.[CreatedDate], t.[AcknowledgedDate]) 
        ELSE NULL 
    END AS AcknowledgementMinutes,
    CASE 
        WHEN t.[ResolvedDate] IS NOT NULL 
        THEN DATEDIFF(MINUTE, t.[CreatedDate], t.[ResolvedDate]) 
        ELSE NULL 
    END AS ResolutionMinutes
FROM [mon].[Tickets] t
INNER JOIN [mon].[TicketStatus] ts ON t.[TicketStatusID] = ts.[TicketStatusID]
INNER JOIN [mon].[TicketSeverity] tsv ON t.[TicketSeverityID] = tsv.[TicketSeverityID]
LEFT JOIN [mon].[MonitoredInstances] mi ON t.[InstanceID] = mi.[InstanceID]
LEFT JOIN [mon].[AlertHistory] ah ON t.[AlertID] = ah.[AlertID]
WHERE t.[IsActive] = 1;
GO

-- Unacknowledged tickets view (New tickets)
CREATE OR ALTER VIEW [mon].[vw_UnacknowledgedTickets]
AS
SELECT *
FROM [mon].[vw_TicketDetails]
WHERE [TicketStatusID] = 1; -- New
GO

-- Tickets pending escalation view
CREATE OR ALTER VIEW [mon].[vw_TicketsPendingEscalation]
AS
SELECT 
    td.*,
    em.[EscalationLevelID],
    el.[LevelName] AS EscalationLevel,
    em.[EscalationTimeMinutes],
    em.[EscalationTo]
FROM [mon].[vw_TicketDetails] td
INNER JOIN [mon].[EscalationMatrix] em ON td.[TicketSeverityID] = em.[TicketSeverityID]
INNER JOIN [mon].[EscalationLevels] el ON em.[EscalationLevelID] = el.[EscalationLevelID]
WHERE td.[TicketStatusID] IN (1, 2, 3) -- New, Acknowledged, In Progress
  AND em.[IsActive] = 1
  AND td.[AgeMinutes] > em.[EscalationTimeMinutes]
  AND NOT EXISTS (
      SELECT 1 FROM [mon].[EscalationHistory] eh 
      WHERE eh.[TicketID] = td.[TicketID] 
        AND eh.[EscalationLevelID] = em.[EscalationLevelID]
  );
GO

-- Task comments view
CREATE OR ALTER VIEW [mon].[vw_TaskComments]
AS
SELECT
    tc.[CommentID],
    tc.[TaskID],
    t.[TaskTitle],
    tc.[CommentText],
    tc.[CreatedBy],
    tc.[CreatedDate],
    tc.[ModifiedBy],
    tc.[ModifiedDate],
    tc.[IsEdited]
FROM [mon].[TaskComments] tc
INNER JOIN [mon].[Tasks] t ON tc.[TaskID] = t.[TaskID]
WHERE tc.[IsActive] = 1;
GO

-- Ticket comments view
CREATE OR ALTER VIEW [mon].[vw_TicketComments]
AS
SELECT
    tc.[CommentID],
    tc.[TicketID],
    t.[TicketNumber],
    tc.[CommentText],
    tc.[CreatedBy],
    tc.[CreatedDate]
FROM [mon].[TicketComments] tc
INNER JOIN [mon].[Tickets] t ON tc.[TicketID] = t.[TicketID]
WHERE tc.[IsActive] = 1;
GO

-- Task audit trail view
CREATE OR ALTER VIEW [mon].[vw_TaskAuditTrail]
AS
SELECT
    CAST(ta.[ActivityID] AS BIGINT) AS AuditID,
    ta.[TaskID],
    t.[TaskTitle],
    ta.[CreatedDate],
    ta.[CreatedBy] AS UserName,
    ta.[ActivityType] AS ActionName,
    ta.[ActivityDescription] AS Details,
    CAST(N'TaskActivity' AS NVARCHAR(40)) AS AuditSource
FROM [mon].[TaskActivities] ta
INNER JOIN [mon].[Tasks] t ON ta.[TaskID] = t.[TaskID];
GO

-- Ticket audit trail view
CREATE OR ALTER VIEW [mon].[vw_TicketAuditTrail]
AS
SELECT
    dal.[AuditID],
    CAST(NULL AS BIGINT) AS TicketID,
    dal.[CreatedAt] AS CreatedDate,
    dal.[UserName],
    dal.[ActionName],
    dal.[Details],
    dal.[ClientHost],
    CAST(N'DashboardAudit' AS NVARCHAR(40)) AS AuditSource
FROM [mon].[DashboardAuditLog] dal
WHERE dal.[ActionName] LIKE N'%Ticket%';
GO

-- Escalation history view
CREATE OR ALTER VIEW [mon].[vw_EscalationHistory]
AS
SELECT
    eh.[EscalationHistoryID],
    eh.[TicketID],
    t.[TicketNumber],
    el.[LevelName] AS EscalationLevel,
    eh.[EscalatedTo],
    eh.[EscalatedOn],
    eh.[EscalatedBy],
    eh.[ResponseAction],
    eh.[ResponseDate]
FROM [mon].[EscalationHistory] eh
INNER JOIN [mon].[Tickets] t ON eh.[TicketID] = t.[TicketID]
INNER JOIN [mon].[EscalationLevels] el ON eh.[EscalationLevelID] = el.[EscalationLevelID]
WHERE eh.[IsActive] = 1;
GO

-- Add IsTicketCreated column to AlertHistory if not exists
IF COL_LENGTH('mon.AlertHistory', 'IsTicketCreated') IS NULL
BEGIN
    ALTER TABLE [mon].[AlertHistory]
    ADD [IsTicketCreated] BIT NOT NULL DEFAULT 0;
END
GO

PRINT 'Phase 8: Stored Procedures and Views created successfully.'
GO
