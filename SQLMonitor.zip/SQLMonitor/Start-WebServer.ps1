param(
    [int]$Port = 8090,
    [string]$RepositoryServer = '',
    [string]$RepositoryDatabase = ''
)

$ErrorActionPreference = 'Stop'

$webServerScript = Join-Path $PSScriptRoot 'Web\Start-WebServer.ps1'
if (-not (Test-Path -LiteralPath $webServerScript)) {
    throw "Web server script not found: $webServerScript"
}

& $webServerScript -Port $Port -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase
