-- Check what the escalation procedures actually do
SELECT 'usp_ConfigureEscalation' AS ProcName, 
       OBJECT_DEFINITION(OBJECT_ID('mon.usp_ConfigureEscalation')) AS Definition;

-- Check if there's a procedure to process escalations
SELECT ROUTINE_NAME, ROUTINE_TYPE
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_SCHEMA = 'mon'
  AND (ROUTINE_NAME LIKE '%Escalat%' OR ROUTINE_NAME LIKE '%Process%Escalat%')
ORDER BY ROUTINE_NAME;

-- Check the vw_TicketsPendingEscalation view to understand what needs to be processed
SELECT OBJECT_DEFINITION(OBJECT_ID('mon.vw_TicketsPendingEscalation')) AS ViewDef;
