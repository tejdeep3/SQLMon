@echo off
REM Launch-PatchManager.bat
REM Launches the Patch Manager

echo Starting Patch Manager...
echo.

cd /d "%~dp0"

if "%1"=="download" (
    echo Downloading patches...
    powershell.exe -ExecutionPolicy Bypass -File ".\Jobs\Run-PatchManager.ps1" -DownloadPatches
) else (
    echo Checking patch status only...
    powershell.exe -ExecutionPolicy Bypass -File ".\Jobs\Run-PatchManager.ps1"
)

echo.
echo Patch Manager completed.
pause