-- Get the full stored procedure definition
SELECT OBJECT_DEFINITION(OBJECT_ID('mon.usp_ProcessTicketEscalations')) AS ProcText;
GO

-- Check if there are tickets that meet escalation criteria
SELECT COUNT(*) AS TicketsReadyToEscalate
FROM [mon].[Tickets] t
JOIN [mon].[EscalationMatrix] em ON t.TicketSeverityID = em.TicketSeverityID
WHERE t.TicketStatusID = 1  -- Open tickets
  AND em.IsActive = 1
  AND em.EscalationLevelID > ISNULL(t.EscalationLevelID, 0)
  AND DATEDIFF(MINUTE, t.CreatedDate, SYSUTCDATETIME()) >= em.EscalationTimeMinutes;

-- Show some examples
SELECT TOP 5
    t.TicketID,
    t.TicketNumber,
    ts.SeverityName,
    em.EscalationLevelID AS NextLevel,
    em.EscalationTimeMinutes,
    DATEDIFF(MINUTE, t.CreatedDate, SYSUTCDATETIME()) AS AgeMinutes
FROM [mon].[Tickets] t
JOIN [mon].[TicketSeverity] ts ON t.TicketSeverityID = ts.TicketSeverityID
JOIN [mon].[EscalationMatrix] em ON t.TicketSeverityID = em.TicketSeverityID
WHERE t.TicketStatusID = 1
  AND em.IsActive = 1
  AND em.EscalationLevelID > ISNULL(t.EscalationLevelID, 0)
ORDER BY AgeMinutes DESC;
