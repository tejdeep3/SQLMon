@echo off
REM SQL Monitor Web Dashboard Launcher

set "PORT=%~1"
if "%PORT%"=="" set "PORT=8090"

echo Starting SQL Monitor Web Dashboard...
echo.
echo Requested URL: http://localhost:%PORT%/
echo If that port is busy, the server will print the alternate URL.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "Web\Start-WebServer.ps1" -Port %PORT%

pause
