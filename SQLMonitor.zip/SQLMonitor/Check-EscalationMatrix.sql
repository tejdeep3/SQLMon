-- Check escalation matrix data
SELECT em.*, 
       ts.SeverityName, 
       em.EscalationLevelID,
       em.EscalationTo
FROM mon.EscalationMatrix em 
JOIN mon.TicketSeverity ts ON em.TicketSeverityID = ts.TicketSeverityID 
WHERE em.IsActive = 1
ORDER BY em.TicketSeverityID, em.EscalationLevelID;

-- Check pending escalations view
SELECT COUNT(*) AS PendingEscalationCount 
FROM mon.vw_TicketsPendingEscalation;

-- Check tickets that need escalation
SELECT TOP 10 * 
FROM mon.vw_TicketsPendingEscalation
ORDER BY MinutesSinceLastEscalation DESC;
