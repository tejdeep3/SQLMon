-- Phase8B: Alert to Ticket Integration
-- This script adds the missing column to AlertHistory and creates the auto-conversion trigger/procedure

USE [DBA_SQLMonitor]
GO

-- =============================================
-- ADD MISSING COLUMN TO ALERTHISTORY
-- =============================================

-- Add IsTicketCreated column to AlertHistory if it doesn't exist
IF COL_LENGTH('mon.AlertHistory', 'IsTicketCreated') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD IsTicketCreated BIT NOT NULL
        CONSTRAINT DF_AlertHistory_IsTicketCreated DEFAULT (0);
    
    PRINT 'Added IsTicketCreated column to mon.AlertHistory';
END
GO

-- Add index for performance on the auto-conversion query
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AlertHistory_IsTicketCreated')
BEGIN
    CREATE INDEX [IX_AlertHistory_IsTicketCreated] 
    ON [mon].[AlertHistory] ([IsTicketCreated])
    INCLUDE ([AlertID], [InstanceID], [Severity], [AlertTitle], [AlertDetails]);
    PRINT 'Created index IX_AlertHistory_IsTicketCreated';
END
GO

IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD RepeatCount INT NOT NULL
        CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
    PRINT 'Added RepeatCount column to mon.AlertHistory';
END
GO

IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD FirstAlertTime DATETIME2 NULL;
    PRINT 'Added FirstAlertTime column to mon.AlertHistory';
END
GO

IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD LastRepeatedAt DATETIME2 NULL;
    PRINT 'Added LastRepeatedAt column to mon.AlertHistory';
END
GO

UPDATE mon.AlertHistory
SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
    LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
    RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
WHERE FirstAlertTime IS NULL
   OR LastRepeatedAt IS NULL
   OR ISNULL(RepeatCount, 0) < 1;
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AlertHistory_OpenFingerprint')
BEGIN
    CREATE INDEX [IX_AlertHistory_OpenFingerprint]
    ON [mon].[AlertHistory] ([IsAcknowledged], [InstanceID], [ModuleName], [AlertTitle], [AlertTime] DESC)
    INCLUDE ([Severity], [IsTicketCreated], [RepeatCount], [FirstAlertTime], [LastRepeatedAt]);
    PRINT 'Created index IX_AlertHistory_OpenFingerprint';
END
GO

-- =============================================
-- CREATE AUTO-CONVERSION STORED PROCEDURE
-- =============================================

-- Stored procedure to auto-convert alerts to tickets
CREATE OR ALTER PROCEDURE [mon].[usp_AutoConvertAlertsToTickets]
    @HoursBack INT = 24,
    @CreatedBy NVARCHAR(128) = 'system',
    @TicketsCreated INT = 0 OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @AlertID BIGINT, @Severity NVARCHAR(20);
    DECLARE @TicketSeverityID INT;
    DECLARE @created TABLE (TicketID BIGINT, TicketNumber NVARCHAR(50), IsExistingTicket BIT);
    
    -- Cursor to process unacknowledged alerts without tickets
    DECLARE alert_cursor CURSOR FAST_FORWARD FOR
    WITH candidates AS
    (
        SELECT
            ah.[AlertID],
            ah.[Severity],
            ROW_NUMBER() OVER (
                PARTITION BY ah.[InstanceID], ah.[ModuleName], ah.[AlertTitle]
                ORDER BY CASE ah.[Severity] WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, ah.[AlertTime] DESC, ah.[AlertID] DESC
            ) AS rn
        FROM [mon].[AlertHistory] ah
        WHERE ah.[IsAcknowledged] = 0
          AND (ah.[IsTicketCreated] = 0 OR ah.[IsTicketCreated] IS NULL)
          AND ah.[AlertTime] > DATEADD(HOUR, -@HoursBack, SYSDATETIME())
          AND NOT EXISTS (
              SELECT 1
              FROM [mon].[Tickets] t
              INNER JOIN [mon].[AlertHistory] sourceAlert ON t.[AlertID] = sourceAlert.[AlertID]
              WHERE t.[IsActive] = 1
                AND t.[TicketStatusID] IN (1, 2, 3, 6)
                AND sourceAlert.[InstanceID] = ah.[InstanceID]
                AND sourceAlert.[ModuleName] = ah.[ModuleName]
                AND sourceAlert.[AlertTitle] = ah.[AlertTitle]
          )
    )
    SELECT [AlertID], [Severity]
    FROM candidates
    WHERE rn = 1;
    
    SET @TicketsCreated = 0;
    
    OPEN alert_cursor;
    FETCH NEXT FROM alert_cursor INTO @AlertID, @Severity;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Map severity to TicketSeverityID
            SELECT @TicketSeverityID = 
                CASE 
                    WHEN @Severity = 'Critical' THEN 1
                    WHEN @Severity = 'High' THEN 2
                    WHEN @Severity = 'Medium' THEN 3
                    WHEN @Severity = 'Low' THEN 4
                    ELSE 3 -- Default to Medium
                END;
            
            DELETE FROM @created;
            INSERT INTO @created
            EXEC [mon].[usp_CreateTicketFromAlert]
                @AlertID = @AlertID,
                @CreatedBy = @CreatedBy,
                @TicketSeverityID = @TicketSeverityID,
                @AssignedTo = NULL;

            IF EXISTS (SELECT 1 FROM @created WHERE IsExistingTicket = 0)
                SET @TicketsCreated = @TicketsCreated + 1;
        END TRY
        BEGIN CATCH
            PRINT 'Error creating ticket from alert ' + CAST(@AlertID AS VARCHAR(20)) + ': ' + ERROR_MESSAGE();
        END CATCH
        
        FETCH NEXT FROM alert_cursor INTO @AlertID, @Severity;
    END
    
    CLOSE alert_cursor;
    DEALLOCATE alert_cursor;
    
    PRINT 'Auto-conversion completed. Created ' + CAST(@TicketsCreated AS VARCHAR(10)) + ' ticket(s).';
END
GO

-- =============================================
-- CREATE VIEW FOR PENDING ALERT-TO-TICKET CONVERSION
-- =============================================

CREATE OR ALTER VIEW [mon].[vw_AlertsPendingTicketCreation]
AS
WITH candidates AS
(
SELECT 
    ah.[AlertID],
    ah.[InstanceID],
    i.[DisplayName] AS InstanceName,
    ah.[AlertTime],
    ah.[Severity],
    ah.[ModuleName],
    ah.[AlertTitle],
    ah.[AlertDetails],
    ah.[IsAcknowledged],
    ah.[IsTicketCreated],
    SUM(ISNULL(ah.[RepeatCount], 1)) OVER (PARTITION BY ah.[InstanceID], ah.[ModuleName], ah.[AlertTitle]) AS RepeatCount,
    ROW_NUMBER() OVER (
        PARTITION BY ah.[InstanceID], ah.[ModuleName], ah.[AlertTitle]
        ORDER BY CASE ah.[Severity] WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, ah.[AlertTime] DESC, ah.[AlertID] DESC
    ) AS rn
FROM [mon].[AlertHistory] ah
LEFT JOIN [mon].[MonitoredInstances] i ON ah.[InstanceID] = i.[InstanceID]
WHERE ah.[IsAcknowledged] = 0
  AND (ah.[IsTicketCreated] = 0 OR ah.[IsTicketCreated] IS NULL)
  AND ah.[AlertTime] > DATEADD(HOUR, -24, SYSUTCDATETIME())
  AND NOT EXISTS (
      SELECT 1
      FROM [mon].[Tickets] t
      INNER JOIN [mon].[AlertHistory] sourceAlert ON t.[AlertID] = sourceAlert.[AlertID]
      WHERE t.[IsActive] = 1
        AND t.[TicketStatusID] IN (1, 2, 3, 6)
        AND sourceAlert.[InstanceID] = ah.[InstanceID]
        AND sourceAlert.[ModuleName] = ah.[ModuleName]
        AND sourceAlert.[AlertTitle] = ah.[AlertTitle]
  )
)
SELECT
    [AlertID],
    [InstanceID],
    InstanceName,
    [AlertTime],
    [Severity],
    [ModuleName],
    [AlertTitle],
    [AlertDetails],
    [IsAcknowledged],
    [IsTicketCreated],
    RepeatCount
FROM candidates
WHERE rn = 1;
GO

PRINT 'Phase8B: Alert to Ticket Integration completed successfully!';
GO
