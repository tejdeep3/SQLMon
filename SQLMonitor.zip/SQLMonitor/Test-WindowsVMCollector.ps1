# Test script for Windows VM Collector
# This script tests the new file-based collector and verifies database storage

param(
    [switch]$TestFileOutput = $false,
    [switch]$TestDatabaseStorage = $false
)

$ErrorActionPreference = 'Stop'

Write-Host "Testing Windows VM Collector..." -ForegroundColor Cyan

# Import required modules
$projectRoot = $PSScriptRoot
Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-WindowsVM.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-WindowsVM-FileBased.psm1') -Force

# Test 1: Test file-based collection
if ($TestFileOutput) {
    Write-Host "`n=== Testing File-Based Collection ===" -ForegroundColor Yellow
    
    $outputDir = "C:\Temp\VMTest"
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }
    
    try {
        # Use the collector with file output
        $repository = Get-SqlMonitorRepositorySettings
        
        Invoke-WindowsVMCollector-FileBased `
            -RepositoryServer $repository.RepositoryServer `
            -RepositoryDatabase $repository.RepositoryDatabase `
            -ComputerName $env:COMPUTERNAME `
            -TopNProcesses 10 `
            -EventHours 6 `
            -PerfSampleSeconds 2 `
            -PerfSamples 2 `
            -MaxStoppedServices 20 `
            -OutDir $outputDir `
            -EvaluateAlerts $false `
            -AutoCreateTickets $false
        
        Write-Host "✓ File-based collection successful" -ForegroundColor Green
        Write-Host "  Files created in: $outputDir" -ForegroundColor Gray
        
        # List created files
        Get-ChildItem $outputDir | ForEach-Object {
            Write-Host "  - $($_.Name)" -ForegroundColor Gray
        }
        
        # Clean up
        Remove-Item $outputDir -Recurse -Force | Out-Null
        Write-Host "  ✓ Test files cleaned up" -ForegroundColor Green
    }
    catch {
        Write-Host "✗ File-based collection failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

# Test 2: Test database storage
if ($TestDatabaseStorage) {
    Write-Host "`n=== Testing Database Storage ===" -ForegroundColor Yellow
    
    try {
        # Test database connection
        $repository = Get-SqlMonitorRepositorySettings
        Write-Host "✓ Database connection successful: $($repository.RepositoryServer)\$($repository.RepositoryDatabase)" -ForegroundColor Green
        
        # Test collection with database storage
        Invoke-WindowsVMCollector-FileBased `
            -RepositoryServer $repository.RepositoryServer `
            -RepositoryDatabase $repository.RepositoryDatabase `
            -ComputerName $env:COMPUTERNAME `
            -TopNProcesses 10 `
            -EventHours 6 `
            -PerfSampleSeconds 2 `
            -PerfSamples 2 `
            -MaxStoppedServices 20 `
            -EvaluateAlerts $false `
            -AutoCreateTickets $false
        
        Write-Host "✓ Database storage successful" -ForegroundColor Green
        
        # Verify data was stored
        $query = @"
SELECT TOP 5 
    ps.CaptureTime, 
    ps.CPUPercent, 
    ps.MemoryUsedPercent, 
    ps.HealthScore, 
    ps.HealthPosture,
    t.ComputerName
FROM mon.WindowsPerformanceSamples ps
INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
WHERE t.ComputerName = '$($env:COMPUTERNAME)'
ORDER BY ps.CaptureTime DESC
"@
        
        $results = Invoke-MonitorSqlQuery -ServerInstance $repository.RepositoryServer -Database $repository.RepositoryDatabase -Query $query
        
        if ($results.Rows.Count -gt 0) {
            Write-Host "✓ Data verification successful - found $($results.Rows.Count) recent records" -ForegroundColor Green
            $results.Rows | ForEach-Object {
                Write-Host "  - $($_.ComputerName) at $($_.CaptureTime): CPU=$($_.CPUPercent)%, Memory=$($_.MemoryUsedPercent)%, Score=$($_.HealthScore)" -ForegroundColor Gray
            }
        }
        else {
            Write-Host "⚠ No data found in database" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "✗ Database storage failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Cyan
Write-Host "If both tests passed, the Windows VM collector is working correctly." -ForegroundColor Gray