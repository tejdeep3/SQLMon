-- Add or repair the current escalation level marker on tickets.
-- Tickets store the current escalation level, so the FK belongs to the
-- EscalationLevels lookup table, not EscalationMatrix. EscalationMatrix is
-- keyed by severity + level and can contain repeated EscalationLevelID values.
USE [DBA_SQLMonitor]
GO

IF OBJECT_ID('mon.Tickets', 'U') IS NULL
BEGIN
    THROW 51000, 'mon.Tickets is not deployed. Run Phase8_TaskTicketEscalation.sql first.', 1;
END;
GO

IF EXISTS (
    SELECT 1
    FROM sys.foreign_keys
    WHERE parent_object_id = OBJECT_ID('mon.Tickets')
      AND name = 'FK_Tickets_EscalationLevel'
)
BEGIN
    ALTER TABLE [mon].[Tickets] DROP CONSTRAINT [FK_Tickets_EscalationLevel];
END;
GO

IF COL_LENGTH('mon.Tickets', 'EscalationLevelID') IS NULL
BEGIN
    ALTER TABLE [mon].[Tickets] ADD [EscalationLevelID] INT NULL;
END;
GO

IF OBJECT_ID('mon.EscalationLevels', 'U') IS NOT NULL
AND NOT EXISTS (
    SELECT 1
    FROM sys.foreign_keys
    WHERE parent_object_id = OBJECT_ID('mon.Tickets')
      AND name = 'FK_Tickets_EscalationLevel'
)
BEGIN
    ALTER TABLE [mon].[Tickets] WITH CHECK
    ADD CONSTRAINT [FK_Tickets_EscalationLevel]
        FOREIGN KEY ([EscalationLevelID])
        REFERENCES [mon].[EscalationLevels] ([EscalationLevelID]);
END;
GO

IF COL_LENGTH('mon.Tickets', 'EscalationLevelID') IS NOT NULL
AND NOT EXISTS (
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID('mon.Tickets')
      AND name = 'IX_Tickets_EscalationLevelID'
)
BEGIN
    CREATE INDEX [IX_Tickets_EscalationLevelID]
    ON [mon].[Tickets]([EscalationLevelID]);
END;
GO

PRINT 'EscalationLevelID column and lookup foreign key are ready on mon.Tickets.';
GO
