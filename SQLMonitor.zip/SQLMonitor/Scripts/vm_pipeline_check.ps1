# End-to-end VM monitoring pipeline check
Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$srv = $repo.RepositoryServer
$db = $repo.RepositoryDatabase

Write-Host "=== Repository: $srv\$db ===" -ForegroundColor Cyan

# 1) Check stored procedures
Write-Host "`n--- Stored Procedures ---" -ForegroundColor Yellow
$procs = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query @"
SELECT name, create_date, modify_date 
FROM sys.procedures 
WHERE schema_id = SCHEMA_ID('mon') 
AND name LIKE '%Windows%'
ORDER BY name
"@
if ($procs.Rows.Count -eq 0) { Write-Host "  (none found)" -ForegroundColor Red }
foreach ($r in $procs.Rows) { Write-Host "  $($r.name)  created=$($r.create_date)  modified=$($r.modify_date)" }

# 2) Check mon.WindowsTargets
Write-Host "`n--- VM Targets ---" -ForegroundColor Yellow
$targets = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT TargetID, ComputerName, DisplayName, IsActive, CollectionIntervalMinutes FROM mon.WindowsTargets"
if ($targets.Rows.Count -eq 0) { Write-Host "  (no targets found)" -ForegroundColor Red }
foreach ($r in $targets.Rows) { Write-Host "  TargetID=$($r.TargetID)  ComputerName=$($r.ComputerName)  DisplayName=$($r.DisplayName)  IsActive=$($r.IsActive)  Interval=$($r.CollectionIntervalMinutes)m" }

# 3) Check mon.WindowsPerformanceSamples
Write-Host "`n--- Performance Samples ---" -ForegroundColor Yellow
$count = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT COUNT(1) FROM mon.WindowsPerformanceSamples"
Write-Host "  Total rows: $count"
if ($count -gt 0) {
    $latest = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT TOP 5 CaptureTime, CPUPercent, MemoryUsedPercent, DiskUsedPercent, HealthScore, HealthPosture FROM mon.WindowsPerformanceSamples ORDER BY CaptureTime DESC"
    foreach ($r in $latest.Rows) {
        Write-Host "  $($r.CaptureTime)  CPU=$($r.CPUPercent)%  Mem=$($r.MemoryUsedPercent)%  Disk=$($r.DiskUsedPercent)%  Score=$($r.HealthScore)  Posture=$($r.HealthPosture)"
    }
}

# 4) Check mon.WindowsInventory
Write-Host "`n--- Windows Inventory ---" -ForegroundColor Yellow
$invCount = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT COUNT(1) FROM mon.WindowsInventory"
Write-Host "  Total rows: $invCount"

# 5) Check VM-related scheduled tasks on this machine
Write-Host "`n--- Scheduled Tasks ---" -ForegroundColor Yellow
Get-ScheduledTask -TaskName 'SQLMonitor-WindowsVMCollectors' -ErrorAction SilentlyContinue | Select-Object TaskName, State, @{N='NextRun';E={(Get-ScheduledTaskInfo $_).NextRunTime}} | Format-List

# 6) Check VM config
Write-Host "`n--- VM Configuration ---" -ForegroundColor Yellow
try {
    $vmConfig = Get-SqlMonitorVMs
    Write-Host "  VMs in config: $($vmConfig.Count)"
    foreach ($vm in $vmConfig) {
        Write-Host "  VM: $($vm.DisplayName)  Enabled=$($vm.IsEnabled)"
        foreach ($inst in $vm.SQLInstances) {
            Write-Host "    SQL: $($inst.DisplayName)  Server=$($inst.SqlInstance)  Active=$($inst.IsActive)"
        }
    }
} catch {
    Write-Host "  ERROR: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== Check Complete ===" -ForegroundColor Cyan
