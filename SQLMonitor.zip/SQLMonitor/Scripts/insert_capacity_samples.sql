-- ============================================================
-- Debug: Insert sample data for capacity forecasting
-- Run this directly in SSMS against DBA_SQLMonitor
-- ============================================================

-- Check current state
SELECT 'WindowsTargets' AS Info, COUNT(*) AS Cnt FROM mon.WindowsTargets;
SELECT 'PerformanceSamples' AS Info, COUNT(*) AS Cnt FROM mon.WindowsPerformanceSamples;
SELECT 'MemorySamples' AS Info, COUNT(*) AS Cnt FROM mon.WindowsPerformanceSamples WHERE MemoryUsedPercent IS NOT NULL;
SELECT 'DiskSamples' AS Info, COUNT(*) AS Cnt FROM mon.WindowsPerformanceSamples WHERE DiskUsedPercent IS NOT NULL;
SELECT 'ForecastRows' AS Info, COUNT(*) AS Cnt FROM mon.WindowsCapacityForecast;

-- Get the target ID
DECLARE @TargetID INT = (SELECT TOP 1 TargetID FROM mon.WindowsTargets WHERE IsEnabled = 1);
PRINT 'TargetID: ' + ISNULL(CAST(@TargetID AS VARCHAR), 'NONE');

-- Delete existing samples for clean test
-- DELETE FROM mon.WindowsPerformanceSamples WHERE TargetID = @TargetID;

-- Insert 10 days of samples with gradual disk growth and memory variation
DECLARE @Day INT = 10;
DECLARE @Hour INT;
DECLARE @CaptureTime DATETIME2(0);
DECLARE @DiskUsed DECIMAL(6,2);
DECLARE @MemUsed DECIMAL(6,2);
DECLARE @DiskFree DECIMAL(18,2);
DECLARE @CpuUsed DECIMAL(6,2);
DECLARE @HealthScore INT;
DECLARE @Posture NVARCHAR(30);

WHILE @Day >= 0
BEGIN
    SET @Hour = 0;
    WHILE @Hour < 24
    BEGIN
        SET @CaptureTime = DATEADD(DAY, -@Day, CAST(GETDATE() AS DATE)) + DATEADD(HOUR, @Hour, 0);
        
        -- Simulate disk growth: 65% -> 75% over 10 days
        SET @DiskUsed = 65.0 + (10 - @Day) * 1.0 + (ABS(CHECKSUM(NEWID())) % 50) / 10.0;
        IF @DiskUsed > 99 SET @DiskUsed = 99;
        
        -- Simulate memory: 70% -> 82% over 10 days
        SET @MemUsed = 70.0 + (10 - @Day) * 1.2 + (ABS(CHECKSUM(NEWID())) % 40) / 10.0;
        IF @MemUsed > 99 SET @MemUsed = 99;
        
        SET @DiskFree = 140.0 - (@DiskUsed / 100.0 * 140.0);
        SET @CpuUsed = 30.0 + (ABS(CHECKSUM(NEWID())) % 500) / 10.0;
        IF @CpuUsed > 95 SET @CpuUsed = 95;
        
        SET @HealthScore = 100 - CAST(@DiskUsed AS INT) + 20;
        IF @HealthScore > 100 SET @HealthScore = 100;
        IF @HealthScore < 0 SET @HealthScore = 0;
        
        SET @Posture = CASE 
            WHEN @HealthScore >= 85 THEN 'Healthy'
            WHEN @HealthScore >= 60 THEN 'Warning'
            ELSE 'Critical'
        END;
        
        INSERT INTO mon.WindowsPerformanceSamples
            (TargetID, CaptureTime, CPUPercent, MemoryUsedPercent, DiskUsedPercent, DiskFreeGB, HealthScore, HealthPosture)
        VALUES
            (@TargetID, @CaptureTime, @CpuUsed, @MemUsed, @DiskUsed, @DiskFree, @HealthScore, @Posture);
        
        SET @Hour = @Hour + 6; -- Every 6 hours
    END
    SET @Day = @Day - 1;
END

PRINT 'Sample data inserted.';

-- Verify
SELECT 'After Insert' AS Info, COUNT(*) AS TotalSamples, 
       COUNT(DISTINCT CAST(CaptureTime AS DATE)) AS DistinctDays,
       SUM(CASE WHEN MemoryUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS MemSamples,
       SUM(CASE WHEN DiskUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS DiskSamples
FROM mon.WindowsPerformanceSamples;

-- Run forecast
EXEC mon.usp_CalculateWindowsCapacityForecast @TargetID = NULL, @LookbackDays = 90;

-- Check results
SELECT 'Forecast Results' AS Info, COUNT(*) AS Cnt FROM mon.WindowsCapacityForecast;
SELECT * FROM mon.vw_WindowsCapacityDashboard;
