Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$srv = $repo.RepositoryServer
$db = $repo.RepositoryDatabase

$tables = @(
    'mon.WindowsDiskSamples',
    'mon.WindowsServiceSamples',
    'mon.WindowsHotFixSamples',
    'mon.WindowsNetworkAdapterSamples',
    'mon.WindowsProcessSamples',
    'mon.WindowsEventSamples',
    'mon.WindowsPerfCounterSamples'
)

Write-Host "=== Extended VM Schema Tables ===" -ForegroundColor Cyan
foreach ($t in $tables) {
    $exists = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT CASE WHEN OBJECT_ID('$t','U') IS NULL THEN 0 ELSE 1 END"
    $status = if ($exists -eq 1) { "EXISTS" } else { "MISSING" }
    $color = if ($exists -eq 1) { 'Green' } else { 'Red' }
    Write-Host "  $t : $status" -ForegroundColor $color
}
