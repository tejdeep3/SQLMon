$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $projectRoot "Modules\Common.psm1") -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$srv = $repo.RepositoryServer
$db = $repo.RepositoryDatabase
Write-Host "=== Repository: $srv / $db ===" -ForegroundColor Cyan
function Show-Table {
    param([System.Data.DataTable]$Table)
    if ($Table -and $Table.Rows.Count -gt 0) {
        foreach ($r in $Table.Rows) {
            $props = @()
            foreach ($c in $Table.Columns) { $props += "$($c.ColumnName)=$($r[$c.ColumnName])" }
            Write-Host "  " + ($props -join " | ")
        }
    } else { Write-Host "  No data" }
}
Write-Host "`n--- Windows Targets ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT TargetID, ComputerName, DisplayName, IsEnabled FROM mon.WindowsTargets ORDER BY DisplayName;" -CommandTimeout 15)
Write-Host "`n--- Sample Counts ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT t.DisplayName, COUNT(*) AS TotalSamples, COUNT(DISTINCT CAST(ps.CaptureTime AS DATE)) AS DistinctDays, MIN(ps.CaptureTime) AS EarliestSample, MAX(ps.CaptureTime) AS LatestSample, SUM(CASE WHEN ps.DiskUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS DiskSamples, SUM(CASE WHEN ps.MemoryUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS MemorySamples FROM mon.WindowsPerformanceSamples ps INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID WHERE t.IsEnabled = 1 GROUP BY t.TargetID, t.DisplayName ORDER BY t.DisplayName;" -CommandTimeout 15)
Write-Host "`n--- Forecast Table (before) ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.WindowsCapacityForecast;" -CommandTimeout 15)
Write-Host "`n--- Dashboard View (before) ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.vw_WindowsCapacityDashboard;" -CommandTimeout 15)
Write-Host "`n--- Running Forecast Procedure ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "EXEC mon.usp_CalculateWindowsCapacityForecast @TargetID = NULL, @LookbackDays = 90;" -CommandTimeout 120)
Write-Host "`n--- Forecast Table (after) ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.WindowsCapacityForecast;" -CommandTimeout 15)
Write-Host "`n--- Dashboard View (after) ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.vw_WindowsCapacityDashboard;" -CommandTimeout 15)
Write-Host "`n--- Daily Disk Detail ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT TargetID, CAST(CaptureTime AS DATE) AS SampleDate, MAX(DiskUsedPercent) AS MaxDisk, MIN(DiskFreeGB) AS MinFree FROM mon.WindowsPerformanceSamples WHERE DiskUsedPercent IS NOT NULL GROUP BY TargetID, CAST(CaptureTime AS DATE) ORDER BY TargetID, SampleDate;" -CommandTimeout 15)
Write-Host "`n--- Daily Memory Detail ---" -ForegroundColor Yellow
Show-Table (Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT TargetID, CAST(CaptureTime AS DATE) AS SampleDate, MAX(MemoryUsedPercent) AS MaxMem FROM mon.WindowsPerformanceSamples WHERE MemoryUsedPercent IS NOT NULL GROUP BY TargetID, CAST(CaptureTime AS DATE) ORDER BY TargetID, SampleDate;" -CommandTimeout 15)
Write-Host "`n=== Done ===" -ForegroundColor Cyan
