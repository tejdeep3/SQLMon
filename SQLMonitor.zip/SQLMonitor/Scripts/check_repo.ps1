# Check repository for stored proc and WindowsPerformanceSamples count
Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force
$repo = Get-SqlMonitorRepositorySettings
$usp = Invoke-MonitorSqlScalar -ServerInstance $repo.RepositoryServer -Database $repo.RepositoryDatabase -Query "SELECT CASE WHEN OBJECT_ID('mon.usp_GetWindowsPerformanceTrend','P') IS NULL THEN 0 ELSE 1 END"
Write-Host "usp_exists=$usp"
$count = Invoke-MonitorSqlScalar -ServerInstance $repo.RepositoryServer -Database $repo.RepositoryDatabase -Query "SELECT COUNT(1) FROM mon.WindowsPerformanceSamples"
Write-Host "sample_count=$count"
