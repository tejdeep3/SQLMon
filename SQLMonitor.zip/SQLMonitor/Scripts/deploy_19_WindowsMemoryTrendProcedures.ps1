# Deploy Sql/19_WindowsMemoryTrendProcedures.sql to repository by splitting GO batches
Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force
$repo = Get-SqlMonitorRepositorySettings
$sqlPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'Sql\19_WindowsMemoryTrendProcedures.sql'
if (-not (Test-Path $sqlPath)) { throw "SQL file not found: $sqlPath" }
$sql = Get-Content -Path $sqlPath -Raw
$batches = $sql -split "(?mi)^[\s]*GO[\s]*$"
$batchIndex = 0
foreach ($batch in $batches) {
    $batchIndex++
    if ([string]::IsNullOrWhiteSpace($batch)) { continue }
    Write-Host "Executing batch $batchIndex..."
    try {
        Invoke-MonitorSqlNonQuery -ServerInstance $repo.RepositoryServer -Database $repo.RepositoryDatabase -Query $batch -CommandTimeout 120
    }
    catch {
        Write-Host "Batch $batchIndex failed: $($_.Exception.Message)" -ForegroundColor Red
        throw
    }
}
Write-Host 'Deployment complete.' -ForegroundColor Green
