# Test script for capacity forecasting and baseline anomaly detection
Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$srv = $repo.RepositoryServer
$db = $repo.RepositoryDatabase

Write-Host "=== Testing Capacity Forecasting & Baseline Anomaly Detection ===" -ForegroundColor Cyan

# 1) Check tables exist
Write-Host "`n--- Checking tables ---" -ForegroundColor Yellow
$tables = @('mon.WindowsPerformanceBaseline', 'mon.WindowsCapacityForecast', 'mon.WindowsAnomalyLog')
foreach ($t in $tables) {
    $exists = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT CASE WHEN OBJECT_ID('$t','U') IS NULL THEN 'MISSING' ELSE 'EXISTS' END"
    Write-Host "  $t : $exists"
}

# 2) Check views exist
Write-Host "`n--- Checking views ---" -ForegroundColor Yellow
$views = @('mon.vw_WindowsAnomalySummary', 'mon.vw_WindowsCapacityDashboard', 'mon.vw_WindowsBaselineSummary')
foreach ($v in $views) {
    $exists = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT CASE WHEN OBJECT_ID('$v','V') IS NULL THEN 'MISSING' ELSE 'EXISTS' END"
    Write-Host "  $v : $exists"
}

# 3) Check stored procedures exist
Write-Host "`n--- Checking stored procedures ---" -ForegroundColor Yellow
$procs = @('usp_CalculateWindowsBaselines', 'usp_DetectWindowsAnomalies', 'usp_CalculateWindowsCapacityForecast')
foreach ($p in $procs) {
    $exists = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT CASE WHEN OBJECT_ID('mon.$p','P') IS NULL THEN 'MISSING' ELSE 'EXISTS' END"
    Write-Host "  mon.$p : $exists"
}

# 4) Insert synthetic sample data for testing (simulate 14 days of samples)
Write-Host "`n--- Inserting synthetic sample data (14 days) ---" -ForegroundColor Yellow
$targetId = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT TOP 1 TargetID FROM mon.WindowsTargets"
if ($targetId) {
    $inserted = 0
    for ($day = 14; $day -ge 0; $day--) {
        $baseDate = (Get-Date).AddDays(-$day)
        # Insert 4 samples per day (every 6 hours)
        for ($hour = 0; $hour -lt 24; $hour += 6) {
            $captureTime = $baseDate.Date.AddHours($hour)
            # Simulate gradual disk growth (70% -> 78% over 14 days)
            $diskBase = 70.0 + (14 - $day) * 0.57
            $diskUsed = [math]::Round($diskBase + (Get-Random -Minimum -2.0 -Maximum 2.0), 2)
            $cpuUsed = [math]::Round(40 + (Get-Random -Minimum -15 -Maximum 40), 2)
            $memUsed = [math]::Round(75 + (Get-Random -Minimum -5 -Maximum 10), 2)
            $diskFree = [math]::Round(140 - ($diskUsed / 100 * 140), 2)
            $healthScore = [math]::Max(0, [math]::Min(100, [int](100 - $diskUsed + 20)))
            $posture = if ($healthScore -ge 85) { 'Healthy' } elseif ($healthScore -ge 60) { 'Warning' } else { 'Critical' }

            $sql = @"
EXEC mon.usp_InsertWindowsPerformanceSample
    @TargetID = @TargetID,
    @CaptureTime = @CaptureTime,
    @CPUPercent = @CPUPercent,
    @MemoryUsedPercent = @MemoryUsedPercent,
    @DiskUsedPercent = @DiskUsedPercent,
    @DiskFreeGB = @DiskFreeGB,
    @HealthScore = @HealthScore,
    @HealthPosture = @HealthPosture;
"@
            Invoke-MonitorSqlNonQuery -ServerInstance $srv -Database $db -Query $sql -Parameters @{
                TargetID = $targetId
                CaptureTime = $captureTime
                CPUPercent = $cpuUsed
                MemoryUsedPercent = $memUsed
                DiskUsedPercent = $diskUsed
                DiskFreeGB = $diskFree
                HealthScore = $healthScore
                HealthPosture = $posture
            }
            $inserted++
        }
    }
    Write-Host "  Inserted $inserted synthetic samples."
} else {
    Write-Host "  No targets found. Skipping sample insertion." -ForegroundColor Red
}

# 5) Run baseline calculation
Write-Host "`n--- Running baseline calculation ---" -ForegroundColor Yellow
try {
    $result = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "EXEC mon.usp_CalculateWindowsBaselines @TargetID = NULL, @LookbackDays = 30;" -CommandTimeout 120
    if ($result -is [System.Data.DataTable] -and $result.Rows.Count -gt 0) {
        Write-Host "  Baselines updated: $($result.Rows[0].BaselinesUpdated)"
    }
} catch {
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
}

# 6) Run anomaly detection
Write-Host "`n--- Running anomaly detection ---" -ForegroundColor Yellow
try {
    $result = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "EXEC mon.usp_DetectWindowsAnomalies @TargetID = NULL, @StdDevThreshold = 2.5;" -CommandTimeout 120
    if ($result -is [System.Data.DataTable] -and $result.Rows.Count -gt 0) {
        Write-Host "  Anomalies detected: $($result.Rows[0].AnomaliesDetected)"
    }
} catch {
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
}

# 7) Run capacity forecast
Write-Host "`n--- Running capacity forecast ---" -ForegroundColor Yellow
try {
    $result = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "EXEC mon.usp_CalculateWindowsCapacityForecast @TargetID = NULL, @LookbackDays = 90;" -CommandTimeout 120
    if ($result -is [System.Data.DataTable] -and $result.Rows.Count -gt 0) {
        Write-Host "  Forecasts updated: $($result.Rows[0].ForecastsUpdated)"
    }
} catch {
    Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
}

# 8) Query results
Write-Host "`n--- Capacity Forecast Results ---" -ForegroundColor Yellow
$forecasts = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.vw_WindowsCapacityDashboard"
if ($forecasts.Rows.Count -eq 0) { Write-Host "  (no forecasts)" }
foreach ($r in $forecasts.Rows) {
    Write-Host "  $($r.DisplayName) | $($r.MetricName) | Current: $($r.CurrentValue)% | Growth: $($r.GrowthRatePerDay)/day | Exhaustion: $($r.ForecastExhaustionDate) | Days: $($r.DaysUntilExhaustion) | Confidence: $($r.ConfidencePercent)%"
    Write-Host "    Action: $($r.RecommendedAction)"
}

Write-Host "`n--- Baseline Summary ---" -ForegroundColor Yellow
$baselines = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.vw_WindowsBaselineSummary"
if ($baselines.Rows.Count -eq 0) { Write-Host "  (no baselines)" }
foreach ($r in $baselines.Rows) {
    Write-Host "  $($r.DisplayName) | $($r.MetricName) | Avg: $($r.CurrentHourAvg) | StdDev: $($r.CurrentHourStdDev) | Samples: $($r.SampleCount)"
}

Write-Host "`n--- Anomaly Summary ---" -ForegroundColor Yellow
$anomalies = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.vw_WindowsAnomalySummary"
if ($anomalies.Rows.Count -eq 0) { Write-Host "  (no anomalies)" }
foreach ($r in $anomalies.Rows) {
    Write-Host "  $($r.DisplayName) | $($r.MetricName) | Actual: $($r.ActualValue) | Baseline: $($r.BaselineAvg) | Deviation: $($r.DeviationMultiplier)x | Severity: $($r.Severity)"
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Cyan
