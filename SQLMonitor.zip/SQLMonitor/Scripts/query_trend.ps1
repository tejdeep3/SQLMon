Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$rows = Invoke-MonitorSqlQuery -ServerInstance $repo.RepositoryServer -Database $repo.RepositoryDatabase -Query "EXEC mon.usp_GetWindowsPerformanceTrend @TopSamples = 240;"
if ($rows -is [System.Data.DataTable]) {
    $objRows = @()
    foreach ($r in $rows.Rows) {
        $h = @{}
        foreach ($c in $rows.Columns) { $val = $r[$c.ColumnName]; if ($val -is [System.DBNull]) { $val = $null }; $h[$c.ColumnName] = $val }
        $objRows += [pscustomobject]$h
    }
    $objRows | ConvertTo-Json -Depth 6
}
else {
    $rows | ConvertTo-Json -Depth 6
}
