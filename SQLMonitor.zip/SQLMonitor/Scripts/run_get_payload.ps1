Import-Module 'Modules\Common.psm1' -Force -WarningAction SilentlyContinue
. .\Web\Start-WebServer.ps1
$repo = Get-SqlMonitorRepositorySettings
$script:RepositoryServer = $repo.RepositoryServer
$script:RepositoryDatabase = $repo.RepositoryDatabase
$payload = Get-WindowsMonitoringPayload
$payload | ConvertTo-Json -Depth 6
