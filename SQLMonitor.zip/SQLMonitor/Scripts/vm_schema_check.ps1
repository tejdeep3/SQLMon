Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$srv = $repo.RepositoryServer
$db = $repo.RepositoryDatabase

Write-Host "=== mon.WindowsTargets columns ===" -ForegroundColor Cyan
$cols = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query @"
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'mon' AND TABLE_NAME = 'WindowsTargets'
ORDER BY ORDINAL_POSITION
"@
foreach ($r in $cols.Rows) { Write-Host "  $($r.COLUMN_NAME)  $($r.DATA_TYPE)  nullable=$($r.IS_NULLABLE)" }

Write-Host "`n=== mon.WindowsTargets data ===" -ForegroundColor Cyan
$targets = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.WindowsTargets"
if ($targets.Rows.Count -eq 0) { Write-Host "  (empty)" -ForegroundColor Red }
foreach ($r in $targets.Rows) {
    $h = @{}
    foreach ($c in $targets.Columns) { $h[$c.ColumnName] = $r[$c.ColumnName] }
    Write-Host "  $($h | ConvertTo-Json -Compress)"
}

Write-Host "`n=== mon.WindowsPerformanceSamples columns ===" -ForegroundColor Cyan
$cols2 = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query @"
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'mon' AND TABLE_NAME = 'WindowsPerformanceSamples'
ORDER BY ORDINAL_POSITION
"@
foreach ($r in $cols2.Rows) { Write-Host "  $($r.COLUMN_NAME)  $($r.DATA_TYPE)  nullable=$($r.IS_NULLABLE)" }

Write-Host "`n=== mon.WindowsInventory columns ===" -ForegroundColor Cyan
$cols3 = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query @"
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'mon' AND TABLE_NAME = 'WindowsInventory'
ORDER BY ORDINAL_POSITION
"@
foreach ($r in $cols3.Rows) { Write-Host "  $($r.COLUMN_NAME)  $($r.DATA_TYPE)  nullable=$($r.IS_NULLABLE)" }

Write-Host "`n=== VM-related stored procs (full list) ===" -ForegroundColor Cyan
$procs = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query @"
SELECT name 
FROM sys.procedures 
WHERE schema_id = SCHEMA_ID('mon') 
AND name LIKE '%Windows%' OR name LIKE '%VM%' OR name LIKE '%vm%'
ORDER BY name
"@
foreach ($r in $procs.Rows) { Write-Host "  $($r.name)" }

Write-Host "`n=== Check for usp_InsertWindowsPerformanceSample ===" -ForegroundColor Cyan
$uspInsert = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT CASE WHEN OBJECT_ID('mon.usp_InsertWindowsPerformanceSample','P') IS NULL THEN 'MISSING' ELSE 'EXISTS' END"
Write-Host "  mon.usp_InsertWindowsPerformanceSample: $uspInsert"

Write-Host "`n=== Check for usp_GetWindowsPerformanceTrend ===" -ForegroundColor Cyan
$uspTrend = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT CASE WHEN OBJECT_ID('mon.usp_GetWindowsPerformanceTrend','P') IS NULL THEN 'MISSING' ELSE 'EXISTS' END"
Write-Host "  mon.usp_GetWindowsPerformanceTrend: $uspTrend"
