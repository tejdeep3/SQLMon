Import-Module (Join-Path (Split-Path -Parent $PSScriptRoot) 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$ready = Test-WindowsExtendedSchemaReady -RepositoryServer $repo.RepositoryServer -RepositoryDatabase $repo.RepositoryDatabase
Write-Host "extendedSchemaReady=$ready"

# Check which tables exist
$tables = @('mon.WindowsNetworkAdapterStats','mon.WindowsNetworkConnectionSamples','mon.WindowsFirewallStatus','mon.WindowsPatchBaseline')
foreach ($t in $tables) {
    $exists = Invoke-MonitorSqlScalar -ServerInstance $repo.RepositoryServer -Database $repo.RepositoryDatabase -Query "SELECT CASE WHEN OBJECT_ID('$t','U') IS NULL THEN 'MISSING' ELSE 'EXISTS' END"
    Write-Host "$t : $exists"
}
