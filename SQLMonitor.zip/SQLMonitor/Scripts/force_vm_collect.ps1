$projectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\Collect-WindowsVM.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\Collect-WindowsVM-FileBased.psm1') -Force -WarningAction SilentlyContinue

$repo = Get-SqlMonitorRepositorySettings
Invoke-WindowsVMCollector-FileBased `
    -RepositoryServer $repo.RepositoryServer `
    -RepositoryDatabase $repo.RepositoryDatabase `
    -ComputerName @('BBLBHLAP860') `
    -EvaluateAlerts $false `
    -AutoCreateTickets $false
