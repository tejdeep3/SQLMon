$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
$repo = Get-SqlMonitorRepositorySettings
$srv = $repo.RepositoryServer
$db = $repo.RepositoryDatabase

Write-Host "=== Inserting capacity forecast sample data ===" -ForegroundColor Cyan

# Get target ID
$targetId = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT TOP 1 TargetID FROM mon.WindowsTargets WHERE IsEnabled = 1;" -CommandTimeout 10
if (-not $targetId) {
    Write-Host "ERROR: No enabled Windows targets found!" -ForegroundColor Red
    exit 1
}
Write-Host "TargetID: $targetId"

# Check existing samples
$existing = Invoke-MonitorSqlScalar -ServerInstance $srv -Database $db -Query "SELECT COUNT(*) FROM mon.WindowsPerformanceSamples WHERE TargetID = $targetId;" -CommandTimeout 10
Write-Host "Existing samples: $existing"

# Insert 10 days of samples with memory data
$inserted = 0
for ($day = 10; $day -ge 0; $day--) {
    for ($hour = 0; $hour -lt 24; $hour += 6) {
        $captureTime = (Get-Date).AddDays(-$day).Date.AddHours($hour).ToString('yyyy-MM-dd HH:mm:ss')
        
        # Disk: 65% -> 75% over 10 days with some variance
        $diskUsed = [math]::Round(65.0 + (10 - $day) * 1.0 + (Get-Random -Minimum -20 -Maximum 20) / 10.0, 2)
        if ($diskUsed -gt 99) { $diskUsed = 99 }
        if ($diskUsed -lt 0) { $diskUsed = 0 }
        
        # Memory: 70% -> 82% over 10 days with some variance
        $memUsed = [math]::Round(70.0 + (10 - $day) * 1.2 + (Get-Random -Minimum -15 -Maximum 15) / 10.0, 2)
        if ($memUsed -gt 99) { $memUsed = 99 }
        if ($memUsed -lt 0) { $memUsed = 0 }
        
        $diskFree = [math]::Round(140.0 - ($diskUsed / 100.0 * 140.0), 2)
        $cpuUsed = [math]::Round(30 + (Get-Random -Minimum 0 -Maximum 500) / 10.0, 2)
        if ($cpuUsed -gt 95) { $cpuUsed = 95 }
        
        $healthScore = [math]::Max(0, [math]::Min(100, [int](100 - $diskUsed + 20)))
        $posture = if ($healthScore -ge 85) { 'Healthy' } elseif ($healthScore -ge 60) { 'Warning' } else { 'Critical' }
        
        $sql = "EXEC mon.usp_InsertWindowsPerformanceSample @TargetID = @TargetID, @CaptureTime = @CaptureTime, @CPUPercent = @CPUPercent, @MemoryUsedPercent = @MemoryUsedPercent, @DiskUsedPercent = @DiskUsedPercent, @DiskFreeGB = @DiskFreeGB, @HealthScore = @HealthScore, @HealthPosture = @HealthPosture;"
        
        Invoke-MonitorSqlNonQuery -ServerInstance $srv -Database $db -Query $sql -Parameters @{
            TargetID = [int]$targetId
            CaptureTime = $captureTime
            CPUPercent = $cpuUsed
            MemoryUsedPercent = $memUsed
            DiskUsedPercent = $diskUsed
            DiskFreeGB = $diskFree
            HealthScore = $healthScore
            HealthPosture = $posture
        } -CommandTimeout 30
        
        $inserted++
    }
    Write-Host "  Day -$day : inserted 4 samples"
}

Write-Host "`nInserted $inserted samples." -ForegroundColor Green

# Verify
$verify = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT COUNT(*) AS Total, SUM(CASE WHEN MemoryUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS MemSamples, SUM(CASE WHEN DiskUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS DiskSamples FROM mon.WindowsPerformanceSamples WHERE TargetID = $targetId;" -CommandTimeout 10
foreach ($r in $verify.Rows) {
    Write-Host "Total=$($r.Total) MemSamples=$($r.MemSamples) DiskSamples=$($r.DiskSamples)"
}

# Run forecast
Write-Host "`nRunning forecast..." -ForegroundColor Yellow
$fc = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "EXEC mon.usp_CalculateWindowsCapacityForecast @TargetID = NULL, @LookbackDays = 90;" -CommandTimeout 120
foreach ($r in $fc.Rows) {
    Write-Host "ForecastsUpdated: $($r.ForecastsUpdated)"
}

# Check results
$results = Invoke-MonitorSqlQuery -ServerInstance $srv -Database $db -Query "SELECT * FROM mon.vw_WindowsCapacityDashboard;" -CommandTimeout 10
if ($results.Rows.Count -gt 0) {
    Write-Host "`n=== Forecast Results ===" -ForegroundColor Green
    foreach ($r in $results.Rows) {
        Write-Host "  $($r.DisplayName) | $($r.MetricName) | Current=$($r.CurrentValue)% | Growth=$($r.GrowthRatePerDay)/day | Days=$($r.DaysUntilExhaustion) | $($r.RecommendedAction)"
    }
} else {
    Write-Host "`nWARNING: Still no forecast rows!" -ForegroundColor Red
}

Write-Host "`n=== Done ===" -ForegroundColor Cyan
