@echo off
REM SQL Monitor Repository self-healing upgrade

set "REPO_SERVER=%~1"
set "REPO_DB=%~2"

if "%REPO_SERVER%"=="" set "REPO_SERVER="
if "%REPO_DB%"=="" set "REPO_DB="

echo Starting SQL Monitor repository upgrade...
echo.

rem Ensure MonitoredInstances is passed as an empty array when not supplied
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Upgrade-SQLMonitorRepository.ps1" -RepositoryServer "%REPO_SERVER%" -RepositoryDatabase "%REPO_DB%" -InstallPath "%~dp0" -MonitoredInstances @() -UpdateSqlAgentJobs

pause
