-- Configure default escalation rules for SQLMonitor
USE [DBA_SQLMonitor]
GO

-- Clear existing rules (optional - comment out if you want to keep existing)
-- DELETE FROM [mon].[EscalationMatrix];

-- Insert default escalation rules
-- Critical tickets: Escalate every 30 minutes
INSERT INTO [mon].[EscalationMatrix] ([TicketSeverityID], [EscalationLevelID], [EscalationTimeMinutes], [EscalationTo], [NotificationTemplate], [IsActive])
VALUES 
(1, 1, 30, 'dba-team@company.com', 'Critical ticket {TicketNumber} needs immediate attention. Title: {Title}. Please acknowledge within 30 minutes.', 1),
(1, 2, 60, 'senior-dba@company.com', 'Critical ticket {TicketNumber} has been escalated to Level 2. Title: {Title}. Please respond immediately.', 1),
(1, 3, 120, 'dba-manager@company.com', 'Critical ticket {TicketNumber} has been escalated to Management. Title: {Title}. SLA breach imminent.', 1);

-- High priority tickets: Escalate every 2 hours
INSERT INTO [mon].[EscalationMatrix] ([TicketSeverityID], [EscalationLevelID], [EscalationTimeMinutes], [EscalationTo], [NotificationTemplate], [IsActive])
VALUES 
(2, 1, 120, 'dba-team@company.com', 'High priority ticket {TicketNumber} requires attention. Title: {Title}. Please acknowledge within 2 hours.', 1),
(2, 2, 240, 'senior-dba@company.com', 'High priority ticket {TicketNumber} has been escalated to Level 2. Title: {Title}.', 1);

-- Medium priority tickets: Escalate every 4 hours
INSERT INTO [mon].[EscalationMatrix] ([TicketSeverityID], [EscalationLevelID], [EscalationTimeMinutes], [EscalationTo], [NotificationTemplate], [IsActive])
VALUES 
(3, 1, 240, 'dba-team@company.com', 'Ticket {TicketNumber} needs attention. Title: {Title}.', 1);

-- Low priority tickets: Escalate every 8 hours
INSERT INTO [mon].[EscalationMatrix] ([TicketSeverityID], [EscalationLevelID], [EscalationTimeMinutes], [EscalationTo], [NotificationTemplate], [IsActive])
VALUES 
(4, 1, 480, 'dba-team@company.com', 'Low priority ticket {TicketNumber} is pending. Title: {Title}.', 1);

PRINT 'Default escalation rules inserted successfully.';
GO

-- Verify the rules
SELECT 
    em.EscalationMatrixID,
    ts.SeverityName,
    el.LevelName,
    em.EscalationTimeMinutes,
    em.EscalationTo,
    em.IsActive
FROM [mon].[EscalationMatrix] em
JOIN [mon].[TicketSeverity] ts ON em.TicketSeverityID = ts.TicketSeverityID
JOIN [mon].[EscalationLevels] el ON em.EscalationLevelID = el.EscalationLevelID
ORDER BY ts.SeverityOrder, el.LevelOrder;
GO
