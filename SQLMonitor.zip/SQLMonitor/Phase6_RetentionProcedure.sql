USE DBA_SQLMonitor;
GO

CREATE OR ALTER PROCEDURE mon.usp_PurgeRetention
    @CoreDays INT = 30,
    @AdvancedDays INT = 45,
    @DailyDays INT = 60,
    @AlertDays INT = 90,
    @RunHistoryDays INT = 30
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Now DATETIME2 = SYSDATETIME();

    -- ===== CORE HISTORY (30 days default) =====
    DELETE FROM mon.CPUHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.MemoryHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.DiskVolumeHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.IOFileHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.TempDBHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.BackupStatusHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.BlockingHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.LongRunningHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.KPIHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.ConfigHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    DELETE FROM mon.DBOptionsHistory
    WHERE CaptureTime < DATEADD(DAY, -@CoreDays, @Now);

    -- ===== ADVANCED PERFORMANCE HISTORY (45 days default) =====
    DELETE FROM dbo.WaitStats
    WHERE CollectionDateTime < DATEADD(DAY, -@AdvancedDays, @Now);

    DELETE FROM dbo.TopQueries
    WHERE CollectionDateTime < DATEADD(DAY, -@AdvancedDays, @Now);

    DELETE FROM dbo.MissingIndexes
    WHERE CollectionDateTime < DATEADD(DAY, -@AdvancedDays, @Now);

    -- ===== DAILY / OPERATIONAL HISTORY (60 days default) =====
    DELETE FROM dbo.IndexFragmentation
    WHERE CollectionDateTime < DATEADD(DAY, -@DailyDays, @Now);

    DELETE FROM mon.AgentJobHistory
    WHERE CaptureTime < DATEADD(DAY, -@DailyDays, @Now);

    DELETE FROM mon.DeadlockHistory
    WHERE CaptureTime < DATEADD(DAY, -@DailyDays, @Now);

    DELETE FROM mon.AGOverviewHistory
    WHERE CaptureTime < DATEADD(DAY, -@DailyDays, @Now);

    DELETE FROM mon.AGReplicaHistory
    WHERE CaptureTime < DATEADD(DAY, -@DailyDays, @Now);

    DELETE FROM mon.AGDatabaseHistory
    WHERE CaptureTime < DATEADD(DAY, -@DailyDays, @Now);

    DELETE FROM mon.ListenerHistory
    WHERE CaptureTime < DATEADD(DAY, -@DailyDays, @Now);

    DELETE FROM mon.EndpointHistory
    WHERE CaptureTime < DATEADD(DAY, -@DailyDays, @Now);

    -- ===== ALERTS (90 days default) =====
    DELETE FROM mon.AlertHistory
    WHERE AlertTime < DATEADD(DAY, -@AlertDays, @Now);

    -- ===== COLLECTION RUN HISTORY (30 days default) =====
    DELETE FROM mon.CollectionRuns
    WHERE StartTime < DATEADD(DAY, -@RunHistoryDays, @Now);
END
GO