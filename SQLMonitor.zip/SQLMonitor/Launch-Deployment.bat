@echo off
REM SQL Monitor Deployment Center Launcher

set "ROOT=%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%ROOT%GUI\SQLMonitorDeployment.ps1"

if errorlevel 1 (
    echo.
    echo Error launching deployment center. Press any key to exit.
    pause
)

exit /b 0
