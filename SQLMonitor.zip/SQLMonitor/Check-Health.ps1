# SQL Monitor - Collection Health Check
# Run this to verify all collectors are working properly.

$ErrorActionPreference = 'Stop'

$projectRoot = $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-HealthCheck.psm1') -Force

$instances = @(Get-SqlMonitorInstances)
$repositorySettings = Get-SqlMonitorRepositorySettings -Instances $instances

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host '  SQL Monitor - Collection Health Check' -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

foreach ($instance in $instances) {
    Write-Host "`nChecking: $($instance.DisplayName)" -ForegroundColor Yellow
    Write-Host "Server: $($instance.SqlInstance)`n" -ForegroundColor Gray

    $health = Get-CollectionHealth -Instance $instance -IncludeOK

    if ($health -and $health.Rows.Count -gt 0) {
        $healthy = ($health.Rows | Where-Object { $_['HealthStatus'] -eq 'Healthy' }).Count
        $warning = ($health.Rows | Where-Object { $_['HealthStatus'] -eq 'Warning' }).Count
        $critical = ($health.Rows | Where-Object { $_['HealthStatus'] -eq 'Critical' }).Count
        $never = ($health.Rows | Where-Object { $_['HealthStatus'] -eq 'Never Collected' }).Count

        Write-Host '  Health Summary:' -ForegroundColor White
        Write-Host "    Healthy: $healthy" -ForegroundColor Green
        if ($warning -gt 0) { Write-Host "    Warning: $warning" -ForegroundColor Yellow }
        if ($critical -gt 0) { Write-Host "    Critical: $critical" -ForegroundColor Red }
        if ($never -gt 0) { Write-Host "    Never Collected: $never" -ForegroundColor DarkGray }
        Write-Host ''

        $issues = $health.Rows | Where-Object { $_['HealthStatus'] -ne 'Healthy' } | Sort-Object { $_['MinutesAgo'] } -Descending

        if ($issues.Count -gt 0) {
            Write-Host '  Issues Found:' -ForegroundColor Red
            foreach ($issue in $issues) {
                $statusColor = if ($issue['HealthStatus'] -eq 'Critical') {
                    'Red'
                }
                elseif ($issue['HealthStatus'] -eq 'Warning') {
                    'Yellow'
                }
                else {
                    'DarkGray'
                }

                $statusIcon = if ($issue['HealthStatus'] -eq 'Critical') {
                    '[CRIT]'
                }
                elseif ($issue['HealthStatus'] -eq 'Warning') {
                    '[WARN]'
                }
                elseif ($issue['HealthStatus'] -eq 'Never Collected') {
                    '[NEVER]'
                }
                else {
                    '[OK]'
                }

                Write-Host "    $statusIcon $($issue['ModuleName'])" -ForegroundColor $statusColor -NoNewline
                Write-Host " - Last run: $(if ($issue['MinutesAgo'] -gt 0) { "$($issue['MinutesAgo']) min ago" } else { 'Never' })" -ForegroundColor Gray

                if ($issue['LastStatus'] -eq 'Failed' -and -not [string]::IsNullOrWhiteSpace([string]$issue['ErrorMessage'])) {
                    Write-Host "           Error: $($issue['ErrorMessage'])" -ForegroundColor DarkRed
                }
            }
        }
        else {
            Write-Host '  [OK] All collectors are healthy.' -ForegroundColor Green
        }
    }
    else {
        Write-Host '  [WARN] No collection data found' -ForegroundColor Yellow
    }

    Write-Host '  ----------------------------------------' -ForegroundColor DarkGray
}

Write-Host "`nHealth check complete.`n" -ForegroundColor Cyan
Write-Host 'Quick Commands:' -ForegroundColor Yellow
Write-Host "  View detailed health:    Get-Content '$((Get-SqlMonitorLogPath))' -Tail 50" -ForegroundColor Gray
Write-Host "  Check collection runs:   sqlcmd -S $($repositorySettings.RepositoryServer) -d $($repositorySettings.RepositoryDatabase) -Q `"SELECT * FROM mon.vw_CollectionHealth ORDER BY MinutesAgo DESC`"" -ForegroundColor Gray
Write-Host "  View gaps:               sqlcmd -S $($repositorySettings.RepositoryServer) -d $($repositorySettings.RepositoryDatabase) -Q `"SELECT * FROM mon.vw_CollectionGaps`"" -ForegroundColor Gray
Write-Host ''
