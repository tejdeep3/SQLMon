-- Check if the stored procedure exists and get its definition
SELECT ROUTINE_NAME, ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_SCHEMA = 'mon' AND ROUTINE_NAME = 'usp_ProcessTicketEscalations';

-- Check if there are any tickets that qualify for escalation
SELECT COUNT(*) AS TicketsNeedingEscalation
FROM [mon].[Tickets] t
WHERE t.TicketStatusID = 1  -- Open tickets only
  AND EXISTS (
    SELECT 1 FROM [mon].[EscalationMatrix] em
    WHERE em.TicketSeverityID = t.TicketSeverityID
      AND em.IsActive = 1
      AND em.EscalationLevelID > ISNULL(t.EscalationLevelID, 0)
  );

-- Check the actual data
SELECT TOP 5 
    t.TicketID, 
    t.TicketNumber, 
    t.TicketSeverityID,
    t.EscalationLevelID,
    ts.SeverityName
FROM [mon].[Tickets] t
JOIN [mon].[TicketSeverity] ts ON t.TicketSeverityID = ts.TicketSeverityID
WHERE t.TicketStatusID = 1;
