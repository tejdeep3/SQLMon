$connStr='Server=BBLBHLAP860\\BBDBTESTSQL;Database=DBA_SQLMonitor;Integrated Security=True;TrustServerCertificate=True;'
$conn = New-Object System.Data.SqlClient.SqlConnection $connStr
$cmd = $conn.CreateCommand()
$cmd.CommandText="UPDATE mon.DashboardUsers SET FailedLoginCount=0, LockoutUntil=NULL WHERE UserName='admin'"
$conn.Open()
$cmd.ExecuteNonQuery()
$conn.Close()
Write-Host 'Admin lockout reset'