USE DBA_SQLMonitor;
GO

IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD RepeatCount INT NOT NULL
        CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
END
GO

IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD FirstAlertTime DATETIME2 NULL;
END
GO

IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD LastRepeatedAt DATETIME2 NULL;
END
GO

UPDATE mon.AlertHistory
SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
    LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
    RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
WHERE FirstAlertTime IS NULL
   OR LastRepeatedAt IS NULL
   OR ISNULL(RepeatCount, 0) < 1;
GO

CREATE OR ALTER VIEW mon.vw_OpenAlertsDetailed
AS
WITH ranked AS
(
    SELECT
        ah.AlertID,
        ah.InstanceID,
        mi.DisplayName,
        ah.AlertTime,
        ah.Severity,
        ah.ModuleName,
        ah.AlertTitle,
        ah.AlertDetails,
        ah.IsAcknowledged,
        SUM(ISNULL(ah.RepeatCount, 1)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS RepeatCount,
        MIN(COALESCE(ah.FirstAlertTime, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS FirstAlertTime,
        MAX(COALESCE(ah.LastRepeatedAt, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS LastRepeatedAt,
        ROW_NUMBER() OVER (
            PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle
            ORDER BY CASE ah.Severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, ah.AlertTime DESC, ah.AlertID DESC
        ) AS rn
    FROM mon.AlertHistory ah
    INNER JOIN mon.MonitoredInstances mi
        ON ah.InstanceID = mi.InstanceID
    WHERE ah.IsAcknowledged = 0
)
SELECT
    AlertID,
    InstanceID,
    DisplayName,
    AlertTime,
    DATEDIFF(MINUTE, FirstAlertTime, GETDATE()) as AlertAgeMinutes,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    RepeatCount,
    FirstAlertTime,
    LastRepeatedAt
FROM ranked
WHERE rn = 1;
GO

CREATE OR ALTER VIEW mon.vw_AlertSummary
AS
SELECT
    mi.InstanceID,
    mi.DisplayName,
    COUNT(ah.AlertID) AS OpenAlertCount,
    SUM(CASE WHEN ah.Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
    SUM(CASE WHEN ah.Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
FROM mon.MonitoredInstances mi
LEFT JOIN mon.vw_OpenAlertsDetailed ah
    ON mi.InstanceID = ah.InstanceID
GROUP BY mi.InstanceID, mi.DisplayName;
GO

CREATE OR ALTER VIEW mon.vw_OverviewWithAlerts
AS
SELECT
    o.InstanceID,
    o.DisplayName,
    o.CpuCaptureTime,
    o.SqlCPUPercent,
    o.OtherCPUPercent,
    o.IdleCPUPercent,
    o.MemoryCaptureTime,
    o.TotalPhysicalMB,
    o.AvailablePhysicalMB,
    o.SqlMemoryUsedGB,
    o.PLESeconds,
    o.BufferCacheHitRatio,
    ISNULL(a.OpenAlertCount, 0) AS OpenAlertCount,
    ISNULL(a.CriticalAlertCount, 0) AS CriticalAlertCount,
    ISNULL(a.WarningAlertCount, 0) AS WarningAlertCount
FROM mon.vw_Overview o
LEFT JOIN mon.vw_AlertSummary a
    ON o.InstanceID = a.InstanceID;
GO

-- Alert History Detailed View for Dashboard
CREATE OR ALTER VIEW mon.vw_AlertHistoryDetailed
AS
SELECT
    ah.AlertID,
    ah.InstanceID,
    mi.DisplayName,
    ah.AlertTime,
    ah.Severity,
    ah.ModuleName,
    ah.AlertTitle,
    ah.AlertDetails,
    ah.IsAcknowledged,
    ah.AcknowledgedOn as AcknowledgedTime,
    ah.AcknowledgedBy,
    DATEDIFF(MINUTE, ah.AlertTime, GETDATE()) as AgeMinutes
FROM mon.AlertHistory ah
INNER JOIN mon.MonitoredInstances mi
    ON ah.InstanceID = mi.InstanceID;
GO
