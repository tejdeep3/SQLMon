param(
    [Parameter(Mandatory = $true)]
    [string]$MonitorServiceAccount,

    [string]$SqlInstance = $env:COMPUTERNAME,
    [string]$RepositoryServer = "",
    [string]$RepositoryDatabase = "DBA_SQLMonitor",
    [string]$DisplayName = "",
    [string]$Environment = "Production",
    [switch]$RegisterInRepository,
    [switch]$OpenFirewall,
    [int]$SqlPort = 1433
)

$ErrorActionPreference = "Stop"

function Invoke-LocalSqlNonQuery {
    param([string]$ServerInstance, [string]$Database, [string]$Query)
    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = 120
    try {
        $connection.Open()
        [void]$command.ExecuteNonQuery()
    }
    finally {
        $connection.Dispose()
    }
}

function Invoke-LocalSqlScalar {
    param([string]$ServerInstance, [string]$Database, [string]$Query)
    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = 60
    try {
        $connection.Open()
        return $command.ExecuteScalar()
    }
    finally {
        $connection.Dispose()
    }
}

if ([string]::IsNullOrWhiteSpace($DisplayName)) {
    $DisplayName = $SqlInstance
}

$escapedAccount = $MonitorServiceAccount.Replace("'", "''")
$quotedAccount = $MonitorServiceAccount.Replace("]", "]]")
$permissionSql = @"
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'$escapedAccount')
BEGIN
    CREATE LOGIN [$quotedAccount] FROM WINDOWS;
END;

GRANT VIEW SERVER STATE TO [$quotedAccount];
GRANT VIEW ANY DEFINITION TO [$quotedAccount];

IF TRY_CONVERT(INT, SERVERPROPERTY('ProductMajorVersion')) >= 16
BEGIN
    GRANT VIEW SERVER PERFORMANCE STATE TO [$quotedAccount];
    GRANT VIEW ANY PERFORMANCE DEFINITION TO [$quotedAccount];
END;
"@

Write-Host "Preparing SQL Monitor permissions on $SqlInstance for $MonitorServiceAccount"
Invoke-LocalSqlNonQuery -ServerInstance $SqlInstance -Database "master" -Query $permissionSql
Write-Host "Granted SQL Monitor read/DMV permissions." -ForegroundColor Green

if ($OpenFirewall) {
    Write-Host "Opening Windows Firewall for TCP $SqlPort"
    New-NetFirewallRule -DisplayName "SQL Monitor Collector TCP $SqlPort" -Direction Inbound -Action Allow -Protocol TCP -LocalPort $SqlPort -ErrorAction SilentlyContinue | Out-Null
}

if ($RegisterInRepository) {
    if ([string]::IsNullOrWhiteSpace($RepositoryServer)) {
        throw "RepositoryServer is required when -RegisterInRepository is used."
    }

    $serverName = $SqlInstance.Split('\')[0].Replace("'", "''")
    $instanceName = if ($SqlInstance.Contains('\')) { $SqlInstance.Split('\')[1] } else { "MSSQLSERVER" }
    $displayEscaped = $DisplayName.Replace("'", "''")
    $environmentEscaped = $Environment.Replace("'", "''")
    $registerSql = @"
IF OBJECT_ID('mon.MonitoredInstances', 'U') IS NULL
BEGIN
    THROW 50000, 'Repository table mon.MonitoredInstances does not exist. Deploy SQL Monitor repository first.', 1;
END;

IF NOT EXISTS (SELECT 1 FROM mon.MonitoredInstances WHERE DisplayName = N'$displayEscaped')
BEGIN
    INSERT INTO mon.MonitoredInstances (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
    VALUES (N'$serverName', N'$($instanceName.Replace("'", "''"))', N'$displayEscaped', N'$environmentEscaped', 1);
END
ELSE
BEGIN
    UPDATE mon.MonitoredInstances
    SET ServerName = N'$serverName',
        InstanceName = N'$($instanceName.Replace("'", "''"))',
        EnvironmentName = N'$environmentEscaped',
        IsActive = 1
    WHERE DisplayName = N'$displayEscaped';
END;
"@

    Write-Host "Registering $DisplayName in repository $RepositoryServer / $RepositoryDatabase"
    Invoke-LocalSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $registerSql
    Write-Host "Repository registration complete." -ForegroundColor Green
}

try {
    $version = Invoke-LocalSqlScalar -ServerInstance $SqlInstance -Database "master" -Query "SELECT CONVERT(NVARCHAR(128), SERVERPROPERTY('ProductVersion'));"
    Write-Host "Remote SQL connectivity check succeeded. Version: $version" -ForegroundColor Green
}
catch {
    Write-Host "Remote SQL connectivity check failed: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Next step: add this instance in SQL Monitor Instance Management or Config\instances.json, then run collectors from the central SQL Monitor server." -ForegroundColor Cyan
