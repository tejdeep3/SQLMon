# SQL Monitor Remote Collection Setup

SQL Monitor collectors are designed to run from one central SQL Monitor server and connect to remote SQL Server instances over TDS. You do not need to install the web dashboard on every SQL Server.

## 1. Choose The Collector Account

Recommended: a domain service account, for example:

```text
DOMAIN\SqlMonitorSvc
```

Run SQL Agent jobs, Windows Scheduled Tasks, and the web dashboard under this account when possible.

## 2. Run This On Each Remote SQL Server

Copy `Remote\Prepare-SQLMonitorRemoteServer.ps1` to the remote SQL Server, open PowerShell as Administrator in that folder, and run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Prepare-SQLMonitorRemoteServer.ps1 `
  -MonitorServiceAccount "DOMAIN\SqlMonitorSvc" `
  -SqlInstance "REMOTE01\SQL2019" `
  -RepositoryServer "CENTRALSQL\MONITOR" `
  -RepositoryDatabase "DBA_SQLMonitor2" `
  -DisplayName "REMOTE01\SQL2019" `
  -RegisterInRepository
```

If SQL Server listens on a fixed port and Windows Firewall blocks inbound SQL traffic, add:

```powershell
-OpenFirewall -SqlPort 1433
```

## 3. Add Instance To The Web Dashboard

In the web dashboard:

```text
Administration > Instance Management > New
```

Use:

```text
Display Name: REMOTE01\SQL2019
SQL Instance: REMOTE01\SQL2019
Repository Server: CENTRALSQL\MONITOR
Repository Database: DBA_SQLMonitor2
Environment: Production
Active: checked
```

## 4. Test From The Central SQL Monitor Server

Run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Remote\Test-SQLMonitorRemoteCollection.ps1 `
  -SqlInstance "REMOTE01\SQL2019" `
  -RepositoryServer "CENTRALSQL\MONITOR" `
  -RepositoryDatabase "DBA_SQLMonitor2"
```

## 5. Run Collectors

From the central SQL Monitor server:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Jobs\Run-Collectors-InstanceGroup.ps1 `
  -CollectorGroup Core `
  -InstanceFilter "REMOTE01\SQL2019"
```

Or use:

```text
Web Dashboard > Collectors & Schedule > Run Now
```

## Permissions Granted

The remote preparation script grants:

```sql
VIEW SERVER STATE
VIEW ANY DEFINITION
```

For SQL Server 2022 and newer it also grants:

```sql
VIEW SERVER PERFORMANCE STATE
VIEW ANY PERFORMANCE DEFINITION
```

## Network Requirements

The central SQL Monitor server must be able to connect to the remote SQL Server using the instance name or port:

```text
REMOTE01\SQL2019
REMOTE01,1433
```

For named instances, make sure SQL Browser is available or configure a static SQL port.
