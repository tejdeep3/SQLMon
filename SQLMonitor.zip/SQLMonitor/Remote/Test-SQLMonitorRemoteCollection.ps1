param(
    [Parameter(Mandatory = $true)]
    [string]$SqlInstance,

    [string]$RepositoryServer = "",
    [string]$RepositoryDatabase = "DBA_SQLMonitor",
    [string]$CollectorRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = "Stop"

function Invoke-TestSqlScalar {
    param([string]$ServerInstance, [string]$Database, [string]$Query)
    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = 30
    try {
        $connection.Open()
        return $command.ExecuteScalar()
    }
    finally {
        $connection.Dispose()
    }
}

if ([string]::IsNullOrWhiteSpace($RepositoryServer)) {
    $configPath = Join-Path $CollectorRoot "Config\instances.json"
    if (Test-Path $configPath) {
        $first = @(Get-Content -Path $configPath -Raw | ConvertFrom-Json | Select-Object -First 1)
        if ($first.Count -gt 0) {
            $RepositoryServer = [string]$first[0].RepositoryServer
            $RepositoryDatabase = [string]$first[0].RepositoryDatabase
        }
    }
}

Write-Host "Testing monitored SQL instance: $SqlInstance"
$sqlVersion = Invoke-TestSqlScalar -ServerInstance $SqlInstance -Database "master" -Query "SELECT CONVERT(NVARCHAR(128), SERVERPROPERTY('ProductVersion'));"
Write-Host "  SQL connection OK: $sqlVersion" -ForegroundColor Green

if (-not [string]::IsNullOrWhiteSpace($RepositoryServer)) {
    Write-Host "Testing repository: $RepositoryServer / $RepositoryDatabase"
    $repoCheck = Invoke-TestSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query "SELECT COUNT(*) FROM mon.MonitoredInstances;"
    Write-Host "  Repository connection OK. Registered instances: $repoCheck" -ForegroundColor Green
}

$runner = Join-Path $CollectorRoot "Jobs\Run-Collectors-InstanceGroup.ps1"
if (Test-Path $runner) {
    Write-Host ""
    Write-Host "Collector runner found: $runner" -ForegroundColor Green
    Write-Host "Run this from the central SQL Monitor server:"
    Write-Host "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$runner`" -CollectorGroup Core -InstanceFilter `"$SqlInstance`""
}
else {
    Write-Host "Collector runner not found under $CollectorRoot" -ForegroundColor Yellow
}
