-- Manual test with CORRECT parameters (no @NotificationSent)
DECLARE @TicketID BIGINT = 1; -- First ticket
DECLARE @EscalationLevelID INT = 1;
DECLARE @EscalationTo NVARCHAR(255) = 'dba-team@company.com';

-- Record the escalation with correct parameters
EXEC [mon].[usp_RecordEscalation] 
    @TicketID = @TicketID,
    @EscalationLevelID = @EscalationLevelID,
    @EscalatedTo = @EscalationTo,
    @EscalatedBy = 'system';

-- Update ticket
UPDATE [mon].[Tickets]
SET [EscalationLevelID] = @EscalationLevelID,
    [ModifiedDate] = SYSUTCDATETIME()
WHERE [TicketID] = @TicketID;

-- Log in comments
INSERT INTO [mon].[TicketComments] ([TicketID], [CommentText], [CreatedBy])
VALUES (@TicketID, 
        'Ticket escalated to ' + @EscalationTo + ' (Manual test)', 
        'system');

SELECT 'Ticket ' + CAST(@TicketID AS NVARCHAR(20)) + ' escalated to ' + @EscalationTo AS Result;

-- Verify the escalation was recorded
SELECT * FROM mon.vw_EscalationHistory WHERE TicketID = @TicketID;
