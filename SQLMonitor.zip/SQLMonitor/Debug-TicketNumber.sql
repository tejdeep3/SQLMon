-- Check TicketStatus table for correct status IDs
SELECT * FROM mon.TicketStatus ORDER BY TicketStatusID;

-- Check the year and ticket number generation logic
DECLARE @Year VARCHAR(4) = YEAR(SYSUTCDATETIME());
SELECT @Year AS CurrentYear;

-- Test the substring logic
DECLARE @TestTicket VARCHAR(50) = 'TKT-2026-0001';
SELECT SUBSTRING(@TestTicket, LEN(@Year) + 5, 10) AS WrongPosition,
       SUBSTRING(@TestTicket, 10, 10) AS CorrectPosition;
