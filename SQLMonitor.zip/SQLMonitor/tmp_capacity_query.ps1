$connectionString = 'Server=BBLBHLAP860\\BBDBTESTSQL;Database=DBA_SQLMonitor;Integrated Security=True;TrustServerCertificate=True;'
$conn = New-Object System.Data.SqlClient.SqlConnection($connectionString)
$conn.Open()
$cmd = $conn.CreateCommand()
$cmd.CommandText = 'SELECT COUNT(*) AS ForecastCount FROM mon.WindowsCapacityForecast; SELECT COUNT(*) AS DashboardCount FROM mon.vw_WindowsCapacityDashboard; SELECT TOP 5 ForecastID, TargetID, DisplayName, MetricName, CurrentValue, DaysUntilExhaustion, RecommendedAction FROM mon.vw_WindowsCapacityDashboard;'
$reader = $cmd.ExecuteReader()
$resultIndex = 1
Do {
    Write-Host '--- Result set' $resultIndex
    while ($reader.Read()) {
        $values = @()
        for ($i = 0; $i -lt $reader.FieldCount; $i++) {
            $values += "$($reader.GetName($i))=$($reader.GetValue($i))"
        }
        Write-Host ($values -join '; ')
    }
    $resultIndex++
} While ($reader.NextResult())
$conn.Close()
