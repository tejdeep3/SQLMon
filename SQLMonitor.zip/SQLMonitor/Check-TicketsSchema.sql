-- Check Tickets table schema
SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'mon' AND TABLE_NAME = 'Tickets'
ORDER BY ORDINAL_POSITION;

-- Check if EscalationLevelID column exists
IF COL_LENGTH('mon.Tickets', 'EscalationLevelID') IS NULL
BEGIN
    PRINT 'EscalationLevelID column does not exist in Tickets table';
END
ELSE
BEGIN
    PRINT 'EscalationLevelID column exists';
END
