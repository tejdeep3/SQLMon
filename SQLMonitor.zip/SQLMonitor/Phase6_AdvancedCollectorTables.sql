-- Phase 6: Production Scheduling and Advanced Collectors Tables
-- This script creates tables for advanced monitoring data

USE [DBA_SQLMonitor]
GO

-- Wait Statistics table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='WaitStats' AND xtype='U')
CREATE TABLE [dbo].[WaitStats] (
    [WaitStatsID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CollectionDateTime] [datetime2](7) NOT NULL,
    [WaitType] [nvarchar](60) NOT NULL,
    [WaitingTasksCount] [bigint] NOT NULL,
    [WaitTimeMs] [bigint] NOT NULL,
    [MaxWaitTimeMs] [bigint] NOT NULL,
    [SignalWaitTimeMs] [bigint] NOT NULL,
    CONSTRAINT [PK_WaitStats] PRIMARY KEY CLUSTERED ([WaitStatsID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Top Queries table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TopQueries' AND xtype='U')
CREATE TABLE [dbo].[TopQueries] (
    [TopQueryID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CollectionDateTime] [datetime2](7) NOT NULL,
    [QueryID] [bigint] NOT NULL,
    [PlanID] [bigint] NOT NULL,
    [QueryText] [nvarchar](max) NOT NULL,
    [AvgCpuTime] [float] NOT NULL,
    [AvgDuration] [float] NOT NULL,
    [AvgLogicalIOReads] [float] NOT NULL,
    [AvgLogicalIOWrites] [float] NOT NULL,
    [AvgPhysicalIOReads] [float] NOT NULL,
    [CountExecutions] [bigint] NOT NULL,
    [AvgRowCount] [float] NOT NULL,
    CONSTRAINT [PK_TopQueries] PRIMARY KEY CLUSTERED ([TopQueryID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Missing Indexes table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='MissingIndexes' AND xtype='U')
CREATE TABLE [dbo].[MissingIndexes] (
    [MissingIndexID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CollectionDateTime] [datetime2](7) NOT NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [ObjectName] [nvarchar](128) NOT NULL,
    [EqualityColumns] [nvarchar](4000) NULL,
    [InequalityColumns] [nvarchar](4000) NULL,
    [IncludedColumns] [nvarchar](4000) NULL,
    [UserSeeks] [bigint] NOT NULL,
    [UserScans] [bigint] NOT NULL,
    [UserLookups] [bigint] NOT NULL,
    [UserUpdates] [bigint] NOT NULL,
    [AvgFragmentationPercent] [float] NULL,
    [PageCount] [bigint] NULL,
    [RecordCount] [bigint] NULL,
    [ImprovementMeasure] [float] NOT NULL,
    CONSTRAINT [PK_MissingIndexes] PRIMARY KEY CLUSTERED ([MissingIndexID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Index Fragmentation table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='IndexFragmentation' AND xtype='U')
CREATE TABLE [dbo].[IndexFragmentation] (
    [FragmentationID] [int] IDENTITY(1,1) NOT NULL,
    [InstanceID] [int] NOT NULL,
    [CollectionDateTime] [datetime2](7) NOT NULL,
    [DatabaseName] [nvarchar](128) NOT NULL,
    [ObjectName] [nvarchar](128) NOT NULL,
    [IndexName] [nvarchar](128) NOT NULL,
    [IndexType] [nvarchar](60) NOT NULL,
    [AvgFragmentationPercent] [float] NOT NULL,
    [AvgPageSpaceUsedPercent] [float] NULL,
    [RecordCount] [bigint] NULL,
    [PageCount] [bigint] NULL,
    [AvgRecordSizeBytes] [float] NULL,
    CONSTRAINT [PK_IndexFragmentation] PRIMARY KEY CLUSTERED ([FragmentationID] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Add foreign key constraints
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_WaitStats_Instances')
ALTER TABLE [dbo].[WaitStats] WITH CHECK ADD CONSTRAINT [FK_WaitStats_Instances] FOREIGN KEY([InstanceID])
REFERENCES [mon].[MonitoredInstances] ([InstanceID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TopQueries_Instances')
ALTER TABLE [dbo].[TopQueries] WITH CHECK ADD CONSTRAINT [FK_TopQueries_Instances] FOREIGN KEY([InstanceID])
REFERENCES [mon].[MonitoredInstances] ([InstanceID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_MissingIndexes_Instances')
ALTER TABLE [dbo].[MissingIndexes] WITH CHECK ADD CONSTRAINT [FK_MissingIndexes_Instances] FOREIGN KEY([InstanceID])
REFERENCES [mon].[MonitoredInstances] ([InstanceID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_IndexFragmentation_Instances')
ALTER TABLE [dbo].[IndexFragmentation] WITH CHECK ADD CONSTRAINT [FK_IndexFragmentation_Instances] FOREIGN KEY([InstanceID])
REFERENCES [mon].[MonitoredInstances] ([InstanceID])
GO

-- Create indexes for performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_WaitStats_InstanceID_CollectionDateTime')
CREATE NONCLUSTERED INDEX [IX_WaitStats_InstanceID_CollectionDateTime] ON [dbo].[WaitStats]
(
    [InstanceID] ASC,
    [CollectionDateTime] ASC
)
INCLUDE ([WaitType],[WaitTimeMs]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_TopQueries_InstanceID_CollectionDateTime')
CREATE NONCLUSTERED INDEX [IX_TopQueries_InstanceID_CollectionDateTime] ON [dbo].[TopQueries]
(
    [InstanceID] ASC,
    [CollectionDateTime] ASC
)
INCLUDE ([AvgCpuTime],[AvgDuration]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_MissingIndexes_InstanceID_CollectionDateTime')
CREATE NONCLUSTERED INDEX [IX_MissingIndexes_InstanceID_CollectionDateTime] ON [dbo].[MissingIndexes]
(
    [InstanceID] ASC,
    [CollectionDateTime] ASC
)
INCLUDE ([DatabaseName],[ImprovementMeasure]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_IndexFragmentation_InstanceID_CollectionDateTime')
CREATE NONCLUSTERED INDEX [IX_IndexFragmentation_InstanceID_CollectionDateTime] ON [dbo].[IndexFragmentation]
(
    [InstanceID] ASC,
    [CollectionDateTime] ASC
)
INCLUDE ([DatabaseName],[AvgFragmentationPercent]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

PRINT 'Phase 6 advanced collector tables created successfully'