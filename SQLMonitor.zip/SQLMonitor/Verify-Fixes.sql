-- Check system status
SELECT COUNT(*) AS TotalTickets, 
       COUNT(CASE WHEN EscalationLevelID IS NOT NULL THEN 1 END) AS EscalatedTickets,
       COUNT(CASE WHEN TicketStatusID = 1 THEN 1 END) AS OpenTickets
FROM mon.Tickets;

-- Check some escalated tickets
SELECT TOP 5 
    t.TicketID, 
    t.TicketNumber, 
    ts.SeverityName,
    t.EscalationLevelID,
    em.EscalationTo
FROM mon.Tickets t
JOIN mon.TicketSeverity ts ON t.TicketSeverityID = ts.TicketSeverityID
LEFT JOIN mon.EscalationMatrix em ON t.EscalationLevelID = em.EscalationLevelID
WHERE t.EscalationLevelID IS NOT NULL;

-- Check escalation history
SELECT TOP 5 * FROM mon.vw_EscalationHistory ORDER BY EscalatedOn DESC;
