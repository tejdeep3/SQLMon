-- =============================================
-- CREATE ESCALATION PROCESSING STORED PROCEDURE
-- =============================================

-- Stored procedure to check and process pending escalations
CREATE OR ALTER PROCEDURE [mon].[usp_CheckAndProcessEscalations]
    @BatchSize INT = 100,
    @ProcessedCount INT = 0 OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @TicketID BIGINT, @TicketNumber NVARCHAR(50), @SeverityName NVARCHAR(20);
    DECLARE @EscalationLevelID INT, @EscalationTo NVARCHAR(255), @EscalationTimeMinutes INT;
    DECLARE @NotificationTemplate NVARCHAR(500), @AssignedTo NVARCHAR(100);
    
    -- Cursor to process tickets pending escalation
    DECLARE escalation_cursor CURSOR FAST_FORWARD FOR
    SELECT TOP (@BatchSize)
        vw.TicketID,
        vw.TicketNumber,
        vw.TicketSeverity,
        vw.EscalationLevelID,
        em.EscalationTo,
        em.EscalationTimeMinutes,
        em.NotificationTemplate,
        t.AssignedTo
    FROM [mon].[vw_TicketsPendingEscalation] vw
    JOIN [mon].[EscalationMatrix] em ON vw.TicketSeverityID = em.TicketSeverityID 
        AND vw.EscalationLevelID = em.EscalationLevelID
    JOIN [mon].[Tickets] t ON vw.TicketID = t.TicketID
    WHERE em.IsActive = 1
      AND vw.AgeMinutes >= em.EscalationTimeMinutes
    ORDER BY vw.AgeMinutes DESC;
    
    SET @ProcessedCount = 0;
    
    OPEN escalation_cursor;
    FETCH NEXT FROM escalation_cursor INTO @TicketID, @TicketNumber, @SeverityName, 
        @EscalationLevelID, @EscalationTo, @EscalationTimeMinutes, 
        @NotificationTemplate, @AssignedTo;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Record the escalation
            EXEC [mon].[usp_RecordEscalation] 
                @TicketID = @TicketID,
                @EscalationLevelID = @EscalationLevelID,
                @EscalatedTo = @EscalationTo,
                @NotificationSent = 1;
            
            -- Update ticket's escalation level
            UPDATE [mon].[Tickets]
            SET [EscalationLevelID] = @EscalationLevelID,
                [ModifiedDate] = SYSUTCDATETIME()
            WHERE [TicketID] = @TicketID;
            
            -- Log the escalation in comments
            INSERT INTO [mon].[TicketComments] ([TicketID], [CommentText], [CreatedBy])
            VALUES (@TicketID, 
                    'Ticket escalated to ' + @EscalationTo + ' (Level ' + CAST(@EscalationLevelID AS NVARCHAR(10)) + ')', 
                    'system');
            
            SET @ProcessedCount = @ProcessedCount + 1;
            
            PRINT 'Escalated ticket ' + @TicketNumber + ' to ' + @EscalationTo;
        END TRY
        BEGIN CATCH
            PRINT 'Error escalating ticket ' + CAST(@TicketID AS VARCHAR(20)) + ': ' + ERROR_MESSAGE();
        END CATCH
        
        FETCH NEXT FROM escalation_cursor INTO @TicketID, @TicketNumber, @SeverityName,
            @EscalationLevelID, @EscalationTo, @EscalationTimeMinutes,
            @NotificationTemplate, @AssignedTo;
    END
    
    CLOSE escalation_cursor;
    DEALLOCATE escalation_cursor;
    
    PRINT 'Escalation processing completed. Processed ' + CAST(@ProcessedCount AS VARCHAR(10)) + ' ticket(s).';
END
GO
