@echo off
REM Launch-WebAgent.bat
REM Launches the Web Solutions Agent

echo Starting Web Solutions Agent...
echo.

cd /d "%~dp0"

powershell.exe -ExecutionPolicy Bypass -File ".\Jobs\Run-WebAgent.ps1"

echo.
echo Web Solutions Agent completed.
pause