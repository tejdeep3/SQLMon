USE DBA_SQLMonitor;
GO

IF COL_LENGTH('mon.AlertThresholds', 'ComparisonType') IS NULL
BEGIN
    ALTER TABLE mon.AlertThresholds
    ADD ComparisonType NVARCHAR(20) NOT NULL
        CONSTRAINT DF_AlertThresholds_ComparisonType DEFAULT ('GreaterThan');
END
GO

IF COL_LENGTH('mon.AlertThresholds', 'CooldownMinutes') IS NULL
BEGIN
    ALTER TABLE mon.AlertThresholds
    ADD CooldownMinutes INT NOT NULL
        CONSTRAINT DF_AlertThresholds_CooldownMinutes DEFAULT (60);
END
GO

IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD RepeatCount INT NOT NULL
        CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
END
GO

IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD FirstAlertTime DATETIME2 NULL;
END
GO

IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD LastRepeatedAt DATETIME2 NULL;
END
GO

UPDATE mon.AlertHistory
SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
    LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
    RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
WHERE FirstAlertTime IS NULL
   OR LastRepeatedAt IS NULL
   OR ISNULL(RepeatCount, 0) < 1;
GO

CREATE OR ALTER TRIGGER mon.trg_AlertHistory_RepeatCounter
ON mon.AlertHistory
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM inserted WHERE ISNULL(IsAcknowledged, 0) = 0)
        RETURN;

    UPDATE ah
    SET RepeatCount = CASE WHEN ISNULL(ah.RepeatCount, 0) < 1 THEN 1 ELSE ah.RepeatCount END,
        FirstAlertTime = COALESCE(ah.FirstAlertTime, ah.AlertTime),
        LastRepeatedAt = COALESCE(ah.LastRepeatedAt, ah.AlertTime)
    FROM mon.AlertHistory ah
    INNER JOIN inserted i ON ah.AlertID = i.AlertID;

    ;WITH mapped AS
    (
        SELECT
            i.AlertID AS InsertedAlertID,
            keeper.AlertID AS KeeperAlertID,
            ISNULL(i.RepeatCount, 1) AS InsertedRepeatCount,
            i.AlertTime,
            i.Severity,
            i.AlertDetails
        FROM inserted i
        CROSS APPLY
        (
            SELECT TOP (1) h.AlertID
            FROM mon.AlertHistory h
            WHERE ISNULL(h.IsAcknowledged, 0) = 0
              AND h.InstanceID = i.InstanceID
              AND h.ModuleName = i.ModuleName
              AND h.AlertTitle = i.AlertTitle
            ORDER BY COALESCE(h.FirstAlertTime, h.AlertTime), h.AlertID
        ) keeper
        WHERE ISNULL(i.IsAcknowledged, 0) = 0
          AND keeper.AlertID <> i.AlertID
    ),
    grouped AS
    (
        SELECT
            KeeperAlertID,
            SUM(InsertedRepeatCount) AS AddRepeatCount,
            MAX(AlertTime) AS LastRepeatedAt,
            MAX(CASE WHEN Severity = 'Critical' THEN 2 WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS MaxSeverityRank
        FROM mapped
        GROUP BY KeeperAlertID
    )
    UPDATE keeper
    SET RepeatCount = ISNULL(keeper.RepeatCount, 1) + grouped.AddRepeatCount,
        LastRepeatedAt = grouped.LastRepeatedAt,
        Severity = CASE
            WHEN grouped.MaxSeverityRank = 2 THEN 'Critical'
            WHEN grouped.MaxSeverityRank = 1 AND keeper.Severity <> 'Critical' THEN 'Warning'
            ELSE keeper.Severity
        END,
        AlertDetails = COALESCE(latest.AlertDetails, keeper.AlertDetails)
    FROM mon.AlertHistory keeper
    INNER JOIN grouped ON keeper.AlertID = grouped.KeeperAlertID
    OUTER APPLY
    (
        SELECT TOP (1) m.AlertDetails
        FROM mapped m
        WHERE m.KeeperAlertID = grouped.KeeperAlertID
        ORDER BY m.AlertTime DESC, m.InsertedAlertID DESC
    ) latest;

    DELETE ah
    FROM mon.AlertHistory ah
    INNER JOIN
    (
        SELECT DISTINCT InsertedAlertID
        FROM
        (
            SELECT
                i.AlertID AS InsertedAlertID,
                keeper.AlertID AS KeeperAlertID
            FROM inserted i
            CROSS APPLY
            (
                SELECT TOP (1) h.AlertID
                FROM mon.AlertHistory h
                WHERE ISNULL(h.IsAcknowledged, 0) = 0
                  AND h.InstanceID = i.InstanceID
                  AND h.ModuleName = i.ModuleName
                  AND h.AlertTitle = i.AlertTitle
                ORDER BY COALESCE(h.FirstAlertTime, h.AlertTime), h.AlertID
            ) keeper
            WHERE ISNULL(i.IsAcknowledged, 0) = 0
              AND keeper.AlertID <> i.AlertID
        ) x
    ) d ON ah.AlertID = d.InsertedAlertID;
END
GO

MERGE mon.AlertThresholds AS tgt
USING
(
    SELECT 'CPU'    AS ModuleName, 'SqlCPUPercent'      AS MetricName, 70.0 AS WarningValue, 85.0 AS CriticalValue, 'GreaterThan' AS ComparisonType, 30 AS CooldownMinutes, 1 AS IsActive
    UNION ALL
    SELECT 'Memory', 'AvailablePhysicalMB',              8192.0,             4096.0,              'LessThan',         30,                    1
    UNION ALL
    SELECT 'Memory', 'PLESeconds',                       3000.0,             1000.0,              'LessThan',         30,                    1
    UNION ALL
    SELECT 'Backup', 'OverdueCount',                     1.0,                1.0,                 'GreaterThan',      60,                    1
    UNION ALL
    SELECT 'AgentJobs', 'FailedJobsCount',               1.0,                1.0,                 'GreaterThan',      30,                    1
    UNION ALL
    SELECT 'Deadlocks', 'RecentDeadlocksCount',          1.0,                1.0,                 'GreaterThan',      30,                    1
    UNION ALL
    SELECT 'AlwaysOn', 'UnhealthyAGCount',               1.0,                1.0,                 'GreaterThan',      30,                    1
) AS src
ON tgt.ModuleName = src.ModuleName
AND tgt.MetricName = src.MetricName
WHEN MATCHED THEN
    UPDATE SET
        tgt.WarningValue    = src.WarningValue,
        tgt.CriticalValue   = src.CriticalValue,
        tgt.ComparisonType  = src.ComparisonType,
        tgt.CooldownMinutes = src.CooldownMinutes,
        tgt.IsActive        = src.IsActive
WHEN NOT MATCHED THEN
    INSERT (ModuleName, MetricName, WarningValue, CriticalValue, ComparisonType, CooldownMinutes, IsActive)
    VALUES (src.ModuleName, src.MetricName, src.WarningValue, src.CriticalValue, src.ComparisonType, src.CooldownMinutes, src.IsActive);
GO

CREATE OR ALTER VIEW mon.vw_LatestBackupStatus
AS
WITH x AS
(
    SELECT
        b.*,
        ROW_NUMBER() OVER (PARTITION BY b.InstanceID, b.DatabaseName ORDER BY b.CaptureTime DESC) AS rn
    FROM mon.BackupStatusHistory b
)
SELECT *
FROM x
WHERE rn = 1;
GO

CREATE OR ALTER VIEW mon.vw_LatestAgentJobs
AS
WITH x AS
(
    SELECT
        a.*,
        ROW_NUMBER() OVER (PARTITION BY a.InstanceID, a.JobName ORDER BY a.CaptureTime DESC) AS rn
    FROM mon.AgentJobHistory a
)
SELECT *
FROM x
WHERE rn = 1;
GO

CREATE OR ALTER VIEW mon.vw_LatestAGOverview
AS
WITH x AS
(
    SELECT
        a.*,
        ROW_NUMBER() OVER (PARTITION BY a.InstanceID, a.AGName ORDER BY a.CaptureTime DESC) AS rn
    FROM mon.AGOverviewHistory a
)
SELECT *
FROM x
WHERE rn = 1;
GO

CREATE OR ALTER VIEW mon.vw_RecentDeadlocks60Min
AS
SELECT
    InstanceID,
    COUNT(*) AS RecentDeadlocksCount
FROM mon.DeadlockHistory
WHERE DeadlockTime >= DATEADD(MINUTE, -60, SYSDATETIME())
GROUP BY InstanceID;
GO

CREATE OR ALTER VIEW mon.vw_OpenAlerts
AS
WITH ranked AS
(
    SELECT
        ah.AlertID,
        ah.InstanceID,
        mi.DisplayName,
        ah.AlertTime,
        ah.Severity,
        ah.ModuleName,
        ah.AlertTitle,
        ah.AlertDetails,
        ah.IsAcknowledged,
        ah.AcknowledgedBy,
        ah.AcknowledgedOn,
        SUM(ISNULL(ah.RepeatCount, 1)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS RepeatCount,
        MIN(COALESCE(ah.FirstAlertTime, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS FirstAlertTime,
        MAX(COALESCE(ah.LastRepeatedAt, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS LastRepeatedAt,
        ROW_NUMBER() OVER (
            PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle
            ORDER BY CASE ah.Severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END,
                     ah.AlertTime DESC,
                     ah.AlertID DESC
        ) AS rn
    FROM mon.AlertHistory ah
    INNER JOIN mon.MonitoredInstances mi
        ON ah.InstanceID = mi.InstanceID
    WHERE ah.IsAcknowledged = 0
)
SELECT
    AlertID,
    InstanceID,
    DisplayName,
    AlertTime,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    AcknowledgedBy,
    AcknowledgedOn,
    RepeatCount,
    FirstAlertTime,
    LastRepeatedAt
FROM ranked
WHERE rn = 1;
GO

CREATE OR ALTER VIEW mon.vw_OpenAlertCounts
AS
WITH open_alerts AS
(
    SELECT InstanceID, Severity
    FROM mon.vw_OpenAlerts
)
SELECT
    InstanceID,
    COUNT(*) AS OpenAlertCount,
    SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
    SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
FROM open_alerts
GROUP BY InstanceID;
GO

CREATE OR ALTER PROCEDURE mon.usp_EvaluateAlerts
    @InstanceID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Now DATETIME2 = SYSDATETIME();

    IF OBJECT_ID('tempdb..#AlertCandidates') IS NOT NULL DROP TABLE #AlertCandidates;

    CREATE TABLE #AlertCandidates
    (
        InstanceID       INT NOT NULL,
        Severity         NVARCHAR(20) NOT NULL,
        ModuleName       NVARCHAR(100) NOT NULL,
        AlertTitle       NVARCHAR(300) NOT NULL,
        AlertDetails     NVARCHAR(MAX) NULL,
        CooldownMinutes  INT NOT NULL
    );

    ;WITH T AS
    (
        SELECT *
        FROM mon.AlertThresholds
        WHERE ModuleName = 'CPU'
          AND MetricName = 'SqlCPUPercent'
          AND IsActive = 1
    )
    INSERT INTO #AlertCandidates (InstanceID, Severity, ModuleName, AlertTitle, AlertDetails, CooldownMinutes)
    SELECT
        o.InstanceID,
        CASE
            WHEN o.SqlCPUPercent >= t.CriticalValue THEN 'Critical'
            WHEN o.SqlCPUPercent >= t.WarningValue THEN 'Warning'
        END AS Severity,
        'CPU',
        'High SQL CPU detected',
        CONCAT('SQL CPU = ', CONVERT(VARCHAR(30), o.SqlCPUPercent), '%. Instance = ', mi.DisplayName),
        t.CooldownMinutes
    FROM mon.vw_Overview o
    INNER JOIN mon.MonitoredInstances mi
        ON o.InstanceID = mi.InstanceID
    CROSS JOIN T t
    WHERE o.InstanceID = @InstanceID
      AND o.SqlCPUPercent IS NOT NULL
      AND o.SqlCPUPercent >= t.WarningValue;

    ;WITH T AS
    (
        SELECT *
        FROM mon.AlertThresholds
        WHERE ModuleName = 'Memory'
          AND MetricName = 'AvailablePhysicalMB'
          AND IsActive = 1
    )
    INSERT INTO #AlertCandidates (InstanceID, Severity, ModuleName, AlertTitle, AlertDetails, CooldownMinutes)
    SELECT
        o.InstanceID,
        CASE
            WHEN o.AvailablePhysicalMB <= t.CriticalValue THEN 'Critical'
            WHEN o.AvailablePhysicalMB <= t.WarningValue THEN 'Warning'
        END,
        'Memory',
        'Low available physical memory detected',
        CONCAT('Available physical memory = ', CONVERT(VARCHAR(30), o.AvailablePhysicalMB), ' MB. Instance = ', mi.DisplayName),
        t.CooldownMinutes
    FROM mon.vw_Overview o
    INNER JOIN mon.MonitoredInstances mi
        ON o.InstanceID = mi.InstanceID
    CROSS JOIN T t
    WHERE o.InstanceID = @InstanceID
      AND o.AvailablePhysicalMB IS NOT NULL
      AND o.AvailablePhysicalMB <= t.WarningValue;

    ;WITH T AS
    (
        SELECT *
        FROM mon.AlertThresholds
        WHERE ModuleName = 'Memory'
          AND MetricName = 'PLESeconds'
          AND IsActive = 1
    )
    INSERT INTO #AlertCandidates (InstanceID, Severity, ModuleName, AlertTitle, AlertDetails, CooldownMinutes)
    SELECT
        o.InstanceID,
        CASE
            WHEN o.PLESeconds <= t.CriticalValue THEN 'Critical'
            WHEN o.PLESeconds <= t.WarningValue THEN 'Warning'
        END,
        'Memory',
        'Low page life expectancy detected',
        CONCAT('PLE = ', CONVERT(VARCHAR(30), o.PLESeconds), ' seconds. Instance = ', mi.DisplayName),
        t.CooldownMinutes
    FROM mon.vw_Overview o
    INNER JOIN mon.MonitoredInstances mi
        ON o.InstanceID = mi.InstanceID
    CROSS JOIN T t
    WHERE o.InstanceID = @InstanceID
      AND o.PLESeconds IS NOT NULL
      AND o.PLESeconds <= t.WarningValue;

    ;WITH T AS
    (
        SELECT *
        FROM mon.AlertThresholds
        WHERE ModuleName = 'Backup'
          AND MetricName = 'OverdueCount'
          AND IsActive = 1
    ),
    X AS
    (
        SELECT
            InstanceID,
            COUNT(*) AS OverdueCount
        FROM mon.vw_LatestBackupStatus
        WHERE InstanceID = @InstanceID
          AND StatusText LIKE '%overdue%'
        GROUP BY InstanceID
    )
    INSERT INTO #AlertCandidates (InstanceID, Severity, ModuleName, AlertTitle, AlertDetails, CooldownMinutes)
    SELECT
        x.InstanceID,
        'Critical',
        'Backup',
        'Backup overdue databases detected',
        CONCAT('Overdue backup count = ', CONVERT(VARCHAR(30), x.OverdueCount)),
        t.CooldownMinutes
    FROM X x
    CROSS JOIN T t
    WHERE x.OverdueCount >= t.WarningValue;

    ;WITH T AS
    (
        SELECT *
        FROM mon.AlertThresholds
        WHERE ModuleName = 'AgentJobs'
          AND MetricName = 'FailedJobsCount'
          AND IsActive = 1
    ),
    X AS
    (
        SELECT
            InstanceID,
            COUNT(*) AS FailedJobsCount
        FROM mon.vw_LatestAgentJobs
        WHERE InstanceID = @InstanceID
          AND (LastStatus = 'Failed' OR ISNULL(FailuresRecent, 0) > 0)
        GROUP BY InstanceID
    )
    INSERT INTO #AlertCandidates (InstanceID, Severity, ModuleName, AlertTitle, AlertDetails, CooldownMinutes)
    SELECT
        x.InstanceID,
        'Critical',
        'AgentJobs',
        'Failed SQL Agent jobs detected',
        CONCAT('Failed job count = ', CONVERT(VARCHAR(30), x.FailedJobsCount)),
        t.CooldownMinutes
    FROM X x
    CROSS JOIN T t
    WHERE x.FailedJobsCount >= t.WarningValue;

    ;WITH T AS
    (
        SELECT *
        FROM mon.AlertThresholds
        WHERE ModuleName = 'Deadlocks'
          AND MetricName = 'RecentDeadlocksCount'
          AND IsActive = 1
    )
    INSERT INTO #AlertCandidates (InstanceID, Severity, ModuleName, AlertTitle, AlertDetails, CooldownMinutes)
    SELECT
        d.InstanceID,
        'Critical',
        'Deadlocks',
        'Recent deadlocks detected',
        CONCAT('Deadlocks in last 60 minutes = ', CONVERT(VARCHAR(30), d.RecentDeadlocksCount)),
        t.CooldownMinutes
    FROM mon.vw_RecentDeadlocks60Min d
    CROSS JOIN T t
    WHERE d.InstanceID = @InstanceID
      AND d.RecentDeadlocksCount >= t.WarningValue;

    ;WITH T AS
    (
        SELECT *
        FROM mon.AlertThresholds
        WHERE ModuleName = 'AlwaysOn'
          AND MetricName = 'UnhealthyAGCount'
          AND IsActive = 1
    ),
    X AS
    (
        SELECT
            InstanceID,
            COUNT(*) AS UnhealthyAGCount
        FROM mon.vw_LatestAGOverview
        WHERE InstanceID = @InstanceID
          AND SyncHealthDesc IS NOT NULL
          AND SyncHealthDesc <> 'HEALTHY'
        GROUP BY InstanceID
    )
    INSERT INTO #AlertCandidates (InstanceID, Severity, ModuleName, AlertTitle, AlertDetails, CooldownMinutes)
    SELECT
        x.InstanceID,
        'Critical',
        'AlwaysOn',
        'Availability Group health issue detected',
        CONCAT('Unhealthy AG count = ', CONVERT(VARCHAR(30), x.UnhealthyAGCount)),
        t.CooldownMinutes
    FROM X x
    CROSS JOIN T t
    WHERE x.UnhealthyAGCount >= t.WarningValue;

    UPDATE h
    SET
        Severity = CASE
            WHEN c.Severity = 'Critical' THEN 'Critical'
            WHEN h.Severity = 'Critical' THEN h.Severity
            ELSE c.Severity
        END,
        AlertDetails = c.AlertDetails,
        RepeatCount = ISNULL(h.RepeatCount, 1) + 1,
        FirstAlertTime = COALESCE(h.FirstAlertTime, h.AlertTime),
        LastRepeatedAt = @Now
    FROM mon.AlertHistory h
    INNER JOIN #AlertCandidates c
        ON h.InstanceID = c.InstanceID
       AND h.ModuleName = c.ModuleName
       AND h.AlertTitle = c.AlertTitle
    WHERE h.IsAcknowledged = 0;

    INSERT INTO mon.AlertHistory
    (
        InstanceID,
        AlertTime,
        Severity,
        ModuleName,
        AlertTitle,
        AlertDetails,
        IsAcknowledged,
        RepeatCount,
        FirstAlertTime,
        LastRepeatedAt
    )
    SELECT
        c.InstanceID,
        @Now,
        c.Severity,
        c.ModuleName,
        c.AlertTitle,
        c.AlertDetails,
        0,
        1,
        @Now,
        @Now
    FROM #AlertCandidates c
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM mon.AlertHistory h
        WHERE h.InstanceID = c.InstanceID
          AND h.ModuleName = c.ModuleName
          AND h.AlertTitle = c.AlertTitle
          AND h.IsAcknowledged = 0
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM mon.AlertHistory h
        WHERE h.InstanceID = c.InstanceID
          AND h.ModuleName = c.ModuleName
          AND h.AlertTitle = c.AlertTitle
          AND h.AlertTime >= DATEADD(MINUTE, -c.CooldownMinutes, @Now)
    );

    SELECT
        AlertID,
        InstanceID,
        AlertTime,
        Severity,
        ModuleName,
        AlertTitle,
        AlertDetails,
        IsAcknowledged,
        AcknowledgedBy,
        AcknowledgedOn
    FROM mon.AlertHistory
    WHERE InstanceID = @InstanceID
      AND AlertTime >= DATEADD(MINUTE, -120, @Now)
    ORDER BY AlertTime DESC;
END
GO
