# SQL Server Monitoring Platform

A comprehensive, repository-backed SQL Server monitoring platform built with PowerShell and .NET, using only built-in Windows components.

## Architecture Overview

- **Repository Database**: DBA_SQLMonitor with mon schema for centralized monitoring data
- **Collectors**: Modular PowerShell modules for different monitoring aspects
- **Alert Engine**: Threshold-based alerting with acknowledgement system
- **Dashboard**: WinForms GUI for real-time monitoring and alert management
- **Scheduling**: Windows Task Scheduler for automated collection and maintenance

## Components

### Database Schema (mon.*)
- MonitoredInstances: SQL Server instances being monitored
- CollectionRuns: Audit trail of collection activities
- History tables: CPUHistory, MemoryHistory, AgentJobHistory, etc.
- AlertHistory: All alerts with acknowledgement tracking
- AlertThresholds: Configurable alert thresholds

### PowerShell Modules
- **Common.psm1**: Core utilities (SQL queries, logging, instance management)
- **SQL Server Collectors**:
  - Collect-CPU.psm1: CPU utilization monitoring
  - Collect-Memory.psm1: Memory usage tracking
  - Collect-AgentJobs.psm1: SQL Agent job status
  - Collect-Deadlocks.psm1: Deadlock detection
  - Collect-AG.psm1: Availability Group monitoring
  - Collect-Waits.psm1: Wait statistics (advanced)
  - Collect-TopQueries.psm1: Query performance analysis (advanced)
  - Collect-MissingIndexes.psm1: Index optimization recommendations (advanced)
  - Collect-Fragmentation.psm1: Index fragmentation monitoring
  - **Collect-ExecutionPlans.psm1**: Real-time execution plan analysis with optimization recommendations (UNIQUE)
  - **Collect-MemoryClerks.psm1**: Memory clerk pressure analysis and buffer pool optimization (UNIQUE)
- **VM / Windows Monitoring Collectors**:
  - **Collect-WindowsVM.psm1**: Windows VM data collection (inventory, performance, disk, services, events, hotfixes, network adapters, processes)
  - **Collect-WindowsVM-FileBased.psm1**: Enhanced file-based collector with per-adapter bandwidth stats, TCP connection tracking, firewall status
- **Invoke-AlertEngine.psm1**: Alert evaluation and notification
- **WebAgent.psm1**: Intelligent web search for SQL Server solutions
- **PatchManager.psm1**: SQL Server patch status evaluation

### Scheduled Jobs
- **Run-Collectors-Core.ps1**: CPU and Memory (every 5 minutes)
- **Run-Collectors-Advanced.ps1**: Waits, Top Queries, Missing Indexes (every 30 minutes)
- **Run-Collectors-Daily.ps1**: Agent Jobs, Deadlocks, AG, Fragmentation (daily)
- **Run-ExecutionPlans.ps1**: Real-time execution plan analysis (every 30 minutes) (UNIQUE)
- **Run-MemoryClerks.ps1**: Memory clerk pressure monitoring (every 15 minutes) (UNIQUE)
- **Run-AlertEngine.ps1**: Alert evaluation (every 2 minutes)
- **Purge-Retention.ps1**: Data cleanup (daily)
- **Run-WindowsVMCollectors.ps1**: Windows VM data collection (every 15 minutes)
- **Run-WindowsBaselineAnalysis.ps1**: VM baseline calculation, anomaly detection, capacity forecast (daily at 1:00 AM)
- **Register-SQLMonitorTasks.ps1**: Task Scheduler setup

### Dashboard
- **SQLMonitorDashboard.ps1**: WinForms application with:
  - Overview tiles with alert indicators
  - Detailed metrics tabs (CPU, Memory, Jobs, etc.)
  - Alerts tab with acknowledgement functionality
  - Real-time data refresh  - **Interactive tooltips**: Detailed explanations for all metrics, alerts, and controls

## VM / Windows Monitoring

Comprehensive Windows server and VM monitoring with 8 dashboard tabs:

### VM Overview
- Server health tiles with posture indicators (Healthy/Warning/Critical)
- Health score trend chart, posture doughnut chart
- Open VM alerts with auto-ticket creation
- Recent Windows events and top processes

### VM Inventory
- Hardware inventory (OS, CPU, memory, manufacturer, model)
- Network adapter details (name, description, link speed, MAC)
- Patch snapshot (recent hotfixes)
- VM alert rules with SLA and auto-ticket policy

### VM Performance
- CPU, Memory, Disk trend charts (Chart.js)
- Latest disk capacity table
- Top processes by CPU and memory
- Performance counter burst samples

### VM Services
- Stopped automatic services with critical flag
- Recent Windows events (Critical, Error, Warning)

### Capacity Forecast
- Linear regression on historical samples to predict resource exhaustion
- Disk and memory exhaustion dates with confidence scores
- Recommended actions (Urgent/Plan/Monitor/Healthy)
- Per-metric baseline statistics (avg, stddev, min, max)

### Anomaly Detection
- Per-target, per-metric baselines grouped by hour-of-day and day-of-week
- Configurable standard deviation threshold (default 2.5σ)
- Unacknowledged anomaly log with severity (Critical/Warning)
- One-click acknowledge with notes

### Network Monitor
- Per-adapter bandwidth utilization (rx/tx/total, utilization %)
- TCP connection tracking (Listen/Established states)
- Firewall profile status (Domain/Private/Public, enabled/disabled)

### Patching Compliance
- Compliance scorecard per VM against defined patch baseline
- Missing patches detail with severity and required flags
- Patch installation timeline (last 90 days)
- Auto-discovery of new hotfixes as recommended baseline entries

## Unique Advanced Features

This monitoring platform includes several advanced capabilities not found in typical SQL Server monitoring tools:

### Real-Time Execution Plan Analysis
- **Collect-ExecutionPlans.psm1**: Monitors active queries and analyzes their execution plans
- Identifies table scans, missing indexes, high-cost operations, and parallelism issues
- Provides specific optimization recommendations for each query
- UNIQUE: Automated plan analysis with actionable recommendations

### Memory Clerk Pressure Analysis
- **Collect-MemoryClerks.psm1**: Detailed analysis of SQL Server's internal memory allocation
- Monitors memory usage by components (buffer pool, CLR, query plans, etc.)
- Predicts memory pressure scenarios and provides scaling recommendations
- UNIQUE: Component-level memory analysis with pressure prediction

### Intelligent Web Solutions Search
- **WebAgent.psm1**: Context-aware search for SQL Server troubleshooting solutions
- Analyzes alert text and error numbers to generate targeted search queries
- Filters results to ensure SQL Server relevance
- UNIQUE: Alert-specific query generation with relevance filtering

### AI Diagnostic Assistant
- **Invoke-WebDiagnosticAssistant**: Generates a root cause summary, likely issue category, and remediation guidance from alert text and repository evidence
- Integrates into the Web Solutions Agent dashboard tab as an "AI Diagnose" assistant
- Uses SQL Server-specific patterns and alert history to provide actionable recommendations

### Query Store Forced Plan Effectiveness Tracking
- Analyzes the effectiveness of forced execution plans
- Tracks performance improvements or regressions
- UNIQUE: Automated evaluation of plan forcing impact
## Installation

1. Execute SQL scripts via `Deploy-SQLMonitor.ps1 -DeployDatabase` (recommended) or run scripts 00 through 21 in order

2. Configure instances in `Config\instances.json`

3. Run `Deploy-SQLMonitor.ps1 -All` for full deployment (database, scripts, scheduled tasks, SQL Agent jobs). This also deploys the latest dashboard UI and WebAgent module updates.

4. For VM monitoring, seed the patch baseline:
   ```sql
   INSERT INTO mon.WindowsPatchBaseline (HotFixID, Description, Severity, IsRequired, Category)
   VALUES (N'KB5034441', N'Windows Security Update', N'Critical', 1, N'Security');
   ```

5. Launch web dashboard via `Launch-WebDashboard.bat` or `GUI/SQLMonitorDashboard.ps1` for WinForms

## Configuration

### Instance Configuration (Config/instances.json)
```json
[
  {
    "DisplayName": "SERVER\\INSTANCE",
    "SqlInstance": "SERVER\\INSTANCE",
    "RepositoryServer": "REPO_SERVER\\INSTANCE",
    "RepositoryDatabase": "DBA_SQLMonitor",
    "Environment": "Production",
    "IsActive": true
  }
]
```

### Alert Thresholds
Configure in `mon.AlertThresholds` table:
- CPUPercent > 80 for 5 minutes
- Memory utilization patterns
- Job failure detection
- Deadlock frequency
- etc.

## Retention Policy

- Core metrics: 30 days
- Advanced metrics: 45 days
- Daily metrics: 60 days
- Alert history: 90 days
- Collection runs: 30 days

## Security

- Uses Windows Integrated Security
- Service account requires:
  - Read access to monitored SQL instances
  - Read/write access to repository database
  - Local administrator for Task Scheduler

## Troubleshooting

### Common Issues
- **Task Scheduler failures**: Run registration script as administrator
- **Connection errors**: Verify service account permissions
- **Missing data**: Check collector logs in `Logs/SQLMonitor.log`
- **Alert storms**: Review and adjust thresholds

### Log Files
- `Logs/SQLMonitor.log`: All monitoring activity
- Task Scheduler logs: Windows Event Viewer
- SQL Server logs: For repository database issues

## Development

### Adding New Collectors
1. Create module in `Modules/Collect-*.psm1`
2. Follow pattern: Invoke-*Collector function
3. Add to appropriate job runner
4. Update retention procedure
5. Test manually before scheduling

### Extending Dashboard
- Modify `GUI/SQLMonitorDashboard.ps1`
- Add new tabs or controls as needed
- Use existing data access patterns

## Support

This monitoring platform is designed for production use with comprehensive error handling and logging. For issues, check logs first, then verify configuration and permissions.