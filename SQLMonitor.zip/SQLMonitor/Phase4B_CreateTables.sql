USE DBA_SQLMonitor;
GO

IF OBJECT_ID('mon.AgentJobHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.AgentJobHistory
    (
        AgentJobHistoryID BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID INT NOT NULL,
        CaptureTime DATETIME2(7) NOT NULL,
        JobName NVARCHAR(128) NULL,
        Enabled BIT NULL,
        Category NVARCHAR(128) NULL,
        LastRunTime DATETIME NULL,
        LastStatus NVARCHAR(40) NULL,
        LastDurationSec INT NULL,
        NextRunTime DATETIME NULL,
        RunsRecent INT NULL,
        FailuresRecent INT NULL,
        SuccessPctRecent DECIMAL(10,2) NULL,
        AvgDurationSecRecent INT NULL,
        LastFailureTime DATETIME NULL,
        LastFailureMessage NVARCHAR(1024) NULL
    );
END;
GO

IF OBJECT_ID('mon.DeadlockHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DeadlockHistory
    (
        DeadlockHistoryID BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID INT NOT NULL,
        CaptureTime DATETIME2(7) NOT NULL,
        DeadlockTime DATETIME2(0) NULL,
        DeadlockXml NVARCHAR(MAX) NULL
    );
END;
GO

IF OBJECT_ID('mon.AGOverviewHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.AGOverviewHistory
    (
        AGOverviewHistoryID BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID INT NOT NULL,
        CaptureTime DATETIME2(7) NOT NULL,
        AGName SYSNAME NULL,
        PrimaryReplica SYSNAME NULL,
        SyncHealthDesc NVARCHAR(60) NULL,
        BackupPreferenceDesc NVARCHAR(60) NULL,
        FailureConditionLevel INT NULL,
        ClusterTypeDesc NVARCHAR(60) NULL
    );
END;
GO

IF OBJECT_ID('mon.AGReplicaHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.AGReplicaHistory
    (
        AGReplicaHistoryID BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID INT NOT NULL,
        CaptureTime DATETIME2(7) NOT NULL,
        AGName SYSNAME NULL,
        ReplicaServer SYSNAME NULL,
        IsLocal BIT NULL,
        RoleDesc NVARCHAR(60) NULL,
        AvailabilityModeDesc NVARCHAR(60) NULL,
        FailoverModeDesc NVARCHAR(60) NULL,
        SyncHealthDesc NVARCHAR(60) NULL,
        ConnectedStateDesc NVARCHAR(60) NULL
    );
END;
GO

IF OBJECT_ID('mon.AGDatabaseHistory', 'U') IS NULL
BEGIN
    CREATE TABLE mon.AGDatabaseHistory
    (
        AGDatabaseHistoryID BIGINT IDENTITY(1,1) PRIMARY KEY,
        InstanceID INT NOT NULL,
        CaptureTime DATETIME2(7) NOT NULL,
        AGName SYSNAME NULL,
        ReplicaServer SYSNAME NULL,
        DatabaseName SYSNAME NULL,
        IsPrimaryReplica BIT NULL,
        SyncStateDesc NVARCHAR(60) NULL,
        SyncHealthDesc NVARCHAR(60) NULL,
        LogSendQueueMB DECIMAL(18,2) NULL,
        RedoQueueMB DECIMAL(18,2) NULL,
        LastCommitTime DATETIME NULL
    );
END;
GO
