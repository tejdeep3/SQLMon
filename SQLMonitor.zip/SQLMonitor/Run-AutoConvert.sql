DECLARE @TicketsCreated INT;
EXEC mon.usp_AutoConvertAlertsToTickets 
    @HoursBack = 24, 
    @CreatedBy = 'system', 
    @TicketsCreated = @TicketsCreated OUTPUT;
SELECT @TicketsCreated AS TicketsCreated;
GO
