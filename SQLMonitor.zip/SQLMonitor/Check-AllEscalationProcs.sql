-- Check all escalation-related stored procedures
SELECT 'usp_ConfigureEscalation' AS ProcedureName, OBJECT_DEFINITION(OBJECT_ID('mon.usp_ConfigureEscalation')) AS Definition
UNION ALL
SELECT 'usp_GetEscalationRules', OBJECT_DEFINITION(OBJECT_ID('mon.usp_GetEscalationRules'))
UNION ALL
SELECT 'usp_RecordEscalation', OBJECT_DEFINITION(OBJECT_ID('mon.usp_RecordEscalation'));

-- Check if there's a procedure to actually CHECK and PROCESS escalations
SELECT ROUTINE_NAME
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_SCHEMA = 'mon'
  AND (ROUTINE_NAME LIKE '%Escalat%' OR ROUTINE_NAME LIKE '%Check%Escalat%');

-- Check the vw_TicketsPendingEscalation view
SELECT OBJECT_DEFINITION(OBJECT_ID('mon.vw_TicketsPendingEscalation')) AS ViewDefinition;
