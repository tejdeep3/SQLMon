-- Check the correct parameters for usp_RecordEscalation
SELECT PARAMETER_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.PARAMETERS
WHERE SPECIFIC_SCHEMA = 'mon' 
  AND SPECIFIC_NAME = 'usp_RecordEscalation'
ORDER BY ORDINAL_POSITION;

-- Manual test with correct parameters
DECLARE @TicketID BIGINT = 1; -- First ticket
DECLARE @EscalationLevelID INT = 1;
DECLARE @EscalationTo NVARCHAR(255) = 'dba-team@company.com';

-- Record the escalation with correct parameters
EXEC [mon].[usp_RecordEscalation] 
    @TicketID = @TicketID,
    @EscalationLevelID = @EscalationLevelID,
    @EscalatedTo = @EscalationTo,
    @EscalatedBy = 'system',  -- This parameter was missing
    @NotificationSent = 1;

-- Update ticket
UPDATE [mon].[Tickets]
SET [EscalationLevelID] = @EscalationLevelID,
    [ModifiedDate] = SYSUTCDATETIME()
WHERE [TicketID] = @TicketID;

-- Log in comments
INSERT INTO [mon].[TicketComments] ([TicketID], [CommentText], [CreatedBy])
VALUES (@TicketID, 
        'Ticket escalated to ' + @EscalationTo + ' (Manual test)', 
        'system');

SELECT 'Ticket ' + CAST(@TicketID AS NVARCHAR(20)) + ' escalated to ' + @EscalationTo AS Result;
