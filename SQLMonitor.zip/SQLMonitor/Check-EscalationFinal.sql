-- Check escalation matrix data with column aliases
SELECT em.EscalationMatrixID,
       em.TicketSeverityID,
       ts.SeverityName, 
       em.EscalationLevelID,
       em.EscalationTo,
       em.EscalationTimeMinutes,
       em.IsActive
FROM mon.EscalationMatrix em 
JOIN mon.TicketSeverity ts ON em.TicketSeverityID = ts.TicketSeverityID 
WHERE em.IsActive = 1
ORDER BY em.TicketSeverityID, em.EscalationLevelID;

-- Check pending escalations view structure
SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'mon' AND TABLE_NAME = 'vw_TicketsPendingEscalation'
ORDER BY ORDINAL_POSITION;

-- Check open tickets that might need escalation
SELECT TOP 10 t.TicketID, t.TicketNumber, ts.SeverityName, t.CreatedDate, t.TicketStatusID
FROM mon.Tickets t
JOIN mon.TicketSeverity ts ON t.TicketSeverityID = ts.TicketSeverityID
WHERE t.TicketStatusID = 1  -- Open tickets
ORDER BY t.CreatedDate DESC;

-- Count total open tickets
SELECT COUNT(*) AS OpenTickets FROM mon.Tickets WHERE TicketStatusID = 1;
