# SQL Monitor Scheduling Matrix

Complete schedule for all 20 monitoring components across the distributed collection model.

## Execution Schedule Summary

| Schedule | Task | Frequency | Collectors | Purpose |
|---|---|---|---|---|
| **Every 5 min** | Core Collection | 288x/day | 11 collectors | Real-time resource & operational state |
| **Every 30 min** | Advanced Analysis | 48x/day | 3 collectors | Performance analysis & optimization |
| **Daily 2 AM** | Daily Analysis | 1x/day | 5 collectors | Resource-intensive deep analysis |
| **Every 2 min** | Alert Evaluation | 720x/day | Alert Engine | Threshold monitoring & notification |
| **Daily 3 AM** | Data Cleanup | 1x/day | Retention Engine | Repository maintenance |

**Total Data Points Per Day: ~10,656 collection events**

---

## Detailed Schedule

### CORE COLLECTION (Every 5 Minutes)
**Task:** `SQLMonitor-CoreCollectors`  
**Script:** `Run-Collectors-Core.ps1`  
**Execution Time:** ~10-30 seconds  
**Daily Executions:** 288 (24 hours × 60 min ÷ 5)

| # | Collector | Module | Table | Purpose |
|---|---|---|---|---|
| 1 | KPIs | Collect-KPIs.psm1 | mon.KPIHistory | Key performance indicators |
| 2 | Disks | Collect-Disks.psm1 | mon.DiskVolumeHistory | Volume utilization tracking |
| 3 | Config | Collect-Config.psm1 | mon.ConfigHistory | Server configuration drift |
| 4 | CPU | Collect-CPU.psm1 | mon.CPUHistory | CPU utilization trend |
| 5 | Memory | Collect-Memory.psm1 | mon.MemoryHistory | Memory availability trend |
| 6 | I/O | Collect-IO.psm1 | mon.IOFileHistory | File-level latency monitoring |
| 7 | tempdb | Collect-TempDB.psm1 | mon.TempDBHistory | tempdb growth & usage |
| 8 | Backups | Collect-Backups.psm1 | mon.BackupStatusHistory | Backup freshness tracking |
| 9 | DB Options | Collect-DBOptions.psm1 | mon.DBOptionsHistory | Database configuration |
| 10 | Blocking | Collect-Blocking.psm1 | mon.BlockingHistory | Active blocking chains |
| 11 | Long Running | Collect-LongRunning.psm1 | mon.LongRunningHistory | Long-running queries |

**Data Volume:**
- ~11 rows per execution
- 288 executions/day = 3,168 rows/day for core metrics
- Retention: 30 days = ~95,000 rows maintained

**Sample Output:**
```
2026-04-07 11:15:17     Starting CORE collectors for BBLBHLAP860\BBDBTESTSQL
2026-04-07 11:15:17     KPI collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 1
2026-04-07 11:15:17     Disks collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 4
2026-04-07 11:15:18     CPU collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 60
2026-04-07 11:15:18     Memory collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 1
... (remaining collectors)
2026-04-07 11:15:21     Completed CORE collectors for BBLBHLAP860\BBDBTESTSQL
```

---

### ADVANCED COLLECTORS (Every 30 Minutes)
**Task:** `SQLMonitor-AdvancedCollectors`  
**Script:** `Run-Collectors-Advanced.ps1`  
**Execution Time:** ~20-45 seconds  
**Daily Executions:** 48 (24 hours × 60 min ÷ 30)

| # | Collector | Module | Table | Purpose |
|---|---|---|---|---|
| 1 | Waits | Collect-Waits.psm1 | dbo.WaitStats | Wait type distribution analysis |
| 2 | Top Queries | Collect-TopQueries.psm1 | dbo.TopQueries | Query performance ranking |
| 3 | Missing Indexes | Collect-MissingIndexes.psm1 | dbo.MissingIndexes | Index optimization recommendations |

**Data Volume:**
- ~40 rows per execution (across 3 collectors)
- 48 executions/day = 1,920 rows/day for advanced metrics
- Retention: 45 days = ~86,400 rows maintained

**Sample Output:**
```
2026-04-07 11:30:00     Starting ADVANCED collectors for BBLBHLAP860\BBDBTESTSQL
2026-04-07 11:30:05     Waits collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 25
2026-04-07 11:30:15     Top Queries collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 10
2026-04-07 11:30:25     Missing Indexes collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 5
2026-04-07 11:30:30     Completed ADVANCED collectors for BBLBHLAP860\BBDBTESTSQL
```

---

### DAILY COLLECTORS (2:00 AM Daily)
**Task:** `SQLMonitor-DailyCollectors`  
**Script:** `Run-Collectors-Daily.ps1`  
**Execution Time:** ~1-3 minutes (resource-intensive)  
**Daily Executions:** 1

| # | Collector | Module | Table(s) | Purpose |
|---|---|---|---|---|
| 1 | Index Fragmentation | Collect-IndexFragmentation.psm1 | dbo.IndexFragmentation | Fragmentation & rebuild recommendations |
| 2 | Always On / WSFC | Collect-AG.psm1 | mon.AG* (3 tables) | HA/DR cluster health |
| 3 | Listeners & Endpoints | Collect-ListenersEndpoints.psm1 | mon.Listener*/Endpoint* | Listener & endpoint configuration |
| 4 | Agent Jobs | Collect-AgentJobs.psm1 | mon.AgentJobHistory | Job execution & success tracking |
| 5 | Deadlocks | Collect-Deadlocks.psm1 | mon.DeadlockHistory | Deadlock event analysis |

**Data Volume:**
- ~100-500 rows per execution (depends on database count, job count, deadlocks)
- 1 execution/day = variable rows
- Retention: 60 days

**Scheduling Rationale:**
- **2:00 AM** chosen to avoid business hours impact
- Resource-intensive queries (table scans, extended events parsing)
- Infrequent data changes (fragmentation, configuration)
- Allows overnight maintenance window

**Sample Output:**
```
2026-04-07 02:00:00     Starting DAILY collectors for BBLBHLAP860\BBDBTESTSQL
2026-04-07 02:01:15     Index Fragmentation collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 245
2026-04-07 02:02:30     AG collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 18
2026-04-07 02:03:00     Listeners & Endpoints collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 8
2026-04-07 02:03:30     Agent Jobs collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 42
2026-04-07 02:04:15     Deadlocks collector completed for BBLBHLAP860\BBDBTESTSQL. Rows inserted: 2
2026-04-07 02:04:15     Completed DAILY collectors for BBLBHLAP860\BBDBTESTSQL
```

---

### ALERT ENGINE (Every 2 Minutes)
**Task:** `SQLMonitor-AlertEngine`  
**Script:** `Run-AlertEngine.ps1`  
**Execution Time:** ~5-10 seconds  
**Daily Executions:** 720 (24 hours × 60 min ÷ 2)

**Alert Processing Loop:**
1. Query mon.AlertThresholds
2. Evaluate each metric against thresholds
3. Compare current value vs. last 5-minute window
4. Trigger NEW alerts if threshold violated
5. Apply cooldown logic (avoid alert storms)
6. Write to mon.AlertHistory with severity level
7. Escalate critical alerts to dashboard/notifications

**Typical Alert Flow:**
```
Threshold: CPU > 80% for 5 consecutive minutes
Alert ID   | Instance | AlertTime | Severity | Status
-----------|----------|-----------|----------|----------
4          | SERVER\I | 11:10:12  | CRITICAL | Open
5          | SERVER\I | 11:15:15  | CRITICAL | Open
3          | SERVER\I | 11:22:00  | CRITICAL | Acknowledged
```

**Data Volume:**
- ~1-5 rows per execution (alerts triggered)
- 720 executions/day = highly variable
- Retention: 90 days for audit trail

---

### RETENTION CLEANUP (Daily 3:00 AM)
**Task:** `SQLMonitor-RetentionCleanup`  
**Script:** `Purge-Retention.ps1`  
**Execution Time:** ~10-30 seconds  
**Daily Executions:** 1

**Procedure:** `mon.usp_PurgeRetention`

**Deletion Schedule:**
| Category | Retention | Rows Typically Deleted |
|---|---|---|
| Core metrics (CPU, Memory, Disks, I/O, tempdb) | 30 days | ~6,000 |
| Advanced metrics (Waits, Queries, Indexes) | 45 days | ~2,500 |
| Daily metrics (Fragmentation, AG, Jobs, Deadlocks) | 60 days | ~500 |
| Alert history | 90 days | ~500 |
| Collection runs | 30 days | ~500 |

**Sample Output:**
```
2026-04-07 03:00:00     Starting retention cleanup on BBLBHLAP860\BBDBTESTSQL
2026-04-07 03:00:02     Completed retention cleanup on BBLBHLAP860\BBDBTESTSQL
```

---

## Daily Execution Timeline

```
 Minute    Activity                                    Tasks
 ────────────────────────────────────────────────────────────
 00:00     CORE Collection #1 (midnight)              11 collectors
 05:00     CORE Collection #2
 10:00     CORE Collection #3
 ...
 02:00     DAILY Collection (index fragmentation)     5 deep collectors
 02:05     CORE Collection coincides
 03:00     RETENTION CLEANUP                           Purge old data
 03:05     CORE Collection continues
 ...
 20:00     ALERT ENGINE (every 2 min throughout day)  Alert checks
 23:00-02:00 "Off-hours" window                       Heavy operations
```

---

## Resource Impact Estimate

### CPU Impact
- Core collectors: ~5-10% spike for 30 seconds every 5 min
- Advanced collectors: ~10-15% spike for 30 seconds every 30 min
- Daily collectors (2 AM): ~20-30% spike for 2 minutes once/day
- Alert engine: <1% continuous

### Network I/O
- Core: 15-25 KB per execution (11 queries)
- Advanced: 50-100 KB per execution (3 heavy queries)
- Daily: 100-500 KB per execution
- Typical daily network: ~10-15 MB

### Storage
- Per instance per day: ~10-15 MB
- Per instance per month: ~300-450 MB
- Per instance per year: ~3.6-5.4 GB
- Archive recommendation: Partition by year

---

## Fault Tolerance

| Failure Scenario | Recovery | Impact |
|---|---|---|
| Core collection fails | Next execution in 5 min | 5-min data gap |
| Advanced collection fails | Next execution in 30 min | 30-min data gap |
| Daily collection fails | Next execution tomorrow 2 AM | 1-day gap (usually OK) |
| Alert engine fails | Next execution in 2 min | Up to 2-min delayed alerts |
| Retention fails | Next execution tomorrow | Data may not be purged on schedule |

---

## Scaling Consideration

### Single Instance
- Total daily executions: ~10,600
- Daily data volume: ~10,000-15,000 rows
- Repository size growth: ~300-400 MB/month

### Multiple Instances (e.g., 5 instances)
- Total daily executions: ~53,000
- Daily data volume: ~50,000-75,000 rows
- Repository size growth: ~1.5-2 GB/month
- Recommendation: Archive old data quarterly

### Monitoring System Overhead
- Minimal: Task Scheduler + PowerShell + SQL calls
- CPU: <5% average
- RAM: ~100-200 MB
- Disk I/O: Negligible

---

## Tuning Guide

### To Reduce Collection Frequency
- Core: Modify task to every 10 minutes (–mo 10)
- Impact: 144 daily collections instead of 288

### To Skip Collections
- Disable in Task Scheduler if not needed
- E.g., if no AG in environment, disable Listeners task

### To Adjust Retention
Edit Purge-Retention.ps1:
```powershell
# Default: 30 days core, 45 advanced, 60 daily
Invoke-MonitorSqlQuery ... -Query "EXEC mon.usp_PurgeRetention @CoreDays=60, @AdvancedDays=90"
```

---

## Summary

- **11 Core collectors** provide continuous real-time monitoring every 5 minutes
- **3 Advanced collectors** provide detailed analysis every 30 minutes
- **5 Daily collectors** provide comprehensive deep analysis once daily at 2 AM
- **Alert engine** evaluates thresholds continuously every 2 minutes
- **Retention process** automatically maintains data windows and cleanup every 3 AM
- **Total overhead:** Minimal (<5% CPU, ~100-200 MB RAM, ~10-15 MB network/day)
- **Repository growth:** 300-400 MB/month per instance with 30-90 day retention

This schedule balances monitoring granularity with system performance and storage efficiency.
