# SQL Monitor Distributed Collector Architecture

SQL Monitor now supports three deployment roles:

- `Standalone`: application, repository, and collectors run from the same installation.
- `Central`: central repository and web dashboard for the organization.
- `Collector`: lightweight collector node that receives server assignments from the central repository and writes collection data back to it.

## Core Flow

1. The central repository stores monitored instances, collector nodes, assignments, collection runs, alerts, tickets, tasks, BI data, and audit data.
2. Collector nodes register themselves in `mon.CollectorNodes`.
3. Ticket records now carry a global `TicketUID` for distributed dedupe, and ticket numbers will use the central `mon.seq_TicketNumber` sequence when available. Local fallbacks still use the legacy year-based `TKT-YYYY-NNNN` format.
4. Admins assign monitored SQL instances to collector nodes in the web dashboard under `Administration > Collector Nodes`.
4. Collector jobs run on each collector node.
5. Each collector node pulls only its enabled assignments from `mon.CollectorAssignments`.
6. Collection output is written directly to the central repository.
7. Heartbeats are stored in `mon.CollectorNodeHeartbeat`.
8. Every collection run is stamped with `CollectorNodeID` in `mon.CollectionRuns`.

## Local Repository To Central Repository Sync

Some sites collect into a local repository first and then push data into the central repository. This is supported by `Sql\14_CentralRepositorySync.sql`.

This mode requires a linked server from the local repository SQL Server to the central repository SQL Server. The sync stored procedure runs in the local repository and writes to the central repository through the linked server.

Example linked server setup:

```sql
EXEC master.dbo.sp_addlinkedserver
    @server = N'SQLMON_CENTRAL',
    @srvproduct = N'',
    @provider = N'MSOLEDBSQL',
    @datasrc = N'CentralSQL01';

EXEC master.dbo.sp_addlinkedsrvlogin
    @rmtsrvname = N'SQLMON_CENTRAL',
    @useself = N'True';
```

Deployment can create this linked server for you from the local/source repository SQL Server to the central/destination SQL Server:

```powershell
.\Deploy-SQLMonitor.ps1 `
  -RepositoryServer "LocalRepoSQL01" `
  -RepositoryDatabase "DBA_SQLMonitor" `
  -DeployDatabase `
  -ConfigureCentralLinkedServer `
  -CentralLinkedServer "SQLMON_CENTRAL" `
  -CentralServerInstance "CentralSQL01"
```

By default, the linked server uses Windows passthrough authentication. If your environment requires SQL authentication for the remote central server, add:

```powershell
  -CentralLinkedServerLogin "central_sync_login" `
  -CentralLinkedServerPassword "StrongPassword"
```

The Deployment Center GUI also has a `Central Repository Sync` section where admins can create the linked server by entering the central SQL Server name.

Run a sync from the local repository:

```sql
EXEC mon.usp_SyncRepositoryToCentral
    @CentralLinkedServer = N'SQLMON_CENTRAL',
    @CentralDatabase = N'DBA_SQLMonitor',
    @LookbackMinutes = 1440;
```

The same sync can be triggered in the web dashboard:

`Administration > Collector Nodes > Central Repo Sync`

The deployment script also creates a SQL Agent job named `SQLMonitor - Central Repository Sync` when SQL Agent jobs are configured. By default it uses linked server `SQLMON_CENTRAL`; override it during deployment if your linked server name is different:

```powershell
.\Deploy-SQLMonitor.ps1 `
  -RepositoryServer "LocalRepoSQL01" `
  -RepositoryDatabase "DBA_SQLMonitor" `
  -ConfigureSqlAgentJobs `
  -CentralLinkedServer "SQLMON_CENTRAL" `
  -CentralSyncIntervalMinutes 15
```

The procedure:

- Creates or updates matching central `mon.MonitoredInstances` rows by `DisplayName`.
- Remaps local `InstanceID` values to central `InstanceID` values.
- Inserts only missing rows into central history tables.
- Uses table-specific natural keys such as `CaptureTime`, `DatabaseName`, `VolumeMountPoint`, `WaitType`, `JobName`, and similar dimensions.
- Logs each run in `mon.CentralSyncRuns` and per-table results in `mon.CentralSyncTableRuns`.

For testing without inserting rows:

```sql
EXEC mon.usp_SyncRepositoryToCentral
    @CentralLinkedServer = N'SQLMON_CENTRAL',
    @CentralDatabase = N'DBA_SQLMonitor',
    @LookbackMinutes = 60,
    @DryRun = 1;
```

To sync one table:

```sql
EXEC mon.usp_SyncRepositoryToCentral
    @CentralLinkedServer = N'SQLMON_CENTRAL',
    @CentralDatabase = N'DBA_SQLMonitor',
    @TableName = N'CPUHistory',
    @LookbackMinutes = 1440;
```

## Deployment Examples

Central repository and dashboard:

```powershell
.\Deploy-SQLMonitor.ps1 `
  -RepositoryServer "CentralSQL01" `
  -RepositoryDatabase "DBA_SQLMonitor" `
  -DeploymentRole Central `
  -All
```

Collector node using Windows Scheduled Tasks:

```powershell
.\Deploy-SQLMonitor.ps1 `
  -RepositoryServer "CentralSQL01" `
  -RepositoryDatabase "DBA_SQLMonitor" `
  -DeploymentRole Collector `
  -CollectorNodeName "Collector-East-01" `
  -CollectorSite "East DC" `
  -DeployScripts `
  -DeployDatabase `
  -ConfigureWindowsTasks `
  -SkipInstanceConfiguration
```

Collector node using SQL Agent on a local collector SQL instance:

```powershell
.\Deploy-SQLMonitor.ps1 `
  -RepositoryServer "CentralSQL01" `
  -RepositoryDatabase "DBA_SQLMonitor" `
  -DeploymentRole Collector `
  -CollectorNodeName "Collector-East-01" `
  -JobServer "CollectorEast01" `
  -DeployScripts `
  -DeployDatabase `
  -ConfigureSqlAgentJobs `
  -SkipInstanceConfiguration
```

## Operational Notes

- Collector nodes do not need the web dashboard.
- Collector nodes need Windows authentication access to the central repository.
- Assignments are controlled centrally in the web dashboard.
- If a collector node has no assignments, the job exits cleanly and records a `NoAssignments` heartbeat.
- Existing standalone deployments continue to work.
