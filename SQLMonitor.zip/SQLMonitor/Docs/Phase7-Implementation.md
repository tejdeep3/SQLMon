# Phase 7: Complete Monitoring Coverage Implementation

## Overview

Phase 7 expands the SQL Server monitoring platform to cover **all 19 monitoring sections** from the comprehensive health check procedure:

1. KPIs (Key Performance Indicators)
2. Disks (Volume utilization)
3. Config (Server configuration)
4. Memory (Physical memory)
5. CPU (Processor utilization)
6. I/O (File latency)
7. tempdb (Temporary database)
8. Backups (Backup posture)
9. DB Options (Database properties)
10. Blocking (Lock chains)
11. Long Running (Query execution)
12. Waits (Wait statistics)
13. Top Queries (Query performance)
14. Missing Indexes (Index optimization)
15. Index Fragmentation (Fragmentation health)
16. Always On / WSFC (Cluster status)
17. Listeners & Endpoints (Endpoint configuration)
18. Agent Jobs (Job execution)
19. Deadlocks (Deadlock history)

## What Was Added

### New SQL Tables
- **mon.KPIHistory**: Key health indicators (Page Life Expectancy, Buffer Hit Ratio, MAXDOP, etc.)
- **mon.ConfigHistory**: Server configuration snapshot (version, processors, memory settings)
- **mon.DBOptionsHistory**: Database settings (recovery model, encryption, auto-close, etc.)
- **mon.ListenerHistory**: AG Listener configuration
- **mon.EndpointHistory**: Database mirroring and AG endpoints

### New SQL Views (Latest Snapshots)
- mon.vw_LatestKPIs
- mon.vw_LatestConfig
- mon.vw_LatestDBOptions
- mon.vw_LatestListeners
- mon.vw_LatestEndpoints
- mon.vw_LatestIO (updated mapping)
- mon.vw_LatestTempDB (updated mapping)
- mon.vw_LatestWaits (mapped to dbo.WaitStats)
- mon.vw_LatestTopQueries (updated mapping)
- mon.vw_LatestMissingIndexes (updated mapping)
- mon.vw_LatestIndexFragmentation (updated mapping)
- mon.vw_LatestAGOverview (updated mapping)
- mon.vw_LatestAGReplicas (updated mapping)
- mon.vw_LatestAGDatabases (updated mapping)

### PowerShell Collector Modules (20 total)

All modules follow the standard pattern:
1. Get instance ID
2. Start collection run
3. Query data from source
4. Insert into repository
5. Complete collection run

**Core Collectors** (every 5 minutes):
- Collect-KPIs.psm1
- Collect-Disks.psm1
- Collect-Config.psm1
- Collect-Memory.psm1
- Collect-CPU.psm1
- Collect-IO.psm1
- Collect-TempDB.psm1
- Collect-Backups.psm1
- Collect-DBOptions.psm1
- Collect-Blocking.psm1
- Collect-LongRunning.psm1

**Advanced Collectors** (every 30 minutes):
- Collect-Waits.psm1
- Collect-TopQueries.psm1
- Collect-MissingIndexes.psm1

**Daily Collectors** (once per day, 2 AM):
- Collect-IndexFragmentation.psm1
- Collect-AG.psm1
- Collect-ListenersEndpoints.psm1
- Collect-AgentJobs.psm1
- Collect-Deadlocks.psm1

**Alert Engine**:
- Invoke-AlertEngine.psm1

### Updated Job Runners

Three job runners orchestrate collection:

**Run-Collectors-Core.ps1** (every 5 minutes):
```powershell
# 11 fast-changing runtime metrics
Invoke-KPIsCollector
Invoke-DisksCollector
Invoke-ConfigCollector
Invoke-MemoryCollector
Invoke-CPUCollector
Invoke-IOCollector
Invoke-TempDBCollector
Invoke-BackupsCollector
Invoke-DBOptionsCollector
Invoke-BlockingCollector
Invoke-LongRunningCollector
```

**Run-Collectors-Advanced.ps1** (every 30 minutes):
```powershell
# 3 performance analysis metrics
Invoke-WaitsCollector
Invoke-TopQueriesCollector
Invoke-MissingIndexesCollector
```

**Run-Collectors-Daily.ps1** (once daily, 2 AM):
```powershell
# 5 operational/structural metrics
Invoke-IndexFragmentationCollector
Invoke-AGCollector
Invoke-ListenersEndpointsCollector
Invoke-AgentJobsCollector
Invoke-DeadlocksCollector
```

### Dashboard Expansion

The WinForms dashboard now supports tabs for all 19 sections:

- **Overview**: Alert summary + KPI tiles
- **KPIs**: Health indicators
- **Disks**: Volume utilization charts
- **Config**: Server configuration grid
- **Memory**: Memory trend charts
- **CPU**: CPU trend charts
- **I/O**: File latency rankings
- **tempdb**: File growth tracking
- **Backups**: Backup recency status
- **DB Options**: Database settings
- **Blocking**: Current blocking chains
- **Long Running**: Query execution times
- **Waits**: Wait type distribution
- **Top Queries**: Query performance metrics
- **Missing Indexes**: Index recommendations
- **Index Fragmentation**: Fragmentation status
- **Always On**: Replica synchronization
- **Listeners**: Listener configuration
- **Agent Jobs**: Job execution trends
- **Deadlocks**: Deadlock pattern analysis
- **Alerts**: All system alerts with acknowledgement

## Data Retention

Updated retention procedure (`mon.usp_PurgeRetention`) now cleans:
- Core metrics: 30 days
- Advanced metrics: 45 days
- Daily metrics: 60 days
- Alerts: 90 days
- Collection runs: 30 days

## Deployment Steps

1. **Deploy SQL Schema**:
   ```powershell
   sqlcmd -S SERVER\INSTANCE -d DBA_SQLMonitor -i Phase7_CompleteSchemaCoverage.sql
   ```

2. **Update Retention Procedure**:
   ```powershell
   sqlcmd -S SERVER\INSTANCE -d DBA_SQLMonitor -i Phase6_RetentionProcedure.sql
   ```

3. **Verify All Modules Exist**:
   ```powershell
   Get-ChildItem C:\SQLMonitor\Modules\
   ```

4. **Test Collectors Individually**:
   ```powershell
   . C:\SQLMonitor\Modules\Common.psm1
   . C:\SQLMonitor\Modules\Collect-KPIs.psm1
   $instance = Get-Content C:\SQLMonitor\Config\instances.json | ConvertFrom-Json | Select-Object -First 1
   Invoke-KPIsCollector -Instance $instance
   ```

5. **Run Test Collection Cycle**:
   ```powershell
   C:\SQLMonitor\Jobs\Run-Collectors-Core.ps1
   C:\SQLMonitor\Jobs\Run-Collectors-Advanced.ps1
   C:\SQLMonitor\Jobs\Run-Collectors-Daily.ps1
   ```

6. **Verify Data Collection**:
   ```sql
   SELECT TABLE_NAME, COUNT(*) as RecordCount
   FROM INFORMATION_SCHEMA.COLUMNS c
   INNER JOIN (
       SELECT * FROM mon.KPIHistory UNION ALL
       SELECT * FROM mon.ConfigHistory UNION ALL
       -- ... etc
   ) t ON 1=1
   GROUP BY TABLE_NAME
   ORDER BY TABLE_NAME
   ```

7. **Update Scheduled Tasks** (if already registered):
   ```powershell
   schtasks /delete /tn SQLMonitor-* /f
   C:\SQLMonitor\Jobs\Register-SQLMonitorTasks.ps1
   ```

## Monitoring Coverage

✅ **Complete Coverage**: The platform now collects and monitors all 19 sections from the comprehensive SQL Server health check.

✅ **Repository-Backed**: All data stored in DBA_SQLMonitor for historical analysis and trending.

✅ **Real-Time Alerting**: All sections except Config and DB Options support alert thresholds.

✅ **Multi-Tier Scheduling**: Fast (5m), normal (30m), and slow (daily) collection tiers optimize performance.

✅ **Dashboard Integration**: All 20 monitoring tabs available in the WinForms dashboard.

## Testing Checklist

- [ ] All new tables exist in mon schema
- [ ] All new views exist and return correct columns
- [ ] Each collector module executes without error
- [ ] Collection runs complete successfully
- [ ] Data appears in repository tables
- [ ] Dashboard loads all tabs without errors
- [ ] Retention procedure executes successfully
- [ ] Scheduled tasks appear in Task Scheduler
- [ ] Monitor logs show successful collections
- [ ] Alert engine processes all alertable sections

## Next Steps

1. **Customize Alerts**: Update mon.AlertThresholds for each section
2. **Tune Collection Schedule**: Adjust timing based on performance impact
3. **Enable Dashboard Tabs**: Progressively enable new tabs as needed
4. **Production Deployment**: Follow ProductionDeploymentChecklist.md
5. **Performance Baseline**: Establish baseline metrics for trending analysis