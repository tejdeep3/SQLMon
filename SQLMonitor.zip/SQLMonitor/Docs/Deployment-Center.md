# SQL Monitor Deployment Center

Use `Launch-Deployment.bat` for an interactive deployment GUI, or run `Deploy-SQLMonitor.ps1` directly for unattended installs.

## GUI Deployment

1. Run `Launch-Deployment.bat`.
2. Enter the repository SQL Server and repository database name.
3. Enter the install path. Existing folders are supported and will be updated in place. SQL Server Agent jobs run on the repository SQL Server, so this path must exist on that server. Use a local path on the SQL Server or a UNC path that the SQL Agent service account can read.
4. Enter one monitored SQL Server or instance per line.
5. Click `One Click Full Deploy`.
6. After deployment, start the web dashboard with `Launch-WebDashboard.bat`. The default URL is `http://localhost:8090/`; if the port is busy, the server prints the alternate URL.

The GUI also supports partial deployment:

- `Database Only`: deploys database, core/advanced/extended tables, views, stored procedures, alert objects, retention objects, health views, and dashboard security tables.
- `Configure Agent Jobs Only`: creates SQL Server Agent jobs without redeploying schema.
- `Deploy Selected Options`: runs only the checked options.

## Unattended Deployment

Example:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Deploy-SQLMonitor.ps1 `
  -RepositoryServer "SERVER\INSTANCE" `
  -RepositoryDatabase "DBA_SQLMonitor" `
  -InstallPath "C:\SQLMonitor" `
  -MonitoredInstances "SERVER\INSTANCE","SERVER2" `
  -All `
  -ConfigurePerInstanceJobs `
  -Force
```

## What Gets Created

- Repository database if it does not already exist.
- `mon` schema and all required tables, views, and stored procedures, including Execution Plans, Memory Analysis, collection health, alert acknowledgement, and dashboard security objects.
- Dashboard security tables and first admin user.
- Local/deployed `Config\instances.json`, `Config\dashboard-settings.json`, and `Config\notifications.json`.
- Web dashboard files, launchers, `Logs`, and `Patches` download folder.
- SQL Server Agent jobs:
  - `SQLMonitor - Core Collectors`
  - `SQLMonitor - Advanced Collectors`
  - `SQLMonitor - Daily Collectors`
  - `SQLMonitor - Alert Engine`
  - `SQLMonitor - Retention Purge`
  - Optional per-server core collector jobs.

## First Dashboard Login

Default first login:

- User: `admin`
- Password: `Admin@123`

The dashboard forces a password change after first login.

## Web Dashboard Notes

- Server Overview shows monitored servers as status tiles and includes User Management and Instance Management.
- Instance Management supports adding/editing servers, importing CSV/TXT server lists, and exporting the current server list.
- Patch Manager downloads to the local/deployed `Patches` folder by default and links to the Microsoft Update Catalog.
- `Config\notifications.json` is updated to use `http://localhost:8090` unless it already has a custom dashboard URL.

## Refresh Existing Installs

Run the deployment again with `-DeployDatabase -DeployScripts` or use `One Click Full Deploy` to bring older installs up to date. This applies the extended schema tables used by Execution Plans and Memory Analysis, deploys the latest web dashboard/API files, updates launcher defaults, and preserves existing notification settings except for the old local dashboard URL default.

## Self-Healing Upgrade

Use `Upgrade-Repository.bat` or `Upgrade-SQLMonitorRepository.ps1` to repair an existing repository without dropping the database. The upgrade checks required tables, columns, views, procedures, and SQL Agent jobs before and after applying the idempotent schema scripts.

Example:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Upgrade-SQLMonitorRepository.ps1 `
  -RepositoryServer "SERVER\INSTANCE" `
  -RepositoryDatabase "DBA_SQLMonitor" `
  -InstallPath "C:\SQLMonitor" `
  -UpdateSqlAgentJobs
```

The web dashboard also exposes this from Administration > Repository Upgrade for admin users.
