# VM → SQL Server Hierarchy Migration Guide

## Overview

This guide describes the architectural change from a flat monitoring model (where VMs and SQL instances are separate, unrelated entities) to a hierarchical model where:

- **VM (Windows Target)** = Parent/Server level
- **SQL Server Instance(s)** = Child level (one or more per VM)
- **Standalone SQL Instances** = SQL servers not associated with a monitored VM

## What Changed

### 1. Database Schema (`Sql\17_VM_SQL_Hierarchy.sql`)

#### New Column
- `mon.MonitoredInstances.ParentVMID` — Foreign key to `mon.WindowsTargets.TargetID`
- Links each SQL instance to its parent VM

#### New Views
- `mon.vw_VMWithSQLInstances` — Flat view joining VMs with their SQL instances
- `mon.vw_VMSummary` — VM health summary with aggregated SQL instance counts and alert totals
- `mon.vw_SQLInstancesWithVM` — SQL instances with VM context (VM health, CPU, memory, disk)
- `mon.vw_HierarchyOverview` — Combined view of VMs and standalone SQL instances

#### New Stored Procedures
- `mon.usp_GetVMTree` — Returns VM tree with SQL children (multi-resultset)
- `mon.usp_LinkSQLInstanceToVM` — Links a SQL instance to a VM
- `mon.usp_AutoLinkSQLInstancesToVMs` — Auto-links SQL instances to VMs by matching `ServerName` to `ComputerName`

### 2. Configuration (`Config\instances.json`)

#### New Format
```json
{
    "VMs": [
        {
            "VMName": "SERVER01",
            "VMDisplayName": "Production Server 01",
            "IsEnabled": true,
            "SQLInstances": [
                {
                    "DisplayName": "SERVER01\\SQLINST1",
                    "SqlInstance": "SERVER01\\SQLINST1",
                    "RepositoryServer": "SERVER01\\SQLINST1",
                    "RepositoryDatabase": "DBA_SQLMonitor",
                    "Environment": "Production",
                    "IsActive": true
                }
            ]
        }
    ],
    "StandaloneSQLInstances": []
}
```

#### Backward Compatibility
- The old flat format is automatically migrated to the new VM-based format
- Each instance becomes a VM with a single SQL instance
- Migration happens transparently in `Get-SqlMonitorInstanceConfig`

### 3. PowerShell Modules (`Modules\Common.psm1`)

#### New Functions
- `Get-SqlMonitorInstanceConfig` — Reads instances.json and returns normalized config (supports both formats)
- `Get-SqlMonitorVMs` — Returns the list of VMs from configuration

#### Updated Functions
- `Get-SqlMonitorInstances` — Now flattens VM-based config into a single list with VM context fields (`VMName`, `VMDisplayName`, `ParentVMID`)

### 4. Web Dashboard API (`Web\Start-WebServer.ps1`)

#### New Endpoints
- `GET /api/vms` — Returns VM-first hierarchy with nested SQL instances and health data
- `GET /api/vms/tree?vmId={id}` — Returns VM tree for a specific VM

#### Updated Endpoints
- `GET /api/bootstrap` — Now includes `vmHierarchy` data
- `GET /api/overview` — Feature key changed from `overview` to `vm-first-overview`

### 5. Web Dashboard UI (`Web\app.js`)

#### New Rendering
- `renderVMFirstOverview()` — VM-first server overview with nested SQL instances
- `renderVMTiles()` — Renders VM tiles with expandable SQL instance children
- `renderSuiteHome` — Updated to show "Unified Monitoring" as default

### 6. Collector Scripts (`Jobs\Run-Collectors-InstanceGroup.ps1`)

#### Updated Filter Logic
- Instance filter now matches against `VMName` and `VMDisplayName` in addition to existing fields
- Allows running collectors by VM name (runs all SQL instances under that VM)

## Migration Steps

### Step 1: Run Database Migration
```powershell
# From the SQL Monitor root directory
sqlcmd -S "SERVER\INSTANCE" -d "DBA_SQLMonitor" -i "Sql\17_VM_SQL_Hierarchy.sql"
```

Or use the Apply Latest Changes script:
```powershell
.\Apply-LatestChanges.ps1 -RepositoryServer "SERVER\INSTANCE"
```

### Step 2: Link Existing SQL Instances to VMs
```powershell
# Auto-link by matching ServerName to ComputerName
sqlcmd -S "SERVER\INSTANCE" -d "DBA_SQLMonitor" -Q "EXEC mon.usp_AutoLinkSQLInstancesToVMs"
```

### Step 3: Update instances.json
Convert your existing `instances.json` to the new format. See `instances.json.sample` for examples.

The system will still work with the old format (auto-migrated), but the new format is recommended.

### Step 4: Deploy Updated Code
Copy the updated files to your deployment location:
- `Modules\Common.psm1`
- `Jobs\Run-Collectors-InstanceGroup.ps1`
- `Web\Start-WebServer.ps1`
- `Web\app.js`
- `Config\instances.json`

### Step 5: Restart Web Dashboard
```powershell
.\Launch-WebDashboard.bat
```

## Rollback

If you need to rollback:
1. The `ParentVMID` column is nullable — existing data is not affected
2. Revert `instances.json` to the old format
3. Revert the PowerShell and JS files from backup
4. The old API endpoints still work (they just won't have VM hierarchy data)

## Troubleshooting

### "No instance found matching 'SERVERNAME'"
- The filter now matches against VM names too. If you type a VM name, all SQL instances under that VM will be collected.

### Duplicate server entries
- The new hierarchy eliminates duplicates by grouping SQL instances under their parent VM
- Make sure `ParentVMID` is set correctly in `mon.MonitoredInstances`

### VM health not showing
- Ensure `mon.WindowsTargets` has the VM registered
- Ensure `mon.WindowsPerformanceSamples` has recent data
- Run VM collectors: `.\Jobs\Run-WindowsVMCollectors.ps1`
