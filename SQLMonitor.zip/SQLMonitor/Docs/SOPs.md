# Standard Operating Procedures (SOPs)

| Description | SOP | Frequency | IssueID | Severity | Category | Title | Owner | Last Updated |
|---|---|---|---|---|---|---|---|---|
| SQL Server CPU usage is consistently high. | **Detailed SOP:**
	1. **Identify top CPU‑consuming queries** – Run `sys.dm_exec_query_stats` joined with `sys.dm_exec_sql_text` to list queries by total CPU time. Focus on the top 5‑10 queries.
	2. **Inspect execution plans** – Use `SET SHOWPLAN_XML ON` or query the plan cache (`sys.dm_exec_query_plan`) to find missing indexes, scans, or expensive operators.
	3. **Check for missing indexes** – Run the Missing Index DMVs (`sys.dm_db_missing_index_details`) and evaluate the suggested index impact vs. cost.
	4. **Review parameterization** – Ensure frequently executed queries are parameterized to promote plan reuse and reduce compilation overhead.
	5. **Validate host CPU capacity** – Compare SQL Server CPU usage with the underlying VM/physical host CPU counters. If SQL Server consistently hits >90 % and the host has spare capacity, consider scaling up the instance.
	6. **Apply fixes** – Add missing indexes, rewrite inefficient queries, or adjust statistics update frequency. Re‑monitor for at least 24 hours after changes.
	|
| High | 1 | Critical | Performance | High CPU Utilization (>90%) |
| John Doe | 2026-05-04 |
| Pages are being flushed from memory too quickly. | **Detailed SOP:**
	1. **Monitor buffer cache health** – Use `sys.dm_os_performance_counters` for `Page life expectancy` (PLE). A PLE < 300 seconds indicates memory pressure.
	2. **Identify memory‑grant issues** – Query `sys.dm_exec_query_memory_grants` to find queries requesting large grants that are being throttled.
	3. **Check max server memory setting** – Verify that `sp_configure 'max server memory'` is set appropriately for the host’s RAM (leave ~10 % for OS).
	4. **Find expensive queries** – Look for queries with high `logical reads` and `writes` in `sys.dm_exec_query_stats`.
	5. **Add memory or tune queries** – If memory pressure persists after query tuning, increase the VM/host memory allocation.
	|
| Medium | 2 | Critical | Memory | Low Page Life Expectancy |
| Jane Smith | 2026-05-04 |
| Transaction log has reached capacity. | **Detailed SOP:**
	1. **Immediate action** – Perform a transaction‑log backup (`BACKUP LOG … WITH NORECOVERY`) to free space.
	2. **Review backup schedule** – Ensure regular log backups (every 5‑15 minutes for high‑transaction systems) are succeeding.
	3. **Identify long‑running transactions** – Use `sys.dm_tran_active_transactions` and `sys.dm_exec_requests` to spot open transactions that prevent log truncation.
	4. **Adjust log growth** – Verify `LOGFILE` growth settings; avoid small incremental growth (e.g., 10 MB). Use a reasonable autogrowth size (e.g., 10 % of current size) and set a maximum size.
	5. **Consider recovery model** – If point‑in‑time recovery isn’t required, switch to `SIMPLE` recovery to eliminate the need for log backups.
	6. **Monitor** – Set up alerts on `log_reuse_wait_desc` and `log_space_used` to catch future issues early.
	|
| Medium | 3 | High | Storage | Transaction Log Full |
| DBA Team | 2026-05-04 |
| Availability Group databases are not synchronizing. | **Detailed SOP:**
	1. **Check replica health** – Query `sys.dm_hadr_availability_replica_states` for `synchronization_state_desc`. Look for `NOT SYNCHRONIZING` or `DISCONNECTED`.
	2. **Review SQL error logs** – Search the error log on both primary and secondary for AG‑related errors (e.g., network, authentication).
	3. **Validate endpoint connectivity** – Ensure the TCP endpoints (`SELECT * FROM sys.availability_endpoints`) are reachable (ping, telnet to port 5022).
	4. **Disk space** – Verify that the secondary replicas have sufficient free space for the transaction log and data files.
	5. **Permissions** – Confirm that the SQL Server service accounts have the required permissions on the shared network resources.
	6. **Failover readiness** – Run `ALTER AVAILABILITY GROUP … FAILOVER` in a test environment to ensure the secondary can become primary.
	7. **Resolve** – Address any network, disk, or permission issues, then resume data movement with `ALTER DATABASE … SET HADR RESUME`.
	|
| Low | 4 | Critical | Availability | Always On AG Synchronization Issues |
| Ops Lead | 2026-05-04 |
| Queries are blocked for extended periods. | **Detailed SOP:**
	1. **Identify the blocker** – Use `sp_who2` or query `sys.dm_os_waiting_tasks` to locate the session holding locks.
	2. **Examine the blocking query** – Capture the full text (`sys.dm_exec_sql_text`) and execution plan of the blocking session.
	3. **Tune the query** – Add missing indexes, rewrite joins, or break the statement into smaller batches.
	4. **Review transaction scope** – Keep transactions as short as possible; avoid user‑interaction inside a transaction.
	5. **Isolation level** – Consider using `READ COMMITTED SNAPSHOT` or `SNAPSHOT` isolation to reduce lock contention.
	6. **Lock escalation** – Monitor for escalation to table‑level locks; if observed, evaluate partitioning or index redesign.
	7. **Monitoring** – Set up alerts on `blocked_process_report` and `deadlock_graph` to capture recurring patterns.
	|
| High | 5 | High | Performance | Excessive Blocking |
| Support | 2026-05-04 |
| Database backup jobs are failing. | **Detailed SOP:**
	1. **Check job history** – Open the SQL Agent job history for the backup job; note the error number and message.
	2. **Destination permissions** – Verify the service account has write permissions on the backup folder or network share.
	3. **Disk space** – Ensure sufficient free space on the backup destination; consider adding a new drive or cleaning old backups.
	4. **Backup integrity** – After a successful backup, run `RESTORE VERIFYONLY` to confirm the backup file is not corrupted.
	5. **Backup device configuration** – Confirm the backup device path is correct and not using an outdated UNC path.
	6. **Error‑specific actions** – For common errors (e.g., 3201 – insufficient disk space, 1802 – permission denied), follow Microsoft’s KB recommendations.
	7. **Alerting** – Configure an alert on backup failure severity (e.g., severity 16) to notify DBAs immediately.
	|
| Medium | 6 | Critical | Backup | Failed Backup Jobs |
| Backup Admin | 2026-05-04 |
| Repeated authentication failures were detected. | **Detailed SOP:**
	1. **Examine error logs** – Search the SQL Server error log for `Login failed for user` messages; note the client IP and error number.
	2. **Validate connection strings** – Ensure applications are using the correct credentials and that passwords have not expired.
	3. **Account policy** – Verify the login’s password policy, lockout threshold, and expiration settings (`ALTER LOGIN … WITH CHECK_POLICY`).
	4. **Brute‑force detection** – If many distinct IPs are attempting logins, consider enabling IP‑based firewall rules or Azure AD Conditional Access.
	5. **Lockout handling** – For accounts locked out, unlock with `ALTER LOGIN … WITH UNLOCK` after confirming the cause.
	6. **Audit** – Enable login auditing (`FAILED_LOGIN_ATTEMPTS`) and review the audit logs regularly.
	|
| High | 7 | High | Security | Failed Login Attempts |
| Security Team | 2026-05-04 |
| Disk operations are taking too long. | **Detailed SOP:**
	1. **Collect I/O statistics** – Use `sys.dm_io_virtual_file_stats` to identify files with high latency and I/O stalls.
	2. **Check storage tier** – Verify that the database files are on the appropriate storage tier (e.g., Premium SSD vs. Standard HDD) for the workload.
	3. **TempDB placement** – Ensure TempDB files are on fast storage and spread across multiple files (one per CPU core) to reduce contention.
	4. **Index maintenance** – Rebuild or reorganize fragmented indexes (`ALTER INDEX … REBUILD`) to improve read/write efficiency.
	5. **Query tuning** – Identify queries with high logical reads; add covering indexes or rewrite to reduce I/O.
	6. **Monitor latency** – Set up alerts on `Avg Disk sec/Read` and `Avg Disk sec/Write` performance counters.
	|
| Medium | 8 | Medium | Storage | High Disk I/O Latency |
| Infra Team | 2026-05-04 |
