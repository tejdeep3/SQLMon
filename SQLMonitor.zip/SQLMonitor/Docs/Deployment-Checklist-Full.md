# Deployment Checklist - Full Coverage Edition

This checklist ensures complete deployment of the comprehensive 19-section SQL Server monitoring platform with all collectors, repository tables, views, and dashboards.

## Phase 0: Prerequisites

- [ ] SQL Server 2016 SP2 or later on monitored instances
- [ ] SQL Server 2016 SP2 or later for repository (DBA_SQLMonitor)
- [ ] Windows Server 2012 R2 or later for monitoring host
- [ ] PowerShell 5.0 or later with .NET System.Data.SqlClient
- [ ] Local Administrator access on monitoring host
- [ ] SQL Server system admin rights on repository
- [ ] Read permissions on monitored instances
- [ ] TrustServerCertificate=True configured in connection strings

## Phase 1: Repository Setup

- [ ] Create DBA_SQLMonitor database
- [ ] Create mon schema
- [ ] Execute Phase 0-6 SQL scripts in order:
  - [ ] 01_Create_Database.sql
  - [ ] 02_Create_Tables.sql
  - [ ] 03_Create_Views.sql
  - [ ] 04_Create_Procedures.sql
  - [ ] 05_Seed_Data.sql
  - [ ] 06_Validation_Queries.sql
  - [ ] 07_Extended_Tables.sql
  - [ ] 08_Extended_Views.sql
  - [ ] 09_Retention_Procedure.sql (usp_PurgeRetention)
- [ ] Verify repository tables:
  - [ ] mon.MonitoredInstances
  - [ ] mon.AlertThresholds
  - [ ] mon.CollectionRuns
  - [ ] All 20+ History/Status tables
- [ ] Verify repository views (15+ views)
- [ ] Create test alert thresholds

## Phase 2: Framework Modules

- [ ] Verify Common.psm1 functions:
  - [ ] Get-MonitorInstanceId
  - [ ] Invoke-MonitorSqlQuery
  - [ ] Invoke-MonitorSqlScalar
  - [ ] Invoke-MonitorSqlNonQuery
  - [ ] Write-MonitorLog
  - [ ] Start-CollectionRun
  - [ ] End-CollectionRun
- [ ] Test Common module:
  ```powershell
  Import-Module C:\SQLMonitor\Modules\Common.psm1
  Get-MonitorInstanceId -RepositoryServer "SERVER\INSTANCE" -RepositoryDatabase "DBA_SQLMonitor" -DisplayName "Test Instance"
  ```

## Phase 3: Core Collectors (Every 5 minutes)

All 11 core collectors must exist, be importable, and return valid data:

- [ ] Collect-KPIs.psm1
  - [ ] Captures: PLE, Buffer Hit Ratio, MAXDOP, Cost Threshold, Memory settings
  - [ ] Writes to: mon.KPIHistory
  - [ ] Test: Run-Collectors-Core.ps1, verify 1 row in mon.KPIHistory
  
- [ ] Collect-Disks.psm1
  - [ ] Captures: Volume mount points, total/free space, utilization
  - [ ] Writes to: mon.DiskVolumeHistory
  - [ ] Test: Verify rows match detected volumes

- [ ] Collect-Config.psm1
  - [ ] Captures: All server configurations
  - [ ] Writes to: mon.ConfigHistory
  - [ ] Test: Verify 50+ configuration rows

- [ ] Collect-Memory.psm1
  - [ ] Captures: Available, total, process memory
  - [ ] Writes to: mon.MemoryHistory
  - [ ] Test: Verify 1 row with non-zero memory values

- [ ] Collect-CPU.psm1
  - [ ] Captures: SQL CPU, Other CPU, Idle percentages
  - [ ] Writes to: mon.CPUHistory
  - [ ] Test: Verify 60 rows from 60-second collection

- [ ] Collect-IO.psm1
  - [ ] Captures: Database files, latency, stalls
  - [ ] Writes to: mon.IOFileHistory
  - [ ] Test: Verify rows for all user databases

- [ ] Collect-TempDB.psm1
  - [ ] Captures: File count, total size, used space
  - [ ] Writes to: mon.TempDBHistory
  - [ ] Test: Verify 1 row with correct file count

- [ ] Collect-Backups.psm1 *(already tested)*
  - [ ] Captures: Last full, diff, log backup times
  - [ ] Writes to: mon.BackupStatusHistory
  - [ ] Status: ✅ Verified working

- [ ] Collect-DBOptions.psm1
  - [ ] Captures: Database state, recovery model, encryption, sizes
  - [ ] Writes to: mon.DBOptionsHistory
  - [ ] Test: Verify rows for all user databases

- [ ] Collect-Blocking.psm1
  - [ ] Captures: Active blocking chains, wait times, statements
  - [ ] Writes to: mon.BlockingHistory
  - [ ] Test: Trigger blocking scenario, verify capture

- [ ] Collect-LongRunning.psm1
  - [ ] Captures: Long-running queries, duration, resources
  - [ ] Writes to: mon.LongRunningHistory
  - [ ] Test: Run long transaction, verify capture

**Core Collectors Test:**
```powershell
cd C:\SQLMonitor\Jobs
.\Run-Collectors-Core.ps1
# Check Logs\SQLMonitor.log for "Completed CORE collectors"
```

## Phase 4: Advanced Collectors (Every 30 minutes)

All 3 advanced collectors must exist and function:

- [ ] Collect-Waits.psm1
  - [ ] Captures: Wait statistics by type
  - [ ] Writes to: dbo.WaitStats
  - [ ] Test: Verify 10+ wait types

- [ ] Collect-TopQueries.psm1
  - [ ] Captures: Top queries by CPU, reads, duration
  - [ ] Writes to: dbo.TopQueries
  - [ ] Test: Verify rows from plan cache

- [ ] Collect-MissingIndexes.psm1
  - [ ] Captures: High-impact missing indexes
  - [ ] Writes to: dbo.MissingIndexes
  - [ ] Test: Verify recommendations

**Advanced Collectors Test:**
```powershell
.\Run-Collectors-Advanced.ps1
# Check Logs\SQLMonitor.log for "Completed ADVANCED collectors"
```

## Phase 5: Daily Collectors (2 AM daily)

All 5 daily collectors must exist and function:

- [ ] Collect-IndexFragmentation.psm1
  - [ ] Captures: Index fragmentation, recommended actions
  - [ ] Writes to: dbo.IndexFragmentation
  - [ ] Test: Verify fragmentation data

- [ ] Collect-AG.psm1 *(already tested)*
  - [ ] Captures: AG overview, replicas, databases, sync health
  - [ ] Writes to: mon.AG* (3 tables)
  - [ ] Status: ✅ Verified working

- [ ] Collect-ListenersEndpoints.psm1
  - [ ] Captures: AG listeners, mirroring endpoints
  - [ ] Writes to: mon.ListenerHistory, mon.EndpointHistory
  - [ ] Test: Verify listener and endpoint data

- [ ] Collect-AgentJobs.psm1 *(already tested)*
  - [ ] Captures: Job status, success rate, last run
  - [ ] Writes to: mon.AgentJobHistory
  - [ ] Status: ✅ Verified working

- [ ] Collect-Deadlocks.psm1 *(already tested)*
  - [ ] Captures: Deadlock events, participants
  - [ ] Writes to: mon.DeadlockHistory
  - [ ] Status: ✅ Verified working

**Daily Collectors Test:**
```powershell
.\Run-Collectors-Daily.ps1
# Check Logs\SQLMonitor.log for "Completed DAILY collectors"
```

## Phase 6: Alert Engine

- [ ] Invoke-AlertEngine.psm1 *(already tested)*
  - [ ] Evaluates all thresholds
  - [ ] Writes to: mon.AlertHistory
  - [ ] Status: ✅ Verified working (4 alerts detected)

**Alert Engine Test:**
```powershell
.\Run-AlertEngine.ps1
# Should output: "Alert run complete for INSTANCE: N active/recent alerts found"
```

## Phase 7: Repository Cleanup

- [ ] Test retention procedure:
  ```powershell
  .\Purge-Retention.ps1
  # Check log for "Completed retention cleanup"
  ```
- [ ] Verify data is removed per retention policy
- [ ] Verify alert history maintains 90-day window

## Phase 8: Task Scheduler Integration

All tasks must be registered and running:

- [ ] **SQLMonitor-CoreCollectors**
  - [ ] Frequency: Every 5 minutes
  - [ ] Command: Run-Collectors-Core.ps1
  - [ ] Status: Verify in "Last Run Time"
  
- [ ] **SQLMonitor-AdvancedCollectors**
  - [ ] Frequency: Every 30 minutes
  - [ ] Command: Run-Collectors-Advanced.ps1
  - [ ] Status: Verify in "Last Run Time"
  
- [ ] **SQLMonitor-DailyCollectors**
  - [ ] Frequency: Daily at 2:00 AM
  - [ ] Command: Run-Collectors-Daily.ps1
  - [ ] Status: Verify in "Last Run Time"
  
- [ ] **SQLMonitor-AlertEngine**
  - [ ] Frequency: Every 2 minutes
  - [ ] Command: Run-AlertEngine.ps1
  - [ ] Status: Verify in "Last Run Time"
  
- [ ] **SQLMonitor-RetentionCleanup**
  - [ ] Frequency: Daily at 3:00 AM
  - [ ] Command: Purge-Retention.ps1
  - [ ] Status: Verify in "Last Run Time"

**Task Registration:**
```powershell
# Run as Administrator
.\Register-SQLMonitorTasks.ps1
# Verify tasks exist
schtasks /query /tn "SQLMonitor-*"
```

## Phase 9: Dashboard

- [ ] Launch dashboard:
  ```powershell
  .\SQLMonitorDashboard.ps1
  ```

- [ ] Verify all tabs load without errors:
  - [ ] Overview (KPI summary, alert tiles)
  - [ ] KPIs (Page Life, Buffer Hit, settings)
  - [ ] Disks (Volume utilization)
  - [ ] Config (Server configurations)
  - [ ] Memory (Memory trend)
  - [ ] CPU (CPU trend)
  - [ ] Waits (Wait breakdown)
  - [ ] I/O (File latency ranking)
  - [ ] tempdb (File count, fullness)
  - [ ] Backups (Last backup times)
  - [ ] DB Options (Database settings)
  - [ ] Blocking (Active blocks)
  - [ ] Long Running (Query durations)
  - [ ] Top Queries (CPU/Reads ranking)
  - [ ] Missing Indexes (Index recommendations)
  - [ ] Index Fragmentation (Rebuild/Reorganize actions)
  - [ ] Always On (Replica/Database sync)
  - [ ] Listeners (Listener status)
  - [ ] Agent Jobs (Job health)
  - [ ] Deadlocks (Recent deadlocks)
  - [ ] Alerts (Alert history + acknowledgement)

- [ ] Test data refresh (should auto-update)
- [ ] Test alert acknowledgement (mark alert as acknowledged)
- [ ] Test filtering and sorting

## Phase 10: Production Validation

- [ ] Allow 24 hours of data collection
- [ ] Verify:
  - [ ] All 20+ history tables have data
  - [ ] All 15+ views return current data
  - [ ] Alerts trigger on threshold violations
  - [ ] Log file grows normally (no errors)
  - [ ] Task Scheduler executes all jobs successfully
  - [ ] Dashboard reflects real-time data
  - [ ] Retention cleanup runs and removes old data

- [ ] Monitor log file:
  ```powershell
  Get-Content C:\SQLMonitor\Logs\SQLMonitor.log -Tail 20 -Wait
  ```

## Phase 11: Monitoring & Alerting

- [ ] Configure critical alerts in mon.AlertThresholds:
  - [ ] CPU > 80%
  - [ ] Memory available < 10%
  - [ ] Disk free < 10%
  - [ ] Active blocking detected
  - [ ] Deadlock detected
  - [ ] Backup overdue > 24 hours
  - [ ] Agent job failed

- [ ] Set up log rotation for SQLMonitor.log

- [ ] Document escalation procedures:
  - [ ] Who to contact for high-severity alerts
  - [ ] Expected response time
  - [ ] Mitigation steps for common alerts

## Phase 12: Documentation & Training

- [ ] Complete Module-Coverage-Matrix.md
- [ ] Complete Scheduling-Matrix.md
- [ ] Complete Production-Runbook.md
- [ ] Training on:
  - [ ] Dashboard usage
  - [ ] Alert management
  - [ ] Adding new collectors
  - [ ] Troubleshooting common issues

## Go-Live Checklist

- [ ] All collectors verified working
- [ ] All tasks scheduled and executing
- [ ] Dashboard fully functional
- [ ] 24-hour baseline data collected
- [ ] Alert thresholds reviewed and approved
- [ ] Escalation procedures documented
- [ ] Team trained on dashboard
- [ ] Backup/recovery procedures tested
- [ ] Security review completed
- [ ] Sign-off from DBA team

---

**Sign-Off:**

- [ ] **DBA Lead:** _________________________ Date: _______
- [ ] **Infrastructure:** _________________________ Date: _______
- [ ] **Operations:** _________________________ Date: _______

---

**Go-Live Date:** _____________

**Post-Go-Live Review:** _____________
