-- Manual test: Escalate a specific ticket
DECLARE @TicketID BIGINT = 1; -- First ticket
DECLARE @EscalationLevelID INT = 1;
DECLARE @EscalationTo NVARCHAR(255);

-- Get escalation details
SELECT @EscalationTo = em.EscalationTo
FROM [mon].[EscalationMatrix] em
JOIN [mon].[Tickets] t ON em.TicketSeverityID = t.TicketSeverityID
WHERE t.TicketID = @TicketID
  AND em.EscalationLevelID = @EscalationLevelID
  AND em.IsActive = 1;

-- Record the escalation
EXEC [mon].[usp_RecordEscalation] 
    @TicketID = @TicketID,
    @EscalationLevelID = @EscalationLevelID,
    @EscalatedTo = @EscalationTo,
    @NotificationSent = 1;

-- Update ticket
UPDATE [mon].[Tickets]
SET [EscalationLevelID] = @EscalationLevelID,
    [ModifiedDate] = SYSUTCDATETIME()
WHERE [TicketID] = @TicketID;

-- Log in comments
INSERT INTO [mon].[TicketComments] ([TicketID], [CommentText], [CreatedBy])
VALUES (@TicketID, 
        'Ticket escalated to ' + @EscalationTo + ' (Manual test)', 
        'system');

SELECT 'Ticket ' + CAST(@TicketID AS NVARCHAR(20)) + ' escalated to ' + @EscalationTo AS Result;
