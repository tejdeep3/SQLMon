-- Fix duplicate ticket numbers
-- First, let's see the current state
SELECT TicketNumber, COUNT(*) AS Cnt
FROM mon.Tickets
GROUP BY TicketNumber
ORDER BY TicketNumber;

-- Update ticket numbers to be unique
DECLARE @Year VARCHAR(4) = YEAR(SYSUTCDATETIME());
DECLARE @Counter BIGINT = 1;
DECLARE @TicketID BIGINT;
DECLARE @NewNumber VARCHAR(50);

DECLARE ticket_cursor CURSOR FAST_FORWARD FOR
SELECT TicketID FROM mon.Tickets ORDER BY TicketID;

OPEN ticket_cursor;
FETCH NEXT FROM ticket_cursor INTO @TicketID;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @NewNumber = 'TKT-' + @Year + '-' + RIGHT('0000' + CAST(@Counter AS VARCHAR(10)), 4);
    
    UPDATE mon.Tickets
    SET TicketNumber = @NewNumber
    WHERE TicketID = @TicketID;
    
    SET @Counter = @Counter + 1;
    FETCH NEXT FROM ticket_cursor INTO @TicketID;
END

CLOSE ticket_cursor;
DEALLOCATE ticket_cursor;

-- Verify the fix
SELECT TicketNumber, COUNT(*) AS Cnt
FROM mon.Tickets
GROUP BY TicketNumber
ORDER BY TicketNumber;
