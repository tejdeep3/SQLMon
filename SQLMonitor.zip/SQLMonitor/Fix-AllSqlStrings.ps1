# Fix-UpdateTask.ps1
$filePath = Join-Path $PSScriptRoot "Web\Start-WebServer.ps1"
$content = Get-Content $filePath -Raw

# Fix the Invoke-RepoNonQuery line for UpdateTask
$oldPattern = 'Invoke-RepoNonQuery -Query "EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;" -Parameters @{'
$newPattern = 'Invoke-RepoNonQuery -Query ''EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;'' -Parameters @{'

if ($content.Contains($oldPattern)) {
    $content = $content.Replace($oldPattern, $newPattern)
    Set-Content -Path $filePath -Value $content -Encoding UTF8
    Write-Host "Fixed UpdateTask SQL string quotes"
} else {
    Write-Host "Pattern not found for UpdateTask"
}

# Also fix CreateTask if needed
$oldPattern2 = 'Invoke-RepoNonQuery -Query "EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;" -Parameters @{'
$newPattern2 = 'Invoke-RepoNonQuery -Query ''EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;'' -Parameters @{'

if ($content.Contains($oldPattern2)) {
    $content = $content.Replace($oldPattern2, $newPattern2)
    Set-Content -Path $filePath -Value $content -Encoding UTF8
    Write-Host "Fixed CreateTask SQL string quotes"
}

# Also fix CreateTicketFromAlert if needed
$oldPattern3 = 'Invoke-RepoQuery -Query "EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;" -Parameters @{'
$newPattern3 = 'Invoke-RepoQuery -Query ''EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;'' -Parameters @{'

if ($content.Contains($oldPattern3)) {
    $content = $content.Replace($oldPattern3, $newPattern3)
    Set-Content -Path $filePath -Value $content -Encoding UTF8
    Write-Host "Fixed CreateTicketFromAlert SQL string quotes"
}

Write-Host "All fixes applied"
