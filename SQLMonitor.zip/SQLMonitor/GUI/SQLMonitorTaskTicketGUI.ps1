# SQLMonitorTaskTicketGUI.ps1 - GUI for Task Management, Ticketing System, and Escalation Matrix
# Provides a user interface for DBA team to manage tasks, tickets, and escalation rules

param(
    [string]$ProjectRoot = ""
)

# Resolve ProjectRoot if not provided
if ([string]::IsNullOrEmpty($ProjectRoot)) {
    # Try to determine project root from script location
    if ($PSScriptRoot) {
        $ProjectRoot = Split-Path -Parent $PSScriptRoot
    }
    elseif ($MyInvocation.MyCommand.Path) {
        $ProjectRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
    }
    else {
        $ProjectRoot = (Get-Location).Path
    }
}

# Validate project root exists
if (-not (Test-Path $ProjectRoot)) {
    [System.Windows.Forms.MessageBox]::Show(
        "Project root not found: $ProjectRoot",
        "Path Error",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Import required modules
$modulePath = Join-Path $ProjectRoot 'Modules\Common.psm1'
if (Test-Path $modulePath) {
    Import-Module $modulePath -Force -WarningAction SilentlyContinue
}
else {
    Write-Warning "Common module not found at: $modulePath"
}

$modulePath = Join-Path $ProjectRoot 'Modules\TaskManagement.psm1'
if (Test-Path $modulePath) {
    Import-Module $modulePath -Force -WarningAction SilentlyContinue
}
else {
    Write-Warning "TaskManagement module not found at: $modulePath"
}

$modulePath = Join-Path $ProjectRoot 'Modules\TicketSystem.psm1'
if (Test-Path $modulePath) {
    Import-Module $modulePath -Force -WarningAction SilentlyContinue
}
else {
    Write-Warning "TicketSystem module not found at: $modulePath"
}

$modulePath = Join-Path $ProjectRoot 'Modules\EscalationMatrix.psm1'
if (Test-Path $modulePath) {
    Import-Module $modulePath -Force -WarningAction SilentlyContinue
}
else {
    Write-Warning "EscalationMatrix module not found at: $modulePath"
}

# Get current user
$script:CurrentUser = $env:USERNAME

# Main Form
$form = New-Object System.Windows.Forms.Form
$form.Text = "SQL Monitor - Task, Ticket & Escalation Management"
$form.Size = New-Object System.Drawing.Size(1400, 900)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "Sizable"

# Create Tab Control
$tabControl = New-Object System.Windows.Forms.TabControl
$tabControl.Location = New-Object System.Drawing.Point(10, 10)
$tabControl.Size = New-Object System.Drawing.Size(1360, 840)
$tabControl.Anchor = "Top, Bottom, Left, Right"
$form.Controls.Add($tabControl)

# ============================================
# TAB 1: TASK MANAGEMENT
# ============================================
$tabTasks = New-Object System.Windows.Forms.TabPage
$tabTasks.Text = "Task Management"
$tabControl.Controls.Add($tabTasks)

# Task List
$lblTaskList = New-Object System.Windows.Forms.Label
$lblTaskList.Location = New-Object System.Drawing.Point(10, 10)
$lblTaskList.Size = New-Object System.Drawing.Size(100, 20)
$lblTaskList.Text = "Tasks:"
$tabTasks.Controls.Add($lblTaskList)

$dgvTasks = New-Object System.Windows.Forms.DataGridView
$dgvTasks.Location = New-Object System.Drawing.Point(10, 35)
$dgvTasks.Size = New-Object System.Drawing.Size(1330, 300)
$dgvTasks.Anchor = "Top, Left, Right"
$dgvTasks.ReadOnly = $true
$dgvTasks.AllowUserToAddRows = $false
$dgvTasks.AllowUserToDeleteRows = $false
$dgvTasks.SelectionMode = "FullRowSelect"
$dgvTasks.MultiSelect = $false
$tabTasks.Controls.Add($dgvTasks)

# Task Filter Panel
$pnlTaskFilter = New-Object System.Windows.Forms.Panel
$pnlTaskFilter.Location = New-Object System.Drawing.Point(10, 345)
$pnlTaskFilter.Size = New-Object System.Drawing.Size(1330, 40)
$pnlTaskFilter.Anchor = "Top, Left, Right"
$tabTasks.Controls.Add($pnlTaskFilter)

$lblFilterAssigned = New-Object System.Windows.Forms.Label
$lblFilterAssigned.Location = New-Object System.Drawing.Point(0, 10)
$lblFilterAssigned.Size = New-Object System.Drawing.Size(60, 20)
$lblFilterAssigned.Text = "Assigned:"
$pnlTaskFilter.Controls.Add($lblFilterAssigned)

$txtFilterAssigned = New-Object System.Windows.Forms.TextBox
$txtFilterAssigned.Location = New-Object System.Drawing.Point(65, 8)
$txtFilterAssigned.Size = New-Object System.Drawing.Size(120, 20)
$pnlTaskFilter.Controls.Add($txtFilterAssigned)

$lblFilterStatus = New-Object System.Windows.Forms.Label
$lblFilterStatus.Location = New-Object System.Drawing.Point(200, 10)
$lblFilterStatus.Size = New-Object System.Drawing.Size(40, 20)
$lblFilterStatus.Text = "Status:"
$pnlTaskFilter.Controls.Add($lblFilterStatus)

$cmbFilterStatus = New-Object System.Windows.Forms.ComboBox
$cmbFilterStatus.Location = New-Object System.Drawing.Point(245, 8)
$cmbFilterStatus.Size = New-Object System.Drawing.Size(120, 20)
$cmbFilterStatus.DropDownStyle = "DropDownList"
$cmbFilterStatus.Items.Add("") | Out-Null
$cmbFilterStatus.Items.Add("Open") | Out-Null
$cmbFilterStatus.Items.Add("In Progress") | Out-Null
$cmbFilterStatus.Items.Add("Pending") | Out-Null
$cmbFilterStatus.Items.Add("Completed") | Out-Null
$cmbFilterStatus.Items.Add("Cancelled") | Out-Null
$cmbFilterStatus.Items.Add("On Hold") | Out-Null
$pnlTaskFilter.Controls.Add($cmbFilterStatus)

$lblFilterPriority = New-Object System.Windows.Forms.Label
$lblFilterPriority.Location = New-Object System.Drawing.Point(380, 10)
$lblFilterPriority.Size = New-Object System.Drawing.Size(45, 20)
$lblFilterPriority.Text = "Priority:"
$pnlTaskFilter.Controls.Add($lblFilterPriority)

$cmbFilterPriority = New-Object System.Windows.Forms.ComboBox
$cmbFilterPriority.Location = New-Object System.Drawing.Point(430, 8)
$cmbFilterPriority.Size = New-Object System.Drawing.Size(120, 20)
$cmbFilterPriority.DropDownStyle = "DropDownList"
$cmbFilterPriority.Items.Add("") | Out-Null
$cmbFilterPriority.Items.Add("Critical") | Out-Null
$cmbFilterPriority.Items.Add("High") | Out-Null
$cmbFilterPriority.Items.Add("Medium") | Out-Null
$cmbFilterPriority.Items.Add("Low") | Out-Null
$pnlTaskFilter.Controls.Add($cmbFilterPriority)

$chkIncludeCompleted = New-Object System.Windows.Forms.CheckBox
$chkIncludeCompleted.Location = New-Object System.Drawing.Point(565, 10)
$chkIncludeCompleted.Size = New-Object System.Drawing.Size(120, 20)
$chkIncludeCompleted.Text = "Include Completed"
$chkIncludeCompleted.Checked = $false
$pnlTaskFilter.Controls.Add($chkIncludeCompleted)

$btnRefreshTasks = New-Object System.Windows.Forms.Button
$btnRefreshTasks.Location = New-Object System.Drawing.Point(700, 6)
$btnRefreshTasks.Size = New-Object System.Drawing.Size(80, 24)
$btnRefreshTasks.Text = "Refresh"
$btnRefreshTasks.Add_Click({ Load-Tasks })
$pnlTaskFilter.Controls.Add($btnRefreshTasks)

# Task Details/Edit Panel
$pnlTaskDetails = New-Object System.Windows.Forms.Panel
$pnlTaskDetails.Location = New-Object System.Drawing.Point(10, 395)
$pnlTaskDetails.Size = New-Object System.Drawing.Size(1330, 400)
$pnlTaskDetails.Anchor = "Top, Bottom, Left, Right"
$tabTasks.Controls.Add($pnlTaskDetails)

$lblTaskTitle = New-Object System.Windows.Forms.Label
$lblTaskTitle.Location = New-Object System.Drawing.Point(10, 10)
$lblTaskTitle.Size = New-Object System.Drawing.Size(60, 20)
$lblTaskTitle.Text = "Title:"
$pnlTaskDetails.Controls.Add($lblTaskTitle)

$txtTaskTitle = New-Object System.Windows.Forms.TextBox
$txtTaskTitle.Location = New-Object System.Drawing.Point(75, 8)
$txtTaskTitle.Size = New-Object System.Drawing.Size(400, 20)
$pnlTaskDetails.Controls.Add($txtTaskTitle)

$lblTaskAssigned = New-Object System.Windows.Forms.Label
$lblTaskAssigned.Location = New-Object System.Drawing.Point(490, 10)
$lblTaskAssigned.Size = New-Object System.Drawing.Size(60, 20)
$lblTaskAssigned.Text = "Assigned:"
$pnlTaskDetails.Controls.Add($lblTaskAssigned)

$txtTaskAssigned = New-Object System.Windows.Forms.TextBox
$txtTaskAssigned.Location = New-Object System.Drawing.Point(555, 8)
$txtTaskAssigned.Size = New-Object System.Drawing.Size(150, 20)
$pnlTaskDetails.Controls.Add($txtTaskAssigned)

$lblTaskPriority = New-Object System.Windows.Forms.Label
$lblTaskPriority.Location = New-Object System.Drawing.Point(720, 10)
$lblTaskPriority.Size = New-Object System.Drawing.Size(45, 20)
$lblTaskPriority.Text = "Priority:"
$pnlTaskDetails.Controls.Add($lblTaskPriority)

$cmbTaskPriority = New-Object System.Windows.Forms.ComboBox
$cmbTaskPriority.Location = New-Object System.Drawing.Point(770, 8)
$cmbTaskPriority.Size = New-Object System.Drawing.Size(120, 20)
$cmbTaskPriority.DropDownStyle = "DropDownList"
$cmbTaskPriority.Items.Add("Critical") | Out-Null
$cmbTaskPriority.Items.Add("High") | Out-Null
$cmbTaskPriority.Items.Add("Medium") | Out-Null
$cmbTaskPriority.Items.Add("Low") | Out-Null
$cmbTaskPriority.SelectedIndex = 2
$pnlTaskDetails.Controls.Add($cmbTaskPriority)

$lblTaskStatus = New-Object System.Windows.Forms.Label
$lblTaskStatus.Location = New-Object System.Drawing.Point(910, 10)
$lblTaskStatus.Size = New-Object System.Drawing.Size(45, 20)
$lblTaskStatus.Text = "Status:"
$pnlTaskDetails.Controls.Add($lblTaskStatus)

$cmbTaskStatus = New-Object System.Windows.Forms.ComboBox
$cmbTaskStatus.Location = New-Object System.Drawing.Point(960, 8)
$cmbTaskStatus.Size = New-Object System.Drawing.Size(120, 20)
$cmbTaskStatus.DropDownStyle = "DropDownList"
$cmbTaskStatus.Items.Add("Open") | Out-Null
$cmbTaskStatus.Items.Add("In Progress") | Out-Null
$cmbTaskStatus.Items.Add("Pending") | Out-Null
$cmbTaskStatus.Items.Add("Completed") | Out-Null
$cmbTaskStatus.Items.Add("Cancelled") | Out-Null
$cmbTaskStatus.Items.Add("On Hold") | Out-Null
$cmbTaskStatus.SelectedIndex = 0
$pnlTaskDetails.Controls.Add($cmbTaskStatus)

$lblTaskDueDate = New-Object System.Windows.Forms.Label
$lblTaskDueDate.Location = New-Object System.Drawing.Point(1095, 10)
$lblTaskDueDate.Size = New-Object System.Drawing.Size(60, 20)
$lblTaskDueDate.Text = "Due Date:"
$pnlTaskDetails.Controls.Add($lblTaskDueDate)

$dtpTaskDueDate = New-Object System.Windows.Forms.DateTimePicker
$dtpTaskDueDate.Location = New-Object System.Drawing.Point(1160, 8)
$dtpTaskDueDate.Size = New-Object System.Drawing.Size(150, 20)
$dtpTaskDueDate.Format = "Custom"
$dtpTaskDueDate.CustomFormat = "yyyy-MM-dd HH:mm"
$dtpTaskDueDate.ShowCheckBox = $true
$dtpTaskDueDate.Checked = $false
$pnlTaskDetails.Controls.Add($dtpTaskDueDate)

$lblTaskDescription = New-Object System.Windows.Forms.Label
$lblTaskDescription.Location = New-Object System.Drawing.Point(10, 45)
$lblTaskDescription.Size = New-Object System.Drawing.Size(80, 20)
$lblTaskDescription.Text = "Description:"
$pnlTaskDetails.Controls.Add($lblTaskDescription)

$txtTaskDescription = New-Object System.Windows.Forms.TextBox
$txtTaskDescription.Location = New-Object System.Drawing.Point(10, 65)
$txtTaskDescription.Size = New-Object System.Drawing.Size(650, 150)
$txtTaskDescription.Multiline = $true
$txtTaskDescription.ScrollBars = "Vertical"
$pnlTaskDetails.Controls.Add($txtTaskDescription)

# Task Buttons
$btnNewTask = New-Object System.Windows.Forms.Button
$btnNewTask.Location = New-Object System.Drawing.Point(10, 225)
$btnNewTask.Size = New-Object System.Drawing.Size(100, 30)
$btnNewTask.Text = "New Task"
$btnNewTask.Add_Click({ New-TaskClick })
$pnlTaskDetails.Controls.Add($btnNewTask)

$btnUpdateTask = New-Object System.Windows.Forms.Button
$btnUpdateTask.Location = New-Object System.Drawing.Point(120, 225)
$btnUpdateTask.Size = New-Object System.Drawing.Size(100, 30)
$btnUpdateTask.Text = "Update Task"
$btnUpdateTask.Add_Click({ Update-TaskClick })
$pnlTaskDetails.Controls.Add($btnUpdateTask)

$btnAddComment = New-Object System.Windows.Forms.Button
$btnAddComment.Location = New-Object System.Drawing.Point(230, 225)
$btnAddComment.Size = New-Object System.Drawing.Size(120, 30)
$btnAddComment.Text = "Add Comment"
$btnAddComment.Add_Click({ Add-TaskCommentClick })
$pnlTaskDetails.Controls.Add($btnAddComment)

$btnViewComments = New-Object System.Windows.Forms.Button
$btnViewComments.Location = New-Object System.Drawing.Point(360, 225)
$btnViewComments.Size = New-Object System.Drawing.Size(120, 30)
$btnViewComments.Text = "View Comments"
$btnViewComments.Add_Click({ View-TaskCommentsClick })
$pnlTaskDetails.Controls.Add($btnViewComments)

# Task Comments Display
$lblComments = New-Object System.Windows.Forms.Label
$lblComments.Location = New-Object System.Drawing.Point(680, 45)
$lblComments.Size = New-Object System.Drawing.Size(100, 20)
$lblComments.Text = "Comments:"
$pnlTaskDetails.Controls.Add($lblComments)

$txtTaskComments = New-Object System.Windows.Forms.TextBox
$txtTaskComments.Location = New-Object System.Drawing.Point(680, 65)
$txtTaskComments.Size = New-Object System.Drawing.Size(640, 320)
$txtTaskComments.Multiline = $true
$txtTaskComments.ScrollBars = "Vertical"
$txtTaskComments.ReadOnly = $true
$pnlTaskDetails.Controls.Add($txtTaskComments)

# ============================================
# TAB 2: TICKETING SYSTEM
# ============================================
$tabTickets = New-Object System.Windows.Forms.TabPage
$tabTickets.Text = "Ticketing System"
$tabControl.Controls.Add($tabTickets)

# Ticket List
$lblTicketList = New-Object System.Windows.Forms.Label
$lblTicketList.Location = New-Object System.Drawing.Point(10, 10)
$lblTicketList.Size = New-Object System.Drawing.Size(100, 20)
$lblTicketList.Text = "Tickets:"
$tabTickets.Controls.Add($lblTicketList)

$dgvTickets = New-Object System.Windows.Forms.DataGridView
$dgvTickets.Location = New-Object System.Drawing.Point(10, 35)
$dgvTickets.Size = New-Object System.Drawing.Size(1330, 300)
$dgvTickets.Anchor = "Top, Left, Right"
$dgvTickets.ReadOnly = $true
$dgvTickets.AllowUserToAddRows = $false
$dgvTickets.AllowUserToDeleteRows = $false
$dgvTickets.SelectionMode = "FullRowSelect"
$dgvTickets.MultiSelect = $false
$tabTickets.Controls.Add($dgvTickets)

# Ticket Filter Panel
$pnlTicketFilter = New-Object System.Windows.Forms.Panel
$pnlTicketFilter.Location = New-Object System.Drawing.Point(10, 345)
$pnlTicketFilter.Size = New-Object System.Drawing.Size(1330, 40)
$pnlTicketFilter.Anchor = "Top, Left, Right"
$tabTickets.Controls.Add($pnlTicketFilter)

$lblTicketFilterAssigned = New-Object System.Windows.Forms.Label
$lblTicketFilterAssigned.Location = New-Object System.Drawing.Point(0, 10)
$lblTicketFilterAssigned.Size = New-Object System.Drawing.Size(60, 20)
$lblTicketFilterAssigned.Text = "Assigned:"
$pnlTicketFilter.Controls.Add($lblTicketFilterAssigned)

$txtTicketFilterAssigned = New-Object System.Windows.Forms.TextBox
$txtTicketFilterAssigned.Location = New-Object System.Drawing.Point(65, 8)
$txtTicketFilterAssigned.Size = New-Object System.Drawing.Size(120, 20)
$pnlTicketFilter.Controls.Add($txtTicketFilterAssigned)

$lblTicketFilterStatus = New-Object System.Windows.Forms.Label
$lblTicketFilterStatus.Location = New-Object System.Drawing.Point(200, 10)
$lblTicketFilterStatus.Size = New-Object System.Drawing.Size(40, 20)
$lblTicketFilterStatus.Text = "Status:"
$pnlTicketFilter.Controls.Add($lblTicketFilterStatus)

$cmbTicketFilterStatus = New-Object System.Windows.Forms.ComboBox
$cmbTicketFilterStatus.Location = New-Object System.Drawing.Point(245, 8)
$cmbTicketFilterStatus.Size = New-Object System.Drawing.Size(120, 20)
$cmbTicketFilterStatus.DropDownStyle = "DropDownList"
$cmbTicketFilterStatus.Items.Add("") | Out-Null
$cmbTicketFilterStatus.Items.Add("New") | Out-Null
$cmbTicketFilterStatus.Items.Add("Acknowledged") | Out-Null
$cmbTicketFilterStatus.Items.Add("In Progress") | Out-Null
$cmbTicketFilterStatus.Items.Add("Resolved") | Out-Null
$cmbTicketFilterStatus.Items.Add("Closed") | Out-Null
$pnlTicketFilter.Controls.Add($cmbTicketFilterStatus)

$lblTicketFilterSeverity = New-Object System.Windows.Forms.Label
$lblTicketFilterSeverity.Location = New-Object System.Drawing.Point(380, 10)
$lblTicketFilterSeverity.Size = New-Object System.Drawing.Size(45, 20)
$lblTicketFilterSeverity.Text = "Severity:"
$pnlTicketFilter.Controls.Add($lblTicketFilterSeverity)

$cmbTicketFilterSeverity = New-Object System.Windows.Forms.ComboBox
$cmbTicketFilterSeverity.Location = New-Object System.Drawing.Point(430, 8)
$cmbTicketFilterSeverity.Size = New-Object System.Drawing.Size(120, 20)
$cmbTicketFilterSeverity.DropDownStyle = "DropDownList"
$cmbTicketFilterSeverity.Items.Add("") | Out-Null
$cmbTicketFilterSeverity.Items.Add("Critical") | Out-Null
$cmbTicketFilterSeverity.Items.Add("High") | Out-Null
$cmbTicketFilterSeverity.Items.Add("Medium") | Out-Null
$cmbTicketFilterSeverity.Items.Add("Low") | Out-Null
$pnlTicketFilter.Controls.Add($cmbTicketFilterSeverity)

$chkTicketIncludeClosed = New-Object System.Windows.Forms.CheckBox
$chkTicketIncludeClosed.Location = New-Object System.Drawing.Point(565, 10)
$chkTicketIncludeClosed.Size = New-Object System.Drawing.Size(120, 20)
$chkTicketIncludeClosed.Text = "Include Closed"
$chkTicketIncludeClosed.Checked = $false
$pnlTicketFilter.Controls.Add($chkTicketIncludeClosed)

$btnRefreshTickets = New-Object System.Windows.Forms.Button
$btnRefreshTickets.Location = New-Object System.Drawing.Point(700, 6)
$btnRefreshTickets.Size = New-Object System.Drawing.Size(80, 24)
$btnRefreshTickets.Text = "Refresh"
$btnRefreshTickets.Add_Click({ Load-Tickets })
$pnlTicketFilter.Controls.Add($btnRefreshTickets)

# Ticket Details Panel
$pnlTicketDetails = New-Object System.Windows.Forms.Panel
$pnlTicketDetails.Location = New-Object System.Drawing.Point(10, 395)
$pnlTicketDetails.Size = New-Object System.Drawing.Size(1330, 400)
$pnlTicketDetails.Anchor = "Top, Bottom, Left, Right"
$tabTickets.Controls.Add($pnlTicketDetails)

$lblTicketNumber = New-Object System.Windows.Forms.Label
$lblTicketNumber.Location = New-Object System.Drawing.Point(10, 10)
$lblTicketNumber.Size = New-Object System.Drawing.Size(80, 20)
$lblTicketNumber.Text = "Ticket #:"
$pnlTicketDetails.Controls.Add($lblTicketNumber)

$txtTicketNumber = New-Object System.Windows.Forms.TextBox
$txtTicketNumber.Location = New-Object System.Drawing.Point(95, 8)
$txtTicketNumber.Size = New-Object System.Drawing.Size(150, 20)
$txtTicketNumber.ReadOnly = $true
$pnlTicketDetails.Controls.Add($txtTicketNumber)

$lblTicketSeverity = New-Object System.Windows.Forms.Label
$lblTicketSeverity.Location = New-Object System.Drawing.Point(260, 10)
$lblTicketSeverity.Size = New-Object System.Drawing.Size(50, 20)
$lblTicketSeverity.Text = "Severity:"
$pnlTicketDetails.Controls.Add($lblTicketSeverity)

$cmbTicketSeverity = New-Object System.Windows.Forms.ComboBox
$cmbTicketSeverity.Location = New-Object System.Drawing.Point(315, 8)
$cmbTicketSeverity.Size = New-Object System.Drawing.Size(120, 20)
$cmbTicketSeverity.DropDownStyle = "DropDownList"
$cmbTicketSeverity.Items.Add("Critical") | Out-Null
$cmbTicketSeverity.Items.Add("High") | Out-Null
$cmbTicketSeverity.Items.Add("Medium") | Out-Null
$cmbTicketSeverity.Items.Add("Low") | Out-Null
$pnlTicketDetails.Controls.Add($cmbTicketSeverity)

$lblTicketAssigned = New-Object System.Windows.Forms.Label
$lblTicketAssigned.Location = New-Object System.Drawing.Point(450, 10)
$lblTicketAssigned.Size = New-Object System.Drawing.Size(60, 20)
$lblTicketAssigned.Text = "Assigned:"
$pnlTicketDetails.Controls.Add($lblTicketAssigned)

$txtTicketAssigned = New-Object System.Windows.Forms.TextBox
$txtTicketAssigned.Location = New-Object System.Drawing.Point(515, 8)
$txtTicketAssigned.Size = New-Object System.Drawing.Size(150, 20)
$pnlTicketDetails.Controls.Add($txtTicketAssigned)

$lblTicketError = New-Object System.Windows.Forms.Label
$lblTicketError.Location = New-Object System.Drawing.Point(10, 45)
$lblTicketError.Size = New-Object System.Drawing.Size(100, 20)
$lblTicketError.Text = "Error Description:"
$pnlTicketDetails.Controls.Add($lblTicketError)

$txtTicketError = New-Object System.Windows.Forms.TextBox
$txtTicketError.Location = New-Object System.Drawing.Point(10, 65)
$txtTicketError.Size = New-Object System.Drawing.Size(650, 150)
$txtTicketError.Multiline = $true
$txtTicketError.ScrollBars = "Vertical"
$pnlTicketDetails.Controls.Add($txtTicketError)

# Ticket Buttons
$btnAcknowledgeTicket = New-Object System.Windows.Forms.Button
$btnAcknowledgeTicket.Location = New-Object System.Drawing.Point(10, 225)
$btnAcknowledgeTicket.Size = New-Object System.Drawing.Size(120, 30)
$btnAcknowledgeTicket.Text = "Acknowledge"
$btnAcknowledgeTicket.Add_Click({ Acknowledge-TicketClick })
$pnlTicketDetails.Controls.Add($btnAcknowledgeTicket)

$btnResolveTicket = New-Object System.Windows.Forms.Button
$btnResolveTicket.Location = New-Object System.Drawing.Point(140, 225)
$btnResolveTicket.Size = New-Object System.Drawing.Size(120, 30)
$btnResolveTicket.Text = "Resolve"
$btnResolveTicket.Add_Click({ Resolve-TicketClick })
$pnlTicketDetails.Controls.Add($btnResolveTicket)

$btnAddTicketComment = New-Object System.Windows.Forms.Button
$btnAddTicketComment.Location = New-Object System.Drawing.Point(270, 225)
$btnAddTicketComment.Size = New-Object System.Drawing.Size(120, 30)
$btnAddTicketComment.Text = "Add Comment"
$btnAddTicketComment.Add_Click({ Add-TicketCommentClick })
$pnlTicketDetails.Controls.Add($btnAddTicketComment)

$btnViewTicketComments = New-Object System.Windows.Forms.Button
$btnViewTicketComments.Location = New-Object System.Drawing.Point(400, 225)
$btnViewTicketComments.Size = New-Object System.Drawing.Size(120, 30)
$btnViewTicketComments.Text = "View Comments"
$btnViewTicketComments.Add_Click({ View-TicketCommentsClick })
$pnlTicketDetails.Controls.Add($btnViewTicketComments)

$btnCreateFromAlert = New-Object System.Windows.Forms.Button
$btnCreateFromAlert.Location = New-Object System.Drawing.Point(530, 225)
$btnCreateFromAlert.Size = New-Object System.Drawing.Size(140, 30)
$btnCreateFromAlert.Text = "Create From Alert"
$btnCreateFromAlert.Add_Click({ CreateFromAlertClick })
$pnlTicketDetails.Controls.Add($btnCreateFromAlert)

# Ticket Comments Display
$lblTicketComments = New-Object System.Windows.Forms.Label
$lblTicketComments.Location = New-Object System.Drawing.Point(680, 45)
$lblTicketComments.Size = New-Object System.Drawing.Size(100, 20)
$lblTicketComments.Text = "Comments:"
$pnlTicketDetails.Controls.Add($lblTicketComments)

$txtTicketComments = New-Object System.Windows.Forms.TextBox
$txtTicketComments.Location = New-Object System.Drawing.Point(680, 65)
$txtTicketComments.Size = New-Object System.Drawing.Size(640, 320)
$txtTicketComments.Multiline = $true
$txtTicketComments.ScrollBars = "Vertical"
$txtTicketComments.ReadOnly = $true
$pnlTicketDetails.Controls.Add($txtTicketComments)

# ============================================
# TAB 3: ESCALATION MATRIX
# ============================================
$tabEscalation = New-Object System.Windows.Forms.TabPage
$tabEscalation.Text = "Escalation Matrix"
$tabControl.Controls.Add($tabEscalation)

# Escalation Rules List
$lblEscalationRules = New-Object System.Windows.Forms.Label
$lblEscalationRules.Location = New-Object System.Drawing.Point(10, 10)
$lblEscalationRules.Size = New-Object System.Drawing.Size(120, 20)
$lblEscalationRules.Text = "Escalation Rules:"
$tabEscalation.Controls.Add($lblEscalationRules)

$dgvEscalationRules = New-Object System.Windows.Forms.DataGridView
$dgvEscalationRules.Location = New-Object System.Drawing.Point(10, 35)
$dgvEscalationRules.Size = New-Object System.Drawing.Size(1330, 300)
$dgvEscalationRules.Anchor = "Top, Left, Right"
$dgvEscalationRules.ReadOnly = $true
$dgvEscalationRules.AllowUserToAddRows = $false
$dgvEscalationRules.AllowUserToDeleteRows = $false
$dgvEscalationRules.SelectionMode = "FullRowSelect"
$dgvEscalationRules.MultiSelect = $false
$tabEscalation.Controls.Add($dgvEscalationRules)

# Escalation Rule Details Panel
$pnlEscalationDetails = New-Object System.Windows.Forms.Panel
$pnlEscalationDetails.Location = New-Object System.Drawing.Point(10, 345)
$pnlEscalationDetails.Size = New-Object System.Drawing.Size(1330, 450)
$pnlEscalationDetails.Anchor = "Top, Bottom, Left, Right"
$tabEscalation.Controls.Add($pnlEscalationDetails)

$lblEscSeverity = New-Object System.Windows.Forms.Label
$lblEscSeverity.Location = New-Object System.Drawing.Point(10, 10)
$lblEscSeverity.Size = New-Object System.Drawing.Size(50, 20)
$lblEscSeverity.Text = "Severity:"
$pnlEscalationDetails.Controls.Add($lblEscSeverity)

$cmbEscSeverity = New-Object System.Windows.Forms.ComboBox
$cmbEscSeverity.Location = New-Object System.Drawing.Point(65, 8)
$cmbEscSeverity.Size = New-Object System.Drawing.Size(120, 20)
$cmbEscSeverity.DropDownStyle = "DropDownList"
$cmbEscSeverity.Items.Add("Critical") | Out-Null
$cmbEscSeverity.Items.Add("High") | Out-Null
$cmbEscSeverity.Items.Add("Medium") | Out-Null
$cmbEscSeverity.Items.Add("Low") | Out-Null
$pnlEscalationDetails.Controls.Add($cmbEscSeverity)

$lblEscLevel = New-Object System.Windows.Forms.Label
$lblEscLevel.Location = New-Object System.Drawing.Point(200, 10)
$lblEscLevel.Size = New-Object System.Drawing.Size(40, 20)
$lblEscLevel.Text = "Level:"
$pnlEscalationDetails.Controls.Add($lblEscLevel)

$cmbEscLevel = New-Object System.Windows.Forms.ComboBox
$cmbEscLevel.Location = New-Object System.Drawing.Point(245, 8)
$cmbEscLevel.Size = New-Object System.Drawing.Size(180, 20)
$cmbEscLevel.DropDownStyle = "DropDownList"
$cmbEscLevel.Items.Add("Level 1 - DBA Team") | Out-Null
$cmbEscLevel.Items.Add("Level 2 - Senior DBA") | Out-Null
$cmbEscLevel.Items.Add("Level 3 - DBA Manager") | Out-Null
$cmbEscLevel.Items.Add("Level 4 - IT Management") | Out-Null
$pnlEscalationDetails.Controls.Add($cmbEscLevel)

$lblEscTime = New-Object System.Windows.Forms.Label
$lblEscTime.Location = New-Object System.Drawing.Point(440, 10)
$lblEscTime.Size = New-Object System.Drawing.Size(100, 20)
$lblEscTime.Text = "Time (minutes):"
$pnlEscalationDetails.Controls.Add($lblEscTime)

$numEscTime = New-Object System.Windows.Forms.NumericUpDown
$numEscTime.Location = New-Object System.Drawing.Point(545, 8)
$numEscTime.Size = New-Object System.Drawing.Size(80, 20)
$numEscTime.Minimum = 1
$numEscTime.Maximum = 1440
$numEscTime.Value = 30
$pnlEscalationDetails.Controls.Add($numEscTime)

$lblEscTo = New-Object System.Windows.Forms.Label
$lblEscTo.Location = New-Object System.Drawing.Point(640, 10)
$lblEscTo.Size = New-Object System.Drawing.Size(60, 20)
$lblEscTo.Text = "Escalate To:"
$pnlEscalationDetails.Controls.Add($lblEscTo)

$txtEscTo = New-Object System.Windows.Forms.TextBox
$txtEscTo.Location = New-Object System.Drawing.Point(705, 8)
$txtEscTo.Size = New-Object System.Drawing.Size(300, 20)
$pnlEscalationDetails.Controls.Add($txtEscTo)

$lblEscTemplate = New-Object System.Windows.Forms.Label
$lblEscTemplate.Location = New-Object System.Drawing.Point(10, 45)
$lblEscTemplate.Size = New-Object System.Drawing.Size(120, 20)
$lblEscTemplate.Text = "Notification Template:"
$pnlEscalationDetails.Controls.Add($lblEscTemplate)

$txtEscTemplate = New-Object System.Windows.Forms.TextBox
$txtEscTemplate.Location = New-Object System.Drawing.Point(10, 65)
$txtEscTemplate.Size = New-Object System.Drawing.Size(650, 150)
$txtEscTemplate.Multiline = $true
$txtEscTemplate.ScrollBars = "Vertical"
$pnlEscalationDetails.Controls.Add($txtEscTemplate)

# Escalation Buttons
$btnAddEscRule = New-Object System.Windows.Forms.Button
$btnAddEscRule.Location = New-Object System.Drawing.Point(10, 225)
$btnAddEscRule.Size = New-Object System.Drawing.Size(140, 30)
$btnAddEscRule.Text = "Add/Update Rule"
$btnAddEscRule.Add_Click({ Add-EscalationRuleClick })
$pnlEscalationDetails.Controls.Add($btnAddEscRule)

$btnSetDefaultRules = New-Object System.Windows.Forms.Button
$btnSetDefaultRules.Location = New-Object System.Drawing.Point(160, 225)
$btnSetDefaultRules.Size = New-Object System.Drawing.Size(140, 30)
$btnSetDefaultRules.Text = "Set Default Rules"
$btnSetDefaultRules.Add_Click({ Set-DefaultRulesClick })
$pnlEscalationDetails.Controls.Add($btnSetDefaultRules)

$btnRefreshEscRules = New-Object System.Windows.Forms.Button
$btnRefreshEscRules.Location = New-Object System.Drawing.Point(310, 225)
$btnRefreshEscRules.Size = New-Object System.Drawing.Size(140, 30)
$btnRefreshEscRules.Text = "Refresh Rules"
$btnRefreshEscRules.Add_Click({ Load-EscalationRules })
$pnlEscalationDetails.Controls.Add($btnRefreshEscRules)

$btnCheckEscalations = New-Object System.Windows.Forms.Button
$btnCheckEscalations.Location = New-Object System.Drawing.Point(460, 225)
$btnCheckEscalations.Size = New-Object System.Drawing.Size(140, 30)
$btnCheckEscalations.Text = "Check Escalations"
$btnCheckEscalations.Add_Click({ Check-EscalationsClick })
$pnlEscalationDetails.Controls.Add($btnCheckEscalations)

# Escalation History
$lblEscHistory = New-Object System.Windows.Forms.Label
$lblEscHistory.Location = New-Object System.Drawing.Point(680, 45)
$lblEscHistory.Size = New-Object System.Drawing.Size(120, 20)
$lblEscHistory.Text = "Escalation History:"
$pnlEscalationDetails.Controls.Add($lblEscHistory)

$dgvEscHistory = New-Object System.Windows.Forms.DataGridView
$dgvEscHistory.Location = New-Object System.Drawing.Point(680, 65)
$dgvEscHistory.Size = New-Object System.Drawing.Size(640, 320)
$dgvEscHistory.ReadOnly = $true
$dgvEscHistory.AllowUserToAddRows = $false
$dgvEscHistory.AllowUserToDeleteRows = $false
$dgvEscHistory.SelectionMode = "FullRowSelect"
$pnlEscalationDetails.Controls.Add($dgvEscHistory)

# ============================================
# FUNCTIONS
# ============================================

# Load Tasks
function Load-Tasks {
    try {
        $tasks = Get-Task -AssignedTo $txtFilterAssigned.Text `
                        -Status $cmbFilterStatus.Text `
                        -Priority $cmbFilterPriority.Text `
                        -IncludeCompleted $chkIncludeCompleted.Checked
        
        $dgvTasks.DataSource = $tasks
        $dgvTasks.Refresh()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error loading tasks: $_", "Error", "OK", "Error")
    }
}

# Load Tickets
function Load-Tickets {
    try {
        $tickets = Get-Ticket -AssignedTo $txtTicketFilterAssigned.Text `
                           -Status $cmbTicketFilterStatus.Text `
                           -Severity $cmbTicketFilterSeverity.Text `
                           -IncludeClosed $chkTicketIncludeClosed.Checked
        
        $dgvTickets.DataSource = $tickets
        $dgvTickets.Refresh()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error loading tickets: $_", "Error", "OK", "Error")
    }
}

# Load Escalation Rules
function Load-EscalationRules {
    try {
        $rules = Get-EscalationRule
        $dgvEscalationRules.DataSource = $rules
        $dgvEscalationRules.Refresh()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error loading escalation rules: $_", "Error", "OK", "Error")
    }
}

# Load Escalation History
function Load-EscalationHistory {
    try {
        $history = Get-EscalationHistory
        $dgvEscHistory.DataSource = $history
        $dgvEscHistory.Refresh()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error loading escalation history: $_", "Error", "OK", "Error")
    }
}

# New Task Click
function New-TaskClick {
    try {
        if ([string]::IsNullOrWhiteSpace($txtTaskTitle.Text)) {
            [System.Windows.Forms.MessageBox]::Show("Please enter a task title.", "Validation Error", "OK", "Warning")
            return
        }
        
        $dueDate = if ($dtpTaskDueDate.Checked) { $dtpTaskDueDate.Value } else { $null }
        
        $result = New-Task -TaskTitle $txtTaskTitle.Text `
                           -TaskDescription $txtTaskDescription.Text `
                           -AssignedTo $txtTaskAssigned.Text `
                           -Priority $cmbTaskPriority.Text `
                           -DueDate $dueDate `
                           -CreatedBy $script:CurrentUser
        
        [System.Windows.Forms.MessageBox]::Show("Task created successfully! Task ID: $($result.TaskID)", "Success", "OK", "Information")
        Load-Tasks
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error creating task: $_", "Error", "OK", "Error")
    }
}

# Update Task Click
function Update-TaskClick {
    if ($dgvTasks.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a task to update.", "Validation Error", "OK", "Warning")
        return
    }
    
    try {
        $taskID = $dgvTasks.SelectedRows[0].Cells["TaskID"].Value
        $dueDate = if ($dtpTaskDueDate.Checked) { $dtpTaskDueDate.Value } else { $null }
        
        Update-Task -TaskID $taskID `
                     -TaskTitle $txtTaskTitle.Text `
                     -TaskDescription $txtTaskDescription.Text `
                     -AssignedTo $txtTaskAssigned.Text `
                     -Status $cmbTaskStatus.Text `
                     -Priority $cmbTaskPriority.Text `
                     -DueDate $dueDate `
                     -ModifiedBy $script:CurrentUser
        
        [System.Windows.Forms.MessageBox]::Show("Task updated successfully!", "Success", "OK", "Information")
        Load-Tasks
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error updating task: $_", "Error", "OK", "Error")
    }
}

# Add Task Comment Click
function Add-TaskCommentClick {
    if ($dgvTasks.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a task to add comment.", "Validation Error", "OK", "Warning")
        return
    }
    
    $comment = [Microsoft.VisualBasic.Interaction]::InputBox("Enter your comment:", "Add Comment", "")
    if ([string]::IsNullOrWhiteSpace($comment)) { return }
    
    try {
        $taskID = $dgvTasks.SelectedRows[0].Cells["TaskID"].Value
        Add-TaskComment -TaskID $taskID -CommentText $comment -CreatedBy $script:CurrentUser
        [System.Windows.Forms.MessageBox]::Show("Comment added successfully!", "Success", "OK", "Information")
        View-TaskCommentsClick
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error adding comment: $_", "Error", "OK", "Error")
    }
}

# View Task Comments Click
function View-TaskCommentsClick {
    if ($dgvTasks.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a task to view comments.", "Validation Error", "OK", "Warning")
        return
    }
    
    try {
        $taskID = $dgvTasks.SelectedRows[0].Cells["TaskID"].Value
        $comments = Get-TaskComments -TaskID $taskID
        
        $txtTaskComments.Text = ""
        foreach ($comment in $comments) {
            $txtTaskComments.Text += "=== $($comment.CreatedBy) at $($comment.CreatedDate) ===`r`n"
            $txtTaskComments.Text += "$($comment.CommentText)`r`n`r`n"
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error loading comments: $_", "Error", "OK", "Error")
    }
}

# Acknowledge Ticket Click
function Acknowledge-TicketClick {
    if ($dgvTickets.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a ticket to acknowledge.", "Validation Error", "OK", "Warning")
        return
    }
    
    try {
        $ticketID = $dgvTickets.SelectedRows[0].Cells["TicketID"].Value
        Acknowledge-Ticket -TicketID $ticketID -AcknowledgedBy $script:CurrentUser
        [System.Windows.Forms.MessageBox]::Show("Ticket acknowledged successfully!", "Success", "OK", "Information")
        Load-Tickets
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error acknowledging ticket: $_", "Error", "OK", "Error")
    }
}

# Resolve Ticket Click
function Resolve-TicketClick {
    if ($dgvTickets.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a ticket to resolve.", "Validation Error", "OK", "Warning")
        return
    }
    
    $resolution = [Microsoft.VisualBasic.Interaction]::InputBox("Enter resolution notes:", "Resolve Ticket", "")
    if ([string]::IsNullOrWhiteSpace($resolution)) { return }
    
    try {
        $ticketID = $dgvTickets.SelectedRows[0].Cells["TicketID"].Value
        Resolve-Ticket -TicketID $ticketID -ResolvedBy $script:CurrentUser -ResolutionNotes $resolution
        [System.Windows.Forms.MessageBox]::Show("Ticket resolved successfully!", "Success", "OK", "Information")
        Load-Tickets
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error resolving ticket: $_", "Error", "OK", "Error")
    }
}

# Add Ticket Comment Click
function Add-TicketCommentClick {
    if ($dgvTickets.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a ticket to add comment.", "Validation Error", "OK", "Warning")
        return
    }
    
    $comment = [Microsoft.VisualBasic.Interaction]::InputBox("Enter your comment:", "Add Comment", "")
    if ([string]::IsNullOrWhiteSpace($comment)) { return }
    
    try {
        $ticketID = $dgvTickets.SelectedRows[0].Cells["TicketID"].Value
        Add-TicketComment -TicketID $ticketID -CommentText $comment -CreatedBy $script:CurrentUser
        [System.Windows.Forms.MessageBox]::Show("Comment added successfully!", "Success", "OK", "Information")
        View-TicketCommentsClick
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error adding comment: $_", "Error", "OK", "Error")
    }
}

# View Ticket Comments Click
function View-TicketCommentsClick {
    if ($dgvTickets.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a ticket to view comments.", "Validation Error", "OK", "Warning")
        return
    }
    
    try {
        $ticketID = $dgvTickets.SelectedRows[0].Cells["TicketID"].Value
        $comments = Get-TicketComments -TicketID $ticketID
        
        $txtTicketComments.Text = ""
        foreach ($comment in $comments) {
            $txtTicketComments.Text += "=== $($comment.CreatedBy) at $($comment.CreatedDate) ===`r`n"
            $txtTicketComments.Text += "$($comment.CommentText)`r`n`r`n"
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error loading comments: $_", "Error", "OK", "Error")
    }
}

# Create From Alert Click
function CreateFromAlertClick {
    $alertID = [Microsoft.VisualBasic.Interaction]::InputBox("Enter Alert ID:", "Create Ticket From Alert", "")
    if ([string]::IsNullOrWhiteSpace($alertID)) { return }
    
    try {
        $result = New-TicketFromAlert -AlertID $alertID -CreatedBy $script:CurrentUser -Severity $cmbTicketSeverity.Text
        [System.Windows.Forms.MessageBox]::Show("Ticket created from alert! Ticket ID: $($result.TicketID), Number: $($result.TicketNumber)", "Success", "OK", "Information")
        Load-Tickets
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error creating ticket from alert: $_", "Error", "OK", "Error")
    }
}

# Add Escalation Rule Click
function Add-EscalationRuleClick {
    try {
        if ([string]::IsNullOrWhiteSpace($txtEscTo.Text)) {
            [System.Windows.Forms.MessageBox]::Show("Please enter escalation target (email/team).", "Validation Error", "OK", "Warning")
            return
        }
        
        Add-EscalationRule -Severity $cmbEscSeverity.Text `
                           -Level $cmbEscLevel.Text `
                           -EscalationTimeMinutes $numEscTime.Value `
                           -EscalationTo $txtEscTo.Text `
                           -NotificationTemplate $txtEscTemplate.Text
        
        [System.Windows.Forms.MessageBox]::Show("Escalation rule added/updated successfully!", "Success", "OK", "Information")
        Load-EscalationRules
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error adding escalation rule: $_", "Error", "OK", "Error")
    }
}

# Set Default Rules Click
function Set-DefaultRulesClick {
    try {
        Set-DefaultEscalationRules
        [System.Windows.Forms.MessageBox]::Show("Default escalation rules configured successfully!", "Success", "OK", "Information")
        Load-EscalationRules
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error setting default rules: $_", "Error", "OK", "Error")
    }
}

# Check Escalations Click
function Check-EscalationsClick {
    try {
        $pending = Invoke-EscalationCheck
        if ($pending -and $pending.Rows.Count -gt 0) {
            [System.Windows.Forms.MessageBox]::Show("Found $($pending.Rows.Count) ticket(s) pending escalation. Check the history tab.", "Escalation Check", "OK", "Information")
        }
        else {
            [System.Windows.Forms.MessageBox]::Show("No tickets pending escalation.", "Escalation Check", "OK", "Information")
        }
        Load-EscalationHistory
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error checking escalations: $_", "Error", "OK", "Error")
    }
}

# DataGridView Selection Changed Events
$dgvTasks.Add_SelectionChanged({
    if ($dgvTasks.SelectedRows.Count -gt 0) {
        $row = $dgvTasks.SelectedRows[0]
        $txtTaskTitle.Text = $row.Cells["TaskTitle"].Value
        $txtTaskDescription.Text = $row.Cells["TaskDescription"].Value
        $txtTaskAssigned.Text = $row.Cells["AssignedTo"].Value
        $cmbTaskPriority.Text = $row.Cells["TaskPriority"].Value
        $cmbTaskStatus.Text = $row.Cells["TaskStatus"].Value
        
        if ($row.Cells["DueDate"].Value) {
            $dtpTaskDueDate.Checked = $true
            $dtpTaskDueDate.Value = [datetime]$row.Cells["DueDate"].Value
        }
        else {
            $dtpTaskDueDate.Checked = $false
        }
    }
})

$dgvTickets.Add_SelectionChanged({
    if ($dgvTickets.SelectedRows.Count -gt 0) {
        $row = $dgvTickets.SelectedRows[0]
        $txtTicketNumber.Text = $row.Cells["TicketNumber"].Value
        $txtTicketError.Text = $row.Cells["ErrorDescription"].Value
        $txtTicketAssigned.Text = $row.Cells["AssignedTo"].Value
        $cmbTicketSeverity.Text = $row.Cells["TicketSeverity"].Value
    }
})

# Load initial data
Load-Tasks
Load-Tickets
Load-EscalationRules
Load-EscalationHistory

# Show Form
[void]$form.ShowDialog()
