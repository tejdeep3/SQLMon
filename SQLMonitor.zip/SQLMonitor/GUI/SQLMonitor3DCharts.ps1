# SQL Monitor 3D Chart Viewer
# Dedicated WPF application for interactive 3D data visualizations

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Xaml

$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force

# ------------------------------------------------------------
# Config
# ------------------------------------------------------------
$RepositoryServer = ''
$RepositoryDatabase = ''

try {
    $repositorySettings = Get-SqlMonitorRepositorySettings
    $RepositoryServer = $repositorySettings.RepositoryServer
    $RepositoryDatabase = $repositorySettings.RepositoryDatabase
}
catch {
    $RepositoryServer = 'localhost'
    $RepositoryDatabase = 'DBA_SQLMonitor'
}

# ------------------------------------------------------------
# Data Functions
# ------------------------------------------------------------
function Get-CPUData {
    param([int]$InstanceID = 1, [int]$Hours = 1)

    $query = @"
SELECT TOP 60
    DATEPART(hour, CaptureTime) as Hour,
    AVG(SqlCPUPercent) as AvgSqlCPU,
    AVG(OtherCPUPercent) as AvgOtherCPU,
    AVG(IdleCPUPercent) as AvgIdleCPU
FROM mon.CPUHistory
WHERE InstanceID = $InstanceID
    AND CaptureTime >= DATEADD(hour, -$Hours, GETDATE())
GROUP BY DATEPART(hour, CaptureTime)
ORDER BY Hour;
"@

    try {
        return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
    }
    catch {
        Write-Host "Error getting CPU data: $($_.Exception.Message)"
        return $null
    }
}

function Get-MemoryData {
    param([int]$InstanceID = 1, [int]$Hours = 1)

    $query = @"
SELECT TOP 60
    DATEPART(hour, CaptureTime) as Hour,
    AVG(CAST(TotalPhysicalMB as float)) as AvgTotalMB,
    AVG(CAST(AvailablePhysicalMB as float)) as AvgAvailableMB,
    AVG(CAST(SqlMemoryUsedGB as float)) as AvgSqlMemoryGB
FROM mon.MemoryHistory
WHERE InstanceID = $InstanceID
    AND CaptureTime >= DATEADD(hour, -$Hours, GETDATE())
GROUP BY DATEPART(hour, CaptureTime)
ORDER BY Hour;
"@

    try {
        return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
    }
    catch {
        Write-Host "Error getting memory data: $($_.Exception.Message)"
        return $null
    }
}

# ------------------------------------------------------------
# 3D Chart Functions
# ------------------------------------------------------------
function Create-3DCPUChart {
    param([System.Windows.Controls.Viewport3D]$Viewport)

    $cpuData = Get-CPUData
    if (-not $cpuData -or $cpuData.Rows.Count -eq 0) {
        Write-Host "No CPU data available"
        return
    }

    $modelGroup = New-Object System.Windows.Media.Media3D.Model3DGroup

    # Add lights
    $directionalLight = New-Object System.Windows.Media.Media3D.DirectionalLight
    $directionalLight.Color = [System.Windows.Media.Colors]::White
    $directionalLight.Direction = (New-Object System.Windows.Media.Media3D.Vector3D -1,-1,-1)
    $modelGroup.Children.Add($directionalLight)

    $ambientLight = New-Object System.Windows.Media.Media3D.AmbientLight
    $ambientLight.Color = [System.Windows.Media.Color]::FromRgb(60,60,60)
    $modelGroup.Children.Add($ambientLight)

    # Create 3D bars
    for ($i = 0; $i -lt [Math]::Min($cpuData.Rows.Count, 24); $i++) {
        $row = $cpuData.Rows[$i]
        $sqlCpu = [double]$row.AvgSqlCPU
        $otherCpu = [double]$row.AvgOtherCPU

        # SQL CPU bar (blue)
        if ($sqlCpu -gt 0) {
            $geometryModel = New-Object System.Windows.Media.Media3D.GeometryModel3D
            $meshGeometry = New-Object System.Windows.Media.Media3D.MeshGeometry3D

            $x = $i * 1.5
            $positions = New-Object System.Windows.Media.Media3D.Point3DCollection
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 0, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 0, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 0, $sqlCpu))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 0, $sqlCpu))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 0.5, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 0.5, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 0.5, $sqlCpu))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 0.5, $sqlCpu))

            $meshGeometry.Positions = $positions
            $meshGeometry.TriangleIndices = [System.Int32[]](0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,3,7, 0,7,4, 1,5,6, 1,6,2, 3,2,6, 3,6,7, 0,4,5, 0,5,1)

            $geometryModel.Geometry = $meshGeometry
            $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Blue))

            $modelGroup.Children.Add($geometryModel)
        }

        # Other CPU bar (red)
        if ($otherCpu -gt 0) {
            $geometryModel = New-Object System.Windows.Media.Media3D.GeometryModel3D
            $meshGeometry = New-Object System.Windows.Media.Media3D.MeshGeometry3D

            $x = $i * 1.5
            $positions = New-Object System.Windows.Media.Media3D.Point3DCollection
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 0.6, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 0.6, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 0.6, $otherCpu))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 0.6, $otherCpu))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 1.1, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 1.1, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.3), 1.1, $otherCpu))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.3), 1.1, $otherCpu))

            $meshGeometry.Positions = $positions
            $meshGeometry.TriangleIndices = [System.Int32[]](0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,3,7, 0,7,4, 1,5,6, 1,6,2, 3,2,6, 3,6,7, 0,4,5, 0,5,1)

            $geometryModel.Geometry = $meshGeometry
            $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Red))

            $modelGroup.Children.Add($geometryModel)
        }
    }

    $Viewport.Children.Clear()
    $Viewport.Children.Add((New-Object System.Windows.Media.Media3D.ModelVisual3D -Property @{Content=$modelGroup}))

    # Add camera
    $camera = New-Object System.Windows.Media.Media3D.PerspectiveCamera
    $camera.Position = New-Object System.Windows.Media.Media3D.Point3D 20,15,15
    $camera.LookDirection = New-Object System.Windows.Media.Media3D.Vector3D -20,-15,-15
    $camera.UpDirection = New-Object System.Windows.Media.Media3D.Vector3D 0,0,1
    $camera.FieldOfView = 60
    $Viewport.Camera = $camera
}

function Create-3DMemoryChart {
    param([System.Windows.Controls.Viewport3D]$Viewport)

    $memoryData = Get-MemoryData
    if (-not $memoryData -or $memoryData.Rows.Count -eq 0) {
        Write-Host "No memory data available"
        return
    }

    $modelGroup = New-Object System.Windows.Media.Media3D.Model3DGroup

    # Add lights
    $directionalLight = New-Object System.Windows.Media.Media3D.DirectionalLight
    $directionalLight.Color = [System.Windows.Media.Colors]::White
    $directionalLight.Direction = (New-Object System.Windows.Media.Media3D.Vector3D -1,-1,-1)
    $modelGroup.Children.Add($directionalLight)

    $ambientLight = New-Object System.Windows.Media.Media3D.AmbientLight
    $ambientLight.Color = [System.Windows.Media.Color]::FromRgb(60,60,60)
    $modelGroup.Children.Add($ambientLight)

    # Create 3D bars for memory usage
    for ($i = 0; $i -lt [Math]::Min($memoryData.Rows.Count, 24); $i++) {
        $row = $memoryData.Rows[$i]
        $totalMB = [double]$row.AvgTotalMB
        $availableMB = [double]$row.AvgAvailableMB
        $usagePercent = (($totalMB - $availableMB) / $totalMB) * 100

        $geometryModel = New-Object System.Windows.Media.Media3D.GeometryModel3D
        $meshGeometry = New-Object System.Windows.Media.Media3D.MeshGeometry3D

        $x = $i * 1.5
        $positions = New-Object System.Windows.Media.Media3D.Point3DCollection
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.4), 0, 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.4), 0, 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.4), 0, $usagePercent))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.4), 0, $usagePercent))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.4), 0.8, 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.4), 0.8, 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x + 0.4), 0.8, $usagePercent))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($x - 0.4), 0.8, $usagePercent))

        $meshGeometry.Positions = $positions
        $meshGeometry.TriangleIndices = [System.Int32[]](0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,3,7, 0,7,4, 1,5,6, 1,6,2, 3,2,6, 3,6,7, 0,4,5, 0,5,1)

        $geometryModel.Geometry = $meshGeometry

        # Color based on usage
        if ($usagePercent -gt 90) {
            $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Red))
        }
        elseif ($usagePercent -gt 75) {
            $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Orange))
        }
        else {
            $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Green))
        }

        $modelGroup.Children.Add($geometryModel)
    }

    $Viewport.Children.Clear()
    $Viewport.Children.Add((New-Object System.Windows.Media.Media3D.ModelVisual3D -Property @{Content=$modelGroup}))

    # Add camera
    $camera = New-Object System.Windows.Media.Media3D.PerspectiveCamera
    $camera.Position = New-Object System.Windows.Media.Media3D.Point3D 18,12,12
    $camera.LookDirection = New-Object System.Windows.Media.Media3D.Vector3D -18,-12,-12
    $camera.UpDirection = New-Object System.Windows.Media.Media3D.Vector3D 0,0,1
    $camera.FieldOfView = 60
    $Viewport.Camera = $camera
}

# ------------------------------------------------------------
# WPF Window
# ------------------------------------------------------------
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="SQL Monitor - Interactive 3D Charts" Height="800" Width="1200"
        WindowStartupLocation="CenterScreen" Background="#2D2D30">
    <Window.Resources>
        <Style x:Key="ChartButtonStyle" TargetType="Button">
            <Setter Property="Background" Value="#007ACC"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Padding" Value="10,5"/>
            <Setter Property="Margin" Value="5"/>
            <Setter Property="FontWeight" Value="Bold"/>
        </Style>
        <Style x:Key="GroupBoxStyle" TargetType="GroupBox">
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
            <Setter Property="Margin" Value="5"/>
        </Style>
    </Window.Resources>

    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>

        <!-- Header -->
        <Border Grid.Row="0" Background="#007ACC" Padding="20,10">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock Grid.Column="0" Text="SQL Monitor - Interactive 3D Data Visualizations"
                          FontSize="20" FontWeight="Bold" Foreground="White"/>
                <TextBlock x:Name="txtStatus" Grid.Column="1"
                          Text="Ready"
                          FontSize="12" Foreground="White"/>
            </Grid>
        </Border>

        <!-- Main Content -->
        <Grid Grid.Row="1" Margin="10">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="*"/>
                <ColumnDefinition Width="*"/>
            </Grid.ColumnDefinitions>

            <!-- CPU Chart -->
            <GroupBox Grid.Column="0" Header="CPU Usage 3D View" Style="{StaticResource GroupBoxStyle}">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>

                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,10">
                        <Button x:Name="btnRefreshCPU" Content="Refresh CPU" Style="{StaticResource ChartButtonStyle}"/>
                        <TextBlock Text="Blue: SQL CPU, Red: Other CPU" Foreground="LightGray" VerticalAlignment="Center" Margin="10,0"/>
                    </StackPanel>

                    <Viewport3D x:Name="cpuViewport" Grid.Row="1" Margin="5"/>
                </Grid>
            </GroupBox>

            <!-- Memory Chart -->
            <GroupBox Grid.Column="1" Header="Memory Usage 3D View" Style="{StaticResource GroupBoxStyle}">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>

                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,10">
                        <Button x:Name="btnRefreshMemory" Content="Refresh Memory" Style="{StaticResource ChartButtonStyle}"/>
                        <TextBlock Text="Color-coded by usage %" Foreground="LightGray" VerticalAlignment="Center" Margin="10,0"/>
                    </StackPanel>

                    <Viewport3D x:Name="memoryViewport" Grid.Row="1" Margin="5"/>
                </Grid>
            </GroupBox>
        </Grid>
    </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

# Get controls
$txtStatus = $window.FindName("txtStatus")
$btnRefreshCPU = $window.FindName("btnRefreshCPU")
$btnRefreshMemory = $window.FindName("btnRefreshMemory")
$cpuViewport = $window.FindName("cpuViewport")
$memoryViewport = $window.FindName("memoryViewport")

# ------------------------------------------------------------
# Event Handlers
# ------------------------------------------------------------
$btnRefreshCPU.Add_Click({
    $txtStatus.Text = "Loading CPU data..."
    try {
        Create-3DCPUChart -Viewport $cpuViewport
        $txtStatus.Text = "CPU chart updated"
    }
    catch {
        $txtStatus.Text = "Error: $($_.Exception.Message)"
    }
})

$btnRefreshMemory.Add_Click({
    $txtStatus.Text = "Loading memory data..."
    try {
        Create-3DMemoryChart -Viewport $memoryViewport
        $txtStatus.Text = "Memory chart updated"
    }
    catch {
        $txtStatus.Text = "Error: $($_.Exception.Message)"
    }
})

# ------------------------------------------------------------
# Initialize
# ------------------------------------------------------------
$txtStatus.Text = "Initializing 3D charts..."
try {
    Create-3DCPUChart -Viewport $cpuViewport
    Create-3DMemoryChart -Viewport $memoryViewport
    $txtStatus.Text = "3D charts loaded successfully"
}
catch {
    $txtStatus.Text = "Initialization error: $($_.Exception.Message)"
}

# Show window
$window.ShowDialog() | Out-Null
