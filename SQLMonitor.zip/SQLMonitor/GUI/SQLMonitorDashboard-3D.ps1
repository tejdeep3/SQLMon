# SQL Monitor Dashboard - Enhanced WPF Version with 3D Visualizations
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Xaml

$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force

# ------------------------------------------------------------
# Config
# ------------------------------------------------------------
$RepositoryServer = ''
$RepositoryDatabase = ''

try {
    $repositorySettings = Get-SqlMonitorRepositorySettings
    $RepositoryServer = $repositorySettings.RepositoryServer
    $RepositoryDatabase = $repositorySettings.RepositoryDatabase
}
catch {
    $RepositoryServer = 'localhost'
    $RepositoryDatabase = 'DBA_SQLMonitor'
}

# ------------------------------------------------------------
# Data Query Functions
# ------------------------------------------------------------
function Get-OverviewData {
    $query = @"
SELECT *
FROM mon.vw_OverviewWithAlerts
ORDER BY DisplayName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-CPUTrendData {
    param([int]$InstanceID)

    $query = @"
SELECT TOP 60
    CaptureTime,
    SqlCPUPercent,
    OtherCPUPercent,
    IdleCPUPercent
FROM mon.CPUHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-MemoryTrendData {
    param([int]$InstanceID)

    $query = @"
SELECT TOP 60
    CaptureTime,
    TotalPhysicalMB,
    AvailablePhysicalMB,
    SqlMemoryUsedGB,
    PLESeconds,
    BufferCacheHitRatio
FROM mon.MemoryHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-OpenAlertsData {
    param(
        [int]$InstanceID,
        [bool]$CriticalOnly = $false
    )

    $severityClause = if ($CriticalOnly) { "AND Severity = 'Critical'" } else { "" }

    $query = @"
SELECT
    AlertID,
    DisplayName,
    AlertTime,
    AlertAgeMinutes,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails
FROM mon.vw_OpenAlertsDetailed
WHERE InstanceID = $InstanceID
$severityClause
ORDER BY AlertTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Acknowledge-Alert {
    param([int64]$AlertID)

    $ackUser = if ($env:USERDOMAIN -and $env:USERNAME) {
        "$($env:USERDOMAIN)\$($env:USERNAME)"
    }
    elseif ($env:USERNAME) {
        $env:USERNAME
    }
    else {
        "UnknownUser"
    }

    $escapedUser = $ackUser.Replace("'", "''")

    $query = @"
EXEC mon.usp_AcknowledgeAlert
    @AlertID = $AlertID,
    @AcknowledgedBy = N'$escapedUser';
"@

    return Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

# ------------------------------------------------------------
# 3D Visualization Helpers
# ------------------------------------------------------------
function New-3DChart {
    param(
        [string]$Title,
        [System.Windows.Media.Media3D.Point3D[]]$Points,
        [System.Windows.Media.Color]$Color = [System.Windows.Media.Colors]::Blue
    )

    $viewport = New-Object System.Windows.Controls.Viewport3D

    # Create 3D model group
    $modelGroup = New-Object System.Windows.Media.Media3D.Model3DGroup

    # Add lights
    $directionalLight = New-Object System.Windows.Media.Media3D.DirectionalLight
    $directionalLight.Color = [System.Windows.Media.Colors]::White
    $directionalLight.Direction = (New-Object System.Windows.Media.Media3D.Vector3D -1,-1,-1)
    $modelGroup.Children.Add($directionalLight)

    $ambientLight = New-Object System.Windows.Media.Media3D.AmbientLight
    $ambientLight.Color = [System.Windows.Media.Color]::FromRgb(50,50,50)
    $modelGroup.Children.Add($ambientLight)

    # Create 3D geometry
    $meshGeometry = New-Object System.Windows.Media.Media3D.MeshGeometry3D

    # Add points as bars
    for ($i = 0; $i -lt $Points.Count; $i++) {
        $point = $Points[$i]
        $height = $point.Z

        # Create a bar (cube) for each data point
        $positions = New-Object System.Windows.Media.Media3D.Point3DCollection
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X - 0.5), ($point.Y), 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X + 0.5), ($point.Y), 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X + 0.5), ($point.Y), $height))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X - 0.5), ($point.Y), $height))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X - 0.5), ($point.Y + 1), 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X + 0.5), ($point.Y + 1), 0))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X + 0.5), ($point.Y + 1), $height))
        $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($point.X - 0.5), ($point.Y + 1), $height))

        $triangleIndices = New-Object System.Int32[] (0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,3,7, 0,7,4, 1,5,6, 1,6,2, 3,2,6, 3,6,7, 0,4,5, 0,5,1)

        $geometryModel = New-Object System.Windows.Media.Media3D.GeometryModel3D
        $geometryModel.Geometry = $meshGeometry
        $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush $Color)

        $modelGroup.Children.Add($geometryModel)
    }

    $viewport.Children.Add((New-Object System.Windows.Media.Media3D.ModelVisual3D -Property @{Content=$modelGroup}))

    # Add camera
    $camera = New-Object System.Windows.Media.Media3D.PerspectiveCamera
    $camera.Position = New-Object System.Windows.Media.Media3D.Point3D 10,10,10
    $camera.LookDirection = New-Object System.Windows.Media.Media3D.Vector3D -10,-10,-10
    $camera.UpDirection = New-Object System.Windows.Media.Media3D.Vector3D 0,0,1
    $camera.FieldOfView = 60
    $viewport.Camera = $camera

    return $viewport
}

function Update-3DCPUChart {
    param([System.Windows.Controls.Viewport3D]$Viewport, [int]$InstanceID)

    try {
        $cpuData = Get-CPUTrendData -InstanceID $InstanceID
        if (-not $cpuData -or $cpuData.Rows.Count -eq 0) { return }

        $modelGroup = New-Object System.Windows.Media.Media3D.Model3DGroup

        # Add lights
        $directionalLight = New-Object System.Windows.Media.Media3D.DirectionalLight
        $directionalLight.Color = [System.Windows.Media.Colors]::White
        $directionalLight.Direction = (New-Object System.Windows.Media.Media3D.Vector3D -1,-1,-1)
        $modelGroup.Children.Add($directionalLight)

        $ambientLight = New-Object System.Windows.Media.Media3D.AmbientLight
        $ambientLight.Color = [System.Windows.Media.Color]::FromRgb(50,50,50)
        $modelGroup.Children.Add($ambientLight)

        # Create 3D bars for CPU data
        for ($i = 0; $i -lt [Math]::Min($cpuData.Rows.Count, 20); $i++) {
            $row = $cpuData.Rows[$i]
            $sqlCpu = [double]$row.SqlCPUPercent
            $otherCpu = [double]$row.OtherCPUPercent

            # SQL CPU bar (blue)
            if ($sqlCpu -gt 0) {
                $geometryModel = New-Object System.Windows.Media.Media3D.GeometryModel3D
                $meshGeometry = New-Object System.Windows.Media.Media3D.MeshGeometry3D

                $positions = New-Object System.Windows.Media.Media3D.Point3DCollection
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.8), 0, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.2), 0, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.2), 0, $sqlCpu))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.8), 0, $sqlCpu))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.8), 1, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.2), 1, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.2), 1, $sqlCpu))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 - 0.8), 1, $sqlCpu))

                $meshGeometry.Positions = $positions
                $meshGeometry.TriangleIndices = [System.Int32[]](0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,3,7, 0,7,4, 1,5,6, 1,6,2, 3,2,6, 3,6,7, 0,4,5, 0,5,1)

                $geometryModel.Geometry = $meshGeometry
                $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Blue))

                $modelGroup.Children.Add($geometryModel)
            }

            # Other CPU bar (red)
            if ($otherCpu -gt 0) {
                $geometryModel = New-Object System.Windows.Media.Media3D.GeometryModel3D
                $meshGeometry = New-Object System.Windows.Media.Media3D.MeshGeometry3D

                $positions = New-Object System.Windows.Media.Media3D.Point3DCollection
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.2), 0, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.8), 0, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.8), 0, $otherCpu))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.2), 0, $otherCpu))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.2), 1, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.8), 1, 0))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.8), 1, $otherCpu))
                $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i * 2 + 0.2), 1, $otherCpu))

                $meshGeometry.Positions = $positions
                $meshGeometry.TriangleIndices = [System.Int32[]](0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,3,7, 0,7,4, 1,5,6, 1,6,2, 3,2,6, 3,6,7, 0,4,5, 0,5,1)

                $geometryModel.Geometry = $meshGeometry
                $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Red))

                $modelGroup.Children.Add($geometryModel)
            }
        }

        $Viewport.Children.Clear()
        $Viewport.Children.Add((New-Object System.Windows.Media.Media3D.ModelVisual3D -Property @{Content=$modelGroup}))

        # Add camera
        $camera = New-Object System.Windows.Media.Media3D.PerspectiveCamera
        $camera.Position = New-Object System.Windows.Media.Media3D.Point3D 20,20,20
        $camera.LookDirection = New-Object System.Windows.Media.Media3D.Vector3D -20,-20,-20
        $camera.UpDirection = New-Object System.Windows.Media.Media3D.Vector3D 0,0,1
        $camera.FieldOfView = 60
        $Viewport.Camera = $camera
    }
    catch {
        Write-Host "Error in Update-3DCPUChart: $($_.Exception.Message)"
    }
}

# ------------------------------------------------------------
# WPF Window Creation
# ------------------------------------------------------------
[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="SQL Monitor Dashboard - Enhanced 3D" Height="900" Width="1500"
        WindowStartupLocation="CenterScreen" Background="#F5F5F5">
    <Window.Resources>
        <Style x:Key="TileStyle" TargetType="Border">
            <Setter Property="BorderBrush" Value="#DDD"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="CornerRadius" Value="5"/>
            <Setter Property="Margin" Value="5"/>
            <Setter Property="Padding" Value="10"/>
            <Setter Property="Background" Value="White"/>
        </Style>
        <Style x:Key="HeaderStyle" TargetType="TextBlock">
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="Bold"/>
            <Setter Property="Foreground" Value="#333"/>
        </Style>
        <Style x:Key="ValueStyle" TargetType="TextBlock">
            <Setter Property="FontSize" Value="24"/>
            <Setter Property="FontWeight" Value="Bold"/>
            <Setter Property="Foreground" Value="#007ACC"/>
        </Style>
    </Window.Resources>

    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>

        <!-- Header -->
        <Border Grid.Row="0" Background="#007ACC" Margin="0,0,0,10">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock Grid.Column="0" Text="SQL Monitor Dashboard - 3D Enhanced"
                          FontSize="24" FontWeight="Bold" Foreground="White"
                          VerticalAlignment="Center" Margin="20,10"/>
                <TextBlock x:Name="txtLastRefresh" Grid.Column="1"
                          Text="Last Refresh: Loading..."
                          FontSize="12" Foreground="White"
                          VerticalAlignment="Center" Margin="20,10"/>
            </Grid>
        </Border>

        <!-- Main Content -->
        <TabControl Grid.Row="1" Margin="10">
            <!-- Overview Tab -->
            <TabItem Header="Overview">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>

                    <!-- Controls -->
                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,10">
                        <ComboBox x:Name="cbInstances" Width="300" Margin="0,0,10,0"/>
                        <Button x:Name="btnRefresh" Content="Refresh Now" Width="100"/>
                        <CheckBox x:Name="chkCriticalOnly" Content="Critical Alerts Only" Margin="20,0,0,0"/>
                    </StackPanel>

                    <!-- Overview Content -->
                    <ScrollViewer Grid.Row="1" VerticalScrollBarVisibility="Auto">
                        <StackPanel>
                            <!-- Summary Tiles -->
                            <WrapPanel x:Name="pnlSummaryTiles" Margin="0,0,0,20"/>

                            <!-- 3D Charts Section -->
                            <GroupBox Header="Interactive 3D Visualizations" Margin="0,0,0,10">
                                <Grid>
                                    <Grid.ColumnDefinitions>
                                        <ColumnDefinition Width="*"/>
                                        <ColumnDefinition Width="*"/>
                                    </Grid.ColumnDefinitions>

                                    <!-- CPU 3D Chart -->
                                    <GroupBox Grid.Column="0" Header="CPU Usage 3D View" Margin="5">
                                        <Viewport3D x:Name="cpu3DChart" Height="300"/>
                                    </GroupBox>

                                    <!-- Memory 3D Chart -->
                                    <GroupBox Grid.Column="1" Header="Memory Usage 3D View" Margin="5">
                                        <Viewport3D x:Name="memory3DChart" Height="300"/>
                                    </GroupBox>
                                </Grid>
                            </GroupBox>
                        </StackPanel>
                    </ScrollViewer>
                </Grid>
            </TabItem>

            <!-- CPU Tab -->
            <TabItem Header="CPU Analysis">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>

                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,10">
                        <ComboBox x:Name="cbCPUInstances" Width="300" Margin="0,0,10,0"/>
                        <Button x:Name="btnRefreshCPU" Content="Refresh" Width="100"/>
                    </StackPanel>

                    <Viewport3D x:Name="cpuDetail3DChart" Grid.Row="1" Margin="10"/>
                </Grid>
            </TabItem>

            <!-- Memory Tab -->
            <TabItem Header="Memory Analysis">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>

                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,10">
                        <ComboBox x:Name="cbMemoryInstances" Width="300" Margin="0,0,10,0"/>
                        <Button x:Name="btnRefreshMemory" Content="Refresh" Width="100"/>
                    </StackPanel>

                    <Viewport3D x:Name="memoryDetail3DChart" Grid.Row="1" Margin="10"/>
                </Grid>
            </TabItem>

            <!-- Alerts Tab -->
            <TabItem Header="Alerts">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>

                    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,10">
                        <ComboBox x:Name="cbAlertInstances" Width="300" Margin="0,0,10,0"/>
                        <Button x:Name="btnRefreshAlerts" Content="Refresh" Width="100"/>
                        <CheckBox x:Name="chkCriticalAlertsOnly" Content="Critical Only" Margin="20,0,0,0"/>
                    </StackPanel>

                    <DataGrid x:Name="dgAlerts" Grid.Row="1" Margin="10" AutoGenerateColumns="False" IsReadOnly="True">
                        <DataGrid.Columns>
                            <DataGridTextColumn Header="Time" Binding="{Binding AlertTime}" Width="150"/>
                            <DataGridTextColumn Header="Age (min)" Binding="{Binding AlertAgeMinutes}" Width="80"/>
                            <DataGridTextColumn Header="Severity" Binding="{Binding Severity}" Width="80"/>
                            <DataGridTextColumn Header="Module" Binding="{Binding ModuleName}" Width="100"/>
                            <DataGridTextColumn Header="Title" Binding="{Binding AlertTitle}" Width="*"/>
                            <DataGridTextColumn Header="Details" Binding="{Binding AlertDetails}" Width="200"/>
                            <DataGridTemplateColumn Header="Actions" Width="100">
                                <DataGridTemplateColumn.CellTemplate>
                                    <DataTemplate>
                                        <Button Content="Acknowledge" Click="AcknowledgeAlert_Click"/>
                                    </DataTemplate>
                                </DataGridTemplateColumn.CellTemplate>
                            </DataGridTemplateColumn>
                        </DataGrid.Columns>
                    </DataGrid>
                </Grid>
            </TabItem>
        </TabControl>
    </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

# Get controls
$txtLastRefresh = $window.FindName("txtLastRefresh")
$cbInstances = $window.FindName("cbInstances")
$btnRefresh = $window.FindName("btnRefresh")
$chkCriticalOnly = $window.FindName("chkCriticalOnly")
$pnlSummaryTiles = $window.FindName("pnlSummaryTiles")
$cpu3DChart = $window.FindName("cpu3DChart")
$memory3DChart = $window.FindName("memory3DChart")

$cbCPUInstances = $window.FindName("cbCPUInstances")
$btnRefreshCPU = $window.FindName("btnRefreshCPU")
$cpuDetail3DChart = $window.FindName("cpuDetail3DChart")

$cbMemoryInstances = $window.FindName("cbMemoryInstances")
$btnRefreshMemory = $window.FindName("btnRefreshMemory")
$memoryDetail3DChart = $window.FindName("memoryDetail3DChart")

$cbAlertInstances = $window.FindName("cbAlertInstances")
$btnRefreshAlerts = $window.FindName("btnRefreshAlerts")
$chkCriticalAlertsOnly = $window.FindName("chkCriticalAlertsOnly")
$dgAlerts = $window.FindName("dgAlerts")

# Global variables
$global:selectedInstance = $null
$global:overviewData = $null

# ------------------------------------------------------------
# Event Handlers
# ------------------------------------------------------------
function Update-LastRefresh {
    $txtLastRefresh.Text = "Last Refresh: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
}

function Load-Instances {
    try {
        $data = Get-OverviewData
        if ($data -and $data.Rows.Count -gt 0) {
            $instances = $data.Rows | Select-Object -Unique DisplayName, InstanceID | Sort-Object DisplayName

            $cbInstances.Items.Clear()
            $cbCPUInstances.Items.Clear()
            $cbMemoryInstances.Items.Clear()
            $cbAlertInstances.Items.Clear()

            foreach ($instance in $instances) {
                $cbInstances.Items.Add($instance)
                $cbCPUInstances.Items.Add($instance)
                $cbMemoryInstances.Items.Add($instance)
                $cbAlertInstances.Items.Add($instance)
            }

            if ($cbInstances.Items.Count -gt 0) {
                $cbInstances.SelectedIndex = 0
                $cbCPUInstances.SelectedIndex = 0
                $cbMemoryInstances.SelectedIndex = 0
                $cbAlertInstances.SelectedIndex = 0
            }
        }
    }
    catch {
        [System.Windows.MessageBox]::Show("Error loading instances: $($_.Exception.Message)", "Error")
    }
}

function Update-Overview {
    try {
        $data = Get-OverviewData
        $global:overviewData = $data

        if ($data -and $data.Rows.Count -gt 0) {
            # Clear existing tiles
            $pnlSummaryTiles.Children.Clear()

            foreach ($row in $data.Rows) {
                # Create tile
                $tile = New-Object System.Windows.Controls.Border
                $tile.Style = $window.Resources["TileStyle"]

                $grid = New-Object System.Windows.Controls.Grid
                $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition))
                $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition))

                # Instance name
                $txtInstance = New-Object System.Windows.Controls.TextBlock
                $txtInstance.Style = $window.Resources["HeaderStyle"]
                $txtInstance.Text = $row.DisplayName
                [System.Windows.Controls.Grid]::SetRow($txtInstance, 0)
                $grid.Children.Add($txtInstance)

                # Status info
                $txtStatus = New-Object System.Windows.Controls.TextBlock
                $txtStatus.Style = $window.Resources["ValueStyle"]

                $criticalCount = [int]$row.CriticalAlerts
                $warningCount = [int]$row.WarningAlerts

                if ($criticalCount -gt 0) {
                    $txtStatus.Text = "CRITICAL ($criticalCount)"
                    $tile.Background = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Color]::FromRgb(220, 53, 69))
                    $txtStatus.Foreground = [System.Windows.Media.Brushes]::White
                }
                elseif ($warningCount -gt 0) {
                    $txtStatus.Text = "WARNING ($warningCount)"
                    $tile.Background = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Color]::FromRgb(255, 193, 7))
                    $txtStatus.Foreground = [System.Windows.Media.Brushes]::Black
                }
                else {
                    $txtStatus.Text = "HEALTHY"
                    $tile.Background = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Color]::FromRgb(40, 167, 69))
                    $txtStatus.Foreground = [System.Windows.Media.Brushes]::White
                }

                [System.Windows.Controls.Grid]::SetRow($txtStatus, 1)
                $grid.Children.Add($txtStatus)

                $tile.Child = $grid
                $pnlSummaryTiles.Children.Add($tile)
            }

            # Update 3D charts if instance selected
            if ($cbInstances.SelectedItem) {
                $selectedInstance = $cbInstances.SelectedItem
                Update-3DCPUChart -Viewport $cpu3DChart -InstanceID $selectedInstance.InstanceID
                Update-3DMemoryChart -Viewport $memory3DChart -InstanceID $selectedInstance.InstanceID
            }
        }

        Update-LastRefresh
    }
    catch {
        [System.Windows.MessageBox]::Show("Error updating overview: $($_.Exception.Message)", "Error")
    }
}

function Update-CPUDetail {
    try {
        if ($cbCPUInstances.SelectedItem) {
            $selectedInstance = $cbCPUInstances.SelectedItem
            Update-3DCPUChart -Viewport $cpuDetail3DChart -InstanceID $selectedInstance.InstanceID
        }
    }
    catch {
        [System.Windows.MessageBox]::Show("Error updating CPU chart: $($_.Exception.Message)", "Error")
    }
}

function Update-MemoryDetail {
    try {
        if ($cbMemoryInstances.SelectedItem) {
            $selectedInstance = $cbMemoryInstances.SelectedItem
            Update-3DMemoryChart -Viewport $memoryDetail3DChart -InstanceID $selectedInstance.InstanceID
        }
    }
    catch {
        [System.Windows.MessageBox]::Show("Error updating memory chart: $($_.Exception.Message)", "Error")
    }
}

function Update-Alerts {
    try {
        if ($cbAlertInstances.SelectedItem) {
            $selectedInstance = $cbAlertInstances.SelectedItem
            $criticalOnly = $chkCriticalAlertsOnly.IsChecked

            $alertsData = Get-OpenAlertsData -InstanceID $selectedInstance.InstanceID -CriticalOnly $criticalOnly

            $dgAlerts.ItemsSource = $alertsData.Rows
        }
    }
    catch {
        [System.Windows.MessageBox]::Show("Error updating alerts: $($_.Exception.Message)", "Error")
    }
}

function Update-3DMemoryChart {
    param([System.Windows.Controls.Viewport3D]$Viewport, [int]$InstanceID)

    try {
        $memoryData = Get-MemoryTrendData -InstanceID $InstanceID
        if (-not $memoryData -or $memoryData.Rows.Count -eq 0) { return }

        $modelGroup = New-Object System.Windows.Media.Media3D.Model3DGroup

        # Add lights
        $directionalLight = New-Object System.Windows.Media.Media3D.DirectionalLight
        $directionalLight.Color = [System.Windows.Media.Colors]::White
        $directionalLight.Direction = (New-Object System.Windows.Media.Media3D.Vector3D -1,-1,-1)
        $modelGroup.Children.Add($directionalLight)

        $ambientLight = New-Object System.Windows.Media.Media3D.AmbientLight
        $ambientLight.Color = [System.Windows.Media.Color]::FromRgb(50,50,50)
        $modelGroup.Children.Add($ambientLight)

        for ($i = 0; $i -lt [Math]::Min($memoryData.Rows.Count, 20); $i++) {
            $row = $memoryData.Rows[$i]
            $totalMB = [double]$row.TotalPhysicalMB
            $availableMB = [double]$row.AvailablePhysicalMB

            # Memory usage as percentage
            $usagePercent = (($totalMB - $availableMB) / $totalMB) * 100

            # Create 3D bar for memory usage
            $geometryModel = New-Object System.Windows.Media.Media3D.GeometryModel3D
            $meshGeometry = New-Object System.Windows.Media.Media3D.MeshGeometry3D

            $positions = New-Object System.Windows.Media.Media3D.Point3DCollection
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i - 0.4), 0, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i + 0.4), 0, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i + 0.4), 0, $usagePercent))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i - 0.4), 0, $usagePercent))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i - 0.4), 1, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i + 0.4), 1, 0))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i + 0.4), 1, $usagePercent))
            $positions.Add((New-Object System.Windows.Media.Media3D.Point3D ($i - 0.4), 1, $usagePercent))

            $meshGeometry.Positions = $positions
            $meshGeometry.TriangleIndices = [System.Int32[]](0,1,2, 0,2,3, 4,6,5, 4,7,6, 0,3,7, 0,7,4, 1,5,6, 1,6,2, 3,2,6, 3,6,7, 0,4,5, 0,5,1)

            $geometryModel.Geometry = $meshGeometry

            # Color based on usage
            if ($usagePercent -gt 90) {
                $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Red))
            }
            elseif ($usagePercent -gt 75) {
                $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Orange))
            }
            else {
                $geometryModel.Material = New-Object System.Windows.Media.Media3D.DiffuseMaterial (New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Colors]::Green))
            }

            $modelGroup.Children.Add($geometryModel)
        }

        $Viewport.Children.Clear()
        $Viewport.Children.Add((New-Object System.Windows.Media.Media3D.ModelVisual3D -Property @{Content=$modelGroup}))

        # Add camera
        $camera = New-Object System.Windows.Media.Media3D.PerspectiveCamera
        $camera.Position = New-Object System.Windows.Media.Media3D.Point3D 15,15,15
        $camera.LookDirection = New-Object System.Windows.Media.Media3D.Vector3D -15,-15,-15
        $camera.UpDirection = New-Object System.Windows.Media.Media3D.Vector3D 0,0,1
        $camera.FieldOfView = 60
        $Viewport.Camera = $camera
    }
    catch {
        Write-Host "Error in Update-3DMemoryChart: $($_.Exception.Message)"
    }
}

# ------------------------------------------------------------
# Wire up events
# ------------------------------------------------------------
$btnRefresh.Add_Click({
    Update-Overview
})

$cbInstances.Add_SelectionChanged({
    if ($cbInstances.SelectedItem) {
        $global:selectedInstance = $cbInstances.SelectedItem
        Update-Overview
    }
})

$btnRefreshCPU.Add_Click({
    Update-CPUDetail
})

$cbCPUInstances.Add_SelectionChanged({
    Update-CPUDetail
})

$btnRefreshMemory.Add_Click({
    Update-MemoryDetail
})

$cbMemoryInstances.Add_SelectionChanged({
    Update-MemoryDetail
})

$btnRefreshAlerts.Add_Click({
    Update-Alerts
})

$cbAlertInstances.Add_SelectionChanged({
    Update-Alerts
})

$chkCriticalAlertsOnly.Add_Checked({
    Update-Alerts
})

$chkCriticalAlertsOnly.Add_Unchecked({
    Update-Alerts
})

# Alert acknowledgement handler
function AcknowledgeAlert_Click {
    param($sender, $e)

    $button = $sender
    $alert = $button.DataContext

    if ($alert) {
        try {
            $result = Acknowledge-Alert -AlertID $alert.AlertID
            if ($result -eq 1) {
                [System.Windows.MessageBox]::Show("Alert acknowledged successfully!", "Success")
                Update-Alerts
                Update-Overview
            }
            else {
                [System.Windows.MessageBox]::Show("Failed to acknowledge alert.", "Error")
            }
        }
        catch {
            [System.Windows.MessageBox]::Show("Error acknowledging alert: $($_.Exception.Message)", "Error")
        }
    }
}

# ------------------------------------------------------------
# Initialize
# ------------------------------------------------------------
Load-Instances
Update-Overview

# Show window
$window.ShowDialog() | Out-Null
