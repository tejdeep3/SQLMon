Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$projectRoot = Split-Path -Parent $PSScriptRoot
$deployScript = Join-Path $projectRoot "Deploy-SQLMonitor.ps1"
$applyLatestScript = Join-Path $projectRoot "Apply-LatestChanges.ps1"
$resetAdminScript = Join-Path $projectRoot "Reset-DashboardAdmin.ps1"
$instancesPath = Join-Path $projectRoot "Config\instances.json"

function Get-DefaultRepositorySettings {
    $settings = [pscustomobject]@{
        RepositoryServer = $env:COMPUTERNAME
        RepositoryDatabase = "DBA_SQLMonitor"
        MonitoredInstances = @()
    }

    if (Test-Path $instancesPath) {
        try {
            $instances = Get-Content -Path $instancesPath -Raw | ConvertFrom-Json

            # Handle new VM-based hierarchy format
            if ($instances.VMs -and $instances.VMs.Count -gt 0) {
                $firstVM = $instances.VMs[0]
                if ($firstVM.SQLInstances -and $firstVM.SQLInstances.Count -gt 0) {
                    $firstSQL = $firstVM.SQLInstances[0]
                    if (-not [string]::IsNullOrWhiteSpace([string]$firstSQL.RepositoryServer)) {
                        $settings.RepositoryServer = [string]$firstSQL.RepositoryServer
                    }
                    if (-not [string]::IsNullOrWhiteSpace([string]$firstSQL.RepositoryDatabase)) {
                        $settings.RepositoryDatabase = [string]$firstSQL.RepositoryDatabase
                    }
                }
                # Also check StandaloneSQLInstances
                if ($instances.StandaloneSQLInstances -and $instances.StandaloneSQLInstances.Count -gt 0) {
                    $firstStandalone = $instances.StandaloneSQLInstances[0]
                    if ([string]::IsNullOrWhiteSpace($settings.RepositoryServer) -and -not [string]::IsNullOrWhiteSpace([string]$firstStandalone.RepositoryServer)) {
                        $settings.RepositoryServer = [string]$firstStandalone.RepositoryServer
                    }
                }
                # Collect all SQL instance names for monitored instances list
                $settings.MonitoredInstances = @($instances.VMs | ForEach-Object {
                    if ($_.SQLInstances) { $_.SQLInstances | ForEach-Object { [string]$_.SqlInstance } }
                } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
                $standaloneList = @($instances.StandaloneSQLInstances | ForEach-Object { [string]$_.SqlInstance } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
                $settings.MonitoredInstances = @($settings.MonitoredInstances + $standaloneList)
            }
            else {
                # Handle old flat format (backward compatibility)
                $first = @($instances) | Select-Object -First 1
                if ($first) {
                    if (-not [string]::IsNullOrWhiteSpace([string]$first.RepositoryServer)) {
                        $settings.RepositoryServer = [string]$first.RepositoryServer
                    }
                    if (-not [string]::IsNullOrWhiteSpace([string]$first.RepositoryDatabase)) {
                        $settings.RepositoryDatabase = [string]$first.RepositoryDatabase
                    }
                }
                $settings.MonitoredInstances = @($instances | ForEach-Object { [string]$_.SqlInstance } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
            }
        }
        catch {
            # Defaults are good enough if config is not readable yet.
        }
    }

    return $settings
}

function New-UiFont {
    param(
        [float]$Size,
        [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular
    )
    return New-Object System.Drawing.Font("Segoe UI", $Size, $Style)
}

function Add-Label {
    param(
        [System.Windows.Forms.Control]$Parent,
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$Width = 140
    )

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.Location = New-Object System.Drawing.Point($X, $Y)
    $label.Size = New-Object System.Drawing.Size($Width, 24)
    $label.Font = New-UiFont -Size 9
    $Parent.Controls.Add($label)
    return $label
}

function Add-ButtonStyle {
    param([System.Windows.Forms.Button]$Button)
    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 0
    $Button.BackColor = [System.Drawing.Color]::FromArgb(8, 103, 196)
    $Button.ForeColor = [System.Drawing.Color]::White
    $Button.Font = New-UiFont -Size 9 -Style ([System.Drawing.FontStyle]::Bold)
    $Button.Cursor = [System.Windows.Forms.Cursors]::Hand
}

function Add-SecondaryButtonStyle {
    param([System.Windows.Forms.Button]$Button)
    Add-ButtonStyle -Button $Button
    $Button.BackColor = [System.Drawing.Color]::FromArgb(28, 46, 74)
}

function Add-CardStyle {
    param([System.Windows.Forms.GroupBox]$Group)
    $Group.BackColor = [System.Drawing.Color]::White
    $Group.ForeColor = [System.Drawing.Color]::FromArgb(38, 50, 72)
    $Group.Font = New-UiFont -Size 9 -Style ([System.Drawing.FontStyle]::Bold)
}

function Get-MonitoredInstanceList {
    return @($txtMonitoredInstances.Text -split '\r?\n|,' | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
}

function New-DeployArguments {
    param(
        [switch]$All,
        [switch]$DeployDatabase,
        [switch]$DeployScripts,
        [switch]$ConfigureSqlAgentJobs,
        [switch]$ConfigureWindowsTasks,
        [switch]$ConfigurePerInstanceJobs,
        [switch]$DeployEnhancements,
        [switch]$SkipInstanceConfiguration
    )

    $arguments = New-Object System.Collections.Generic.List[string]
    $arguments.Add("-NoProfile")
    $arguments.Add("-ExecutionPolicy")
    $arguments.Add("Bypass")
    $arguments.Add("-File")
    $arguments.Add($deployScript)
    $arguments.Add("-RepositoryServer")
    $arguments.Add($txtRepositoryServer.Text.Trim())
    $arguments.Add("-RepositoryDatabase")
    $arguments.Add($txtRepositoryDatabase.Text.Trim())
    $arguments.Add("-InstallPath")
    $arguments.Add($txtInstallPath.Text.Trim())
    $arguments.Add("-CoreIntervalMinutes")
    $arguments.Add([string][int]$numCoreInterval.Value)
    $arguments.Add("-AdvancedIntervalMinutes")
    $arguments.Add([string][int]$numAdvancedInterval.Value)
    $arguments.Add("-WebDashboardPort")
    $arguments.Add("8090")
    $arguments.Add("-DailyTime")
    $arguments.Add($dtpDailyTime.Value.ToString("HH:mm"))
    $arguments.Add("-RetentionTime")
    $arguments.Add($dtpRetentionTime.Value.ToString("HH:mm"))

    $instanceList = @(Get-MonitoredInstanceList)
    if ($instanceList.Count -gt 0) {
        $arguments.Add("-MonitoredInstances")
    }
    foreach ($instance in $instanceList) {
        $arguments.Add($instance)
    }

    if ($All) { $arguments.Add("-All") }
    if ($DeployDatabase) { $arguments.Add("-DeployDatabase") }
    if ($DeployScripts) { $arguments.Add("-DeployScripts") }
    if ($ConfigureSqlAgentJobs) { $arguments.Add("-ConfigureSqlAgentJobs") }
    if ($ConfigureWindowsTasks) { $arguments.Add("-ConfigureWindowsTasks") }
    if ($ConfigurePerInstanceJobs) { $arguments.Add("-ConfigurePerInstanceJobs") }
    if ($DeployEnhancements) { $arguments.Add("-DeployDatabase") }
    if ($SkipInstanceConfiguration) { $arguments.Add("-SkipInstanceConfiguration") }
    if ($chkForce.Checked) { $arguments.Add("-Force") }
    if ($chkCreateLinkedServer.Checked) {
        $arguments.Add("-ConfigureCentralLinkedServer")
        $arguments.Add("-CentralLinkedServer")
        $arguments.Add($txtCentralLinkedServer.Text.Trim())
        $arguments.Add("-CentralServerInstance")
        $arguments.Add($txtCentralServerInstance.Text.Trim())
        $arguments.Add("-CentralSyncIntervalMinutes")
        $arguments.Add([string][int]$numCentralSyncInterval.Value)
    }

    return $arguments
}

function Join-ProcessArguments {
    param([string[]]$Arguments)

    $quoted = @()
    foreach ($arg in $Arguments) {
        if ($arg -match '[\s"]') {
            $quoted += '"' + ($arg -replace '"', '\"') + '"'
        }
        else {
            $quoted += $arg
        }
    }
    return ($quoted -join " ")
}

function New-LatestChangesArguments {
    $arguments = New-Object System.Collections.Generic.List[string]
    $arguments.Add("-NoProfile")
    $arguments.Add("-ExecutionPolicy")
    $arguments.Add("Bypass")
    $arguments.Add("-File")
    $arguments.Add($applyLatestScript)
    $arguments.Add("-RepositoryServer")
    $arguments.Add($txtRepositoryServer.Text.Trim())
    $arguments.Add("-RepositoryDatabase")
    $arguments.Add($txtRepositoryDatabase.Text.Trim())
    $arguments.Add("-SourcePath")
    $arguments.Add($projectRoot)
    $arguments.Add("-InstallPath")
    $arguments.Add($txtInstallPath.Text.Trim())
    $arguments.Add("-WebDashboardPort")
    $arguments.Add("8090")
    if ($chkConfigureSqlAgent.Checked) { $arguments.Add("-UpdateSqlAgentJobs") }
    if ($chkPerInstanceJobs.Checked) { $arguments.Add("-ConfigurePerInstanceJobs") }
    if ($chkWindowsTasks.Checked) {
        $arguments.Add("-ConfigureWindowsTasks")
        $arguments.Add("-WindowsTaskRunAs")
        $arguments.Add("System")
    }
    return $arguments
}

function New-ResetAdminArguments {
    $arguments = New-Object System.Collections.Generic.List[string]
    $arguments.Add("-NoProfile")
    $arguments.Add("-ExecutionPolicy")
    $arguments.Add("Bypass")
    $arguments.Add("-File")
    $arguments.Add($resetAdminScript)
    $arguments.Add("-RepositoryServer")
    $arguments.Add($txtRepositoryServer.Text.Trim())
    $arguments.Add("-RepositoryDatabase")
    $arguments.Add($txtRepositoryDatabase.Text.Trim())
    $arguments.Add("-UserName")
    $arguments.Add("admin")
    $arguments.Add("-NewPassword")
    $arguments.Add("Admin@123")
    return $arguments
}

function Set-ActionButtonsEnabled {
    param([bool]$Enabled)
    $btnFullDeploy.Enabled = $Enabled
    $btnDeploySelected.Enabled = $Enabled
    $btnDeployDatabaseOnly.Enabled = $Enabled
    $btnConfigureJobsOnly.Enabled = $Enabled
    $btnDeployEnhancements.Enabled = $Enabled
    if ($null -ne $btnApplyLatestChanges) { $btnApplyLatestChanges.Enabled = $Enabled }
    if ($null -ne $btnResetAdminLogin) { $btnResetAdminLogin.Enabled = $Enabled }
}

function Invoke-Deployment {
    param(
        [switch]$All,
        [switch]$DeployDatabase,
        [switch]$DeployScripts,
        [switch]$ConfigureSqlAgentJobs,
        [switch]$ConfigureWindowsTasks,
        [switch]$ConfigurePerInstanceJobs,
        [switch]$DeployEnhancements,
        [switch]$SkipInstanceConfiguration
    )

    if (-not (Test-Path $deployScript)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Deployment engine not found: $deployScript",
            "Missing Deployment Script",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    $txtOutput.Clear()
    $txtOutput.AppendText("Starting deployment at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n`r`n")
    Set-ActionButtonsEnabled -Enabled $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    try {
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = "powershell.exe"
        $startInfo.Arguments = Join-ProcessArguments -Arguments (New-DeployArguments `
            -All:$All `
            -DeployDatabase:$DeployDatabase `
            -DeployScripts:$DeployScripts `
            -ConfigureSqlAgentJobs:$ConfigureSqlAgentJobs `
            -ConfigureWindowsTasks:$ConfigureWindowsTasks `
            -ConfigurePerInstanceJobs:$ConfigurePerInstanceJobs `
            -DeployEnhancements:$DeployEnhancements `
            -SkipInstanceConfiguration:$SkipInstanceConfiguration)
        $startInfo.UseShellExecute = $false
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $startInfo.CreateNoWindow = $true
        $startInfo.WorkingDirectory = $projectRoot

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $startInfo
        [void]$process.Start()

        while (-not $process.HasExited) {
            $line = $process.StandardOutput.ReadLine()
            if ($null -ne $line) {
                $txtOutput.AppendText("$line`r`n")
                $txtOutput.SelectionStart = $txtOutput.TextLength
                $txtOutput.ScrollToCaret()
                [System.Windows.Forms.Application]::DoEvents()
            }
        }

        $remainingOutput = $process.StandardOutput.ReadToEnd()
        if (-not [string]::IsNullOrWhiteSpace($remainingOutput)) {
            $txtOutput.AppendText($remainingOutput)
        }

        $errorOutput = $process.StandardError.ReadToEnd()
        if (-not [string]::IsNullOrWhiteSpace($errorOutput)) {
            $txtOutput.AppendText("`r`nERROR OUTPUT:`r`n$errorOutput`r`n")
        }

        if ($process.ExitCode -eq 0) {
            $txtOutput.AppendText("`r`nDeployment completed successfully.`r`n")
        }
        else {
            $txtOutput.AppendText("`r`nDeployment failed with exit code $($process.ExitCode).`r`n")
        }
    }
    catch {
        $txtOutput.AppendText("ERROR: $($_.Exception.Message)`r`n")
    }
    finally {
        Set-ActionButtonsEnabled -Enabled $true
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
}

function Invoke-LatestChangesUpdate {
    if (-not (Test-Path $applyLatestScript)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Apply latest changes script not found: $applyLatestScript",
            "Missing Update Script",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    $txtOutput.Clear()
    $txtOutput.AppendText("Applying latest SQL Monitor changes at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n`r`n")
    Set-ActionButtonsEnabled -Enabled $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    try {
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = "powershell.exe"
        $startInfo.Arguments = Join-ProcessArguments -Arguments (New-LatestChangesArguments)
        $startInfo.UseShellExecute = $false
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $startInfo.CreateNoWindow = $true
        $startInfo.WorkingDirectory = $projectRoot

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $startInfo
        [void]$process.Start()

        while (-not $process.HasExited) {
            $line = $process.StandardOutput.ReadLine()
            if ($null -ne $line) {
                $txtOutput.AppendText("$line`r`n")
                $txtOutput.SelectionStart = $txtOutput.TextLength
                $txtOutput.ScrollToCaret()
                [System.Windows.Forms.Application]::DoEvents()
            }
        }

        $remainingOutput = $process.StandardOutput.ReadToEnd()
        if (-not [string]::IsNullOrWhiteSpace($remainingOutput)) {
            $txtOutput.AppendText($remainingOutput)
        }

        $errorOutput = $process.StandardError.ReadToEnd()
        if (-not [string]::IsNullOrWhiteSpace($errorOutput)) {
            $txtOutput.AppendText("`r`nERROR OUTPUT:`r`n$errorOutput`r`n")
        }

        if ($process.ExitCode -eq 0) {
            $txtOutput.AppendText("`r`nLatest application and database changes applied successfully.`r`n")
        }
        else {
            $txtOutput.AppendText("`r`nApply latest changes failed with exit code $($process.ExitCode).`r`n")
        }
    }
    catch {
        $txtOutput.AppendText("ERROR: $($_.Exception.Message)`r`n")
    }
    finally {
        Set-ActionButtonsEnabled -Enabled $true
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
}

function Invoke-DashboardAdminReset {
    if (-not (Test-Path $resetAdminScript)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Dashboard admin reset script not found: $resetAdminScript",
            "Missing Reset Script",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    $confirmation = [System.Windows.Forms.MessageBox]::Show(
        "This will reset the web dashboard admin account to Admin@123, unlock it, activate it, and force a password change on next login. Continue?",
        "Reset Dashboard Admin Login",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($confirmation -ne [System.Windows.Forms.DialogResult]::Yes) { return }

    $txtOutput.Clear()
    $txtOutput.AppendText("Resetting dashboard admin login at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n`r`n")
    Set-ActionButtonsEnabled -Enabled $false
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor

    try {
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = "powershell.exe"
        $startInfo.Arguments = Join-ProcessArguments -Arguments (New-ResetAdminArguments)
        $startInfo.UseShellExecute = $false
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true
        $startInfo.CreateNoWindow = $true
        $startInfo.WorkingDirectory = $projectRoot

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $startInfo
        [void]$process.Start()

        while (-not $process.HasExited) {
            $line = $process.StandardOutput.ReadLine()
            if ($null -ne $line) {
                $txtOutput.AppendText("$line`r`n")
                $txtOutput.SelectionStart = $txtOutput.TextLength
                $txtOutput.ScrollToCaret()
                [System.Windows.Forms.Application]::DoEvents()
            }
        }

        $remainingOutput = $process.StandardOutput.ReadToEnd()
        if (-not [string]::IsNullOrWhiteSpace($remainingOutput)) {
            $txtOutput.AppendText($remainingOutput)
        }

        $errorOutput = $process.StandardError.ReadToEnd()
        if (-not [string]::IsNullOrWhiteSpace($errorOutput)) {
            $txtOutput.AppendText("`r`nERROR OUTPUT:`r`n$errorOutput`r`n")
        }

        if ($process.ExitCode -eq 0) {
            $txtOutput.AppendText("`r`nDashboard admin login reset successfully.`r`n")
        }
        else {
            $txtOutput.AppendText("`r`nDashboard admin login reset failed with exit code $($process.ExitCode).`r`n")
        }
    }
    catch {
        $txtOutput.AppendText("ERROR: $($_.Exception.Message)`r`n")
    }
    finally {
        Set-ActionButtonsEnabled -Enabled $true
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
}

$defaults = Get-DefaultRepositorySettings

$form = New-Object System.Windows.Forms.Form
$form.Text = "SQL Monitor Deployment Center"
$form.Size = New-Object System.Drawing.Size(1220, 900)
$form.MinimumSize = New-Object System.Drawing.Size(1160, 820)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(237, 243, 250)
$form.Font = New-UiFont -Size 9
$form.AutoScroll = $true
$form.AutoScrollMinSize = New-Object System.Drawing.Size(1180, 1010)

$pnlHeader = New-Object System.Windows.Forms.Panel
$pnlHeader.Location = New-Object System.Drawing.Point(24, 18)
$pnlHeader.Size = New-Object System.Drawing.Size(1130, 78)
$pnlHeader.BackColor = [System.Drawing.Color]::FromArgb(17, 35, 64)
$form.Controls.Add($pnlHeader)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "SQL Monitor Deployment Center"
$lblTitle.Font = New-UiFont -Size 18 -Style ([System.Drawing.FontStyle]::Bold)
$lblTitle.AutoSize = $true
$lblTitle.ForeColor = [System.Drawing.Color]::White
$lblTitle.Location = New-Object System.Drawing.Point(22, 14)
$pnlHeader.Controls.Add($lblTitle)

$lblSubtitle = New-Object System.Windows.Forms.Label
$lblSubtitle.Text = "Deploy repository schema, application files, SQL Agent jobs, and central sync from one clean control surface."
$lblSubtitle.Font = New-UiFont -Size 10
$lblSubtitle.AutoSize = $true
$lblSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(205, 219, 235)
$lblSubtitle.Location = New-Object System.Drawing.Point(24, 48)
$pnlHeader.Controls.Add($lblSubtitle)

$grpConnection = New-Object System.Windows.Forms.GroupBox
$grpConnection.Text = "Repository and Install Target"
$grpConnection.Location = New-Object System.Drawing.Point(24, 112)
$grpConnection.Size = New-Object System.Drawing.Size(1130, 150)
Add-CardStyle -Group $grpConnection
$form.Controls.Add($grpConnection)

Add-Label -Parent $grpConnection -Text "Repository Server:" -X 20 -Y 34 | Out-Null
$txtRepositoryServer = New-Object System.Windows.Forms.TextBox
$txtRepositoryServer.Location = New-Object System.Drawing.Point(160, 30)
$txtRepositoryServer.Size = New-Object System.Drawing.Size(390, 28)
$txtRepositoryServer.Text = $defaults.RepositoryServer
$grpConnection.Controls.Add($txtRepositoryServer)

Add-Label -Parent $grpConnection -Text "Repository Database:" -X 585 -Y 34 | Out-Null
$txtRepositoryDatabase = New-Object System.Windows.Forms.TextBox
$txtRepositoryDatabase.Location = New-Object System.Drawing.Point(745, 30)
$txtRepositoryDatabase.Size = New-Object System.Drawing.Size(240, 28)
$txtRepositoryDatabase.Text = $defaults.RepositoryDatabase
$grpConnection.Controls.Add($txtRepositoryDatabase)

Add-Label -Parent $grpConnection -Text "Install Path:" -X 20 -Y 78 | Out-Null
$txtInstallPath = New-Object System.Windows.Forms.TextBox
$txtInstallPath.Location = New-Object System.Drawing.Point(160, 74)
$txtInstallPath.Size = New-Object System.Drawing.Size(825, 28)
$txtInstallPath.Text = $projectRoot
$grpConnection.Controls.Add($txtInstallPath)

$btnBrowseInstall = New-Object System.Windows.Forms.Button
$btnBrowseInstall.Text = "Browse"
$btnBrowseInstall.Location = New-Object System.Drawing.Point(1005, 72)
$btnBrowseInstall.Size = New-Object System.Drawing.Size(90, 30)
Add-ButtonStyle -Button $btnBrowseInstall
$grpConnection.Controls.Add($btnBrowseInstall)

$chkForce = New-Object System.Windows.Forms.CheckBox
$chkForce.Text = "Force overwrite existing SQL Monitor files during copy"
$chkForce.AutoSize = $true
$chkForce.Location = New-Object System.Drawing.Point(160, 112)
$grpConnection.Controls.Add($chkForce)

$grpOptions = New-Object System.Windows.Forms.GroupBox
$grpOptions.Text = "Deployment Options"
$grpOptions.Location = New-Object System.Drawing.Point(24, 278)
$grpOptions.Size = New-Object System.Drawing.Size(548, 255)
Add-CardStyle -Group $grpOptions
$form.Controls.Add($grpOptions)

$chkDeployDatabase = New-Object System.Windows.Forms.CheckBox
$chkDeployDatabase.Text = "Deploy repository schema, views, alert objects, dashboard security"
$chkDeployDatabase.Checked = $true
$chkDeployDatabase.AutoSize = $true
$chkDeployDatabase.Location = New-Object System.Drawing.Point(22, 34)
$grpOptions.Controls.Add($chkDeployDatabase)

$chkDeployScripts = New-Object System.Windows.Forms.CheckBox
$chkDeployScripts.Text = "Copy collectors, jobs, web dashboard, and launchers"
$chkDeployScripts.Checked = $true
$chkDeployScripts.AutoSize = $true
$chkDeployScripts.Location = New-Object System.Drawing.Point(22, 64)
$grpOptions.Controls.Add($chkDeployScripts)

$chkConfigureSqlAgent = New-Object System.Windows.Forms.CheckBox
$chkConfigureSqlAgent.Text = "Configure SQL Server Agent jobs"
$chkConfigureSqlAgent.Checked = $true
$chkConfigureSqlAgent.AutoSize = $true
$chkConfigureSqlAgent.Location = New-Object System.Drawing.Point(22, 94)
$grpOptions.Controls.Add($chkConfigureSqlAgent)

$chkPerInstanceJobs = New-Object System.Windows.Forms.CheckBox
$chkPerInstanceJobs.Text = "Also create individual per-server collector jobs"
$chkPerInstanceJobs.AutoSize = $true
$chkPerInstanceJobs.Location = New-Object System.Drawing.Point(45, 124)
$grpOptions.Controls.Add($chkPerInstanceJobs)

$chkWindowsTasks = New-Object System.Windows.Forms.CheckBox
$chkWindowsTasks.Text = "Configure Windows Scheduled Tasks instead/as well"
$chkWindowsTasks.AutoSize = $true
$chkWindowsTasks.Location = New-Object System.Drawing.Point(22, 154)
$grpOptions.Controls.Add($chkWindowsTasks)

$chkEnhancements = New-Object System.Windows.Forms.CheckBox
$chkEnhancements.Text = "Deploy Task, Ticket & Escalation enhancements (Phase 8)"
$chkEnhancements.AutoSize = $true
$chkEnhancements.Location = New-Object System.Drawing.Point(22, 184)
$chkEnhancements.Checked = $true
$grpOptions.Controls.Add($chkEnhancements)

$lblWarning = New-Object System.Windows.Forms.Label
$lblWarning.Text = "SQL Agent jobs run on the repository SQL Server. Web Dashboard uses Launch-WebDashboard.bat on port 8090."
$lblWarning.Location = New-Object System.Drawing.Point(22, 214)
$lblWarning.Size = New-Object System.Drawing.Size(500, 32)
$lblWarning.ForeColor = [System.Drawing.Color]::FromArgb(150, 90, 0)
$grpOptions.Controls.Add($lblWarning)

$grpSchedule = New-Object System.Windows.Forms.GroupBox
$grpSchedule.Text = "Job Schedule"
$grpSchedule.Location = New-Object System.Drawing.Point(606, 278)
$grpSchedule.Size = New-Object System.Drawing.Size(548, 255)
Add-CardStyle -Group $grpSchedule
$form.Controls.Add($grpSchedule)

Add-Label -Parent $grpSchedule -Text "Core interval min:" -X 20 -Y 36 | Out-Null
$numCoreInterval = New-Object System.Windows.Forms.NumericUpDown
$numCoreInterval.Minimum = 1
$numCoreInterval.Maximum = 1440
$numCoreInterval.Value = 5
$numCoreInterval.Location = New-Object System.Drawing.Point(170, 32)
$numCoreInterval.Size = New-Object System.Drawing.Size(90, 28)
$grpSchedule.Controls.Add($numCoreInterval)

Add-Label -Parent $grpSchedule -Text "Advanced interval min:" -X 20 -Y 76 | Out-Null
$numAdvancedInterval = New-Object System.Windows.Forms.NumericUpDown
$numAdvancedInterval.Minimum = 1
$numAdvancedInterval.Maximum = 1440
$numAdvancedInterval.Value = 30
$numAdvancedInterval.Location = New-Object System.Drawing.Point(170, 72)
$numAdvancedInterval.Size = New-Object System.Drawing.Size(90, 28)
$grpSchedule.Controls.Add($numAdvancedInterval)

Add-Label -Parent $grpSchedule -Text "Daily collectors at:" -X 20 -Y 116 | Out-Null
$dtpDailyTime = New-Object System.Windows.Forms.DateTimePicker
$dtpDailyTime.Format = [System.Windows.Forms.DateTimePickerFormat]::Time
$dtpDailyTime.ShowUpDown = $true
$dtpDailyTime.Value = [datetime]::Today.AddHours(2)
$dtpDailyTime.Location = New-Object System.Drawing.Point(170, 112)
$dtpDailyTime.Size = New-Object System.Drawing.Size(120, 28)
$grpSchedule.Controls.Add($dtpDailyTime)

Add-Label -Parent $grpSchedule -Text "Retention purge at:" -X 20 -Y 156 | Out-Null
$dtpRetentionTime = New-Object System.Windows.Forms.DateTimePicker
$dtpRetentionTime.Format = [System.Windows.Forms.DateTimePickerFormat]::Time
$dtpRetentionTime.ShowUpDown = $true
$dtpRetentionTime.Value = [datetime]::Today.AddHours(3)
$dtpRetentionTime.Location = New-Object System.Drawing.Point(170, 152)
$dtpRetentionTime.Size = New-Object System.Drawing.Size(120, 28)
$grpSchedule.Controls.Add($dtpRetentionTime)

$grpInstances = New-Object System.Windows.Forms.GroupBox
$grpInstances.Text = "Monitored SQL Servers"
$grpInstances.Location = New-Object System.Drawing.Point(24, 550)
$grpInstances.Size = New-Object System.Drawing.Size(548, 190)
Add-CardStyle -Group $grpInstances
$form.Controls.Add($grpInstances)

$txtMonitoredInstances = New-Object System.Windows.Forms.TextBox
$txtMonitoredInstances.Multiline = $true
$txtMonitoredInstances.ScrollBars = "Vertical"
$txtMonitoredInstances.Location = New-Object System.Drawing.Point(20, 30)
$txtMonitoredInstances.Size = New-Object System.Drawing.Size(508, 120)
$txtMonitoredInstances.Text = ($defaults.MonitoredInstances -join "`r`n")
$grpInstances.Controls.Add($txtMonitoredInstances)

$lblInstancesHelp = New-Object System.Windows.Forms.Label
$lblInstancesHelp.Text = "Enter one SQL Server or instance per line. If blank, repository server is monitored."
$lblInstancesHelp.Location = New-Object System.Drawing.Point(20, 158)
$lblInstancesHelp.Size = New-Object System.Drawing.Size(508, 22)
$lblInstancesHelp.ForeColor = [System.Drawing.Color]::DimGray
$grpInstances.Controls.Add($lblInstancesHelp)

$grpCentralSync = New-Object System.Windows.Forms.GroupBox
$grpCentralSync.Text = "Central Repository Sync"
$grpCentralSync.Location = New-Object System.Drawing.Point(24, 815)
$grpCentralSync.Size = New-Object System.Drawing.Size(1130, 98)
Add-CardStyle -Group $grpCentralSync
$form.Controls.Add($grpCentralSync)

$chkCreateLinkedServer = New-Object System.Windows.Forms.CheckBox
$chkCreateLinkedServer.Text = "Create linked server to central"
$chkCreateLinkedServer.AutoSize = $true
$chkCreateLinkedServer.Location = New-Object System.Drawing.Point(20, 30)
$grpCentralSync.Controls.Add($chkCreateLinkedServer)

Add-Label -Parent $grpCentralSync -Text "Linked Server:" -X 280 -Y 32 -Width 110 | Out-Null
$txtCentralLinkedServer = New-Object System.Windows.Forms.TextBox
$txtCentralLinkedServer.Location = New-Object System.Drawing.Point(392, 28)
$txtCentralLinkedServer.Size = New-Object System.Drawing.Size(170, 24)
$txtCentralLinkedServer.Text = "SQLMON_CENTRAL"
$grpCentralSync.Controls.Add($txtCentralLinkedServer)

Add-Label -Parent $grpCentralSync -Text "Central SQL Server:" -X 590 -Y 32 -Width 130 | Out-Null
$txtCentralServerInstance = New-Object System.Windows.Forms.TextBox
$txtCentralServerInstance.Location = New-Object System.Drawing.Point(730, 28)
$txtCentralServerInstance.Size = New-Object System.Drawing.Size(235, 24)
$grpCentralSync.Controls.Add($txtCentralServerInstance)

Add-Label -Parent $grpCentralSync -Text "Sync every min:" -X 280 -Y 66 -Width 110 | Out-Null
$numCentralSyncInterval = New-Object System.Windows.Forms.NumericUpDown
$numCentralSyncInterval.Minimum = 1
$numCentralSyncInterval.Maximum = 1440
$numCentralSyncInterval.Value = 15
$numCentralSyncInterval.Location = New-Object System.Drawing.Point(392, 62)
$numCentralSyncInterval.Size = New-Object System.Drawing.Size(90, 24)
$grpCentralSync.Controls.Add($numCentralSyncInterval)

$lblCentralHelp = New-Object System.Windows.Forms.Label
$lblCentralHelp.Text = "Use this when this node pushes newly collected rows into a central DBA_SQLMonitor repository."
$lblCentralHelp.Location = New-Object System.Drawing.Point(590, 64)
$lblCentralHelp.Size = New-Object System.Drawing.Size(500, 22)
$lblCentralHelp.ForeColor = [System.Drawing.Color]::FromArgb(92, 104, 121)
$grpCentralSync.Controls.Add($lblCentralHelp)

$grpActions = New-Object System.Windows.Forms.GroupBox
$grpActions.Text = "Actions"
$grpActions.Location = New-Object System.Drawing.Point(606, 550)
$grpActions.Size = New-Object System.Drawing.Size(548, 246)
Add-CardStyle -Group $grpActions
$form.Controls.Add($grpActions)

$btnFullDeploy = New-Object System.Windows.Forms.Button
$btnFullDeploy.Text = "One Click Full Deploy"
$btnFullDeploy.Location = New-Object System.Drawing.Point(20, 32)
$btnFullDeploy.Size = New-Object System.Drawing.Size(240, 38)
Add-ButtonStyle -Button $btnFullDeploy
$grpActions.Controls.Add($btnFullDeploy)

$btnDeploySelected = New-Object System.Windows.Forms.Button
$btnDeploySelected.Text = "Deploy Selected Options"
$btnDeploySelected.Location = New-Object System.Drawing.Point(285, 32)
$btnDeploySelected.Size = New-Object System.Drawing.Size(240, 38)
Add-ButtonStyle -Button $btnDeploySelected
$grpActions.Controls.Add($btnDeploySelected)

$btnDeployDatabaseOnly = New-Object System.Windows.Forms.Button
$btnDeployDatabaseOnly.Text = "Database Only"
$btnDeployDatabaseOnly.Location = New-Object System.Drawing.Point(20, 88)
$btnDeployDatabaseOnly.Size = New-Object System.Drawing.Size(240, 38)
Add-ButtonStyle -Button $btnDeployDatabaseOnly
$grpActions.Controls.Add($btnDeployDatabaseOnly)

$btnConfigureJobsOnly = New-Object System.Windows.Forms.Button
$btnConfigureJobsOnly.Text = "Configure Agent Jobs Only"
$btnConfigureJobsOnly.Location = New-Object System.Drawing.Point(285, 88)
$btnConfigureJobsOnly.Size = New-Object System.Drawing.Size(240, 38)
Add-ButtonStyle -Button $btnConfigureJobsOnly
$grpActions.Controls.Add($btnConfigureJobsOnly)

$btnDeployEnhancements = New-Object System.Windows.Forms.Button
$btnDeployEnhancements.Text = "Deploy Enhancements Only"
$btnDeployEnhancements.Location = New-Object System.Drawing.Point(20, 144)
$btnDeployEnhancements.Size = New-Object System.Drawing.Size(240, 38)
Add-ButtonStyle -Button $btnDeployEnhancements
$grpActions.Controls.Add($btnDeployEnhancements)

$btnApplyLatestChanges = New-Object System.Windows.Forms.Button
$btnApplyLatestChanges.Text = "Apply Latest Changes"
$btnApplyLatestChanges.Location = New-Object System.Drawing.Point(285, 144)
$btnApplyLatestChanges.Size = New-Object System.Drawing.Size(240, 38)
Add-ButtonStyle -Button $btnApplyLatestChanges
$grpActions.Controls.Add($btnApplyLatestChanges)

$btnResetAdminLogin = New-Object System.Windows.Forms.Button
$btnResetAdminLogin.Text = "Repair Admin Login"
$btnResetAdminLogin.Location = New-Object System.Drawing.Point(20, 200)
$btnResetAdminLogin.Size = New-Object System.Drawing.Size(240, 38)
Add-SecondaryButtonStyle -Button $btnResetAdminLogin
$grpActions.Controls.Add($btnResetAdminLogin)

$txtOutput = New-Object System.Windows.Forms.TextBox
$txtOutput.Multiline = $true
$txtOutput.ScrollBars = "Vertical"
$txtOutput.ReadOnly = $true
$txtOutput.Font = New-Object System.Drawing.Font("Consolas", 9)
$txtOutput.Location = New-Object System.Drawing.Point(24, 930)
$txtOutput.Size = New-Object System.Drawing.Size(1130, 60)
$txtOutput.BackColor = [System.Drawing.Color]::FromArgb(12, 22, 38)
$txtOutput.ForeColor = [System.Drawing.Color]::FromArgb(220, 235, 250)
$form.Controls.Add($txtOutput)

$btnBrowseInstall.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select SQL Monitor install path"
    $dialog.SelectedPath = $txtInstallPath.Text
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtInstallPath.Text = $dialog.SelectedPath
    }
})

$btnFullDeploy.Add_Click({
    Invoke-Deployment -All -ConfigurePerInstanceJobs:$chkPerInstanceJobs.Checked -ConfigureWindowsTasks:$chkWindowsTasks.Checked -DeployEnhancements:$chkEnhancements.Checked
})

$btnDeploySelected.Add_Click({
    Invoke-Deployment `
        -DeployDatabase:$chkDeployDatabase.Checked `
        -DeployScripts:$chkDeployScripts.Checked `
        -ConfigureSqlAgentJobs:$chkConfigureSqlAgent.Checked `
        -ConfigureWindowsTasks:$chkWindowsTasks.Checked `
        -ConfigurePerInstanceJobs:$chkPerInstanceJobs.Checked `
        -DeployEnhancements:$chkEnhancements.Checked
})


$btnDeployEnhancements.Add_Click({
    Invoke-Deployment -DeployDatabase -SkipInstanceConfiguration
    # After database deployment, also set up default escalation rules
    $txtOutput.AppendText("`r`nSetting up default escalation rules...`r`n")
    $arguments = New-Object System.Collections.Generic.List[string]
    $arguments.Add("-NoProfile")
    $arguments.Add("-ExecutionPolicy")
    $arguments.Add("Bypass")
    $arguments.Add("-Command")
    $arguments.Add("Import-Module '$projectRoot\Modules\Common.psm1' -Force; Import-Module '$projectRoot\Modules\EscalationMatrix.psm1' -Force; Set-DefaultEscalationRules")
    
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = "powershell.exe"
    $startInfo.Arguments = Join-ProcessArguments -Arguments $arguments
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.CreateNoWindow = $true
    $startInfo.WorkingDirectory = $projectRoot

    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    [void]$process.Start()
    
    while (-not $process.HasExited) {
        $line = $process.StandardOutput.ReadLine()
        if ($null -ne $line) {
            $txtOutput.AppendText("$line`r`n")
            $txtOutput.SelectionStart = $txtOutput.TextLength
            $txtOutput.ScrollToCaret()
            [System.Windows.Forms.Application]::DoEvents()
        }
    }
    $remainingOutput = $process.StandardOutput.ReadToEnd()
    if (-not [string]::IsNullOrWhiteSpace($remainingOutput)) {
        $txtOutput.AppendText($remainingOutput)
    }
    $errorOutput = $process.StandardError.ReadToEnd()
    if (-not [string]::IsNullOrWhiteSpace($errorOutput)) {
        $txtOutput.AppendText("`r`nERROR OUTPUT:`r`n$errorOutput`r`n")
    }
    if ($process.ExitCode -eq 0) {
        $txtOutput.AppendText("`r`nDefault escalation rules configured successfully.`r`n")
    }
    else {
        $txtOutput.AppendText("`r`nDefault escalation rule setup failed with exit code $($process.ExitCode).`r`n")
    }
})
$btnDeployDatabaseOnly.Add_Click({
    Invoke-Deployment -DeployDatabase -DeployEnhancements:$chkEnhancements.Checked -SkipInstanceConfiguration
})

$btnConfigureJobsOnly.Add_Click({
    Invoke-Deployment -ConfigureSqlAgentJobs -ConfigurePerInstanceJobs:$chkPerInstanceJobs.Checked
})

$btnApplyLatestChanges.Add_Click({
    Invoke-LatestChangesUpdate
})

$btnResetAdminLogin.Add_Click({
    Invoke-DashboardAdminReset
})

[void]$form.ShowDialog()
