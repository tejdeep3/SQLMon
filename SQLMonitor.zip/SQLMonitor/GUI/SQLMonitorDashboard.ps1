Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms.DataVisualization

$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\WebAgent.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\PatchManager.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\PatchDownloader.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\TaskManagement.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\TicketSystem.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\EscalationMatrix.psm1') -Force -WarningAction SilentlyContinue

# ------------------------------------------------------------
# Config
# ------------------------------------------------------------
$RepositoryServer = ''
$RepositoryDatabase = ''

try {
    $repositorySettings = Get-SqlMonitorRepositorySettings
    $RepositoryServer = $repositorySettings.RepositoryServer
    $RepositoryDatabase = $repositorySettings.RepositoryDatabase
}
catch {
    $RepositoryServer = 'localhost'
    $RepositoryDatabase = 'DBA_SQLMonitor'
}

$script:CurrentUser = $null
$script:LoginCancelled = $false

function ConvertTo-HexString {
    param([byte[]]$Bytes)

    if ($null -eq $Bytes) { return "0x" }
    return "0x" + (($Bytes | ForEach-Object { $_.ToString("X2") }) -join "")
}

function Load-CommonIssues {
    # Prefer the rich HTML SOP file if it exists; otherwise fall back to the sample data.
    $htmlPath = Join-Path $PSScriptRoot "..\\Docs\\SOPs.html"
    try {
        if (Test-Path $htmlPath) {
            $html = Get-Content $htmlPath -Raw -ErrorAction Stop
            $script:webSOPs.DocumentText = $html
        } else {
            # Fallback: generate a simple table from hard‑coded sample data (kept for backward compatibility)
            $issues = @(
                @{ IssueID = 1; Category = "Performance"; Severity = "Critical"; Title = "High CPU Utilization (>90%)"; Description = "SQL Server CPU usage is consistently above 90%"; Frequency = "High"; SOP = "1. Identify top CPU‑consuming queries..." },
                @{ IssueID = 2; Category = "Memory"; Severity = "Critical"; Title = "Low Page Life Expectancy (<100 seconds)"; Description = "Pages are being flushed from memory too quickly"; Frequency = "Medium"; SOP = "1. Increase server memory..." }
            )
            $html = "<h2>Common Issues</h2><table border='1' cellpadding='5'><tr><th>ID</th><th>Title</th><th>Description</th><th>Severity</th><th>SOP</th></tr>"
            foreach ($issue in $issues) {
                $html += "<tr><td>$($issue.IssueID)</td><td>$($issue.Title)</td><td>$($issue.Description)</td><td>$($issue.Severity)</td><td><pre>$($issue.SOP)</pre></td></tr>"
            }
            $html += "</table>"
            $script:webSOPs.DocumentText = $html
        }
    } catch {
        $script:webSOPs.DocumentText = "<p>Error loading Common Issues: $($_.Exception.Message)</p>"
    }
}

# Data Query Functions – Overview
function Get-OverviewData {
    $query = @"
SELECT *
FROM mon.vw_OverviewWithAlerts
ORDER BY DisplayName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

# Password handling utilities (mirrored from Web\Start-WebServer.ps1)
function New-PasswordSalt {
    $salt = New-Object byte[] 16
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($salt) }
    finally { $rng.Dispose() }
    return ,$salt
}

# Clears the instance form fields – used throughout the UI
function Clear-InstanceForm {
    $script:txtDisplayName.Text = ""
    $script:txtSqlInstance.Text = ""
    $script:txtRepositoryServer.Text = $RepositoryServer
    $script:txtRepositoryDatabase.Text = $RepositoryDatabase
    $script:txtEnvironment.Text = "Production"
    $script:chkInstanceActive.Checked = $true
}

function Save-InstanceConfigFromValues {
    param(
        [string]$DisplayName,
        [string]$SqlInstance,
        [string]$RepositoryServerValue,
        [string]$RepositoryDatabaseValue,
        [string]$Environment,
        [bool]$IsActive
    )

    $sqlInstanceValue = ([string]$SqlInstance).Trim()
    $displayNameValue = ([string]$DisplayName).Trim()
    if ([string]::IsNullOrWhiteSpace($displayNameValue)) {
        $displayNameValue = $sqlInstanceValue
    }

    if ([string]::IsNullOrWhiteSpace($sqlInstanceValue)) {
        throw "SQL Instance is required."
    }
    if ([string]::IsNullOrWhiteSpace($displayNameValue)) {
        throw "Display Name is required."
    }

    $repoServerValue = if ([string]::IsNullOrWhiteSpace($RepositoryServerValue)) { $RepositoryServer } else { ([string]$RepositoryServerValue).Trim() }
    $repoDatabaseValue = if ([string]::IsNullOrWhiteSpace($RepositoryDatabaseValue)) { $RepositoryDatabase } else { ([string]$RepositoryDatabaseValue).Trim() }
    $environmentValue = if ([string]::IsNullOrWhiteSpace($Environment)) { "Production" } else { ([string]$Environment).Trim() }

    $instances = @(Load-InstanceConfigs)
    $existing = $instances |
        Where-Object { $_.DisplayName -eq $displayNameValue -or $_.SqlInstance -eq $sqlInstanceValue } |
        Select-Object -First 1

    if ($existing) {
        $existing.DisplayName = $displayNameValue
        $existing.SqlInstance = $sqlInstanceValue
        $existing.RepositoryServer = $repoServerValue
        $existing.RepositoryDatabase = $repoDatabaseValue
        $existing.Environment = $environmentValue
        $existing.IsActive = $IsActive
    }
    else {
        $instances += [pscustomobject]@{
            DisplayName        = $displayNameValue
            SqlInstance        = $sqlInstanceValue
            RepositoryServer   = $repoServerValue
            RepositoryDatabase = $repoDatabaseValue
            Environment        = $environmentValue
            IsActive           = $IsActive
        }
    }

    Save-InstanceConfigs -Instances $instances
    Refresh-InstanceConfigs
    Refresh-MainDashboardAfterInstanceConfigChange
}

function Show-NewInstanceForm {
    param([System.Windows.Forms.Form]$OwnerForm)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Add New Server"
    $dlg.Size = New-Object System.Drawing.Size(560, 360)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)

    $fontLabel = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $fontInput = New-Object System.Drawing.Font("Segoe UI", 10)

    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text = "Add new monitored server"
    $lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
    $lblTitle.AutoSize = $true
    $lblTitle.Location = New-Object System.Drawing.Point(22, 18)
    $dlg.Controls.Add($lblTitle)

    $lblSqlInstance = New-Object System.Windows.Forms.Label
    $lblSqlInstance.Text = "SQL Instance"
    $lblSqlInstance.Font = $fontLabel
    $lblSqlInstance.Location = New-Object System.Drawing.Point(24, 62)
    $lblSqlInstance.AutoSize = $true
    $dlg.Controls.Add($lblSqlInstance)

    $txtNewSqlInstance = New-Object System.Windows.Forms.TextBox
    $txtNewSqlInstance.Location = New-Object System.Drawing.Point(170, 58)
    $txtNewSqlInstance.Size = New-Object System.Drawing.Size(330, 28)
    $txtNewSqlInstance.Font = $fontInput
    $dlg.Controls.Add($txtNewSqlInstance)

    $lblDisplayName = New-Object System.Windows.Forms.Label
    $lblDisplayName.Text = "Display Name"
    $lblDisplayName.Font = $fontLabel
    $lblDisplayName.Location = New-Object System.Drawing.Point(24, 102)
    $lblDisplayName.AutoSize = $true
    $dlg.Controls.Add($lblDisplayName)

    $txtNewDisplayName = New-Object System.Windows.Forms.TextBox
    $txtNewDisplayName.Location = New-Object System.Drawing.Point(170, 98)
    $txtNewDisplayName.Size = New-Object System.Drawing.Size(330, 28)
    $txtNewDisplayName.Font = $fontInput
    $dlg.Controls.Add($txtNewDisplayName)

    $lblRepositoryServer = New-Object System.Windows.Forms.Label
    $lblRepositoryServer.Text = "Repository Server"
    $lblRepositoryServer.Font = $fontLabel
    $lblRepositoryServer.Location = New-Object System.Drawing.Point(24, 142)
    $lblRepositoryServer.AutoSize = $true
    $dlg.Controls.Add($lblRepositoryServer)

    $txtNewRepositoryServer = New-Object System.Windows.Forms.TextBox
    $txtNewRepositoryServer.Location = New-Object System.Drawing.Point(170, 138)
    $txtNewRepositoryServer.Size = New-Object System.Drawing.Size(330, 28)
    $txtNewRepositoryServer.Text = $RepositoryServer
    $txtNewRepositoryServer.Font = $fontInput
    $dlg.Controls.Add($txtNewRepositoryServer)

    $lblRepositoryDatabase = New-Object System.Windows.Forms.Label
    $lblRepositoryDatabase.Text = "Repository DB"
    $lblRepositoryDatabase.Font = $fontLabel
    $lblRepositoryDatabase.Location = New-Object System.Drawing.Point(24, 182)
    $lblRepositoryDatabase.AutoSize = $true
    $dlg.Controls.Add($lblRepositoryDatabase)

    $txtNewRepositoryDatabase = New-Object System.Windows.Forms.TextBox
    $txtNewRepositoryDatabase.Location = New-Object System.Drawing.Point(170, 178)
    $txtNewRepositoryDatabase.Size = New-Object System.Drawing.Size(330, 28)
    $txtNewRepositoryDatabase.Text = $RepositoryDatabase
    $txtNewRepositoryDatabase.Font = $fontInput
    $dlg.Controls.Add($txtNewRepositoryDatabase)

    $lblEnvironment = New-Object System.Windows.Forms.Label
    $lblEnvironment.Text = "Environment"
    $lblEnvironment.Font = $fontLabel
    $lblEnvironment.Location = New-Object System.Drawing.Point(24, 222)
    $lblEnvironment.AutoSize = $true
    $dlg.Controls.Add($lblEnvironment)

    $txtNewEnvironment = New-Object System.Windows.Forms.TextBox
    $txtNewEnvironment.Location = New-Object System.Drawing.Point(170, 218)
    $txtNewEnvironment.Size = New-Object System.Drawing.Size(200, 28)
    $txtNewEnvironment.Text = "Production"
    $txtNewEnvironment.Font = $fontInput
    $dlg.Controls.Add($txtNewEnvironment)

    $chkNewActive = New-Object System.Windows.Forms.CheckBox
    $chkNewActive.Text = "Active"
    $chkNewActive.Location = New-Object System.Drawing.Point(395, 220)
    $chkNewActive.Size = New-Object System.Drawing.Size(100, 28)
    $chkNewActive.Checked = $true
    $dlg.Controls.Add($chkNewActive)

    $btnCreate = New-Object System.Windows.Forms.Button
    $btnCreate.Text = "Save"
    $btnCreate.Location = New-Object System.Drawing.Point(325, 270)
    $btnCreate.Size = New-Object System.Drawing.Size(85, 34)
    $btnCreate.BackColor = [System.Drawing.Color]::FromArgb(0, 95, 184)
    $btnCreate.ForeColor = [System.Drawing.Color]::White
    $btnCreate.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $dlg.Controls.Add($btnCreate)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"
    $btnCancel.Location = New-Object System.Drawing.Point(420, 270)
    $btnCancel.Size = New-Object System.Drawing.Size(80, 34)
    $btnCancel.BackColor = [System.Drawing.Color]::FromArgb(108, 117, 125)
    $btnCancel.ForeColor = [System.Drawing.Color]::White
    $btnCancel.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $dlg.Controls.Add($btnCancel)

    $btnCreate.Add_Click({
        try {
            Save-InstanceConfigFromValues `
                -DisplayName $txtNewDisplayName.Text `
                -SqlInstance $txtNewSqlInstance.Text `
                -RepositoryServerValue $txtNewRepositoryServer.Text `
                -RepositoryDatabaseValue $txtNewRepositoryDatabase.Text `
                -Environment $txtNewEnvironment.Text `
                -IsActive $chkNewActive.Checked

            [System.Windows.Forms.MessageBox]::Show(
                "Instance configuration saved.",
                "Saved",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null

            $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $dlg.Close()
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(
                $_.Exception.Message,
                "Validation Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
        }
    })

    $btnCancel.Add_Click({
        $dlg.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $dlg.Close()
    })

    $dlg.AcceptButton = $btnCreate
    $dlg.CancelButton = $btnCancel
    $txtNewSqlInstance.Focus()

    if ($OwnerForm) {
        [void]$dlg.ShowDialog($OwnerForm)
    }
    else {
        [void]$dlg.ShowDialog()
    }
}

function Get-InstancesConfigPath {
    return Join-Path (Split-Path -Parent $PSScriptRoot) "Config\instances.json"
}

function Load-InstanceConfigs {
    $path = Get-InstancesConfigPath
    if (-not (Test-Path $path)) {
        return @()
    }

    $json = Get-Content $path -Raw
    if ([string]::IsNullOrWhiteSpace($json)) {
        return @()
    }

    $instances = $json | ConvertFrom-Json
    if ($instances -isnot [System.Array]) {
        $instances = @($instances)
    }
    return $instances
}

function Sync-InstancesJsonToDatabase {
    <#
    .SYNOPSIS
    Syncs all instances from the JSON config file to the SQL database.
    This ensures instances defined in the JSON are registered in mon.MonitoredInstances.
    #>
    try {
        $instances = Load-InstanceConfigs
        if ($instances.Count -eq 0) {
            return
        }

        $syncCount = 0
        foreach ($instance in $instances) {
            try {
                $displayName = $instance.DisplayName
                $parts = $displayName -split '\\'
                
                if ($parts.Count -eq 2) {
                    $serverName = $parts[0]
                    $instanceName = $parts[1]
                }
                else {
                    $serverName = $displayName
                    $instanceName = $null
                }

                # Check if instance already exists in database
                $checkQuery = @"
SELECT COUNT(*) AS cnt FROM mon.MonitoredInstances WHERE DisplayName = @DisplayName
"@
                $result = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $checkQuery -Parameters @{ DisplayName = $displayName }

                if ([int]$result -eq 0) {
                    # Insert new instance
                    $insertQuery = @"
INSERT INTO mon.MonitoredInstances (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
VALUES (@ServerName, @InstanceName, @DisplayName, @EnvironmentName, @IsActive)
"@
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $insertQuery -Parameters @{
                        ServerName = $serverName
                        InstanceName = $instanceName
                        DisplayName = $displayName
                        EnvironmentName = $instance.Environment
                        IsActive = if ($instance.IsActive) { 1 } else { 0 }
                    }
                    $syncCount++
                }
            }
            catch {
                Write-Host "Warning: Could not sync instance '$($instance.DisplayName)' to database: $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }

        if ($syncCount -gt 0) {
            Write-Host "Synced $syncCount instance(s) from JSON to database." -ForegroundColor Green
        }
    }
    catch {
        Write-Host "Warning: Error during JSON to Database sync: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Save-InstanceConfigs {
    param([Parameter(Mandatory = $true)][AllowEmptyCollection()][object[]]$Instances)

    $path = Get-InstancesConfigPath
    $json = $Instances | ConvertTo-Json -Depth 5
    $json | Set-Content -Path $path -Encoding UTF8

    # Sync instances to SQL database
    foreach ($instance in $Instances) {
        try {
            # Parse DisplayName to extract ServerName and InstanceName
            # DisplayName format: "SERVER\INSTANCE" or "SERVER"
            $displayName = $instance.DisplayName
            $parts = $displayName -split '\\'
            
            if ($parts.Count -eq 2) {
                $serverName = $parts[0]
                $instanceName = $parts[1]
            }
            else {
                $serverName = $displayName
                $instanceName = $null
            }

            # Check if instance already exists in database
            $checkQuery = @"
SELECT COUNT(*) AS cnt FROM mon.MonitoredInstances WHERE DisplayName = @DisplayName
"@
            $result = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $checkQuery -Parameters @{ DisplayName = $displayName }

            if ([int]$result -gt 0) {
                # Update existing instance
                $updateQuery = @"
UPDATE mon.MonitoredInstances
SET ServerName = @ServerName,
    InstanceName = @InstanceName,
    EnvironmentName = @EnvironmentName,
    IsActive = @IsActive
WHERE DisplayName = @DisplayName
"@
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $updateQuery -Parameters @{
                    ServerName = $serverName
                    InstanceName = $instanceName
                    EnvironmentName = $instance.Environment
                    IsActive = if ($instance.IsActive) { 1 } else { 0 }
                    DisplayName = $displayName
                }
            }
            else {
                # Insert new instance
                $insertQuery = @"
INSERT INTO mon.MonitoredInstances (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
VALUES (@ServerName, @InstanceName, @DisplayName, @EnvironmentName, @IsActive)
"@
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $insertQuery -Parameters @{
                    ServerName = $serverName
                    InstanceName = $instanceName
                    DisplayName = $displayName
                    EnvironmentName = $instance.Environment
                    IsActive = if ($instance.IsActive) { 1 } else { 0 }
                }
            }
        }
        catch {
            Write-Host "Warning: Could not sync instance '$($instance.DisplayName)' to database: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
}

function Refresh-InstanceConfigs {
    $instances = Load-InstanceConfigs
    
    # Convert instances to DataTable for proper DataGridView binding
    $dt = New-Object System.Data.DataTable
    $dt.Columns.Add("DisplayName", [string]) | Out-Null
    $dt.Columns.Add("SqlInstance", [string]) | Out-Null
    $dt.Columns.Add("RepositoryServer", [string]) | Out-Null
    $dt.Columns.Add("RepositoryDatabase", [string]) | Out-Null
    $dt.Columns.Add("Environment", [string]) | Out-Null
    $dt.Columns.Add("IsActive", [bool]) | Out-Null
    
    foreach ($instance in $instances) {
        $row = $dt.NewRow()
        $row["DisplayName"] = if ($instance.DisplayName) { [string]$instance.DisplayName } else { "" }
        $row["SqlInstance"] = if ($instance.SqlInstance) { [string]$instance.SqlInstance } else { "" }
        $row["RepositoryServer"] = if ($instance.RepositoryServer) { [string]$instance.RepositoryServer } else { "" }
        $row["RepositoryDatabase"] = if ($instance.RepositoryDatabase) { [string]$instance.RepositoryDatabase } else { "" }
        $row["Environment"] = if ($instance.Environment) { [string]$instance.Environment } else { "" }
        $row["IsActive"] = if ($instance.IsActive) { [bool]$instance.IsActive } else { $false }
        $dt.Rows.Add($row)
    }
    
    $script:dgvInstances.DataSource = $dt
    Clear-InstanceForm
}

function Load-SelectedInstance {
    if ($script:dgvInstances.SelectedRows.Count -eq 0) {
        return
    }

    $row = $script:dgvInstances.SelectedRows[0]
    $script:txtDisplayName.Text = [string]$row.Cells["DisplayName"].Value
    $script:txtSqlInstance.Text = [string]$row.Cells["SqlInstance"].Value
    $script:txtRepositoryServer.Text = [string]$row.Cells["RepositoryServer"].Value
    $script:txtRepositoryDatabase.Text = [string]$row.Cells["RepositoryDatabase"].Value
    $script:txtEnvironment.Text = [string]$row.Cells["Environment"].Value
    $script:chkInstanceActive.Checked = [bool]$row.Cells["IsActive"].Value
}

function Save-SelectedInstance {
    $displayName = $script:txtDisplayName.Text.Trim()
    $sqlInstance = $script:txtSqlInstance.Text.Trim()
    $repoServer = $script:txtRepositoryServer.Text.Trim()
    $repoDatabase = $script:txtRepositoryDatabase.Text.Trim()
    $environment = $script:txtEnvironment.Text.Trim()
    $isActive = $script:chkInstanceActive.Checked

    if ([string]::IsNullOrWhiteSpace($displayName)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Display Name is required.",
            "Validation Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    if ([string]::IsNullOrWhiteSpace($sqlInstance)) {
        [System.Windows.Forms.MessageBox]::Show(
            "SQL Instance is required.",
            "Validation Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    try {
        Save-InstanceConfigFromValues `
            -DisplayName $displayName `
            -SqlInstance $sqlInstance `
            -RepositoryServerValue $repoServer `
            -RepositoryDatabaseValue $repoDatabase `
            -Environment $environment `
            -IsActive $isActive
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.Message,
            "Validation Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }

    [System.Windows.Forms.MessageBox]::Show(
        "Instance configuration saved.",
        "Saved",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Delete-SelectedInstance {
    if ($script:dgvInstances.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select an instance to delete.",
            "Delete Instance",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $displayName = [string]$script:dgvInstances.SelectedRows[0].Cells["DisplayName"].Value
    
    # Delete from database
    try {
        $deleteQuery = @"
DELETE FROM mon.MonitoredInstances WHERE DisplayName = @DisplayName
"@
        Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $deleteQuery -Parameters @{ DisplayName = $displayName }
    }
    catch {
        Write-Host "Warning: Could not delete instance from database: $($_.Exception.Message)" -ForegroundColor Yellow
    }
    
    # Delete from JSON config
    $instances = Load-InstanceConfigs
    $instances = $instances | Where-Object { $_.DisplayName -ne $displayName }
    Save-InstanceConfigs -Instances $instances
    Refresh-InstanceConfigs
    Refresh-MainDashboardAfterInstanceConfigChange
    [System.Windows.Forms.MessageBox]::Show(
        "Instance '$displayName' deleted.",
        "Deleted",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Reload-InstanceConfigs {
    Refresh-InstanceConfigs
}

function Refresh-MainDashboardAfterInstanceConfigChange {
    $loadOverviewCommand = Get-Command -Name Load-Overview -CommandType Function -ErrorAction SilentlyContinue
    $updateScheduleCommand = Get-Command -Name Update-ScheduleInfo -CommandType Function -ErrorAction SilentlyContinue

    if ($loadOverviewCommand -and $cbInstances -and $dgvOverview -and $lblLastRefresh) {
        & $loadOverviewCommand
    }

    if ($updateScheduleCommand -and $cbInstances -and $lblScheduleInfo) {
        & $updateScheduleCommand
    }
}

function Browse-ImportFile {
    $openFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $openFileDialog.Filter = "CSV files (*.csv)|*.csv|Text files (*.txt)|*.txt|All files (*.*)|*.*"
    $openFileDialog.Title = "Select file to import instances from"
    
    if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $txtImportFile.Text = $openFileDialog.FileName
    }
}

function Parse-ImportFile {
    param([string]$FilePath)
    
    if (-not (Test-Path $FilePath)) {
        throw "File not found: $FilePath"
    }
    
    $extension = [System.IO.Path]::GetExtension($FilePath).ToLower()
    
    if ($extension -eq ".csv") {
        # Parse CSV file
        $data = Import-Csv -Path $FilePath
        $serverColumn = $data | Get-Member -MemberType NoteProperty | Where-Object { $_.Name -like "*server*" -or $_.Name -like "*name*" } | Select-Object -First 1
        $envColumn = $data | Get-Member -MemberType NoteProperty | Where-Object { $_.Name -like "*environment*" -or $_.Name -like "*env*" } | Select-Object -First 1
        
        if (-not $serverColumn -or -not $envColumn) {
            throw "CSV file must contain columns with 'Server Name' and 'Environment' (case insensitive)"
        }
        
        $instances = @()
        foreach ($row in $data) {
            $serverName = $row.($serverColumn.Name)
            $environment = $row.($envColumn.Name)
            
            if ([string]::IsNullOrWhiteSpace($serverName) -or [string]::IsNullOrWhiteSpace($environment)) {
                continue
            }
            
            $instances += [pscustomobject]@{
                ServerName = $serverName.Trim()
                Environment = $environment.Trim()
            }
        }
        
        return $instances
    }
    elseif ($extension -eq ".txt") {
        # Parse TXT file (tab or comma separated)
        $content = Get-Content -Path $FilePath
        $header = $content[0]
        
        # Try to detect delimiter
        $delimiter = "`t"
        if ($header -match ",") {
            $delimiter = ","
        }
        
        $lines = $content | Where-Object { $_ -and $_.Trim() }
        if ($lines.Count -lt 2) {
            throw "TXT file must have at least a header row and one data row"
        }
        
        $headerParts = $header -split $delimiter
        $serverIndex = -1
        $envIndex = -1
        
        for ($i = 0; $i -lt $headerParts.Count; $i++) {
            $colName = $headerParts[$i].Trim().ToLower()
            if ($colName -like "*server*" -or $colName -like "*name*") {
                $serverIndex = $i
            }
            elseif ($colName -like "*environment*" -or $colName -like "*env*") {
                $envIndex = $i
            }
        }
        
        if ($serverIndex -eq -1 -or $envIndex -eq -1) {
            throw "TXT file must contain columns with 'Server Name' and 'Environment' (case insensitive)"
        }
        
        $instances = @()
        for ($i = 1; $i -lt $lines.Count; $i++) {
            $parts = $lines[$i] -split $delimiter
            if ($parts.Count -gt [Math]::Max($serverIndex, $envIndex)) {
                $serverName = $parts[$serverIndex].Trim()
                $environment = $parts[$envIndex].Trim()
                
                if (-not [string]::IsNullOrWhiteSpace($serverName) -and -not [string]::IsNullOrWhiteSpace($environment)) {
                    $instances += [pscustomobject]@{
                        ServerName = $serverName
                        Environment = $environment
                    }
                }
            }
        }
        
        return $instances
    }
    else {
        throw "Unsupported file format. Only .csv and .txt files are supported."
    }
}

function Preview-ImportInstances {
    if ([string]::IsNullOrWhiteSpace($txtImportFile.Text)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select a file to import.",
            "No File Selected",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }
    
    try {
        $instances = Parse-ImportFile -FilePath $txtImportFile.Text
        
        if ($instances.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "No valid instances found in the file.",
                "No Data",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }
        
        $preview = "Found $($instances.Count) instances to import:`r`n`r`n"
        foreach ($instance in $instances | Select-Object -First 10) {
            $preview += "$($instance.ServerName) - $($instance.Environment)`r`n"
        }
        
        if ($instances.Count -gt 10) {
            $preview += "`r`n... and $($instances.Count - 10) more instances"
        }
        
        [System.Windows.Forms.MessageBox]::Show(
            $preview,
            "Import Preview",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Error parsing file: $($_.Exception.Message)",
            "Parse Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Import-InstancesFromFile {
    if ([string]::IsNullOrWhiteSpace($txtImportFile.Text)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select a file to import.",
            "No File Selected",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }
    
    try {
        $newInstances = Parse-ImportFile -FilePath $txtImportFile.Text
        
        if ($newInstances.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "No valid instances found in the file.",
                "No Data",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }
        
        $existingInstances = Load-InstanceConfigs
        $addedCount = 0
        $skippedCount = 0
        
        foreach ($newInstance in $newInstances) {
            $serverName = $newInstance.ServerName
            $existing = $existingInstances | Where-Object { $_.DisplayName -eq $serverName -or $_.SqlInstance -eq $serverName }
            
            if ($existing) {
                $skippedCount++
                continue
            }
            
            $existingInstances += [pscustomobject]@{
                DisplayName = $serverName
                SqlInstance = $serverName
                RepositoryServer = $RepositoryServer
                RepositoryDatabase = $RepositoryDatabase
                Environment = $newInstance.Environment
                IsActive = $true
            }
            
            $addedCount++
        }
        
        Save-InstanceConfigs -Instances $existingInstances
        Refresh-InstanceConfigs
        Refresh-MainDashboardAfterInstanceConfigChange
        
        [System.Windows.Forms.MessageBox]::Show(
            "Import completed:`r`n- Added: $addedCount instances`r`n- Skipped: $skippedCount duplicates",
            "Import Complete",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Error importing file: $($_.Exception.Message)",
            "Import Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Clear-DashboardUserForm {
    $script:SelectedDashboardUserId = $null

    $script:lblSelectedUserId.Text = "Selected UserID: new"

    $script:txtUserName.Text = ""
    $script:txtUserDisplayName.Text = ""
    $script:txtUserPassword.Text = ""

    $script:txtUserName.ReadOnly = $false
    $script:txtUserName.Enabled = $true
    $script:txtUserDisplayName.Enabled = $true
    $script:txtUserPassword.Enabled = $true

    $script:cbUserRole.SelectedItem = "ViewOnly"
    $script:chkUserActive.Checked = $true

    Populate-UserInstanceChecklist -CheckedInstanceIDs @()

    if ($script:dgvUsers.SelectedRows.Count -gt 0) {
        $script:dgvUsers.ClearSelection()
    }

    $script:txtUserName.Focus()
}

function Refresh-DashboardUsers {
    if (-not (Test-AdminAccess)) { return }
    $script:dgvUsers.DataSource = Get-DashboardUsers
    if ($script:dgvUsers.Columns["UserID"]) {
        $script:dgvUsers.Columns["UserID"].Visible = $false
    }
    if ($script:dgvUsers.Rows.Count -eq 0) {
        Clear-DashboardUserForm
    }
}

function Start-NewDashboardUser {
    param(
        [System.Windows.Forms.IWin32Window]$OwnerForm = $null
    )

    if (-not (Require-AdminAccess -ActionName "Create dashboard user")) {
        return
    }

    if ($null -eq $OwnerForm -and $form) {
        $OwnerForm = $form
    }

    Show-NewDashboardUserDialog -OwnerForm $OwnerForm
}

function Show-NewDashboardUserDialog {
    param(
        [System.Windows.Forms.IWin32Window]$OwnerForm = $null
    )

    if (-not (Require-AdminAccess -ActionName "Create dashboard user")) {
        return
    }

    # Load active monitored instances for server access assignment
    $instancesQuery = @"
SELECT InstanceID, DisplayName
FROM mon.MonitoredInstances
WHERE IsActive = 1
ORDER BY DisplayName;
"@

    try {
        $instanceTable = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $instancesQuery
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Unable to load monitored instances.`r`n`r`n$($_.Exception.Message)",
            "Load Instances Failed",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Create New Dashboard User"
    $dlg.Size = New-Object System.Drawing.Size(720, 620)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.BackColor = [System.Drawing.Color]::WhiteSmoke

    $fontLabel = New-Object System.Drawing.Font("Segoe UI", 9)
    $fontHeader = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
    $fontHelp = New-Object System.Drawing.Font("Segoe UI", 8)

    $lblHeader = New-Object System.Windows.Forms.Label
    $lblHeader.Text = "Create new dashboard user"
    $lblHeader.Font = $fontHeader
    $lblHeader.AutoSize = $true
    $lblHeader.Location = New-Object System.Drawing.Point(20, 15)
    $dlg.Controls.Add($lblHeader)

    $lblHelp = New-Object System.Windows.Forms.Label
    $lblHelp.Text = "Create a login for the monitoring application and assign server access for read-only roles."
    $lblHelp.Font = $fontHelp
    $lblHelp.ForeColor = [System.Drawing.Color]::DimGray
    $lblHelp.AutoSize = $true
    $lblHelp.Location = New-Object System.Drawing.Point(20, 45)
    $dlg.Controls.Add($lblHelp)

    $lblUserName = New-Object System.Windows.Forms.Label
    $lblUserName.Text = "User Name:"
    $lblUserName.Font = $fontLabel
    $lblUserName.AutoSize = $true
    $lblUserName.Location = New-Object System.Drawing.Point(20, 90)
    $dlg.Controls.Add($lblUserName)

    $txtUserNameNew = New-Object System.Windows.Forms.TextBox
    $txtUserNameNew.Location = New-Object System.Drawing.Point(140, 86)
    $txtUserNameNew.Size = New-Object System.Drawing.Size(220, 24)
    $dlg.Controls.Add($txtUserNameNew)

    $lblDisplayName = New-Object System.Windows.Forms.Label
    $lblDisplayName.Text = "Display Name:"
    $lblDisplayName.Font = $fontLabel
    $lblDisplayName.AutoSize = $true
    $lblDisplayName.Location = New-Object System.Drawing.Point(380, 90)
    $dlg.Controls.Add($lblDisplayName)

    $txtDisplayNameNew = New-Object System.Windows.Forms.TextBox
    $txtDisplayNameNew.Location = New-Object System.Drawing.Point(480, 86)
    $txtDisplayNameNew.Size = New-Object System.Drawing.Size(200, 24)
    $dlg.Controls.Add($txtDisplayNameNew)

    $lblEmail = New-Object System.Windows.Forms.Label
    $lblEmail.Text = "Email:"
    $lblEmail.Font = $fontLabel
    $lblEmail.AutoSize = $true
    $lblEmail.Location = New-Object System.Drawing.Point(20, 130)
    $dlg.Controls.Add($lblEmail)

    $txtEmailNew = New-Object System.Windows.Forms.TextBox
    $txtEmailNew.Location = New-Object System.Drawing.Point(140, 126)
    $txtEmailNew.Size = New-Object System.Drawing.Size(220, 24)
    $dlg.Controls.Add($txtEmailNew)

    $lblPhone = New-Object System.Windows.Forms.Label
    $lblPhone.Text = "Phone:"
    $lblPhone.Font = $fontLabel
    $lblPhone.AutoSize = $true
    $lblPhone.Location = New-Object System.Drawing.Point(380, 130)
    $dlg.Controls.Add($lblPhone)

    $txtPhoneNew = New-Object System.Windows.Forms.TextBox
    $txtPhoneNew.Location = New-Object System.Drawing.Point(480, 126)
    $txtPhoneNew.Size = New-Object System.Drawing.Size(200, 24)
    $dlg.Controls.Add($txtPhoneNew)

    $lblDept = New-Object System.Windows.Forms.Label
    $lblDept.Text = "Department:"
    $lblDept.Font = $fontLabel
    $lblDept.AutoSize = $true
    $lblDept.Location = New-Object System.Drawing.Point(20, 170)
    $dlg.Controls.Add($lblDept)

    $txtDeptNew = New-Object System.Windows.Forms.TextBox
    $txtDeptNew.Location = New-Object System.Drawing.Point(140, 166)
    $txtDeptNew.Size = New-Object System.Drawing.Size(220, 24)
    $dlg.Controls.Add($txtDeptNew)

    $lblPassword = New-Object System.Windows.Forms.Label
    $lblPassword.Text = "Password:"
    $lblPassword.Font = $fontLabel
    $lblPassword.AutoSize = $true
    $lblPassword.Location = New-Object System.Drawing.Point(20, 210)
    $dlg.Controls.Add($lblPassword)

    $txtPasswordNew = New-Object System.Windows.Forms.TextBox
    $txtPasswordNew.Location = New-Object System.Drawing.Point(140, 206)
    $txtPasswordNew.Size = New-Object System.Drawing.Size(220, 24)
    $txtPasswordNew.UseSystemPasswordChar = $true
    $dlg.Controls.Add($txtPasswordNew)

    $lblPasswordHelp = New-Object System.Windows.Forms.Label
    $lblPasswordHelp.Text = "Password is mandatory for a new user."
    $lblPasswordHelp.Font = $fontHelp
    $lblPasswordHelp.ForeColor = [System.Drawing.Color]::DimGray
    $lblPasswordHelp.AutoSize = $true
    $lblPasswordHelp.Location = New-Object System.Drawing.Point(380, 210)
    $dlg.Controls.Add($lblPasswordHelp)

    $lblRole = New-Object System.Windows.Forms.Label
    $lblRole.Text = "Role:"
    $lblRole.Font = $fontLabel
    $lblRole.AutoSize = $true
    $lblRole.Location = New-Object System.Drawing.Point(380, 170)
    $dlg.Controls.Add($lblRole)

    $cbRoleNew = New-Object System.Windows.Forms.ComboBox
    $cbRoleNew.Location = New-Object System.Drawing.Point(480, 166)
    $cbRoleNew.Size = New-Object System.Drawing.Size(140, 24)
    $cbRoleNew.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    [void]$cbRoleNew.Items.Add("Admin")
    [void]$cbRoleNew.Items.Add("ViewOnly")
    [void]$cbRoleNew.Items.Add("Limited")
    [void]$cbRoleNew.Items.Add("Limited")
    $cbRoleNew.SelectedItem = "ViewOnly"
    $dlg.Controls.Add($cbRoleNew)

    # -------------------------------------------------
    # Button – Edit Role Permissions (visible to Admins only)
    # -------------------------------------------------
    $btnEditRoles = New-Object System.Windows.Forms.Button
    $btnEditRoles.Text = "Edit Role Permissions"
    $btnEditRoles.Location = New-Object System.Drawing.Point(20, 210)
    $btnEditRoles.Size = New-Object System.Drawing.Size(200, 30)
    $dlg.Controls.Add($btnEditRoles)

    # Enable only for Admins (assumes $script:currentUserRole is set elsewhere)
    if ($script:currentUserRole -eq 'Admin') {
        $btnEditRoles.Enabled = $true
    } else {
        $btnEditRoles.Enabled = $false
    }

    $btnEditRoles.Add_Click({
        # Load matrix using the function defined in Start-WebServer.ps1 (imported via dot‑sourcing)
        $matrix = Get-RolePermissionsMatrix

        $grid = New-Object System.Windows.Forms.DataGridView
        $grid.AutoGenerateColumns = $true
        $grid.DataSource = $matrix
        $grid.Dock = [System.Windows.Forms.DockStyle]::Fill

        $form = New-Object System.Windows.Forms.Form
        $form.Text = "Edit Role Permissions"
        $form.Size = New-Object System.Drawing.Size(800, 400)
        $form.StartPosition = "CenterParent"
        $form.Controls.Add($grid)

        $btnSave = New-Object System.Windows.Forms.Button
        $btnSave.Text = "Save"
        $btnSave.Dock = [System.Windows.Forms.DockStyle]::Bottom
        $form.Controls.Add($btnSave)

        $btnSave.Add_Click({
            $updated = @()
            foreach ($row in $grid.Rows) {
                if ($row.IsNewRow) { continue }
                $obj = [pscustomobject]@{
                    Role               = $row.Cells['Role'].Value
                    ServerOverview     = $row.Cells['ServerOverview'].Value
                    RunCollectors      = $row.Cells['RunCollectors'].Value
                    InstanceManagement = $row.Cells['InstanceManagement'].Value
                    UserManagement     = $row.Cells['UserManagement'].Value
                    Thresholds         = $row.Cells['Thresholds'].Value
                    Notifications      = $row.Cells['Notifications'].Value
                    PatchManager       = $row.Cells['PatchManager'].Value
                    RepositoryUpgrade  = $row.Cells['RepositoryUpgrade'].Value
                }
                $updated += $obj
            }
            $jsonPath = Join-Path $PSScriptRoot '..\Config\rolePermissions.json'
            $updated | ConvertTo-Json -Depth 5 | Set-Content $jsonPath -Encoding UTF8
            Show-Notification -Message "Role permissions saved." -Type Info -Title "Role Permissions"
            $form.Close()
        })

        $form.ShowDialog()
    })

    $chkIsActiveNew = New-Object System.Windows.Forms.CheckBox
    $chkIsActiveNew.Text = "Active"
    $chkIsActiveNew.Checked = $true
    $chkIsActiveNew.AutoSize = $true
    $chkIsActiveNew.Location = New-Object System.Drawing.Point(310, 169)
    $dlg.Controls.Add($chkIsActiveNew)

    $lblInstances = New-Object System.Windows.Forms.Label
    $lblInstances.Text = "Server Access:"
    $lblInstances.Font = $fontLabel
    $lblInstances.AutoSize = $true
    $lblInstances.Location = New-Object System.Drawing.Point(20, 215)
    $dlg.Controls.Add($lblInstances)

    $clbInstancesNew = New-Object System.Windows.Forms.CheckedListBox
    $clbInstancesNew.Location = New-Object System.Drawing.Point(20, 240)
    $clbInstancesNew.Size = New-Object System.Drawing.Size(660, 250)
    $clbInstancesNew.CheckOnClick = $true
    $clbInstancesNew.DisplayMember = "DisplayName"
    foreach ($row in $instanceTable.Rows) {
        [void]$clbInstancesNew.Items.Add([pscustomobject]@{
            InstanceID   = [int]$row["InstanceID"]
            DisplayName  = [string]$row["DisplayName"]
        })
    }
    $dlg.Controls.Add($clbInstancesNew)

    $lblRoleInfo = New-Object System.Windows.Forms.Label
    $lblRoleInfo.Text = "Admin = full access | ViewOnly/Limited = assigned servers only"
    $lblRoleInfo.Font = $fontHelp
    $lblRoleInfo.ForeColor = [System.Drawing.Color]::DimGray
    $lblRoleInfo.AutoSize = $true
    $lblRoleInfo.Location = New-Object System.Drawing.Point(20, 500)
    $dlg.Controls.Add($lblRoleInfo)

    $btnCreate = New-Object System.Windows.Forms.Button
    $btnCreate.Text = "Create User"
    $btnCreate.Location = New-Object System.Drawing.Point(470, 530)
    $btnCreate.Size = New-Object System.Drawing.Size(100, 32)
    $dlg.Controls.Add($btnCreate)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"
    $btnCancel.Location = New-Object System.Drawing.Point(580, 530)
    $btnCancel.Size = New-Object System.Drawing.Size(100, 32)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCancel)

    $dlg.AcceptButton = $btnCreate
    $dlg.CancelButton = $btnCancel

    $updateAccessState = {
        $requiresAssignedAccess = ([string]$cbRoleNew.SelectedItem -ne "Admin")
        $clbInstancesNew.Enabled = $requiresAssignedAccess
        $lblInstances.Enabled = $requiresAssignedAccess

        if (-not $requiresAssignedAccess) {
            for ($i = 0; $i -lt $clbInstancesNew.Items.Count; $i++) {
                $clbInstancesNew.SetItemChecked($i, $false)
            }
        }
    }

    $cbRoleNew.Add_SelectedIndexChanged($updateAccessState)
    & $updateAccessState

    $btnCreate.Add_Click({
        $userName = $txtUserNameNew.Text.Trim()
        $displayName = $txtDisplayNameNew.Text.Trim()
        $password = $txtPasswordNew.Text
        $roleName = [string]$cbRoleNew.SelectedItem
        $isActive = [bool]$chkIsActiveNew.Checked

        if ([string]::IsNullOrWhiteSpace($userName)) {
            [System.Windows.Forms.MessageBox]::Show(
                "User Name is required.",
                "Validation",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            $txtUserNameNew.Focus()
            return
        }

        if ([string]::IsNullOrWhiteSpace($displayName)) {
            [System.Windows.Forms.MessageBox]::Show(
                "Display Name is required.",
                "Validation",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            $txtDisplayNameNew.Focus()
            return
        }

        if ([string]::IsNullOrWhiteSpace($password)) {
            [System.Windows.Forms.MessageBox]::Show(
                "Password is required for a new user.",
                "Validation",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            $txtPasswordNew.Focus()
            return
        }

        $instanceIds = @()
        foreach ($item in $clbInstancesNew.CheckedItems) {
            $instanceIds += [int]$item.InstanceID
        }

        if ($roleName -ne "Admin" -and $instanceIds.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "Please assign at least one server for ViewOnly or Limited users.",
                "Validation",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
            return
        }

        try {
            Save-DashboardUser `
                -UserID 0 `
                -UserName $userName `
                -DisplayName $displayName `
                -RoleName $roleName `
                -IsActive $isActive `
                -Password $password `
                -InstanceIDs $instanceIds

            Refresh-DashboardUsers
            Clear-DashboardUserForm

            $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $dlg.Close()

            [System.Windows.Forms.MessageBox]::Show(
                "New dashboard user created successfully.",
                "User Created",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(
                "Failed to create dashboard user.`r`n`r`n$($_.Exception.Message)",
                "Create User Failed",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    })

    if ($OwnerForm) {
        [void]$dlg.ShowDialog($OwnerForm)
    }
    else {
        [void]$dlg.ShowDialog()
    }
}

function Load-SelectedDashboardUser {
    if ($script:dgvUsers.SelectedRows.Count -eq 0) {
        return
    }

    $row = $script:dgvUsers.SelectedRows[0]
    $userId = [int]$row.Cells["UserID"].Value
    $script:lblSelectedUserId.Text = "Selected UserID: $userId"
    $script:txtUserName.Text = [string]$row.Cells["UserName"].Value
    $script:txtUserDisplayName.Text = [string]$row.Cells["DisplayName"].Value
    $script:cbUserRole.SelectedItem = [string]$row.Cells["RoleName"].Value
    $script:chkUserActive.Checked = [bool]$row.Cells["IsActive"].Value
    $script:txtUserPassword.Text = ""
    Populate-UserInstanceChecklist -CheckedInstanceIDs @(Get-DashboardUserAccessIds -UserID $userId)
}

function Get-CheckedUserInstanceIds {
    $ids = @()
    foreach ($item in $script:clbUserInstances.CheckedItems) {
        $ids += [int]$item.InstanceID
    }
    return $ids
}

function Save-SelectedDashboardUser {
    if (-not (Require-AdminAccess -ActionName "Save user")) { return }

    try {
        $userId = 0
        if ($script:lblSelectedUserId.Text -match '(\d+)') {
            $userId = [int]$Matches[1]
        }

        [void](Save-DashboardUser `
            -UserID $userId `
            -UserName $script:txtUserName.Text `
            -DisplayName $script:txtUserDisplayName.Text `
            -RoleName ([string]$script:cbUserRole.SelectedItem) `
            -IsActive $script:chkUserActive.Checked `
            -Password $script:txtUserPassword.Text `
            -InstanceIDs @(Get-CheckedUserInstanceIds))

        Refresh-DashboardUsers
        [System.Windows.Forms.MessageBox]::Show(
            "Dashboard user saved successfully.",
            "User Saved",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to save dashboard user: $($_.Exception.Message)",
            "User Save Failed",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Delete-SelectedDashboardUser {
    if (-not (Require-AdminAccess -ActionName "Delete user")) { return }
    if ($script:dgvUsers.SelectedRows.Count -eq 0) { return }

    $userId = [int]$script:dgvUsers.SelectedRows[0].Cells["UserID"].Value
    $userName = [string]$script:dgvUsers.SelectedRows[0].Cells["UserName"].Value
    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Delete dashboard user '$userName'?",
        "Confirm Delete",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return }

    try {
        Remove-DashboardUser -UserID $userId
        Refresh-DashboardUsers
        Clear-DashboardUserForm
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to delete dashboard user: $($_.Exception.Message)",
            "User Delete Failed",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Populate-UserInstanceChecklist {
    param([int[]]$CheckedInstanceIDs = @())

    $script:clbUserInstances.Items.Clear()
    $query = @"
SELECT InstanceID, DisplayName
FROM mon.MonitoredInstances
WHERE IsActive = 1
ORDER BY DisplayName;
"@
    $dt = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query

    foreach ($row in $dt.Rows) {
        $item = [pscustomobject]@{
            InstanceID = [int]$row["InstanceID"]
            DisplayName = [string]$row["DisplayName"]
        }
        $index = $script:clbUserInstances.Items.Add($item)
        if ($CheckedInstanceIDs -contains $item.InstanceID) {
            $script:clbUserInstances.SetItemChecked($index, $true)
        }
    }
    $script:clbUserInstances.DisplayMember = "DisplayName"
}

function Show-ServerOverviewDialog {
    $overviewForm = New-Object System.Windows.Forms.Form
    $overviewForm.Text = "SQL Monitor - Server Overview & Management"
    $overviewForm.Size = New-Object System.Drawing.Size(1200, 800)
    $overviewForm.StartPosition = "CenterScreen"
    $overviewForm.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $overviewForm.Icon = [System.Drawing.SystemIcons]::Network

    # Create tooltip for the form
    $overviewToolTip = New-Object System.Windows.Forms.ToolTip
    $overviewToolTip.AutoPopDelay = 5000
    $overviewToolTip.InitialDelay = 1000
    $overviewToolTip.ReshowDelay = 500

    # Header
    $lblHeader = New-Object System.Windows.Forms.Label
    $lblHeader.Text = "SQL Monitor - Server Overview & Management"
    $lblHeader.Font = New-Object System.Drawing.Font("Segoe UI", 20, [System.Drawing.FontStyle]::Bold)
    $lblHeader.AutoSize = $true
    $lblHeader.Location = New-Object System.Drawing.Point(30, 20)
    $lblHeader.ForeColor = [System.Drawing.Color]::FromArgb(0, 95, 184)
    $overviewForm.Controls.Add($lblHeader)

    # Create tab control
    $overviewTabs = New-Object System.Windows.Forms.TabControl
    $overviewTabs.Location = New-Object System.Drawing.Point(20, 70)
    $overviewTabs.Size = New-Object System.Drawing.Size(1140, 650)
    $overviewTabs.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right -bor [System.Windows.Forms.AnchorStyles]::Bottom
    $overviewForm.Controls.Add($overviewTabs)

    # Overview Tab
    $tabOverview = New-Object System.Windows.Forms.TabPage
    $tabOverview.Text = "Server Overview"
    $tabOverview.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $overviewTabs.Controls.Add($tabOverview)

    # Users Tab
    $tabUsers = New-Object System.Windows.Forms.TabPage
    $tabUsers.Text = "User Management"
    $tabUsers.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $overviewTabs.Controls.Add($tabUsers)

    # Instances Tab
    $tabInstances = New-Object System.Windows.Forms.TabPage
    $tabInstances.Text = "Instance Management"
    $tabInstances.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $overviewTabs.Controls.Add($tabInstances)

    # Tickets Tab
    $tabTickets = New-Object System.Windows.Forms.TabPage
    $tabTickets.Text = "Ticket System"
    $tabTickets.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $overviewTabs.Controls.Add($tabTickets)

    # Tickets Tab Content
    $lblTicketList = New-Object System.Windows.Forms.Label
    $lblTicketList.Location = New-Object System.Drawing.Point(10, 10)
    $lblTicketList.Size = New-Object System.Drawing.Size(100, 20)
    $lblTicketList.Text = "Tickets:"
    $tabTickets.Controls.Add($lblTicketList)

    $script:dgvTickets = New-Object System.Windows.Forms.DataGridView
    $script:dgvTickets.Location = New-Object System.Drawing.Point(10, 35)
    $script:dgvTickets.Size = New-Object System.Drawing.Size(1100, 250)
    $script:dgvTickets.ReadOnly = $true
    $script:dgvTickets.AllowUserToAddRows = $false
    $script:dgvTickets.AllowUserToDeleteRows = $false
    $script:dgvTickets.SelectionMode = "FullRowSelect"
    $script:dgvTickets.MultiSelect = $false
    $tabTickets.Controls.Add($script:dgvTickets)

    $btnLoadTickets = New-Object System.Windows.Forms.Button
    $btnLoadTickets.Location = New-Object System.Drawing.Point(10, 300)
    $btnLoadTickets.Size = New-Object System.Drawing.Size(100, 30)
    $btnLoadTickets.Text = "Load Tickets"
    $tabTickets.Controls.Add($btnLoadTickets)

    # Tasks Tab
    $tabTasks = New-Object System.Windows.Forms.TabPage
    $tabTasks.Text = "Task Management"
    $tabTasks.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $overviewTabs.Controls.Add($tabTasks)

    # Tasks Tab Content
    $lblTaskList = New-Object System.Windows.Forms.Label
    $lblTaskList.Location = New-Object System.Drawing.Point(10, 10)
    $lblTaskList.Size = New-Object System.Drawing.Size(100, 20)
    $lblTaskList.Text = "Tasks:"
    $tabTasks.Controls.Add($lblTaskList)

    $script:dgvTasks = New-Object System.Windows.Forms.DataGridView
    $script:dgvTasks.Location = New-Object System.Drawing.Point(10, 35)
    $script:dgvTasks.Size = New-Object System.Drawing.Size(1100, 250)
    $script:dgvTasks.ReadOnly = $true
    $script:dgvTasks.AllowUserToAddRows = $false
    $script:dgvTasks.AllowUserToDeleteRows = $false
    $script:dgvTasks.SelectionMode = "FullRowSelect"
    $script:dgvTasks.MultiSelect = $false
    $tabTasks.Controls.Add($script:dgvTasks)

    $btnLoadTasks = New-Object System.Windows.Forms.Button
    $btnLoadTasks.Location = New-Object System.Drawing.Point(10, 300)
    $btnLoadTasks.Size = New-Object System.Drawing.Size(100, 30)
    $btnLoadTasks.Text = "Load Tasks"
    $tabTasks.Controls.Add($btnLoadTasks)

    # Escalation Tab
    $tabEscalation = New-Object System.Windows.Forms.TabPage
    $tabEscalation.Text = "Escalation Matrix"
    $tabEscalation.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $overviewTabs.Controls.Add($tabEscalation)

    # Escalation Tab Content
    $lblEscalationRules = New-Object System.Windows.Forms.Label
    $lblEscalationRules.Location = New-Object System.Drawing.Point(10, 10)
    $lblEscalationRules.Size = New-Object System.Drawing.Size(120, 20)
    $lblEscalationRules.Text = "Escalation Rules:"
    $tabEscalation.Controls.Add($lblEscalationRules)

    $script:dgvEscalationRules = New-Object System.Windows.Forms.DataGridView
    $script:dgvEscalationRules.Location = New-Object System.Drawing.Point(10, 35)
    $script:dgvEscalationRules.Size = New-Object System.Drawing.Size(1100, 250)
    $script:dgvEscalationRules.ReadOnly = $true
    $script:dgvEscalationRules.AllowUserToAddRows = $false
    $script:dgvEscalationRules.AllowUserToDeleteRows = $false
    $script:dgvEscalationRules.SelectionMode = "FullRowSelect"
    $script:dgvEscalationRules.MultiSelect = $false
    $tabEscalation.Controls.Add($script:dgvEscalationRules)

    $btnLoadEscRules = New-Object System.Windows.Forms.Button
    $btnLoadEscRules.Location = New-Object System.Drawing.Point(10, 300)
    $btnLoadEscRules.Size = New-Object System.Drawing.Size(120, 30)
    $btnLoadEscRules.Text = "Load Rules"
    $tabEscalation.Controls.Add($btnLoadEscRules)

    # ------------------------------------------------------------

    # ------------------------------------------------------------

    # Overview Tab Content
    $lblSubtitle = New-Object System.Windows.Forms.Label
    $lblSubtitle.Text = "Click on any server to view detailed monitoring dashboard"
    $lblSubtitle.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $lblSubtitle.AutoSize = $true
    $lblSubtitle.Location = New-Object System.Drawing.Point(10, 10)
    $lblSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(92, 104, 121)
    $tabOverview.Controls.Add($lblSubtitle)

    # Legend
    $panelLegend = New-Object System.Windows.Forms.Panel
    $panelLegend.BackColor = [System.Drawing.Color]::White
    $panelLegend.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $panelLegend.Location = New-Object System.Drawing.Point(10, 35)
    $panelLegend.Size = New-Object System.Drawing.Size(1100, 50)
    $tabOverview.Controls.Add($panelLegend)

    $lblLegend = New-Object System.Windows.Forms.Label
    $lblLegend.Text = "Status Legend:"
    $lblLegend.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $lblLegend.AutoSize = $true
    $lblLegend.Location = New-Object System.Drawing.Point(20, 15)
    $panelLegend.Controls.Add($lblLegend)

    # Green status
    $panelGreen = New-Object System.Windows.Forms.Panel
    $panelGreen.BackColor = [System.Drawing.Color]::FromArgb(40, 167, 69)
    $panelGreen.Location = New-Object System.Drawing.Point(120, 15)
    $panelGreen.Size = New-Object System.Drawing.Size(20, 20)
    $panelLegend.Controls.Add($panelGreen)

    $lblGreen = New-Object System.Windows.Forms.Label
    $lblGreen.Text = "Healthy"
    $lblGreen.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $lblGreen.AutoSize = $true
    $lblGreen.Location = New-Object System.Drawing.Point(150, 17)
    $panelLegend.Controls.Add($lblGreen)

    # Orange status
    $panelOrange = New-Object System.Windows.Forms.Panel
    $panelOrange.BackColor = [System.Drawing.Color]::FromArgb(255, 193, 7)
    $panelOrange.Location = New-Object System.Drawing.Point(220, 15)
    $panelOrange.Size = New-Object System.Drawing.Size(20, 20)
    $panelLegend.Controls.Add($panelOrange)

    $lblOrange = New-Object System.Windows.Forms.Label
    $lblOrange.Text = "Warning"
    $lblOrange.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $lblOrange.AutoSize = $true
    $lblOrange.Location = New-Object System.Drawing.Point(250, 17)
    $panelLegend.Controls.Add($lblOrange)

    # Red status
    $panelRed = New-Object System.Windows.Forms.Panel
    $panelRed.BackColor = [System.Drawing.Color]::FromArgb(220, 53, 69)
    $panelRed.Location = New-Object System.Drawing.Point(320, 15)
    $panelRed.Size = New-Object System.Drawing.Size(20, 20)
    $panelLegend.Controls.Add($panelRed)

    $lblRed = New-Object System.Windows.Forms.Label
    $lblRed.Text = "Critical"
    $lblRed.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $lblRed.AutoSize = $true
    $lblRed.Location = New-Object System.Drawing.Point(350, 17)
    $panelLegend.Controls.Add($lblRed)

    # Server blocks container
    $panelServers = New-Object System.Windows.Forms.Panel
    $panelServers.BackColor = [System.Drawing.Color]::White
    $panelServers.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $panelServers.Location = New-Object System.Drawing.Point(10, 95)
    $panelServers.Size = New-Object System.Drawing.Size(1100, 480)
    $panelServers.AutoScroll = $true
    $tabOverview.Controls.Add($panelServers)

    # Load server data
    try {
        $serverData = Get-OverviewData
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Unable to load server overview data.`r`n`r`n$($_.Exception.Message)",
            "Overview Load Failed",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return $null
    }

    if ($null -eq $serverData -or $null -eq $serverData.Rows -or $serverData.Rows.Count -eq 0) {
        $emptyOverviewMessage = if (Test-CurrentUserRequiresAssignedInstanceAccess) {
            "No servers are assigned to your dashboard user. Ask an admin to add server access in User Management."
        }
        else {
            "No active server overview data is available."
        }

        [System.Windows.Forms.MessageBox]::Show(
            $emptyOverviewMessage,
            "Overview Data Missing",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return $null
    }

    $serverBlocks = @()
    $blockWidth = 180
    $blockHeight = 120
    $blocksPerRow = 4
    $margin = 15
    $startX = 20
    $startY = 20

    $row = 0
    $col = 0

    foreach ($server in $serverData.Rows) {
        $blockX = $startX + ($col * ($blockWidth + $margin))
        $blockY = $startY + ($row * ($blockHeight + $margin))

        # Create server block panel
        $serverBlock = New-Object System.Windows.Forms.Panel
        $serverBlock.Location = New-Object System.Drawing.Point($blockX, $blockY)
        $serverBlock.Size = New-Object System.Drawing.Size($blockWidth, $blockHeight)
        $serverBlock.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $serverBlock.Cursor = [System.Windows.Forms.Cursors]::Hand

        # Determine status color
        $statusColor = Get-ServerStatusColor -ServerData $server
        $serverBlock.BackColor = $statusColor

        # Server name label
        $lblServerName = New-Object System.Windows.Forms.Label
        $lblServerName.Text = $server.DisplayName
        $lblServerName.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
        $lblServerName.AutoSize = $true
        $lblServerName.Location = New-Object System.Drawing.Point(10, 10)
        $lblServerName.ForeColor = [System.Drawing.Color]::White
        $lblServerName.MaximumSize = New-Object System.Drawing.Size(160, 0)
        $serverBlock.Controls.Add($lblServerName)

        # CPU indicator
        $cpuValue = [decimal]$server.SqlCPUPercent
        $lblCPU = New-Object System.Windows.Forms.Label
        $lblCPU.Text = "CPU: $($cpuValue.ToString("F1"))%"
        $lblCPU.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblCPU.AutoSize = $true
        $lblCPU.Location = New-Object System.Drawing.Point(10, 35)
        $lblCPU.ForeColor = [System.Drawing.Color]::White
        $serverBlock.Controls.Add($lblCPU)

        # Memory indicator
        $memAvailable = [decimal]$server.AvailablePhysicalMB
        $lblMemory = New-Object System.Windows.Forms.Label
        $lblMemory.Text = "Mem: $($memAvailable.ToString("F0"))MB"
        $lblMemory.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblMemory.AutoSize = $true
        $lblMemory.Location = New-Object System.Drawing.Point(10, 55)
        $lblMemory.ForeColor = [System.Drawing.Color]::White
        $serverBlock.Controls.Add($lblMemory)

        # Alert count
        $alertCount = [int]$server.OpenAlertCount
        $criticalCount = [int]$server.CriticalAlertCount
        $lblAlerts = New-Object System.Windows.Forms.Label
        $lblAlerts.Text = "Alerts: $alertCount ($criticalCount crit)"
        $lblAlerts.Font = New-Object System.Drawing.Font("Segoe UI", 8)
        $lblAlerts.AutoSize = $true
        $lblAlerts.Location = New-Object System.Drawing.Point(10, 75)
        $lblAlerts.ForeColor = [System.Drawing.Color]::White
        $serverBlock.Controls.Add($lblAlerts)

        # Status indicator
        $statusText = Get-ServerStatusText -ServerData $server
        $lblStatus = New-Object System.Windows.Forms.Label
        $lblStatus.Text = $statusText
        $lblStatus.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
        $lblStatus.AutoSize = $true
        $lblStatus.Location = New-Object System.Drawing.Point(10, 95)
        $lblStatus.ForeColor = [System.Drawing.Color]::White
        $serverBlock.Controls.Add($lblStatus)

        # Tooltip with detailed info
        $tooltipText = Get-ServerTooltipText -ServerData $server
        $overviewToolTip.SetToolTip($serverBlock, $tooltipText)

        # Store server data in block tag
        $serverBlock.Tag = $server

        # Click handler
        $clickHandler = {
            param($sender, $eventArgs)
            $selectedServer = $sender.Tag
            $overviewForm.Tag = $selectedServer.InstanceID
            $overviewForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $overviewForm.Close()
        }

        $serverBlock.Add_Click($clickHandler)
        foreach ($ctrl in $serverBlock.Controls) {
            $ctrl.Cursor = [System.Windows.Forms.Cursors]::Hand
            $ctrl.Tag = $server
            $ctrl.Add_Click($clickHandler)
        }

        $panelServers.Controls.Add($serverBlock)
        $serverBlocks += $serverBlock

        $col++
        if ($col -ge $blocksPerRow) {
            $col = 0
            $row++
        }
    }

    # ------------------------------------------------------------

    # Users Tab Content
    $lblUsersHeader = New-Object System.Windows.Forms.Label
    $lblUsersHeader.Text = "Manage dashboard users and server access"
    $lblUsersHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
    $lblUsersHeader.AutoSize = $true
    $lblUsersHeader.Location = New-Object System.Drawing.Point(10, 10)
    $tabUsers.Controls.Add($lblUsersHeader)

    $lblUsersHelp = New-Object System.Windows.Forms.Label
    $lblUsersHelp.Text = "Roles: Admin can configure and view all servers; ViewOnly and Limited can view assigned servers only."
    $lblUsersHelp.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $lblUsersHelp.AutoSize = $true
    $lblUsersHelp.ForeColor = [System.Drawing.Color]::DimGray
    $lblUsersHelp.Location = New-Object System.Drawing.Point(10, 35)
    $tabUsers.Controls.Add($lblUsersHelp)

    $script:dgvUsers = New-Object System.Windows.Forms.DataGridView
    $script:dgvUsers.Location = New-Object System.Drawing.Point(10, 60)
    $script:dgvUsers.Size = New-Object System.Drawing.Size(1100, 120)
    $script:dgvUsers.ReadOnly = $true
    $script:dgvUsers.AllowUserToAddRows = $false
    $script:dgvUsers.AllowUserToDeleteRows = $false
    $script:dgvUsers.AutoSizeColumnsMode = "Fill"
    $script:dgvUsers.SelectionMode = "FullRowSelect"
    $script:dgvUsers.MultiSelect = $false
    $tabUsers.Controls.Add($script:dgvUsers)

    $lblUserName = New-Object System.Windows.Forms.Label
    $lblUserName.Text = "User Name:"
    $lblUserName.Location = New-Object System.Drawing.Point(10, 200)
    $lblUserName.AutoSize = $true
    $tabUsers.Controls.Add($lblUserName)

    $script:txtUserName = New-Object System.Windows.Forms.TextBox
    $script:txtUserName.Location = New-Object System.Drawing.Point(110, 196)
    $script:txtUserName.Size = New-Object System.Drawing.Size(150, 22)
    $tabUsers.Controls.Add($script:txtUserName)

    $lblUserDisplayName = New-Object System.Windows.Forms.Label
    $lblUserDisplayName.Text = "Display Name:"
    $lblUserDisplayName.Location = New-Object System.Drawing.Point(280, 200)
    $lblUserDisplayName.AutoSize = $true
    $tabUsers.Controls.Add($lblUserDisplayName)

    $script:txtUserDisplayName = New-Object System.Windows.Forms.TextBox
    $script:txtUserDisplayName.Location = New-Object System.Drawing.Point(380, 196)
    $script:txtUserDisplayName.Size = New-Object System.Drawing.Size(150, 22)
    $tabUsers.Controls.Add($script:txtUserDisplayName)

    $lblUserRole = New-Object System.Windows.Forms.Label
    $lblUserRole.Text = "Role:"
    $lblUserRole.Location = New-Object System.Drawing.Point(550, 200)
    $lblUserRole.AutoSize = $true
    $tabUsers.Controls.Add($lblUserRole)

    $script:cbUserRole = New-Object System.Windows.Forms.ComboBox
    $script:cbUserRole.Items.AddRange(@("Admin", "ViewOnly", "Limited"))
    $script:cbUserRole.DropDownStyle = "DropDownList"
    $script:cbUserRole.Location = New-Object System.Drawing.Point(590, 196)
    $script:cbUserRole.Size = New-Object System.Drawing.Size(100, 22)
    $script:cbUserRole.SelectedIndex = 1
    $tabUsers.Controls.Add($script:cbUserRole)

    $script:chkUserActive = New-Object System.Windows.Forms.CheckBox
    $script:chkUserActive.Text = "Active"
    $script:chkUserActive.Checked = $true
    $script:chkUserActive.Location = New-Object System.Drawing.Point(710, 198)
    $script:chkUserActive.AutoSize = $true
    $tabUsers.Controls.Add($script:chkUserActive)

    $lblUserPassword = New-Object System.Windows.Forms.Label
    $lblUserPassword.Text = "Password:"
    $lblUserPassword.Location = New-Object System.Drawing.Point(10, 230)
    $lblUserPassword.AutoSize = $true
    $tabUsers.Controls.Add($lblUserPassword)

    $script:txtUserPassword = New-Object System.Windows.Forms.TextBox
    $script:txtUserPassword.Location = New-Object System.Drawing.Point(110, 226)
    $script:txtUserPassword.Size = New-Object System.Drawing.Size(150, 22)
    $script:txtUserPassword.UseSystemPasswordChar = $true
    $tabUsers.Controls.Add($script:txtUserPassword)

    $lblPasswordHelp = New-Object System.Windows.Forms.Label
    $lblPasswordHelp.Text = "Leave blank when editing to keep existing password."
    $lblPasswordHelp.Location = New-Object System.Drawing.Point(280, 230)
    $lblPasswordHelp.AutoSize = $true
    $lblPasswordHelp.ForeColor = [System.Drawing.Color]::DimGray
    $lblPasswordHelp.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $tabUsers.Controls.Add($lblPasswordHelp)

    $lblUserServers = New-Object System.Windows.Forms.Label
    $lblUserServers.Text = "Server Access:"
    $lblUserServers.Location = New-Object System.Drawing.Point(10, 260)
    $lblUserServers.AutoSize = $true
    $tabUsers.Controls.Add($lblUserServers)

    $script:clbUserInstances = New-Object System.Windows.Forms.CheckedListBox
    $script:clbUserInstances.Location = New-Object System.Drawing.Point(10, 280)
    $script:clbUserInstances.Size = New-Object System.Drawing.Size(500, 150)
    $script:clbUserInstances.CheckOnClick = $true
    $tabUsers.Controls.Add($script:clbUserInstances)

    $script:btnNewUser = New-Object System.Windows.Forms.Button
    $script:btnNewUser.Text = "New User"
    $script:btnNewUser.Location = New-Object System.Drawing.Point(550, 285)
    $script:btnNewUser.Size = New-Object System.Drawing.Size(120, 32)
    $tabUsers.Controls.Add($script:btnNewUser)

    $script:btnSaveUser = New-Object System.Windows.Forms.Button
    $script:btnSaveUser.Text = "Save User"
    $script:btnSaveUser.Location = New-Object System.Drawing.Point(550, 320)
    $script:btnSaveUser.Size = New-Object System.Drawing.Size(120, 32)
    $tabUsers.Controls.Add($script:btnSaveUser)

    $script:btnDeleteUser = New-Object System.Windows.Forms.Button
    $script:btnDeleteUser.Text = "Delete User"
    $script:btnDeleteUser.Location = New-Object System.Drawing.Point(550, 355)
    $script:btnDeleteUser.Size = New-Object System.Drawing.Size(120, 32)
    $tabUsers.Controls.Add($script:btnDeleteUser)

    $script:btnReloadUsers = New-Object System.Windows.Forms.Button
    $script:btnReloadUsers.Text = "Reload"
    $script:btnReloadUsers.Location = New-Object System.Drawing.Point(550, 390)
    $script:btnReloadUsers.Size = New-Object System.Drawing.Size(120, 32)
    $tabUsers.Controls.Add($script:btnReloadUsers)

    $script:lblSelectedUserId = New-Object System.Windows.Forms.Label
    $script:lblSelectedUserId.Text = "Selected UserID: new"
    $script:lblSelectedUserId.Location = New-Object System.Drawing.Point(530, 425)
    $script:lblSelectedUserId.AutoSize = $true
    $script:lblSelectedUserId.ForeColor = [System.Drawing.Color]::DimGray
    $script:lblSelectedUserId.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $tabUsers.Controls.Add($script:lblSelectedUserId)

    # ------------------------------------------------------------

    # Instances Tab Content
    $lblInstancesHeader = New-Object System.Windows.Forms.Label
    $lblInstancesHeader.Text = "Manage monitored instances"
    $lblInstancesHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
    $lblInstancesHeader.AutoSize = $true
    $lblInstancesHeader.Location = New-Object System.Drawing.Point(10, 10)
    $tabInstances.Controls.Add($lblInstancesHeader)

    $script:dgvInstances = New-Object System.Windows.Forms.DataGridView
    $script:dgvInstances.Location = New-Object System.Drawing.Point(10, 40)
    $script:dgvInstances.Size = New-Object System.Drawing.Size(1100, 200)
    $script:dgvInstances.ReadOnly = $true
    $script:dgvInstances.AllowUserToAddRows = $false
    $script:dgvInstances.AllowUserToDeleteRows = $false
    $script:dgvInstances.AutoSizeColumnsMode = "Fill"
    $script:dgvInstances.SelectionMode = "FullRowSelect"
    $script:dgvInstances.RowHeadersVisible = $false
    $script:dgvInstances.ScrollBars = [System.Windows.Forms.ScrollBars]::Both
    $tabInstances.Controls.Add($script:dgvInstances)

    $lblDisplayName = New-Object System.Windows.Forms.Label
    $lblDisplayName.Text = "Display Name:"
    $lblDisplayName.Location = New-Object System.Drawing.Point(10, 260)
    $lblDisplayName.AutoSize = $true
    $lblDisplayName.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $tabInstances.Controls.Add($lblDisplayName)

    $script:txtDisplayName = New-Object System.Windows.Forms.TextBox
    $script:txtDisplayName.Location = New-Object System.Drawing.Point(130, 258)
    $script:txtDisplayName.Size = New-Object System.Drawing.Size(300, 28)
    $tabInstances.Controls.Add($script:txtDisplayName)

    $lblSqlInstance = New-Object System.Windows.Forms.Label
    $lblSqlInstance.Text = "SQL Instance:"
    $lblSqlInstance.Location = New-Object System.Drawing.Point(10, 300)
    $lblSqlInstance.AutoSize = $true
    $lblSqlInstance.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $tabInstances.Controls.Add($lblSqlInstance)

    $script:txtSqlInstance = New-Object System.Windows.Forms.TextBox
    $script:txtSqlInstance.Location = New-Object System.Drawing.Point(130, 298)
    $script:txtSqlInstance.Size = New-Object System.Drawing.Size(300, 28)
    $tabInstances.Controls.Add($script:txtSqlInstance)

    $lblRepositoryServer = New-Object System.Windows.Forms.Label
    $lblRepositoryServer.Text = "Repository Server:"
    $lblRepositoryServer.Location = New-Object System.Drawing.Point(10, 340)
    $lblRepositoryServer.AutoSize = $true
    $lblRepositoryServer.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $tabInstances.Controls.Add($lblRepositoryServer)

    $script:txtRepositoryServer = New-Object System.Windows.Forms.TextBox
    $script:txtRepositoryServer.Location = New-Object System.Drawing.Point(130, 338)
    $script:txtRepositoryServer.Size = New-Object System.Drawing.Size(300, 28)
    $script:txtRepositoryServer.Text = $RepositoryServer
    $tabInstances.Controls.Add($script:txtRepositoryServer)

    $lblRepositoryDatabase = New-Object System.Windows.Forms.Label
    $lblRepositoryDatabase.Text = "Repository DB:"
    $lblRepositoryDatabase.Location = New-Object System.Drawing.Point(10, 380)
    $lblRepositoryDatabase.AutoSize = $true
    $lblRepositoryDatabase.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $tabInstances.Controls.Add($lblRepositoryDatabase)

    $script:txtRepositoryDatabase = New-Object System.Windows.Forms.TextBox
    $script:txtRepositoryDatabase.Location = New-Object System.Drawing.Point(130, 378)
    $script:txtRepositoryDatabase.Size = New-Object System.Drawing.Size(300, 28)
    $script:txtRepositoryDatabase.Text = $RepositoryDatabase
    $tabInstances.Controls.Add($script:txtRepositoryDatabase)

    $lblEnvironment = New-Object System.Windows.Forms.Label
    $lblEnvironment.Text = "Environment:"
    $lblEnvironment.Location = New-Object System.Drawing.Point(10, 420)
    $lblEnvironment.AutoSize = $true
    $lblEnvironment.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $tabInstances.Controls.Add($lblEnvironment)

    $script:txtEnvironment = New-Object System.Windows.Forms.TextBox
    $script:txtEnvironment.Location = New-Object System.Drawing.Point(130, 418)
    $script:txtEnvironment.Size = New-Object System.Drawing.Size(150, 28)
    $script:txtEnvironment.Text = "Production"
    $tabInstances.Controls.Add($script:txtEnvironment)

    $script:chkInstanceActive = New-Object System.Windows.Forms.CheckBox
    $script:chkInstanceActive.Text = "Active"
    $script:chkInstanceActive.Location = New-Object System.Drawing.Point(300, 420)
    $script:chkInstanceActive.Size = New-Object System.Drawing.Size(100, 28)
    $script:chkInstanceActive.Checked = $true
    $tabInstances.Controls.Add($script:chkInstanceActive)

    $script:btnNewInstance = New-Object System.Windows.Forms.Button
    $script:btnNewInstance.Text = "New"
    $script:btnNewInstance.Location = New-Object System.Drawing.Point(500, 298)
    $script:btnNewInstance.Size = New-Object System.Drawing.Size(100, 32)
    $tabInstances.Controls.Add($script:btnNewInstance)

    $script:btnSaveInstance = New-Object System.Windows.Forms.Button
    $script:btnSaveInstance.Text = "Save"
    $script:btnSaveInstance.Location = New-Object System.Drawing.Point(610, 298)
    $script:btnSaveInstance.Size = New-Object System.Drawing.Size(100, 32)
    $tabInstances.Controls.Add($script:btnSaveInstance)

    $script:btnDeleteInstance = New-Object System.Windows.Forms.Button
    $script:btnDeleteInstance.Text = "Delete"
    $script:btnDeleteInstance.Location = New-Object System.Drawing.Point(720, 298)
    $script:btnDeleteInstance.Size = New-Object System.Drawing.Size(100, 32)
    $tabInstances.Controls.Add($script:btnDeleteInstance)

    $script:btnReloadInstances = New-Object System.Windows.Forms.Button
    $script:btnReloadInstances.Text = "Reload"
    $script:btnReloadInstances.Location = New-Object System.Drawing.Point(830, 298)
    $script:btnReloadInstances.Size = New-Object System.Drawing.Size(100, 32)
    $tabInstances.Controls.Add($script:btnReloadInstances)

    # Bulk Import Section
    $grpBulkImport = New-Object System.Windows.Forms.GroupBox
    $grpBulkImport.Text = "Bulk Import Instances"
    $grpBulkImport.Location = New-Object System.Drawing.Point(10, 460)
    $grpBulkImport.Size = New-Object System.Drawing.Size(1100, 120)
    $tabInstances.Controls.Add($grpBulkImport)

    $lblImportFile = New-Object System.Windows.Forms.Label
    $lblImportFile.Text = "File:"
    $lblImportFile.Location = New-Object System.Drawing.Point(20, 30)
    $lblImportFile.AutoSize = $true
    $lblImportFile.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $grpBulkImport.Controls.Add($lblImportFile)

    $script:txtImportFile = New-Object System.Windows.Forms.TextBox
    $script:txtImportFile.Location = New-Object System.Drawing.Point(60, 28)
    $script:txtImportFile.Size = New-Object System.Drawing.Size(700, 28)
    $script:txtImportFile.ReadOnly = $true
    $grpBulkImport.Controls.Add($script:txtImportFile)

    $script:btnBrowseFile = New-Object System.Windows.Forms.Button
    $script:btnBrowseFile.Text = "Browse..."
    $script:btnBrowseFile.Location = New-Object System.Drawing.Point(780, 26)
    $script:btnBrowseFile.Size = New-Object System.Drawing.Size(100, 32)
    $grpBulkImport.Controls.Add($script:btnBrowseFile)

    $lblFileFormat = New-Object System.Windows.Forms.Label
    $lblFileFormat.Text = "Format: CSV or TXT with columns 'Server Name', 'Environment'"
    $lblFileFormat.Location = New-Object System.Drawing.Point(20, 70)
    $lblFileFormat.AutoSize = $true
    $lblFileFormat.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $lblFileFormat.ForeColor = [System.Drawing.Color]::Gray
    $grpBulkImport.Controls.Add($lblFileFormat)

    $script:btnImportInstances = New-Object System.Windows.Forms.Button
    $script:btnImportInstances.Text = "Import Instances"
    $script:btnImportInstances.Location = New-Object System.Drawing.Point(900, 26)
    $script:btnImportInstances.Size = New-Object System.Drawing.Size(120, 32)
    $grpBulkImport.Controls.Add($script:btnImportInstances)

    $script:btnPreviewImport = New-Object System.Windows.Forms.Button
    $script:btnPreviewImport.Text = "Preview Import"
    $script:btnPreviewImport.Location = New-Object System.Drawing.Point(900, 66)
    $script:btnPreviewImport.Size = New-Object System.Drawing.Size(120, 32)
    $grpBulkImport.Controls.Add($script:btnPreviewImport)

    # Wire management button events
    $script:btnNewUser.Add_Click({ Start-NewDashboardUser -OwnerForm $overviewForm })
    $script:btnSaveUser.Add_Click({ Save-SelectedDashboardUser })
    $script:btnDeleteUser.Add_Click({ Delete-SelectedDashboardUser })
    $script:btnReloadUsers.Add_Click({ Refresh-DashboardUsers })
    $script:dgvUsers.Add_SelectionChanged({ Load-SelectedDashboardUser })

    $script:btnNewInstance.Add_Click({ Show-NewInstanceForm -OwnerForm $overviewForm })
    $script:btnSaveInstance.Add_Click({ Save-SelectedInstance })
    $script:btnDeleteInstance.Add_Click({ Delete-SelectedInstance })
    $script:btnReloadInstances.Add_Click({ Reload-InstanceConfigs })
    $script:dgvInstances.Add_SelectionChanged({ Load-SelectedInstance })
    $script:btnBrowseFile.Add_Click({ Browse-ImportFile })
    $script:btnPreviewImport.Add_Click({ Preview-ImportInstances })
    $script:btnImportInstances.Add_Click({ Import-InstancesFromFile })

    # Ticket System event handlers
    $btnLoadTickets.Add_Click({
        try {
            $tickets = Get-Ticket
            $script:dgvTickets.DataSource = $tickets
            $script:dgvTickets.Refresh()
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Error loading tickets: $_", "Error", "OK", "Error")
        }
    })

    # Task Management event handlers
    $btnLoadTasks.Add_Click({
        try {
            $tasks = Get-Task
            $script:dgvTasks.DataSource = $tasks
            $script:dgvTasks.Refresh()
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Error loading tasks: $_", "Error", "OK", "Error")
        }
    })

    # Escalation Matrix event handlers
    $btnLoadEscRules.Add_Click({
        try {
            $rules = Get-EscalationRule
            $script:dgvEscalationRules.DataSource = $rules
            $script:dgvEscalationRules.Refresh()
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Error loading escalation rules: $_", "Error", "OK", "Error")
        }
    })

    # Initialize management data
    Refresh-DashboardUsers
    Refresh-InstanceConfigs

    # Close button
    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = "Close"
    $btnClose.Location = New-Object System.Drawing.Point(790, 640)
    $btnClose.Size = New-Object System.Drawing.Size(90, 35)
    $btnClose.BackColor = [System.Drawing.Color]::FromArgb(108, 117, 125)
    $btnClose.ForeColor = [System.Drawing.Color]::White
    $btnClose.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btnClose.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $btnClose.Cursor = [System.Windows.Forms.Cursors]::Hand
    $overviewForm.Controls.Add($btnClose)
    $overviewToolTip.SetToolTip($btnClose, "Close the server overview and exit")

    # Management buttons
    $btnManageUsers = New-Object System.Windows.Forms.Button
    $btnManageUsers.Text = "Users"
    $btnManageUsers.Location = New-Object System.Drawing.Point(30, 640)
    $btnManageUsers.Size = New-Object System.Drawing.Size(90, 35)
    $btnManageUsers.BackColor = [System.Drawing.Color]::FromArgb(0, 123, 255)
    $btnManageUsers.ForeColor = [System.Drawing.Color]::White
    $btnManageUsers.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btnManageUsers.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $btnManageUsers.Cursor = [System.Windows.Forms.Cursors]::Hand
    $overviewForm.Controls.Add($btnManageUsers)
    $overviewToolTip.SetToolTip($btnManageUsers, "Manage dashboard users and access permissions")

    $btnManageInstances = New-Object System.Windows.Forms.Button
    $btnManageInstances.Text = "Instances"
    $btnManageInstances.Location = New-Object System.Drawing.Point(130, 640)
    $btnManageInstances.Size = New-Object System.Drawing.Size(90, 35)
    $btnManageInstances.BackColor = [System.Drawing.Color]::FromArgb(0, 123, 255)
    $btnManageInstances.ForeColor = [System.Drawing.Color]::White
    $btnManageInstances.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btnManageInstances.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $btnManageInstances.Cursor = [System.Windows.Forms.Cursors]::Hand
    $overviewForm.Controls.Add($btnManageInstances)
    $overviewToolTip.SetToolTip($btnManageInstances, "Add and manage monitored SQL Server instances")

    $btnClose.Add_Click({
        $overviewForm.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $overviewForm.Close()
    })

    $btnManageUsers.Add_Click({
        $overviewTabs.SelectedTab = $tabUsers
    })

    $btnManageInstances.Add_Click({
        $overviewTabs.SelectedTab = $tabInstances
    })

    $overviewForm.CancelButton = $btnClose

    $result = $overviewForm.ShowDialog()
    if ($result -eq [System.Windows.Forms.DialogResult]::OK -and $overviewForm.Tag) {
        return [int]$overviewForm.Tag
    }
    return $null
}

function Get-ServerStatusColor {
    param([System.Data.DataRow]$ServerData)

    $cpuPercent = [decimal]$ServerData.SqlCPUPercent
    $memAvailable = [decimal]$ServerData.AvailablePhysicalMB
    $criticalAlerts = [int]$ServerData.CriticalAlertCount
    $warningAlerts = [int]$ServerData.WarningAlertCount

    # Red: Critical alerts or severe issues
    if ($criticalAlerts -gt 0 -or $cpuPercent -gt 90 -or $memAvailable -lt 1024) {
        return [System.Drawing.Color]::FromArgb(220, 53, 69)
    }

    # Orange: Warning alerts or moderate issues
    if ($warningAlerts -gt 0 -or $cpuPercent -gt 70 -or $memAvailable -lt 2048) {
        return [System.Drawing.Color]::FromArgb(255, 193, 7)
    }

    # Green: Healthy
    return [System.Drawing.Color]::FromArgb(40, 167, 69)
}

function Get-ServerStatusText {
    param([System.Data.DataRow]$ServerData)

    $cpuPercent = [decimal]$ServerData.SqlCPUPercent
    $memAvailable = [decimal]$ServerData.AvailablePhysicalMB
    $criticalAlerts = [int]$ServerData.CriticalAlertCount
    $warningAlerts = [int]$ServerData.WarningAlertCount

    if ($criticalAlerts -gt 0) {
        return "CRITICAL"
    }
    elseif ($warningAlerts -gt 0 -or $cpuPercent -gt 70 -or $memAvailable -lt 2048) {
        return "WARNING"
    }
    else {
        return "HEALTHY"
    }
}

function Get-ServerTooltipText {
    param([System.Data.DataRow]$ServerData)

    $serverName = $ServerData.DisplayName
    $cpuPercent = [decimal]$ServerData.SqlCPUPercent
    $memTotal = [decimal]$ServerData.TotalPhysicalMB
    $memAvailable = [decimal]$ServerData.AvailablePhysicalMB
    $memUsed = [decimal]$ServerData.SqlMemoryUsedGB
    $pleSeconds = [decimal]$ServerData.PLESeconds
    $bufferHitRatio = [decimal]$ServerData.BufferCacheHitRatio
    $openAlerts = [int]$ServerData.OpenAlertCount
    $criticalAlerts = [int]$ServerData.CriticalAlertCount
    $warningAlerts = [int]$ServerData.WarningAlertCount

    $tooltip = @"
$serverName

CPU Usage: $cpuPercent%
Memory: $([math]::Round($memAvailable/1024, 1))GB available of $([math]::Round($memTotal/1024, 1))GB total
SQL Memory Used: ${memUsed}GB
Page Life Expectancy: ${pleSeconds}s
Buffer Cache Hit Ratio: $([math]::Round($bufferHitRatio, 1))%

Alerts: $openAlerts open ($criticalAlerts critical, $warningAlerts warning)

Click to view detailed dashboard
"@

    return $tooltip.Trim()
}

function Get-PasswordHashBytes {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Password,
        [Parameter(Mandatory = $true)]
        [byte[]]$Salt
    )

    $passwordBytes = [System.Text.Encoding]::Unicode.GetBytes($Password)
    $combined = New-Object byte[] ($Salt.Length + $passwordBytes.Length)
    [System.Buffer]::BlockCopy($Salt, 0, $combined, 0, $Salt.Length)
    [System.Buffer]::BlockCopy($passwordBytes, 0, $combined, $Salt.Length, $passwordBytes.Length)

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ,$sha.ComputeHash($combined)
    }
    finally {
        $sha.Dispose()
    }
}

function Test-ByteArrayEqual {
    param(
        [byte[]]$Left,
        [byte[]]$Right
    )

    if ($null -eq $Left -or $null -eq $Right -or $Left.Length -ne $Right.Length) {
        return $false
    }

    $diff = 0
    for ($i = 0; $i -lt $Left.Length; $i++) {
        $diff = $diff -bor ($Left[$i] -bxor $Right[$i])
    }
    return ($diff -eq 0)
}

function Invoke-DashboardSecuritySchemaEnsure {
    $query = @"
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');

IF OBJECT_ID('mon.DashboardUsers', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUsers (
        UserID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardUsers PRIMARY KEY,
        UserName NVARCHAR(128) NOT NULL,
        DisplayName NVARCHAR(200) NULL,
        PasswordSalt VARBINARY(16) NOT NULL,
        PasswordHash VARBINARY(32) NOT NULL,
        RoleName NVARCHAR(20) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_DashboardUsers_IsActive DEFAULT (1),
        MustChangePassword BIT NOT NULL CONSTRAINT DF_DashboardUsers_MustChangePassword DEFAULT (0),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUsers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastLoginAt DATETIME2(0) NULL,
        CONSTRAINT UQ_DashboardUsers_UserName UNIQUE (UserName),
        CONSTRAINT CK_DashboardUsers_RoleName CHECK (RoleName IN ('Admin', 'ViewOnly', 'Limited'))
    );
END;

IF OBJECT_ID('mon.DashboardUserInstanceAccess', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUserInstanceAccess (
        UserID INT NOT NULL,
        InstanceID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUserInstanceAccess_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardUserInstanceAccess PRIMARY KEY (UserID, InstanceID),
        CONSTRAINT FK_DashboardUserInstanceAccess_Users FOREIGN KEY (UserID) REFERENCES mon.DashboardUsers(UserID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardUserInstanceAccess_Instances FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.DashboardAuditLog', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardAuditLog (
        AuditID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardAuditLog PRIMARY KEY,
        UserID INT NULL,
        UserName NVARCHAR(128) NULL,
        ActionName NVARCHAR(100) NOT NULL,
        Details NVARCHAR(1000) NULL,
        ClientHost NVARCHAR(128) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardAuditLog_CreatedAt DEFAULT (SYSDATETIME())
    );
END;

IF NOT EXISTS (SELECT 1 FROM mon.DashboardUsers)
BEGIN
    DECLARE @Salt VARBINARY(16) = 0x53514C4D4F4E41444D494E30303031;
    DECLARE @Password NVARCHAR(128) = N'Admin@123';

    INSERT INTO mon.DashboardUsers
        (UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword)
    VALUES
        (N'admin', N'Dashboard Administrator', @Salt, HASHBYTES('SHA2_256', @Salt + CONVERT(VARBINARY(MAX), @Password)), N'Admin', 1, 1);
END;
"@

    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Write-DashboardAudit {
    param(
        [string]$ActionName,
        [string]$Details = $null
    )

    try {
        $userId = if ($script:CurrentUser) { $script:CurrentUser.UserID } else { $null }
        $userName = if ($script:CurrentUser) { $script:CurrentUser.UserName } else { $env:USERNAME }
        Invoke-MonitorSqlNonQuery `
            -ServerInstance $RepositoryServer `
            -Database $RepositoryDatabase `
            -Query "INSERT INTO mon.DashboardAuditLog (UserID, UserName, ActionName, Details, ClientHost) VALUES (@UserID, @UserName, @ActionName, @Details, @ClientHost);" `
            -Parameters @{
                UserID = $userId
                UserName = $userName
                ActionName = $ActionName
                Details = $Details
                ClientHost = $env:COMPUTERNAME
            }
    }
    catch {
        Write-MonitorLog "Dashboard audit write failed: $($_.Exception.Message)" -Level 'Warning'
    }
}

function Test-AdminAccess {
    return ($script:CurrentUser -and $script:CurrentUser.RoleName -eq 'Admin')
}

function Test-ReadOnlyAccess {
    return (-not (Test-AdminAccess))
}

function Get-AccessDeniedMessage {
    return "Your dashboard role is '$($script:CurrentUser.RoleName)'. This action requires Admin access."
}

function Require-AdminAccess {
    param([string]$ActionName = "This action")

    if (Test-AdminAccess) { return $true }

    [System.Windows.Forms.MessageBox]::Show(
        "$(Get-AccessDeniedMessage)`r`n`r`n$ActionName was not run.",
        "Admin Access Required",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    return $false
}

function Test-RoleRequiresAssignedInstanceAccess {
    param([string]$RoleName)

    return ($RoleName -in @('ViewOnly', 'Limited'))
}

function Test-CurrentUserRequiresAssignedInstanceAccess {
    return ($script:CurrentUser -and (Test-RoleRequiresAssignedInstanceAccess -RoleName $script:CurrentUser.RoleName))
}

function Get-InstanceAccessJoinClause {
    param([string]$InstanceAlias = "i")

    if (Test-CurrentUserRequiresAssignedInstanceAccess) {
        return "INNER JOIN mon.DashboardUserInstanceAccess dua ON dua.InstanceID = $InstanceAlias.InstanceID AND dua.UserID = $($script:CurrentUser.UserID)"
    }
    return ""
}

function Test-CurrentUserInstanceAccess {
    param([int]$InstanceID)

    if (-not $script:CurrentUser) { return $false }
    if (-not (Test-CurrentUserRequiresAssignedInstanceAccess)) { return $true }
    return ($script:CurrentUser.AllowedInstanceIDs -contains $InstanceID)
}

function Get-DashboardUsers {
    $query = @"
SELECT
    UserID,
    UserName,
    DisplayName,
    RoleName,
    IsActive,
    MustChangePassword,
    LastLoginAt,
    CreatedAt
FROM mon.DashboardUsers
ORDER BY UserName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-DashboardUserAccessIds {
    param([int]$UserID)

    $rows = Invoke-MonitorSqlQuery `
        -ServerInstance $RepositoryServer `
        -Database $RepositoryDatabase `
        -Query "SELECT InstanceID FROM mon.DashboardUserInstanceAccess WHERE UserID = @UserID;" `
        -Parameters @{ UserID = $UserID }

    $ids = @()
    foreach ($row in $rows.Rows) {
        $ids += [int]$row["InstanceID"]
    }
    return $ids
}

function Get-CurrentUserAccessIds {
    if (-not (Test-CurrentUserRequiresAssignedInstanceAccess)) {
        return @()
    }
    return @(Get-DashboardUserAccessIds -UserID $script:CurrentUser.UserID)
}

function Get-AccessFilteredInstanceConfigs {
    param([object[]]$Instances)

    if (-not (Test-CurrentUserRequiresAssignedInstanceAccess)) {
        return @($Instances)
    }

    $allowedNames = @{}
    if ($global:OverviewCache -and $global:OverviewCache.Rows) {
        foreach ($row in $global:OverviewCache.Rows) {
            $allowedNames[[string]$row["DisplayName"]] = $true
        }
    }
    else {
        $overviewRows = Get-OverviewData
        foreach ($row in $overviewRows.Rows) {
            $allowedNames[[string]$row["DisplayName"]] = $true
        }
    }

    return @($Instances | Where-Object { $allowedNames.ContainsKey([string]$_.DisplayName) })
}

function Set-DashboardUserPassword {
    param(
        [int]$UserID,
        [string]$Password,
        [bool]$MustChangePassword = $false
    )

    if ([string]::IsNullOrWhiteSpace($Password) -or $Password.Length -lt 8) {
        throw "Password must be at least 8 characters."
    }

    $salt = New-PasswordSalt
    $hash = Get-PasswordHashBytes -Password $Password -Salt $salt
    $saltHex = ConvertTo-HexString -Bytes $salt
    $hashHex = ConvertTo-HexString -Bytes $hash
    $mustChange = if ($MustChangePassword) { 1 } else { 0 }

    $query = @"
UPDATE mon.DashboardUsers
SET PasswordSalt = $saltHex,
    PasswordHash = $hashHex,
    MustChangePassword = $mustChange,
    UpdatedAt = SYSDATETIME()
WHERE UserID = $UserID;
"@
    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Save-DashboardUserAccess {
    param(
        [int]$UserID,
        [int[]]$InstanceIDs
    )

    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query "DELETE FROM mon.DashboardUserInstanceAccess WHERE UserID = @UserID;" -Parameters @{ UserID = $UserID }

    foreach ($instanceId in @($InstanceIDs)) {
        Invoke-MonitorSqlNonQuery `
            -ServerInstance $RepositoryServer `
            -Database $RepositoryDatabase `
            -Query "INSERT INTO mon.DashboardUserInstanceAccess (UserID, InstanceID) VALUES (@UserID, @InstanceID);" `
            -Parameters @{ UserID = $UserID; InstanceID = $instanceId }
    }
}

function Save-DashboardUser {
    param(
        [int]$UserID,
        [string]$UserName,
        [string]$DisplayName,
        [string]$RoleName,
        [bool]$IsActive,
        [string]$Password,
        [int[]]$InstanceIDs
    )

    if ([string]::IsNullOrWhiteSpace($UserName)) {
        throw "User name is required."
    }
    if ($RoleName -notin @("Admin", "ViewOnly", "Limited")) {
        throw "Invalid role selected."
    }
    if ((Test-RoleRequiresAssignedInstanceAccess -RoleName $RoleName) -and @($InstanceIDs).Count -eq 0) {
        throw "ViewOnly and Limited users must be assigned at least one server."
    }

    $activeValue = if ($IsActive) { 1 } else { 0 }

    if ($UserID -le 0) {
        if ([string]::IsNullOrWhiteSpace($Password)) {
            throw "Password is required for new users."
        }

        $salt = New-PasswordSalt
        $hash = Get-PasswordHashBytes -Password $Password -Salt $salt
        $saltHex = ConvertTo-HexString -Bytes $salt
        $hashHex = ConvertTo-HexString -Bytes $hash

        $query = @"
INSERT INTO mon.DashboardUsers
    (UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword)
VALUES
    (@UserName, @DisplayName, $saltHex, $hashHex, @RoleName, $activeValue, 0);

SELECT CAST(SCOPE_IDENTITY() AS INT);
"@
        $newId = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters @{
            UserName = $UserName.Trim()
            DisplayName = $DisplayName.Trim()
            RoleName = $RoleName
        }
        $UserID = [int]$newId
    }
    else {
        Invoke-MonitorSqlNonQuery `
            -ServerInstance $RepositoryServer `
            -Database $RepositoryDatabase `
            -Query "UPDATE mon.DashboardUsers SET UserName = @UserName, DisplayName = @DisplayName, RoleName = @RoleName, IsActive = $activeValue, UpdatedAt = SYSDATETIME() WHERE UserID = @UserID;" `
            -Parameters @{
                UserID = $UserID
                UserName = $UserName.Trim()
                DisplayName = $DisplayName.Trim()
                RoleName = $RoleName
            }

        if (-not [string]::IsNullOrWhiteSpace($Password)) {
            Set-DashboardUserPassword -UserID $UserID -Password $Password
        }
    }

    Save-DashboardUserAccess -UserID $UserID -InstanceIDs @($InstanceIDs)
    Write-DashboardAudit -ActionName "SaveUser" -Details "UserName=$UserName; Role=$RoleName"
    return $UserID
}

function Remove-DashboardUser {
    param([int]$UserID)

    if ($script:CurrentUser -and $UserID -eq $script:CurrentUser.UserID) {
        throw "You cannot delete the account you are currently using."
    }

    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query "DELETE FROM mon.DashboardUsers WHERE UserID = @UserID;" -Parameters @{ UserID = $UserID }
    Write-DashboardAudit -ActionName "DeleteUser" -Details "UserID=$UserID"
}

function Authenticate-DashboardUser {
    param(
        [string]$UserName,
        [string]$Password
    )

    $dt = Invoke-MonitorSqlQuery `
        -ServerInstance $RepositoryServer `
        -Database $RepositoryDatabase `
        -Query "SELECT TOP 1 UserID, UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword FROM mon.DashboardUsers WHERE UserName = @UserName;" `
        -Parameters @{ UserName = $UserName.Trim() }

    if ($dt.Rows.Count -eq 0) {
        return $null
    }

    $row = $dt.Rows[0]
    if (-not [bool]$row["IsActive"]) {
        throw "This dashboard user is inactive."
    }

    $salt = [byte[]]$row["PasswordSalt"]
    $expectedHash = [byte[]]$row["PasswordHash"]
    $actualHash = Get-PasswordHashBytes -Password $Password -Salt $salt
    if (-not (Test-ByteArrayEqual -Left $expectedHash -Right $actualHash)) {
        return $null
    }

    $userId = [int]$row["UserID"]
    $allowedIds = @(Get-DashboardUserAccessIds -UserID $userId)

    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query "UPDATE mon.DashboardUsers SET LastLoginAt = SYSDATETIME() WHERE UserID = @UserID;" -Parameters @{ UserID = $userId }

    return [pscustomobject]@{
        UserID               = $userId
        UserName             = [string]$row["UserName"]
        DisplayName          = [string]$row["DisplayName"]
        RoleName             = [string]$row["RoleName"]
        MustChangePassword   = [bool]$row["MustChangePassword"]
        AllowedInstanceIDs   = $allowedIds
    }
}

function Show-DashboardLoginDialog {
    $loginForm = New-Object System.Windows.Forms.Form
    $loginForm.Text = "SQL Monitor Login"
    $loginForm.Size = New-Object System.Drawing.Size(480, 350)
    $loginForm.StartPosition = "CenterScreen"
    $loginForm.FormBorderStyle = "FixedDialog"
    $loginForm.MaximizeBox = $false
    $loginForm.MinimizeBox = $false
    $loginForm.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $loginForm.Icon = [System.Drawing.SystemIcons]::Shield

    # Create tooltip for the form
    $loginToolTip = New-Object System.Windows.Forms.ToolTip
    $loginToolTip.AutoPopDelay = 5000
    $loginToolTip.InitialDelay = 1000
    $loginToolTip.ReshowDelay = 500

    $panelBody = New-Object System.Windows.Forms.Panel
    $panelBody.BackColor = [System.Drawing.Color]::White
    $panelBody.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $panelBody.Location = New-Object System.Drawing.Point(20, 20)
    $panelBody.Size = New-Object System.Drawing.Size(440, 300)
    $loginForm.Controls.Add($panelBody)

    $panelAccent = New-Object System.Windows.Forms.Panel
    $panelAccent.BackColor = [System.Drawing.Color]::FromArgb(0, 95, 184)
    $panelAccent.Location = New-Object System.Drawing.Point(0, 0)
    $panelAccent.Size = New-Object System.Drawing.Size(440, 8)
    $panelBody.Controls.Add($panelAccent)

    $lblBoxHeader = New-Object System.Windows.Forms.Label
    $lblBoxHeader.Text = "SQL Monitor Login"
    $lblBoxHeader.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
    $lblBoxHeader.AutoSize = $true
    $lblBoxHeader.Location = New-Object System.Drawing.Point(24, 18)
    $panelBody.Controls.Add($lblBoxHeader)

    $lblBoxSubtitle = New-Object System.Windows.Forms.Label
    $lblBoxSubtitle.Text = "Secure access to your monitoring dashboard"
    $lblBoxSubtitle.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $lblBoxSubtitle.AutoSize = $true
    $lblBoxSubtitle.Location = New-Object System.Drawing.Point(24, 45)
    $lblBoxSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(92, 104, 121)
    $panelBody.Controls.Add($lblBoxSubtitle)

    $lblUser = New-Object System.Windows.Forms.Label
    $lblUser.Text = "Username"
    $lblUser.Location = New-Object System.Drawing.Point(24, 86)
    $lblUser.AutoSize = $true
    $lblUser.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $panelBody.Controls.Add($lblUser)
    $loginToolTip.SetToolTip($lblUser, "Enter your dashboard username (case-sensitive)")

    $txtLoginUser = New-Object System.Windows.Forms.TextBox
    $txtLoginUser.Location = New-Object System.Drawing.Point(24, 108)
    $txtLoginUser.Size = New-Object System.Drawing.Size(392, 28)
    $txtLoginUser.Text = "admin"
    $txtLoginUser.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $txtLoginUser.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $panelBody.Controls.Add($txtLoginUser)
    $loginToolTip.SetToolTip($txtLoginUser, "Enter your assigned dashboard username")

    $lblPassword = New-Object System.Windows.Forms.Label
    $lblPassword.Text = "Password"
    $lblPassword.Location = New-Object System.Drawing.Point(24, 148)
    $lblPassword.AutoSize = $true
    $lblPassword.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $panelBody.Controls.Add($lblPassword)
    $loginToolTip.SetToolTip($lblPassword, "Enter your dashboard password (case-sensitive)")

    $txtLoginPassword = New-Object System.Windows.Forms.TextBox
    $txtLoginPassword.Location = New-Object System.Drawing.Point(24, 170)
    $txtLoginPassword.Size = New-Object System.Drawing.Size(392, 28)
    $txtLoginPassword.UseSystemPasswordChar = $true
    $txtLoginPassword.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $txtLoginPassword.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $panelBody.Controls.Add($txtLoginPassword)
    $loginToolTip.SetToolTip($txtLoginPassword, "Enter your dashboard password")

    $lblLoginMessage = New-Object System.Windows.Forms.Label
    $lblLoginMessage.Text = "Sign in with your dashboard credentials. Change bootstrap passwords immediately after setup."
    $lblLoginMessage.ForeColor = [System.Drawing.Color]::FromArgb(92, 104, 121)
    $lblLoginMessage.Location = New-Object System.Drawing.Point(24, 210)
    $lblLoginMessage.Size = New-Object System.Drawing.Size(392, 35)
    $lblLoginMessage.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $panelBody.Controls.Add($lblLoginMessage)
    $loginToolTip.SetToolTip($lblLoginMessage, "Security note: Change default password immediately after first login")

    # Enhanced buttons
    $btnLogin = New-Object System.Windows.Forms.Button
    $btnLogin.Text = "Login"
    $btnLogin.Location = New-Object System.Drawing.Point(248, 255)
    $btnLogin.Size = New-Object System.Drawing.Size(95, 35)
    $btnLogin.BackColor = [System.Drawing.Color]::FromArgb(0, 95, 184)
    $btnLogin.ForeColor = [System.Drawing.Color]::White
    $btnLogin.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btnLogin.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $btnLogin.Cursor = [System.Windows.Forms.Cursors]::Hand
    $panelBody.Controls.Add($btnLogin)
    $loginToolTip.SetToolTip($btnLogin, "Authenticate and access the monitoring dashboard")

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"
    $btnCancel.Location = New-Object System.Drawing.Point(348, 255)
    $btnCancel.Size = New-Object System.Drawing.Size(70, 35)
    $btnCancel.BackColor = [System.Drawing.Color]::FromArgb(108, 117, 125)
    $btnCancel.ForeColor = [System.Drawing.Color]::White
    $btnCancel.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btnCancel.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $btnCancel.Cursor = [System.Windows.Forms.Cursors]::Hand
    $panelBody.Controls.Add($btnCancel)
    $loginToolTip.SetToolTip($btnCancel, "Exit without logging in")

    $loginForm.AcceptButton = $btnLogin
    $loginForm.CancelButton = $btnCancel

    $btnLogin.Add_Click({
        try {
            $user = Authenticate-DashboardUser -UserName $txtLoginUser.Text -Password $txtLoginPassword.Text
            if ($null -eq $user) {
                $lblLoginMessage.Text = "Invalid user name or password."
                $lblLoginMessage.ForeColor = [System.Drawing.Color]::Firebrick
                return
            }

            $script:CurrentUser = $user
            Write-DashboardAudit -ActionName "Login" -Details "Role=$($user.RoleName)"
            $loginForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $loginForm.Close()
        }
        catch {
            $lblLoginMessage.Text = $_.Exception.Message
            $lblLoginMessage.ForeColor = [System.Drawing.Color]::Firebrick
        }
    })

    $btnCancel.Add_Click({
        $script:LoginCancelled = $true
        $loginForm.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $loginForm.Close()
    })

    return $loginForm.ShowDialog()
}

function Show-PasswordChangeDialog {
    if (-not $script:CurrentUser -or -not $script:CurrentUser.MustChangePassword) {
        return [System.Windows.Forms.DialogResult]::OK
    }

    $changeForm = New-Object System.Windows.Forms.Form
    $changeForm.Text = "Change Dashboard Password"
    $changeForm.Size = New-Object System.Drawing.Size(500, 320)
    $changeForm.StartPosition = "CenterScreen"
    $changeForm.FormBorderStyle = "FixedDialog"
    $changeForm.MaximizeBox = $false
    $changeForm.MinimizeBox = $false
    $changeForm.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 251)
    $changeForm.Icon = [System.Drawing.SystemIcons]::Shield

    # Create tooltip for the form
    $changeToolTip = New-Object System.Windows.Forms.ToolTip
    $changeToolTip.AutoPopDelay = 5000
    $changeToolTip.InitialDelay = 1000
    $changeToolTip.ReshowDelay = 500

    $lblHeader = New-Object System.Windows.Forms.Label
    $lblHeader.Text = "Change Temporary Password"
    $lblHeader.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
    $lblHeader.AutoSize = $true
    $lblHeader.Location = New-Object System.Drawing.Point(30, 20)
    $lblHeader.ForeColor = [System.Drawing.Color]::FromArgb(0, 95, 184)
    $changeForm.Controls.Add($lblHeader)
    $changeToolTip.SetToolTip($lblHeader, "Security requirement: Change default password for account protection")

    $lblSubtitle = New-Object System.Windows.Forms.Label
    $lblSubtitle.Text = "Set a strong password for your dashboard account"
    $lblSubtitle.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $lblSubtitle.AutoSize = $true
    $lblSubtitle.Location = New-Object System.Drawing.Point(32, 50)
    $lblSubtitle.ForeColor = [System.Drawing.Color]::FromArgb(92, 104, 121)
    $changeForm.Controls.Add($lblSubtitle)

    # New password section
    $lblNewIcon = New-Object System.Windows.Forms.Label
    $lblNewIcon.Text = "[Lock]"
    $lblNewIcon.Font = New-Object System.Drawing.Font("Segoe UI", 12)
    $lblNewIcon.AutoSize = $true
    $lblNewIcon.Location = New-Object System.Drawing.Point(32, 85)
    $changeForm.Controls.Add($lblNewIcon)

    $lblNew = New-Object System.Windows.Forms.Label
    $lblNew.Text = "New Password"
    $lblNew.Location = New-Object System.Drawing.Point(70, 90)
    $lblNew.AutoSize = $true
    $lblNew.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $changeForm.Controls.Add($lblNew)
    $changeToolTip.SetToolTip($lblNew, "Enter a strong password (minimum 8 characters)")

    $txtNewPassword = New-Object System.Windows.Forms.TextBox
    $txtNewPassword.Location = New-Object System.Drawing.Point(70, 110)
    $txtNewPassword.Size = New-Object System.Drawing.Size(380, 28)
    $txtNewPassword.UseSystemPasswordChar = $true
    $txtNewPassword.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $txtNewPassword.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $changeForm.Controls.Add($txtNewPassword)
    $changeToolTip.SetToolTip($txtNewPassword, "Password must be at least 8 characters long")

    # Confirm password section
    $lblConfirmIcon = New-Object System.Windows.Forms.Label
    $lblConfirmIcon.Text = "[OK]"
    $lblConfirmIcon.Font = New-Object System.Drawing.Font("Segoe UI", 12)
    $lblConfirmIcon.AutoSize = $true
    $lblConfirmIcon.Location = New-Object System.Drawing.Point(32, 155)
    $changeForm.Controls.Add($lblConfirmIcon)

    $lblConfirm = New-Object System.Windows.Forms.Label
    $lblConfirm.Text = "Confirm Password"
    $lblConfirm.Location = New-Object System.Drawing.Point(70, 160)
    $lblConfirm.AutoSize = $true
    $lblConfirm.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $changeForm.Controls.Add($lblConfirm)
    $changeToolTip.SetToolTip($lblConfirm, "Re-enter the same password to confirm")

    $txtConfirmPassword = New-Object System.Windows.Forms.TextBox
    $txtConfirmPassword.Location = New-Object System.Drawing.Point(70, 180)
    $txtConfirmPassword.Size = New-Object System.Drawing.Size(380, 28)
    $txtConfirmPassword.UseSystemPasswordChar = $true
    $txtConfirmPassword.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $txtConfirmPassword.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $changeForm.Controls.Add($txtConfirmPassword)
    $changeToolTip.SetToolTip($txtConfirmPassword, "Must match the new password exactly")

    $lblChangeMessage = New-Object System.Windows.Forms.Label
    $lblChangeMessage.Text = "Security: Use at least 8 characters with mixed case, numbers, and symbols for security."
    $lblChangeMessage.Location = New-Object System.Drawing.Point(32, 220)
    $lblChangeMessage.Size = New-Object System.Drawing.Size(430, 35)
    $lblChangeMessage.ForeColor = [System.Drawing.Color]::FromArgb(92, 104, 121)
    $lblChangeMessage.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $changeForm.Controls.Add($lblChangeMessage)
    $changeToolTip.SetToolTip($lblChangeMessage, "Strong passwords protect against unauthorized access")

    # Enhanced buttons
    $btnSavePassword = New-Object System.Windows.Forms.Button
    $btnSavePassword.Text = "Save Password"
    $btnSavePassword.Location = New-Object System.Drawing.Point(280, 265)
    $btnSavePassword.Size = New-Object System.Drawing.Size(120, 35)
    $btnSavePassword.BackColor = [System.Drawing.Color]::FromArgb(0, 95, 184)
    $btnSavePassword.ForeColor = [System.Drawing.Color]::White
    $btnSavePassword.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btnSavePassword.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $btnSavePassword.Cursor = [System.Windows.Forms.Cursors]::Hand
    $changeForm.Controls.Add($btnSavePassword)
    $changeToolTip.SetToolTip($btnSavePassword, "Save the new password and continue to dashboard")

    $btnCancelPassword = New-Object System.Windows.Forms.Button
    $btnCancelPassword.Text = "Cancel"
    $btnCancelPassword.Location = New-Object System.Drawing.Point(410, 265)
    $btnCancelPassword.Size = New-Object System.Drawing.Size(80, 35)
    $btnCancelPassword.BackColor = [System.Drawing.Color]::FromArgb(108, 117, 125)
    $btnCancelPassword.ForeColor = [System.Drawing.Color]::White
    $btnCancelPassword.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $btnCancelPassword.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $btnCancelPassword.Cursor = [System.Windows.Forms.Cursors]::Hand
    $changeForm.Controls.Add($btnCancelPassword)
    $changeToolTip.SetToolTip($btnCancelPassword, "Exit without changing password (login will fail)")

    $changeForm.AcceptButton = $btnSavePassword
    $changeForm.CancelButton = $btnCancelPassword

    $btnSavePassword.Add_Click({
        try {
            if ($txtNewPassword.Text -ne $txtConfirmPassword.Text) {
                throw "Passwords do not match."
            }

            Set-DashboardUserPassword -UserID $script:CurrentUser.UserID -Password $txtNewPassword.Text -MustChangePassword $false
            $script:CurrentUser.MustChangePassword = $false
            Write-DashboardAudit -ActionName "ChangePassword" -Details "User changed temporary password"
            $changeForm.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $changeForm.Close()
        }
        catch {
            $lblChangeMessage.Text = $_.Exception.Message
            $lblChangeMessage.ForeColor = [System.Drawing.Color]::Firebrick
        }
    })

    $btnCancelPassword.Add_Click({
        $changeForm.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $changeForm.Close()
    })

    return $changeForm.ShowDialog()
}

try {
    Invoke-DashboardSecuritySchemaEnsure
}
catch {
    [System.Windows.Forms.MessageBox]::Show(
        "Unable to initialize dashboard security tables.`r`n`r`n$($_.Exception.Message)",
        "Security Initialization Failed",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}

if ((Show-DashboardLoginDialog) -ne [System.Windows.Forms.DialogResult]::OK) {
    exit 0
}

if ((Show-PasswordChangeDialog) -ne [System.Windows.Forms.DialogResult]::OK) {
    exit 0
}

# Show server overview screen
$selectedInstanceId = Show-ServerOverviewDialog
if ($null -eq $selectedInstanceId) {
    exit 0
}

# ------------------------------------------------------------
# Query helpers
# ------------------------------------------------------------
function Get-CPUTrendData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 60
    CaptureTime,
    SqlCPUPercent,
    OtherCPUPercent,
    IdleCPUPercent
FROM mon.CPUHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-MemoryTrendData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 60
    CaptureTime,
    TotalPhysicalMB,
    AvailablePhysicalMB,
    SqlMemoryUsedGB,
    PLESeconds,
    BufferCacheHitRatio
FROM mon.MemoryHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-OpenAlertsData {
    param(
        [int]$InstanceID,
        [bool]$CriticalOnly = $false
    )

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $severityClause = if ($CriticalOnly) { "AND Severity = 'Critical'" } else { "" }

    $query = @"
SELECT
    AlertID,
    DisplayName,
    AlertTime,
    AlertAgeMinutes,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails
FROM mon.vw_OpenAlertsDetailed
WHERE InstanceID = $InstanceID
$severityClause
ORDER BY AlertTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-CollectionHealthData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT 
    ModuleName,
    HealthStatus,
    LastCollectionTime,
    MinutesAgo,
    LastStatus,
    DurationSeconds,
    ErrorMessage
FROM mon.vw_CollectionHealth
WHERE InstanceID = $InstanceID
ORDER BY 
    CASE HealthStatus 
        WHEN 'Critical' THEN 1 
        WHEN 'Warning' THEN 2 
        WHEN 'Healthy' THEN 3 
        ELSE 4 
    END,
    MinutesAgo DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-CollectionGapsData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT 
    ModuleName,
    LastCollectionTime,
    MinutesAgo,
    LastStatus,
    IssueDescription,
    Severity,
    ErrorMessage
FROM mon.vw_CollectionGaps
WHERE InstanceID = $InstanceID
ORDER BY Severity DESC, MinutesAgo DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Acknowledge-Alert {
    param(
        [int64]$AlertID
    )

    $ackUser = if ($env:USERDOMAIN -and $env:USERNAME) {
        "$($env:USERDOMAIN)\$($env:USERNAME)"
    }
    elseif ($env:USERNAME) {
        $env:USERNAME
    }
    else {
        "UnknownUser"
    }

    $escapedUser = $ackUser.Replace("'", "''")

    $query = @"
EXEC mon.usp_AcknowledgeAlert
    @AlertID = $AlertID,
    @AcknowledgedBy = N'$escapedUser';
"@

    return Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}
function Get-KPIsData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 10
    CaptureTime,
    PageLifeExpectancy,
    BufferCacheHitRatio,
    VisibleOnlineCPUs,
    MaxDOP,
    CostThresholdForParallelism
FROM mon.KPIHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-DisksData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    VolumeMountPoint,
    LogicalVolumeName,
    TotalGB,
    FreeGB,
    UsedGB,
    UsedPct
FROM mon.DiskVolumeHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, VolumeMountPoint;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-ConfigData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 10
    CaptureTime,
    MaxDOPSetting,
    CostThresholdSetting,
    MinServerMemorySetting,
    MaxServerMemorySetting,
    ProcessorCount,
    PhysicalMemoryMB
FROM mon.ConfigHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-IOData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    DatabaseName,
    FileType,
    LogicalName,
    PhysicalName,
    SizeMB,
    AvgReadMS,
    AvgWriteMS,
    TotalStallMS
FROM mon.IOFileHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, AvgReadMS + AvgWriteMS DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-TempDBData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 10
    CaptureTime,
    FileType,
    LogicalName,
    SizeMB,
    UsedMB,
    PercentFull,
    TempDBDataFileCount,
    RecommendedFileCount
FROM mon.TempDBHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-BackupsData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    DatabaseName,
    LastFullHours,
    LastDiffHours,
    LastLogHours,
    StatusText
FROM mon.BackupStatusHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, DatabaseName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-DBOptionsData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    DatabaseName,
    State,
    RecoveryModel,
    PageVerify,
    IsAutoClose,
    IsAutoShrink,
    IsEncrypted,
    SizeMB,
    AvailableSpaceMB,
    LogSizeMB
FROM mon.DBOptionsHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, DatabaseName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-BlockingData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    SessionID,
    BlockingSessionID,
    DatabaseName,
    WaitType,
    WaitTimeMS,
    LoginName,
    HostName,
    CommandText,
    StatementText
FROM mon.BlockingHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, WaitTimeMS DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-LongRunningData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    SessionID,
    DatabaseName,
    StartTime,
    DurationMinutes,
    WaitType,
    CPUms,
    Reads,
    Writes,
    CommandText,
    StatementText
FROM mon.LongRunningHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, DurationMinutes DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-TopQueriesData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CollectionDateTime,
    QueryID,
    PlanID,
    CAST(SUBSTRING(QueryText, 1, 100) AS NVARCHAR(100)) as QueryText,
    AvgCpuTime,
    AvgDuration,
    AvgLogicalIOReads,
    AvgLogicalIOWrites,
    AvgPhysicalIOReads,
    CountExecutions,
    AvgRowCount
FROM dbo.TopQueries
WHERE InstanceID = $InstanceID
ORDER BY AvgCpuTime DESC, CollectionDateTime DESC
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-MissingIndexesData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CollectionDateTime,
    DatabaseName,
    ObjectName,
    EqualityColumns,
    InequalityColumns,
    IncludedColumns,
    UserSeeks,
    UserScans,
    UserLookups,
    UserUpdates,
    AvgTotalUserCost,
    AvgUserImpact,
    UniqueCompiles,
    ImprovementMeasure
FROM dbo.MissingIndexes
WHERE InstanceID = $InstanceID
ORDER BY ImprovementMeasure DESC, CollectionDateTime DESC
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-IndexFragmentationData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CollectionDateTime,
    DatabaseName,
    ObjectName,
    IndexName,
    IndexType,
    AvgFragmentationPercent,
    AvgPageSpaceUsedPercent,
    RecordCount,
    PageCount,
    AvgRecordSizeBytes
FROM dbo.IndexFragmentation
WHERE InstanceID = $InstanceID
ORDER BY AvgFragmentationPercent DESC, CollectionDateTime DESC
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-AGData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    AGName,
    PrimaryReplica,
    SyncHealthDesc,
    BackupPreferenceDesc,
    FailureConditionLevel,
    ClusterTypeDesc
FROM mon.AGOverviewHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, AGName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-ListenersData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 20
    CaptureTime,
    DNSName,
    IPAddress,
    Port,
    State,
    AGName
FROM mon.ListenerHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, DNSName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

# UNIQUE FEATURE: Get Execution Plans Data
function Get-ExecutionPlansData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    QueryText,
    PlanHandle,
    QueryPlan,
    EstimatedCost,
    EstimatedRows,
    EstimatedIO,
    EstimatedCPU,
    MissingIndexes,
    TableScans,
    OptimizationRecommendations
FROM mon.ExecutionPlansHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, EstimatedCost DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

# UNIQUE FEATURE: Get Memory Clerks Data
function Get-MemoryClerksData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    MemoryClerkType,
    MemoryUsedMB,
    MemoryAllocatedMB,
    MemoryPressure,
    ScalingRecommendation,
    ComponentDescription
FROM mon.MemoryClerksHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, MemoryUsedMB DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

# UNIQUE FEATURE: Get Buffer Pool Analysis Data
function Get-BufferPoolAnalysisData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    DatabaseName,
    PagesInBuffer,
    PagesDirty,
    DirtyPageRatio,
    AccessFrequency,
    BufferPoolRecommendation
FROM mon.BufferPoolAnalysisHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, PagesInBuffer DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-AgentJobsData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 100
    CaptureTime,
    JobName,
    Enabled,
    Category,
    LastRunTime,
    LastStatus,
    LastDurationSec,
    NextRunTime,
    SuccessPctRecent,
    LastFailureMessage
FROM mon.AgentJobHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC, LastRunTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-DeadlocksData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CaptureTime,
    DeadlockTime,
    DeadlockXml
FROM mon.DeadlockHistory
WHERE InstanceID = $InstanceID
ORDER BY CaptureTime DESC;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-WaitsData {
    param([int]$InstanceID)

    if ($InstanceID -le 0) { return New-Object System.Data.DataTable }

    $query = @"
SELECT TOP 50
    CollectionDateTime,
    WaitType,
    WaitingTasksCount,
    WaitTimeMs,
    MaxWaitTimeMs,
    SignalWaitTimeMs
FROM dbo.WaitStats
WHERE InstanceID = $InstanceID
ORDER BY WaitTimeMs DESC, CollectionDateTime DESC
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}
# ------------------------------------------------------------
# Helpers for dashboard colors
# ------------------------------------------------------------
function Get-HealthColor {
    param(
        [int]$CriticalCount,
        [int]$WarningCount
    )

    if ($CriticalCount -gt 0) {
        return [System.Drawing.Color]::FromArgb(220, 53, 69)
    }
    elseif ($WarningCount -gt 0) {
        return [System.Drawing.Color]::FromArgb(255, 193, 7)
    }
    else {
        return [System.Drawing.Color]::FromArgb(40, 167, 69)
    }
}

function Set-TileStyle {
    param(
        [System.Windows.Forms.Panel]$Panel,
        [System.Windows.Forms.Label]$Label,
        [string]$Value,
        [System.Drawing.Color]$BackColor
    )

    $Panel.BackColor = $BackColor
    $Label.Text = $Value
    $Label.ForeColor = [System.Drawing.Color]::White
}

function Set-StatusTileStyle {
    param(
        [System.Windows.Forms.Panel]$Panel,
        [System.Windows.Forms.Label]$Label,
        [string]$StatusText,
        [System.Drawing.Color]$BackColor
    )

    $Panel.BackColor = $BackColor
    $Label.Text = $StatusText
    $Label.ForeColor = [System.Drawing.Color]::White
}

function New-DashboardFont {
    param(
        [float]$Size,
        [System.Drawing.FontStyle]$Style = [System.Drawing.FontStyle]::Regular
    )

    return New-Object System.Drawing.Font("Segoe UI", $Size, $Style)
}

$script:DashboardTheme = @{
    Shell       = [System.Drawing.Color]::FromArgb(245, 247, 251)
    Surface     = [System.Drawing.Color]::White
    SurfaceAlt  = [System.Drawing.Color]::FromArgb(249, 250, 252)
    Border      = [System.Drawing.Color]::FromArgb(221, 226, 235)
    Text        = [System.Drawing.Color]::FromArgb(32, 42, 57)
    MutedText   = [System.Drawing.Color]::FromArgb(92, 104, 121)
    Accent      = [System.Drawing.Color]::FromArgb(0, 95, 184)
    AccentSoft  = [System.Drawing.Color]::FromArgb(229, 241, 255)
    Header      = [System.Drawing.Color]::FromArgb(22, 34, 52)
}

function Enable-ControlDoubleBuffer {
    param([System.Windows.Forms.Control]$Control)

    try {
        $property = $Control.GetType().GetProperty("DoubleBuffered", [System.Reflection.BindingFlags]"Instance, NonPublic")
        if ($null -ne $property) {
            $property.SetValue($Control, $true, $null)
        }
    }
    catch {
        # Double buffering is an optimization only; ignore unsupported controls.
    }
}

function Set-ModernButtonStyle {
    param([System.Windows.Forms.Button]$Button)

    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 0
    $Button.BackColor = $script:DashboardTheme.Accent
    $Button.ForeColor = [System.Drawing.Color]::White
    $Button.Font = New-DashboardFont -Size 9 -Style ([System.Drawing.FontStyle]::Bold)
    $Button.Cursor = [System.Windows.Forms.Cursors]::Hand
}

function Set-ModernGridStyle {
    param([System.Windows.Forms.DataGridView]$Grid)

    Enable-ControlDoubleBuffer -Control $Grid
    $Grid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $Grid.BackgroundColor = $script:DashboardTheme.Surface
    $Grid.GridColor = $script:DashboardTheme.Border
    $Grid.RowHeadersVisible = $false
    $Grid.EnableHeadersVisualStyles = $false
    $Grid.ColumnHeadersBorderStyle = [System.Windows.Forms.DataGridViewHeaderBorderStyle]::Single
    $Grid.ColumnHeadersDefaultCellStyle.BackColor = $script:DashboardTheme.Header
    $Grid.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::White
    $Grid.ColumnHeadersDefaultCellStyle.Font = New-DashboardFont -Size 9 -Style ([System.Drawing.FontStyle]::Bold)
    $Grid.DefaultCellStyle.BackColor = $script:DashboardTheme.Surface
    $Grid.DefaultCellStyle.ForeColor = $script:DashboardTheme.Text
    $Grid.DefaultCellStyle.SelectionBackColor = $script:DashboardTheme.AccentSoft
    $Grid.DefaultCellStyle.SelectionForeColor = $script:DashboardTheme.Text
    $Grid.AlternatingRowsDefaultCellStyle.BackColor = $script:DashboardTheme.SurfaceAlt
    $Grid.CellBorderStyle = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal
    $Grid.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
}

function Set-ModernChartStyle {
    param([System.Windows.Forms.DataVisualization.Charting.Chart]$Chart)

    $Chart.BackColor = $script:DashboardTheme.Surface
    $Chart.BorderlineColor = $script:DashboardTheme.Border
    $Chart.BorderlineDashStyle = [System.Windows.Forms.DataVisualization.Charting.ChartDashStyle]::Solid

    foreach ($area in $Chart.ChartAreas) {
        $area.BackColor = $script:DashboardTheme.Surface
        $area.AxisX.MajorGrid.LineColor = $script:DashboardTheme.Border
        $area.AxisY.MajorGrid.LineColor = $script:DashboardTheme.Border
        $area.AxisX.LabelStyle.ForeColor = $script:DashboardTheme.MutedText
        $area.AxisY.LabelStyle.ForeColor = $script:DashboardTheme.MutedText
        $area.AxisX.LineColor = $script:DashboardTheme.Border
        $area.AxisY.LineColor = $script:DashboardTheme.Border
    }

    foreach ($legend in $Chart.Legends) {
        $legend.BackColor = $script:DashboardTheme.Surface
        $legend.ForeColor = $script:DashboardTheme.Text
        $legend.Font = New-DashboardFont -Size 9
    }
}

function Apply-ModernDashboardTheme {
    param(
        [System.Windows.Forms.Form]$RootForm,
        [System.Windows.Forms.TabControl]$TabControl
    )

    Enable-ControlDoubleBuffer -Control $RootForm
    $RootForm.BackColor = $script:DashboardTheme.Shell
    $RootForm.Font = New-DashboardFont -Size 9
    $RootForm.MinimumSize = New-Object System.Drawing.Size(1200, 760)

    $TabControl.Font = New-DashboardFont -Size 9
    foreach ($page in $TabControl.TabPages) {
        $page.BackColor = $script:DashboardTheme.Shell
    }

    $controls = New-Object System.Collections.Queue
    $controls.Enqueue($RootForm)
    while ($controls.Count -gt 0) {
        $control = [System.Windows.Forms.Control]$controls.Dequeue()

        if ($control -is [System.Windows.Forms.Button]) {
            Set-ModernButtonStyle -Button $control
        }
        elseif ($control -is [System.Windows.Forms.DataGridView]) {
            Set-ModernGridStyle -Grid $control
        }
        elseif ($control -is [System.Windows.Forms.GroupBox]) {
            $control.BackColor = $script:DashboardTheme.Surface
            $control.ForeColor = $script:DashboardTheme.Text
            $control.Font = New-DashboardFont -Size 9 -Style ([System.Drawing.FontStyle]::Bold)
        }
        elseif ($control -is [System.Windows.Forms.TextBox]) {
            $control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
            $control.BackColor = $script:DashboardTheme.Surface
            $control.ForeColor = $script:DashboardTheme.Text
        }
        elseif ($control -is [System.Windows.Forms.ComboBox]) {
            $control.FlatStyle = [System.Windows.Forms.FlatStyle]::Popup
            $control.BackColor = $script:DashboardTheme.Surface
            $control.ForeColor = $script:DashboardTheme.Text
        }
        elseif ($control -is [System.Windows.Forms.DataVisualization.Charting.Chart]) {
            Set-ModernChartStyle -Chart $control
        }

        foreach ($child in $control.Controls) {
            $controls.Enqueue($child)
        }
    }
}

function Hide-TabHeaders {
    param([System.Windows.Forms.TabControl]$TabControl)

    $TabControl.Appearance = [System.Windows.Forms.TabAppearance]::FlatButtons
    $TabControl.SizeMode = [System.Windows.Forms.TabSizeMode]::Fixed
    $TabControl.ItemSize = New-Object System.Drawing.Size(0, 1)
    $TabControl.Multiline = $true
    $TabControl.DrawMode = [System.Windows.Forms.TabDrawMode]::OwnerDrawFixed
    $TabControl.Add_DrawItem({
        param($sender, $e)
        # Navigation is rendered by the sidebar; keep native tab headers invisible.
    })
}

function Set-SidebarButtonVisual {
    param(
        [System.Windows.Forms.Button]$Button,
        [bool]$Selected = $false,
        [bool]$Hovered = $false
    )

    $Button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Button.FlatAppearance.BorderSize = 0
    $Button.Cursor = [System.Windows.Forms.Cursors]::Hand
    $Button.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $Button.Font = New-DashboardFont -Size 9 -Style ([System.Drawing.FontStyle]::Bold)
    $Button.ForeColor = if ($Selected) { [System.Drawing.Color]::White } else { $script:DashboardTheme.Text }
    $Button.BackColor = if ($Selected) {
        $script:DashboardTheme.Accent
    }
    elseif ($Hovered) {
        $script:DashboardTheme.AccentSoft
    }
    else {
        $script:DashboardTheme.Surface
    }
}

function Update-SidebarSelection {
    if (-not $script:SidebarButtons -or -not $script:tabs -or -not $script:tabs.SelectedTab) { return }
    if ($null -eq $script:tabs.SelectedTab) {
        if ($script:SidebarIndicator) { $script:SidebarIndicator.Visible = $false }
        return
    }

    foreach ($entry in $script:SidebarButtons.GetEnumerator()) {
        $button = [System.Windows.Forms.Button]$entry.Value
        Set-SidebarButtonVisual -Button $button -Selected ($entry.Key -eq $script:tabs.SelectedTab)
    }

    if ($script:SidebarIndicator -and $script:tabs.SelectedTab -and $script:SidebarButtons.ContainsKey($script:tabs.SelectedTab)) {
        $targetButton = [System.Windows.Forms.Button]$script:SidebarButtons[$script:tabs.SelectedTab]
        $script:SidebarIndicator.Top = $targetButton.Top + $script:SidebarNavPanel.Top
        $script:SidebarIndicator.Height = $targetButton.Height
        $script:SidebarIndicator.Visible = $true
    }
}

# Assign functions to script scope so they are accessible inside event handlers
$script:Set_SidebarButtonVisual = ${function:Set-SidebarButtonVisual}
$script:Update_SidebarSelection = ${function:Update-SidebarSelection}

function Remove-SidebarNavButton {
    param([System.Windows.Forms.TabPage]$TabPage)

    if ($null -eq $TabPage) { return }
    if (-not $script:SidebarButtons -or -not $script:SidebarButtons.ContainsKey($TabPage)) { return }

    $button = [System.Windows.Forms.Button]$script:SidebarButtons[$TabPage]
    if ($button.Parent) {
        $button.Parent.Controls.Remove($button)
    }
    $button.Dispose()
    $script:SidebarButtons.Remove($TabPage)
}

function Add-SidebarNavButton {
    param(
        [System.Windows.Forms.Panel]$Parent,
        [System.Windows.Forms.TabPage]$TabPage,
        [string]$Text,
        [int]$Top
    )

    $button = New-Object System.Windows.Forms.Button
    $button.Text = "  $Text"
    $button.Tag = "SidebarNav"
    $button.Location = New-Object System.Drawing.Point(10, $Top)
    $button.Size = New-Object System.Drawing.Size(196, 34)
    Set-SidebarButtonVisual -Button $button

    $button.Add_MouseEnter({
        param($sender, $eventArgs)
        if ($script:tabs.SelectedTab -ne $TabPage) {
            & (Get-Command Set-SidebarButtonVisual) -Button $sender -Hovered $true
        }
    }.GetNewClosure())

    $button.Add_MouseLeave({
        param($sender, $eventArgs)
        & (Get-Command Set-SidebarButtonVisual) -Button $sender -Selected ($script:tabs.SelectedTab -eq $TabPage)
    }.GetNewClosure())

    $button.Add_Click({
        param($sender, $e)
        $form = $sender.FindForm()
        $tabs = $form.Controls | Where-Object { $_ -is [System.Windows.Forms.TabControl] } | Select-Object -First 1
        $tabs.SelectedTab = $TabPage
        & (Get-Command Update-SidebarSelection)
    }.GetNewClosure())

    $Parent.Controls.Add($button)
    $script:SidebarButtons[$TabPage] = $button
    return $button
}

function Update-DashboardLayout {
    if (-not $script:SidebarPanel -or -not $tabs) { return }

    $top = 70
    $bottomPadding = 20
    $leftPadding = 20
    $rightPadding = 20
    $script:SidebarPanel.Location = New-Object System.Drawing.Point(20, $top)
    $script:SidebarPanel.Size = New-Object System.Drawing.Size($script:SidebarCurrentWidth, [Math]::Max(520, $form.ClientSize.Height - $top - $bottomPadding))
    if ($script:SidebarNavPanel) {
        $script:SidebarNavPanel.Size = New-Object System.Drawing.Size([Math]::Max(40, $script:SidebarCurrentWidth - 14), [Math]::Max(440, $script:SidebarPanel.Height - 56))
    }

    $tabs.Location = New-Object System.Drawing.Point(($script:SidebarPanel.Right + 12), $top)
    $tabs.Size = New-Object System.Drawing.Size([Math]::Max(900, $form.ClientSize.Width - $tabs.Left - $rightPadding), [Math]::Max(520, $form.ClientSize.Height - $top - $bottomPadding))

    $lblLastRefresh.Left = [Math]::Max($leftPadding, $form.ClientSize.Width - $lblLastRefresh.Width - $rightPadding)
    $btnApplyRefresh.Left = [Math]::Max($leftPadding, $lblLastRefresh.Left - 90)
    $chkAutoRefresh.Left = [Math]::Max($leftPadding, $btnApplyRefresh.Left - 60)
    $numRefreshInterval.Left = [Math]::Max($leftPadding, $chkAutoRefresh.Left - 90)
    $lblRefreshInterval.Left = [Math]::Max($leftPadding, $numRefreshInterval.Left - 96)

    if ($tabHealth -and $dgvHealth -and $dgvHealthIssues) {
        $gridTop = 130
        $gridHeight = [Math]::Max(320, $tabHealth.ClientSize.Height - $gridTop - 24)
        $availableWidth = [Math]::Max(900, $tabHealth.ClientSize.Width - 60)
        $gridWidth = [int](($availableWidth - 30) / 2)

        $dgvHealth.Location = New-Object System.Drawing.Point(20, $gridTop)
        $dgvHealth.Size = New-Object System.Drawing.Size($gridWidth, $gridHeight)
        $lblIssues.Left = $dgvHealth.Right + 30
        $dgvHealthIssues.Location = New-Object System.Drawing.Point(($dgvHealth.Right + 30), 145)
        $dgvHealthIssues.Size = New-Object System.Drawing.Size($gridWidth, [Math]::Max(300, $tabHealth.ClientSize.Height - 169))
    }

    Update-AgentTabLayout
}

function Update-AgentTabLayout {
    $left = 20
    $topRow = 60
    $topGrid = 100
    $gap = 12

    if ($tabWebAgent -and $cbWebAgentInstance -and $txtWebAgentSearch -and $btnWebAgentSearch -and $btnWebAgentAlerts -and $dgvWebAgentResults -and $rtbWebAgentDetails) {
        $clientWidth = [Math]::Max(860, $tabWebAgent.ClientSize.Width)
        $clientHeight = [Math]::Max(520, $tabWebAgent.ClientSize.Height)

        $instanceWidth = [Math]::Min(300, [Math]::Max(260, [int](($clientWidth - 40) * 0.24)))
        $searchButtonWidth = 110
        $alertsButtonWidth = 150

        $cbWebAgentInstance.Location = New-Object System.Drawing.Point($left, $topRow)
        $cbWebAgentInstance.Size = New-Object System.Drawing.Size($instanceWidth, 25)

        $btnWebAgentAlerts.Location = New-Object System.Drawing.Point(($clientWidth - $left - $alertsButtonWidth), ($topRow - 2))
        $btnWebAgentAlerts.Size = New-Object System.Drawing.Size($alertsButtonWidth, 27)

        $btnWebAgentSearch.Location = New-Object System.Drawing.Point(($btnWebAgentAlerts.Left - $gap - $searchButtonWidth), ($topRow - 2))
        $btnWebAgentSearch.Size = New-Object System.Drawing.Size($searchButtonWidth, 27)

        $txtWebAgentSearch.Location = New-Object System.Drawing.Point(($cbWebAgentInstance.Right + $gap), $topRow)
        $txtWebAgentSearch.Size = New-Object System.Drawing.Size([Math]::Max(220, ($btnWebAgentSearch.Left - $gap - $txtWebAgentSearch.Left)), 25)

        $gridWidth = $clientWidth - (2 * $left)
        $gridHeight = [Math]::Max(230, [int](($clientHeight - $topGrid - 30) * 0.44))
        $detailsTop = $topGrid + $gridHeight + 10
        $detailsHeight = [Math]::Max(170, $clientHeight - $detailsTop - 20)

        $dgvWebAgentResults.Location = New-Object System.Drawing.Point($left, $topGrid)
        $dgvWebAgentResults.Size = New-Object System.Drawing.Size($gridWidth, $gridHeight)
        $rtbWebAgentDetails.Location = New-Object System.Drawing.Point($left, $detailsTop)
        $rtbWebAgentDetails.Size = New-Object System.Drawing.Size($gridWidth, $detailsHeight)
    }

    if ($tabPatchManager -and $cbPatchManagerInstance -and $btnPatchRefresh -and $txtPatchDownloadPath -and $chkPatchForce -and $btnPatchDownload -and $dgvPatchStatus -and $rtbPatchManagerDetails) {
        $clientWidth = [Math]::Max(860, $tabPatchManager.ClientSize.Width)
        $clientHeight = [Math]::Max(520, $tabPatchManager.ClientSize.Height)

        $instanceWidth = [Math]::Min(300, [Math]::Max(260, [int](($clientWidth - 40) * 0.24)))
        $refreshWidth = 165
        $downloadWidth = 145
        $forceWidth = 110

        $cbPatchManagerInstance.Location = New-Object System.Drawing.Point($left, $topRow)
        $cbPatchManagerInstance.Size = New-Object System.Drawing.Size($instanceWidth, 25)

        $btnPatchRefresh.Location = New-Object System.Drawing.Point(($cbPatchManagerInstance.Right + $gap), ($topRow - 2))
        $btnPatchRefresh.Size = New-Object System.Drawing.Size($refreshWidth, 27)

        $btnPatchDownload.Location = New-Object System.Drawing.Point(($clientWidth - $left - $downloadWidth), ($topRow - 2))
        $btnPatchDownload.Size = New-Object System.Drawing.Size($downloadWidth, 27)

        $chkPatchForce.Location = New-Object System.Drawing.Point(($btnPatchDownload.Left - $gap - $forceWidth), ($topRow + 2))
        $chkPatchForce.Size = New-Object System.Drawing.Size($forceWidth, 20)

        $txtPatchDownloadPath.Location = New-Object System.Drawing.Point(($btnPatchRefresh.Right + $gap), $topRow)
        $txtPatchDownloadPath.Size = New-Object System.Drawing.Size([Math]::Max(220, ($chkPatchForce.Left - $gap - $txtPatchDownloadPath.Left)), 25)

        $gridWidth = $clientWidth - (2 * $left)
        $gridHeight = [Math]::Max(230, [int](($clientHeight - $topGrid - 30) * 0.44))
        $detailsTop = $topGrid + $gridHeight + 10
        $detailsHeight = [Math]::Max(170, $clientHeight - $detailsTop - 20)

        $dgvPatchStatus.Location = New-Object System.Drawing.Point($left, $topGrid)
        $dgvPatchStatus.Size = New-Object System.Drawing.Size($gridWidth, $gridHeight)
        $rtbPatchManagerDetails.Location = New-Object System.Drawing.Point($left, $detailsTop)
        $rtbPatchManagerDetails.Size = New-Object System.Drawing.Size($gridWidth, $detailsHeight)
    }
}

function Toggle-Sidebar {
    if (-not $script:SidebarAnimationTimer) { return }

    $script:SidebarTargetWidth = if ($script:SidebarExpanded) { $script:SidebarCollapsedWidth } else { $script:SidebarExpandedWidth }
    $script:SidebarExpanded = -not $script:SidebarExpanded
    $script:SidebarAnimationTimer.Start()

    # Update toggle button visual cue
    if ($script:SidebarExpanded) {
        $btnSidebarToggle.Text = "<"
    } else {
        $btnSidebarToggle.Text = ">"
    }
}

function Set-FillAnchor {
    param([System.Windows.Forms.Control]$Control)

    if ($Control) {
        $Control.Anchor = [System.Windows.Forms.AnchorStyles]"Top, Bottom, Left, Right"
    }
}

function Set-DashboardResponsiveAnchors {
    foreach ($control in @(
        $tabs, $dgvOverview, $dgvCPU, $dgvMemory, $dgvAlerts,
        $dgvKPIs, $dgvDisks, $dgvConfig, $dgvIO, $dgvTempDB,
        $dgvBackups, $dgvDBOptions, $dgvBlocking, $dgvLongRunning,
        $dgvTopQueries, $dgvMissingIndexes, $dgvIndexFragmentation,
        $dgvAG, $dgvListeners, $dgvAgentJobs, $dgvDeadlocks, $dgvWaits,
        $dgvThresholds, $dgvAlertHistory,
        $dgvWebAgentResults, $rtbWebAgentDetails,
        $dgvPatchStatus, $rtbPatchManagerDetails,
        $cpuChart, $memoryChart, $trendChart
    )) {
        Set-FillAnchor -Control $control
    }

    # Instances tab - fixed top grid + form below
    $dgvInstances.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                         -bor [System.Windows.Forms.AnchorStyles]::Left `
                         -bor [System.Windows.Forms.AnchorStyles]::Right

    $txtDisplayName.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                           -bor [System.Windows.Forms.AnchorStyles]::Left
    $txtSqlInstance.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                           -bor [System.Windows.Forms.AnchorStyles]::Left
    $txtRepositoryServer.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                -bor [System.Windows.Forms.AnchorStyles]::Left
    $txtRepositoryDatabase.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                  -bor [System.Windows.Forms.AnchorStyles]::Left
    $txtEnvironment.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                           -bor [System.Windows.Forms.AnchorStyles]::Left
    $chkInstanceActive.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                              -bor [System.Windows.Forms.AnchorStyles]::Left

    $btnNewInstance.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                           -bor [System.Windows.Forms.AnchorStyles]::Left
    $btnSaveInstance.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                            -bor [System.Windows.Forms.AnchorStyles]::Left
    $btnDeleteInstance.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                              -bor [System.Windows.Forms.AnchorStyles]::Left
    $btnReloadInstances.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                               -bor [System.Windows.Forms.AnchorStyles]::Left

    $grpBulkImport.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                          -bor [System.Windows.Forms.AnchorStyles]::Left `
                          -bor [System.Windows.Forms.AnchorStyles]::Right

    # User Management tab uses explicit form layout - NOT full fill
    $dgvUsers.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                     -bor [System.Windows.Forms.AnchorStyles]::Left `
                     -bor [System.Windows.Forms.AnchorStyles]::Right

    $clbUserInstances.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                             -bor [System.Windows.Forms.AnchorStyles]::Left

    $btnNewUser.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                       -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnSaveUser.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                        -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnDeleteUser.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                          -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnReloadUsers.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                           -bor [System.Windows.Forms.AnchorStyles]::Right

    # WebAgent tab controls
    $cbWebAgentInstance.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                 -bor [System.Windows.Forms.AnchorStyles]::Left
    $txtWebAgentSearch.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                 -bor [System.Windows.Forms.AnchorStyles]::Left `
                                 -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnWebAgentSearch.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                   -bor [System.Windows.Forms.AnchorStyles]::Right
    $btnWebAgentAlerts.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                   -bor [System.Windows.Forms.AnchorStyles]::Right
    $dgvWebAgentResults.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                               -bor [System.Windows.Forms.AnchorStyles]::Bottom `
                               -bor [System.Windows.Forms.AnchorStyles]::Left `
                               -bor [System.Windows.Forms.AnchorStyles]::Right
    $rtbWebAgentDetails.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                  -bor [System.Windows.Forms.AnchorStyles]::Bottom `
                                  -bor [System.Windows.Forms.AnchorStyles]::Left `
                                  -bor [System.Windows.Forms.AnchorStyles]::Right

    # PatchManager tab controls
    $cbPatchManagerInstance.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                    -bor [System.Windows.Forms.AnchorStyles]::Left
    $btnPatchRefresh.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                               -bor [System.Windows.Forms.AnchorStyles]::Left
    $btnPatchDownload.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                 -bor [System.Windows.Forms.AnchorStyles]::Right
    $txtPatchDownloadPath.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                  -bor [System.Windows.Forms.AnchorStyles]::Left `
                                  -bor [System.Windows.Forms.AnchorStyles]::Right
    $chkPatchForce.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                              -bor [System.Windows.Forms.AnchorStyles]::Right
    $dgvPatchStatus.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                             -bor [System.Windows.Forms.AnchorStyles]::Bottom `
                             -bor [System.Windows.Forms.AnchorStyles]::Left `
                             -bor [System.Windows.Forms.AnchorStyles]::Right
    $rtbPatchManagerDetails.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                                       -bor [System.Windows.Forms.AnchorStyles]::Bottom `
                                       -bor [System.Windows.Forms.AnchorStyles]::Left `
                                       -bor [System.Windows.Forms.AnchorStyles]::Right
}

function Get-DashboardSettingsPath {
    return Join-Path $projectRoot "Config\dashboard-settings.json"
}

function Get-ClampedRefreshIntervalSeconds {
    param([object]$Value)

    try {
        $seconds = [int]$Value
    }
    catch {
        $seconds = 30
    }

    if ($seconds -lt 10) { return 10 }
    if ($seconds -gt 3600) { return 3600 }
    return $seconds
}

function Load-DashboardSettings {
    $settings = [pscustomobject]@{
        RefreshIntervalSeconds = 30
        AutoRefreshEnabled     = $true
    }

    $settingsPath = Get-DashboardSettingsPath
    if (Test-Path $settingsPath) {
        try {
            $saved = Get-Content -Path $settingsPath -Raw | ConvertFrom-Json
            $settings.RefreshIntervalSeconds = Get-ClampedRefreshIntervalSeconds -Value $saved.RefreshIntervalSeconds
            $settings.AutoRefreshEnabled = [bool]$saved.AutoRefreshEnabled
        }
        catch {
            Write-MonitorLog "Failed to read dashboard settings from ${settingsPath}: $($_.Exception.Message)" -Level 'Warning'
        }
    }

    return $settings
}

function Save-DashboardSettings {
    param([pscustomobject]$Settings)

    $settingsPath = Get-DashboardSettingsPath
    $settingsDir = Split-Path -Parent $settingsPath
    if (-not (Test-Path $settingsDir)) {
        New-Item -ItemType Directory -Path $settingsDir -Force | Out-Null
    }

    $Settings | ConvertTo-Json -Depth 3 | Set-Content -Path $settingsPath -Encoding UTF8
}

$script:DashboardSettings = Load-DashboardSettings
$script:IsRefreshing = $false
$script:SuppressInstanceChangeLoad = $false

# ------------------------------------------------------------
# Main form
# ------------------------------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = "SQL Monitor Dashboard"
$form.Size = New-Object System.Drawing.Size(1450, 940)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::WhiteSmoke
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

# ------------------------------------------------------------
# ToolTip component for detailed explanations
# ------------------------------------------------------------
$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.AutoPopDelay = 5000
$toolTip.InitialDelay = 1000
$toolTip.ReshowDelay = 500
$toolTip.ShowAlways = $true

# ------------------------------------------------------------
# Header
# ------------------------------------------------------------
$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "SQL Monitor Dashboard"
$lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
$lblTitle.AutoSize = $true
$lblTitle.Location = New-Object System.Drawing.Point(20, 15)
$form.Controls.Add($lblTitle)

$lblLastRefresh = New-Object System.Windows.Forms.Label
$lblLastRefresh.Text = "Last Refresh: Not yet loaded"
$lblLastRefresh.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblLastRefresh.AutoSize = $true
$lblLastRefresh.Location = New-Object System.Drawing.Point(1180, 22)
$form.Controls.Add($lblLastRefresh)

$lblRefreshInterval = New-Object System.Windows.Forms.Label
$lblRefreshInterval.Text = "Refresh (sec):"
$lblRefreshInterval.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblRefreshInterval.AutoSize = $true
$lblRefreshInterval.Location = New-Object System.Drawing.Point(790, 24)
$form.Controls.Add($lblRefreshInterval)

$numRefreshInterval = New-Object System.Windows.Forms.NumericUpDown
$numRefreshInterval.Minimum = 10
$numRefreshInterval.Maximum = 3600
$numRefreshInterval.Increment = 5
$numRefreshInterval.Value = Get-ClampedRefreshIntervalSeconds -Value $script:DashboardSettings.RefreshIntervalSeconds
$numRefreshInterval.Location = New-Object System.Drawing.Point(885, 20)
$numRefreshInterval.Size = New-Object System.Drawing.Size(80, 28)
$form.Controls.Add($numRefreshInterval)

$chkAutoRefresh = New-Object System.Windows.Forms.CheckBox
$chkAutoRefresh.Text = "Auto"
$chkAutoRefresh.Checked = [bool]$script:DashboardSettings.AutoRefreshEnabled
$chkAutoRefresh.AutoSize = $true
$chkAutoRefresh.Location = New-Object System.Drawing.Point(975, 23)
$form.Controls.Add($chkAutoRefresh)

$btnApplyRefresh = New-Object System.Windows.Forms.Button
$btnApplyRefresh.Text = "Apply"
$btnApplyRefresh.Location = New-Object System.Drawing.Point(1035, 18)
$btnApplyRefresh.Size = New-Object System.Drawing.Size(75, 30)
$form.Controls.Add($btnApplyRefresh)

$lblCollectorStatus = New-Object System.Windows.Forms.Label
$lblCollectorStatus.Text = "Status: Ready"
$lblCollectorStatus.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblCollectorStatus.AutoSize = $true
$lblCollectorStatus.ForeColor = [System.Drawing.Color]::DarkSlateGray
$lblCollectorStatus.Location = New-Object System.Drawing.Point(20, 45)
$form.Controls.Add($lblCollectorStatus)

$lblCurrentUser = New-Object System.Windows.Forms.Label
$lblCurrentUser.Text = "User: $($script:CurrentUser.UserName) ($($script:CurrentUser.RoleName))"
$lblCurrentUser.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$lblCurrentUser.AutoSize = $true
$lblCurrentUser.ForeColor = [System.Drawing.Color]::FromArgb(0, 95, 184)
$lblCurrentUser.Location = New-Object System.Drawing.Point(420, 45)
$form.Controls.Add($lblCurrentUser)

function Apply-RefreshIntervalSettings {
    param([bool]$ShowStatus = $false)

    $seconds = Get-ClampedRefreshIntervalSeconds -Value $numRefreshInterval.Value
    $autoEnabled = [bool]$chkAutoRefresh.Checked

    $script:DashboardSettings = [pscustomobject]@{
        RefreshIntervalSeconds = $seconds
        AutoRefreshEnabled     = $autoEnabled
    }
    Save-DashboardSettings -Settings $script:DashboardSettings

    if ($timer) {
        $timer.Interval = $seconds * 1000
        if ($autoEnabled) {
            $timer.Start()
        }
        else {
            $timer.Stop()
        }
    }

    if ($ShowStatus -and $lblCollectorStatus) {
        $state = if ($autoEnabled) { "enabled" } else { "paused" }
        $lblCollectorStatus.Text = "Status: Auto-refresh $state ($seconds sec)"
    }
}

# ------------------------------------------------------------
# Tabs
# ------------------------------------------------------------
$script:tabs = New-Object System.Windows.Forms.TabControl
$script:tabs.Location = New-Object System.Drawing.Point(262, 70)
$script:tabs.Size = New-Object System.Drawing.Size(1160, 810)
Hide-TabHeaders -TabControl $script:tabs

$tabOverview = New-Object System.Windows.Forms.TabPage
$tabOverview.Text = "Overview"
$tabOverview.AutoScroll = $true
$tabOverview.Padding = New-Object System.Windows.Forms.Padding(5)

$tabCPU = New-Object System.Windows.Forms.TabPage
$tabCPU.Text = "CPU"
$tabCPU.AutoScroll = $true
$tabCPU.Padding = New-Object System.Windows.Forms.Padding(5)

$tabMemory = New-Object System.Windows.Forms.TabPage
$tabMemory.Text = "Memory"
$tabMemory.AutoScroll = $true
$tabMemory.Padding = New-Object System.Windows.Forms.Padding(5)

$tabAlerts = New-Object System.Windows.Forms.TabPage
$tabAlerts.Text = "Alerts"
$tabAlerts.AutoScroll = $true
$tabAlerts.Padding = New-Object System.Windows.Forms.Padding(5)
# Add missing tabs
$tabKPIs = New-Object System.Windows.Forms.TabPage
$tabKPIs.Text = "KPIs"
$tabKPIs.AutoScroll = $true
$tabKPIs.Padding = New-Object System.Windows.Forms.Padding(5)
$tabDisks = New-Object System.Windows.Forms.TabPage
$tabDisks.Text = "Disks"
$tabDisks.AutoScroll = $true
$tabDisks.Padding = New-Object System.Windows.Forms.Padding(5)
$tabConfig = New-Object System.Windows.Forms.TabPage
$tabConfig.Text = "Config"
$tabConfig.AutoScroll = $true
$tabConfig.Padding = New-Object System.Windows.Forms.Padding(5)

# UNIQUE FEATURE TABS
$tabExecutionPlans = New-Object System.Windows.Forms.TabPage
$tabExecutionPlans.Text = "Execution Plans"
$tabExecutionPlans.AutoScroll = $true
$tabExecutionPlans.Padding = New-Object System.Windows.Forms.Padding(5)

$tabMemoryAnalysis = New-Object System.Windows.Forms.TabPage
$tabMemoryAnalysis.Text = "Memory Analysis"
$tabMemoryAnalysis.AutoScroll = $true
$tabMemoryAnalysis.Padding = New-Object System.Windows.Forms.Padding(5)
$tabIO = New-Object System.Windows.Forms.TabPage
$tabIO.Text = "I/O"
$tabIO.AutoScroll = $true
$tabIO.Padding = New-Object System.Windows.Forms.Padding(5)
$tabTempDB = New-Object System.Windows.Forms.TabPage
$tabTempDB.Text = "tempdb"
$tabTempDB.AutoScroll = $true
$tabTempDB.Padding = New-Object System.Windows.Forms.Padding(5)
$tabBackups = New-Object System.Windows.Forms.TabPage
$tabBackups.Text = "Backups"
$tabBackups.AutoScroll = $true
$tabBackups.Padding = New-Object System.Windows.Forms.Padding(5)
$tabDBOptions = New-Object System.Windows.Forms.TabPage
$tabDBOptions.Text = "DB Options"
$tabDBOptions.AutoScroll = $true
$tabDBOptions.Padding = New-Object System.Windows.Forms.Padding(5)
$tabBlocking = New-Object System.Windows.Forms.TabPage
$tabBlocking.Text = "Blocking"
$tabBlocking.AutoScroll = $true
$tabBlocking.Padding = New-Object System.Windows.Forms.Padding(5)
$tabLongRunning = New-Object System.Windows.Forms.TabPage
$tabLongRunning.Text = "Long Running"
$tabLongRunning.AutoScroll = $true
$tabLongRunning.Padding = New-Object System.Windows.Forms.Padding(5)
$tabTopQueries = New-Object System.Windows.Forms.TabPage
$tabTopQueries.Text = "Top Queries"
$tabTopQueries.AutoScroll = $true
$tabTopQueries.Padding = New-Object System.Windows.Forms.Padding(5)
$tabMissingIndexes = New-Object System.Windows.Forms.TabPage
$tabMissingIndexes.Text = "Missing Indexes"
$tabMissingIndexes.AutoScroll = $true
$tabMissingIndexes.Padding = New-Object System.Windows.Forms.Padding(5)
$tabIndexFragmentation = New-Object System.Windows.Forms.TabPage
$tabIndexFragmentation.Text = "Index Fragmentation"
$tabIndexFragmentation.AutoScroll = $true
$tabIndexFragmentation.Padding = New-Object System.Windows.Forms.Padding(5)
$tabAG = New-Object System.Windows.Forms.TabPage
$tabAG.Text = "Always On / WSFC"
$tabAG.AutoScroll = $true
$tabAG.Padding = New-Object System.Windows.Forms.Padding(5)
$tabListeners = New-Object System.Windows.Forms.TabPage
$tabListeners.Text = "Listeners & Endpoints"
$tabListeners.AutoScroll = $true
$tabListeners.Padding = New-Object System.Windows.Forms.Padding(5)
$tabAgentJobs = New-Object System.Windows.Forms.TabPage
$tabAgentJobs.Text = "Agent Jobs"
$tabAgentJobs.AutoScroll = $true
$tabAgentJobs.Padding = New-Object System.Windows.Forms.Padding(5)
$tabDeadlocks = New-Object System.Windows.Forms.TabPage
$tabDeadlocks.Text = "Deadlocks"
$tabDeadlocks.AutoScroll = $true
$tabDeadlocks.Padding = New-Object System.Windows.Forms.Padding(5)
$tabWaits = New-Object System.Windows.Forms.TabPage
$tabWaits.Text = "Waits"
$tabWaits.AutoScroll = $true
$tabWaits.Padding = New-Object System.Windows.Forms.Padding(5)
$tabHealth = New-Object System.Windows.Forms.TabPage
$tabHealth.Text = "Collection Health"
$tabHealth.AutoScroll = $true
$tabHealth.Padding = New-Object System.Windows.Forms.Padding(5)
$tabInstances = New-Object System.Windows.Forms.TabPage
$tabInstances.Text = "Instances"
$tabInstances.AutoScroll = $true
$tabInstances.Padding = New-Object System.Windows.Forms.Padding(5)

$tabNotifications = New-Object System.Windows.Forms.TabPage
$tabNotifications.Text = "Notifications"
$tabNotifications.AutoScroll = $true
$tabNotifications.Padding = New-Object System.Windows.Forms.Padding(5)
$tabThresholds = New-Object System.Windows.Forms.TabPage
$tabThresholds.Text = "Alert Thresholds"
$tabThresholds.AutoScroll = $true
$tabThresholds.Padding = New-Object System.Windows.Forms.Padding(5)
$tabAlertHistory = New-Object System.Windows.Forms.TabPage
$tabAlertHistory.Text = "Alert History"
$tabAlertHistory.AutoScroll = $true
$tabAlertHistory.Padding = New-Object System.Windows.Forms.Padding(5)
$tabAnalytics = New-Object System.Windows.Forms.TabPage
$tabAnalytics.Text = "Performance Analytics"
$tabAnalytics.AutoScroll = $true
$tabAnalytics.Padding = New-Object System.Windows.Forms.Padding(5)
$tabInstanceGroup = New-Object System.Windows.Forms.TabPage
$tabInstanceGroup.Text = "Instance Group Execution"
$tabInstanceGroup.AutoScroll = $true
$tabInstanceGroup.Padding = New-Object System.Windows.Forms.Padding(5)

# New tabs for enhanced functionality
$tabDictionary = New-Object System.Windows.Forms.TabPage
$tabDictionary.Text = "SQL Server Dictionary"
$tabDictionary.AutoScroll = $true
$tabDictionary.Padding = New-Object System.Windows.Forms.Padding(5)

$tabIssues = New-Object System.Windows.Forms.TabPage
$tabIssues.Text = "Common Issues & SOPs"
$tabIssues.AutoScroll = $true
$tabIssues.Padding = New-Object System.Windows.Forms.Padding(5)

# RichTextBox to display SOP content
# Use a WebBrowser control so we can render HTML generated from Markdown
$script:webSOPs = New-Object System.Windows.Forms.WebBrowser
$script:webSOPs.Dock = [System.Windows.Forms.DockStyle]::Fill
$script:webSOPs.Location = New-Object System.Drawing.Point(0,30)
$tabIssues.Controls.Add($script:webSOPs)

# New tabs for WebAgent and PatchManager
$tabWebAgent = New-Object System.Windows.Forms.TabPage
$tabWebAgent.Text = "Web Solutions Agent"
$tabWebAgent.AutoScroll = $true
$tabWebAgent.Padding = New-Object System.Windows.Forms.Padding(5)

$tabPatchManager = New-Object System.Windows.Forms.TabPage
$tabPatchManager.Text = "Patch Manager"
$tabPatchManager.AutoScroll = $true
$tabPatchManager.Padding = New-Object System.Windows.Forms.Padding(5)

$tabUsers = New-Object System.Windows.Forms.TabPage
$tabUsers.Text = "User Management"
$tabUsers.AutoScroll = $true
$tabUsers.Padding = New-Object System.Windows.Forms.Padding(5)

$script:tabs.TabPages.Add($tabOverview)
$script:tabs.TabPages.Add($tabHealth)
$script:tabs.TabPages.Add($tabKPIs)
$script:tabs.TabPages.Add($tabCPU)
$script:tabs.TabPages.Add($tabMemory)
$script:tabs.TabPages.Add($tabDisks)
$script:tabs.TabPages.Add($tabConfig)
$script:tabs.TabPages.Add($tabIO)
$script:tabs.TabPages.Add($tabTempDB)
$script:tabs.TabPages.Add($tabBackups)
$script:tabs.TabPages.Add($tabDBOptions)
$script:tabs.TabPages.Add($tabBlocking)
$script:tabs.TabPages.Add($tabLongRunning)
$script:tabs.TabPages.Add($tabTopQueries)
$script:tabs.TabPages.Add($tabMissingIndexes)
$script:tabs.TabPages.Add($tabIndexFragmentation)
$script:tabs.TabPages.Add($tabAG)
$script:tabs.TabPages.Add($tabListeners)
$script:tabs.TabPages.Add($tabAgentJobs)
$script:tabs.TabPages.Add($tabDeadlocks)
$script:tabs.TabPages.Add($tabWaits)
$script:tabs.TabPages.Add($tabAlerts)
$script:tabs.TabPages.Add($tabExecutionPlans)
$script:tabs.TabPages.Add($tabIssues)
$script:tabs.TabPages.Add($tabMemoryAnalysis)
$script:tabs.TabPages.Add($tabNotifications)
$script:tabs.TabPages.Add($tabThresholds)
$script:tabs.TabPages.Add($tabAlertHistory)
$script:tabs.TabPages.Add($tabAnalytics)
$script:tabs.TabPages.Add($tabInstanceGroup)
$script:tabs.TabPages.Add($tabDictionary)
$script:tabs.TabPages.Add($tabIssues)
$script:tabs.TabPages.Add($tabWebAgent)
$script:tabs.TabPages.Add($tabPatchManager)

$form.Controls.Add($script:tabs)

$script:SidebarExpandedWidth = 230
$script:SidebarCollapsedWidth = 66
$script:SidebarCurrentWidth = $script:SidebarExpandedWidth
$script:SidebarTargetWidth = $script:SidebarExpandedWidth
$script:SidebarExpanded = $true
$script:SidebarButtons = @{}

$script:SidebarPanel = New-Object System.Windows.Forms.Panel
$script:SidebarPanel.BackColor = $script:DashboardTheme.Surface
$script:SidebarPanel.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$form.Controls.Add($script:SidebarPanel)

$lblSidebarTitle = New-Object System.Windows.Forms.Label
$lblSidebarTitle.Text = "Navigation"
$lblSidebarTitle.Font = New-DashboardFont -Size 12 -Style ([System.Drawing.FontStyle]::Bold)
$lblSidebarTitle.ForeColor = $script:DashboardTheme.Header
$lblSidebarTitle.Location = New-Object System.Drawing.Point(14, 12)
$lblSidebarTitle.Size = New-Object System.Drawing.Size(150, 28)
$script:SidebarPanel.Controls.Add($lblSidebarTitle)

$btnSidebarToggle = New-Object System.Windows.Forms.Button
$btnSidebarToggle.Text = "<"
$btnSidebarToggle.Tag = "SidebarToggle"
$btnSidebarToggle.Location = New-Object System.Drawing.Point(178, 10)
$btnSidebarToggle.Size = New-Object System.Drawing.Size(36, 28)
Set-SidebarButtonVisual -Button $btnSidebarToggle
$btnSidebarToggle.Add_Click({ Toggle-Sidebar })
$script:SidebarPanel.Controls.Add($btnSidebarToggle)

$script:SidebarIndicator = New-Object System.Windows.Forms.Panel
$script:SidebarIndicator.BackColor = $script:DashboardTheme.Accent
$script:SidebarIndicator.Location = New-Object System.Drawing.Point(0, 50)
$script:SidebarIndicator.Size = New-Object System.Drawing.Size(4, 34)
$script:SidebarPanel.Controls.Add($script:SidebarIndicator)

$script:SidebarNavPanel = New-Object System.Windows.Forms.Panel
$script:SidebarNavPanel.Location = New-Object System.Drawing.Point(6, 48)
$script:SidebarNavPanel.Size = New-Object System.Drawing.Size(216, 740)
$script:SidebarNavPanel.AutoScroll = $true
$script:SidebarPanel.Controls.Add($script:SidebarNavPanel)

# Set default theme before applying
$script:CurrentTheme = 'Dark'

# -------------------------------------------------
# Theme toggle button (light / dark) – placed at bottom of sidebar
# -------------------------------------------------
$script:CurrentTheme = 'Dark'
$btnThemeToggle = New-Object System.Windows.Forms.Button
$btnThemeToggle.Text = 'Light Theme'
$btnThemeToggle.Size = New-Object System.Drawing.Size(120,30)
$themeY = $script:SidebarPanel.Height - 40
$btnThemeToggle.Location = New-Object System.Drawing.Point(10, $themeY)
$script:SidebarPanel.Controls.Add($btnThemeToggle)

function Apply-Theme {
    param([string]$Theme)
    if ($Theme -eq 'Dark') {
        $script:DashboardTheme.Surface = [System.Drawing.Color]::FromArgb(30,30,30)
        $script:DashboardTheme.Text = [System.Drawing.Color]::White
        $script:DashboardTheme.Header = [System.Drawing.Color]::FromArgb(200,200,200)
        $script:DashboardTheme.Accent = [System.Drawing.Color]::FromArgb(0,95,184)
        $btnThemeToggle.Text = 'Light Theme'
    } else {
        $script:DashboardTheme.Surface = [System.Drawing.Color]::White
        $script:DashboardTheme.Text = [System.Drawing.Color]::FromArgb(32,42,57)
        $script:DashboardTheme.Header = [System.Drawing.Color]::FromArgb(22,34,52)
        $script:DashboardTheme.Accent = [System.Drawing.Color]::FromArgb(0,95,184)
        $btnThemeToggle.Text = 'Dark Theme'
    }
    # Apply colors to main UI elements
    $script:SidebarPanel.BackColor = $script:DashboardTheme.Surface
    $script:SidebarNavPanel.BackColor = $script:DashboardTheme.Surface
    $form.BackColor = $script:DashboardTheme.Surface
    foreach ($ctrl in $form.Controls) { $ctrl.ForeColor = $script:DashboardTheme.Text }
    $script:CurrentTheme = $Theme
}

# Apply the theme after function definition using the current theme
Apply-Theme $script:CurrentTheme

$btnThemeToggle.Add_Click({
    if ($script:CurrentTheme -eq 'Dark') { Apply-Theme 'Light' } else { Apply-Theme 'Dark' }
})

$sidebarTop = 0
foreach ($navItem in @(
    @{ Tab = $tabOverview; Text = "Overview" },
    @{ Tab = $tabHealth; Text = "Collection Health" },
    @{ Tab = $tabKPIs; Text = "KPIs" },
    @{ Tab = $tabCPU; Text = "CPU" },
    @{ Tab = $tabMemory; Text = "Memory" },
    @{ Tab = $tabDisks; Text = "Disks" },
    @{ Tab = $tabConfig; Text = "Config" },
    @{ Tab = $tabIO; Text = "I/O" },
    @{ Tab = $tabTempDB; Text = "tempdb" },
    @{ Tab = $tabBackups; Text = "Backups" },
    @{ Tab = $tabDBOptions; Text = "DB Options" },
    @{ Tab = $tabBlocking; Text = "Blocking" },
    @{ Tab = $tabLongRunning; Text = "Long Running" },
    @{ Tab = $tabTopQueries; Text = "Top Queries" },
    @{ Tab = $tabMissingIndexes; Text = "Missing Indexes" },
    @{ Tab = $tabIndexFragmentation; Text = "Index Fragmentation" },
    @{ Tab = $tabAG; Text = "Always On / WSFC" },
    @{ Tab = $tabListeners; Text = "Listeners & Endpoints" },
    @{ Tab = $tabAgentJobs; Text = "Agent Jobs" },
    @{ Tab = $tabDeadlocks; Text = "Deadlocks" },
    @{ Tab = $tabWaits; Text = "Waits" },
    @{ Tab = $tabAlerts; Text = "Alerts" },
    @{ Tab = $tabNotifications; Text = "Notifications" },
    @{ Tab = $tabThresholds; Text = "Alert Thresholds" },
    @{ Tab = $tabAlertHistory; Text = "Alert History" },
    @{ Tab = $tabAnalytics; Text = "Performance Analytics" },
    @{ Tab = $tabInstanceGroup; Text = "Instance Group Execution" },
    @{ Tab = $tabDictionary; Text = "SQL Server Dictionary" },
    @{ Tab = $tabIssues; Text = "Common Issues & SOPs" },
    @{ Tab = $tabWebAgent; Text = "Web Solutions Agent" },
    @{ Tab = $tabPatchManager; Text = "Patch Manager" },
    @{ Tab = $tabUsers; Text = "User Management" }
)) {
    if ($tabs.TabPages.Contains($navItem.Tab)) {
        Add-SidebarNavButton -Parent $script:SidebarNavPanel -TabPage $navItem.Tab -Text $navItem.Text -Top $sidebarTop | Out-Null
        $sidebarTop += 38
    }
}

$script:SidebarAnimationTimer = New-Object System.Windows.Forms.Timer
$script:SidebarAnimationTimer.Interval = 15
$script:SidebarAnimationTimer.Add_Tick({
    $delta = $script:SidebarTargetWidth - $script:SidebarCurrentWidth
    if ([Math]::Abs($delta) -le 8) {
        $script:SidebarCurrentWidth = $script:SidebarTargetWidth
        $script:SidebarAnimationTimer.Stop()
    }
    else {
        $script:SidebarCurrentWidth += [Math]::Sign($delta) * 18
    }

    $script:SidebarPanel.Width = $script:SidebarCurrentWidth
    $script:SidebarNavPanel.Width = [Math]::Max(40, $script:SidebarCurrentWidth - 14)
    foreach ($button in $script:SidebarButtons.Values) {
        $button.Width = [Math]::Max(42, $script:SidebarCurrentWidth - 34)
        $button.Text = if ($script:SidebarCurrentWidth -le 90) { "" } else { "  $($button.AccessibleName)" }
    }
    $lblSidebarTitle.Visible = ($script:SidebarCurrentWidth -gt 120)
    $btnSidebarToggle.Left = [Math]::Max(15, $script:SidebarCurrentWidth - 52)
    $btnSidebarToggle.Text = if ($script:SidebarExpanded) { "<" } else { ">" }
    Update-DashboardLayout
    Update-SidebarSelection
})

foreach ($entry in $script:SidebarButtons.GetEnumerator()) {
    $entry.Value.AccessibleName = $entry.Value.Text.Trim()
}

Update-DashboardLayout
Update-SidebarSelection

# ------------------------------------------------------------
# Overview controls
# ------------------------------------------------------------
$cbInstances = New-Object System.Windows.Forms.ComboBox
$cbInstances.Location = New-Object System.Drawing.Point(20, 20)
$cbInstances.Size = New-Object System.Drawing.Size(400, 30)
$cbInstances.DropDownStyle = "DropDownList"
$tabOverview.Controls.Add($cbInstances)
$toolTip.SetToolTip($cbInstances, "Select the SQL Server instance to monitor. This dropdown shows all configured instances in your monitoring repository. The dashboard will display metrics and alerts specific to the selected instance.")

$btnBackToOverview = New-Object System.Windows.Forms.Button
$btnBackToOverview.Text = "← Server Overview"
$btnBackToOverview.Location = New-Object System.Drawing.Point(440, 18)
$btnBackToOverview.Size = New-Object System.Drawing.Size(140, 32)
$btnBackToOverview.BackColor = [System.Drawing.Color]::FromArgb(108, 117, 125)
$btnBackToOverview.ForeColor = [System.Drawing.Color]::White
$btnBackToOverview.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$tabOverview.Controls.Add($btnBackToOverview)
$toolTip.SetToolTip($btnBackToOverview, "Return to the server overview screen to select a different instance or access management functions")

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = "Refresh Now"
$btnRefresh.Location = New-Object System.Drawing.Point(600, 18)
$btnRefresh.Size = New-Object System.Drawing.Size(120, 32)
$tabOverview.Controls.Add($btnRefresh)
$toolTip.SetToolTip($btnRefresh, "Manually refresh the dashboard data. This will query the monitoring repository for the latest metrics, alerts, and performance data for the selected instance.")

$btnRun = New-Object System.Windows.Forms.Button
$btnRun.Text = "Run Collectors"
$btnRun.Location = New-Object System.Drawing.Point(760, 18)
$btnRun.Size = New-Object System.Drawing.Size(120, 32)
$tabOverview.Controls.Add($btnRun)
$toolTip.SetToolTip($btnRun, "Execute data collectors immediately. This runs the configured collector jobs to gather fresh performance metrics from the selected SQL Server instance.")

$lblCollectorGroup = New-Object System.Windows.Forms.Label
$lblCollectorGroup.Text = "Group:"
$lblCollectorGroup.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblCollectorGroup.AutoSize = $true
$lblCollectorGroup.Location = New-Object System.Drawing.Point(900, 24)
$tabOverview.Controls.Add($lblCollectorGroup)

$cbOverviewCollectorGroup = New-Object System.Windows.Forms.ComboBox
$cbOverviewCollectorGroup.Items.AddRange(@("Core", "Advanced", "Daily", "All"))
$cbOverviewCollectorGroup.DropDownStyle = "DropDownList"
$cbOverviewCollectorGroup.Location = New-Object System.Drawing.Point(940, 18)
$cbOverviewCollectorGroup.Size = New-Object System.Drawing.Size(120, 32)
$cbOverviewCollectorGroup.SelectedIndex = 0
$tabOverview.Controls.Add($cbOverviewCollectorGroup)

$lblScheduleMode = New-Object System.Windows.Forms.Label
$lblScheduleMode.Text = "Schedule:"
$lblScheduleMode.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblScheduleMode.AutoSize = $true
$lblScheduleMode.Location = New-Object System.Drawing.Point(1080, 24)
$tabOverview.Controls.Add($lblScheduleMode)

$cbScheduleType = New-Object System.Windows.Forms.ComboBox
$cbScheduleType.Items.AddRange(@("Manual only", "Every 5 minutes", "Every 30 minutes", "Daily at"))
$cbScheduleType.DropDownStyle = "DropDownList"
$cbScheduleType.Location = New-Object System.Drawing.Point(1140, 18)
$cbScheduleType.Size = New-Object System.Drawing.Size(150, 32)
$cbScheduleType.SelectedIndex = 0
$tabOverview.Controls.Add($cbScheduleType)

$dtpScheduleTime = New-Object System.Windows.Forms.DateTimePicker
$dtpScheduleTime.Format = "Time"
$dtpScheduleTime.ShowUpDown = $true
$dtpScheduleTime.Location = New-Object System.Drawing.Point(1300, 18)
$dtpScheduleTime.Size = New-Object System.Drawing.Size(100, 32)
$dtpScheduleTime.Visible = $false
$tabOverview.Controls.Add($dtpScheduleTime)

$btnSetSchedule = New-Object System.Windows.Forms.Button
$btnSetSchedule.Text = "Set Schedule"
$btnSetSchedule.Location = New-Object System.Drawing.Point(1420, 18)
$btnSetSchedule.Size = New-Object System.Drawing.Size(90, 32)
$tabOverview.Controls.Add($btnSetSchedule)

$btnRemoveSchedule = New-Object System.Windows.Forms.Button
$btnRemoveSchedule.Text = "Remove Schedule"
$btnRemoveSchedule.Location = New-Object System.Drawing.Point(1360, 18)
$btnRemoveSchedule.Size = New-Object System.Drawing.Size(120, 32)
$tabOverview.Controls.Add($btnRemoveSchedule)

$lblScheduleInfo = New-Object System.Windows.Forms.Label
$lblScheduleInfo.Text = "Schedule: none"
$lblScheduleInfo.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblScheduleInfo.AutoSize = $true
$lblScheduleInfo.Location = New-Object System.Drawing.Point(20, 60)
$tabOverview.Controls.Add($lblScheduleInfo)

# ------------------------------------------------------------
# Instance management tab controls
$lblInstancesHeader = New-Object System.Windows.Forms.Label
$lblInstancesHeader.Text = "Manage monitored instances"
$lblInstancesHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblInstancesHeader.AutoSize = $true
$lblInstancesHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabInstances.Controls.Add($lblInstancesHeader)

$dgvInstances = New-Object System.Windows.Forms.DataGridView
$dgvInstances.Location = New-Object System.Drawing.Point(20, 60)
$dgvInstances.Size = New-Object System.Drawing.Size(1320, 340)
$dgvInstances.ReadOnly = $true
$dgvInstances.AllowUserToAddRows = $false
$dgvInstances.AllowUserToDeleteRows = $false
$dgvInstances.AutoSizeColumnsMode = "Fill"
$dgvInstances.SelectionMode = "FullRowSelect"
$dgvInstances.RowHeadersVisible = $false
$dgvInstances.ScrollBars = [System.Windows.Forms.ScrollBars]::Both
$dgvInstances.Anchor = [System.Windows.Forms.AnchorStyles]::Top `
                     -bor [System.Windows.Forms.AnchorStyles]::Left `
                     -bor [System.Windows.Forms.AnchorStyles]::Right
$tabInstances.Controls.Add($dgvInstances)

$lblDisplayName = New-Object System.Windows.Forms.Label
$lblDisplayName.Text = "Display Name:"
$lblDisplayName.Location = New-Object System.Drawing.Point(20, 420)
$lblDisplayName.AutoSize = $true
$lblDisplayName.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabInstances.Controls.Add($lblDisplayName)

$txtDisplayName = New-Object System.Windows.Forms.TextBox
$txtDisplayName.Location = New-Object System.Drawing.Point(140, 418)
$txtDisplayName.Size = New-Object System.Drawing.Size(400, 28)
$tabInstances.Controls.Add($txtDisplayName)

$lblSqlInstance = New-Object System.Windows.Forms.Label
$lblSqlInstance.Text = "SQL Instance:"
$lblSqlInstance.Location = New-Object System.Drawing.Point(20, 460)
$lblSqlInstance.AutoSize = $true
$lblSqlInstance.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabInstances.Controls.Add($lblSqlInstance)

$txtSqlInstance = New-Object System.Windows.Forms.TextBox
$txtSqlInstance.Location = New-Object System.Drawing.Point(140, 458)
$txtSqlInstance.Size = New-Object System.Drawing.Size(400, 28)
$tabInstances.Controls.Add($txtSqlInstance)

$lblRepositoryServer = New-Object System.Windows.Forms.Label
$lblRepositoryServer.Text = "Repository Server:"
$lblRepositoryServer.Location = New-Object System.Drawing.Point(20, 500)
$lblRepositoryServer.AutoSize = $true
$lblRepositoryServer.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabInstances.Controls.Add($lblRepositoryServer)

$txtRepositoryServer = New-Object System.Windows.Forms.TextBox
$txtRepositoryServer.Location = New-Object System.Drawing.Point(140, 498)
$txtRepositoryServer.Size = New-Object System.Drawing.Size(400, 28)
$txtRepositoryServer.Text = $RepositoryServer
$tabInstances.Controls.Add($txtRepositoryServer)

$lblRepositoryDatabase = New-Object System.Windows.Forms.Label
$lblRepositoryDatabase.Text = "Repository DB:"
$lblRepositoryDatabase.Location = New-Object System.Drawing.Point(20, 540)
$lblRepositoryDatabase.AutoSize = $true
$lblRepositoryDatabase.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabInstances.Controls.Add($lblRepositoryDatabase)

$txtRepositoryDatabase = New-Object System.Windows.Forms.TextBox
$txtRepositoryDatabase.Location = New-Object System.Drawing.Point(140, 538)
$txtRepositoryDatabase.Size = New-Object System.Drawing.Size(400, 28)
$txtRepositoryDatabase.Text = $RepositoryDatabase
$tabInstances.Controls.Add($txtRepositoryDatabase)

$lblEnvironment = New-Object System.Windows.Forms.Label
$lblEnvironment.Text = "Environment:"
$lblEnvironment.Location = New-Object System.Drawing.Point(20, 580)
$lblEnvironment.AutoSize = $true
$lblEnvironment.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabInstances.Controls.Add($lblEnvironment)

$txtEnvironment = New-Object System.Windows.Forms.TextBox
$txtEnvironment.Location = New-Object System.Drawing.Point(140, 578)
$txtEnvironment.Size = New-Object System.Drawing.Size(200, 28)
$txtEnvironment.Text = "Production"
$tabInstances.Controls.Add($txtEnvironment)

$chkInstanceActive = New-Object System.Windows.Forms.CheckBox
$chkInstanceActive.Text = "Active"
$chkInstanceActive.Location = New-Object System.Drawing.Point(360, 580)
$chkInstanceActive.Size = New-Object System.Drawing.Size(100, 28)
$chkInstanceActive.Checked = $true
$tabInstances.Controls.Add($chkInstanceActive)

$btnNewInstance = New-Object System.Windows.Forms.Button
$btnNewInstance.Text = "New"
$btnNewInstance.Location = New-Object System.Drawing.Point(580, 456)
$btnNewInstance.Size = New-Object System.Drawing.Size(100, 32)
$tabInstances.Controls.Add($btnNewInstance)

$btnSaveInstance = New-Object System.Windows.Forms.Button
$btnSaveInstance.Text = "Save"
$btnSaveInstance.Location = New-Object System.Drawing.Point(690, 456)
$btnSaveInstance.Size = New-Object System.Drawing.Size(100, 32)
$tabInstances.Controls.Add($btnSaveInstance)

$btnDeleteInstance = New-Object System.Windows.Forms.Button
$btnDeleteInstance.Text = "Delete"
$btnDeleteInstance.Location = New-Object System.Drawing.Point(800, 456)
$btnDeleteInstance.Size = New-Object System.Drawing.Size(100, 32)
$tabInstances.Controls.Add($btnDeleteInstance)

$btnReloadInstances = New-Object System.Windows.Forms.Button
$btnReloadInstances.Text = "Reload"
$btnReloadInstances.Location = New-Object System.Drawing.Point(910, 456)
$btnReloadInstances.Size = New-Object System.Drawing.Size(100, 32)
$tabInstances.Controls.Add($btnReloadInstances)

# Bulk Import Section
$grpBulkImport = New-Object System.Windows.Forms.GroupBox
$grpBulkImport.Text = "Bulk Import Instances"
$grpBulkImport.Location = New-Object System.Drawing.Point(20, 620)
$grpBulkImport.Size = New-Object System.Drawing.Size(1320, 120)
$tabInstances.Controls.Add($grpBulkImport)

$lblImportFile = New-Object System.Windows.Forms.Label
$lblImportFile.Text = "File:"
$lblImportFile.Location = New-Object System.Drawing.Point(20, 30)
$lblImportFile.AutoSize = $true
$lblImportFile.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpBulkImport.Controls.Add($lblImportFile)

$txtImportFile = New-Object System.Windows.Forms.TextBox
$txtImportFile.Location = New-Object System.Drawing.Point(60, 28)
$txtImportFile.Size = New-Object System.Drawing.Size(900, 28)
$txtImportFile.ReadOnly = $true
$grpBulkImport.Controls.Add($txtImportFile)

$btnBrowseFile = New-Object System.Windows.Forms.Button
$btnBrowseFile.Text = "Browse..."
$btnBrowseFile.Location = New-Object System.Drawing.Point(980, 26)
$btnBrowseFile.Size = New-Object System.Drawing.Size(100, 32)
$grpBulkImport.Controls.Add($btnBrowseFile)

$lblFileFormat = New-Object System.Windows.Forms.Label
$lblFileFormat.Text = "Format: CSV or TXT with columns 'Server Name', 'Environment'"
$lblFileFormat.Location = New-Object System.Drawing.Point(20, 70)
$lblFileFormat.AutoSize = $true
$lblFileFormat.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblFileFormat.ForeColor = [System.Drawing.Color]::Gray
$grpBulkImport.Controls.Add($lblFileFormat)

$btnImportInstances = New-Object System.Windows.Forms.Button
$btnImportInstances.Text = "Import Instances"
$btnImportInstances.Location = New-Object System.Drawing.Point(1100, 26)
$btnImportInstances.Size = New-Object System.Drawing.Size(120, 32)
$grpBulkImport.Controls.Add($btnImportInstances)

$btnPreviewImport = New-Object System.Windows.Forms.Button
$btnPreviewImport.Text = "Preview Import"
$btnPreviewImport.Location = New-Object System.Drawing.Point(1100, 66)
$btnPreviewImport.Size = New-Object System.Drawing.Size(120, 32)
$grpBulkImport.Controls.Add($btnPreviewImport)

# ------------------------------------------------------------
# User management tab controls
$lblUsersHeader = New-Object System.Windows.Forms.Label
$lblUsersHeader.Text = "Manage dashboard users and server access"
$lblUsersHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblUsersHeader.AutoSize = $true
$lblUsersHeader.Location = New-Object System.Drawing.Point(20, 10)
$tabUsers.Controls.Add($lblUsersHeader)

$lblUsersHelp = New-Object System.Windows.Forms.Label
$lblUsersHelp.Text = "Roles: Admin can configure and view all servers; ViewOnly and Limited can view assigned servers only."
$lblUsersHelp.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblUsersHelp.AutoSize = $true
$lblUsersHelp.ForeColor = [System.Drawing.Color]::DimGray
$lblUsersHelp.Location = New-Object System.Drawing.Point(20, 35)
$tabUsers.Controls.Add($lblUsersHelp)

$dgvUsers = New-Object System.Windows.Forms.DataGridView
$dgvUsers.Location = New-Object System.Drawing.Point(10, 60)
$dgvUsers.Size = New-Object System.Drawing.Size(1130, 100)
$dgvUsers.ReadOnly = $true
$dgvUsers.AllowUserToAddRows = $false
$dgvUsers.AllowUserToDeleteRows = $false
$dgvUsers.AutoSizeColumnsMode = "Fill"
$dgvUsers.SelectionMode = "FullRowSelect"
$dgvUsers.MultiSelect = $false
$tabUsers.Controls.Add($dgvUsers)

$lblUserName = New-Object System.Windows.Forms.Label
$lblUserName.Text = "User Name:"
$lblUserName.Location = New-Object System.Drawing.Point(10, 190)
$lblUserName.AutoSize = $true
$tabUsers.Controls.Add($lblUserName)

$txtUserName = New-Object System.Windows.Forms.TextBox
$txtUserName.Location = New-Object System.Drawing.Point(110, 186)
$txtUserName.Size = New-Object System.Drawing.Size(150, 22)
$tabUsers.Controls.Add($txtUserName)

$lblUserDisplayName = New-Object System.Windows.Forms.Label
$lblUserDisplayName.Text = "Display Name:"
$lblUserDisplayName.Location = New-Object System.Drawing.Point(280, 190)
$lblUserDisplayName.AutoSize = $true
$tabUsers.Controls.Add($lblUserDisplayName)

$txtUserDisplayName = New-Object System.Windows.Forms.TextBox
$txtUserDisplayName.Location = New-Object System.Drawing.Point(380, 186)
$txtUserDisplayName.Size = New-Object System.Drawing.Size(150, 22)
$tabUsers.Controls.Add($txtUserDisplayName)

$lblUserRole = New-Object System.Windows.Forms.Label
$lblUserRole.Text = "Role:"
$lblUserRole.Location = New-Object System.Drawing.Point(550, 190)
$lblUserRole.AutoSize = $true
$tabUsers.Controls.Add($lblUserRole)

$cbUserRole = New-Object System.Windows.Forms.ComboBox
$cbUserRole.Items.AddRange(@("Admin", "ViewOnly", "Limited"))
$cbUserRole.DropDownStyle = "DropDownList"
$cbUserRole.Location = New-Object System.Drawing.Point(590, 186)
$cbUserRole.Size = New-Object System.Drawing.Size(100, 22)
$cbUserRole.SelectedIndex = 1
$tabUsers.Controls.Add($cbUserRole)

$chkUserActive = New-Object System.Windows.Forms.CheckBox
$chkUserActive.Text = "Active"
$chkUserActive.Checked = $true
$chkUserActive.Location = New-Object System.Drawing.Point(710, 188)
$chkUserActive.AutoSize = $true
$tabUsers.Controls.Add($chkUserActive)

$lblUserPassword = New-Object System.Windows.Forms.Label
$lblUserPassword.Text = "Password:"
$lblUserPassword.Location = New-Object System.Drawing.Point(10, 220)
$lblUserPassword.AutoSize = $true
$tabUsers.Controls.Add($lblUserPassword)

$txtUserPassword = New-Object System.Windows.Forms.TextBox
$txtUserPassword.Location = New-Object System.Drawing.Point(110, 216)
$txtUserPassword.Size = New-Object System.Drawing.Size(150, 22)
$txtUserPassword.UseSystemPasswordChar = $true
$tabUsers.Controls.Add($txtUserPassword)

$lblPasswordHelp = New-Object System.Windows.Forms.Label
$lblPasswordHelp.Text = "Leave blank when editing to keep existing password."
$lblPasswordHelp.Location = New-Object System.Drawing.Point(280, 220)
$lblPasswordHelp.AutoSize = $true
$lblPasswordHelp.ForeColor = [System.Drawing.Color]::DimGray
$lblPasswordHelp.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$tabUsers.Controls.Add($lblPasswordHelp)

$lblUserServers = New-Object System.Windows.Forms.Label
$lblUserServers.Text = "Server Access:"
$lblUserServers.Location = New-Object System.Drawing.Point(10, 250)
$lblUserServers.AutoSize = $true
$tabUsers.Controls.Add($lblUserServers)

$clbUserInstances = New-Object System.Windows.Forms.CheckedListBox
$clbUserInstances.Location = New-Object System.Drawing.Point(10, 270)
$clbUserInstances.Size = New-Object System.Drawing.Size(500, 150)
$clbUserInstances.CheckOnClick = $true
$tabUsers.Controls.Add($clbUserInstances)

$btnNewUser = New-Object System.Windows.Forms.Button
$btnNewUser.Text = "New User"
$btnNewUser.Location = New-Object System.Drawing.Point(550, 255)
$btnNewUser.Size = New-Object System.Drawing.Size(120, 32)
$tabUsers.Controls.Add($btnNewUser)

$btnSaveUser = New-Object System.Windows.Forms.Button
$btnSaveUser.Text = "Save User"
$btnSaveUser.Location = New-Object System.Drawing.Point(550, 290)
$btnSaveUser.Size = New-Object System.Drawing.Size(120, 32)
$tabUsers.Controls.Add($btnSaveUser)

$btnDeleteUser = New-Object System.Windows.Forms.Button
$btnDeleteUser.Text = "Delete User"
$btnDeleteUser.Location = New-Object System.Drawing.Point(550, 325)
$btnDeleteUser.Size = New-Object System.Drawing.Size(120, 32)
$tabUsers.Controls.Add($btnDeleteUser)

$btnReloadUsers = New-Object System.Windows.Forms.Button
$btnReloadUsers.Text = "Reload"
$btnReloadUsers.Location = New-Object System.Drawing.Point(550, 360)
$btnReloadUsers.Size = New-Object System.Drawing.Size(120, 32)
$tabUsers.Controls.Add($btnReloadUsers)

$lblSelectedUserId = New-Object System.Windows.Forms.Label
$lblSelectedUserId.Text = "Selected UserID: new"
$lblSelectedUserId.Location = New-Object System.Drawing.Point(530, 395)
$lblSelectedUserId.AutoSize = $true
$lblSelectedUserId.ForeColor = [System.Drawing.Color]::DimGray
$lblSelectedUserId.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$tabUsers.Controls.Add($lblSelectedUserId)




# ------------------------------------------------------------
# Notification management tab controls
$lblNotificationsHeader = New-Object System.Windows.Forms.Label
$lblNotificationsHeader.Text = "Configure alert notifications"
$lblNotificationsHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblNotificationsHeader.AutoSize = $true
$lblNotificationsHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabNotifications.Controls.Add($lblNotificationsHeader)

# SMTP Settings Group
$grpSMTP = New-Object System.Windows.Forms.GroupBox
$grpSMTP.Text = "SMTP Settings"
$grpSMTP.Location = New-Object System.Drawing.Point(20, 50)
$grpSMTP.Size = New-Object System.Drawing.Size(650, 200)
$tabNotifications.Controls.Add($grpSMTP)

$lblSMTPServer = New-Object System.Windows.Forms.Label
$lblSMTPServer.Text = "Server:"
$lblSMTPServer.Location = New-Object System.Drawing.Point(20, 30)
$lblSMTPServer.AutoSize = $true
$lblSMTPServer.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpSMTP.Controls.Add($lblSMTPServer)

$txtSMTPServer = New-Object System.Windows.Forms.TextBox
$txtSMTPServer.Location = New-Object System.Drawing.Point(140, 28)
$txtSMTPServer.Size = New-Object System.Drawing.Size(300, 28)
$grpSMTP.Controls.Add($txtSMTPServer)

$lblSMTPPort = New-Object System.Windows.Forms.Label
$lblSMTPPort.Text = "Port:"
$lblSMTPPort.Location = New-Object System.Drawing.Point(460, 30)
$lblSMTPPort.AutoSize = $true
$lblSMTPPort.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpSMTP.Controls.Add($lblSMTPPort)

$txtSMTPPort = New-Object System.Windows.Forms.TextBox
$txtSMTPPort.Location = New-Object System.Drawing.Point(500, 28)
$txtSMTPPort.Size = New-Object System.Drawing.Size(80, 28)
$grpSMTP.Controls.Add($txtSMTPPort)

$lblSMTPFrom = New-Object System.Windows.Forms.Label
$lblSMTPFrom.Text = "From:"
$lblSMTPFrom.Location = New-Object System.Drawing.Point(20, 70)
$lblSMTPFrom.AutoSize = $true
$lblSMTPFrom.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpSMTP.Controls.Add($lblSMTPFrom)

$txtSMTPFrom = New-Object System.Windows.Forms.TextBox
$txtSMTPFrom.Location = New-Object System.Drawing.Point(140, 68)
$txtSMTPFrom.Size = New-Object System.Drawing.Size(440, 28)
$grpSMTP.Controls.Add($txtSMTPFrom)

$chkSMTPSSL = New-Object System.Windows.Forms.CheckBox
$chkSMTPSSL.Text = "Enable SSL"
$chkSMTPSSL.Location = New-Object System.Drawing.Point(20, 110)
$chkSMTPSSL.Size = New-Object System.Drawing.Size(120, 28)
$chkSMTPSSL.Checked = $true
$grpSMTP.Controls.Add($chkSMTPSSL)

$chkSMTPDefaultCreds = New-Object System.Windows.Forms.CheckBox
$chkSMTPDefaultCreds.Text = "Use Windows Authentication"
$chkSMTPDefaultCreds.Location = New-Object System.Drawing.Point(150, 110)
$chkSMTPDefaultCreds.Size = New-Object System.Drawing.Size(200, 28)
$chkSMTPDefaultCreds.Checked = $true
$grpSMTP.Controls.Add($chkSMTPDefaultCreds)

$lblSMTPUsername = New-Object System.Windows.Forms.Label
$lblSMTPUsername.Text = "Username:"
$lblSMTPUsername.Location = New-Object System.Drawing.Point(20, 150)
$lblSMTPUsername.AutoSize = $true
$lblSMTPUsername.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpSMTP.Controls.Add($lblSMTPUsername)

$txtSMTPUsername = New-Object System.Windows.Forms.TextBox
$txtSMTPUsername.Location = New-Object System.Drawing.Point(140, 148)
$txtSMTPUsername.Size = New-Object System.Drawing.Size(200, 28)
$grpSMTP.Controls.Add($txtSMTPUsername)

$lblSMTPPassword = New-Object System.Windows.Forms.Label
$lblSMTPPassword.Text = "Password:"
$lblSMTPPassword.Location = New-Object System.Drawing.Point(360, 150)
$lblSMTPPassword.AutoSize = $true
$lblSMTPPassword.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpSMTP.Controls.Add($lblSMTPPassword)

$txtSMTPPassword = New-Object System.Windows.Forms.TextBox
$txtSMTPPassword.Location = New-Object System.Drawing.Point(430, 148)
$txtSMTPPassword.Size = New-Object System.Drawing.Size(200, 28)
$txtSMTPPassword.UseSystemPasswordChar = $true
$grpSMTP.Controls.Add($txtSMTPPassword)

# Notification Settings Group
$grpNotifications = New-Object System.Windows.Forms.GroupBox
$grpNotifications.Text = "Notification Settings"
$grpNotifications.Location = New-Object System.Drawing.Point(20, 270)
$grpNotifications.Size = New-Object System.Drawing.Size(650, 250)
$tabNotifications.Controls.Add($grpNotifications)

$chkNotificationsEnabled = New-Object System.Windows.Forms.CheckBox
$chkNotificationsEnabled.Text = "Enable Email Notifications"
$chkNotificationsEnabled.Location = New-Object System.Drawing.Point(20, 30)
$chkNotificationsEnabled.Size = New-Object System.Drawing.Size(200, 28)
$chkNotificationsEnabled.Checked = $true
$grpNotifications.Controls.Add($chkNotificationsEnabled)

$lblMinSeverity = New-Object System.Windows.Forms.Label
$lblMinSeverity.Text = "Minimum Severity:"
$lblMinSeverity.Location = New-Object System.Drawing.Point(20, 70)
$lblMinSeverity.AutoSize = $true
$lblMinSeverity.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpNotifications.Controls.Add($lblMinSeverity)

$cbMinSeverity = New-Object System.Windows.Forms.ComboBox
$cbMinSeverity.Items.AddRange(@("Info", "Warning", "Critical"))
$cbMinSeverity.DropDownStyle = "DropDownList"
$cbMinSeverity.Location = New-Object System.Drawing.Point(140, 68)
$cbMinSeverity.Size = New-Object System.Drawing.Size(120, 32)
$cbMinSeverity.SelectedIndex = 1
$grpNotifications.Controls.Add($cbMinSeverity)

$lblThrottleMinutes = New-Object System.Windows.Forms.Label
$lblThrottleMinutes.Text = "Throttle (minutes):"
$lblThrottleMinutes.Location = New-Object System.Drawing.Point(280, 70)
$lblThrottleMinutes.AutoSize = $true
$lblThrottleMinutes.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpNotifications.Controls.Add($lblThrottleMinutes)

$txtThrottleMinutes = New-Object System.Windows.Forms.TextBox
$txtThrottleMinutes.Location = New-Object System.Drawing.Point(400, 68)
$txtThrottleMinutes.Size = New-Object System.Drawing.Size(80, 28)
$txtThrottleMinutes.Text = "30"
$grpNotifications.Controls.Add($txtThrottleMinutes)

$chkIncludeDashboardLink = New-Object System.Windows.Forms.CheckBox
$chkIncludeDashboardLink.Text = "Include Dashboard Link"
$chkIncludeDashboardLink.Location = New-Object System.Drawing.Point(20, 110)
$chkIncludeDashboardLink.Size = New-Object System.Drawing.Size(200, 28)
$chkIncludeDashboardLink.Checked = $true
$grpNotifications.Controls.Add($chkIncludeDashboardLink)

$lblDashboardURL = New-Object System.Windows.Forms.Label
$lblDashboardURL.Text = "Dashboard URL:"
$lblDashboardURL.Location = New-Object System.Drawing.Point(20, 150)
$lblDashboardURL.AutoSize = $true
$lblDashboardURL.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpNotifications.Controls.Add($lblDashboardURL)

$txtDashboardURL = New-Object System.Windows.Forms.TextBox
$txtDashboardURL.Location = New-Object System.Drawing.Point(140, 148)
$txtDashboardURL.Size = New-Object System.Drawing.Size(480, 28)
$txtDashboardURL.Text = "http://localhost:8080"
$grpNotifications.Controls.Add($txtDashboardURL)

$chkQuietHours = New-Object System.Windows.Forms.CheckBox
$chkQuietHours.Text = "Enable Quiet Hours"
$chkQuietHours.Location = New-Object System.Drawing.Point(20, 190)
$chkQuietHours.Size = New-Object System.Drawing.Size(150, 28)
$chkQuietHours.Checked = $false
$grpNotifications.Controls.Add($chkQuietHours)

$lblQuietStart = New-Object System.Windows.Forms.Label
$lblQuietStart.Text = "Start:"
$lblQuietStart.Location = New-Object System.Drawing.Point(180, 195)
$lblQuietStart.AutoSize = $true
$lblQuietStart.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpNotifications.Controls.Add($lblQuietStart)

$txtQuietStart = New-Object System.Windows.Forms.TextBox
$txtQuietStart.Location = New-Object System.Drawing.Point(220, 193)
$txtQuietStart.Size = New-Object System.Drawing.Size(80, 28)
$txtQuietStart.Text = "22:00"
$grpNotifications.Controls.Add($txtQuietStart)

$lblQuietEnd = New-Object System.Windows.Forms.Label
$lblQuietEnd.Text = "End:"
$lblQuietEnd.Location = New-Object System.Drawing.Point(320, 195)
$lblQuietEnd.AutoSize = $true
$lblQuietEnd.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpNotifications.Controls.Add($lblQuietEnd)

$txtQuietEnd = New-Object System.Windows.Forms.TextBox
$txtQuietEnd.Location = New-Object System.Drawing.Point(350, 193)
$txtQuietEnd.Size = New-Object System.Drawing.Size(80, 28)
$txtQuietEnd.Text = "07:00"
$grpNotifications.Controls.Add($txtQuietEnd)

# Recipients Group
$grpRecipients = New-Object System.Windows.Forms.GroupBox
$grpRecipients.Text = "Email Recipients"
$grpRecipients.Location = New-Object System.Drawing.Point(690, 50)
$grpRecipients.Size = New-Object System.Drawing.Size(650, 200)
$tabNotifications.Controls.Add($grpRecipients)

$lblRecipients = New-Object System.Windows.Forms.Label
$lblRecipients.Text = "Recipients (one per line):"
$lblRecipients.Location = New-Object System.Drawing.Point(20, 30)
$lblRecipients.AutoSize = $true
$lblRecipients.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpRecipients.Controls.Add($lblRecipients)

$txtRecipients = New-Object System.Windows.Forms.TextBox
$txtRecipients.Location = New-Object System.Drawing.Point(20, 60)
$txtRecipients.Size = New-Object System.Drawing.Size(600, 120)
$txtRecipients.Multiline = $true
$txtRecipients.ScrollBars = "Vertical"
$grpRecipients.Controls.Add($txtRecipients)

# Teams Integration Group
$grpTeams = New-Object System.Windows.Forms.GroupBox
$grpTeams.Text = "Microsoft Teams Integration"
$grpTeams.Location = New-Object System.Drawing.Point(690, 270)
$grpTeams.Size = New-Object System.Drawing.Size(650, 150)
$tabNotifications.Controls.Add($grpTeams)

$chkTeamsEnabled = New-Object System.Windows.Forms.CheckBox
$chkTeamsEnabled.Text = "Enable Teams Notifications"
$chkTeamsEnabled.Location = New-Object System.Drawing.Point(20, 30)
$chkTeamsEnabled.Size = New-Object System.Drawing.Size(200, 28)
$chkTeamsEnabled.Checked = $true
$grpTeams.Controls.Add($chkTeamsEnabled)

$lblWebhookURL = New-Object System.Windows.Forms.Label
$lblWebhookURL.Text = "Webhook URL:"
$lblWebhookURL.Location = New-Object System.Drawing.Point(20, 70)
$lblWebhookURL.AutoSize = $true
$lblWebhookURL.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$grpTeams.Controls.Add($lblWebhookURL)

$txtWebhookURL = New-Object System.Windows.Forms.TextBox
$txtWebhookURL.Location = New-Object System.Drawing.Point(140, 68)
$txtWebhookURL.Size = New-Object System.Drawing.Size(480, 28)
$txtWebhookURL.Text = "https://outlook.office.com/webhook/YOUR-WEBHOOK-URL-HERE"
$grpTeams.Controls.Add($txtWebhookURL)

# Buttons
$btnSaveNotifications = New-Object System.Windows.Forms.Button
$btnSaveNotifications.Text = "Save Configuration"
$btnSaveNotifications.Location = New-Object System.Drawing.Point(690, 450)
$btnSaveNotifications.Size = New-Object System.Drawing.Size(150, 32)
$tabNotifications.Controls.Add($btnSaveNotifications)

$btnReloadNotifications = New-Object System.Windows.Forms.Button
$btnReloadNotifications.Text = "Reload Configuration"
$btnReloadNotifications.Location = New-Object System.Drawing.Point(860, 450)
$btnReloadNotifications.Size = New-Object System.Drawing.Size(150, 32)
$tabNotifications.Controls.Add($btnReloadNotifications)

$btnTestEmail = New-Object System.Windows.Forms.Button
$btnTestEmail.Text = "Send Test Email"
$btnTestEmail.Location = New-Object System.Drawing.Point(1020, 450)
$btnTestEmail.Size = New-Object System.Drawing.Size(150, 32)
$tabNotifications.Controls.Add($btnTestEmail)

$btnTestTeams = New-Object System.Windows.Forms.Button
$btnTestTeams.Text = "Send Test Teams Message"
$btnTestTeams.Location = New-Object System.Drawing.Point(1180, 450)
$btnTestTeams.Size = New-Object System.Drawing.Size(160, 32)
$tabNotifications.Controls.Add($btnTestTeams)

function Get-NotificationsConfigPath {
    return Join-Path (Split-Path -Parent $PSScriptRoot) "Config\notifications.json"
}

function Load-NotificationsConfig {
    $path = Get-NotificationsConfigPath
    if (-not (Test-Path $path)) {
        return @{
            SMTP = @{
                Server = ""
                Port = 587
                EnableSSL = $true
                From = ""
                Username = ""
                Password = ""
                UseDefaultCredentials = $true
            }
            Notifications = @{
                Enabled = $true
                Recipients = @()
                CCRecipients = @()
                MinSeverity = "Warning"
                QuietHours = @{
                    Enabled = $false
                    Start = "22:00"
                    End = "07:00"
                }
                ThrottleMinutes = 30
                IncludeDashboardLink = $true
                DashboardURL = "http://localhost:8080"
            }
            Teams = @{
                Enabled = $true
                WebhookURL = "https://outlook.office.com/webhook/YOUR-WEBHOOK-URL-HERE"
            }
        }
    }

    $json = Get-Content $path -Raw
    if ([string]::IsNullOrWhiteSpace($json)) {
        return Load-NotificationsConfig  # Return default if empty
    }

    return $json | ConvertFrom-Json
}

function Save-NotificationsConfig {
    param([Parameter(Mandatory = $true)]$Config)

    $path = Get-NotificationsConfigPath
    $json = $Config | ConvertTo-Json -Depth 5
    $json | Set-Content -Path $path -Encoding UTF8
}

function Refresh-NotificationsConfig {
    $config = Load-NotificationsConfig

    # SMTP Settings
    $txtSMTPServer.Text = $config.SMTP.Server
    $txtSMTPPort.Text = [string]$config.SMTP.Port
    $txtSMTPFrom.Text = $config.SMTP.From
    $chkSMTPSSL.Checked = [bool]$config.SMTP.EnableSSL
    $chkSMTPDefaultCreds.Checked = [bool]$config.SMTP.UseDefaultCredentials
    $txtSMTPUsername.Text = $config.SMTP.Username
    $txtSMTPPassword.Text = $config.SMTP.Password

    # Notification Settings
    $chkNotificationsEnabled.Checked = [bool]$config.Notifications.Enabled
    $cbMinSeverity.SelectedItem = $config.Notifications.MinSeverity
    $txtThrottleMinutes.Text = [string]$config.Notifications.ThrottleMinutes
    $chkIncludeDashboardLink.Checked = [bool]$config.Notifications.IncludeDashboardLink
    $txtDashboardURL.Text = $config.Notifications.DashboardURL
    $chkQuietHours.Checked = [bool]$config.Notifications.QuietHours.Enabled
    $txtQuietStart.Text = $config.Notifications.QuietHours.Start
    $txtQuietEnd.Text = $config.Notifications.QuietHours.End

    # Recipients
    $txtRecipients.Text = ($config.Notifications.Recipients -join "`r`n")

    # Teams
    $chkTeamsEnabled.Checked = [bool]$config.Teams.Enabled
    $txtWebhookURL.Text = $config.Teams.WebhookURL
}

function Save-NotificationsConfigFromUI {
    $config = @{
        SMTP = @{
            Server = $txtSMTPServer.Text.Trim()
            Port = [int]$txtSMTPPort.Text
            EnableSSL = $chkSMTPSSL.Checked
            From = $txtSMTPFrom.Text.Trim()
            Username = $txtSMTPUsername.Text.Trim()
            Password = $txtSMTPPassword.Text
            UseDefaultCredentials = $chkSMTPDefaultCreds.Checked
        }
        Notifications = @{
            Enabled = $chkNotificationsEnabled.Checked
            Recipients = ($txtRecipients.Text -split "`r`n" | Where-Object { $_ -and $_.Trim() } | ForEach-Object { $_.Trim() })
            CCRecipients = @()
            MinSeverity = $cbMinSeverity.SelectedItem
            QuietHours = @{
                Enabled = $chkQuietHours.Checked
                Start = $txtQuietStart.Text.Trim()
                End = $txtQuietEnd.Text.Trim()
            }
            ThrottleMinutes = [int]$txtThrottleMinutes.Text
            IncludeDashboardLink = $chkIncludeDashboardLink.Checked
            DashboardURL = $txtDashboardURL.Text.Trim()
        }
        Teams = @{
            Enabled = $chkTeamsEnabled.Checked
            WebhookURL = $txtWebhookURL.Text.Trim()
        }
    }

    Save-NotificationsConfig -Config $config
    [System.Windows.Forms.MessageBox]::Show(
        "Notification configuration saved.",
        "Saved",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Reload-NotificationsConfigFromUI {
    Refresh-NotificationsConfig
}

function Send-TestEmail {
    try {
        $lblCollectorStatus.Text = "Status: Sending test email..."
        
        # Load notification configuration
        $configPath = Join-Path (Split-Path -Parent $PSScriptRoot) "Config\notifications.json"
        if (-not (Test-Path $configPath)) {
            throw "Notification configuration not found at: $configPath"
        }

        $notificationConfig = Get-Content -Path $configPath -Raw | ConvertFrom-Json

        # Validate email is enabled
        if (-not $notificationConfig.Notifications.Enabled) {
            throw "Email notifications are not enabled in configuration"
        }

        # Validate SMTP server is configured
        if ([string]::IsNullOrWhiteSpace($notificationConfig.SMTP.Server)) {
            throw "SMTP server is not configured"
        }

        # Validate recipient is configured
        if ([string]::IsNullOrWhiteSpace($notificationConfig.Notifications.Recipients)) {
            throw "Recipient email address is not configured"
        }

        # Build email parameters
        $testTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $subject = "[SQL Monitor Test] Email Notification Test - $testTime"
        
        $body = @"
<html>
<body style="font-family: Segoe UI, Arial, sans-serif;">
    <h2 style="color: #0078d4;">SQL Monitor Test Email</h2>
    <p>This is a test email from SQL Monitor Dashboard.</p>
    <table style="border-collapse: collapse; width: 100%; max-width: 600px;">
        <tr style="background-color: #f3f3f3;">
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Test Time</td>
            <td style="border: 1px solid #ddd; padding: 8px;">$testTime</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">Status</td>
            <td style="border: 1px solid #ddd; padding: 8px;">OK - Email system is working correctly</td>
        </tr>
        <tr style="background-color: #f3f3f3;">
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">SMTP Server</td>
            <td style="border: 1px solid #ddd; padding: 8px;">$($notificationConfig.SMTP.Server):$($notificationConfig.SMTP.Port)</td>
        </tr>
        <tr>
            <td style="border: 1px solid #ddd; padding: 8px; font-weight: bold;">From</td>
            <td style="border: 1px solid #ddd; padding: 8px;">$($notificationConfig.SMTP.From)</td>
        </tr>
    </table>
    <p style="margin-top: 20px; color: #666; font-size: 12px;">
        This is an automated test message. No action is required.
    </p>
</body>
</html>
"@

        Send-SqlMonitorEmail `
            -SmtpConfig $notificationConfig.SMTP `
            -To $notificationConfig.Notifications.Recipients `
            -Cc $notificationConfig.Notifications.CCRecipients `
            -Subject $subject `
            -Body $body `
            -BodyAsHtml

        $lblCollectorStatus.Text = "Status: Test email sent successfully"
        [System.Windows.Forms.MessageBox]::Show(
            "Test email sent successfully to: $($notificationConfig.Notifications.Recipients)",
            "Email Test Success",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        $lblCollectorStatus.Text = "Status: Test email failed"
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to send test email: $(Get-SqlMonitorExceptionMessage -Exception $_.Exception)",
            "Email Test Failed",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Send-TestTeamsMessage {
    try {
        $lblCollectorStatus.Text = "Status: Sending test Teams message..."
        
        # Load notification configuration
        $configPath = Join-Path (Split-Path -Parent $PSScriptRoot) "Config\notifications.json"
        if (-not (Test-Path $configPath)) {
            throw "Notification configuration not found at: $configPath"
        }

        $notificationConfig = Get-Content -Path $configPath -Raw | ConvertFrom-Json

        # Validate Teams is enabled
        if (-not $notificationConfig.Teams.Enabled) {
            throw "Teams notifications are not enabled in configuration"
        }

        # Validate webhook URL is configured
        $webhookUrl = [string]$notificationConfig.Teams.WebhookURL
        if ([string]::IsNullOrWhiteSpace($webhookUrl) -or $webhookUrl -like '*YOUR-WEBHOOK-URL-HERE*') {
            throw "Teams webhook URL is not properly configured"
        }

        # Build Teams message
        $testTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        
        $body = @{
            "@type" = "MessageCard"
            "@context" = "http://schema.org/extensions"
            "themeColor" = "0078d4"
            "summary" = "SQL Monitor Test Notification"
            "sections" = @(
                @{
                    "activityTitle" = "SQL Monitor Test Notification"
                    "activitySubtitle" = "Webhook Configuration Test"
                    "facts" = @(
                        @{ "name" = "Test Time"; "value" = $testTime }
                        @{ "name" = "Status"; "value" = "OK - Teams integration is working" }
                        @{ "name" = "Message Type"; "value" = "Configuration Test" }
                    )
                    "text" = "This is a test message from SQL Monitor Dashboard to verify Teams webhook integration."
                }
            )
            "potentialAction" = @(
                @{
                    "@type" = "OpenUri"
                    "name" = "View Dashboard"
                    "targets" = @(@{ "os" = "default"; "uri" = $notificationConfig.Notifications.DashboardURL })
                }
            )
        } | ConvertTo-Json -Depth 4

        # Send the test message to Teams
        $response = Invoke-RestMethod -Uri $webhookUrl -Method Post -Body $body -ContentType 'application/json' -ErrorAction Stop

        $lblCollectorStatus.Text = "Status: Test Teams message sent successfully"
        [System.Windows.Forms.MessageBox]::Show(
            "Test Teams message sent successfully to webhook.",
            "Teams Test Success",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        $lblCollectorStatus.Text = "Status: Test Teams message failed"
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to send test Teams message: $($_.Exception.Message)",
            "Teams Test Failed",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

# ------------------------------------------------------------
# Alert thresholds tab controls
$lblThresholdsHeader = New-Object System.Windows.Forms.Label
$lblThresholdsHeader.Text = "Configure alert thresholds"
$lblThresholdsHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblThresholdsHeader.AutoSize = $true
$lblThresholdsHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabThresholds.Controls.Add($lblThresholdsHeader)

$dgvThresholds = New-Object System.Windows.Forms.DataGridView
$dgvThresholds.Location = New-Object System.Drawing.Point(20, 60)
$dgvThresholds.Size = New-Object System.Drawing.Size(1320, 400)
$dgvThresholds.ReadOnly = $true
$dgvThresholds.AllowUserToAddRows = $false
$dgvThresholds.AllowUserToDeleteRows = $false
$dgvThresholds.AutoSizeColumnsMode = "Fill"
$dgvThresholds.SelectionMode = "FullRowSelect"
$tabThresholds.Controls.Add($dgvThresholds)

$lblThresholdModule = New-Object System.Windows.Forms.Label
$lblThresholdModule.Text = "Module:"
$lblThresholdModule.Location = New-Object System.Drawing.Point(20, 480)
$lblThresholdModule.AutoSize = $true
$lblThresholdModule.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabThresholds.Controls.Add($lblThresholdModule)

$txtThresholdModule = New-Object System.Windows.Forms.TextBox
$txtThresholdModule.Location = New-Object System.Drawing.Point(140, 478)
$txtThresholdModule.Size = New-Object System.Drawing.Size(200, 28)
$txtThresholdModule.ReadOnly = $true
$tabThresholds.Controls.Add($txtThresholdModule)

$lblThresholdMetric = New-Object System.Windows.Forms.Label
$lblThresholdMetric.Text = "Metric:"
$lblThresholdMetric.Location = New-Object System.Drawing.Point(360, 480)
$lblThresholdMetric.AutoSize = $true
$lblThresholdMetric.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabThresholds.Controls.Add($lblThresholdMetric)

$txtThresholdMetric = New-Object System.Windows.Forms.TextBox
$txtThresholdMetric.Location = New-Object System.Drawing.Point(420, 478)
$txtThresholdMetric.Size = New-Object System.Drawing.Size(200, 28)
$txtThresholdMetric.ReadOnly = $true
$tabThresholds.Controls.Add($txtThresholdMetric)

$lblWarningValue = New-Object System.Windows.Forms.Label
$lblWarningValue.Text = "Warning:"
$lblWarningValue.Location = New-Object System.Drawing.Point(20, 520)
$lblWarningValue.AutoSize = $true
$lblWarningValue.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabThresholds.Controls.Add($lblWarningValue)

$txtWarningValue = New-Object System.Windows.Forms.TextBox
$txtWarningValue.Location = New-Object System.Drawing.Point(140, 518)
$txtWarningValue.Size = New-Object System.Drawing.Size(120, 28)
$tabThresholds.Controls.Add($txtWarningValue)

$lblCriticalValue = New-Object System.Windows.Forms.Label
$lblCriticalValue.Text = "Critical:"
$lblCriticalValue.Location = New-Object System.Drawing.Point(280, 520)
$lblCriticalValue.AutoSize = $true
$lblCriticalValue.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabThresholds.Controls.Add($lblCriticalValue)

$txtCriticalValue = New-Object System.Windows.Forms.TextBox
$txtCriticalValue.Location = New-Object System.Drawing.Point(340, 518)
$txtCriticalValue.Size = New-Object System.Drawing.Size(120, 28)
$tabThresholds.Controls.Add($txtCriticalValue)

$lblComparisonType = New-Object System.Windows.Forms.Label
$lblComparisonType.Text = "Comparison:"
$lblComparisonType.Location = New-Object System.Drawing.Point(480, 520)
$lblComparisonType.AutoSize = $true
$lblComparisonType.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabThresholds.Controls.Add($lblComparisonType)

$cbComparisonType = New-Object System.Windows.Forms.ComboBox
$cbComparisonType.Items.AddRange(@("GreaterThan", "LessThan", "Equal", "NotEqual"))
$cbComparisonType.DropDownStyle = "DropDownList"
$cbComparisonType.Location = New-Object System.Drawing.Point(570, 518)
$cbComparisonType.Size = New-Object System.Drawing.Size(120, 32)
$tabThresholds.Controls.Add($cbComparisonType)

$lblCooldownMinutes = New-Object System.Windows.Forms.Label
$lblCooldownMinutes.Text = "Cooldown (min):"
$lblCooldownMinutes.Location = New-Object System.Drawing.Point(20, 560)
$lblCooldownMinutes.AutoSize = $true
$lblCooldownMinutes.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$tabThresholds.Controls.Add($lblCooldownMinutes)

$txtCooldownMinutes = New-Object System.Windows.Forms.TextBox
$txtCooldownMinutes.Location = New-Object System.Drawing.Point(140, 558)
$txtCooldownMinutes.Size = New-Object System.Drawing.Size(80, 28)
$tabThresholds.Controls.Add($txtCooldownMinutes)

$chkThresholdActive = New-Object System.Windows.Forms.CheckBox
$chkThresholdActive.Text = "Active"
$chkThresholdActive.Location = New-Object System.Drawing.Point(240, 560)
$chkThresholdActive.Size = New-Object System.Drawing.Size(100, 28)
$chkThresholdActive.Checked = $true
$tabThresholds.Controls.Add($chkThresholdActive)

$btnSaveThreshold = New-Object System.Windows.Forms.Button
$btnSaveThreshold.Text = "Save Threshold"
$btnSaveThreshold.Location = New-Object System.Drawing.Point(580, 516)
$btnSaveThreshold.Size = New-Object System.Drawing.Size(120, 32)
$tabThresholds.Controls.Add($btnSaveThreshold)

$btnReloadThresholds = New-Object System.Windows.Forms.Button
$btnReloadThresholds.Text = "Reload Thresholds"
$btnReloadThresholds.Location = New-Object System.Drawing.Point(720, 516)
$btnReloadThresholds.Size = New-Object System.Drawing.Size(120, 32)
$tabThresholds.Controls.Add($btnReloadThresholds)

$btnRunAlertEngine = New-Object System.Windows.Forms.Button
$btnRunAlertEngine.Text = "Run Alert Engine Now"
$btnRunAlertEngine.Location = New-Object System.Drawing.Point(860, 516)
$btnRunAlertEngine.Size = New-Object System.Drawing.Size(150, 32)
$tabThresholds.Controls.Add($btnRunAlertEngine)

function Load-AlertThresholds {
    $query = @"
SELECT
    ThresholdID,
    ModuleName,
    MetricName,
    WarningValue,
    CriticalValue,
    ComparisonType,
    CooldownMinutes,
    IsActive
FROM mon.AlertThresholds
ORDER BY ModuleName, MetricName;
"@

    $dt = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
    $dgvThresholds.DataSource = $dt
}

function Load-SelectedThreshold {
    if ($dgvThresholds.SelectedRows.Count -eq 0) {
        return
    }

    $row = $dgvThresholds.SelectedRows[0]
    $txtThresholdModule.Text = [string]$row.Cells["ModuleName"].Value
    $txtThresholdMetric.Text = [string]$row.Cells["MetricName"].Value
    $txtWarningValue.Text = [string]$row.Cells["WarningValue"].Value
    $txtCriticalValue.Text = [string]$row.Cells["CriticalValue"].Value
    $cbComparisonType.SelectedItem = [string]$row.Cells["ComparisonType"].Value
    $txtCooldownMinutes.Text = [string]$row.Cells["CooldownMinutes"].Value
    $chkThresholdActive.Checked = [bool]$row.Cells["IsActive"].Value
}

function Save-SelectedThreshold {
    if ($dgvThresholds.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select a threshold to update.",
            "Select Threshold",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $thresholdId = [int]$dgvThresholds.SelectedRows[0].Cells["ThresholdID"].Value
    $warningValue = [decimal]$txtWarningValue.Text
    $criticalValue = [decimal]$txtCriticalValue.Text
    $comparisonType = $cbComparisonType.SelectedItem
    $cooldownMinutes = [int]$txtCooldownMinutes.Text
    $isActive = $chkThresholdActive.Checked

    $query = @"
UPDATE mon.AlertThresholds
SET WarningValue = $warningValue,
    CriticalValue = $criticalValue,
    ComparisonType = '$comparisonType',
    CooldownMinutes = $cooldownMinutes,
    IsActive = $(if ($isActive) { 1 } else { 0 })
WHERE ThresholdID = $thresholdId;
"@

    Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query | Out-Null

    Load-AlertThresholds
    [System.Windows.Forms.MessageBox]::Show(
        "Threshold updated successfully.",
        "Saved",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Reload-AlertThresholds {
    Load-AlertThresholds
}

function Run-AlertEngineNow {
    $lblCollectorStatus.Text = "Status: Running alert engine..."

    try {
        $alertEnginePath = Join-Path (Split-Path -Parent $PSScriptRoot) "Jobs\Run-AlertEngine.ps1"
        if (-not (Test-Path $alertEnginePath)) {
            throw "Alert engine script not found at: $alertEnginePath"
        }

        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = "powershell.exe"
        $startInfo.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$alertEnginePath`""
        $startInfo.UseShellExecute = $false
        $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardOutput = $true
        $startInfo.RedirectStandardError = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $startInfo
        $process.Start() | Out-Null

        $output = $process.StandardOutput.ReadToEnd()
        $errorOutput = $process.StandardError.ReadToEnd()
        $process.WaitForExit()

        if ($process.ExitCode -eq 0) {
            $lblCollectorStatus.Text = "Status: Alert engine completed successfully"
            [System.Windows.Forms.MessageBox]::Show(
                "Alert engine completed successfully.`r`nOutput: $output",
                "Alert Engine Complete",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
        else {
            $lblCollectorStatus.Text = "Status: Alert engine failed"
            [System.Windows.Forms.MessageBox]::Show(
                "Alert engine failed.`r`nError: $errorOutput",
                "Alert Engine Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    }
    catch {
        $lblCollectorStatus.Text = "Status: Alert engine failed"
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to run alert engine: $($_.Exception.Message)",
            "Alert Engine Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

# ------------------------------------------------------------
# Alert history tab controls
$lblAlertHistoryHeader = New-Object System.Windows.Forms.Label
$lblAlertHistoryHeader.Text = "Alert history and management"
$lblAlertHistoryHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblAlertHistoryHeader.AutoSize = $true
$lblAlertHistoryHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabAlertHistory.Controls.Add($lblAlertHistoryHeader)

$lblHistoryFilter = New-Object System.Windows.Forms.Label
$lblHistoryFilter.Text = "Filter:"
$lblHistoryFilter.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblHistoryFilter.AutoSize = $true
$lblHistoryFilter.Location = New-Object System.Drawing.Point(20, 50)
$tabAlertHistory.Controls.Add($lblHistoryFilter)

$cbHistorySeverity = New-Object System.Windows.Forms.ComboBox
$cbHistorySeverity.Items.AddRange(@("All", "Critical", "Warning", "Info"))
$cbHistorySeverity.DropDownStyle = "DropDownList"
$cbHistorySeverity.Location = New-Object System.Drawing.Point(70, 48)
$cbHistorySeverity.Size = New-Object System.Drawing.Size(100, 32)
$cbHistorySeverity.SelectedIndex = 0
$tabAlertHistory.Controls.Add($cbHistorySeverity)

$lblHistoryInstance = New-Object System.Windows.Forms.Label
$lblHistoryInstance.Text = "Instance:"
$lblHistoryInstance.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblHistoryInstance.AutoSize = $true
$lblHistoryInstance.Location = New-Object System.Drawing.Point(180, 50)
$tabAlertHistory.Controls.Add($lblHistoryInstance)

$cbHistoryInstance = New-Object System.Windows.Forms.ComboBox
$cbHistoryInstance.DropDownStyle = "DropDownList"
$cbHistoryInstance.Location = New-Object System.Drawing.Point(250, 48)
$cbHistoryInstance.Size = New-Object System.Drawing.Size(200, 32)
$tabAlertHistory.Controls.Add($cbHistoryInstance)

$chkHistoryAcknowledged = New-Object System.Windows.Forms.CheckBox
$chkHistoryAcknowledged.Text = "Show acknowledged"
$chkHistoryAcknowledged.Location = New-Object System.Drawing.Point(470, 50)
$chkHistoryAcknowledged.Size = New-Object System.Drawing.Size(150, 28)
$chkHistoryAcknowledged.Checked = $true
$tabAlertHistory.Controls.Add($chkHistoryAcknowledged)

    # -------------------------------------------------
    # Multi‑select alert list + Bulk Acknowledge button (admin only)
    # -------------------------------------------------
    $lstAlerts = New-Object System.Windows.Forms.ListView
    $lstAlerts.View = [System.Windows.Forms.View]::Details
    $lstAlerts.CheckBoxes = $true
    $lstAlerts.FullRowSelect = $true
    $lstAlerts.MultiSelect = $true
    $lstAlerts.Location = New-Object System.Drawing.Point(20, 90)
    $lstAlerts.Size = New-Object System.Drawing.Size(1320, 200)
    $lstAlerts.Columns.Add('AlertID',120) | Out-Null
    $lstAlerts.Columns.Add('Message',800) | Out-Null
    $lstAlerts.Columns.Add('CreatedAt',200) | Out-Null
    $tabAlertHistory.Controls.Add($lstAlerts)

    $btnBulkAck = New-Object System.Windows.Forms.Button
    $btnBulkAck.Text = 'Bulk Acknowledge'
    $btnBulkAck.Location = New-Object System.Drawing.Point(20, 300)
    $btnBulkAck.Size = New-Object System.Drawing.Size(150,30)
    $tabAlertHistory.Controls.Add($btnBulkAck)

    # Enable only for Admins
    if ($script:currentUserRole -eq 'Admin') {
        $btnBulkAck.Enabled = $true
    } else {
        $btnBulkAck.Enabled = $false
    }

    $btnBulkAck.Add_Click({
        $selectedIds = @()
        foreach ($item in $lstAlerts.CheckedItems) {
            $selectedIds += $item.SubItems[0].Text
        }
        if ($selectedIds.Count -eq 0) {
            Show-Notification -Message 'No alerts selected.' -Type Warning -Title 'Bulk Acknowledge'
            return
        }
        foreach ($id in $selectedIds) {
            # Re‑use existing Acknowledge‑Alert function (expects -AlertID parameter)
            Acknowledge-Alert -AlertID $id
        }
        Show-Notification -Message "Acknowledged $($selectedIds.Count) alerts." -Type Info -Title 'Bulk Acknowledge'
        # Refresh the alert list if a refresh routine exists
        if (Get-Command Refresh-AlertHistory -ErrorAction SilentlyContinue) { Refresh-AlertHistory }
    })

$btnLoadAlertHistory = New-Object System.Windows.Forms.Button
$btnLoadAlertHistory.Text = "Load History"
$btnLoadAlertHistory.Location = New-Object System.Drawing.Point(640, 46)
$btnLoadAlertHistory.Size = New-Object System.Drawing.Size(100, 32)
$tabAlertHistory.Controls.Add($btnLoadAlertHistory)

$dgvAlertHistory = New-Object System.Windows.Forms.DataGridView
$dgvAlertHistory.Location = New-Object System.Drawing.Point(20, 90)
$dgvAlertHistory.Size = New-Object System.Drawing.Size(1320, 400)
$dgvAlertHistory.ReadOnly = $true
$dgvAlertHistory.AllowUserToAddRows = $false
$dgvAlertHistory.AllowUserToDeleteRows = $false
$dgvAlertHistory.AutoSizeColumnsMode = "Fill"
$dgvAlertHistory.SelectionMode = "FullRowSelect"
$tabAlertHistory.Controls.Add($dgvAlertHistory)

$lblSelectedAlertDetails = New-Object System.Windows.Forms.Label
$lblSelectedAlertDetails.Text = "Alert Details:"
$lblSelectedAlertDetails.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblSelectedAlertDetails.AutoSize = $true
$lblSelectedAlertDetails.Location = New-Object System.Drawing.Point(20, 510)
$tabAlertHistory.Controls.Add($lblSelectedAlertDetails)

$txtAlertDetails = New-Object System.Windows.Forms.TextBox
$txtAlertDetails.Location = New-Object System.Drawing.Point(20, 535)
$txtAlertDetails.Size = New-Object System.Drawing.Size(1320, 80)
$txtAlertDetails.Multiline = $true
$txtAlertDetails.ReadOnly = $true
$txtAlertDetails.ScrollBars = "Vertical"
$tabAlertHistory.Controls.Add($txtAlertDetails)

$btnAcknowledgeSelectedHistory = New-Object System.Windows.Forms.Button
$btnAcknowledgeSelectedHistory.Text = "Acknowledge Selected"
$btnAcknowledgeSelectedHistory.Location = New-Object System.Drawing.Point(20, 630)
$btnAcknowledgeSelectedHistory.Size = New-Object System.Drawing.Size(150, 32)
$tabAlertHistory.Controls.Add($btnAcknowledgeSelectedHistory)

$btnBulkAcknowledge = New-Object System.Windows.Forms.Button
$btnBulkAcknowledge.Text = "Bulk Acknowledge All"
$btnBulkAcknowledge.Location = New-Object System.Drawing.Point(180, 630)
$btnBulkAcknowledge.Size = New-Object System.Drawing.Size(150, 32)
$tabAlertHistory.Controls.Add($btnBulkAcknowledge)

$btnExportAlerts = New-Object System.Windows.Forms.Button
$btnExportAlerts.Text = "Export to CSV"
$btnExportAlerts.Location = New-Object System.Drawing.Point(340, 630)
$btnExportAlerts.Size = New-Object System.Drawing.Size(120, 32)
$tabAlertHistory.Controls.Add($btnExportAlerts)

$btnClearAlertHistory = New-Object System.Windows.Forms.Button
$btnClearAlertHistory.Text = "Clear Alert History"
$btnClearAlertHistory.Location = New-Object System.Drawing.Point(480, 630)
$btnClearAlertHistory.Size = New-Object System.Drawing.Size(150, 32)
$tabAlertHistory.Controls.Add($btnClearAlertHistory)

$lblAlertStats = New-Object System.Windows.Forms.Label
$lblAlertStats.Text = "Statistics: Loading..."
$lblAlertStats.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$lblAlertStats.AutoSize = $true
$lblAlertStats.Location = New-Object System.Drawing.Point(480, 635)
$tabAlertHistory.Controls.Add($lblAlertStats)

function Load-AlertHistory {
    $severityFilter = $cbHistorySeverity.SelectedItem
    $instanceFilter = $cbHistoryInstance.SelectedItem
    $showAcknowledged = $chkHistoryAcknowledged.Checked

    $whereClause = ""
    if (Test-CurrentUserRequiresAssignedInstanceAccess) {
        $allowedIds = @(Get-CurrentUserAccessIds)
        $allowedList = if ($allowedIds.Count -gt 0) { $allowedIds -join "," } else { "-1" }
        $whereClause += " AND InstanceID IN ($allowedList)"
    }
    if ($null -ne $severityFilter -and $severityFilter -ne "All") {
        $whereClause += " AND Severity = '$severityFilter'"
    }
    if ($instanceFilter -and $instanceFilter.DisplayName -and $instanceFilter.DisplayName -ne "All Instances") {
        $instanceId = $instanceFilter.InstanceID
        if ($null -ne $instanceId) {
            $whereClause += " AND InstanceID = $instanceId"
        }
    }
    if (-not $showAcknowledged) {
        $whereClause += " AND IsAcknowledged = 0"
    }

    $query = @"
SELECT TOP 1000
    AlertID,
    DisplayName,
    AlertTime,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    AcknowledgedTime,
    AcknowledgedBy,
    DATEDIFF(MINUTE, AlertTime, GETDATE()) as AgeMinutes
FROM mon.vw_AlertHistoryDetailed
WHERE 1=1$whereClause
ORDER BY AlertTime DESC;
"@

    $dt = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
    $dgvAlertHistory.DataSource = $dt

    # Color code rows by severity
    foreach ($gridRow in $dgvAlertHistory.Rows) {
        if ($gridRow.Cells["Severity"].Value -eq "Critical") {
            $gridRow.DefaultCellStyle.BackColor = [System.Drawing.Color]::MistyRose
            $gridRow.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
        }
        elseif ($gridRow.Cells["Severity"].Value -eq "Warning") {
            $gridRow.DefaultCellStyle.BackColor = [System.Drawing.Color]::LemonChiffon
            $gridRow.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
        }
    }

    Update-AlertStatistics
}

function Update-AlertStatistics {
    $accessClause = ""
    if (Test-CurrentUserRequiresAssignedInstanceAccess) {
        $allowedIds = @(Get-CurrentUserAccessIds)
        $allowedList = if ($allowedIds.Count -gt 0) { $allowedIds -join "," } else { "-1" }
        $accessClause = " AND InstanceID IN ($allowedList)"
    }

    $query = @"
SELECT
    COUNT(*) as TotalAlerts,
    SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) as CriticalCount,
    SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) as WarningCount,
    SUM(CASE WHEN IsAcknowledged = 1 THEN 1 ELSE 0 END) as AcknowledgedCount,
    SUM(CASE WHEN IsAcknowledged = 0 THEN 1 ELSE 0 END) as UnacknowledgedCount
FROM mon.vw_AlertHistoryDetailed
WHERE AlertTime >= DATEADD(DAY, -7, GETDATE())$accessClause;
"@

    $stats = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
    if ($stats.Rows.Count -gt 0) {
        $row = $stats.Rows[0]
        $lblAlertStats.Text = "Last 7 days: $($row["TotalAlerts"]) total, $($row["CriticalCount"]) critical, $($row["WarningCount"]) warning, $($row["UnacknowledgedCount"]) unacknowledged"
    }
}

function Load-SelectedAlertHistory {
    if ($dgvAlertHistory.SelectedRows.Count -eq 0) {
        $txtAlertDetails.Text = ""
        return
    }

    $row = $dgvAlertHistory.SelectedRows[0]
    $details = [string]$row.Cells["AlertDetails"].Value
    $acknowledged = [bool]$row.Cells["IsAcknowledged"].Value
    $acknowledgedBy = [string]$row.Cells["AcknowledgedBy"].Value
    $acknowledgedTime = [string]$row.Cells["AcknowledgedTime"].Value

    $fullDetails = $details
    if ($acknowledged) {
        $fullDetails += "`r`n`r`nAcknowledged by: $acknowledgedBy at $acknowledgedTime"
    }

    $txtAlertDetails.Text = $fullDetails
}

function Acknowledge-SelectedAlertHistory {
    if ($dgvAlertHistory.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select an alert to acknowledge.",
            "Select Alert",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $alertId = [int64]$dgvAlertHistory.SelectedRows[0].Cells["AlertID"].Value
    $result = Acknowledge-Alert -AlertID $alertId

    if ($result) {
        Load-AlertHistory
        [System.Windows.Forms.MessageBox]::Show(
            "Alert acknowledged successfully.",
            "Acknowledged",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    else {
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to acknowledge alert.",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function BulkAcknowledgeAlerts {
    $result = [System.Windows.Forms.MessageBox]::Show(
        "This will acknowledge ALL unacknowledged alerts. Are you sure?",
        "Bulk Acknowledge",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )

    if ($result -ne [System.Windows.Forms.DialogResult]::Yes) {
        return
    }

    $query = @"
UPDATE mon.AlertHistory
SET IsAcknowledged = 1,
    AcknowledgedOn = SYSDATETIME(),
    AcknowledgedBy = 'Bulk Operation'
WHERE IsAcknowledged = 0;
"@

    Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query | Out-Null

    Load-AlertHistory
    Load-Alerts  # Refresh the main alerts tab too

    [System.Windows.Forms.MessageBox]::Show(
        "All unacknowledged alerts have been acknowledged.",
        "Bulk Operation Complete",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Export-AlertHistory {
    if ($dgvAlertHistory.Rows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "No alerts to export.",
            "Export",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $saveDialog = New-Object System.Windows.Forms.SaveFileDialog
    $saveDialog.Filter = "CSV files (*.csv)|*.csv"
    $saveDialog.Title = "Export Alert History"
    $saveDialog.FileName = "AlertHistory_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"

    if ($saveDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $csvPath = $saveDialog.FileName

        # Get data from DataGridView
        $data = @()
        foreach ($row in $dgvAlertHistory.Rows) {
            $data += [PSCustomObject]@{
                AlertID = $row.Cells["AlertID"].Value
                DisplayName = $row.Cells["DisplayName"].Value
                AlertTime = $row.Cells["AlertTime"].Value
                Severity = $row.Cells["Severity"].Value
                ModuleName = $row.Cells["ModuleName"].Value
                AlertTitle = $row.Cells["AlertTitle"].Value
                AlertDetails = $row.Cells["AlertDetails"].Value
                IsAcknowledged = $row.Cells["IsAcknowledged"].Value
                AcknowledgedTime = $row.Cells["AcknowledgedTime"].Value
                AcknowledgedBy = $row.Cells["AcknowledgedBy"].Value
                AgeMinutes = $row.Cells["AgeMinutes"].Value
            }
        }

        $data | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

        [System.Windows.Forms.MessageBox]::Show(
            "Alert history exported to: $csvPath",
            "Export Complete",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
}

function Clear-AlertHistory {
    # Create a form for user input
    $clearForm = New-Object System.Windows.Forms.Form
    $clearForm.Text = "Clear Alert History"
    $clearForm.Size = New-Object System.Drawing.Size(400, 200)
    $clearForm.StartPosition = "CenterParent"
    $clearForm.FormBorderStyle = "FixedDialog"
    $clearForm.MaximizeBox = $false
    $clearForm.MinimizeBox = $false

    $lblPrompt = New-Object System.Windows.Forms.Label
    $lblPrompt.Text = "Enter the number of days of alert history to keep:`r`n(Alerts older than this will be permanently deleted)"
    $lblPrompt.Location = New-Object System.Drawing.Point(20, 20)
    $lblPrompt.Size = New-Object System.Drawing.Size(350, 40)
    $lblPrompt.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $clearForm.Controls.Add($lblPrompt)

    $txtDays = New-Object System.Windows.Forms.TextBox
    $txtDays.Text = "90"
    $txtDays.Location = New-Object System.Drawing.Point(20, 70)
    $txtDays.Size = New-Object System.Drawing.Size(100, 28)
    $clearForm.Controls.Add($txtDays)

    $lblDays = New-Object System.Windows.Forms.Label
    $lblDays.Text = "days"
    $lblDays.Location = New-Object System.Drawing.Point(130, 73)
    $lblDays.AutoSize = $true
    $clearForm.Controls.Add($lblDays)

    $chkAcknowledgedOnly = New-Object System.Windows.Forms.CheckBox
    $chkAcknowledgedOnly.Text = "Clear only acknowledged alerts"
    $chkAcknowledgedOnly.Location = New-Object System.Drawing.Point(20, 110)
    $chkAcknowledgedOnly.Size = New-Object System.Drawing.Size(200, 24)
    $chkAcknowledgedOnly.Checked = $true
    $clearForm.Controls.Add($chkAcknowledgedOnly)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = "Clear History"
    $btnOK.Location = New-Object System.Drawing.Point(200, 110)
    $btnOK.Size = New-Object System.Drawing.Size(80, 32)
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $clearForm.Controls.Add($btnOK)
    $clearForm.AcceptButton = $btnOK

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"
    $btnCancel.Location = New-Object System.Drawing.Point(290, 110)
    $btnCancel.Size = New-Object System.Drawing.Size(80, 32)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $clearForm.Controls.Add($btnCancel)
    $clearForm.CancelButton = $btnCancel

    $result = $clearForm.ShowDialog()

    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        try {
            $daysToKeep = [int]$txtDays.Text
            if ($daysToKeep -lt 1) {
                [System.Windows.Forms.MessageBox]::Show(
                    "Please enter a valid number of days (1 or more).",
                    "Invalid Input",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                ) | Out-Null
                return
            }

            $cutoffDate = (Get-Date).AddDays(-$daysToKeep)
            $acknowledgedOnly = $chkAcknowledgedOnly.Checked

            # Build confirmation message
            $confirmMessage = "This will permanently delete alert history older than $daysToKeep days"
            if ($acknowledgedOnly) {
                $confirmMessage += " (acknowledged alerts only)"
            }
            $confirmMessage += ".`r`n`r`nCutoff date: $($cutoffDate.ToString('yyyy-MM-dd'))`r`n`r`nAre you sure you want to continue?"

            $confirmResult = [System.Windows.Forms.MessageBox]::Show(
                $confirmMessage,
                "Confirm Clear Alert History",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Question
            )

            if ($confirmResult -eq [System.Windows.Forms.DialogResult]::Yes) {
                # Build the delete query
                $query = @"
DELETE FROM mon.AlertHistory
WHERE AlertTime < '$($cutoffDate.ToString('yyyy-MM-dd HH:mm:ss'))'
"@

                if ($acknowledgedOnly) {
                    $query += "`r`nAND IsAcknowledged = 1"
                }

                # Execute the delete
                $deletedRows = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query

                # Log the operation
                $logQuery = @"
INSERT INTO mon.CollectionRuns (InstanceID, ModuleName, StartTime, EndTime, Status, Notes)
VALUES (0, 'AlertHistoryCleanup', GETDATE(), GETDATE(), 'Success', 'Cleared alerts older than $daysToKeep days, acknowledged only: $acknowledgedOnly')
"@
                Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $logQuery | Out-Null

                # Refresh the alert history
                Load-AlertHistory

                [System.Windows.Forms.MessageBox]::Show(
                    "Alert history cleared successfully.`r`nDeleted $deletedRows rows.",
                    "Clear Complete",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Information
                ) | Out-Null
            }
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show(
                "Failed to clear alert history: $($_.Exception.Message)",
                "Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    }
}

function Populate-AlertHistoryInstances {
    $cbHistoryInstance.Items.Clear()
    [void]$cbHistoryInstance.Items.Add([PSCustomObject]@{ DisplayName = "All Instances"; InstanceID = 0 })

    if ($global:OverviewCache -and $global:OverviewCache.Rows) {
        foreach ($row in $global:OverviewCache.Rows) {
            [void]$cbHistoryInstance.Items.Add([PSCustomObject]@{
                DisplayName = $row["DisplayName"]
                InstanceID  = [int]$row["InstanceID"]
            })
        }
    }

    $cbHistoryInstance.DisplayMember = "DisplayName"
    $cbHistoryInstance.SelectedIndex = 0
}

# ------------------------------------------------------------
# Performance analytics tab controls
$lblAnalyticsHeader = New-Object System.Windows.Forms.Label
$lblAnalyticsHeader.Text = "Performance analytics and insights"
$lblAnalyticsHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblAnalyticsHeader.AutoSize = $true
$lblAnalyticsHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabAnalytics.Controls.Add($lblAnalyticsHeader)

$lblAnalyticsInstance = New-Object System.Windows.Forms.Label
$lblAnalyticsInstance.Text = "Instance:"
$lblAnalyticsInstance.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblAnalyticsInstance.AutoSize = $true
$lblAnalyticsInstance.Location = New-Object System.Drawing.Point(20, 50)
$tabAnalytics.Controls.Add($lblAnalyticsInstance)

$cbAnalyticsInstance = New-Object System.Windows.Forms.ComboBox
$cbAnalyticsInstance.DropDownStyle = "DropDownList"
$cbAnalyticsInstance.Location = New-Object System.Drawing.Point(80, 48)
$cbAnalyticsInstance.Size = New-Object System.Drawing.Size(200, 32)
$tabAnalytics.Controls.Add($cbAnalyticsInstance)

$lblTimeRange = New-Object System.Windows.Forms.Label
$lblTimeRange.Text = "Time Range:"
$lblTimeRange.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblTimeRange.AutoSize = $true
$lblTimeRange.Location = New-Object System.Drawing.Point(300, 50)
$tabAnalytics.Controls.Add($lblTimeRange)

$cbTimeRange = New-Object System.Windows.Forms.ComboBox
$cbTimeRange.Items.AddRange(@("Last Hour", "Last 6 Hours", "Last 24 Hours", "Last 7 Days", "Last 30 Days"))
$cbTimeRange.DropDownStyle = "DropDownList"
$cbTimeRange.Location = New-Object System.Drawing.Point(380, 48)
$cbTimeRange.Size = New-Object System.Drawing.Size(120, 32)
$cbTimeRange.SelectedIndex = 2
$tabAnalytics.Controls.Add($cbTimeRange)

$btnLoadAnalytics = New-Object System.Windows.Forms.Button
$btnLoadAnalytics.Text = "Load Analytics"
$btnLoadAnalytics.Location = New-Object System.Drawing.Point(520, 46)
$btnLoadAnalytics.Size = New-Object System.Drawing.Size(120, 32)
$tabAnalytics.Controls.Add($btnLoadAnalytics)

# Performance Summary Panel
$grpPerformanceSummary = New-Object System.Windows.Forms.GroupBox
$grpPerformanceSummary.Text = "Performance Summary"
$grpPerformanceSummary.Location = New-Object System.Drawing.Point(20, 90)
$grpPerformanceSummary.Size = New-Object System.Drawing.Size(400, 200)
$tabAnalytics.Controls.Add($grpPerformanceSummary)

$lblAvgCPU = New-Object System.Windows.Forms.Label
$lblAvgCPU.Text = "Avg CPU: --"
$lblAvgCPU.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblAvgCPU.AutoSize = $true
$lblAvgCPU.Location = New-Object System.Drawing.Point(20, 30)
$grpPerformanceSummary.Controls.Add($lblAvgCPU)
$toolTip.SetToolTip($lblAvgCPU, "Average CPU utilization percentage over the selected time period. Values above 80-90% may indicate CPU bottlenecks. Monitor for sustained high usage that could impact query performance.")

$lblPeakCPU = New-Object System.Windows.Forms.Label
$lblPeakCPU.Text = "Peak CPU: --"
$lblPeakCPU.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblPeakCPU.AutoSize = $true
$lblPeakCPU.Location = New-Object System.Drawing.Point(20, 60)
$grpPerformanceSummary.Controls.Add($lblPeakCPU)
$toolTip.SetToolTip($lblPeakCPU, "Highest CPU utilization recorded during the selected time period. Peak values help identify intermittent CPU spikes that may cause performance issues.")

$lblAvgMemory = New-Object System.Windows.Forms.Label
$lblAvgMemory.Text = "Avg Memory Usage: --"
$lblAvgMemory.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblAvgMemory.AutoSize = $true
$lblAvgMemory.Location = New-Object System.Drawing.Point(20, 90)
$grpPerformanceSummary.Controls.Add($lblAvgMemory)
$toolTip.SetToolTip($lblAvgMemory, "Average available memory in MB. Low values indicate memory pressure. SQL Server should have sufficient memory for buffer pool, query execution, and other operations.")

$lblMinMemory = New-Object System.Windows.Forms.Label
$lblMinMemory.Text = "Min Available Memory: --"
$lblMinMemory.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblMinMemory.AutoSize = $true
$lblMinMemory.Location = New-Object System.Drawing.Point(20, 120)
$grpPerformanceSummary.Controls.Add($lblMinMemory)
$toolTip.SetToolTip($lblMinMemory, "Minimum available memory recorded. Very low minimum values (<100MB) indicate severe memory pressure that can cause query timeouts and system instability.")

$lblAlertCount = New-Object System.Windows.Forms.Label
$lblAlertCount.Text = "Total Alerts: --"
$lblAlertCount.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblAlertCount.AutoSize = $true
$lblAlertCount.Location = New-Object System.Drawing.Point(20, 150)
$grpPerformanceSummary.Controls.Add($lblAlertCount)

$lblHealthScore = New-Object System.Windows.Forms.Label
$lblHealthScore.Text = "Health Score: --/100"
$lblHealthScore.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblHealthScore.AutoSize = $true
$lblHealthScore.Location = New-Object System.Drawing.Point(20, 170)
$grpPerformanceSummary.Controls.Add($lblHealthScore)

# Trend Analysis Chart
$trendChart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$trendChart.Location = New-Object System.Drawing.Point(440, 90)
$trendChart.Size = New-Object System.Drawing.Size(900, 300)

$trendArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$trendArea.Name = "TrendArea"
$trendArea.AxisX.LabelStyle.Format = "MM/dd HH:mm"
$trendArea.AxisX.IntervalAutoMode = "VariableCount"
$trendChart.ChartAreas.Add($trendArea)

$trendLegend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$trendLegend.Name = "TrendLegend"
$trendChart.Legends.Add($trendLegend)

$seriesTrendCPU = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$seriesTrendCPU.Name = "CPU %"
$seriesTrendCPU.ChartType = "Line"
$seriesTrendCPU.BorderWidth = 2
$seriesTrendCPU.XValueType = "DateTime"
$seriesTrendCPU.Color = [System.Drawing.Color]::FromArgb(220,53,69)

$seriesTrendMemory = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$seriesTrendMemory.Name = "Memory Available MB"
$seriesTrendMemory.ChartType = "Line"
$seriesTrendMemory.BorderWidth = 2
$seriesTrendMemory.XValueType = "DateTime"
$seriesTrendMemory.Color = [System.Drawing.Color]::FromArgb(23,162,184)

$trendChart.Series.Add($seriesTrendCPU)
$trendChart.Series.Add($seriesTrendMemory)

$tabAnalytics.Controls.Add($trendChart)

# Top Issues Panel
$grpTopIssues = New-Object System.Windows.Forms.GroupBox
$grpTopIssues.Text = "Top Issues (Last 24 Hours)"
$grpTopIssues.Location = New-Object System.Drawing.Point(20, 310)
$grpTopIssues.Size = New-Object System.Drawing.Size(400, 250)
$tabAnalytics.Controls.Add($grpTopIssues)

$lstTopIssues = New-Object System.Windows.Forms.ListBox
$lstTopIssues.Location = New-Object System.Drawing.Point(20, 30)
$lstTopIssues.Size = New-Object System.Drawing.Size(360, 200)
$grpTopIssues.Controls.Add($lstTopIssues)

# Recommendations Panel
$grpRecommendations = New-Object System.Windows.Forms.GroupBox
$grpRecommendations.Text = "Recommendations"
$grpRecommendations.Location = New-Object System.Drawing.Point(440, 410)
$grpRecommendations.Size = New-Object System.Drawing.Size(900, 150)
$tabAnalytics.Controls.Add($grpRecommendations)

$lstRecommendations = New-Object System.Windows.Forms.ListBox
$lstRecommendations.Location = New-Object System.Drawing.Point(20, 30)
$lstRecommendations.Size = New-Object System.Drawing.Size(860, 100)
$grpRecommendations.Controls.Add($lstRecommendations)

function Populate-AnalyticsInstances {
    $cbAnalyticsInstance.Items.Clear()

    if ($global:OverviewCache -and $global:OverviewCache.Rows) {
        foreach ($row in $global:OverviewCache.Rows) {
            [void]$cbAnalyticsInstance.Items.Add([PSCustomObject]@{
                DisplayName = $row["DisplayName"]
                InstanceID  = [int]$row["InstanceID"]
            })
        }
    }

    $cbAnalyticsInstance.DisplayMember = "DisplayName"
    if ($cbAnalyticsInstance.Items.Count -gt 0) {
        $cbAnalyticsInstance.SelectedIndex = 0
    }
}

function Load-PerformanceAnalytics {
    if ($cbAnalyticsInstance.SelectedItem -eq $null) {
        return
    }

    $instanceId = $cbAnalyticsInstance.SelectedItem.InstanceID
    $timeRange = $cbTimeRange.SelectedItem

    # Calculate date range
    $endDate = Get-Date
    switch ($timeRange) {
        "Last Hour" { $startDate = $endDate.AddHours(-1) }
        "Last 6 Hours" { $startDate = $endDate.AddHours(-6) }
        "Last 24 Hours" { $startDate = $endDate.AddHours(-24) }
        "Last 7 Days" { $startDate = $endDate.AddDays(-7) }
        "Last 30 Days" { $startDate = $endDate.AddDays(-30) }
    }

    # Load performance summary
    Load-PerformanceSummary -InstanceID $instanceId -StartDate $startDate -EndDate $endDate

    # Load trend data
    Load-PerformanceTrends -InstanceID $instanceId -StartDate $startDate -EndDate $endDate

    # Load top issues
    Load-TopIssues -InstanceID $instanceId

    # Generate recommendations
    Generate-Recommendations -InstanceID $instanceId
}

function Load-PerformanceSummary {
    param([int]$InstanceID, [DateTime]$StartDate, [DateTime]$EndDate)

    # CPU Statistics
    $cpuQuery = @"
SELECT
    AVG(SqlCPUPercent) as AvgCPU,
    MAX(SqlCPUPercent) as PeakCPU,
    COUNT(*) as SampleCount
FROM mon.CPUHistory
WHERE InstanceID = $InstanceID
AND CaptureTime BETWEEN '$($StartDate.ToString('yyyy-MM-dd HH:mm:ss'))' AND '$($EndDate.ToString('yyyy-MM-dd HH:mm:ss'))';
"@

    $cpuStats = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $cpuQuery

    # Memory Statistics
    $memQuery = @"
SELECT
    AVG(AvailablePhysicalMB) as AvgMemory,
    MIN(AvailablePhysicalMB) as MinMemory,
    COUNT(*) as SampleCount
FROM mon.MemoryHistory
WHERE InstanceID = $InstanceID
AND CaptureTime BETWEEN '$($StartDate.ToString('yyyy-MM-dd HH:mm:ss'))' AND '$($EndDate.ToString('yyyy-MM-dd HH:mm:ss'))';
"@

    $memStats = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $memQuery

    # Alert Count
    $alertQuery = @"
SELECT COUNT(*) as AlertCount
FROM mon.vw_AlertHistoryDetailed
WHERE InstanceID = $InstanceID
AND AlertTime BETWEEN '$($StartDate.ToString('yyyy-MM-dd HH:mm:ss'))' AND '$($EndDate.ToString('yyyy-MM-dd HH:mm:ss'))';
"@

    $alertStats = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $alertQuery

    # Update labels
    if ($cpuStats.Rows.Count -gt 0 -and $cpuStats.Rows[0]["SampleCount"] -gt 0) {
        $lblAvgCPU.Text = "Avg CPU: $([math]::Round($cpuStats.Rows[0]["AvgCPU"], 1))%"
        $lblPeakCPU.Text = "Peak CPU: $([math]::Round($cpuStats.Rows[0]["PeakCPU"], 1))%"
    } else {
        $lblAvgCPU.Text = "Avg CPU: No data"
        $lblPeakCPU.Text = "Peak CPU: No data"
    }

    if ($memStats.Rows.Count -gt 0 -and $memStats.Rows[0]["SampleCount"] -gt 0) {
        $lblAvgMemory.Text = "Avg Memory Usage: $([math]::Round($memStats.Rows[0]["AvgMemory"], 0)) MB available"
        $lblMinMemory.Text = "Min Available Memory: $([math]::Round($memStats.Rows[0]["MinMemory"], 0)) MB"
    } else {
        $lblAvgMemory.Text = "Avg Memory Usage: No data"
        $lblMinMemory.Text = "Min Available Memory: No data"
    }

    if ($alertStats.Rows.Count -gt 0) {
        $lblAlertCount.Text = "Total Alerts: $($alertStats.Rows[0]["AlertCount"])"
    } else {
        $lblAlertCount.Text = "Total Alerts: 0"
    }

    # Calculate health score (simple algorithm)
    $healthScore = 100
    if ($cpuStats.Rows.Count -gt 0 -and $cpuStats.Rows[0]["AvgCPU"] -gt 80) {
        $healthScore -= 20
    }
    if ($memStats.Rows.Count -gt 0 -and $memStats.Rows[0]["MinMemory"] -lt 1024) {
        $healthScore -= 20
    }
    if ($alertStats.Rows.Count -gt 0 -and $alertStats.Rows[0]["AlertCount"] -gt 10) {
        $healthScore -= 30
    }
    $healthScore = [math]::Max(0, $healthScore)

    $lblHealthScore.Text = "Health Score: $healthScore/100"
    if ($healthScore -ge 80) {
        $lblHealthScore.ForeColor = [System.Drawing.Color]::Green
    } elseif ($healthScore -ge 60) {
        $lblHealthScore.ForeColor = [System.Drawing.Color]::Orange
    } else {
        $lblHealthScore.ForeColor = [System.Drawing.Color]::Red
    }
}

function Load-PerformanceTrends {
    param([int]$InstanceID, [DateTime]$StartDate, [DateTime]$EndDate)

    $trendChart.Series["CPU %"].Points.Clear()
    $trendChart.Series["Memory Available MB"].Points.Clear()

    # CPU Trend
    $cpuQuery = @"
SELECT CaptureTime, SqlCPUPercent
FROM mon.CPUHistory
WHERE InstanceID = $InstanceID
AND CaptureTime BETWEEN '$($StartDate.ToString('yyyy-MM-dd HH:mm:ss'))' AND '$($EndDate.ToString('yyyy-MM-dd HH:mm:ss'))'
ORDER BY CaptureTime;
"@

    $cpuData = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $cpuQuery

    foreach ($row in $cpuData.Rows) {
        $time = [datetime]$row["CaptureTime"]
        [void]$trendChart.Series["CPU %"].Points.AddXY($time, [decimal]$row["SqlCPUPercent"])
    }

    # Memory Trend
    $memQuery = @"
SELECT CaptureTime, AvailablePhysicalMB
FROM mon.MemoryHistory
WHERE InstanceID = $InstanceID
AND CaptureTime BETWEEN '$($StartDate.ToString('yyyy-MM-dd HH:mm:ss'))' AND '$($EndDate.ToString('yyyy-MM-dd HH:mm:ss'))'
ORDER BY CaptureTime;
"@

    $memData = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $memQuery

    foreach ($row in $memData.Rows) {
        $time = [datetime]$row["CaptureTime"]
        [void]$trendChart.Series["Memory Available MB"].Points.AddXY($time, [decimal]$row["AvailablePhysicalMB"])
    }
}

function Load-TopIssues {
    param([int]$InstanceID)

    $lstTopIssues.Items.Clear()

    $issuesQuery = @"
SELECT TOP 10
    ModuleName,
    AlertTitle,
    COUNT(*) as Frequency,
    MAX(AlertTime) as LastOccurrence
FROM mon.vw_AlertHistoryDetailed
WHERE InstanceID = $InstanceID
AND AlertTime >= DATEADD(DAY, -1, GETDATE())
GROUP BY ModuleName, AlertTitle
ORDER BY Frequency DESC, LastOccurrence DESC;
"@

    $issues = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $issuesQuery

    foreach ($row in $issues.Rows) {
        $item = "$($row["ModuleName"]): $($row["AlertTitle"]) ($($row["Frequency"]) times)"
        [void]$lstTopIssues.Items.Add($item)
    }

    if ($lstTopIssues.Items.Count -eq 0) {
        [void]$lstTopIssues.Items.Add("No issues found in the last 24 hours")
    }
}

function Generate-Recommendations {
    param([int]$InstanceID)

    $lstRecommendations.Items.Clear()

    # Get current performance metrics
    $currentQuery = @"
SELECT TOP 1
    SqlCPUPercent,
    AvailablePhysicalMB,
    PLESeconds
FROM mon.vw_LatestOverview
WHERE InstanceID = $InstanceID;
"@

    $current = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $currentQuery

    if ($current.Rows.Count -gt 0) {
        $cpu = [decimal]$current.Rows[0]["SqlCPUPercent"]
        $memory = [decimal]$current.Rows[0]["AvailablePhysicalMB"]
        $ple = [decimal]$current.Rows[0]["PLESeconds"]

        $recommendations = @()

        if ($cpu -gt 85) {
            $recommendations += "High CPU usage detected ($([math]::Round($cpu, 1))%). Consider optimizing queries or scaling up CPU resources."
        }

        if ($memory -lt 2048) {
            $recommendations += "Low available memory ($([math]::Round($memory, 0)) MB). Consider increasing server memory or optimizing memory usage."
        }

        if ($ple -lt 300) {
            $recommendations += "Low Page Life Expectancy ($([math]::Round($ple, 0)) seconds). Consider increasing server memory."
        }

        # Check for recent alerts
        $alertQuery = @"
SELECT COUNT(*) as RecentAlerts
FROM mon.vw_AlertHistoryDetailed
WHERE InstanceID = $InstanceID
AND AlertTime >= DATEADD(HOUR, -24, GETDATE())
AND Severity = 'Critical';
"@

        $alerts = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $alertQuery
        if ($alerts.Rows.Count -gt 0 -and $alerts.Rows[0]["RecentAlerts"] -gt 5) {
            $recommendations += "High number of critical alerts in last 24 hours. Review alert thresholds and system configuration."
        }

        if ($recommendations.Count -eq 0) {
            $recommendations += "System performance looks good. No immediate recommendations."
        }

        foreach ($rec in $recommendations) {
            [void]$lstRecommendations.Items.Add($rec)
        }
    } else {
        [void]$lstRecommendations.Items.Add("Unable to generate recommendations - no current performance data available")
    }
}

function New-SummaryTile {
    param($x, $y, $title)

    $panel = New-Object System.Windows.Forms.Panel
    $panel.Location = New-Object System.Drawing.Point($x, $y)
    $panel.Size = New-Object System.Drawing.Size(220, 90)
    $panel.BorderStyle = "FixedSingle"
    $panel.BackColor = [System.Drawing.Color]::White

    $lblHeader = New-Object System.Windows.Forms.Label
    $lblHeader.Text = $title
    $lblHeader.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $lblHeader.AutoSize = $true
    $lblHeader.Location = New-Object System.Drawing.Point(10, 10)
    $panel.Controls.Add($lblHeader)

    $lblValue = New-Object System.Windows.Forms.Label
    $lblValue.Text = "-"
    $lblValue.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
    $lblValue.AutoSize = $true
    $lblValue.Location = New-Object System.Drawing.Point(10, 38)
    $panel.Controls.Add($lblValue)

    return @{
        Panel = $panel
        Header = $lblHeader
        Value = $lblValue
    }
}

$tileStatus     = New-SummaryTile -x 20   -y 70  -title "Instance Status"
$tileCPU        = New-SummaryTile -x 250  -y 70  -title "SQL CPU %"
$tileAvailMem   = New-SummaryTile -x 480  -y 70  -title "Available Memory MB"
$tilePLE        = New-SummaryTile -x 710  -y 70  -title "PLE Seconds"
$tileOpenAlerts = New-SummaryTile -x 940  -y 70  -title "Open Alerts"
$tileCritAlerts = New-SummaryTile -x 1170 -y 70  -title "Critical Alerts"

$tabOverview.Controls.Add($tileStatus.Panel)
$tabOverview.Controls.Add($tileCPU.Panel)
$tabOverview.Controls.Add($tileAvailMem.Panel)
$tabOverview.Controls.Add($tilePLE.Panel)
$tabOverview.Controls.Add($tileOpenAlerts.Panel)
$tabOverview.Controls.Add($tileCritAlerts.Panel)

$dgvOverview = New-Object System.Windows.Forms.DataGridView
$dgvOverview.Location = New-Object System.Drawing.Point(20, 180)
$dgvOverview.Size = New-Object System.Drawing.Size(1320, 560)
$dgvOverview.ReadOnly = $true
$dgvOverview.AllowUserToAddRows = $false
$dgvOverview.AllowUserToDeleteRows = $false
$dgvOverview.AutoSizeColumnsMode = "Fill"
$dgvOverview.SelectionMode = "FullRowSelect"
$tabOverview.Controls.Add($dgvOverview)

# ------------------------------------------------------------
# CPU tab
$cpuChart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$cpuChart.Location = New-Object System.Drawing.Point(10, 10)
$cpuChart.Size = New-Object System.Drawing.Size(1130, 240)

$cpuArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$cpuArea.Name = "CPUArea"
$cpuArea.AxisX.LabelStyle.Format = "HH:mm:ss"
$cpuArea.AxisX.IntervalAutoMode = "VariableCount"
$cpuChart.ChartAreas.Add($cpuArea)

$cpuLegend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$cpuLegend.Name = "CPULegend"
$cpuChart.Legends.Add($cpuLegend)

$seriesSqlCPU = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$seriesSqlCPU.Name = "SQL CPU %"
$seriesSqlCPU.ChartType = "Line"
$seriesSqlCPU.BorderWidth = 3
$seriesSqlCPU.XValueType = "DateTime"
$seriesSqlCPU.Color = [System.Drawing.Color]::FromArgb(220,53,69)

$seriesIdleCPU = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$seriesIdleCPU.Name = "Idle CPU %"
$seriesIdleCPU.ChartType = "Line"
$seriesIdleCPU.BorderWidth = 3
$seriesIdleCPU.XValueType = "DateTime"
$seriesIdleCPU.Color = [System.Drawing.Color]::FromArgb(40,167,69)

$seriesOtherCPU = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$seriesOtherCPU.Name = "Other CPU %"
$seriesOtherCPU.ChartType = "Line"
$seriesOtherCPU.BorderWidth = 3
$seriesOtherCPU.XValueType = "DateTime"
$seriesOtherCPU.Color = [System.Drawing.Color]::FromArgb(255,193,7)

$cpuChart.Series.Add($seriesSqlCPU)
$cpuChart.Series.Add($seriesIdleCPU)
$cpuChart.Series.Add($seriesOtherCPU)

$tabCPU.Controls.Add($cpuChart)

$dgvCPU = New-Object System.Windows.Forms.DataGridView
$dgvCPU.Location = New-Object System.Drawing.Point(10, 260)
$dgvCPU.Size = New-Object System.Drawing.Size(1130, 500)
$dgvCPU.ReadOnly = $true
$dgvCPU.AllowUserToAddRows = $false
$dgvCPU.AllowUserToDeleteRows = $false
$dgvCPU.AutoSizeColumnsMode = "Fill"
$tabCPU.Controls.Add($dgvCPU)

# ------------------------------------------------------------
# Memory tab
$memoryChart = New-Object System.Windows.Forms.DataVisualization.Charting.Chart
$memoryChart.Location = New-Object System.Drawing.Point(10, 10)
$memoryChart.Size = New-Object System.Drawing.Size(1130, 240)

$memArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
$memArea.Name = "MemoryArea"
$memArea.AxisX.LabelStyle.Format = "HH:mm:ss"
$memArea.AxisX.IntervalAutoMode = "VariableCount"
$memoryChart.ChartAreas.Add($memArea)

$memLegend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend
$memLegend.Name = "MemoryLegend"
$memoryChart.Legends.Add($memLegend)

$seriesAvailMem = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$seriesAvailMem.Name = "Available Memory MB"
$seriesAvailMem.ChartType = "Line"
$seriesAvailMem.BorderWidth = 3
$seriesAvailMem.XValueType = "DateTime"
$seriesAvailMem.Color = [System.Drawing.Color]::FromArgb(23,162,184)

$seriesPLE = New-Object System.Windows.Forms.DataVisualization.Charting.Series
$seriesPLE.Name = "PLE Seconds"
$seriesPLE.ChartType = "Line"
$seriesPLE.BorderWidth = 3
$seriesPLE.XValueType = "DateTime"
$seriesPLE.Color = [System.Drawing.Color]::FromArgb(111,66,193)

$memoryChart.Series.Add($seriesAvailMem)
$memoryChart.Series.Add($seriesPLE)

$tabMemory.Controls.Add($memoryChart)

$dgvMemory = New-Object System.Windows.Forms.DataGridView
$dgvMemory.Location = New-Object System.Drawing.Point(10, 260)
$dgvMemory.Size = New-Object System.Drawing.Size(1130, 500)
$dgvMemory.ReadOnly = $true
$dgvMemory.AllowUserToAddRows = $false
$dgvMemory.AllowUserToDeleteRows = $false
$dgvMemory.AutoSizeColumnsMode = "Fill"
$tabMemory.Controls.Add($dgvMemory)

# ------------------------------------------------------------
# Alerts tab
$lblAlertsHeader = New-Object System.Windows.Forms.Label
$lblAlertsHeader.Text = "Open Alerts"
$lblAlertsHeader.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblAlertsHeader.AutoSize = $true
$lblAlertsHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabAlerts.Controls.Add($lblAlertsHeader)

$chkCriticalOnly = New-Object System.Windows.Forms.CheckBox
$chkCriticalOnly.Text = "Show critical alerts only"
$chkCriticalOnly.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$chkCriticalOnly.AutoSize = $true
$chkCriticalOnly.Location = New-Object System.Drawing.Point(180, 24)
$tabAlerts.Controls.Add($chkCriticalOnly)

$btnRefreshAlerts = New-Object System.Windows.Forms.Button
$btnRefreshAlerts.Text = "Refresh Alerts"
$btnRefreshAlerts.Location = New-Object System.Drawing.Point(400, 18)
$btnRefreshAlerts.Size = New-Object System.Drawing.Size(120, 32)
$tabAlerts.Controls.Add($btnRefreshAlerts)

$btnAcknowledgeAlert = New-Object System.Windows.Forms.Button
$btnAcknowledgeAlert.Text = "Acknowledge Selected Alert"
$btnAcknowledgeAlert.Location = New-Object System.Drawing.Point(540, 18)
$btnAcknowledgeAlert.Size = New-Object System.Drawing.Size(220, 32)
$tabAlerts.Controls.Add($btnAcknowledgeAlert)

$lblAlertInfo = New-Object System.Windows.Forms.Label
$lblAlertInfo.Text = "No alert selected"
$lblAlertInfo.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblAlertInfo.AutoSize = $true
$lblAlertInfo.Location = New-Object System.Drawing.Point(790, 24)
$tabAlerts.Controls.Add($lblAlertInfo)

$dgvAlerts = New-Object System.Windows.Forms.DataGridView
$dgvAlerts.Location = New-Object System.Drawing.Point(20, 60)
$dgvAlerts.Size = New-Object System.Drawing.Size(1320, 660)
$dgvAlerts.ReadOnly = $true
$dgvAlerts.AllowUserToAddRows = $false
$dgvAlerts.AllowUserToDeleteRows = $false
$dgvAlerts.AutoSizeColumnsMode = "Fill"
$dgvAlerts.SelectionMode = "FullRowSelect"
$dgvAlerts.MultiSelect = $false
$tabAlerts.Controls.Add($dgvAlerts)
$toolTip.SetToolTip($dgvAlerts, "Active alerts from the monitoring system. Select an alert to view details and search for solutions. Alerts are color-coded by severity: Red=Critical, Orange=High, Yellow=Medium, Green=Low.")

# Add data grids for all monitoring tabs
$dgvKPIs = New-Object System.Windows.Forms.DataGridView
$dgvKPIs.Location = New-Object System.Drawing.Point(20, 20)
$dgvKPIs.Size = New-Object System.Drawing.Size(1320, 700)
$dgvKPIs.ReadOnly = $true
$dgvKPIs.AllowUserToAddRows = $false
$dgvKPIs.AllowUserToDeleteRows = $false
$dgvKPIs.AutoSizeColumnsMode = "Fill"
$tabKPIs.Controls.Add($dgvKPIs)

$dgvDisks = New-Object System.Windows.Forms.DataGridView
$dgvDisks.Location = New-Object System.Drawing.Point(20, 20)
$dgvDisks.Size = New-Object System.Drawing.Size(1320, 700)
$dgvDisks.ReadOnly = $true
$dgvDisks.AllowUserToAddRows = $false
$dgvDisks.AllowUserToDeleteRows = $false
$dgvDisks.AutoSizeColumnsMode = "Fill"
$tabDisks.Controls.Add($dgvDisks)

$dgvConfig = New-Object System.Windows.Forms.DataGridView
$dgvConfig.Location = New-Object System.Drawing.Point(20, 20)
$dgvConfig.Size = New-Object System.Drawing.Size(1320, 700)
$dgvConfig.ReadOnly = $true
$dgvConfig.AllowUserToAddRows = $false
$dgvConfig.AllowUserToDeleteRows = $false
$dgvConfig.AutoSizeColumnsMode = "Fill"
$tabConfig.Controls.Add($dgvConfig)

$dgvIO = New-Object System.Windows.Forms.DataGridView
$dgvIO.Location = New-Object System.Drawing.Point(20, 20)
$dgvIO.Size = New-Object System.Drawing.Size(1320, 700)
$dgvIO.ReadOnly = $true
$dgvIO.AllowUserToAddRows = $false
$dgvIO.AllowUserToDeleteRows = $false
$dgvIO.AutoSizeColumnsMode = "Fill"
$tabIO.Controls.Add($dgvIO)

$dgvTempDB = New-Object System.Windows.Forms.DataGridView
$dgvTempDB.Location = New-Object System.Drawing.Point(20, 20)
$dgvTempDB.Size = New-Object System.Drawing.Size(1320, 700)
$dgvTempDB.ReadOnly = $true
$dgvTempDB.AllowUserToAddRows = $false
$dgvTempDB.AllowUserToDeleteRows = $false
$dgvTempDB.AutoSizeColumnsMode = "Fill"
$tabTempDB.Controls.Add($dgvTempDB)

$dgvBackups = New-Object System.Windows.Forms.DataGridView
$dgvBackups.Location = New-Object System.Drawing.Point(20, 20)
$dgvBackups.Size = New-Object System.Drawing.Size(1320, 700)
$dgvBackups.ReadOnly = $true
$dgvBackups.AllowUserToAddRows = $false
$dgvBackups.AllowUserToDeleteRows = $false
$dgvBackups.AutoSizeColumnsMode = "Fill"
$tabBackups.Controls.Add($dgvBackups)

$dgvDBOptions = New-Object System.Windows.Forms.DataGridView
$dgvDBOptions.Location = New-Object System.Drawing.Point(20, 20)
$dgvDBOptions.Size = New-Object System.Drawing.Size(1320, 700)
$dgvDBOptions.ReadOnly = $true
$dgvDBOptions.AllowUserToAddRows = $false
$dgvDBOptions.AllowUserToDeleteRows = $false
$dgvDBOptions.AutoSizeColumnsMode = "Fill"
$tabDBOptions.Controls.Add($dgvDBOptions)

$dgvBlocking = New-Object System.Windows.Forms.DataGridView
$dgvBlocking.Location = New-Object System.Drawing.Point(20, 20)
$dgvBlocking.Size = New-Object System.Drawing.Size(1320, 700)
$dgvBlocking.ReadOnly = $true
$dgvBlocking.AllowUserToAddRows = $false
$dgvBlocking.AllowUserToDeleteRows = $false
$dgvBlocking.AutoSizeColumnsMode = "Fill"
$tabBlocking.Controls.Add($dgvBlocking)

$dgvLongRunning = New-Object System.Windows.Forms.DataGridView
$dgvLongRunning.Location = New-Object System.Drawing.Point(20, 20)
$dgvLongRunning.Size = New-Object System.Drawing.Size(1320, 700)
$dgvLongRunning.ReadOnly = $true
$dgvLongRunning.AllowUserToAddRows = $false
$dgvLongRunning.AllowUserToDeleteRows = $false
$dgvLongRunning.AutoSizeColumnsMode = "Fill"
$tabLongRunning.Controls.Add($dgvLongRunning)

$dgvTopQueries = New-Object System.Windows.Forms.DataGridView
$dgvTopQueries.Location = New-Object System.Drawing.Point(20, 20)
$dgvTopQueries.Size = New-Object System.Drawing.Size(1320, 700)
$dgvTopQueries.ReadOnly = $true
$dgvTopQueries.AllowUserToAddRows = $false
$dgvTopQueries.AllowUserToDeleteRows = $false
$dgvTopQueries.AutoSizeColumnsMode = "Fill"
$tabTopQueries.Controls.Add($dgvTopQueries)

$dgvMissingIndexes = New-Object System.Windows.Forms.DataGridView
$dgvMissingIndexes.Location = New-Object System.Drawing.Point(20, 20)
$dgvMissingIndexes.Size = New-Object System.Drawing.Size(1320, 700)
$dgvMissingIndexes.ReadOnly = $true
$dgvMissingIndexes.AllowUserToAddRows = $false
$dgvMissingIndexes.AllowUserToDeleteRows = $false
$dgvMissingIndexes.AutoSizeColumnsMode = "Fill"
$tabMissingIndexes.Controls.Add($dgvMissingIndexes)

$dgvIndexFragmentation = New-Object System.Windows.Forms.DataGridView
$dgvIndexFragmentation.Location = New-Object System.Drawing.Point(20, 20)
$dgvIndexFragmentation.Size = New-Object System.Drawing.Size(1320, 700)
$dgvIndexFragmentation.ReadOnly = $true
$dgvIndexFragmentation.AllowUserToAddRows = $false
$dgvIndexFragmentation.AllowUserToDeleteRows = $false
$dgvIndexFragmentation.AutoSizeColumnsMode = "Fill"
$tabIndexFragmentation.Controls.Add($dgvIndexFragmentation)

$dgvAG = New-Object System.Windows.Forms.DataGridView
$dgvAG.Location = New-Object System.Drawing.Point(20, 20)
$dgvAG.Size = New-Object System.Drawing.Size(1320, 700)
$dgvAG.ReadOnly = $true
$dgvAG.AllowUserToAddRows = $false
$dgvAG.AllowUserToDeleteRows = $false
$dgvAG.AutoSizeColumnsMode = "Fill"
$tabAG.Controls.Add($dgvAG)

$dgvListeners = New-Object System.Windows.Forms.DataGridView
$dgvListeners.Location = New-Object System.Drawing.Point(20, 20)
$dgvListeners.Size = New-Object System.Drawing.Size(1320, 700)
$dgvListeners.ReadOnly = $true
$dgvListeners.AllowUserToAddRows = $false
$dgvListeners.AllowUserToDeleteRows = $false
$dgvListeners.AutoSizeColumnsMode = "Fill"
$tabListeners.Controls.Add($dgvListeners)

$dgvAgentJobs = New-Object System.Windows.Forms.DataGridView
$dgvAgentJobs.Location = New-Object System.Drawing.Point(20, 20)
$dgvAgentJobs.Size = New-Object System.Drawing.Size(1320, 700)
$dgvAgentJobs.ReadOnly = $true
$dgvAgentJobs.AllowUserToAddRows = $false
$dgvAgentJobs.AllowUserToDeleteRows = $false
$dgvAgentJobs.AutoSizeColumnsMode = "Fill"
$tabAgentJobs.Controls.Add($dgvAgentJobs)

$dgvDeadlocks = New-Object System.Windows.Forms.DataGridView
$dgvDeadlocks.Location = New-Object System.Drawing.Point(20, 20)
$dgvDeadlocks.Size = New-Object System.Drawing.Size(1320, 700)
$dgvDeadlocks.ReadOnly = $true
$dgvDeadlocks.AllowUserToAddRows = $false
$dgvDeadlocks.AllowUserToDeleteRows = $false
$dgvDeadlocks.AutoSizeColumnsMode = "Fill"
$tabDeadlocks.Controls.Add($dgvDeadlocks)

$dgvWaits = New-Object System.Windows.Forms.DataGridView
$dgvWaits.Location = New-Object System.Drawing.Point(20, 20)
$dgvWaits.Size = New-Object System.Drawing.Size(1320, 700)
$dgvWaits.ReadOnly = $true
$dgvWaits.AllowUserToAddRows = $false
$dgvWaits.AllowUserToDeleteRows = $false
$dgvWaits.AutoSizeColumnsMode = "Fill"
$tabWaits.Controls.Add($dgvWaits)

# ------------------------------------------------------------  
# Execution Plans tab (UNIQUE FEATURE)
# ------------------------------------------------------------
$lblExecutionPlansHeader = New-Object System.Windows.Forms.Label
$lblExecutionPlansHeader.Text = "Real-Time Execution Plan Analysis"
$lblExecutionPlansHeader.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblExecutionPlansHeader.AutoSize = $true
$lblExecutionPlansHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabExecutionPlans.Controls.Add($lblExecutionPlansHeader)

$btnRefreshExecutionPlans = New-Object System.Windows.Forms.Button
$btnRefreshExecutionPlans.Text = "Refresh Execution Plans"
$btnRefreshExecutionPlans.Location = New-Object System.Drawing.Point(350, 15)
$btnRefreshExecutionPlans.Size = New-Object System.Drawing.Size(180, 32)
$tabExecutionPlans.Controls.Add($btnRefreshExecutionPlans)

$dgvExecutionPlans = New-Object System.Windows.Forms.DataGridView
$dgvExecutionPlans.Location = New-Object System.Drawing.Point(20, 60)
$dgvExecutionPlans.Size = New-Object System.Drawing.Size(1320, 680)
$dgvExecutionPlans.ReadOnly = $true
$dgvExecutionPlans.AllowUserToAddRows = $false
$dgvExecutionPlans.AllowUserToDeleteRows = $false
$dgvExecutionPlans.AutoSizeColumnsMode = "Fill"
$tabExecutionPlans.Controls.Add($dgvExecutionPlans)
$toolTip.SetToolTip($dgvExecutionPlans, "Real-time analysis of active query execution plans. Shows optimization recommendations including missing indexes, table scans, and high-cost operations. UNIQUE FEATURE: Automated plan analysis with actionable insights.")

# ------------------------------------------------------------  
# Memory Analysis tab (UNIQUE FEATURE)
# ------------------------------------------------------------
$lblMemoryAnalysisHeader = New-Object System.Windows.Forms.Label
$lblMemoryAnalysisHeader.Text = "Memory Clerk Pressure Analysis"
$lblMemoryAnalysisHeader.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblMemoryAnalysisHeader.AutoSize = $true
$lblMemoryAnalysisHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabMemoryAnalysis.Controls.Add($lblMemoryAnalysisHeader)

$btnRefreshMemoryAnalysis = New-Object System.Windows.Forms.Button
$btnRefreshMemoryAnalysis.Text = "Refresh Memory Analysis"
$btnRefreshMemoryAnalysis.Location = New-Object System.Drawing.Point(320, 15)
$btnRefreshMemoryAnalysis.Size = New-Object System.Drawing.Size(180, 32)
$tabMemoryAnalysis.Controls.Add($btnRefreshMemoryAnalysis)

$dgvMemoryClerks = New-Object System.Windows.Forms.DataGridView
$dgvMemoryClerks.Location = New-Object System.Drawing.Point(20, 60)
$dgvMemoryClerks.Size = New-Object System.Drawing.Size(1320, 330)
$dgvMemoryClerks.ReadOnly = $true
$dgvMemoryClerks.AllowUserToAddRows = $false
$dgvMemoryClerks.AllowUserToDeleteRows = $false
$dgvMemoryClerks.AutoSizeColumnsMode = "Fill"
$tabMemoryAnalysis.Controls.Add($dgvMemoryClerks)
$toolTip.SetToolTip($dgvMemoryClerks, "Detailed analysis of SQL Server memory allocation by internal components. Shows memory pressure levels and scaling recommendations. UNIQUE FEATURE: Component-level memory analysis with predictive insights.")

$lblBufferPoolHeader = New-Object System.Windows.Forms.Label
$lblBufferPoolHeader.Text = "Buffer Pool Distribution"
$lblBufferPoolHeader.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblBufferPoolHeader.AutoSize = $true
$lblBufferPoolHeader.Location = New-Object System.Drawing.Point(20, 410)
$tabMemoryAnalysis.Controls.Add($lblBufferPoolHeader)

$dgvBufferPool = New-Object System.Windows.Forms.DataGridView
$dgvBufferPool.Location = New-Object System.Drawing.Point(20, 440)
$dgvBufferPool.Size = New-Object System.Drawing.Size(1320, 300)
$dgvBufferPool.ReadOnly = $true
$dgvBufferPool.AllowUserToAddRows = $false
$dgvBufferPool.AllowUserToDeleteRows = $false
$dgvBufferPool.AutoSizeColumnsMode = "Fill"
$tabMemoryAnalysis.Controls.Add($dgvBufferPool)
$toolTip.SetToolTip($dgvBufferPool, "Analysis of buffer pool page distribution across databases. Shows access patterns, dirty page ratios, and optimization recommendations. UNIQUE FEATURE: Database-level buffer pool insights.")

# ------------------------------------------------------------
# Collection Health tab controls
# ------------------------------------------------------------
$lblHealthSummary = New-Object System.Windows.Forms.Label
$lblHealthSummary.Location = New-Object System.Drawing.Point(20, 15)
$lblHealthSummary.Size = New-Object System.Drawing.Size(800, 25)
$lblHealthSummary.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$lblHealthSummary.Text = "Collection Health Status"
$tabHealth.Controls.Add($lblHealthSummary)

$btnRefreshHealth = New-Object System.Windows.Forms.Button
$btnRefreshHealth.Location = New-Object System.Drawing.Point(1200, 10)
$btnRefreshHealth.Size = New-Object System.Drawing.Size(140, 30)
$btnRefreshHealth.Text = "Refresh Health"
$tabHealth.Controls.Add($btnRefreshHealth)

# Health summary tiles
$lblHealthHealthy = New-Object System.Windows.Forms.Label
$lblHealthHealthy.Location = New-Object System.Drawing.Point(20, 50)
$lblHealthHealthy.Size = New-Object System.Drawing.Size(200, 60)
$lblHealthHealthy.BackColor = [System.Drawing.Color]::FromArgb(212, 237, 218)
$lblHealthHealthy.ForeColor = [System.Drawing.Color]::FromArgb(21, 87, 36)
$lblHealthHealthy.TextAlign = "MiddleCenter"
$lblHealthHealthy.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblHealthHealthy.Text = "Healthy: 0"
$tabHealth.Controls.Add($lblHealthHealthy)

$lblHealthWarning = New-Object System.Windows.Forms.Label
$lblHealthWarning.Location = New-Object System.Drawing.Point(240, 50)
$lblHealthWarning.Size = New-Object System.Drawing.Size(200, 60)
$lblHealthWarning.BackColor = [System.Drawing.Color]::FromArgb(255, 243, 205)
$lblHealthWarning.ForeColor = [System.Drawing.Color]::FromArgb(133, 100, 4)
$lblHealthWarning.TextAlign = "MiddleCenter"
$lblHealthWarning.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblHealthWarning.Text = "Warning: 0"
$tabHealth.Controls.Add($lblHealthWarning)

$lblHealthCritical = New-Object System.Windows.Forms.Label
$lblHealthCritical.Location = New-Object System.Drawing.Point(460, 50)
$lblHealthCritical.Size = New-Object System.Drawing.Size(200, 60)
$lblHealthCritical.BackColor = [System.Drawing.Color]::FromArgb(248, 215, 218)
$lblHealthCritical.ForeColor = [System.Drawing.Color]::FromArgb(114, 28, 36)
$lblHealthCritical.TextAlign = "MiddleCenter"
$lblHealthCritical.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblHealthCritical.Text = "Critical: 0"
$tabHealth.Controls.Add($lblHealthCritical)

$lblHealthNever = New-Object System.Windows.Forms.Label
$lblHealthNever.Location = New-Object System.Drawing.Point(680, 50)
$lblHealthNever.Size = New-Object System.Drawing.Size(200, 60)
$lblHealthNever.BackColor = [System.Drawing.Color]::FromArgb(226, 226, 226)
$lblHealthNever.ForeColor = [System.Drawing.Color]::FromArgb(66, 66, 66)
$lblHealthNever.TextAlign = "MiddleCenter"
$lblHealthNever.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblHealthNever.Text = "Never Run: 0"
$tabHealth.Controls.Add($lblHealthNever)

# Health DataGridView
$dgvHealth = New-Object System.Windows.Forms.DataGridView
$dgvHealth.Location = New-Object System.Drawing.Point(20, 130)
$dgvHealth.Size = New-Object System.Drawing.Size(650, 600)
$dgvHealth.ReadOnly = $true
$dgvHealth.AllowUserToAddRows = $false
$dgvHealth.AllowUserToDeleteRows = $false
$dgvHealth.AutoSizeColumnsMode = "Fill"
$tabHealth.Controls.Add($dgvHealth)

# Issues DataGridView
$lblIssues = New-Object System.Windows.Forms.Label
$lblIssues.Location = New-Object System.Drawing.Point(700, 115)
$lblIssues.Size = New-Object System.Drawing.Size(600, 25)
$lblIssues.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$lblIssues.Text = "Collection Issues"
$tabHealth.Controls.Add($lblIssues)

$dgvHealthIssues = New-Object System.Windows.Forms.DataGridView
$dgvHealthIssues.Location = New-Object System.Drawing.Point(700, 145)
$dgvHealthIssues.Size = New-Object System.Drawing.Size(640, 585)
$dgvHealthIssues.ReadOnly = $true
$dgvHealthIssues.AllowUserToAddRows = $false
$dgvHealthIssues.AllowUserToDeleteRows = $false
$dgvHealthIssues.AutoSizeColumnsMode = "Fill"
$dgvHealthIssues.RowHeadersVisible = $false
$tabHealth.Controls.Add($dgvHealthIssues)

# ------------------------------------------------------------
# Global cache
$global:OverviewCache = $null

# ------------------------------------------------------------
# Load methods
function Load-Overview {
    param([int]$PreSelectedInstanceId = $null)

    $selectedInstanceId = $null
    if ($cbInstances.SelectedItem -and $cbInstances.SelectedItem.InstanceID) {
        $selectedInstanceId = [int]$cbInstances.SelectedItem.InstanceID
    }

    $global:OverviewCache = Get-OverviewData
    $dgvOverview.DataSource = $global:OverviewCache

    $script:SuppressInstanceChangeLoad = $true
    try {
        $cbInstances.Items.Clear()

        # Reset tracking of added display names for each load to avoid stale state across refreshes
        $script:InstanceNamesAdded = @{}
        foreach ($row in $global:OverviewCache.Rows) {
            # Ensure each DisplayName appears only once in the dropdown (handles cases where VM name and SQL instance name differ but refer to same server)
            $display = $row["DisplayName"]
            if (-not $script:InstanceNamesAdded.ContainsKey($display)) {
                $script:InstanceNamesAdded[$display] = $true
                [void]$cbInstances.Items.Add([pscustomobject]@{
                    DisplayName = $display
                    InstanceID  = [int]$row["InstanceID"]
                })
            }
        }

        $cbInstances.DisplayMember = "DisplayName"

        $selectionApplied = $false
        if ($null -ne $PreSelectedInstanceId) {
            # Use pre-selected instance from server overview
            for ($i = 0; $i -lt $cbInstances.Items.Count; $i++) {
                if ($cbInstances.Items[$i].InstanceID -eq $PreSelectedInstanceId) {
                    $cbInstances.SelectedIndex = $i
                    $selectionApplied = $true
                    break
                }
            }
        } elseif ($null -ne $selectedInstanceId) {
            # Use previously selected instance
            for ($i = 0; $i -lt $cbInstances.Items.Count; $i++) {
                if ($cbInstances.Items[$i].InstanceID -eq $selectedInstanceId) {
                    $cbInstances.SelectedIndex = $i
                    $selectionApplied = $true
                    break
                }
            }
        }

        if (-not $selectionApplied -and $cbInstances.Items.Count -gt 0) {
            $cbInstances.SelectedIndex = 0
        }
    }
    finally {
        $script:SuppressInstanceChangeLoad = $false
    }

    $lblLastRefresh.Text = "Last Refresh: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
}

function Update-OverviewTiles {
    if ($cbInstances.SelectedItem -eq $null) { return }

    $instanceId = $cbInstances.SelectedItem.InstanceID
    $row = $global:OverviewCache.Select("InstanceID = $instanceId") | Select-Object -First 1
    if ($null -eq $row) { return }

    $criticalCount = [int]$row["CriticalAlertCount"]
    $warningCount  = [int]$row["WarningAlertCount"]
    $openCount     = [int]$row["OpenAlertCount"]
    $healthColor   = Get-HealthColor -CriticalCount $criticalCount -WarningCount $warningCount

    $statusText = if ($criticalCount -gt 0) {
        "CRITICAL"
    }
    elseif ($warningCount -gt 0) {
        "WARNING"
    }
    else {
        "HEALTHY"
    }
    Set-StatusTileStyle -Panel $tileStatus.Panel -Label $tileStatus.Value -StatusText $statusText -BackColor $healthColor

    $cpuValue = [decimal]$row["SqlCPUPercent"]
    $cpuColor = if ($cpuValue -ge 85) {
        [System.Drawing.Color]::FromArgb(220,53,69)
    }
    elseif ($cpuValue -ge 70) {
        [System.Drawing.Color]::FromArgb(255,193,7)
    }
    else {
        [System.Drawing.Color]::FromArgb(40,167,69)
    }
    Set-TileStyle -Panel $tileCPU.Panel -Label $tileCPU.Value -Value ([string]$cpuValue) -BackColor $cpuColor

    # Handle DBNull for memory
    $memValue = if ($row["AvailablePhysicalMB"] -is [System.DBNull]) { 0 } else { [decimal]$row["AvailablePhysicalMB"] }
    $memColor = if ($memValue -le 4096) {
        [System.Drawing.Color]::FromArgb(220,53,69)
    }
    elseif ($memValue -le 8192) {
        [System.Drawing.Color]::FromArgb(255,193,7)
    }
    else {
        [System.Drawing.Color]::FromArgb(40,167,69)
    }
    Set-TileStyle -Panel $tileAvailMem.Panel -Label $tileAvailMem.Value -Value ([string]$memValue) -BackColor $memColor

    # Handle DBNull for PLE
    $pleValue = if ($row["PLESeconds"] -is [System.DBNull]) { 0 } else { [decimal]$row["PLESeconds"] }
    $pleColor = if ($pleValue -le 1000) {
        [System.Drawing.Color]::FromArgb(220,53,69)
    }
    elseif ($pleValue -le 3000) {
        [System.Drawing.Color]::FromArgb(255,193,7)
    }
    else {
        [System.Drawing.Color]::FromArgb(40,167,69)
    }
    Set-TileStyle -Panel $tilePLE.Panel -Label $tilePLE.Value -Value ([string]$pleValue) -BackColor $pleColor

    $openColor = if ($openCount -gt 0) {
        [System.Drawing.Color]::FromArgb(255,193,7)
    }
    else {
        [System.Drawing.Color]::FromArgb(40,167,69)
    }
    Set-TileStyle -Panel $tileOpenAlerts.Panel -Label $tileOpenAlerts.Value -Value ([string]$openCount) -BackColor $openColor

    $critColor = if ($criticalCount -gt 0) {
        [System.Drawing.Color]::FromArgb(220,53,69)
    }
    else {
        [System.Drawing.Color]::FromArgb(40,167,69)
    }
    Set-TileStyle -Panel $tileCritAlerts.Panel -Label $tileCritAlerts.Value -Value ([string]$criticalCount) -BackColor $critColor
}

function Load-CPUTrend {
    if ($cbInstances.SelectedItem -eq $null) { return }

    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-CPUTrendData -InstanceID $instanceId
    $dgvCPU.DataSource = $dt
    $dgvCPU.Refresh()

    $cpuChart.Series["SQL CPU %"].Points.Clear()
    $cpuChart.Series["Idle CPU %"].Points.Clear()
    $cpuChart.Series["Other CPU %"].Points.Clear()

    $rows = @($dt.Rows) | Sort-Object { [datetime]$_.CaptureTime }

    foreach ($row in $rows) {
        $time = [datetime]$row["CaptureTime"]
        [void]$cpuChart.Series["SQL CPU %"].Points.AddXY($time, [decimal]$row["SqlCPUPercent"])
        [void]$cpuChart.Series["Idle CPU %"].Points.AddXY($time, [decimal]$row["IdleCPUPercent"])
        [void]$cpuChart.Series["Other CPU %"].Points.AddXY($time, [decimal]$row["OtherCPUPercent"])
    }
}

function Load-MemoryTrend {
    if ($cbInstances.SelectedItem -eq $null) { return }

    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-MemoryTrendData -InstanceID $instanceId
    $dgvMemory.DataSource = $dt
    $dgvMemory.Refresh()

    $memoryChart.Series["Available Memory MB"].Points.Clear()
    $memoryChart.Series["PLE Seconds"].Points.Clear()

    $rows = @($dt.Rows) | Sort-Object { [datetime]$_.CaptureTime }

    foreach ($row in $rows) {
        $time = [datetime]$row["CaptureTime"]
        [void]$memoryChart.Series["Available Memory MB"].Points.AddXY($time, [decimal]$row["AvailablePhysicalMB"])
        [void]$memoryChart.Series["PLE Seconds"].Points.AddXY($time, [decimal]$row["PLESeconds"])
    }
}

function Load-Alerts {
    if ($cbInstances.SelectedItem -eq $null) { return }

    $instanceId = $cbInstances.SelectedItem.InstanceID
    $criticalOnly = $chkCriticalOnly.Checked

    $dt = Get-OpenAlertsData -InstanceID $instanceId -CriticalOnly $criticalOnly
    $dgvAlerts.DataSource = $dt

    foreach ($gridRow in $dgvAlerts.Rows) {
        if ($gridRow.Cells["Severity"].Value -eq "Critical") {
            $gridRow.DefaultCellStyle.BackColor = [System.Drawing.Color]::MistyRose
            $gridRow.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
            $gridRow.DefaultCellStyle.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
        }
        elseif ($gridRow.Cells["Severity"].Value -eq "Warning") {
            $gridRow.DefaultCellStyle.BackColor = [System.Drawing.Color]::LemonChiffon
            $gridRow.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
        }
    }

    if ($dgvAlerts.Rows.Count -gt 0) {
        $dgvAlerts.ClearSelection()
        $dgvAlerts.Rows[0].Selected = $true
        Update-AlertSelectionInfo
    }
    else {
        $lblAlertInfo.Text = "No open alerts"
    }
}

function Update-AlertSelectionInfo {
    if ($dgvAlerts.SelectedRows.Count -eq 0) {
        $lblAlertInfo.Text = "No alert selected"
        return
    }

    $row = $dgvAlerts.SelectedRows[0]

    $alertId = $row.Cells["AlertID"].Value
    $severity = $row.Cells["Severity"].Value
    $module = $row.Cells["ModuleName"].Value
    $age = $row.Cells["AlertAgeMinutes"].Value

    $lblAlertInfo.Text = "Selected AlertID=$alertId | Severity=$severity | Module=$module | Age=$age min"
}

function Acknowledge-SelectedAlert {
    if ($dgvAlerts.SelectedRows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select an alert first.",
            "No Alert Selected",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $row = $dgvAlerts.SelectedRows[0]
    $alertId = [int64]$row.Cells["AlertID"].Value
    $alertTitle = [string]$row.Cells["AlertTitle"].Value

    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Acknowledge AlertID $alertId ?`n`n$alertTitle",
        "Confirm Acknowledge",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )

    if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) {
        return
    }

    try {
        $rowsUpdated = Acknowledge-Alert -AlertID $alertId

        if ([int]$rowsUpdated -gt 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "Alert acknowledged successfully.",
                "Success",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null

            Refresh-Dashboard
        }
        else {
            [System.Windows.Forms.MessageBox]::Show(
                "The selected alert may already be acknowledged.",
                "No Update",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to acknowledge alert.`n`n$($_.Exception.Message)",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
}

function Load-KPIs {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-KPIsData -InstanceID $instanceId
    $dgvKPIs.DataSource = $dt
}

function Load-Disks {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-DisksData -InstanceID $instanceId
    $dgvDisks.DataSource = $dt
}

function Load-Config {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-ConfigData -InstanceID $instanceId
    $dgvConfig.DataSource = $dt
}

function Load-IO {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-IOData -InstanceID $instanceId
    $dgvIO.DataSource = $dt
}

function Load-TempDB {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-TempDBData -InstanceID $instanceId
    $dgvTempDB.DataSource = $dt
}

function Load-Backups {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-BackupsData -InstanceID $instanceId
    $dgvBackups.DataSource = $dt
}

function Load-DBOptions {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-DBOptionsData -InstanceID $instanceId
    $dgvDBOptions.DataSource = $dt
}

# UNIQUE FEATURE: Load Execution Plans Data
function Load-ExecutionPlans {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-ExecutionPlansData -InstanceID $instanceId
    $dgvExecutionPlans.DataSource = $dt
}

# UNIQUE FEATURE: Load Memory Analysis Data
function Load-MemoryAnalysis {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    
    # Load Memory Clerks
    $dtClerks = Get-MemoryClerksData -InstanceID $instanceId
    $dgvMemoryClerks.DataSource = $dtClerks
    
    # Load Buffer Pool Analysis
    $dtBuffer = Get-BufferPoolAnalysisData -InstanceID $instanceId
    $dgvBufferPool.DataSource = $dtBuffer
}

function Load-Blocking {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-BlockingData -InstanceID $instanceId
    $dgvBlocking.DataSource = $dt
}

function Load-LongRunning {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-LongRunningData -InstanceID $instanceId
    $dgvLongRunning.DataSource = $dt
}

function Load-TopQueries {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-TopQueriesData -InstanceID $instanceId
    $dgvTopQueries.DataSource = $dt
}

function Load-MissingIndexes {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-MissingIndexesData -InstanceID $instanceId
    $dgvMissingIndexes.DataSource = $dt
}

function Load-IndexFragmentation {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-IndexFragmentationData -InstanceID $instanceId
    $dgvIndexFragmentation.DataSource = $dt
}

function Load-AG {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-AGData -InstanceID $instanceId
    $dgvAG.DataSource = $dt
}

function Load-Listeners {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-ListenersData -InstanceID $instanceId
    $dgvListeners.DataSource = $dt
}

function Load-AgentJobs {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-AgentJobsData -InstanceID $instanceId
    $dgvAgentJobs.DataSource = $dt
}

function Load-Deadlocks {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-DeadlocksData -InstanceID $instanceId
    $dgvDeadlocks.DataSource = $dt
}

function Load-Waits {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    $dt = Get-WaitsData -InstanceID $instanceId
    $dgvWaits.DataSource = $dt
}

function Load-Health {
    if ($cbInstances.SelectedItem -eq $null) { return }
    $instanceId = $cbInstances.SelectedItem.InstanceID
    
    # Load health data
    $dt = Get-CollectionHealthData -InstanceID $instanceId
    $dgvHealth.DataSource = $dt
    
    # Update summary tiles
    if ($dt -and $dt.Rows.Count -gt 0) {
        $healthy = ($dt.Rows | Where-Object { $_['HealthStatus'] -eq 'Healthy' }).Count
        $warning = ($dt.Rows | Where-Object { $_['HealthStatus'] -eq 'Warning' }).Count
        $critical = ($dt.Rows | Where-Object { $_['HealthStatus'] -eq 'Critical' }).Count
        $never = ($dt.Rows | Where-Object { $_['HealthStatus'] -eq 'Never Collected' }).Count
        
        $lblHealthHealthy.Text = "Healthy: $healthy"
        $lblHealthWarning.Text = "Warning: $warning"
        $lblHealthCritical.Text = "Critical: $critical"
        $lblHealthNever.Text = "Never Run: $never"
    }
    
    # Load issues
    $dtIssues = Get-CollectionGapsData -InstanceID $instanceId
    $dgvHealthIssues.DataSource = $dtIssues
}

function Load-SQLDictionary {
    $dictionaryContent = @"
{\rtf1\ansi\ansicpg1252\deff0\nouicompat\deflang1033{\fonttbl{\f0\fnil\fcharset0 Segoe UI;}}
{\colortbl ;\red0\green0\blue0;\red53\green69\blue220;\red40\green167\blue69;\red220\green53\blue69;}
{\*\generator Riched20 10.0.19041}\viewkind4\uc1 
\pard\sa200\sl276\slmult1\f0\fs22\b SQL Server Dictionary & Explanations\b0\par
\par
\b Performance Metrics:\b0\par
\tab\b CPU Utilization:\b0 Percentage of CPU time used by SQL Server processes vs. total CPU capacity. Normal: <80%, Warning: 80-90%, Critical: >90%\par
\tab\b Memory Usage:\b0 Amount of RAM allocated to SQL Server. Monitor for memory pressure and PLE (Page Life Expectancy)\par
\tab\b Page Life Expectancy (PLE):\b0 How long pages stay in memory before being flushed. Normal: >300 seconds, Warning: 100-300s, Critical: <100s\par
\tab\b Buffer Cache Hit Ratio:\b0 Percentage of data requests served from memory cache. Normal: >95%, Warning: 90-95%, Critical: <90%\par
\tab\b Disk I/O:\b0 Read/write operations per second and latency. Normal latency: <20ms reads, <10ms writes\par
\tab\b Wait Statistics:\b0 Time SQL Server spends waiting for resources. Key waits: CXPACKET, PAGEIOLATCH, LCK_M_*\par
\par
\b System Resources:\b0\par
\tab\b TempDB:\b0 Temporary database for sorting, temp tables, etc. Monitor space usage and contention\par
\tab\b Transaction Log:\b0 Records all database changes. Monitor growth, backup frequency, and VLF count\par
\tab\b Database Files:\b0 Data and log files. Monitor auto-growth events and file space usage\par
\tab\b Always On Availability Groups:\b0 High availability and disaster recovery solution. Monitor synchronization status\par
\tab\b SQL Agent Jobs:\b0 Scheduled maintenance and automation tasks. Monitor success/failure rates\par
\par
\b Database Objects:\b0\par
\tab\b Indexes:\b0 Data structures for fast data retrieval. Monitor fragmentation (>30% needs rebuild) and missing indexes\par
\tab\b Statistics:\b0 Data distribution information. Stale statistics can cause poor query performance\par
\tab\b Constraints:\b0 Rules enforcing data integrity (Primary Keys, Foreign Keys, Check Constraints)\par
\tab\b Triggers:\b0 Automatic code execution on data changes. Can impact performance if not optimized\par
\par
\b Security:\b0\par
\tab\b Authentication:\b0 User verification process. Windows vs. SQL Server authentication\par
\tab\b Authorization:\b0 Permissions and roles. Principle of least privilege applies\par
\tab\b Encryption:\b0 Data protection at rest (TDE) and in transit (SSL/TLS)\par
\tab\b Auditing:\b0 Tracking database activity for compliance and security monitoring\par
\par
\b Backup & Recovery:\b0\par
\tab\b Full Backup:\b0 Complete database copy. Should be performed regularly based on RTO/RPO\par
\tab\b Differential Backup:\b0 Only changes since last full backup. Faster than full backups\par
\tab\b Transaction Log Backup:\b0 Captures transaction log changes. Required for point-in-time recovery\par
\tab\b Recovery Models:\b0 Simple (no log backups), Full (all operations logged), Bulk-Logged (minimal logging for bulk ops)\par
\par
\b Troubleshooting:\b0\par
\tab\b Deadlocks:\b0 Two or more processes blocking each other. Monitor and resolve with proper indexing and query tuning\par
\tab\b Blocking:\b0 One process holding locks that others need. Identify head blockers and optimize queries\par
\tab\b Long-Running Queries:\b0 Queries taking excessive time. Tune with indexes, statistics, or query rewriting\par
\tab\b Memory Pressure:\b0 Insufficient memory for SQL Server operations. Add RAM or optimize memory usage\par
\tab\b Disk Space Issues:\b0 Running out of disk space for data/log files. Implement proper growth monitoring\par
\par
\b Key Performance Indicators (KPIs):\b0\par
\tab\b Batch Requests/sec:\b0 Number of SQL batches processed per second. Higher is generally better\par
\tab\b SQL Compilations/sec:\b0 Number of SQL compilations. High values indicate plan cache issues\par
\tab\b Page Reads/sec:\b0 Physical disk reads. High values may indicate memory pressure\par
\tab\b Lock Waits/sec:\b0 Lock contention. High values indicate blocking issues\par
\tab\b Deadlocks/sec:\b0 Deadlock frequency. Should be very low (near zero)\par
}

# -----------------------------------------------------------------
# Load SOPs content (markdown) and display in the RichTextBox
# -----------------------------------------------------------------
function global:Load-SOPs {
    try {
        $htmlPath = Join-Path $PSScriptRoot "..\Docs\SOPs.html"
        $mdPath   = Join-Path $PSScriptRoot "..\Docs\SOPs.md"
        if (Test-Path $htmlPath) {
            # Load pre‑formatted HTML version (preferred for complex tables)
            $script:webSOPs.DocumentText = Get-Content $htmlPath -Raw -ErrorAction Stop
        } elseif (Test-Path $mdPath) {
            $md = Get-Content $mdPath -Raw
            if (Get-Command ConvertFrom-Markdown -ErrorAction SilentlyContinue) {
                $html = (ConvertFrom-Markdown -InputObject $md).Html
            } else {
                $escaped = [System.Web.HttpUtility]::HtmlEncode($md)
                $html = "<pre>$escaped</pre>"
            }
            $script:webSOPs.DocumentText = $html
        } else {
            $script:webSOPs.DocumentText = "<p>SOPs file not found. Place a Markdown file at Docs\\SOPs.md or an HTML file at Docs\\SOPs.html.</p>"
        }
    } catch {
        $script:webSOPs.DocumentText = "<p>Error loading SOPs: $($_.Exception.Message)</p>"
    }
}
}

"@

    $rtbDictionary.Rtf = $dictionaryContent
}

function Load-CommonIssues {
    # Create sample issues data - in a real implementation, this would come from a database or configuration file
    $issues = @(
        @{
            IssueID = 1
            Category = "Performance"
            Severity = "Critical"
            Title = "High CPU Utilization (>90%)"
            Description = "SQL Server CPU usage is consistently above 90%"
            Frequency = "High"
            SOP = "1. Identify top CPU-consuming queries using sys.dm_exec_query_stats\n2. Check for missing indexes on heavily accessed tables\n3. Review query execution plans for inefficiencies\n4. Consider query parameterization for frequently executed queries\n5. Evaluate server hardware capacity and consider CPU upgrade if needed"
        },
        @{
            IssueID = 2
            Category = "Memory"
            Severity = "Critical"
            Title = "Low Page Life Expectancy (<100 seconds)"
            Description = "Pages are being flushed from memory too quickly"
            Frequency = "Medium"
            SOP = "1. Increase server memory if possible\n2. Review and optimize queries causing excessive memory usage\n3. Check for memory leaks in application code\n4. Adjust SQL Server memory configuration (max server memory)\n5. Monitor buffer cache hit ratio (>95% desired)"
        },
        @{
            IssueID = 3
            Category = "Storage"
            Severity = "High"
            Title = "Transaction Log Full"
            Description = "Transaction log has reached capacity"
            Frequency = "Medium"
            SOP = "1. Perform transaction log backup immediately\n2. Check log backup schedule and ensure it's running regularly\n3. Evaluate log growth settings and adjust if needed\n4. Consider switching to Simple recovery model if log backups aren't needed\n5. Monitor log space usage proactively"
        },
        @{
            IssueID = 4
            Category = "Availability"
            Severity = "Critical"
            Title = "Always On AG Synchronization Issues"
            Description = "Availability Group databases are not synchronizing"
            Frequency = "Low"
            SOP = "1. Check AG dashboard for synchronization status\n2. Review error logs on primary and secondary replicas\n3. Verify network connectivity between replicas\n4. Check disk space on secondary replicas\n5. Validate permissions for AG service accounts\n6. Consider failover if primary is unresponsive"
        },
        @{
            IssueID = 5
            Category = "Performance"
            Severity = "High"
            Title = "Excessive Blocking (>30 seconds)"
            Description = "Queries are being blocked for extended periods"
            Frequency = "High"
            SOP = "1. Identify head blocker using sp_who2 or DMVs\n2. Review blocking query and optimize with proper indexing\n3. Check for long-running transactions\n4. Consider query timeout settings\n5. Implement proper transaction isolation levels\n6. Monitor lock waits using sys.dm_os_wait_stats"
        },
        @{
            IssueID = 6
            Category = "Backup"
            Severity = "Critical"
            Title = "Failed Backup Jobs"
            Description = "Database backup jobs are failing"
            Frequency = "Medium"
            SOP = "1. Check SQL Agent job history for failure details\n2. Verify backup destination disk space and permissions\n3. Test backup file integrity with RESTORE VERIFYONLY\n4. Review backup maintenance plans\n5. Ensure service accounts have necessary permissions\n6. Implement backup monitoring and alerting"
        },
        @{
            IssueID = 7
            Category = "Security"
            Severity = "High"
            Title = "Failed Login Attempts"
            Description = "Multiple authentication failures detected"
            Frequency = "High"
            SOP = "1. Review SQL Server error logs for failed login details\n2. Check account lockout policies\n3. Verify password policies and complexity requirements\n4. Review application connection strings\n5. Consider implementing multi-factor authentication\n6. Monitor for brute force attacks"
        },
        @{
            IssueID = 8
            Category = "Performance"
            Severity = "Medium"
            Title = "High Disk I/O Latency (>50ms)"
            Description = "Disk operations are taking too long"
            Frequency = "Medium"
            SOP = "1. Use sys.dm_io_virtual_file_stats to identify slow disks\n2. Check for disk fragmentation and defragment if needed\n3. Review disk hardware (consider SSD upgrade)\n4. Optimize tempdb placement and configuration\n5. Implement proper indexing to reduce I/O\n6. Consider data compression for large tables"
        }
    )

    # Convert to DataTable for DataGridView
    $dt = New-Object System.Data.DataTable
    $dt.Columns.Add("IssueID", [int])
    $dt.Columns.Add("Category", [string])
    $dt.Columns.Add("Severity", [string])
    $dt.Columns.Add("Title", [string])
    $dt.Columns.Add("Frequency", [string])

    foreach ($issue in $issues) {
        $row = $dt.NewRow()
        $row["IssueID"] = $issue.IssueID
        $row["Category"] = $issue.Category
        $row["Severity"] = $issue.Severity
        $row["Title"] = $issue.Title
        $row["Frequency"] = $issue.Frequency
        $dt.Rows.Add($row)
    }

    $dgvIssues.DataSource = $dt

    # Set column headers
    $dgvIssues.Columns["IssueID"].HeaderText = "ID"
    $dgvIssues.Columns["Category"].HeaderText = "Category"
    $dgvIssues.Columns["Severity"].HeaderText = "Severity"
    $dgvIssues.Columns["Title"].HeaderText = "Issue Title"
    $dgvIssues.Columns["Frequency"].HeaderText = "Frequency"
    Ensure-GridButtonColumn -Grid $dgvIssues -ColumnName "SearchSolution" -HeaderText "Solution" -ButtonText "Search"

    # Auto-size columns
    $dgvIssues.AutoResizeColumns()

    # Display first issue details by default
    if ($issues.Count -gt 0) {
        $firstIssue = $issues[0]
        $rtbIssueDetails.Text = @"
Issue: $($firstIssue.Title)
Category: $($firstIssue.Category)
Severity: $($firstIssue.Severity)
Frequency: $($firstIssue.Frequency)

Description:
$($firstIssue.Description)

Standard Operating Procedure:
$($firstIssue.SOP)
"@
    }
}

function Load-WebAgent {
    try {
        $selectedDisplayName = if ($cbWebAgentInstance.SelectedItem) { [string]$cbWebAgentInstance.SelectedItem.DisplayName } else { $null }
        $instances = Get-AccessFilteredInstanceConfigs -Instances @(Get-SqlMonitorInstances | Where-Object { $_.IsActive })
        $cbWebAgentInstance.Items.Clear()
        foreach ($instance in $instances) {
            $cbWebAgentInstance.Items.Add($instance)
        }
        $cbWebAgentInstance.DisplayMember = "DisplayName"

        $selectionApplied = $false
        if ($selectedDisplayName) {
            for ($i = 0; $i -lt $cbWebAgentInstance.Items.Count; $i++) {
                if ($cbWebAgentInstance.Items[$i].DisplayName -eq $selectedDisplayName) {
                    $cbWebAgentInstance.SelectedIndex = $i
                    $selectionApplied = $true
                    break
                }
            }
        }
        if (-not $selectionApplied -and $cbWebAgentInstance.Items.Count -gt 0) {
            $cbWebAgentInstance.SelectedIndex = 0
        }

        Load-WebAgentCurrentIssues
    }
    catch {
        Write-MonitorLog "ERROR in Load-WebAgent: $($_.Exception.Message)" -Level 'Error'
    }
}

function Ensure-GridButtonColumn {
    param(
        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.DataGridView]$Grid,

        [Parameter(Mandatory = $true)]
        [string]$ColumnName,

        [Parameter(Mandatory = $true)]
        [string]$HeaderText,

        [Parameter(Mandatory = $true)]
        [string]$ButtonText
    )

    if (-not $Grid.Columns.Contains($ColumnName)) {
        $column = New-Object System.Windows.Forms.DataGridViewButtonColumn
        $column.Name = $ColumnName
        $column.HeaderText = $HeaderText
        $column.Text = $ButtonText
        $column.UseColumnTextForButtonValue = $true
        $column.FlatStyle = [System.Windows.Forms.FlatStyle]::Standard
        [void]$Grid.Columns.Add($column)
    }

    foreach ($column in $Grid.Columns) {
        $column.ReadOnly = ($column.Name -ne $ColumnName)
    }
}

function Get-SelectedWebAgentInstance {
    if ($cbWebAgentInstance.SelectedItem) {
        return $cbWebAgentInstance.SelectedItem
    }

    return $null
}

function Get-SelectedPatchManagerInstance {
    if ($cbPatchManagerInstance.SelectedItem) {
        return $cbPatchManagerInstance.SelectedItem
    }

    return $null
}

function Set-WebAgentSearchText {
    param(
        [string]$Text
    )

    $txtWebAgentSearch.Text = $Text
    $txtWebAgentSearch.ForeColor = [System.Drawing.Color]::Black
}

function Format-WebAgentIssueDetails {
    param(
        [Parameter(Mandatory = $true)]
        [object]$IssueRow
    )

    $details = @()
    $details += "Instance: $($IssueRow.DisplayName)"
    $details += "Alert Time: $($IssueRow.AlertTime)"
    $details += "Severity: $($IssueRow.Severity)"
    $details += "Module: $($IssueRow.ModuleName)"
    $details += "Title: $($IssueRow.AlertTitle)"
    if ($IssueRow.AgeMinutes -ne $null -and "$($IssueRow.AgeMinutes)" -ne '') {
        $details += "Age (minutes): $($IssueRow.AgeMinutes)"
    }
    $details += ""
    $details += "Alert Details:"
    $details += [string]$IssueRow.AlertDetails
    $details += ""
    $details += "Click the Search button in the row to retrieve web solutions for this issue."
    return ($details -join "`r`n")
}

function Format-WebAgentSolutionSet {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Query,

        [Parameter(Mandatory = $true)]
        [object[]]$Solutions
    )

    $lines = @()
    $lines += "Search Query: $Query"
    $lines += "Solutions Found: $($Solutions.Count)"

    $counter = 1
    foreach ($solution in $Solutions) {
        $lines += ""
        $lines += "$counter. $($solution.Title)"
        $lines += "Source: $($solution.Source)"
        $lines += "Type: $($solution.Type)"
        $lines += "Relevance: $($solution.Relevance) ($($solution.Confidence))"
        if ($solution.ErrorNumber) { $lines += "Error Number: $($solution.ErrorNumber)" }
        if ($solution.Snippet) { $lines += "Snippet: $($solution.Snippet)" }
        if ($solution.RecommendedActionsText) {
            $lines += "Recommended Actions:"
            $lines += $solution.RecommendedActionsText
        }
        $lines += "URL: $($solution.Url)"
        $counter++
    }

    return ($lines -join "`r`n")
}

function Search-WebAgentIssueRow {
    param(
        [Parameter(Mandatory = $true)]
        [int]$RowIndex
    )

    if ($RowIndex -lt 0 -or $RowIndex -ge $dgvWebAgentResults.Rows.Count) {
        return
    }

    $row = $dgvWebAgentResults.Rows[$RowIndex]
    if ($row.IsNewRow) {
        return
    }

    $alertTitle = [string]$row.Cells["AlertTitle"].Value
    $alertDetails = [string]$row.Cells["AlertDetails"].Value
    $queryParts = @($alertTitle, $alertDetails) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    $query = ($queryParts -join ' - ').Trim()

    if ([string]::IsNullOrWhiteSpace($query)) {
        return
    }

    Set-WebAgentSearchText -Text $alertTitle
    $instance = Get-SelectedWebAgentInstance
    $solutions = Invoke-WebSolutionsAgent -ErrorMessage $alertDetails -AlertTitle $alertTitle -Instance $instance -MaxResults 8
    $script:WebAgentResults = @($solutions)

    $rtbWebAgentDetails.Text = if ($solutions.Count -gt 0) {
        Format-WebAgentSolutionSet -Query $query -Solutions $solutions
    }
    else {
        "No solutions found for the selected issue.`r`n`r`n$alertTitle"
    }
}

function Search-CommonIssueSolution {
    param(
        [Parameter(Mandatory = $true)]
        [int]$RowIndex
    )

    if ($RowIndex -lt 0 -or $RowIndex -ge $dgvIssues.Rows.Count) {
        return
    }

    $row = $dgvIssues.Rows[$RowIndex]
    if ($row.IsNewRow) {
        return
    }

    $title = [string]$row.Cells["Title"].Value
    $issueId = [int]$row.Cells["IssueID"].Value
    $description = ''

    switch ($issueId) {
        1 { $description = 'SQL Server CPU usage is consistently above 90%' }
        2 { $description = 'Pages are being flushed from memory too quickly' }
        3 { $description = 'Transaction log has reached capacity' }
        4 { $description = 'Availability Group databases are not synchronizing' }
        5 { $description = 'Queries are being blocked for extended periods' }
        6 { $description = 'Database backup jobs are failing' }
        7 { $description = 'Multiple authentication failures detected' }
        8 { $description = 'Disk operations are taking too long' }
    }

    $query = @($title, $description) -join ' - '
    $tabs.SelectedTab = $tabWebAgent
    Load-WebAgent
    Set-WebAgentSearchText -Text $query
    Search-WebAgentErrorMessage
}

function Load-WebAgentCurrentIssues {
    try {
        $instance = Get-SelectedWebAgentInstance
        $dgvWebAgentResults.DataSource = $null

        if (-not $instance) {
            $rtbWebAgentDetails.Text = "Select an instance to load current errors and issues."
            return
        }

        $instanceId = Get-MonitorInstanceId -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -DisplayName $instance.DisplayName -SqlInstance $instance.SqlInstance
        if (-not $instanceId) {
            $rtbWebAgentDetails.Text = "The selected instance is not registered in the monitoring repository yet."
            return
        }

        $query = @"
SELECT TOP 25
    AlertID,
    DisplayName,
    AlertTime,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    DATEDIFF(MINUTE, AlertTime, GETDATE()) AS AgeMinutes
FROM mon.vw_AlertHistoryDetailed
WHERE InstanceID = @InstanceID
ORDER BY AlertTime DESC;
"@

        $dt = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters @{ InstanceID = $instanceId }
        $dgvWebAgentResults.DataSource = $dt
        Ensure-GridButtonColumn -Grid $dgvWebAgentResults -ColumnName "SearchSolution" -HeaderText "Solution" -ButtonText "Search"

        if ($dgvWebAgentResults.Columns.Contains("AlertDetails")) {
            $dgvWebAgentResults.Columns["AlertDetails"].Visible = $false
        }
        if ($dgvWebAgentResults.Columns.Contains("IsAcknowledged")) {
            $dgvWebAgentResults.Columns["IsAcknowledged"].Visible = $false
        }

        $dgvWebAgentResults.AutoResizeColumns()

        if ($dt.Rows.Count -gt 0) {
            $rtbWebAgentDetails.Text = Format-WebAgentIssueDetails -IssueRow $dt.Rows[0]
        }
        else {
            $rtbWebAgentDetails.Text = "No recent errors or issues were found for the selected instance."
        }
    }
    catch {
        Write-MonitorLog "ERROR in Load-WebAgentCurrentIssues: $($_.Exception.Message)" -Level 'Error'
        $rtbWebAgentDetails.Text = "Failed to load current errors and issues: $($_.Exception.Message)"
    }
}

function Format-WebAgentResultDetails {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Result
    )

    $details = @()
    $details += "Title: $($Result.Title)"
    $details += "Source: $($Result.Source)"
    $details += "Type: $($Result.Type)"
    $details += "Relevance: $($Result.Relevance) ($($Result.Confidence))"
    if ($Result.ErrorNumber) { $details += "Error Number: $($Result.ErrorNumber)" }
    if ($Result.Severity) { $details += "Severity: $($Result.Severity)" }
    if ($Result.State) { $details += "State: $($Result.State)" }
    if ($Result.Query) { $details += "Query Used: $($Result.Query)" }
    if ($Result.MatchedTerms) { $details += "Matched Terms: $($Result.MatchedTerms)" }
    $details += "URL: $($Result.Url)"
    if ($Result.Snippet) {
        $details += ""
        $details += "Snippet:"
        $details += $Result.Snippet
    }
    if ($Result.Summary) {
        $details += ""
        $details += "Summary:"
        $details += $Result.Summary
    }
    if ($Result.RecommendedActionsText) {
        $details += ""
        $details += "Recommended Actions:"
        $details += $Result.RecommendedActionsText
    }

    return ($details -join "`r`n")
}

function Search-WebAgentErrorMessage {
    try {
        $query = $txtWebAgentSearch.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($query) -or $query -eq "Search recent alerts or enter error text") {
            return
        }

        $instance = Get-SelectedWebAgentInstance
        $solutions = Invoke-WebSolutionsAgent -ErrorMessage $query -Instance $instance -MaxResults 10

        $script:WebAgentResults = @($solutions)
        $rtbWebAgentDetails.Text = if ($solutions.Count -gt 0) {
            Format-WebAgentSolutionSet -Query $query -Solutions $solutions
        }
        else {
            "No solutions found for the provided message."
        }
    }
    catch {
        Write-MonitorLog "ERROR in Search-WebAgentErrorMessage: $($_.Exception.Message)" -Level 'Error'
        $rtbWebAgentDetails.Text = "Search failed: $($_.Exception.Message)"
    }
}

function Diagnose-WebAgentIssue {
    try {
        $instance = Get-SelectedWebAgentInstance
        $alertTitle = $null
        $alertDetails = $null

        if ($dgvWebAgentResults.SelectedRows.Count -gt 0) {
            $selectedRow = $dgvWebAgentResults.SelectedRows[0]
            $alertTitle = [string]$selectedRow.Cells["AlertTitle"].Value
            $alertDetails = [string]$selectedRow.Cells["AlertDetails"].Value
        }

        if (-not $alertDetails) {
            $searchText = $txtWebAgentSearch.Text.Trim()
            if ([string]::IsNullOrWhiteSpace($searchText) -or $searchText -eq "Search recent alerts or enter error text") {
                return
            }
            $alertDetails = $searchText
            $alertTitle = $searchText
        }

        $diagnosis = Invoke-WebDiagnosticAssistant -AlertTitle $alertTitle -AlertDetails $alertDetails -Instance $instance -MaxRecommendations 5
        $rtbWebAgentDetails.Text = Format-WebAgentDiagnosisResult -Diagnosis $diagnosis
    }
    catch {
        Write-MonitorLog "ERROR in Diagnose-WebAgentIssue: $($_.Exception.Message)" -Level 'Error'
        $rtbWebAgentDetails.Text = "Diagnostic analysis failed: $($_.Exception.Message)"
    }
}

function Search-WebAgentRecentAlerts {
    try {
        Load-WebAgentCurrentIssues
    }
    catch {
        Write-MonitorLog "ERROR in Search-WebAgentRecentAlerts: $($_.Exception.Message)" -Level 'Error'
        $rtbWebAgentDetails.Text = "Search failed: $($_.Exception.Message)"
    }
}

function Load-PatchManager {
    try {
        $selectedDisplayName = if ($cbPatchManagerInstance.SelectedItem) { [string]$cbPatchManagerInstance.SelectedItem.DisplayName } else { $null }
        $instances = Get-AccessFilteredInstanceConfigs -Instances @(Get-SqlMonitorInstances | Where-Object { $_.IsActive })
        $cbPatchManagerInstance.Items.Clear()
        foreach ($instance in $instances) {
            $cbPatchManagerInstance.Items.Add($instance)
        }
        $cbPatchManagerInstance.DisplayMember = "DisplayName"

        $selectionApplied = $false
        if ($selectedDisplayName) {
            for ($i = 0; $i -lt $cbPatchManagerInstance.Items.Count; $i++) {
                if ($cbPatchManagerInstance.Items[$i].DisplayName -eq $selectedDisplayName) {
                    $cbPatchManagerInstance.SelectedIndex = $i
                    $selectionApplied = $true
                    break
                }
            }
        }
        if (-not $selectionApplied -and $cbPatchManagerInstance.Items.Count -gt 0) {
            $cbPatchManagerInstance.SelectedIndex = 0
        }

        if (-not $script:PatchStatus) {
            $dgvPatchStatus.DataSource = $null
            $rtbPatchManagerDetails.Text = "Press 'Refresh Patch Status' to retrieve patch status."
            return
        }

        Set-PatchStatusGrid
    }
    catch {
        Write-MonitorLog "ERROR in Load-PatchManager: $($_.Exception.Message)" -Level 'Error'
    }
}

function Set-PatchStatusGrid {
    $dgvPatchStatus.DataSource = $null
    if (-not $script:PatchStatus) {
        return
    }

    $dgvPatchStatus.DataSource = @(
        $script:PatchStatus |
            Select-Object InstanceName, VersionName, ProductVersion, CurrentPatchKB, LatestPatchKB, RecommendedKB, CurrentUpdate, CurrentChannel, PatchStatus, @{Name='AvailablePatches'; Expression={ ($_.AvailablePatches | Measure-Object).Count }}, LastChecked
    )
    $dgvPatchStatus.AutoResizeColumns()
}

function Format-PatchStatusDetails {
    param(
        [Parameter(Mandatory = $true)]
        [object]$PatchStatus
    )

    $details = @()
    $details += "Instance: $($PatchStatus.InstanceName)"
    $details += "SQL Instance: $($PatchStatus.SqlInstance)"
    $details += "Version: $($PatchStatus.VersionName) ($($PatchStatus.ProductVersion))"
    $details += "Current Update: $($PatchStatus.CurrentUpdate)"
    $details += "Current Patch KB: $($PatchStatus.CurrentPatchKB)"
    $details += "Current Patch Build: $($PatchStatus.CurrentPatchBuild)"
    $details += "Latest Patch KB: $($PatchStatus.LatestPatchKB)"
    $details += "Latest Patch Build: $($PatchStatus.LatestPatchBuild)"
    $details += "Servicing Channel: $($PatchStatus.CurrentChannel)"
    $details += "Patch Status: $($PatchStatus.PatchStatus)"
    $details += "Edition: $($PatchStatus.Edition)"
    $details += "Product Level: $($PatchStatus.ProductLevel)"
    $details += "Last Checked: $($PatchStatus.LastChecked)"
    $details += ""
    $details += "Version String:"
    $details += $PatchStatus.FullVersion
    $details += ""
    $details += "Status Summary:"
    $details += $PatchStatus.StatusSummary

    if ($PatchStatus.RecommendedPatch) {
        $details += ""
        $details += "Recommended Patch:"
        $details += "  $($PatchStatus.RecommendedPatch.DisplayLabel) $($PatchStatus.RecommendedPatch.KBNumber)"
        $details += "  Build: $($PatchStatus.RecommendedPatch.BuildVersion)"
        $details += "  Release Date: $($PatchStatus.RecommendedPatch.ReleaseDate)"
        $details += "  Catalog: $($PatchStatus.RecommendedPatch.CatalogUrl)"
    }

    if ($PatchStatus.AvailablePatches -and $PatchStatus.AvailablePatches.Count -gt 0) {
        $details += ""
        $details += "Available Patches:"
        foreach ($patch in $PatchStatus.AvailablePatches) {
            $details += "- $($patch.DisplayLabel) $($patch.KBNumber)"
            $details += "  Build: $($patch.BuildVersion)"
            $details += "  Release Date: $($patch.ReleaseDate)"
            $details += "  Catalog: $($patch.CatalogUrl)"
        }
    }

    return ($details -join "`r`n")
}

function Refresh-PatchManagerStatus {
    try {
        $selectedInstance = Get-SelectedPatchManagerInstance
        if ($selectedInstance) {
            $script:PatchStatus = @(Get-SQLServerPatchStatus -Instances @($selectedInstance))
        }
        else {
            $script:PatchStatus = @(Get-SQLServerPatchStatus)
        }
        Load-PatchManager
        if ($script:PatchStatus.Count -gt 0) {
            $rtbPatchManagerDetails.Text = Format-PatchStatusDetails -PatchStatus $script:PatchStatus[0]
        }
    }
    catch {
        Write-MonitorLog "ERROR in Refresh-PatchManagerStatus: $($_.Exception.Message)" -Level 'Error'
        $rtbPatchManagerDetails.Text = "Patch status refresh failed: $($_.Exception.Message)"
    }
}

function Invoke-PatchDownload {
    try {
        if (-not $script:PatchStatus) {
            $rtbPatchManagerDetails.Text = "No patch status available. Refresh patch status first."
            return
        }

        $instance = Get-SelectedPatchManagerInstance
        if (-not $instance) {
            $rtbPatchManagerDetails.Text = "No instance selected for patch download."
            return
        }

        $downloadPath = $txtPatchDownloadPath.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($downloadPath)) {
            $downloadPath = Join-Path $projectRoot 'Patches'
        }
        if (-not (Test-Path $downloadPath)) {
            New-Item -ItemType Directory -Path $downloadPath -Force | Out-Null
        }

        $selectedStatus = $script:PatchStatus | Where-Object { $_.InstanceName -eq $instance.DisplayName } | Select-Object -First 1
        if ($selectedStatus -and $selectedStatus.PatchStatus -ne 'UpdateAvailable') {
            $rtbPatchManagerDetails.Text = Format-PatchStatusDetails -PatchStatus $selectedStatus
            return
        }

        $downloads = Invoke-SQLServerPatchDownloader -Instance $instance -Patch (if ($selectedStatus) { $selectedStatus.RecommendedPatch } else { $null }) -DownloadPath $downloadPath -Force:$chkPatchForce.Checked
        if ($downloads.Count -gt 0) {
            $rtbPatchManagerDetails.Text = "Downloaded $($downloads.Count) patch file(s) to $downloadPath.`r`n`r`n" + (($downloads | ForEach-Object { "- $($_.FileName) ($($_.KBNumber))" }) -join "`r`n")
        }
        else {
            $rtbPatchManagerDetails.Text = "No patch files were downloaded. The catalog may not have returned direct download links for the selected patch."
        }
    }
    catch {
        Write-MonitorLog "ERROR in Invoke-PatchDownload: $($_.Exception.Message)" -Level 'Error'
        $rtbPatchManagerDetails.Text = "Patch download failed: $($_.Exception.Message)"
    }
}

function Refresh-CurrentTabData {
    if ($tabs.SelectedTab -eq $tabOverview) {
        Update-OverviewTiles
    }
    elseif ($tabs.SelectedTab -eq $tabHealth) {
        Load-Health
    }
    elseif ($tabs.SelectedTab -eq $tabKPIs) {
        Load-KPIs
    }
    elseif ($tabs.SelectedTab -eq $tabCPU) {
        Load-CPUTrend
    }
    elseif ($tabs.SelectedTab -eq $tabMemory) {
        Load-MemoryTrend
    }
    elseif ($tabs.SelectedTab -eq $tabDisks) {
        Load-Disks
    }
    elseif ($tabs.SelectedTab -eq $tabConfig) {
        Load-Config
    }
    elseif ($tabs.SelectedTab -eq $tabIO) {
        Load-IO
    }
    elseif ($tabs.SelectedTab -eq $tabTempDB) {
        Load-TempDB
    }
    elseif ($tabs.SelectedTab -eq $tabBackups) {
        Load-Backups
    }
    elseif ($tabs.SelectedTab -eq $tabDBOptions) {
        Load-DBOptions
    }
    elseif ($tabs.SelectedTab -eq $tabBlocking) {
        Load-Blocking
    }
    elseif ($tabs.SelectedTab -eq $tabLongRunning) {
        Load-LongRunning
    }
    elseif ($tabs.SelectedTab -eq $tabTopQueries) {
        Load-TopQueries
    }
    elseif ($tabs.SelectedTab -eq $tabMissingIndexes) {
        Load-MissingIndexes
    }
    elseif ($tabs.SelectedTab -eq $tabIndexFragmentation) {
        Load-IndexFragmentation
    }
    elseif ($tabs.SelectedTab -eq $tabAG) {
        Load-AG
    }
    elseif ($tabs.SelectedTab -eq $tabListeners) {
        Load-Listeners
    }
    elseif ($tabs.SelectedTab -eq $tabAgentJobs) {
        Load-AgentJobs
    }
    elseif ($tabs.SelectedTab -eq $tabDeadlocks) {
        Load-Deadlocks
    }
    elseif ($tabs.SelectedTab -eq $tabWaits) {
        Load-Waits
    }
    elseif ($tabs.SelectedTab -eq $tabAlerts) {
        Load-Alerts
    }
    elseif ($tabs.SelectedTab -eq $tabExecutionPlans) {
        Load-ExecutionPlans
    }
    elseif ($tabs.SelectedTab -eq $tabIssues) {
        Load-SOPs
    }
    elseif ($tabs.SelectedTab -eq $tabMemoryAnalysis) {
        Load-MemoryAnalysis
    }
    elseif ($tabs.SelectedTab -eq $tabUsers) {
        Refresh-DashboardUsers
        Populate-UserInstanceChecklist
    }
    elseif ($tabs.SelectedTab -eq $tabInstances -or
           $tabs.SelectedTab -eq $tabNotifications -or
           $tabs.SelectedTab -eq $tabThresholds) {
        # Avoid overwriting unsaved edits on configuration tabs during auto-refresh.
        return
    }
    elseif ($tabs.SelectedTab -eq $tabAlertHistory) {
        Populate-AlertHistoryInstances
        Load-AlertHistory
    }
    elseif ($tabs.SelectedTab -eq $tabAnalytics) {
        Populate-AnalyticsInstances
        Load-PerformanceAnalytics
    }
    elseif ($tabs.SelectedTab -eq $tabDictionary) {
        Load-SQLDictionary
    }
    elseif ($tabs.SelectedTab -eq $tabIssues) {
        Load-CommonIssues
    }
    elseif ($tabs.SelectedTab -eq $tabWebAgent) {
        Load-WebAgent
    }
    elseif ($tabs.SelectedTab -eq $tabPatchManager) {
        Load-PatchManager
    }
}

function Refresh-Dashboard {
    param([switch]$Full)

    if ($script:IsRefreshing) { return }

    $script:IsRefreshing = $true
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    try {
        if ($lblCollectorStatus) {
            $scopeText = if ($Full) { "full dashboard" } else { "active tab" }
            $lblCollectorStatus.Text = "Status: Refreshing $scopeText..."
        }

        if ($form) {
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            $form.SuspendLayout()
        }

        [System.Windows.Forms.Application]::DoEvents()

        Load-Overview
        Update-OverviewTiles

        if ($Full) {
            Load-Health
            Load-KPIs
            Load-CPUTrend
            Load-MemoryTrend
            Load-Disks
            Load-Config
            Load-IO
            Load-TempDB
            Load-Backups
            Load-DBOptions
            Load-Blocking
            Load-LongRunning
            Load-TopQueries
            Load-MissingIndexes
            Load-IndexFragmentation
            Load-AG
            Load-Listeners
            Load-AgentJobs
            Load-Deadlocks
            Load-Waits
            Load-Alerts
            Load-SQLDictionary
            Load-CommonIssues
        }
        else {
            Refresh-CurrentTabData
        }

        $stopwatch.Stop()
        if ($lblCollectorStatus) {
            $lblCollectorStatus.Text = "Status: Ready (refreshed in $([math]::Round($stopwatch.Elapsed.TotalSeconds, 1)) sec)"
        }
    }
    catch {
        if ($lblCollectorStatus) {
            $lblCollectorStatus.Text = "Status: Refresh failed"
        }
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to refresh dashboard: $($_.Exception.Message)",
            "Refresh Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    finally {
        if ($form) {
            $form.ResumeLayout($true)
            $form.Cursor = [System.Windows.Forms.Cursors]::Default
        }
        $script:IsRefreshing = $false
    }
}

function Run-SelectedInstanceCollectors {
    if ($cbInstances.SelectedItem -eq $null) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select a server instance first.",
            "Select Instance",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $displayName = $cbInstances.SelectedItem.DisplayName
    
    # Build path to Run-Collectors.bat in the repository root
    $runFilePath = Join-Path (Split-Path -Parent $PSScriptRoot) "Run-Collectors.bat"

    if (-not (Test-Path $runFilePath)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Run-Collectors.bat could not be found at: $runFilePath`n`nEnsure the script is present in the repository root.",
            "File Not Found",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
        return
    }

    try {
        $btnRun.Enabled = $false
        $btnRefresh.Enabled = $false
        $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
        $collectorGroup = [string]$cbOverviewCollectorGroup.SelectedItem
        if ([string]::IsNullOrWhiteSpace($collectorGroup)) { $collectorGroup = "All" }
        if ($lblCollectorStatus) { $lblCollectorStatus.Text = "Status: Running $collectorGroup collectors for '$displayName'..." }
        [System.Windows.Forms.Application]::DoEvents()

        $previousNoPause = $env:SQLMON_NO_PAUSE
        $env:SQLMON_NO_PAUSE = "1"
        try {
            $proc = Start-Process -FilePath $runFilePath -ArgumentList @($displayName, $collectorGroup) -WorkingDirectory (Split-Path $runFilePath) -Wait -PassThru
        }
        finally {
            if ($null -eq $previousNoPause) {
                Remove-Item Env:\SQLMON_NO_PAUSE -ErrorAction SilentlyContinue
            }
            else {
                $env:SQLMON_NO_PAUSE = $previousNoPause
            }
        }

        if ($proc.ExitCode -eq 0) {
            if ($lblCollectorStatus) { $lblCollectorStatus.Text = "Status: Completed collection for '$displayName'." }
            [System.Windows.Forms.Application]::DoEvents()
            [System.Windows.Forms.MessageBox]::Show(
                "Data collection completed for '$displayName'.",
                "Collection Completed",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
        }
        else {
            if ($lblCollectorStatus) { $lblCollectorStatus.Text = "Status: Collection failed for '$displayName'." }
            [System.Windows.Forms.Application]::DoEvents()
            [System.Windows.Forms.MessageBox]::Show(
                "Data collection failed for '$displayName'. Exit code $($proc.ExitCode).",
                "Collection Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
        }
    }
    catch {
        if ($lblCollectorStatus) { $lblCollectorStatus.Text = "Status: Data collection failed for '$displayName'." }
        [System.Windows.Forms.Application]::DoEvents()
        [System.Windows.Forms.MessageBox]::Show(
            "Data collection failed: $($_.Exception.Message)",
            "Collection Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    finally {
        $btnRun.Enabled = $true
        $btnRefresh.Enabled = $true
        $form.Cursor = [System.Windows.Forms.Cursors]::Default
        if ($lblCollectorStatus) { $lblCollectorStatus.Text = "Status: Ready" }
    }

    Refresh-Dashboard
}

function Get-InstanceScheduleTaskName {
    param([int]$InstanceID)
    return "SQLMonitor-Collectors-Instance-$InstanceID"
}

function Get-InstanceScheduleTask {
    param([int]$InstanceID)
    return Get-ScheduledTask -TaskName (Get-InstanceScheduleTaskName -InstanceID $InstanceID) -ErrorAction SilentlyContinue
}

function Get-InstanceScheduleStatus {
    param([int]$InstanceID)

    $task = Get-InstanceScheduleTask -InstanceID $InstanceID
    if (-not $task) {
        return "Schedule: none"
    }

    $state = $task.State
    $trigger = $task.Triggers | Select-Object -First 1
    if ($trigger -ne $null) {
        $repeatMinutes = if ($trigger.RepetitionInterval -ne $null) { [int]$trigger.RepetitionInterval.TotalMinutes } else { 0 }
        if ($repeatMinutes -eq 5) {
            return "Schedule: every 5 min ($state)"
        }
        if ($repeatMinutes -eq 30) {
            return "Schedule: every 30 min ($state)"
        }

        if ($trigger.TriggerType -eq 'Daily' -and $trigger.StartBoundary) {
            $time = [datetime]$trigger.StartBoundary
            return "Schedule: daily at $($time.ToString('HH:mm')) ($state)"
        }
    }

    return "Schedule: configured ($state)"
}

function Update-ScheduleInfo {
    if ($cbInstances.SelectedItem -eq $null) {
        $lblScheduleInfo.Text = "Schedule: none"
        return
    }

    $instanceId = $cbInstances.SelectedItem.InstanceID
    $lblScheduleInfo.Text = Get-InstanceScheduleStatus -InstanceID $instanceId
}

function Remove-InstanceSchedule {
    param([int]$InstanceID)

    $taskName = Get-InstanceScheduleTaskName -InstanceID $InstanceID
    $task = Get-InstanceScheduleTask -InstanceID $InstanceID
    if ($task) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    }
}

function Set-InstanceSchedule {
    param(
        [int]$InstanceID,
        [string]$ScheduleType,
        [string]$CollectorGroup,
        [datetime]$DailyAt
    )

    $displayName = $cbInstances.SelectedItem.DisplayName
    $taskName = Get-InstanceScheduleTaskName -InstanceID $InstanceID
    $runFilePath = Join-Path (Split-Path -Parent $PSScriptRoot) "Run-Collectors.bat"

    if (-not (Test-Path $runFilePath)) {
        throw "Run-Collectors.bat could not be found at: $runFilePath"
    }

    if ($ScheduleType -eq 'Manual only') {
        Remove-InstanceSchedule -InstanceID $InstanceID
        return
    }

    $action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$runFilePath`" `"$displayName`" `"$CollectorGroup`""

    switch ($ScheduleType) {
        'Every 5 minutes' {
            $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 365)
        }
        'Every 30 minutes' {
            $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 30) -RepetitionDuration (New-TimeSpan -Days 365)
        }
        'Daily at' {
            $trigger = New-ScheduledTaskTrigger -Daily -At $DailyAt.ToString('HH:mm')
        }
        Default {
            throw "Unsupported schedule type: $ScheduleType"
        }
    }

    $settings = New-ScheduledTaskSettingsSet `
        -AllowStartIfOnBatteries `
        -DontStopIfGoingOnBatteries `
        -StartWhenAvailable `
        -ExecutionTimeLimit (New-TimeSpan -Hours 2)

    $taskObj = New-ScheduledTask -Action $action -Trigger $trigger -Settings $settings
    Register-ScheduledTask -TaskName $taskName -InputObject $taskObj -Force
}

# ------------------------------------------------------------
# Instance Group Execution controls
# ------------------------------------------------------------
$lblGroupHeader = New-Object System.Windows.Forms.Label
$lblGroupHeader.Text = "Run Collectors by Instance Group"
$lblGroupHeader.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblGroupHeader.AutoSize = $true
$lblGroupHeader.Location = New-Object System.Drawing.Point(20, 20)
$tabInstanceGroup.Controls.Add($lblGroupHeader)

$lblCollectorGroup = New-Object System.Windows.Forms.Label
$lblCollectorGroup.Text = "Collector Group:"
$lblCollectorGroup.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblCollectorGroup.AutoSize = $true
$lblCollectorGroup.Location = New-Object System.Drawing.Point(20, 60)
$tabInstanceGroup.Controls.Add($lblCollectorGroup)

$cbInstanceGroupCollectorGroup = New-Object System.Windows.Forms.ComboBox
$cbInstanceGroupCollectorGroup.Location = New-Object System.Drawing.Point(150, 55)
$cbInstanceGroupCollectorGroup.Size = New-Object System.Drawing.Size(200, 30)
$cbInstanceGroupCollectorGroup.DropDownStyle = "DropDownList"
$cbInstanceGroupCollectorGroup.Items.AddRange(@("Core", "Advanced", "Daily", "All"))
$cbInstanceGroupCollectorGroup.SelectedIndex = 0
$tabInstanceGroup.Controls.Add($cbInstanceGroupCollectorGroup)

$lblInstanceFilter = New-Object System.Windows.Forms.Label
$lblInstanceFilter.Text = "Instance Filter (optional):"
$lblInstanceFilter.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$lblInstanceFilter.AutoSize = $true
$lblInstanceFilter.Location = New-Object System.Drawing.Point(20, 100)
$tabInstanceGroup.Controls.Add($lblInstanceFilter)

$txtInstanceFilter = New-Object System.Windows.Forms.TextBox
$txtInstanceFilter.Location = New-Object System.Drawing.Point(200, 95)
$txtInstanceFilter.Size = New-Object System.Drawing.Size(300, 30)
$tabInstanceGroup.Controls.Add($txtInstanceFilter)

$btnRunGroup = New-Object System.Windows.Forms.Button
$btnRunGroup.Text = "Run Collectors"
$btnRunGroup.Location = New-Object System.Drawing.Point(20, 140)
$btnRunGroup.Size = New-Object System.Drawing.Size(150, 40)
$btnRunGroup.BackColor = [System.Drawing.Color]::LightGreen
$tabInstanceGroup.Controls.Add($btnRunGroup)

$txtGroupOutput = New-Object System.Windows.Forms.TextBox
$txtGroupOutput.Location = New-Object System.Drawing.Point(20, 200)
$txtGroupOutput.Size = New-Object System.Drawing.Size(1340, 580)
$txtGroupOutput.Multiline = $true
$txtGroupOutput.ScrollBars = "Vertical"
$txtGroupOutput.Font = New-Object System.Drawing.Font("Consolas", 9)
$txtGroupOutput.ReadOnly = $true
$tabInstanceGroup.Controls.Add($txtGroupOutput)

function Run-InstanceGroupCollectors {
    param(
        [string]$CollectorGroup,
        [string]$InstanceFilter = ""
    )

    $scriptPath = Join-Path $PSScriptRoot "..\Jobs\Run-Collectors-InstanceGroup.ps1"
    if (-not (Test-Path $scriptPath)) {
        $txtGroupOutput.AppendText("ERROR: Script not found at $scriptPath`r`n")
        return
    }

    $txtGroupOutput.AppendText("Starting collectors for group: $CollectorGroup`r`n")
    if ($InstanceFilter -ne "") {
        $txtGroupOutput.AppendText("Instance filter: $InstanceFilter`r`n")
    }
    
    $arguments = @("-CollectorGroup", $CollectorGroup)
    if ($InstanceFilter -ne "") {
        $arguments += "-InstanceFilter"
        $arguments += $InstanceFilter
    }

    $cmdDisplay = "powershell.exe -File '$scriptPath' -CollectorGroup '$CollectorGroup'"
    if ($InstanceFilter -ne "") { $cmdDisplay += " -InstanceFilter '$InstanceFilter'" }
    $txtGroupOutput.AppendText("Command: $cmdDisplay`r`n`r`n")

    try {
        $process = Start-Process -FilePath "powershell.exe" -ArgumentList @("-File", "`"$scriptPath`"", "-CollectorGroup", $CollectorGroup, "-InstanceFilter", $InstanceFilter) -NoNewWindow -PassThru -RedirectStandardOutput "temp_output.txt" -RedirectStandardError "temp_error.txt"
        
        # Wait for completion
        $process.WaitForExit()
        
        $output = Get-Content "temp_output.txt" -ErrorAction SilentlyContinue
        $errorOutput = Get-Content "temp_error.txt" -ErrorAction SilentlyContinue
        
        if ($output) {
            $txtGroupOutput.AppendText("OUTPUT:`r`n$output`r`n")
        }
        if ($errorOutput) {
            $txtGroupOutput.AppendText("ERRORS:`r`n$errorOutput`r`n")
        }
        
        $txtGroupOutput.AppendText("`r`nProcess completed with exit code: $($process.ExitCode)`r`n")
        
        # Clean up temp files
        Remove-Item "temp_output.txt" -ErrorAction SilentlyContinue
        Remove-Item "temp_error.txt" -ErrorAction SilentlyContinue
        
    }
    catch {
        $txtGroupOutput.AppendText("ERROR: $($_.Exception.Message)`r`n")
    }
}

function Apply-RoleRestrictions {
    if (Test-AdminAccess) {
        return
    }

    foreach ($tab in @($tabInstances, $tabNotifications, $tabThresholds, $tabInstanceGroup, $tabUsers)) {
        if ($tabs.TabPages.Contains($tab)) {
            $tabs.TabPages.Remove($tab)
        }
        Remove-SidebarNavButton -TabPage $tab
    }

    foreach ($button in @(
        $btnRun,
        $btnSetSchedule,
        $btnRemoveSchedule,
        $btnNewInstance,
        $btnSaveInstance,
        $btnDeleteInstance,
        $btnBrowseFile,
        $btnImportInstances,
        $btnSaveNotifications,
        $btnTestEmail,
        $btnTestTeams,
        $btnSaveThreshold,
        $btnRunAlertEngine,
        $btnAcknowledgeAlert,
        $btnAcknowledgeSelectedHistory,
        $btnBulkAcknowledge,
        $btnClearAlertHistory,
        $btnRunGroup,
        $btnNewUser,
        $btnSaveUser,
        $btnDeleteUser
    )) {
        if ($null -ne $button) {
            $button.Enabled = $false
        }
    }

    $lblCollectorStatus.Text = "Status: Signed in as $($script:CurrentUser.RoleName); write actions are disabled"
}

# ------------------------------------------------------------
# Events
$btnBackToOverview.Add_Click({
    $overviewResult = Show-ServerOverviewDialog
    if ($overviewResult -is [int]) {
        # User selected a different instance
        $script:CurrentInstanceId = $overviewResult
        Load-Overview -PreSelectedInstanceId $overviewResult
        Refresh-Dashboard -Full
    }
    elseif ($overviewResult -eq "Users") {
        $tabs.SelectedTab = $tabInstances
        Update-SidebarSelection
    }
    elseif ($overviewResult -eq "Instances") {
        $tabs.SelectedTab = $tabInstances
        Update-SidebarSelection
    }
})

$btnRefresh.Add_Click({
    Refresh-Dashboard -Full
})

$btnApplyRefresh.Add_Click({
    Apply-RefreshIntervalSettings -ShowStatus $true
})

$chkAutoRefresh.Add_CheckedChanged({
    Apply-RefreshIntervalSettings -ShowStatus $true
})

$btnRun.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Run collectors")) { return }
    Run-SelectedInstanceCollectors
})

$btnSetSchedule.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Set schedule")) { return }
    if ($cbInstances.SelectedItem -eq $null) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select a server instance first.",
            "Select Instance",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $instanceId = $cbInstances.SelectedItem.InstanceID
    $scheduleType = $cbScheduleType.SelectedItem
    $dailyTime = $dtpScheduleTime.Value

    try {
        Set-InstanceSchedule -InstanceID $instanceId -ScheduleType $scheduleType -CollectorGroup $cbOverviewCollectorGroup.SelectedItem -DailyAt $dailyTime
        [System.Windows.Forms.MessageBox]::Show(
            "Schedule updated for '$($cbInstances.SelectedItem.DisplayName)'.",
            "Schedule Saved",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Failed to save schedule: $($_.Exception.Message)",
            "Schedule Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }

    Update-ScheduleInfo
})

$btnRemoveSchedule.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Remove schedule")) { return }
    if ($cbInstances.SelectedItem -eq $null) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select a server instance first.",
            "Select Instance",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
        return
    }

    $instanceId = $cbInstances.SelectedItem.InstanceID
    Remove-InstanceSchedule -InstanceID $instanceId
    [System.Windows.Forms.MessageBox]::Show(
        "Schedule removed for '$($cbInstances.SelectedItem.DisplayName)'.",
        "Schedule Removed",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
    Update-ScheduleInfo
})

$btnNewInstance.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Create instance")) { return }
    Show-NewInstanceForm -OwnerForm $form
})

$btnSaveInstance.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Save instance")) { return }
    Save-SelectedInstance
})

$btnDeleteInstance.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Delete instance")) { return }
    Delete-SelectedInstance
})

$btnReloadInstances.Add_Click({
    Reload-InstanceConfigs
})

$btnSaveNotifications.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Save notifications")) { return }
    Save-NotificationsConfigFromUI
})

$btnReloadNotifications.Add_Click({
    Reload-NotificationsConfigFromUI
})

$btnTestEmail.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Send test email")) { return }
    Send-TestEmail
})

$btnTestTeams.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Send test Teams message")) { return }
    Send-TestTeamsMessage
})

$btnSaveThreshold.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Save alert threshold")) { return }
    Save-SelectedThreshold
})

$btnReloadThresholds.Add_Click({
    Reload-AlertThresholds
})

$btnRunAlertEngine.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Run alert engine")) { return }
    Run-AlertEngineNow
})

$btnLoadAlertHistory.Add_Click({
    Load-AlertHistory
})

$btnAcknowledgeSelectedHistory.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Acknowledge alert history")) { return }
    Acknowledge-SelectedAlertHistory
})

$btnBulkAcknowledge.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Bulk acknowledge alerts")) { return }
    BulkAcknowledgeAlerts
})

$btnExportAlerts.Add_Click({
    Export-AlertHistory
})

$btnClearAlertHistory.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Clear alert history")) { return }
    Clear-AlertHistory
})

$btnLoadAnalytics.Add_Click({
    Load-PerformanceAnalytics
})

$btnRunGroup.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Run instance group collectors")) { return }
    $collectorGroup = $cbInstanceGroupCollectorGroup.SelectedItem
    $instanceFilter = $txtInstanceFilter.Text.Trim()
    
    if ([string]::IsNullOrEmpty($collectorGroup)) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please select a collector group.",
            "Select Group",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        ) | Out-Null
        return
    }
    
    $txtGroupOutput.Clear()
    Run-InstanceGroupCollectors -CollectorGroup $collectorGroup -InstanceFilter $instanceFilter
})

$dgvAlertHistory.Add_SelectionChanged({
    Load-SelectedAlertHistory
})

$dgvThresholds.Add_SelectionChanged({
    Load-SelectedThreshold
})

$dgvInstances.Add_SelectionChanged({
    Load-SelectedInstance
})

$dgvUsers.Add_SelectionChanged({
    Load-SelectedDashboardUser
})

$cbScheduleType.Add_SelectedIndexChanged({
    $dtpScheduleTime.Visible = ($cbScheduleType.SelectedItem -eq 'Daily at')
})

$btnRefreshAlerts.Add_Click({
    Load-Alerts
})

$btnRefreshHealth.Add_Click({
    Load-Health
})

# UNIQUE FEATURE: Event handlers for new tabs
$btnRefreshExecutionPlans.Add_Click({
    Load-ExecutionPlans
})

$btnRefreshMemoryAnalysis.Add_Click({
    Load-MemoryAnalysis
})

$btnAcknowledgeAlert.Add_Click({
    if (-not (Require-AdminAccess -ActionName "Acknowledge alert")) { return }
    Acknowledge-SelectedAlert
})

$btnNewUser.Add_Click({
    Show-NewDashboardUserDialog
})

$btnSaveUser.Add_Click({
    Save-SelectedDashboardUser
})

$btnDeleteUser.Add_Click({
    Delete-SelectedDashboardUser
})

$btnReloadUsers.Add_Click({
    Refresh-DashboardUsers
})

$chkCriticalOnly.Add_CheckedChanged({
    Load-Alerts
})

$tabs.Add_SelectedIndexChanged({
    Update-SidebarSelection
    Refresh-CurrentTabData
})

$form.Add_Resize({
    Update-DashboardLayout
})

$cbInstances.Add_SelectedIndexChanged({
    if ($script:SuppressInstanceChangeLoad) { return }

    Update-OverviewTiles
    Refresh-CurrentTabData
    Update-ScheduleInfo
})

$dgvOverview.Add_SelectionChanged({
    if ($dgvOverview.SelectedRows.Count -gt 0) {
        $selectedInstanceId = [int]$dgvOverview.SelectedRows[0].Cells["InstanceID"].Value
        for ($i = 0; $i -lt $cbInstances.Items.Count; $i++) {
            if ($cbInstances.Items[$i].InstanceID -eq $selectedInstanceId) {
                $cbInstances.SelectedIndex = $i
                break
            }
        }
    }
})

$dgvAlerts.Add_SelectionChanged({
    Update-AlertSelectionInfo
})

# ------------------------------------------------------------
# Timer
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = (Get-ClampedRefreshIntervalSeconds -Value $script:DashboardSettings.RefreshIntervalSeconds) * 1000
$timer.Add_Tick({
    Refresh-Dashboard
})
Apply-RefreshIntervalSettings -ShowStatus $false

# ------------------------------------------------------------
# SQL Server Dictionary tab
# ------------------------------------------------------------
$lblDictionaryTitle = New-Object System.Windows.Forms.Label
$lblDictionaryTitle.Text = "SQL Server Dictionary & Explanations"
$lblDictionaryTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblDictionaryTitle.ForeColor = $script:DashboardTheme.Header
$lblDictionaryTitle.Location = New-Object System.Drawing.Point(20, 20)
$lblDictionaryTitle.Size = New-Object System.Drawing.Size(600, 30)
$lblDictionaryTitle.AutoSize = $true
$tabDictionary.Controls.Add($lblDictionaryTitle)

$txtDictionarySearch = New-Object System.Windows.Forms.TextBox
$txtDictionarySearch.Location = New-Object System.Drawing.Point(20, 60)
$txtDictionarySearch.Size = New-Object System.Drawing.Size(300, 25)
$txtDictionarySearch.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$txtDictionarySearch.Text = "Search terms..."
$txtDictionarySearch.ForeColor = [System.Drawing.Color]::Gray
$tabDictionary.Controls.Add($txtDictionarySearch)

$btnDictionarySearch = New-Object System.Windows.Forms.Button
$btnDictionarySearch.Text = "Search"
$btnDictionarySearch.Location = New-Object System.Drawing.Point(330, 58)
$btnDictionarySearch.Size = New-Object System.Drawing.Size(80, 27)
$tabDictionary.Controls.Add($btnDictionarySearch)

$cbDictionaryCategory = New-Object System.Windows.Forms.ComboBox
$cbDictionaryCategory.Location = New-Object System.Drawing.Point(420, 60)
$cbDictionaryCategory.Size = New-Object System.Drawing.Size(200, 25)
$cbDictionaryCategory.DropDownStyle = "DropDownList"
$cbDictionaryCategory.Items.AddRange(@("All Categories", "Performance Metrics", "System Resources", "Database Objects", "Security", "High Availability", "Backup & Recovery", "Troubleshooting"))
$cbDictionaryCategory.SelectedIndex = 0
$tabDictionary.Controls.Add($cbDictionaryCategory)

$rtbDictionary = New-Object System.Windows.Forms.RichTextBox
$rtbDictionary.Location = New-Object System.Drawing.Point(20, 100)
$rtbDictionary.Size = New-Object System.Drawing.Size(1100, 500)
$rtbDictionary.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$rtbDictionary.ReadOnly = $true
$rtbDictionary.BackColor = [System.Drawing.Color]::White
$rtbDictionary.ScrollBars = "Vertical"
$tabDictionary.Controls.Add($rtbDictionary)

# ------------------------------------------------------------
# Common Issues & SOPs tab
# ------------------------------------------------------------
$lblIssuesTitle = New-Object System.Windows.Forms.Label
$lblIssuesTitle.Text = "Common SQL Server Issues & Standard Operating Procedures"
$lblIssuesTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblIssuesTitle.ForeColor = $script:DashboardTheme.Header
$lblIssuesTitle.Location = New-Object System.Drawing.Point(20, 20)
$lblIssuesTitle.Size = New-Object System.Drawing.Size(700, 30)
$lblIssuesTitle.AutoSize = $true
$tabIssues.Controls.Add($lblIssuesTitle)

$cbIssuesCategory = New-Object System.Windows.Forms.ComboBox
$cbIssuesCategory.Location = New-Object System.Drawing.Point(20, 60)
$cbIssuesCategory.Size = New-Object System.Drawing.Size(200, 25)
$cbIssuesCategory.DropDownStyle = "DropDownList"
$cbIssuesCategory.Items.AddRange(@("All Issues", "Critical", "High Priority", "Performance", "Availability", "Security", "Storage"))
$cbIssuesCategory.SelectedIndex = 0
$tabIssues.Controls.Add($cbIssuesCategory)

$cbIssuesSeverity = New-Object System.Windows.Forms.ComboBox
$cbIssuesSeverity.Location = New-Object System.Drawing.Point(230, 60)
$cbIssuesSeverity.Size = New-Object System.Drawing.Size(150, 25)
$cbIssuesSeverity.DropDownStyle = "DropDownList"
$cbIssuesSeverity.Items.AddRange(@("All Severities", "Critical", "High", "Medium", "Low"))
$cbIssuesSeverity.SelectedIndex = 0
$tabIssues.Controls.Add($cbIssuesSeverity)

$btnIssuesRefresh = New-Object System.Windows.Forms.Button
$btnIssuesRefresh.Text = "Refresh Issues"
$btnIssuesRefresh.Location = New-Object System.Drawing.Point(390, 58)
$btnIssuesRefresh.Size = New-Object System.Drawing.Size(120, 27)
$tabIssues.Controls.Add($btnIssuesRefresh)

$dgvIssues = New-Object System.Windows.Forms.DataGridView
$dgvIssues.Location = New-Object System.Drawing.Point(20, 100)
$dgvIssues.Size = New-Object System.Drawing.Size(1100, 300)
$dgvIssues.AutoSizeColumnsMode = "Fill"
$dgvIssues.AllowUserToAddRows = $false
$dgvIssues.AllowUserToDeleteRows = $false
$dgvIssues.ReadOnly = $true
$dgvIssues.SelectionMode = "FullRowSelect"
$dgvIssues.MultiSelect = $false
$tabIssues.Controls.Add($dgvIssues)

$rtbIssueDetails = New-Object System.Windows.Forms.RichTextBox
$rtbIssueDetails.Location = New-Object System.Drawing.Point(20, 420)
$rtbIssueDetails.Size = New-Object System.Drawing.Size(1100, 180)
$rtbIssueDetails.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$rtbIssueDetails.ReadOnly = $true
$rtbIssueDetails.BackColor = [System.Drawing.Color]::White
$rtbIssueDetails.ScrollBars = "Vertical"
$tabIssues.Controls.Add($rtbIssueDetails)

# ------------------------------------------------------------
# Web Solutions Agent tab
# ------------------------------------------------------------
$lblWebAgentTitle = New-Object System.Windows.Forms.Label
$lblWebAgentTitle.Text = "Web Solutions Agent"
$lblWebAgentTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblWebAgentTitle.ForeColor = $script:DashboardTheme.Header
$lblWebAgentTitle.Location = New-Object System.Drawing.Point(20, 20)
$lblWebAgentTitle.AutoSize = $true
$tabWebAgent.Controls.Add($lblWebAgentTitle)

$cbWebAgentInstance = New-Object System.Windows.Forms.ComboBox
$cbWebAgentInstance.Location = New-Object System.Drawing.Point(20, 60)
$cbWebAgentInstance.Size = New-Object System.Drawing.Size(260, 25)
$cbWebAgentInstance.DropDownStyle = "DropDownList"
$tabWebAgent.Controls.Add($cbWebAgentInstance)

$txtWebAgentSearch = New-Object System.Windows.Forms.TextBox
$txtWebAgentSearch.Location = New-Object System.Drawing.Point(300, 60)
$txtWebAgentSearch.Size = New-Object System.Drawing.Size(520, 25)
$txtWebAgentSearch.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$txtWebAgentSearch.Text = "Search recent alerts or enter error text"
$txtWebAgentSearch.ForeColor = [System.Drawing.Color]::Gray
$tabWebAgent.Controls.Add($txtWebAgentSearch)

$btnWebAgentSearch = New-Object System.Windows.Forms.Button
$btnWebAgentSearch.Text = "Search Error"
$btnWebAgentSearch.Location = New-Object System.Drawing.Point(790, 58)
$btnWebAgentSearch.Size = New-Object System.Drawing.Size(90, 27)
$tabWebAgent.Controls.Add($btnWebAgentSearch)

$btnWebAgentAlerts = New-Object System.Windows.Forms.Button
$btnWebAgentAlerts.Text = "Load Current Errors"
$btnWebAgentAlerts.Location = New-Object System.Drawing.Point(890, 58)
$btnWebAgentAlerts.Size = New-Object System.Drawing.Size(120, 27)
$tabWebAgent.Controls.Add($btnWebAgentAlerts)

$btnWebAgentDiagnose = New-Object System.Windows.Forms.Button
$btnWebAgentDiagnose.Text = "AI Diagnose"
$btnWebAgentDiagnose.Location = New-Object System.Drawing.Point(1020, 58)
$btnWebAgentDiagnose.Size = New-Object System.Drawing.Size(100, 27)
$tabWebAgent.Controls.Add($btnWebAgentDiagnose)

$dgvWebAgentResults = New-Object System.Windows.Forms.DataGridView
$dgvWebAgentResults.Location = New-Object System.Drawing.Point(20, 100)
$dgvWebAgentResults.Size = New-Object System.Drawing.Size(1060, 280)
$dgvWebAgentResults.AutoSizeColumnsMode = "Fill"
$dgvWebAgentResults.AllowUserToAddRows = $false
$dgvWebAgentResults.AllowUserToDeleteRows = $false
$dgvWebAgentResults.ReadOnly = $true
$dgvWebAgentResults.SelectionMode = "FullRowSelect"
$dgvWebAgentResults.MultiSelect = $false
$tabWebAgent.Controls.Add($dgvWebAgentResults)

$rtbWebAgentDetails = New-Object System.Windows.Forms.RichTextBox
$rtbWebAgentDetails.Location = New-Object System.Drawing.Point(20, 390)
$rtbWebAgentDetails.Size = New-Object System.Drawing.Size(1060, 210)
$rtbWebAgentDetails.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$rtbWebAgentDetails.ReadOnly = $true
$rtbWebAgentDetails.BackColor = [System.Drawing.Color]::White
$rtbWebAgentDetails.ScrollBars = "Vertical"
$tabWebAgent.Controls.Add($rtbWebAgentDetails)

# ------------------------------------------------------------
# Patch Manager tab
# ------------------------------------------------------------
$lblPatchManagerTitle = New-Object System.Windows.Forms.Label
$lblPatchManagerTitle.Text = "Patch Manager"
$lblPatchManagerTitle.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$lblPatchManagerTitle.ForeColor = $script:DashboardTheme.Header
$lblPatchManagerTitle.Location = New-Object System.Drawing.Point(20, 20)
$lblPatchManagerTitle.AutoSize = $true
$tabPatchManager.Controls.Add($lblPatchManagerTitle)

$cbPatchManagerInstance = New-Object System.Windows.Forms.ComboBox
$cbPatchManagerInstance.Location = New-Object System.Drawing.Point(20, 60)
$cbPatchManagerInstance.Size = New-Object System.Drawing.Size(260, 25)
$cbPatchManagerInstance.DropDownStyle = "DropDownList"
$tabPatchManager.Controls.Add($cbPatchManagerInstance)

$btnPatchRefresh = New-Object System.Windows.Forms.Button
$btnPatchRefresh.Text = "Refresh Patch Status"
$btnPatchRefresh.Location = New-Object System.Drawing.Point(300, 58)
$btnPatchRefresh.Size = New-Object System.Drawing.Size(160, 27)
$tabPatchManager.Controls.Add($btnPatchRefresh)

$txtPatchDownloadPath = New-Object System.Windows.Forms.TextBox
$txtPatchDownloadPath.Location = New-Object System.Drawing.Point(480, 60)
$txtPatchDownloadPath.Size = New-Object System.Drawing.Size(360, 25)
$txtPatchDownloadPath.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$txtPatchDownloadPath.Text = Join-Path $projectRoot 'Patches'
$tabPatchManager.Controls.Add($txtPatchDownloadPath)

$chkPatchForce = New-Object System.Windows.Forms.CheckBox
$chkPatchForce.Text = "Force download"
$chkPatchForce.Location = New-Object System.Drawing.Point(850, 62)
$chkPatchForce.AutoSize = $true
$tabPatchManager.Controls.Add($chkPatchForce)

$btnPatchDownload = New-Object System.Windows.Forms.Button
$btnPatchDownload.Text = "Download Patches"
$btnPatchDownload.Location = New-Object System.Drawing.Point(940, 58)
$btnPatchDownload.Size = New-Object System.Drawing.Size(140, 27)
$tabPatchManager.Controls.Add($btnPatchDownload)

$dgvPatchStatus = New-Object System.Windows.Forms.DataGridView
$dgvPatchStatus.Location = New-Object System.Drawing.Point(20, 100)
$dgvPatchStatus.Size = New-Object System.Drawing.Size(1060, 280)
$dgvPatchStatus.AutoSizeColumnsMode = "Fill"
$dgvPatchStatus.AllowUserToAddRows = $false
$dgvPatchStatus.AllowUserToDeleteRows = $false
$dgvPatchStatus.ReadOnly = $true
$dgvPatchStatus.SelectionMode = "FullRowSelect"
$dgvPatchStatus.MultiSelect = $false
$tabPatchManager.Controls.Add($dgvPatchStatus)

$rtbPatchManagerDetails = New-Object System.Windows.Forms.RichTextBox
$rtbPatchManagerDetails.Location = New-Object System.Drawing.Point(20, 390)
$rtbPatchManagerDetails.Size = New-Object System.Drawing.Size(1060, 210)
$rtbPatchManagerDetails.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$rtbPatchManagerDetails.ReadOnly = $true
$rtbPatchManagerDetails.BackColor = [System.Drawing.Color]::White
$rtbPatchManagerDetails.ScrollBars = "Vertical"
$tabPatchManager.Controls.Add($rtbPatchManagerDetails)

# Event handlers for the new tabs
$txtDictionarySearch.Add_GotFocus({
    if ($txtDictionarySearch.Text -eq "Search terms...") {
        $txtDictionarySearch.Text = ""
        $txtDictionarySearch.ForeColor = [System.Drawing.Color]::Black
    }
})

$txtDictionarySearch.Add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($txtDictionarySearch.Text)) {
        $txtDictionarySearch.Text = "Search terms..."
        $txtDictionarySearch.ForeColor = [System.Drawing.Color]::Gray
    }
})

$btnDictionarySearch.Add_Click({
    Load-SQLDictionary  # For now, just reload. Could implement search filtering later
})

$cbDictionaryCategory.Add_SelectedIndexChanged({
    Load-SQLDictionary  # For now, just reload. Could implement category filtering later
})

$btnIssuesRefresh.Add_Click({
    Load-CommonIssues
})

$cbIssuesCategory.Add_SelectedIndexChanged({
    Load-CommonIssues  # For now, just reload. Could implement filtering later
})

$cbIssuesSeverity.Add_SelectedIndexChanged({
    Load-CommonIssues  # For now, just reload. Could implement filtering later
})

$dgvIssues.Add_CellContentClick({
    param($sender, $e)
    if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }
    if ($sender.Columns[$e.ColumnIndex].Name -eq "SearchSolution") {
        Search-CommonIssueSolution -RowIndex $e.RowIndex
    }
})

$dgvIssues.Add_SelectionChanged({
    if ($dgvIssues.SelectedRows.Count -gt 0) {
        $selectedRow = $dgvIssues.SelectedRows[0]
        $issueId = $selectedRow.Cells["IssueID"].Value

        # Find the issue details (in a real implementation, this would query a database)
        $issues = @(
            @{
                IssueID = 1
                Category = "Performance"
                Severity = "Critical"
                Title = "High CPU Utilization (>90%)"
                Description = "SQL Server CPU usage is consistently above 90%"
                Frequency = "High"
                SOP = "1. Identify top CPU-consuming queries using sys.dm_exec_query_stats\n2. Check for missing indexes on heavily accessed tables\n3. Review query execution plans for inefficiencies\n4. Consider query parameterization for frequently executed queries\n5. Evaluate server hardware capacity and consider CPU upgrade if needed"
            },
            @{
                IssueID = 2
                Category = "Memory"
                Severity = "Critical"
                Title = "Low Page Life Expectancy (<100 seconds)"
                Description = "Pages are being flushed from memory too quickly"
                Frequency = "Medium"
                SOP = "1. Increase server memory if possible\n2. Review and optimize queries causing excessive memory usage\n3. Check for memory leaks in application code\n4. Adjust SQL Server memory configuration (max server memory)\n5. Monitor buffer cache hit ratio (>95% desired)"
            },
            @{
                IssueID = 3
                Category = "Storage"
                Severity = "High"
                Title = "Transaction Log Full"
                Description = "Transaction log has reached capacity"
                Frequency = "Medium"
                SOP = "1. Perform transaction log backup immediately\n2. Check log backup schedule and ensure it's running regularly\n3. Evaluate log growth settings and adjust if needed\n4. Consider switching to Simple recovery model if log backups aren't needed\n5. Monitor log space usage proactively"
            },
            @{
                IssueID = 4
                Category = "Availability"
                Severity = "Critical"
                Title = "Always On AG Synchronization Issues"
                Description = "Availability Group databases are not synchronizing"
                Frequency = "Low"
                SOP = "1. Check AG dashboard for synchronization status\n2. Review error logs on primary and secondary replicas\n3. Verify network connectivity between replicas\n4. Check disk space on secondary replicas\n5. Validate permissions for AG service accounts\n6. Consider failover if primary is unresponsive"
            },
            @{
                IssueID = 5
                Category = "Performance"
                Severity = "High"
                Title = "Excessive Blocking (>30 seconds)"
                Description = "Queries are being blocked for extended periods"
                Frequency = "High"
                SOP = "1. Identify head blocker using sp_who2 or DMVs\n2. Review blocking query and optimize with proper indexing\n3. Check for long-running transactions\n4. Consider query timeout settings\n5. Implement proper transaction isolation levels\n6. Monitor lock waits using sys.dm_os_wait_stats"
            },
            @{
                IssueID = 6
                Category = "Backup"
                Severity = "Critical"
                Title = "Failed Backup Jobs"
                Description = "Database backup jobs are failing"
                Frequency = "Medium"
                SOP = "1. Check SQL Agent job history for failure details\n2. Verify backup destination disk space and permissions\n3. Test backup file integrity with RESTORE VERIFYONLY\n4. Review backup maintenance plans\n5. Ensure service accounts have necessary permissions\n6. Implement backup monitoring and alerting"
            },
            @{
                IssueID = 7
                Category = "Security"
                Severity = "High"
                Title = "Failed Login Attempts"
                Description = "Multiple authentication failures detected"
                Frequency = "High"
                SOP = "1. Review SQL Server error logs for failed login details\n2. Check account lockout policies\n3. Verify password policies and complexity requirements\n4. Review application connection strings\n5. Consider implementing multi-factor authentication\n6. Monitor for brute force attacks"
            },
            @{
                IssueID = 8
                Category = "Performance"
                Severity = "Medium"
                Title = "High Disk I/O Latency (>50ms)"
                Description = "Disk operations are taking too long"
                Frequency = "Medium"
                SOP = "1. Use sys.dm_io_virtual_file_stats to identify slow disks\n2. Check for disk fragmentation and defragment if needed\n3. Review disk hardware (consider SSD upgrade)\n4. Optimize tempdb placement and configuration\n5. Implement proper indexing to reduce I/O\n6. Consider data compression for large tables"
            }
        )

        $selectedIssue = $issues | Where-Object { $_.IssueID -eq $issueId }
        if ($selectedIssue) {
            $rtbIssueDetails.Text = @"
Issue: $($selectedIssue.Title)
Category: $($selectedIssue.Category)
Severity: $($selectedIssue.Severity)
Frequency: $($selectedIssue.Frequency)

Description:
$($selectedIssue.Description)

Standard Operating Procedure:
$($selectedIssue.SOP)
"@
        }
    }
})

$btnWebAgentSearch.Add_Click({
    Search-WebAgentErrorMessage
})

$btnWebAgentAlerts.Add_Click({
    Search-WebAgentRecentAlerts
})

$btnWebAgentDiagnose.Add_Click({
    Diagnose-WebAgentIssue
})

$cbWebAgentInstance.Add_SelectedIndexChanged({
    Load-WebAgentCurrentIssues
})

$dgvWebAgentResults.Add_CellContentClick({
    param($sender, $e)
    if ($e.RowIndex -lt 0 -or $e.ColumnIndex -lt 0) { return }
    if ($sender.Columns[$e.ColumnIndex].Name -eq "SearchSolution") {
        Search-WebAgentIssueRow -RowIndex $e.RowIndex
    }
})

$dgvWebAgentResults.Add_SelectionChanged({
    if ($dgvWebAgentResults.SelectedRows.Count -gt 0) {
        $selectedRow = $dgvWebAgentResults.SelectedRows[0]
        if ($selectedRow.Cells["AlertTitle"]) {
            $issue = [PSCustomObject]@{
                DisplayName = [string]$selectedRow.Cells["DisplayName"].Value
                AlertTime   = $selectedRow.Cells["AlertTime"].Value
                Severity    = [string]$selectedRow.Cells["Severity"].Value
                ModuleName  = [string]$selectedRow.Cells["ModuleName"].Value
                AlertTitle  = [string]$selectedRow.Cells["AlertTitle"].Value
                AlertDetails= [string]$selectedRow.Cells["AlertDetails"].Value
                AgeMinutes  = $selectedRow.Cells["AgeMinutes"].Value
            }
            $rtbWebAgentDetails.Text = Format-WebAgentIssueDetails -IssueRow $issue
        }
    }
})

$cbPatchManagerInstance.Add_SelectedIndexChanged({
    if ($cbPatchManagerInstance.SelectedItem -and $script:PatchStatus -and $script:PatchStatus.Count -gt 0) {
        $selectedStatus = $script:PatchStatus | Where-Object { $_.InstanceName -eq $cbPatchManagerInstance.SelectedItem.DisplayName } | Select-Object -First 1
        if ($selectedStatus) {
            $rtbPatchManagerDetails.Text = Format-PatchStatusDetails -PatchStatus $selectedStatus
        }
    }
})

$btnPatchRefresh.Add_Click({
    Refresh-PatchManagerStatus
})

$btnPatchDownload.Add_Click({
    Invoke-PatchDownload
})

$dgvPatchStatus.Add_SelectionChanged({
    if ($dgvPatchStatus.SelectedRows.Count -gt 0) {
        $selectedInstance = $dgvPatchStatus.SelectedRows[0].Cells['InstanceName'].Value
        $selectedStatus = $script:PatchStatus | Where-Object { $_.InstanceName -eq $selectedInstance }
        if ($selectedStatus) {
            $rtbPatchManagerDetails.Text = Format-PatchStatusDetails -PatchStatus $selectedStatus
        }
    }
})

# ------------------------------------------------------------
# Initial load
# Keep startup after all tabs and controls are created so layout helpers
# do not try to anchor controls that still have not been instantiated.
Apply-ModernDashboardTheme -RootForm $form -TabControl $tabs
Apply-RoleRestrictions
Set-DashboardResponsiveAnchors
Update-DashboardLayout
Update-SidebarSelection
Load-Overview -PreSelectedInstanceId $selectedInstanceId
if (Test-AdminAccess) {
    # Sync instances from JSON to database before refreshing UI
    Sync-InstancesJsonToDatabase
    Refresh-InstanceConfigs
    Refresh-NotificationsConfig
    Load-AlertThresholds
    Refresh-DashboardUsers
}
Populate-AlertHistoryInstances
Populate-AnalyticsInstances
Refresh-Dashboard

# ------------------------------------------------------------
# Show form
[void]$form.ShowDialog()






















