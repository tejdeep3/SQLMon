@echo off
REM Launch-TaskTicketGUI.bat - Batch file to launch the Task, Ticket & Escalation Management GUI

setlocal enabledelayedexpansion

REM Get the directory where this batch file is located
set "SCRIPT_DIR=%~dp0"

REM Remove trailing backslash
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

REM Check if PowerShell is available
where pwsh >nul 2>&1
if %errorlevel% equ 0 (
    set "PS_EXE=pwsh"
) else (
    set "PS_EXE=powershell"
)

REM Launch the GUI (don't pass -ProjectRoot, let script resolve it)
echo Launching SQL Monitor Task, Ticket ^& Escalation Management GUI...
%PS_EXE% -ExecutionPolicy Bypass -File "%SCRIPT_DIR%\GUI\SQLMonitorTaskTicketGUI.ps1"

if %errorlevel% neq 0 (
    echo.
    echo Error launching GUI. Please check the PowerShell script.
    pause
)
