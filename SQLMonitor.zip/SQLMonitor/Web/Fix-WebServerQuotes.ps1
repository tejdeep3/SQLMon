# Fix PowerShell splatting issue in Start-WebServer.ps1
# The problem is that @TaskID inside double-quoted strings causes splatting errors
# Fix: Change double quotes to single quotes for SQL strings

$file = "Start-WebServer.ps1"
$content = Get-Content $file -Raw

Write-Host "File length: $($content.Length)"

# Fix 1: UpdateTask SQL string
$oldUpdateTask = '"EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;"'
$newUpdateTask = "'EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;'"

Write-Host "Checking for UpdateTask pattern..."
if ($content.Contains($oldUpdateTask)) {
    Write-Host "Found UpdateTask pattern, replacing..."
    $content = $content.Replace($oldUpdateTask, $newUpdateTask)
    Write-Host "Replaced UpdateTask pattern"
} else {
    Write-Host "UpdateTask pattern NOT FOUND"
    # Try to find what's there
    $idx = $content.IndexOf("usp_UpdateTask")
    if ($idx -ge 0) {
        Write-Host "Found usp_UpdateTask at index $idx"
        Write-Host "Context: $($content.Substring($idx-50, 150))"
    }
}

# Fix 2: CreateTask SQL string (if exists)
$oldCreateTask = '"EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @CreatedBy, @DueDate"'
$newCreateTask = "'EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @CreatedBy, @DueDate'"

Write-Host "Checking for CreateTask pattern..."
if ($content.Contains($oldCreateTask)) {
    Write-Host "Found CreateTask pattern, replacing..."
    $content = $content.Replace($oldCreateTask, $newCreateTask)
    Write-Host "Replaced CreateTask pattern"
} else {
    Write-Host "CreateTask pattern NOT FOUND"
}

# Fix 3: CreateTicketFromAlert SQL string (if exists)
$oldCreateTicket = '"EXEC mon.usp_CreateTicketFromAlert @AlertHistoryID, @TicketTitle, @TicketDescription, @Priority, @CreatedBy"'
$newCreateTicket = "'EXEC mon.usp_CreateTicketFromAlert @AlertHistoryID, @TicketTitle, @TicketDescription, @Priority, @CreatedBy'"

Write-Host "Checking for CreateTicketFromAlert pattern..."
if ($content.Contains($oldCreateTicket)) {
    Write-Host "Found CreateTicketFromAlert pattern, replacing..."
    $content = $content.Replace($oldCreateTicket, $newCreateTicket)
    Write-Host "Replaced CreateTicketFromAlert pattern"
} else {
    Write-Host "CreateTicketFromAlert pattern NOT FOUND"
}

# Save the file
Set-Content -Path $file -Value $content -Encoding UTF8
Write-Host "File saved. Verifying..."

# Verify the fix
$verify = Get-Content $file -Raw
$checkIdx = $verify.IndexOf("usp_UpdateTask")
if ($checkIdx -ge 0) {
    $context = $verify.Substring([Math]::Max(0, $checkIdx-60), [Math]::Min(100, $verify.Length - $checkIdx + 60))
    Write-Host "Verification - context around usp_UpdateTask:"
    Write-Host $context
}

Write-Host "Done!"
