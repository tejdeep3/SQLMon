// ticket-system.js - Rendering functions for Ticket System, Task Management, and Escalation Matrix
// This file extends the main app.js with the new feature renderers

// ----- TICKET SYSTEM RENDERING -----
async function renderTickets() {
  const mode = state.ticketMode || "active";
  const sev = document.getElementById("ticketSeverity")?.value || "";
  let status = document.getElementById("ticketStatus")?.value || "";
  if (mode === "active" && ["Resolved", "Closed"].includes(status)) status = "";
  if (mode === "history" && ["New", "Acknowledged", "In Progress", "Reopened"].includes(status)) status = "";
  const assignedTo = document.getElementById("ticketAssignedTo")?.value || "";
  
  const params = new URLSearchParams();
  if (sev) params.append("severity", sev);
  if (status) params.append("status", status);
  if (assignedTo) params.append("assignedTo", assignedTo);
  if (mode === "history") params.append("includeClosed", "true");
  
  if (mode === "detail") params.set("includeClosed", "true");
  const [data, usersData, auditData, closureData] = await Promise.all([
    apiGet(`/api/tickets?${params}`),
    apiGet("/api/tasks/users"),
    mode === "audit" ? apiGet("/api/tickets/audit?limit=300") : Promise.resolve({ rows: [] }),
    apiGet("/api/tickets/closure-insights?days=30"),
  ]);
  let rows = normalizeRows(data.rows || []);
  const users = normalizeRows(usersData.rows || []);
  const auditRows = normalizeRows(auditData.rows || []);
  const topClosers = normalizeRows(closureData.topClosers || []);
  const recentClosures = normalizeRows(closureData.recentClosures || []);
  if (mode === "history" && !status) rows = rows.filter((row) => ["Resolved", "Closed"].includes(String(row.TicketStatus || "")));
  const selectedTicketId = state.selectedRows.tickets?.TicketID;
  const selectedTicket = rows.find((row) => String(row.TicketID) === String(selectedTicketId)) || rows[0] || null;
  const statusOptions = mode === "history"
    ? ["", "Resolved", "Closed"]
    : ["", "New", "Acknowledged", "In Progress", "Reopened"];
  els.view.innerHTML = `
    <div class="card ticket-command">
      <div class="card-header">
        <h3>Tickets</h3>
        <div class="toolbar">
          <label class="select-label">Severity<select id="ticketSeverity">
            <option value="">All</option>
            <option>Critical</option>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select></label>
          <label class="select-label">Status<select id="ticketStatus">
            ${statusOptions.map((item) => `<option value="${escapeAttr(item)}">${escapeHtml(item || "All")}</option>`).join("")}
          </select></label>
          <label class="field inline"><input id="ticketAssignedTo" placeholder="Filter by assignee"></label>
          <button class="btn primary" id="loadTickets">Load Tickets</button>
          <button class="btn" id="createFromAlert">Create from Alert</button>
          <button class="btn warning" id="autoConvertBtn">Auto-Convert Alerts</button>
        </div>
      </div>
    </div>
    <section class="ticket-closure-board">
      <div class="card ticket-closure-hero">
        <div class="card-header">
          <h3>Smart Closures</h3>
          <span>Last ${escapeHtml(closureData.days || 30)} days</span>
        </div>
        ${renderClosurePodium(topClosers)}
      </div>
      <div class="card ticket-closure-feed-card">
        <div class="card-header">
          <h3>How They Closed</h3>
          <span>Resolution notes, comments, and update evidence</span>
        </div>
        <div class="ticket-closure-feed">
          ${renderClosureFeed(recentClosures)}
        </div>
      </div>
    </section>
    <div class="tabs ticket-history-tabs" role="tablist" aria-label="Ticket workspace">
      <button class="tab ticket-mode-tab ${mode === "active" ? "active" : ""}" type="button" data-ticket-mode="active">Active Tickets</button>
      <button class="tab ticket-mode-tab ${mode === "history" ? "active" : ""}" type="button" data-ticket-mode="history">Historical Tickets</button>
      <button class="tab ticket-mode-tab ${mode === "detail" ? "active" : ""}" type="button" data-ticket-mode="detail" ${selectedTicket ? "" : "disabled"}>Ticket Details</button>
      <button class="tab ticket-mode-tab ${mode === "audit" ? "active" : ""}" type="button" data-ticket-mode="audit">Ticket Audit</button>
    </div>
    ${mode === "audit" ? `
    <div class="card audit-card">
      <div class="card-header">
        <h3>Ticket Audit</h3>
        <span class="muted">${auditRows.length} audit event${auditRows.length === 1 ? "" : "s"}</span>
      </div>
      <div id="ticketAuditTable"></div>
    </div>
    ` : `
    <div class="ticket-workspace ${mode === "detail" ? "detail-only" : ""}">
      ${mode === "detail" ? "" : `
      <div class="card ticket-list-card">
        <div class="card-header">
          <h3>${mode === "history" ? "Historical Queue" : "Active Queue"}</h3>
          <span class="muted">${rows.length} ticket${rows.length === 1 ? "" : "s"}</span>
        </div>
        <div id="ticketsTable"></div>
      </div>
      `}
      <aside id="ticketDetails" class="ticket-detail-panel"></aside>
    </div>
    `}
  `;
  
  // Set filter values
  if (sev) document.getElementById("ticketSeverity").value = sev;
  if (status) document.getElementById("ticketStatus").value = status;
  if (assignedTo) document.getElementById("ticketAssignedTo").value = assignedTo;
  
  if (mode === "audit") {
    renderTable(document.getElementById("ticketAuditTable"), auditRows, {
      key: "ticketAudit",
      columns: ["CreatedDate", "UserName", "ActionName", "Details", "ClientHost"],
      labels: { CreatedDate: "When", UserName: "User", ActionName: "Action", Details: "Details", ClientHost: "Host" },
    });
  }
  
  if (mode !== "detail" && mode !== "audit") renderTable(document.getElementById("ticketsTable"), rows, {
    selectable: true,
    idField: "TicketID",
    key: "tickets",
    columns: ["TicketNumber", "TicketStatus", "TicketSeverity", "InstanceName", "AssignedTo", "AgeMinutes", "CreatedDate"],
    labels: {
      TicketNumber: "Ticket",
      TicketStatus: "Status",
      TicketSeverity: "Severity",
      InstanceName: "Instance",
      AssignedTo: "Owner",
      AgeMinutes: "Age Min",
      CreatedDate: "Created",
    },
    badges: { TicketSeverity: severityClass, TicketStatus: statusClass },
    linkActions: {
      TicketNumber: (row) => {
        state.selectedRows.tickets = row;
        state.ticketMode = "detail";
        renderTickets();
      },
    },
    onSelect: (row) => showTicketDetails(row, users),
  });

  if (mode !== "audit" && selectedTicket) {
    state.selectedRows.tickets = selectedTicket;
    showTicketDetails(selectedTicket, users);
    const selectedIndex = rows.findIndex((row) => String(row.TicketID) === String(selectedTicket.TicketID));
    if (selectedIndex >= 0 && document.getElementById("ticketsTable")) {
      document.querySelectorAll("#ticketsTable tbody tr").forEach((tr) => {
        tr.classList.toggle("selected", Number(tr.dataset.index) === selectedIndex);
      });
    }
  } else if (mode !== "audit") {
    showTicketDetails(null);
  }
  
  document.getElementById("loadTickets").addEventListener("click", () => renderTickets());
  document.querySelectorAll(".ticket-mode-tab").forEach((button) => {
    button.addEventListener("click", async () => {
      state.ticketMode = button.dataset.ticketMode || "active";
      if (!["detail", "audit"].includes(state.ticketMode)) state.selectedRows.tickets = null;
      await renderTickets();
    });
  });
  document.getElementById("createFromAlert").addEventListener("click", async () => {
    const alertId = prompt("Enter Alert ID to create ticket from:");
    if (!alertId) return;
    const result = await apiPost("/api/tickets/create-from-alert", { AlertID: Number(alertId) });
    showStatus(result.message || "Ticket created.");
    await renderTickets();
  });
  document.getElementById("autoConvertBtn").addEventListener("click", async () => {
    const hoursBack = prompt("How many hours back to check for alerts? (default: 24)", "24");
    if (!hoursBack) return;
    const result = await apiPost("/api/tickets/auto-convert", { HoursBack: Number(hoursBack) });
    showStatus(result.message || `Created ${result.ticketsCreated} ticket(s) from alerts.`);
    await renderTickets();
  });
}

async function showTicketDetails(row, users = []) {
  const box = document.getElementById("ticketDetails");
  if (!box) return;
  if (!row) {
    box.innerHTML = `
      <div class="ticket-empty">
        <h3>No Ticket Selected</h3>
        <p>Select a ticket from the queue to review ownership, timeline, alert context, and available actions.</p>
      </div>
    `;
    return;
  }
  const canAcknowledge = Number(row.TicketStatusID) === 1 || row.TicketStatus === "New";
  const canResolve = !["Resolved", "Closed"].includes(String(row.TicketStatus || ""));
  const ticketUserOptions = taskUserOptions(users, row.AssignedTo || "");
  box.innerHTML = `
    <div class="ticket-detail-header">
      <div>
        <p class="eyebrow">${escapeHtml(row.TicketNumber || "Ticket")}</p>
        <h3>${escapeHtml(row.AlertTitle || row.InstanceName || "Ticket Details")}</h3>
      </div>
      <div class="ticket-detail-badges">
        <span class="badge ${statusClass(row.TicketStatus || "")}">${escapeHtml(row.TicketStatus || "")}</span>
        <span class="badge ${severityClass(row.TicketSeverity || "")}">${escapeHtml(row.TicketSeverity || "")}</span>
      </div>
    </div>

    <div class="ticket-facts">
      <div><span>Instance</span><strong>${escapeHtml(row.InstanceName || "Unassigned")}</strong></div>
      <div><span>Owner</span><strong>${escapeHtml(row.AssignedTo || "Unassigned")}</strong></div>
      <div><span>Age</span><strong>${escapeHtml(row.AgeMinutes ?? "")} min</strong></div>
      <div><span>Created</span><strong>${escapeHtml(row.CreatedDate || "")}</strong></div>
      <div><span>Assignment group</span><strong>${escapeHtml(row.AssignmentGroup || "DBA Operations")}</strong></div>
      <div><span>SLA due</span><strong>${escapeHtml(row.SLADueDate || "")}</strong></div>
    </div>

    <section class="ticket-section">
      <h4>Assignment</h4>
      <div class="task-form">
        <label class="field">Assigned To<select id="ticketEditAssigned">${ticketUserOptions}</select></label>
        <label class="field">Assignment Group<input id="ticketAssignmentGroup" value="${escapeAttr(row.AssignmentGroup || "DBA Operations")}"></label>
        <label class="field">Status<select id="ticketEditStatus">${ticketStatusOptions(row.TicketStatus || "New")}</select></label>
        <label class="field">Severity<select id="ticketEditSeverity">${ticketSeverityOptions(row.TicketSeverity || "Medium")}</select></label>
      </div>
      <div class="ticket-actions">
        <button class="btn primary" id="saveTicketAssignmentBtn">Save Assignment</button>
      </div>
    </section>

    <section class="ticket-section">
      <h4>Service Details</h4>
      <div class="task-form">
        <label class="field">Business Service<input id="ticketBusinessService" value="${escapeAttr(row.BusinessService || "")}" placeholder="Application, platform, or service"></label>
        <label class="field">Category<select id="ticketCategory">${ticketCategoryOptions(row.Category || "Database")}</select></label>
        <label class="field">Subcategory<input id="ticketSubcategory" value="${escapeAttr(row.Subcategory || "")}" placeholder="Backup, CPU, storage, blocking"></label>
        <label class="field">Impact<select id="ticketImpact">${ticketImpactUrgencyOptions(row.Impact || "")}</select></label>
        <label class="field">Urgency<select id="ticketUrgency">${ticketImpactUrgencyOptions(row.Urgency || "")}</select></label>
        <label class="field">Contact Type<select id="ticketContactType">${ticketContactOptions(row.ContactType || "Monitoring")}</select></label>
        <label class="field">Close Code<select id="ticketCloseCode">${ticketCloseCodeOptions(row.CloseCode || "")}</select></label>
        <label class="field">External Reference<input id="ticketExternalReference" value="${escapeAttr(row.ExternalReference || "")}" placeholder="ServiceNow, Jira, bridge, or change reference"></label>
        <label class="field">SLA Due Date<input id="ticketSlaDueDate" type="datetime-local" value="${escapeAttr(toDateTimeInputValue(row.SLADueDate))}"></label>
        <label class="field task-description-field">Work Notes<textarea id="ticketWorkNotes" rows="4" placeholder="Investigation notes, handoff details, customer impact, and next action.">${escapeHtml(row.WorkNotes || "")}</textarea></label>
      </div>
      <div class="ticket-actions">
        <button class="btn" id="saveTicketDetailsBtn">Save Service Details</button>
      </div>
    </section>

    <section class="ticket-section">
      <h4>Issue</h4>
      <div class="ticket-description">${escapeHtml(row.ErrorDescription || "No description recorded.")}</div>
    </section>

    <section class="ticket-section">
      <h4>Timeline</h4>
      <div class="ticket-timeline">
        <div><span>Created by</span><strong>${escapeHtml(row.CreatedBy || "")}</strong></div>
        ${row.AcknowledgedBy ? `<div><span>Acknowledged</span><strong>${escapeHtml(row.AcknowledgedBy)} · ${escapeHtml(row.AcknowledgedDate || "")}</strong></div>` : ""}
        ${row.ResolvedBy ? `<div><span>Resolved</span><strong>${escapeHtml(row.ResolvedBy)} · ${escapeHtml(row.ResolvedDate || "")}</strong></div>` : ""}
      </div>
    </section>

    ${row.ResolutionNotes ? `<section class="ticket-section"><h4>Resolution</h4><div class="ticket-description">${escapeHtml(row.ResolutionNotes)}</div></section>` : ""}

    <div class="ticket-actions">
      <button class="btn good ack-btn" ${canAcknowledge ? "" : "disabled"}>Acknowledge</button>
      <button class="btn primary resolve-btn" ${canResolve ? "" : "disabled"}>Resolve</button>
    </div>

    <section id="ticketResolvePanel" class="ticket-section ticket-resolution-panel" hidden>
      <h4>Resolution Notes</h4>
      <label class="field">
        Notes
        <textarea id="ticketResolutionNotes" placeholder="Summarize what fixed the issue, evidence checked, actions taken, and any follow-up needed."></textarea>
      </label>
      <div class="ticket-actions">
        <button class="btn primary submit-resolution-btn">Submit Resolution</button>
        <button class="btn cancel-resolution-btn">Cancel</button>
      </div>
    </section>
  `;
  
  box.querySelector(".ack-btn").addEventListener("click", async () => {
    await apiPost("/api/tickets/acknowledge", { TicketID: row.TicketID });
    showStatus("Ticket acknowledged.");
    await renderTickets();
  });
  box.querySelector("#saveTicketAssignmentBtn").addEventListener("click", async () => {
    await apiPost("/api/tickets/update", collectTicketPayload(row.TicketID));
    state.selectedRows.tickets = { ...row, AssignedTo: valueOf("ticketEditAssigned"), TicketStatus: valueOf("ticketEditStatus"), TicketSeverity: valueOf("ticketEditSeverity") };
    showStatus("Ticket assignment updated.");
    await renderTickets();
  });
  box.querySelector("#saveTicketDetailsBtn").addEventListener("click", async () => {
    await apiPost("/api/tickets/update", collectTicketPayload(row.TicketID));
    showStatus("Ticket details updated.");
    await renderTickets();
  });
  
  const resolvePanel = box.querySelector("#ticketResolvePanel");
  const notesInput = box.querySelector("#ticketResolutionNotes");
  box.querySelector(".resolve-btn").addEventListener("click", () => {
    resolvePanel.hidden = false;
    notesInput.focus();
  });
  box.querySelector(".cancel-resolution-btn").addEventListener("click", () => {
    notesInput.value = "";
    resolvePanel.hidden = true;
  });
  box.querySelector(".submit-resolution-btn").addEventListener("click", async () => {
    const notes = notesInput.value.trim();
    if (!notes) return showError("Resolution notes are required.");
    const result = await apiPost("/api/tickets/resolve", { TicketID: row.TicketID, ResolutionNotes: notes });
    showStatus(result.message || "Ticket resolved.");
    await renderTickets();
  });
}

function renderClosurePodium(rows) {
  const list = normalizeRows(rows).slice(0, 5);
  if (!list.length) {
    return `<div class="ticket-closure-empty">No resolved or closed tickets in this window yet. The board will light up as users close work with notes and evidence.</div>`;
  }
  const top = list[0] || {};
  const others = list.slice(1);
  return `
    <div class="closure-champion">
      <div class="closure-rank">#1</div>
      <div>
        <strong>${escapeHtml(top.UserName || "Unassigned")}</strong>
        <span>${escapeHtml(top.ClosedTickets || 0)} closed · ${escapeHtml(top.HighImpactClosed || 0)} high impact · ${escapeHtml(top.UpdatedClosures || 0)} updated · ${escapeHtml(Math.round(Number(top.SmartCloseScore || 0)))} smart score</span>
      </div>
    </div>
    <div class="closure-stat-grid">
      <div><span>Documented</span><strong>${escapeHtml(top.ResolutionNotesCount || 0)}</strong></div>
      <div><span>Commented</span><strong>${escapeHtml(top.CommentedClosures || 0)}</strong></div>
      <div><span>Updated</span><strong>${escapeHtml(top.UpdatedClosures || 0)}</strong></div>
      <div><span>Close codes</span><strong>${escapeHtml(top.CloseCodeCount || 0)}</strong></div>
    </div>
    <div class="closure-runner-list">
      ${others.map((row, index) => `
        <article>
          <b>#${index + 2}</b>
          <div><strong>${escapeHtml(row.UserName || "Unassigned")}</strong><span>${escapeHtml(row.ClosedTickets || 0)} closed · score ${escapeHtml(Math.round(Number(row.SmartCloseScore || 0)))}</span></div>
        </article>
      `).join("")}
    </div>
  `;
}

function renderClosureFeed(rows) {
  const list = normalizeRows(rows).slice(0, 8);
  if (!list.length) return `<div class="ticket-closure-empty">No closure stories yet.</div>`;
  return list.map((row) => `
    <article class="closure-story">
      <div class="closure-story-head">
        <strong>${escapeHtml(row.TicketNumber || "Ticket")}</strong>
        <span class="badge ${severityClass(row.TicketSeverity || "")}">${escapeHtml(row.TicketSeverity || "")}</span>
      </div>
      <p>${escapeHtml(row.ClosureSummary || "Closed without a written summary.")}</p>
      <div class="closure-story-meta">
        <span>${escapeHtml(row.ResolvedBy || "Unknown user")}</span>
        <span>${escapeHtml(row.CloseCode || row.Category || "Closure")}</span>
        <span>${escapeHtml(row.CommentCount || 0)} comment${Number(row.CommentCount || 0) === 1 ? "" : "s"}</span>
        <span>${escapeHtml(row.UpdateCount || 0)} update${Number(row.UpdateCount || 0) === 1 ? "" : "s"}</span>
      </div>
    </article>
  `).join("");
}

function collectTicketPayload(ticketId) {
  return {
    TicketID: Number(ticketId),
    AssignedTo: valueOf("ticketEditAssigned"),
    Status: valueOf("ticketEditStatus"),
    Severity: valueOf("ticketEditSeverity"),
    BusinessService: valueOf("ticketBusinessService"),
    Category: valueOf("ticketCategory"),
    Subcategory: valueOf("ticketSubcategory"),
    Impact: valueOf("ticketImpact"),
    Urgency: valueOf("ticketUrgency"),
    AssignmentGroup: valueOf("ticketAssignmentGroup"),
    ContactType: valueOf("ticketContactType"),
    CloseCode: valueOf("ticketCloseCode"),
    ExternalReference: valueOf("ticketExternalReference"),
    SLADueDate: valueOf("ticketSlaDueDate"),
    WorkNotes: valueOf("ticketWorkNotes"),
  };
}

function ticketStatusOptions(selected) {
  return ["New", "Acknowledged", "In Progress", "Resolved", "Closed", "Reopened"]
    .map((value) => `<option ${value === selected ? "selected" : ""}>${value}</option>`)
    .join("");
}

function ticketSeverityOptions(selected) {
  return ["Critical", "High", "Medium", "Low"]
    .map((value) => `<option ${value === selected ? "selected" : ""}>${value}</option>`)
    .join("");
}

function ticketCategoryOptions(selected) {
  return ["Database", "Performance", "Storage", "Availability", "Backup", "Security", "Collector", "Application", "Other"]
    .map((value) => `<option ${value === selected ? "selected" : ""}>${value}</option>`)
    .join("");
}

function ticketImpactUrgencyOptions(selected) {
  return ["", "1 - High", "2 - Medium", "3 - Low"]
    .map((value) => `<option value="${escapeAttr(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(value || "Not set")}</option>`)
    .join("");
}

function ticketContactOptions(selected) {
  return ["Monitoring", "User", "Email", "Phone", "Chat", "Automation"]
    .map((value) => `<option ${value === selected ? "selected" : ""}>${value}</option>`)
    .join("");
}

function ticketCloseCodeOptions(selected) {
  return ["", "Solved Permanently", "Solved Workaround", "Duplicate", "No Fault Found", "Known Error", "Cancelled"]
    .map((value) => `<option value="${escapeAttr(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(value || "Not set")}</option>`)
    .join("");
}

// ----- TASK MANAGEMENT RENDERING -----
async function renderTasks() {
  const assignedTo = document.getElementById("taskAssignedTo")?.value || "";
  let status = document.getElementById("taskStatus")?.value || "";
  const priority = document.getElementById("taskPriority")?.value || "";
  const activeTab = state.taskTab || document.querySelector(".task-tab.active")?.dataset.taskTab || "view";
  const isHistory = activeTab === "history";
  const isAudit = activeTab === "audit";
  if (isHistory && !["", "Completed", "Cancelled"].includes(status)) status = "";
  if (!isHistory && ["Completed", "Cancelled"].includes(status)) status = "";
  
  const params = new URLSearchParams();
  if (assignedTo) params.append("assignedTo", assignedTo);
  if (status) params.append("status", status);
  if (priority) params.append("priority", priority);
  if (isHistory || activeTab === "detail") params.append("includeCompleted", "true");
  
  const [data, usersData, auditData] = await Promise.all([
    apiGet(`/api/tasks?${params}`),
    apiGet("/api/tasks/users"),
    isAudit ? apiGet("/api/tasks/audit?limit=300") : Promise.resolve({ rows: [] }),
  ]);
  let rows = normalizeRows(data.rows || []);
  const users = normalizeRows(usersData.rows || []);
  const auditRows = normalizeRows(auditData.rows || []);
  if (isHistory && !status) rows = rows.filter((row) => ["Completed", "Cancelled"].includes(String(row.TaskStatus || "")));
  const selectedTaskId = state.selectedRows.tasks?.TaskID;
  const selectedTask = rows.find((row) => String(row.TaskID) === String(selectedTaskId)) || rows[0] || null;
  const statusOptions = isHistory
    ? ["", "Completed", "Cancelled"]
    : ["", "Open", "In Progress", "Pending", "On Hold"];
  els.view.innerHTML = `
    <div class="card task-command">
      <div class="card-header">
        <div>
          <h3>Task Management</h3>
          <span class="muted">Create work, operate active tasks, review history, and audit changes.</span>
        </div>
        <div class="tabs task-tabs" role="tablist" aria-label="Task Management">
          <button class="tab task-tab ${activeTab === "create" ? "active" : ""}" data-task-tab="create" type="button">Create Task</button>
          <button class="tab task-tab ${activeTab === "view" ? "active" : ""}" data-task-tab="view" type="button">View Tasks</button>
          <button class="tab task-tab ${activeTab === "history" ? "active" : ""}" data-task-tab="history" type="button">Tasks History</button>
          <button class="tab task-tab ${activeTab === "detail" ? "active" : ""}" data-task-tab="detail" type="button" ${selectedTask ? "" : "disabled"}>Task Details</button>
          <button class="tab task-tab ${activeTab === "audit" ? "active" : ""}" data-task-tab="audit" type="button">Task Audit</button>
        </div>
      </div>
    </div>
    <section id="taskCreatePanel" class="card task-create-panel" ${activeTab === "create" ? "" : "hidden"}>
      <div class="card-header"><h3>Create Task</h3><span class="muted">Assign work to an application user.</span></div>
      <div class="task-form">
        <label class="field">Title<input id="taskCreateTitle" placeholder="Clear action title"></label>
        <label class="field">Assigned To<select id="taskCreateAssigned">${taskUserOptions(users, "")}</select></label>
        <label class="field">Priority<select id="taskCreatePriority">${taskPriorityOptions("Medium")}</select></label>
        <label class="field">Due Date<input id="taskCreateDue" type="date"></label>
        <label class="field task-description-field">Description<textarea id="taskCreateDescription" rows="6" placeholder="Expected outcome, context, systems affected, and acceptance criteria."></textarea></label>
      </div>
      <div class="task-actions">
        <button class="btn primary" id="createTaskSubmit">Create Task</button>
        <button class="btn" id="createTaskReset">Reset</button>
      </div>
    </section>
    <section id="taskAuditPanel" class="card audit-card" ${activeTab === "audit" ? "" : "hidden"}>
      <div class="card-header">
        <h3>Task Audit</h3>
        <span class="muted">${auditRows.length} audit event${auditRows.length === 1 ? "" : "s"}</span>
      </div>
      <div id="taskAuditTable"></div>
    </section>
    <section id="taskViewPanel" ${["view", "history", "detail"].includes(activeTab) ? "" : "hidden"}>
      ${activeTab === "detail" ? "" : `
      <div class="card task-command">
        <div class="toolbar">
          <label class="select-label">Assigned To<select id="taskAssignedTo">${taskUserOptions(users, assignedTo, "All users")}</select></label>
          <label class="select-label">Status<select id="taskStatus">
            ${statusOptions.map((item) => `<option value="${escapeAttr(item)}">${escapeHtml(item || "All")}</option>`).join("")}
          </select></label>
          <label class="select-label">Priority<select id="taskPriority">
            <option value="">All</option>
            <option>Critical</option>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select></label>
          <button class="btn primary" id="loadTasks">Load Tasks</button>
        </div>
      </div>
      `}
      <div class="task-workspace ${activeTab === "detail" ? "detail-only" : ""}">
        ${activeTab === "detail" ? "" : `
        <div class="card task-list-card">
        <div class="card-header">
          <h3>${isHistory ? "Task History" : "Active Task Queue"}</h3>
          <span class="muted">${rows.length} task${rows.length === 1 ? "" : "s"}</span>
        </div>
        <div id="tasksTable"></div>
        </div>
        `}
        <aside id="taskDetails" class="task-detail-panel"></aside>
      </div>
    </section>
  `;
  
  // Set filter values
  if (assignedTo) document.getElementById("taskAssignedTo").value = assignedTo;
  if (status) document.getElementById("taskStatus").value = status;
  if (priority) document.getElementById("taskPriority").value = priority;
  if (isAudit) {
    renderTable(document.getElementById("taskAuditTable"), auditRows, {
      key: "taskAudit",
      columns: ["CreatedDate", "TaskID", "TaskTitle", "UserName", "ActionName", "Details", "AuditSource"],
      labels: { CreatedDate: "When", TaskID: "Task #", TaskTitle: "Task", UserName: "User", ActionName: "Action", Details: "Details", AuditSource: "Source" },
    });
  }
  
  const tableHost = document.getElementById("tasksTable");
  if (tableHost) renderTable(tableHost, rows, {
    selectable: true,
    idField: "TaskID",
    key: "tasks",
    columns: ["TaskID", "TaskTitle", "TaskStatus", "TaskPriority", "AssignedTo", "DueDate", "IsOverdue", "CreatedDate"],
    labels: {
      TaskID: "Task #",
      TaskTitle: "Task",
      TaskStatus: "Status",
      TaskPriority: "Priority",
      AssignedTo: "Owner",
      DueDate: "Due",
      IsOverdue: "Overdue",
      CreatedDate: "Created",
    },
    badges: { TaskPriority: severityClass, TaskStatus: statusClass },
    linkActions: {
      TaskID: (row) => {
        state.selectedRows.tasks = row;
        state.taskTab = "detail";
        renderTasks();
      },
    },
    onSelect: (row) => showTaskDetails(row, users),
  });

  if ((activeTab === "view" || activeTab === "history" || activeTab === "detail") && selectedTask) {
    state.selectedRows.tasks = selectedTask;
    await showTaskDetails(selectedTask, users);
    const selectedIndex = rows.findIndex((row) => String(row.TaskID) === String(selectedTask.TaskID));
    if (selectedIndex >= 0 && document.getElementById("tasksTable")) {
      document.querySelectorAll("#tasksTable tbody tr").forEach((tr) => {
        tr.classList.toggle("selected", Number(tr.dataset.index) === selectedIndex);
      });
    }
  } else if (activeTab === "view" || activeTab === "history" || activeTab === "detail") {
    showTaskDetails(null);
  }
  
  document.querySelectorAll(".task-tab").forEach((button) => {
    button.addEventListener("click", () => {
      state.taskTab = button.dataset.taskTab || "view";
      if (!["detail", "audit"].includes(state.taskTab)) state.selectedRows.tasks = null;
      renderTasks();
    });
  });
  document.getElementById("loadTasks")?.addEventListener("click", () => renderTasks());
  document.getElementById("createTaskReset")?.addEventListener("click", () => {
    ["taskCreateTitle", "taskCreateDescription", "taskCreateDue"].forEach((id) => setValue(id, ""));
    setValue("taskCreateAssigned", "");
    setValue("taskCreatePriority", "Medium");
  });
  document.getElementById("createTaskSubmit")?.addEventListener("click", async () => {
    const payload = {
      Title: valueOf("taskCreateTitle").trim(),
      Description: valueOf("taskCreateDescription"),
      AssignedTo: valueOf("taskCreateAssigned"),
      Priority: valueOf("taskCreatePriority"),
      DueDate: valueOf("taskCreateDue"),
    };
    if (!payload.Title) return showError("Task title is required.");
    const result = await apiPost("/api/tasks/create", payload);
    state.selectedRows.tasks = { TaskID: result.taskId };
    state.taskTab = "detail";
    showStatus("Task created.");
    await renderTasks();
  });
}

async function showTaskDetails(row, users = []) {
  const box = document.getElementById("taskDetails");
  if (!box) return;
  if (!row) {
    box.innerHTML = `
      <div class="task-empty">
        <h3>No Task Selected</h3>
        <p>Select a task to edit ownership, status, dates, and comments, or create a new task.</p>
      </div>
    `;
    return;
  }
  const isNew = !row.TaskID;
  const isClosed = ["Completed", "Cancelled"].includes(String(row.TaskStatus || ""));
  const [commentsData, auditData] = isNew
    ? [{ rows: [] }, { rows: [] }]
    : await Promise.all([
        apiGet(`/api/tasks/comments?taskId=${row.TaskID}`),
        apiGet(`/api/tasks/audit?taskId=${row.TaskID}&limit=100`),
      ]);
  const comments = normalizeRows(commentsData.rows || []);
  const auditRows = normalizeRows(auditData.rows || []);
  const disabledAttr = isClosed ? "disabled" : "";
  box.innerHTML = `
    <div class="task-detail-header">
      <div>
        <p class="eyebrow">${isNew ? "New Task" : `Task #${escapeHtml(row.TaskID)}`}</p>
        <h3>${escapeHtml(row.TaskTitle || "Untitled task")}</h3>
      </div>
      <div class="ticket-detail-badges">
        ${row.TaskStatus ? `<span class="badge ${statusClass(row.TaskStatus)}">${escapeHtml(row.TaskStatus)}</span>` : ""}
        ${row.TaskPriority ? `<span class="badge ${severityClass(row.TaskPriority)}">${escapeHtml(row.TaskPriority)}</span>` : ""}
        ${row.IsOverdue ? '<span class="badge warning">Overdue</span>' : ""}
      </div>
    </div>

    ${isNew ? "" : `
    <div class="task-facts">
      <div><span>Owner</span><strong>${escapeHtml(row.AssignedTo || "Unassigned")}</strong></div>
      <div><span>Created by</span><strong>${escapeHtml(row.CreatedBy || "")}</strong></div>
      <div><span>Due</span><strong>${escapeHtml(row.DueDate || "Not set")}</strong></div>
      <div><span>Completed</span><strong>${escapeHtml(row.CompletedDate || "Not completed")}</strong></div>
      <div><span>Instance</span><strong>${escapeHtml(row.InstanceName || "No instance linked")}</strong></div>
      <div><span>Modified</span><strong>${escapeHtml(row.ModifiedDate || "")}</strong></div>
    </div>
    `}

    <section class="task-section">
      <h4>${isNew ? "Create Task" : isClosed ? "Task Review" : "Task Plan"}</h4>
      <div class="task-form">
        <label class="field">Title<input id="taskEditTitle" value="${escapeAttr(row.TaskTitle || "")}" ${disabledAttr}></label>
        <label class="field">Assigned To<select id="taskEditAssigned" ${disabledAttr}>${taskUserOptions(users, row.AssignedTo || "")}</select></label>
        <label class="field">Status<select id="taskEditStatus" ${disabledAttr}>${taskStatusOptions(row.TaskStatus || "Open")}</select></label>
        <label class="field">Priority<select id="taskEditPriority" ${disabledAttr}>${taskPriorityOptions(row.TaskPriority || "Medium")}</select></label>
        <label class="field">Due Date<input id="taskEditDue" type="date" value="${escapeAttr(toDateInputValue(row.DueDate))}" ${disabledAttr}></label>
        <label class="field task-description-field">Description<textarea id="taskEditDescription" rows="5" ${disabledAttr}>${escapeHtml(row.TaskDescription || "")}</textarea></label>
      </div>
      ${isClosed ? "" : `<div class="task-actions">
        <button class="btn primary" id="saveTaskBtn">${isNew ? "Create Task" : "Save Changes"}</button>
        ${isNew ? '<button class="btn" id="cancelNewTaskBtn">Cancel</button>' : '<button class="btn good" id="closeTaskBtn">Close Task</button>'}
      </div>`}
    </section>

    ${isNew ? "" : `
      <section class="task-section">
        <h4>Comments</h4>
        ${isClosed ? "" : `
        <div class="task-comment-compose">
          <textarea id="newTaskComment" rows="3" placeholder="Add an update, handoff note, investigation detail, or next action."></textarea>
          <button class="btn" id="addTaskCommentBtn">Add Comment</button>
        </div>
        `}
        <div id="taskComments" class="task-comments">${renderTaskComments(comments, !isClosed)}</div>
      </section>
      <section class="task-section">
        <h4>Audit Trail</h4>
        <div class="task-audit-timeline">${renderTaskAuditTimeline(auditRows)}</div>
      </section>
    `}
  `;

  box.querySelector("#saveTaskBtn")?.addEventListener("click", async () => {
    const payload = collectTaskPayload(row.TaskID);
    if (!payload.Title) return showError("Task title is required.");
    if (isNew) {
      const result = await apiPost("/api/tasks/create", payload);
      state.selectedRows.tasks = { TaskID: result.taskId };
      showStatus("Task created.");
    } else {
      await apiPost("/api/tasks/update", payload);
      state.selectedRows.tasks = { ...row, ...payload };
      showStatus("Task updated.");
    }
    await renderTasks();
  });

  box.querySelector("#cancelNewTaskBtn")?.addEventListener("click", () => showTaskDetails(state.selectedRows.tasks || null, users));
  box.querySelector("#closeTaskBtn")?.addEventListener("click", async () => {
    const payload = collectTaskPayload(row.TaskID);
    payload.Status = "Completed";
    await apiPost("/api/tasks/update", payload);
    showStatus("Task closed.");
    await renderTasks();
  });

  box.querySelector("#addTaskCommentBtn")?.addEventListener("click", async () => {
    const commentBox = document.getElementById("newTaskComment");
    const comment = commentBox.value.trim();
    if (!comment) return showError("Comment text is required.");
    await apiPost("/api/tasks/comment", { TaskID: row.TaskID, CommentText: comment });
    commentBox.value = "";
    showStatus("Comment added.");
    await showTaskDetails(row, users);
  });

  box.querySelectorAll(".save-comment-btn").forEach((button) => {
    button.addEventListener("click", async () => {
      const commentId = Number(button.dataset.commentId);
      const editor = document.getElementById(`taskCommentEdit${commentId}`);
      const text = editor.value.trim();
      if (!text) return showError("Comment text is required.");
      await apiPost("/api/tasks/comment/update", { CommentID: commentId, CommentText: text });
      showStatus("Comment updated.");
      await showTaskDetails(row, users);
    });
  });
}

function collectTaskPayload(taskId) {
  const payload = {
    Title: valueOf("taskEditTitle").trim(),
    Description: valueOf("taskEditDescription"),
    AssignedTo: valueOf("taskEditAssigned").trim(),
    Status: valueOf("taskEditStatus"),
    Priority: valueOf("taskEditPriority"),
    DueDate: valueOf("taskEditDue"),
  };
  if (taskId) payload.TaskID = Number(taskId);
  return payload;
}

function taskStatusOptions(selected) {
  return ["Open", "In Progress", "Pending", "Completed", "Cancelled", "On Hold"]
    .map((value) => `<option ${value === selected ? "selected" : ""}>${value}</option>`)
    .join("");
}

function taskPriorityOptions(selected) {
  return ["Critical", "High", "Medium", "Low"]
    .map((value) => `<option ${value === selected ? "selected" : ""}>${value}</option>`)
    .join("");
}

function taskUserOptions(users, selected, emptyLabel = "Unassigned") {
  const options = [`<option value="">${escapeHtml(emptyLabel)}</option>`];
  const seen = new Set();
  normalizeRows(users).forEach((user) => {
    const value = String(user.UserName || "").trim();
    if (!value || seen.has(value.toLowerCase())) return;
    seen.add(value.toLowerCase());
    const label = `${user.DisplayName || value}${user.RoleName ? ` (${user.RoleName})` : ""}`;
    options.push(`<option value="${escapeAttr(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(label)}</option>`);
  });
  if (selected && !seen.has(String(selected).toLowerCase())) {
    options.push(`<option value="${escapeAttr(selected)}" selected>${escapeHtml(selected)}</option>`);
  }
  return options.join("");
}

function toDateInputValue(value) {
  if (!value) return "";
  const text = String(value);
  const match = text.match(/^\d{4}-\d{2}-\d{2}/);
  return match ? match[0] : "";
}

function toDateTimeInputValue(value) {
  if (!value) return "";
  const text = String(value).replace(" ", "T");
  const match = text.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/);
  return match ? match[0] : "";
}

function renderTaskComments(comments, editable = true) {
  if (!comments.length) return `<div class="task-empty-note">No comments yet.</div>`;
  return comments.map((comment) => {
    const edited = comment.IsEdited ? ` · edited ${escapeHtml(comment.ModifiedDate || "")}` : "";
    return `
      <article class="task-comment">
        <div class="task-comment-meta">
          <strong>${escapeHtml(comment.CreatedBy || "")}</strong>
          <span>${escapeHtml(comment.CreatedDate || "")}${edited}</span>
        </div>
        <textarea id="taskCommentEdit${escapeAttr(comment.CommentID)}" rows="3" ${editable ? "" : "disabled"}>${escapeHtml(comment.CommentText || "")}</textarea>
        ${editable ? `<div class="task-comment-actions">
          <button class="btn save-comment-btn" data-comment-id="${escapeAttr(comment.CommentID)}">Save Comment</button>
        </div>` : ""}
      </article>
    `;
  }).join("");
}

function renderTaskAuditTimeline(rows) {
  const items = normalizeRows(rows).slice(0, 20);
  if (!items.length) return `<div class="task-empty-note">No audit activity recorded.</div>`;
  return items.map((row) => `
    <article class="task-audit-item">
      <div>
        <strong>${escapeHtml(row.ActionName || "")}</strong>
        <span>${escapeHtml(row.UserName || "")} &middot; ${escapeHtml(row.CreatedDate || "")}</span>
      </div>
      <p>${escapeHtml(row.Details || "")}</p>
    </article>
  `).join("");
}

// ----- ESCALATION MATRIX RENDERING -----
async function renderEscalationMatrix() {
  const [rules, history] = await Promise.all([
    apiGet("/api/escalation/rules"),
    apiGet("/api/escalation/history")
  ]);
  
  els.view.innerHTML = `
    <div class="grid two">
      <div class="card">
        <div class="card-header"><h3>Escalation Rules</h3></div>
        <div id="escalationRulesTable"></div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Escalation History</h3></div>
        <div id="escalationHistoryTable"></div>
      </div>
    </div>
  `;
  
  renderTable(document.getElementById("escalationRulesTable"), rules.rows || [], {
    badges: { SeverityName: severityClass }
  });
  
  renderTable(document.getElementById("escalationHistoryTable"), history.rows || [], {
    badges: { EscalationLevel: severityClass }
  });
}
