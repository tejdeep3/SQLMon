param(
    [int]$Port = 8090,
    [string]$RepositoryServer = '',
    [string]$RepositoryDatabase = ''
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$staticFilesDir = $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\WebAgent.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\PatchManager.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\PatchDownloader.psm1') -Force -WarningAction SilentlyContinue

if ([string]::IsNullOrWhiteSpace($RepositoryServer) -or [string]::IsNullOrWhiteSpace($RepositoryDatabase)) {
    $repositorySettings = Get-SqlMonitorRepositorySettings
    if ([string]::IsNullOrWhiteSpace($RepositoryServer)) { $RepositoryServer = $repositorySettings.RepositoryServer }
    if ([string]::IsNullOrWhiteSpace($RepositoryDatabase)) { $RepositoryDatabase = $repositorySettings.RepositoryDatabase }
}

$script:RepositoryServer = $RepositoryServer
$script:RepositoryDatabase = $RepositoryDatabase
$script:Sessions = @{}

$script:FeatureGroups = @(
    @{
        name = 'Command Center'
        features = @(
            @{ key = 'overview'; title = 'Server Overview'; type = 'overview'; icon = 'layout-dashboard' },
            @{ key = 'collector-control'; title = 'Collectors & Schedule'; type = 'collector'; icon = 'play-circle' },
            @{ key = 'health'; title = 'Collection Health'; type = 'health'; icon = 'activity' },
            @{ key = 'alerts'; title = 'Open Alerts'; type = 'alerts'; icon = 'bell' },
            @{ key = 'alert-history'; title = 'Alert History'; type = 'alert-history'; icon = 'history' },
            @{ key = 'tickets'; title = 'Ticket System'; type = 'tickets'; icon = 'ticket' },
            @{ key = 'tasks'; title = 'Task Management'; type = 'tasks'; icon = 'check-square' },
            @{ key = 'analytics'; title = 'Performance Analytics'; type = 'analytics'; icon = 'chart-line' },
            @{ key = 'account-security'; title = 'My Account'; type = 'account-security'; icon = 'user' }
        )
    },
    @{
        name = 'Performance'
        features = @(
            @{ key = 'cpu'; title = 'CPU Trend'; type = 'module'; module = 'cpu' },
            # Additional CPU resource metrics (e.g., CPU usage per core, scheduler stats)
            @{ key = 'memory'; title = 'Memory Trend'; type = 'module'; module = 'memory' },
            @{ key = 'kpis'; title = 'KPIs'; type = 'module'; module = 'kpis' },
            @{ key = 'waits'; title = 'Wait Stats'; type = 'module'; module = 'waits' },
            @{ key = 'top-queries'; title = 'Top Queries'; type = 'module'; module = 'top-queries' },
            @{ key = 'execution-plans'; title = 'Execution Plans'; type = 'module'; module = 'execution-plans' },
            @{ key = 'memory-analysis'; title = 'Memory Analysis'; type = 'memory-analysis' }
        )
    },
    @{
        name = 'Storage & Databases'
        features = @(
            @{ key = 'disks'; title = 'Disks'; type = 'module'; module = 'disks' },
            @{ key = 'io'; title = 'I/O Files'; type = 'module'; module = 'io' },
            @{ key = 'tempdb'; title = 'TempDB'; type = 'module'; module = 'tempdb' },
            @{ key = 'backups'; title = 'Backups'; type = 'module'; module = 'backups' },
            @{ key = 'db-options'; title = 'DB Options'; type = 'module'; module = 'db-options' },
            @{ key = 'missing-indexes'; title = 'Missing Indexes'; type = 'module'; module = 'missing-indexes' },
            @{ key = 'fragmentation'; title = 'Fragmentation'; type = 'module'; module = 'fragmentation' }
        )
    },
    @{
        name = 'Operations'
        features = @(
            @{ key = 'config'; title = 'SQL Config'; type = 'module'; module = 'config' },
            @{ key = 'blocking'; title = 'Blocking'; type = 'module'; module = 'blocking' },
            @{ key = 'long-running'; title = 'Long Running'; type = 'module'; module = 'long-running' },
            @{ key = 'ag'; title = 'Availability Groups'; type = 'module'; module = 'ag' },
            @{ key = 'listeners'; title = 'Listeners'; type = 'module'; module = 'listeners' },
            @{ key = 'agent-jobs'; title = 'Agent Jobs'; type = 'module'; module = 'agent-jobs' },
            @{ key = 'deadlocks'; title = 'Deadlocks'; type = 'module'; module = 'deadlocks' },
            @{ key = 'patch-manager'; title = 'Patch Manager'; type = 'patch-manager' }
        )
    },
    @{
        name = 'Administration'
        features = @(
            @{ key = 'instances'; title = 'Instance Management'; type = 'instances' },
            @{ key = 'users'; title = 'Users & Access'; type = 'users' },
            @{ key = 'notifications'; title = 'Notifications'; type = 'notifications' },
            @{ key = 'thresholds'; title = 'Thresholds'; type = 'thresholds' },
            @{ key = 'escalation-matrix'; title = 'Escalation Matrix'; type = 'escalation-matrix'; icon = 'arrow-up-circle' },
            @{ key = 'instance-group'; title = 'Instance Group Execution'; type = 'instance-group' },
            @{ key = 'repository-upgrade'; title = 'Repository Upgrade'; type = 'repository-upgrade' }
        )
    },
    @{
        name = 'Assistants'
        features = @(
            @{ key = 'dictionary'; title = 'SQL Dictionary'; type = 'dictionary' },
            @{ key = 'issues'; title = 'Common Issues & SOPs'; type = 'issues' },
            @{ key = 'web-agent'; title = 'Web Solutions Agent'; type = 'web-agent' }
        )
    }
)

