const state = {
  bootstrap: null,
  currentFeature: null,
  charts: {},
  selectedRows: {},
  token: localStorage.getItem("sqlMonitorToken") || "",
  currentUser: null,
  sidebarCollapsed: localStorage.getItem("sqlMonitorSidebarCollapsed") === "true",
  activeGroupName: "",
  tablePrefs: {},
  ticketMode: "active",
  taskTab: "view",
  biBuilderVisuals: [],
  biSelectedVisualId: null,
  moduleChartConfigs: null,
  suiteQuoteTimer: null,
  assistantOpen: localStorage.getItem("sqlMonitorAssistantOpen") === "true",
  assistantFavorites: readJsonStorage("sqlMonitorAssistantFavorites", []),
};

const els = {
  loginShell: document.getElementById("loginShell"),
  loginForm: document.getElementById("loginForm"),
  loginUser: document.getElementById("loginUser"),
  loginPassword: document.getElementById("loginPassword"),
  loginBtn: document.getElementById("loginBtn"),
  loginMessage: document.getElementById("loginMessage"),
  appShell: document.getElementById("appShell"),
  sidebar: document.getElementById("sidebar"),
  sidebarToggle: document.getElementById("sidebarToggle"),
  nav: document.getElementById("nav"),
  view: document.getElementById("view"),
  viewTitle: document.getElementById("viewTitle"),
  breadcrumb: document.getElementById("breadcrumb"),
  instanceSelect: document.getElementById("instanceSelect"),
  refreshBtn: document.getElementById("refreshBtn"),
  logoutBtn: document.getElementById("logoutBtn"),
  userBadge: document.getElementById("userBadge"),
  statusBar: document.getElementById("statusBar"),
  smartAssistant: document.getElementById("smartAssistant"),
  assistantToggle: document.getElementById("assistantToggle"),
  assistantClose: document.getElementById("assistantClose"),
  assistantPanel: document.getElementById("assistantPanel"),
  assistantBody: document.getElementById("assistantBody"),
};

function readJsonStorage(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  els.loginForm.addEventListener("submit", handleLogin);
  els.logoutBtn.addEventListener("click", handleLogout);
  els.refreshBtn.addEventListener("click", () => loadCurrentFeature());
  els.instanceSelect.addEventListener("change", () => loadCurrentFeature());
  els.sidebarToggle?.addEventListener("click", toggleSidebar);
  els.assistantToggle?.addEventListener("click", toggleSmartAssistant);
  els.assistantClose?.addEventListener("click", () => setSmartAssistantOpen(false));
  applySidebarState();
  applySmartAssistantState();
  await restoreSession();
});

async function restoreSession() {
  if (!state.token) {
    showLogin();
    return;
  }
  try {
    const session = await apiGet("/api/session", { allowAnonymous: true });
    if (!session.authenticated) {
      clearSession();
      showLogin();
      return;
    }
    state.currentUser = session.user;
    showApp();
    await bootstrap({ throwOnError: true });
  } catch {
    clearSession();
    showLogin();
  }
}

async function handleLogin(event) {
  event.preventDefault();
  els.loginMessage.classList.remove("error");
  els.loginMessage.textContent = "Signing in...";
  els.loginBtn.disabled = true;
  try {
    const result = await apiPost("/api/login", {
      UserName: els.loginUser.value,
      Password: els.loginPassword.value,
    }, { allowAnonymous: true });
    state.token = result.token;
    state.currentUser = result.user;
    localStorage.setItem("sqlMonitorToken", state.token);
    els.loginPassword.value = "";
    showApp();
    await bootstrap({ throwOnError: true });
  } catch (error) {
    clearSession();
    showLogin();
    els.loginMessage.classList.add("error");
    els.loginMessage.textContent = error.message;
  } finally {
    els.loginBtn.disabled = false;
  }
}

async function handleLogout() {
  try { await apiPost("/api/logout", {}); } catch {}
  clearSession();
  showLogin();
}

function clearSession() {
  state.token = "";
  state.currentUser = null;
  state.bootstrap = null;
  localStorage.removeItem("sqlMonitorToken");
}

function showLogin() {
  document.body.classList.remove("authenticated");
  document.body.classList.add("login-active");
  els.appShell.hidden = true;
  els.appShell.style.display = "none";
  els.loginShell.hidden = false;
  els.loginShell.style.display = "grid";
  els.loginUser.focus();
}

function showApp() {
  document.body.classList.remove("login-active");
  document.body.classList.add("authenticated");
  els.loginShell.hidden = true;
  els.loginShell.style.display = "none";
  els.appShell.hidden = false;
  els.appShell.style.display = "grid";
  const user = state.currentUser || state.bootstrap?.user;
  els.userBadge.textContent = user ? `${user.DisplayName || user.UserName} (${user.RoleName})` : "";
}

async function bootstrap(options = {}) {
  try {
    showStatus("Loading dashboard metadata...");
    state.bootstrap = await apiGet("/api/bootstrap", { timeoutMs: 90000 });
    state.currentUser = state.bootstrap.user || state.currentUser;
    showApp();
    renderNav();
    renderInstanceSelect();
    renderSmartAssistant();
    const first = state.currentUser?.MustChangePassword ? findFeature("account-security") : { key: "suite-home", title: "Welcome", type: "suite-home", icon: "layout-dashboard" };
    setFeature(first);
    if (state.bootstrap.repositoryError) {
      showStatus(`Repository warning: ${state.bootstrap.repositoryError}`);
    } else {
      showStatus("");
    }
  } catch (error) {
    showError(error.message);
    if (options.throwOnError) throw error;
  }
}

function authHeaders(extra = {}) {
  const headers = { ...extra };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  return headers;
}

async function apiGet(path, options = {}) {
  const response = await fetchWithTimeout(path, { headers: authHeaders() }, options.timeoutMs);
  return handleResponse(response);
}

async function apiPost(path, body = {}, options = {}) {
  const response = await fetchWithTimeout(path, {
    method: "POST",
    headers: authHeaders({ "Content-Type": "application/json" }),
    body: JSON.stringify(body),
  }, options.timeoutMs);
  return handleResponse(response);
}

async function apiDelete(path, options = {}) {
  const response = await fetchWithTimeout(path, { method: "DELETE", headers: authHeaders() }, options.timeoutMs);
  return handleResponse(response);
}

async function fetchWithTimeout(path, options = {}, timeoutMs = 60000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(path, { ...options, signal: controller.signal });
  } catch (error) {
    if (error.name === "AbortError") throw new Error(`Request timed out while calling ${path}. Check whether the web server can reach the SQL Monitor repository.`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function handleResponse(response) {
  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { raw: text };
  }
  if (!response.ok) {
    if (response.status === 401 && state.token) {
      clearSession();
      showLogin();
    }
    throw new Error(payload.error || response.statusText || "Request failed");
  }
  return payload;
}

function renderNav() {
  els.nav.innerHTML = "";
  const homeBtn = document.createElement("button");
  homeBtn.type = "button";
  homeBtn.className = "nav-btn nav-section-btn";
  homeBtn.dataset.group = "Monitoring Suite";
  homeBtn.title = "Monitoring Suite";
  homeBtn.innerHTML = `<span class="nav-icon" aria-hidden="true">${featureIcon({ icon: "layout-dashboard" })}</span><span class="nav-label">Monitoring Suite</span><span class="nav-count">2</span>`;
  homeBtn.addEventListener("click", () => setFeature({ key: "suite-home", title: "Welcome", type: "suite-home", icon: "layout-dashboard" }));
  els.nav.appendChild(homeBtn);

  const adminOnly = new Set(["collector-control", "instances", "users", "notifications", "thresholds", "collector-nodes", "instance-group", "patch-manager", "deployment-center", "repository-upgrade"]);
  const isAdmin = state.currentUser?.RoleName === "Admin";
  state.bootstrap.featureGroups.forEach((group) => {
    const features = group.features.filter((feature) => isAdmin || !adminOnly.has(feature.key));
    if (!features.length) return;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "nav-btn nav-section-btn";
    btn.dataset.group = group.name;
    btn.title = group.name;
    btn.innerHTML = `<span class="nav-icon" aria-hidden="true">${featureIcon(groupIconFeature(group))}</span><span class="nav-label">${escapeHtml(group.name)}</span><span class="nav-count">${features.length}</span>`;
    btn.addEventListener("click", () => setFeature(features[0]));
    els.nav.appendChild(btn);
  });
}

function groupIconFeature(group) {
  const icons = {
    "Command Center": "layout-dashboard",
    "VM Monitoring": "monitor",
    Performance: "chart-line",
    "Storage & Databases": "database",
    Operations: "settings",
    Administration: "shield",
    Assistants: "sparkles",
  };
  return { key: `group-${group.name}`, icon: icons[group.name] || "layout-dashboard" };
}

function toggleSidebar() {
  state.sidebarCollapsed = !state.sidebarCollapsed;
  localStorage.setItem("sqlMonitorSidebarCollapsed", String(state.sidebarCollapsed));
  applySidebarState();
}

function applySidebarState() {
  document.body.classList.toggle("sidebar-collapsed", state.sidebarCollapsed);
  if (!els.sidebarToggle) return;
  els.sidebarToggle.setAttribute("aria-expanded", String(!state.sidebarCollapsed));
  els.sidebarToggle.setAttribute("aria-label", state.sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar");
  els.sidebarToggle.title = state.sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar";
}

function toggleSmartAssistant() {
  setSmartAssistantOpen(!state.assistantOpen);
}

function setSmartAssistantOpen(open) {
  state.assistantOpen = Boolean(open);
  localStorage.setItem("sqlMonitorAssistantOpen", String(state.assistantOpen));
  applySmartAssistantState();
  if (state.assistantOpen) renderSmartAssistant();
}

function applySmartAssistantState() {
  if (!els.assistantPanel || !els.assistantToggle) return;
  els.assistantPanel.hidden = !state.assistantOpen;
  els.assistantToggle.setAttribute("aria-expanded", String(state.assistantOpen));
  els.assistantToggle.title = state.assistantOpen ? "Close Smart Assistant" : "Open Smart Assistant";
  document.body.classList.toggle("assistant-open", state.assistantOpen);
}

function getAccessibleFeatures() {
  const adminOnly = new Set(["collector-control", "instances", "users", "notifications", "thresholds", "collector-nodes", "instance-group", "patch-manager", "deployment-center", "repository-upgrade"]);
  const isAdmin = state.currentUser?.RoleName === "Admin";
  return normalizeRows(state.bootstrap?.featureGroups).flatMap((group) =>
    normalizeRows(group.features)
      .filter((feature) => isAdmin || !adminOnly.has(feature.key))
      .map((feature) => ({ ...feature, groupName: group.name }))
  );
}

function saveAssistantFavorites() {
  state.assistantFavorites = [...new Set(state.assistantFavorites)].filter((key) => getAccessibleFeatures().some((feature) => feature.key === key)).slice(0, 12);
  localStorage.setItem("sqlMonitorAssistantFavorites", JSON.stringify(state.assistantFavorites));
}

function toggleAssistantFavorite(key) {
  if (!key) return;
  if (state.assistantFavorites.includes(key)) state.assistantFavorites = state.assistantFavorites.filter((item) => item !== key);
  else state.assistantFavorites.unshift(key);
  saveAssistantFavorites();
  renderSmartAssistant();
}

function navigateAssistantFeature(key) {
  const feature = findFeature(key);
  if (feature) setFeature(feature);
}

function getAssistantSuggestions() {
  const feature = state.currentFeature || {};
  const suggestions = [
    { label: "Open Alerts", key: "alerts", hint: "Review live critical and warning signals." },
    { label: "Ticket System", key: "tickets", hint: "Check incident ownership and resolutions." },
    { label: "Task Management", key: "tasks", hint: "Review team workload and overdue actions." },
  ];
  if (feature.type === "alerts" || feature.type === "alert-history") suggestions.unshift({ label: "Create tickets", key: "tickets", hint: "Convert noisy alerts into owned work." });
  if (feature.type === "tickets") suggestions.unshift({ label: "Incident Flight Recorder", key: "incident-flight-recorder", hint: "Correlate tickets with telemetry evidence." });
  if (feature.type === "tasks") suggestions.unshift({ label: "Users & Access", key: "users", hint: "Assign work to active application users." });
  if (feature.type === "bi-insights") suggestions.unshift({ label: "Export management report", key: "bi-insights", hint: "Use the BI toolbar Excel export." });
  return suggestions;
}

function renderSmartAssistant(filterText = "") {
  if (!els.assistantBody || !state.bootstrap) return;
  applySmartAssistantState();
  const features = getAccessibleFeatures();
  saveAssistantFavorites();
  const favoriteFeatures = state.assistantFavorites.map((key) => features.find((feature) => feature.key === key)).filter(Boolean);
  const query = String(filterText || "").trim().toLowerCase();
  const matchingFeatures = features.filter((feature) =>
    !query ||
    `${feature.title} ${feature.groupName} ${feature.key}`.toLowerCase().includes(query)
  ).slice(0, 8);
  const current = state.currentFeature || {};
  const isCurrentFavorite = current.key && state.assistantFavorites.includes(current.key);
  els.assistantBody.innerHTML = `
    <div class="assistant-current">
      <span>Current module</span>
      <strong>${escapeHtml(current.title || "Dashboard")}</strong>
      <button class="btn ${isCurrentFavorite ? "" : "primary"}" id="assistantFavoriteCurrent" type="button">${isCurrentFavorite ? "Remove Favorite" : "Add Favorite"}</button>
    </div>
    <label class="assistant-search">
      <span>Find module</span>
      <input id="assistantSearch" type="text" placeholder="Search alerts, tickets, BI..." value="${escapeAttr(filterText)}">
    </label>
    <div class="assistant-section">
      <div class="assistant-section-title">Favorites</div>
      <div class="assistant-chip-list">
        ${favoriteFeatures.length ? favoriteFeatures.map((feature) => assistantFeatureChip(feature, true)).join("") : `<span class="assistant-empty">Add modules for one-click access.</span>`}
      </div>
    </div>
    <div class="assistant-section">
      <div class="assistant-section-title">Quick View</div>
      <div class="assistant-chip-list">
        ${matchingFeatures.map((feature) => assistantFeatureChip(feature, false)).join("")}
      </div>
    </div>
    <div class="assistant-section">
      <div class="assistant-section-title">Smart Suggestions</div>
      <div class="assistant-suggestions">
        ${getAssistantSuggestions().map((item) => `
          <button class="assistant-suggestion" type="button" data-key="${escapeAttr(item.key)}">
            <strong>${escapeHtml(item.label)}</strong>
            <span>${escapeHtml(item.hint)}</span>
          </button>
        `).join("")}
      </div>
    </div>
  `;
  document.getElementById("assistantFavoriteCurrent")?.addEventListener("click", () => toggleAssistantFavorite(current.key));
  document.getElementById("assistantSearch")?.addEventListener("input", (event) => renderSmartAssistant(event.target.value));
  els.assistantBody.querySelectorAll("[data-assistant-feature]").forEach((button) => {
    button.addEventListener("click", () => navigateAssistantFeature(button.dataset.assistantFeature));
  });
  els.assistantBody.querySelectorAll("[data-assistant-favorite]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      toggleAssistantFavorite(button.dataset.assistantFavorite);
    });
  });
  els.assistantBody.querySelectorAll(".assistant-suggestion").forEach((button) => {
    button.addEventListener("click", () => navigateAssistantFeature(button.dataset.key));
  });
}

function assistantFeatureChip(feature, favorite) {
  return `
    <button class="assistant-chip" type="button" data-assistant-feature="${escapeAttr(feature.key)}">
      <span class="assistant-chip-icon">${featureIcon(feature)}</span>
      <span>${escapeHtml(feature.title)}</span>
      <em>${escapeHtml(feature.groupName || "")}</em>
      <i data-assistant-favorite="${escapeAttr(feature.key)}" title="${favorite ? "Remove favorite" : "Add favorite"}">${favorite ? "-" : "+"}</i>
    </button>
  `;
}

function renderInstanceSelect() {
  const instances = state.bootstrap.instances || [];
  els.instanceSelect.innerHTML = instances.length ? instances.map((inst) =>
    `<option value="${inst.InstanceID}">${escapeHtml(inst.DisplayName)}</option>`
  ).join("") : `<option value="">No accessible instances</option>`;
}

function refreshBootstrapInstances(payload) {
  if (payload.instances) {
    state.bootstrap.instances = payload.instances;
  }
  if (payload.repository) {
    state.bootstrap.allInstances = payload.repository;
    if (!payload.instances && payload.repository.length) {
      state.bootstrap.instances = payload.repository.filter((row) => row.IsActive);
    }
  }
  if (payload.configured) state.bootstrap.configuredInstances = payload.configured;
  renderInstanceSelect();
  if (payload.repositoryError) showStatus(`Repository warning: ${payload.repositoryError}`);
}

function findFeature(key) {
  for (const group of state.bootstrap.featureGroups) {
    const found = group.features.find((f) => f.key === key);
    if (found) return found;
  }
  return null;
}

function findFeatureGroup(feature) {
  return state.bootstrap.featureGroups.find((group) =>
    group.features.some((item) => item.key === feature.key)
  );
}

function setFeature(feature) {
  stopSuiteQuoteRotation();
  state.currentFeature = feature;
  const group = findFeatureGroup(feature);
  state.activeGroupName = group?.name || (feature.type === "suite-home" ? "Monitoring Suite" : "");
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.group === state.activeGroupName);
  });
  els.viewTitle.textContent = feature.title;
  els.breadcrumb.textContent = group ? group.name : "SQL Monitor";
  renderWorkspaceTabs(group, feature);
  loadCurrentFeature();
  renderSmartAssistant();
}

function renderWorkspaceTabs(group, activeFeature) {
  document.getElementById("workspaceTabs")?.remove();
  if (!group) return;
  const adminOnly = new Set(["collector-control", "instances", "users", "notifications", "thresholds", "collector-nodes", "instance-group", "patch-manager", "deployment-center", "repository-upgrade"]);
  const isAdmin = state.currentUser?.RoleName === "Admin";
  const features = group.features.filter((feature) => isAdmin || !adminOnly.has(feature.key));
  if (features.length <= 1) return;
  const tabs = document.createElement("nav");
  tabs.id = "workspaceTabs";
  tabs.className = "workspace-tabs";
  tabs.setAttribute("aria-label", `${group.name} modules`);
  tabs.innerHTML = features.map((feature) => `
    <button class="workspace-tab ${feature.key === activeFeature.key ? "active" : ""}" type="button" data-key="${escapeAttr(feature.key)}">
      <span class="workspace-tab-icon" aria-hidden="true">${featureIcon(feature)}</span>
      <span>${escapeHtml(feature.title)}</span>
    </button>
  `).join("");
  els.view.before(tabs);
  tabs.querySelectorAll(".workspace-tab").forEach((button) => {
    button.addEventListener("click", () => {
      const feature = features.find((item) => item.key === button.dataset.key);
      if (feature) setFeature(feature);
    });
  });
}

async function loadCurrentFeature() {
  const feature = state.currentFeature;
  if (!feature) return;
  try {
    showStatus(`Loading ${feature.title}...`);
    if (feature.type === "suite-home") await renderSuiteHome();
    else if (feature.type === "overview") await renderOverview();
    else if (feature.type === "vm-first-overview") await renderVMFirstOverview();
    else if (feature.type === "vm-overview") await renderWindowsMonitoring("overview");
    else if (feature.type === "vm-inventory") await renderWindowsMonitoring("inventory");
    else if (feature.type === "vm-performance") await renderWindowsMonitoring("performance");
    else if (feature.type === "vm-services") await renderWindowsMonitoring("services");
    else if (feature.type === "vm-capacity") await renderWindowsCapacity();
    else if (feature.type === "vm-anomalies") await renderWindowsAnomalies();
    else if (feature.type === "vm-network") await renderWindowsNetwork();
    else if (feature.type === "vm-patching") await renderWindowsPatching();
    else if (feature.type === "module") await renderModule(feature);
    else if (feature.type === "memory-analysis") await renderMemoryAnalysis();
    else if (feature.type === "health") await renderHealth();
    else if (feature.type === "alerts") await renderOpenAlerts();
    else if (feature.type === "alert-history") await renderAlertHistory();
    else if (feature.type === "incident-flight-recorder") await renderIncidentFlightRecorder();
    else if (feature.type === "tickets") await renderTickets();
    else if (feature.type === "tasks") await renderTasks();
    else if (feature.type === "escalation-matrix") await renderEscalationMatrix();
    else if (feature.type === "instances") await renderInstances();
    else if (feature.type === "notifications") await renderNotifications();
    else if (feature.type === "thresholds") await renderThresholds();
    else if (feature.type === "analytics") await renderAnalytics();
    else if (feature.type === "bi-insights") await renderBiInsights();
    else if (feature.type === "collector") await renderCollectorControl();
    else if (feature.type === "collector-nodes") await renderCollectorNodes();
    else if (feature.type === "instance-group") await renderInstanceGroup();
    else if (feature.type === "dictionary") await renderDictionary();
    else if (feature.type === "issues") await renderIssues();
    else if (feature.type === "web-agent") await renderWebAgent();
    else if (feature.type === "query-analyzer") await renderQueryAnalyzer();
    else if (feature.type === "alert-triage") await renderAlertTriage();
    else if (feature.type === "vm-health") await renderVMHealthAssistant();
    else if (feature.type === "incident-timeline") await renderIncidentTimeline();
    else if (feature.type === "config-drift") await renderConfigDrift();
    else if (feature.type === "patch-manager") await renderPatchManager();
    else if (feature.type === "deployment-center") await renderDeploymentCenter();
    else if (feature.type === "repository-upgrade") await renderRepositoryUpgrade();
    else if (feature.type === "account-security") await renderAccountSecurity();
    else if (feature.type === "users") await renderUsers();
    else els.view.innerHTML = `<div class="card">Feature is not wired yet.</div>`;
    showStatus("");
  } catch (error) {
    showError(error.message);
  }
}

function selectedInstanceId() {
  return Number(els.instanceSelect.value || 0);
}

function selectedInstance() {
  const id = selectedInstanceId();
  return (state.bootstrap.instances || []).find((inst) => Number(inst.InstanceID) === id);
}

async function renderOverview() {
  const [data, moduleHealth] = await Promise.all([
    apiGet("/api/overview"),
    apiGet("/api/module-health"),
  ]);
  const s = data.summary || {};
  const instances = normalizeRows(data.instances);
  const alerts = normalizeRows(data.alerts);
  const moduleRows = normalizeRows(moduleHealth.rows);
  const isAdmin = state.currentUser?.RoleName === "Admin";
  const total = Number(s.TotalInstances || instances.length || 0);
  const posture = calculateInstancePosture(instances);
  const healthy = posture.healthy;
  const openAlerts = sumNumeric(instances, "OpenAlertCount", Number(s.OpenAlerts || 0));
  const criticalAlerts = sumNumeric(instances, "CriticalAlertCount", Number(s.CriticalAlerts || 0));
  const warningAlerts = sumNumeric(instances, "WarningAlertCount", Number(s.WarningAlerts || 0));
  const healthScore = posture.score;
  const coverageScore = moduleRows.length ? Math.round((moduleRows.filter((row) => statusClass(row.Status || row.HealthStatus) !== "critical").length / moduleRows.length) * 100) : 100;
  const criticalInstances = posture.critical;
  const warningInstances = posture.warning;
  els.view.innerHTML = `
    <section class="ops-hero">
      <div>
        <p class="eyebrow">Operations Command Center</p>
        <h2>${healthScore}% Health Score</h2>
        <p>${criticalInstances} critical, ${warningInstances} warning, ${openAlerts} open alerts across ${total} monitored instances.</p>
      </div>
      <div class="ops-hero-actions">
        <button class="btn primary" data-open-feature="alerts">Open Alerts</button>
        <button class="btn" data-open-feature="tickets">Tickets</button>
        <button class="btn" data-open-feature="tasks">Tasks</button>
        <button class="btn" data-open-feature="analytics">Analytics</button>
        ${isAdmin ? `<button class="btn warning" data-open-feature="collector-control">Collectors</button>` : ""}
      </div>
    </section>
    <div class="grid four ops-signal-grid">
      ${signalCard("Health Posture", `${healthScore}%`, `${healthy}/${total} instances healthy`, "health", healthScore)}
      ${signalCard("Alert Pressure", openAlerts, `${criticalAlerts} critical alerts`, openAlerts ? "alert" : "calm")}
      ${signalCard("Module Coverage", `${coverageScore}%`, `${moduleRows.length} collector modules reporting`, coverageScore < 80 ? "alert" : "health")}
      ${signalCard("Action Queue", Number(s.OpenAlerts || 0), "Prioritize alerts before ticket conversion", openAlerts ? "watch" : "calm")}
    </div>
    <div class="grid four">
      ${metricCard("Total Instances", s.TotalInstances ?? 0, "Active monitored servers")}
      ${metricCard("Healthy", healthy, "No active warning or critical alerts", "active")}
      ${metricCard("Open Alerts", openAlerts, `${criticalAlerts} critical, ${warningAlerts} warning`, "warning")}
      ${metricCard("Critical", criticalInstances, "Instances requiring attention", "critical")}
    </div>
    ${data.repositoryError ? `<div class="status-bar error">Repository warning: ${escapeHtml(data.repositoryError)}</div>` : ""}
    <div class="card">
      <div class="card-header"><h3>Servers</h3><span class="muted">${escapeHtml(data.capturedAt || "")}</span></div>
      <div class="server-grid" id="serverTiles"></div>
    </div>
    <div class="grid two">
      <div class="card"><div class="card-header"><h3>CPU by Instance</h3></div><div class="chart-box"><canvas id="cpuOverviewChart"></canvas></div></div>
      <div class="card"><div class="card-header"><h3>Memory Available</h3></div><div class="chart-box"><canvas id="memoryOverviewChart"></canvas></div></div>
    </div>
    <div class="card"><div class="card-header"><h3>Latest Open Alerts</h3></div><div id="overviewAlerts"></div></div>
    <div class="card"><div class="card-header"><h3>Module Functionality</h3></div><div id="moduleHealthTable"></div></div>
    ${isAdmin ? `<div class="grid two"><div id="overviewInstances"></div><div id="overviewUsers"></div></div>` : ""}
  `;
  renderServerTiles(document.getElementById("serverTiles"), instances);
  document.querySelectorAll("[data-open-feature]").forEach((button) => {
    button.addEventListener("click", () => {
      const feature = findFeature(button.dataset.openFeature);
      if (feature) setFeature(feature);
    });
  });
  renderTable(document.getElementById("overviewAlerts"), alerts, {
    badges: { Severity: severityClass },
  });
  renderTable(document.getElementById("moduleHealthTable"), moduleRows, {
    badges: { Status: statusClass },
  });
  drawBarChart("cpuOverviewChart", instances, "DisplayName", "SqlCPUPercent", "SQL CPU %", "#0969da");
  drawBarChart("memoryOverviewChart", instances, "DisplayName", "AvailablePhysicalMB", "Available MB", "#198754");
  if (isAdmin) await renderOverviewAdmin();
}

async function renderVMFirstOverview() {
  const data = await apiGet("/api/vms", { timeoutMs: 90000 });
  const vms = normalizeRows(data.vms);
  const standaloneSQL = normalizeRows(data.standaloneSQL);
  const isAdmin = state.currentUser?.RoleName === "Admin";

  // Calculate summary stats
  const totalVMs = vms.length;
  const totalSQL = vms.reduce((sum, vm) => sum + (Number(vm.SQLInstanceCount) || 0), 0) + standaloneSQL.length;
  const healthyVMs = vms.filter((vm) => vm.OverallPosture === 'Healthy' || vm.OverallPosture === 'NoSQL').length;
  const warningVMs = vms.filter((vm) => vm.OverallPosture === 'Warning').length;
  const criticalVMs = vms.filter((vm) => vm.OverallPosture === 'Critical').length;
  const totalOpenAlerts = vms.reduce((sum, vm) => sum + (Number(vm.OpenAlertCount) || 0), 0);
  const totalCriticalAlerts = vms.reduce((sum, vm) => sum + (Number(vm.CriticalAlertCount) || 0), 0);
  const avgHealthScore = totalVMs > 0 ? Math.round(vms.reduce((sum, vm) => sum + (Number(vm.HealthScore) || 0), 0) / totalVMs) : 0;

  els.viewTitle.textContent = "Server Overview";
  els.view.innerHTML = `
    <section class="ops-hero">
      <div>
        <p class="eyebrow">Operations Command Center</p>
        <h2>${avgHealthScore}% Health Score</h2>
        <p>${criticalVMs} critical, ${warningVMs} warning, ${totalOpenAlerts} open alerts across ${totalVMs} servers and ${totalSQL} SQL instances.</p>
      </div>
      <div class="ops-hero-actions">
        <button class="btn primary" data-open-feature="alerts">Open Alerts</button>
        <button class="btn" data-open-feature="tickets">Tickets</button>
        <button class="btn" data-open-feature="tasks">Tasks</button>
        ${isAdmin ? `<button class="btn warning" data-open-feature="collector-control">Collectors</button>` : ""}
      </div>
    </section>
    <div class="grid four ops-signal-grid">
      ${signalCard("Servers", totalVMs, `${healthyVMs} healthy, ${warningVMs} warning`, totalVMs > 0 ? "health" : "calm")}
      ${signalCard("SQL Instances", totalSQL, "Across all servers", totalSQL > 0 ? "health" : "calm")}
      ${signalCard("Alert Pressure", totalOpenAlerts, `${totalCriticalAlerts} critical alerts`, totalCriticalAlerts > 0 ? "alert" : totalOpenAlerts ? "watch" : "calm")}
      ${signalCard("Health Score", `${avgHealthScore}%`, "VM estate average", avgHealthScore >= 80 ? "health" : avgHealthScore >= 50 ? "watch" : "alert")}
    </div>
    ${data.repositoryError ? `<div class="status-bar error">Repository warning: ${escapeHtml(data.repositoryError)}</div>` : ""}
    <div class="card">
      <div class="card-header"><h3>Servers</h3><span class="muted">${totalVMs} server(s) with ${totalSQL} SQL instance(s)</span></div>
      <div class="vm-server-grid" id="vmServerTiles"></div>
    </div>
    ${standaloneSQL.length > 0 ? `
    <div class="card">
      <div class="card-header"><h3>Standalone SQL Instances</h3><span class="muted">${standaloneSQL.length} instance(s) not linked to a VM</span></div>
      <div id="standaloneSQLTable"></div>
    </div>` : ""}
  `;

  renderVMTiles(document.getElementById("vmServerTiles"), vms);

  if (standaloneSQL.length > 0) {
    renderTable(document.getElementById("standaloneSQLTable"), standaloneSQL, {
      badges: { SqlHealthPosture: statusClass },
    });
  }

  document.querySelectorAll("[data-open-feature]").forEach((button) => {
    button.addEventListener("click", () => {
      const feature = findFeature(button.dataset.openFeature);
      if (feature) setFeature(feature);
    });
  });
}

function renderVMTiles(container, vms) {
  if (!vms.length) {
    container.innerHTML = `<div class="details">No servers configured. Add VMs and SQL instances in Instance Management.</div>`;
    return;
  }
  container.innerHTML = vms.map((vm) => {
    const tone = serverStatusTone(vm.OverallPosture);
    const cpu = formatNumber(vm.CPUPercent, 1);
    const mem = formatNumber(vm.MemoryUsedPercent, 1);
    const disk = formatNumber(vm.DiskUsedPercent, 1);
    const sqlCount = Number(vm.SQLInstanceCount) || 0;
    const alerts = Number(vm.OpenAlertCount || 0);
    return `
      <div class="vm-tile ${tone}" type="button">
        <div class="vm-tile-header">
          <span class="server-status-dot"></span>
          <span class="vm-tile-name">${escapeHtml(vm.DisplayName || vm.ComputerName || "Server")}</span>
          <span class="vm-tile-posture">${escapeHtml(vm.OverallPosture || "Unknown")}</span>
        </div>
        <div class="vm-tile-metrics">
          <span>CPU ${escapeHtml(cpu)}%</span>
          <span>Mem ${escapeHtml(mem)}%</span>
          <span>Disk ${escapeHtml(disk)}%</span>
          <span>${alerts} alerts</span>
        </div>
        <div class="vm-tile-sql">
          ${sqlCount > 0 ? `
            <div class="vm-tile-sql-header">${sqlCount} SQL Instance${sqlCount === 1 ? "" : "s"}</div>
            ${(vm.SQLInstances || []).map((sql) => {
              const sqlTone = serverStatusTone(sql.SqlHealthPosture);
              return `
                <button class="vm-tile-sql-item ${sqlTone}" type="button" data-instance-id="${escapeAttr(sql.InstanceID)}">
                  <span class="server-status-dot"></span>
                  <span class="vm-tile-sql-name">${escapeHtml(sql.DisplayName)}</span>
                  <span class="vm-tile-sql-metrics">CPU ${formatNumber(sql.SqlCPUPercent, 1)}% · ${sql.OpenAlertCount} alerts</span>
                </button>
              `;
            }).join("")}
          ` : `<div class="vm-tile-sql-empty">No SQL instances linked</div>`}
        </div>
      </div>
    `;
  }).join("");

  // Add click handlers for VM tiles (navigate to VM overview for this server)
  container.querySelectorAll(".vm-tile").forEach((tile) => {
    tile.addEventListener("click", (e) => {
      // Don't navigate if clicking a SQL instance button inside the tile
      if (e.target.closest(".vm-tile-sql-item")) return;
      const feature = findFeature("vm-overview");
      if (feature) setFeature(feature);
    });
  });

  // Add click handlers for SQL instance tiles
  container.querySelectorAll(".vm-tile-sql-item").forEach((item) => {
    item.addEventListener("click", (e) => {
      e.stopPropagation();
      const instanceId = Number(item.dataset.instanceId);
      if (instanceId > 0) {
        els.instanceSelect.value = instanceId;
        setFeature(findFeature("health"));
      }
    });
  });
}

function renderSuiteHome() {
  const user = state.currentUser || state.bootstrap?.user || {};
  const name = user.DisplayName || user.UserName || "there";
  const greeting = timeGreeting(new Date());
  const quote = getRotatingSuiteQuote();
  const sqlInstances = normalizeRows(state.bootstrap?.instances).length;
  const roleName = user.RoleName || "Operator";
  
  els.viewTitle.textContent = "Welcome";
  els.breadcrumb.textContent = "Monitoring Suite";
  document.getElementById("workspaceTabs")?.remove();
  els.view.innerHTML = `
    <section class="suite-home">
      <div class="suite-welcome">
        <p class="eyebrow">SQL Monitor Enterprise</p>
        <h2>${escapeHtml(greeting)}, ${escapeHtml(name)}</h2>
        <p class="suite-quote" id="suiteRotatingQuote">&ldquo;${escapeHtml(quote)}&rdquo;</p>
        <div class="suite-context">
          <span>${escapeHtml(roleName)}</span>
          <span>${escapeHtml(sqlInstances)} SQL instance${sqlInstances === 1 ? "" : "s"} in scope</span>
          <span>Lightweight VM telemetry ready</span>
        </div>
      </div>
      <div class="suite-choice-grid">
        <button class="suite-choice sql" type="button" data-suite-feature="vm-first-overview">
          <span class="suite-choice-icon">${featureIcon({ icon: "layout-dashboard" })}</span>
          <strong>Unified Monitoring</strong>
          <span>VM-first hierarchy: servers with nested SQL instances, health, alerts, collectors, and operations.</span>
        </button>
        <button class="suite-choice vm" type="button" data-suite-feature="vm-overview">
          <span class="suite-choice-icon">${featureIcon({ icon: "monitor" })}</span>
          <strong>VM Telemetry Only</strong>
          <span>Windows health, CPU, memory, disks, services, uptime, and estate posture without SQL details.</span>
        </button>
      </div>
    </section>
  `;
  document.querySelectorAll("[data-suite-feature]").forEach((button) => {
    button.addEventListener("click", () => {
      const feature = findFeature(button.dataset.suiteFeature);
      if (feature) setFeature(feature);
    });
  });
  startSuiteQuoteRotation();
}

function timeGreeting(date) {
  const hour = date.getHours();
  if (hour < 12) return "Good Morning";
  if (hour < 17) return "Good Afternoon";
  return "Good Evening";
}

function getSuiteQuotes() {
  return [
    "A calm estate is not silent. It is SQL Server and Windows VMs telling the truth early.",
    "Healthy VMs give SQL Server room to breathe; healthy SQL gives the business room to move.",
    "Monitor CPU, memory, disk, waits, and alerts together. Incidents rarely respect boundaries.",
    "The best dashboard catches pressure before users can name it.",
    "A VM can look alive while SQL Server is waiting; watch both layers.",
    "Capacity planning is guessing the future. Monitoring is knowing the present.",
    "Good monitoring turns noisy machines into clear decisions.",
    "SQL Server performance starts below the query plan: memory, storage, CPU, and clean services.",
    "Alert fatigue is real. Measure what matters and escalate what cannot wait.",
    "A stopped Windows service today can become a Sev1 database incident tonight.",
    "The fastest query is still slow on a starving VM.",
    "Trends beat thresholds when you need to see trouble forming.",
    "Disk pressure whispers before it shouts. Listen while there is still free space.",
    "Patch posture, uptime, and event logs are part of performance, not paperwork.",
    "Every critical alert deserves context: host health, SQL health, SLA, owner, and next action.",
    "A monitoring tool should reduce anxiety, not create a second incident queue.",
    "SQL waits tell one chapter; VM telemetry tells the one before it.",
    "The right ticket is an alert with ownership, urgency, SLA, and evidence.",
    "Normal state is a discipline: light collection, useful signals, and fast escalation.",
    "When VM and SQL telemetry agree, troubleshooting gets wonderfully boring.",
    "A dashboard earns trust one accurate minute at a time.",
    "Good morning or good evening, the estate still prefers evidence over assumptions.",
    "Outshine the tools you admire by being quieter, faster, clearer, and kinder to servers.",
    "The best monitoring is lightweight on machines and heavy on insight."
  ];
}

function getRotatingSuiteQuote(date = new Date()) {
  const quotes = getSuiteQuotes();
  const minutesSinceEpoch = Math.floor(date.getTime() / 60000);
  return quotes[minutesSinceEpoch % quotes.length];
}

function startSuiteQuoteRotation() {
  stopSuiteQuoteRotation();
  const updateQuote = () => {
    const host = document.getElementById("suiteRotatingQuote");
    if (!host) return;
    host.innerHTML = `&ldquo;${escapeHtml(getRotatingSuiteQuote())}&rdquo;`;
  };
  updateQuote();
  state.suiteQuoteTimer = window.setInterval(updateQuote, 60000);
}

function stopSuiteQuoteRotation() {
  if (state.suiteQuoteTimer) {
    window.clearInterval(state.suiteQuoteTimer);
    state.suiteQuoteTimer = null;
  }
}

async function renderWindowsMonitoring(tab) {
  const data = await apiGet("/api/windows/overview", { timeoutMs: 90000 });
  const summary = data.summary || {};
  const targets = normalizeRows(data.targets);
  const trend = normalizeRows(data.trend);
  const disks = normalizeRows(data.disks);
  const services = normalizeRows(data.services);
  const processes = normalizeRows(data.processes);
  const events = normalizeRows(data.events);
  const hotfixes = normalizeRows(data.hotfixes);
  const networkAdapters = normalizeRows(data.networkAdapters);
  const perfCounters = normalizeRows(data.perfCounters);
  const vmAlerts = normalizeRows(data.vmAlerts);
  const vmAlertRules = normalizeRows(data.vmAlertRules);
  const activeTitle = tab === "inventory" ? "VM Inventory" : tab === "performance" ? "VM Performance" : tab === "services" ? "Windows Services" : "VM Overview";
  els.viewTitle.textContent = activeTitle;
  els.view.innerHTML = `
    <section class="ops-hero vm-hero">
      <div>
        <p class="eyebrow">VM Monitoring</p>
        <h2>${escapeHtml(summary.AvgHealthScore || 0)}% Estate Health</h2>
        <p>${escapeHtml(summary.Critical || 0)} critical, ${escapeHtml(summary.Warning || 0)} warning, ${escapeHtml(summary.Healthy || 0)} healthy across ${escapeHtml(summary.TotalVMs || targets.length)} Windows targets.</p>
      </div>
      <div class="ops-hero-actions">
        <button class="btn primary" data-vm-tab="vm-overview">Overview</button>
        <button class="btn" data-vm-tab="vm-inventory">Inventory</button>
        <button class="btn" data-vm-tab="vm-performance">Performance</button>
        <button class="btn" data-vm-tab="vm-services">Services</button>
        <button class="btn" data-vm-tab="vm-capacity">Capacity</button>
        <button class="btn" data-vm-tab="vm-anomalies">Anomalies</button>
        <button class="btn" data-vm-tab="vm-network">Network</button>
        <button class="btn" data-vm-tab="vm-patching">Patching</button>
        <button class="btn warning" id="evaluateVmAlerts" type="button">Evaluate Alerts</button>
      </div>
    </section>
    <div class="grid four">
      ${metricCard("Windows Targets", summary.TotalVMs ?? targets.length, "Enabled VM monitoring scope")}
      ${metricCard("Healthy", summary.Healthy ?? 0, "Current posture", "active")}
      ${metricCard("Warning", summary.Warning ?? 0, "Needs review", Number(summary.Warning || 0) ? "warning" : "")}
      ${metricCard("Critical", summary.Critical ?? 0, "Immediate attention", Number(summary.Critical || 0) ? "critical" : "")}
    </div>
    <div class="grid three">
      ${metricCard("Open VM Alerts", summary.OpenVMAlerts ?? vmAlerts.length, `${summary.CriticalVMAlerts || 0} critical`, Number(summary.CriticalVMAlerts || 0) ? "critical" : Number(summary.OpenVMAlerts || 0) ? "warning" : "active")}
      ${metricCard("VM Tickets", summary.VMTickets ?? vmAlerts.filter((row) => row.TicketID).length, "Auto-created from VM alerts")}
      ${metricCard("Alert Rules", vmAlertRules.length, "Active VM rule catalog")}
    </div>
    ${data.message ? `<div class="status-bar warning">${escapeHtml(data.message)}</div>` : ""}
    ${renderWindowsTabContent(tab)}
  `;
  document.querySelectorAll("[data-vm-tab]").forEach((button) => {
    button.addEventListener("click", () => {
      const tab = button.dataset.vmTab;
      if (tab === "vm-capacity") {
        setFeature(findFeature("vm-capacity"));
      } else if (tab === "vm-anomalies") {
        setFeature(findFeature("vm-anomalies"));
      } else if (tab === "vm-network") {
        setFeature(findFeature("vm-network"));
      } else if (tab === "vm-patching") {
        setFeature(findFeature("vm-patching"));
      } else {
        const feature = findFeature(tab);
        if (feature) setFeature(feature);
      }
    });
  });
  document.getElementById("evaluateVmAlerts")?.addEventListener("click", async () => {
    showStatus("Evaluating VM alerts and ticket conversion...");
    await apiPost("/api/windows/evaluate-alerts", {});
    await renderWindowsMonitoring(tab);
  });
  if (tab === "inventory") {
    renderTable(document.getElementById("vmInventoryTable"), targets, { badges: { HealthPosture: statusClass } });
    renderTable(document.getElementById("vmNetworkTable"), networkAdapters, { badges: { StatusName: statusClass } });
    renderTable(document.getElementById("vmHotfixTable"), hotfixes);
    renderTable(document.getElementById("vmAlertRulesTable"), vmAlertRules, { badges: { IsAutoTicketEnabled: booleanTone, IsActive: activeClass } });
  } else if (tab === "performance") {
    renderTable(document.getElementById("vmDiskTable"), disks, { badges: { UsedPercent: percentTone } });
    renderTable(document.getElementById("vmProcessTable"), processes, { badges: { RankingType: statusClass } });
    renderTable(document.getElementById("vmPerfCounterTable"), perfCounters);
    drawWindowsTrendChart("vmCpuTrend", trend, "CPUPercent", "CPU %", "#0969da");
    drawWindowsTrendChart("vmMemoryTrend", trend, "MemoryUsedPercent", "Memory Used %", "#7357c8");
    drawWindowsTrendChart("vmDiskTrend", trend, "DiskUsedPercent", "Disk Used %", "#f2a900");
  } else if (tab === "services") {
    renderTable(document.getElementById("vmServicesTable"), services, { badges: { IsCritical: booleanTone, StateName: statusClass } });
    renderTable(document.getElementById("vmEventsTable"), events, { badges: { LevelName: severityClass } });
  } else {
    renderWindowsTiles(document.getElementById("vmTiles"), targets);
    renderTable(document.getElementById("vmAlertsTable"), vmAlerts, { badges: { Severity: severityClass, IsTicketCreated: booleanTone } });
    renderTable(document.getElementById("vmOverviewEvents"), events.slice(0, 12), { badges: { LevelName: severityClass } });
    renderTable(document.getElementById("vmOverviewProcesses"), processes.slice(0, 12), { badges: { RankingType: statusClass } });
    drawDoughnutChart("vmPostureChart", [
      { Label: "Healthy", Value: Number(summary.Healthy || 0) },
      { Label: "Warning", Value: Number(summary.Warning || 0) },
      { Label: "Critical", Value: Number(summary.Critical || 0) },
    ], "Label", "Value", ["#16834a", "#f2a900", "#d73a49"]);
    drawWindowsTrendChart("vmHealthTrend", trend, "HealthScore", "Health Score", "#0f9f8f");
  }

  function renderWindowsTabContent(currentTab) {
    if (currentTab === "inventory") {
      return `
        <div class="card"><div class="card-header"><h3>Windows Inventory</h3><span>${targets.length} target(s)</span></div><div id="vmInventoryTable"></div></div>
        <div class="grid two">
          <div class="card"><div class="card-header"><h3>Network Adapters</h3><span>Latest captured state</span></div><div id="vmNetworkTable"></div></div>
          <div class="card"><div class="card-header"><h3>Patch Snapshot</h3><span>Latest hotfix evidence</span></div><div id="vmHotfixTable"></div></div>
        </div>
        <div class="card"><div class="card-header"><h3>VM Alert Rules</h3><span>Category, SLA, and auto-ticket policy</span></div><div id="vmAlertRulesTable"></div></div>
      `;
    }
    if (currentTab === "performance") {
      return `
        <div class="grid three">
          <div class="card"><div class="card-header"><h3>CPU Trend</h3></div><div class="chart-box"><canvas id="vmCpuTrend"></canvas></div></div>
          <div class="card"><div class="card-header"><h3>Memory Trend</h3></div><div class="chart-box"><canvas id="vmMemoryTrend"></canvas></div></div>
          <div class="card"><div class="card-header"><h3>Disk Trend</h3></div><div class="chart-box"><canvas id="vmDiskTrend"></canvas></div></div>
        </div>
        <div class="card"><div class="card-header"><h3>Latest Disk Capacity</h3></div><div id="vmDiskTable"></div></div>
        <div class="grid two">
          <div class="card"><div class="card-header"><h3>Top Processes</h3><span>CPU and memory leaders</span></div><div id="vmProcessTable"></div></div>
          <div class="card"><div class="card-header"><h3>Perf Counter Burst</h3><span>Short sample evidence</span></div><div id="vmPerfCounterTable"></div></div>
        </div>
      `;
    }
    if (currentTab === "services") {
      return `
        <div class="card"><div class="card-header"><h3>Stopped Automatic Services</h3><span>Latest captured exceptions</span></div><div id="vmServicesTable"></div></div>
        <div class="card"><div class="card-header"><h3>Recent Windows Events</h3><span>Critical, error, and warning evidence</span></div><div id="vmEventsTable"></div></div>
      `;
    }
    return `
      <div class="grid two">
        <div class="card"><div class="card-header"><h3>VM Posture</h3></div><div class="chart-box"><canvas id="vmPostureChart"></canvas></div></div>
        <div class="card"><div class="card-header"><h3>Health Score Trend</h3></div><div class="chart-box"><canvas id="vmHealthTrend"></canvas></div></div>
      </div>
      <div class="card"><div class="card-header"><h3>Windows Estate</h3></div><div id="vmTiles" class="server-grid"></div></div>
      <div class="card"><div class="card-header"><h3>Open VM Alerts</h3><span>Auto-ticket and SLA state</span></div><div id="vmAlertsTable"></div></div>
      <div class="grid two">
        <div class="card"><div class="card-header"><h3>Recent Windows Events</h3><span>Latest warnings and errors</span></div><div id="vmOverviewEvents"></div></div>
        <div class="card"><div class="card-header"><h3>Top Processes</h3><span>CPU and memory leaders</span></div><div id="vmOverviewProcesses"></div></div>
      </div>
    `;
  }
}

async function renderWindowsCapacity() {
  els.viewTitle.textContent = "Capacity Forecast";
  els.view.innerHTML = `<div class="status-bar">Loading capacity forecast...</div>`;

  let capacity = [], baselines = [], sampleStatus = [];
  try {
    const [capData, baseData] = await Promise.all([
      apiGet("/api/windows/capacity"),
      apiGet("/api/windows/baselines"),
    ]);
    capacity = normalizeRows(capData.capacity);
    baselines = normalizeRows(baseData.baselines);
    sampleStatus = normalizeRows(capData.sampleStatus);
  } catch (err) {
    els.view.innerHTML = `<div class="status-bar error">Failed to load capacity data: ${escapeHtml(err.message)}</div>`;
    return;
  }

  const urgent = capacity.filter((r) => Number(r.DaysUntilExhaustion) > 0 && Number(r.DaysUntilExhaustion) <= 30);
  const warning = capacity.filter((r) => Number(r.DaysUntilExhaustion) > 30 && Number(r.DaysUntilExhaustion) <= 90);
  const healthy = capacity.filter((r) => Number(r.DaysUntilExhaustion) > 90 || r.DaysUntilExhaustion == null);

  const sampleStatusHtml = sampleStatus.length > 0 ? `
    <div class="card">
      <div class="card-header"><h3>Sample Data Status</h3><span>${sampleStatus.length} target(s)</span></div>
      <div id="vmSampleStatusTable"></div>
    </div>
  ` : '';

  const noDataHtml = capacity.length === 0 ? `
    <div class="status-bar warning">
      <strong>No forecast data available.</strong>
      ${sampleStatus.length === 0
        ? ' No Windows performance samples found. Ensure the Windows VM collector is running and collecting data.'
        : ' Insufficient sample history. At least 2 days of samples with DiskUsedPercent and MemoryUsedPercent data are required per target. See Sample Data Status below.'}
      <br><br>
      <strong>How to fix:</strong>
      <ol style="margin:8px 0 0 20px;padding:0">
        <li>Verify Windows VM collectors are enabled and running</li>
        <li>Check that <code>mon.WindowsTargets</code> has enabled targets</li>
        <li>Ensure samples include both DiskUsedPercent and MemoryUsedPercent values. If memory is NULL, the collector may not be collecting memory data.</li>
        <li>Wait for at least 2 days of samples to accumulate, or run: <code>Scripts\\insert_capacity_samples.ps1</code></li>
        <li>Click "Calculate Forecast" after samples are available</li>
      </ol>
    </div>
  ` : '';

  els.view.innerHTML = `
    <section class="ops-hero vm-hero">
      <div>
        <p class="eyebrow">VM Capacity Forecast</p>
        <h2>Resource Exhaustion Predictions</h2>
        <p>Linear regression on historical samples to forecast when disk and memory will reach capacity.</p>
      </div>
      <div class="ops-hero-actions">
        <button class="btn primary" id="btnCalcForecast" type="button">Calculate Forecast</button>
        <button class="btn" id="btnCalcBaselines" type="button">Recalculate Baselines</button>
      </div>
    </section>
    <div class="grid three">
      ${metricCard("Urgent (< 30 days)", urgent.length, "Immediate action needed", urgent.length > 0 ? "critical" : "active")}
      ${metricCard("Warning (30-90 days)", warning.length, "Plan capacity expansion", warning.length > 0 ? "warning" : "active")}
      ${metricCard("Healthy (> 90 days)", healthy.length, "No immediate action", "active")}
    </div>
    <div class="card">
      <div class="card-header"><h3>Capacity Forecast Details</h3><span>${capacity.length} forecast(s)</span></div>
      <div id="vmCapacityTable"></div>
    </div>
    <div class="card">
      <div class="card-header"><h3>Current Baselines</h3><span>${baselines.length} baseline metric(s)</span></div>
      <div id="vmBaselineTable"></div>
    </div>
    ${sampleStatusHtml}
    ${noDataHtml}
  `;

  const capacityColumns = ["DisplayName", "MetricName", "CurrentValue", "GrowthRatePerDay", "ForecastExhaustionDate", "DaysUntilExhaustion", "ConfidencePercent", "RecommendedAction"];
  renderTable(document.getElementById("vmCapacityTable"), capacity, {
    columns: capacityColumns,
    badges: { RecommendedAction: (v) => {
      if (!v) return '';
      const s = String(v).toLowerCase();
      if (s.includes('urgent')) return 'critical';
      if (s.includes('plan') || s.includes('monitor')) return 'warning';
      return 'active';
    }}
  });

  const baselineColumns = ["DisplayName", "MetricName", "CurrentHourAvg", "CurrentHourStdDev", "SampleCount", "LastCalculatedAt"];
  renderTable(document.getElementById("vmBaselineTable"), baselines, { columns: baselineColumns });

  if (sampleStatus.length > 0) {
    const statusColumns = ["DisplayName", "TotalSamples", "DistinctDays", "EarliestSample", "LatestSample", "DiskSamples", "MemorySamples"];
    renderTable(document.getElementById("vmSampleStatusTable"), sampleStatus, {
      columns: statusColumns,
      labels: { TotalSamples: "Total Samples", DistinctDays: "Days of Data", EarliestSample: "Earliest", LatestSample: "Latest", DiskSamples: "Disk Samples", MemorySamples: "Memory Samples" }
    });
  }

  document.getElementById("btnCalcForecast")?.addEventListener("click", async () => {
    showStatus("Calculating capacity forecast...");
    try {
      const result = await apiPost("/api/windows/calculate-forecast", {});
      showStatus(`Forecast calculated. ${result.forecastsUpdated || 0} forecast(s) updated.`);
      await renderWindowsCapacity();
    } catch (err) {
      showError(err.message);
    }
  });

  document.getElementById("btnCalcBaselines")?.addEventListener("click", async () => {
    showStatus("Calculating baselines...");
    try {
      const result = await apiPost("/api/windows/calculate-baselines", {});
      showStatus(`Baselines calculated. ${result.baselinesUpdated || 0} baseline(s) updated.`);
      await renderWindowsCapacity();
    } catch (err) {
      showError(err.message);
    }
  });
}

async function renderWindowsAnomalies() {
  els.viewTitle.textContent = "Anomaly Detection";
  els.view.innerHTML = `<div class="status-bar">Loading anomalies...</div>`;

  let anomalies = [], baselines = [];
  try {
    const [anomData, baseData] = await Promise.all([
      apiGet("/api/windows/anomalies"),
      apiGet("/api/windows/baselines"),
    ]);
    anomalies = normalizeRows(anomData.anomalies);
    baselines = normalizeRows(baseData.baselines);
  } catch (err) {
    els.view.innerHTML = `<div class="status-bar error">Failed to load anomaly data: ${escapeHtml(err.message)}</div>`;
    return;
  }

  const criticalCount = anomalies.filter((r) => r.Severity === 'Critical').length;
  const warningCount = anomalies.filter((r) => r.Severity === 'Warning').length;

  els.view.innerHTML = `
    <section class="ops-hero vm-hero">
      <div>
        <p class="eyebrow">VM Anomaly Detection</p>
        <h2>Baseline Deviation Alerts</h2>
        <p>Metrics that deviate significantly from established baselines (by standard deviation).</p>
      </div>
      <div class="ops-hero-actions">
        <button class="btn primary" id="btnDetectAnomalies" type="button">Detect Anomalies</button>
        <button class="btn" id="btnCalcBaselinesAnom" type="button">Recalculate Baselines</button>
      </div>
    </section>
    <div class="grid three">
      ${metricCard("Critical Anomalies", criticalCount, "Immediate attention", criticalCount > 0 ? "critical" : "active")}
      ${metricCard("Warning Anomalies", warningCount, "Needs review", warningCount > 0 ? "warning" : "active")}
      ${metricCard("Active Baselines", baselines.length, "Metrics with baselines", "active")}
    </div>
    <div class="card">
      <div class="card-header"><h3>Unacknowledged Anomalies</h3><span>${anomalies.length} active</span></div>
      <div id="vmAnomalyTable"></div>
    </div>
    ${anomalies.length === 0 ? '<div class="status-bar">No unacknowledged anomalies. Click "Detect Anomalies" to scan for deviations, or "Recalculate Baselines" to establish baselines first.</div>' : ''}
  `;

  const anomalyColumns = ["DisplayName", "MetricName", "DetectedAt", "ActualValue", "BaselineAvg", "DeviationMultiplier", "Severity"];
  renderTable(document.getElementById("vmAnomalyTable"), anomalies, {
    columns: anomalyColumns,
    badges: { Severity: (v) => v === 'Critical' ? 'critical' : v === 'Warning' ? 'warning' : 'info' },
    actions: [
      {
        label: "Ack",
        handler: async (row) => {
          try {
            await apiPost("/api/windows/acknowledge-anomaly", { AnomalyID: row.AnomalyID });
            await renderWindowsAnomalies();
          } catch (err) {
            showError(err.message);
          }
        }
      }
    ]
  });

  document.getElementById("btnDetectAnomalies")?.addEventListener("click", async () => {
    showStatus("Detecting anomalies...");
    try {
      await apiPost("/api/windows/detect-anomalies", {});
      showStatus("Anomaly detection complete.");
      await renderWindowsAnomalies();
    } catch (err) {
      showError(err.message);
    }
  });

  document.getElementById("btnCalcBaselinesAnom")?.addEventListener("click", async () => {
    showStatus("Calculating baselines...");
    try {
      await apiPost("/api/windows/calculate-baselines", {});
      showStatus("Baselines calculated successfully.");
      await renderWindowsAnomalies();
    } catch (err) {
      showError(err.message);
    }
  });
}

async function renderWindowsNetwork() {
  els.viewTitle.textContent = "Network Monitor";
  els.view.innerHTML = `<div class="status-bar">Loading network data...</div>`;

  let connections = [], adapterStats = [], firewall = [];
  try {
    const data = await apiGet("/api/windows/network");
    connections = normalizeRows(data.connections);
    adapterStats = normalizeRows(data.adapterStats);
    firewall = normalizeRows(data.firewall);
  } catch (err) {
    els.view.innerHTML = `<div class="status-bar error">Failed to load network data: ${escapeHtml(err.message)}</div>`;
    return;
  }

  const disabledFw = firewall.filter((r) => r.Enabled === false).length;
  const highUtil = adapterStats.filter((r) => Number(r.UtilizationPercent) > 70).length;

  els.view.innerHTML = `
    <section class="ops-hero vm-hero">
      <div>
        <p class="eyebrow">VM Network Monitor</p>
        <h2>Network Deep Dive</h2>
        <p>Per-adapter bandwidth, TCP connections, and firewall status across Windows targets.</p>
      </div>
    </section>
    <div class="grid three">
      ${metricCard("Active Adapters", adapterStats.length, "With bandwidth stats", "active")}
      ${metricCard("High Utilization", highUtil, "Above 70% bandwidth", highUtil > 0 ? "warning" : "active")}
      ${metricCard("Firewall Disabled", disabledFw, "Profiles without protection", disabledFw > 0 ? "critical" : "active")}
    </div>
    <div class="card">
      <div class="card-header"><h3>Adapter Bandwidth Utilization</h3><span>${adapterStats.length} adapter(s)</span></div>
      <div id="vmNetAdapterTable"></div>
    </div>
    <div class="grid two">
      <div class="card">
        <div class="card-header"><h3>TCP Connections</h3><span>Latest ${connections.length} connections</span></div>
        <div id="vmNetConnectionTable"></div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Firewall Status</h3><span>${firewall.length} profile(s)</span></div>
        <div id="vmNetFirewallTable"></div>
      </div>
    </div>
  `;

  renderTable(document.getElementById("vmNetAdapterTable"), adapterStats, {
    columns: ["DisplayName", "AdapterName", "BytesReceivedPerSec", "BytesSentPerSec", "BytesTotalPerSec", "UtilizationPercent"],
    badges: { UtilizationPercent: (v) => { const n = Number(v); return n > 80 ? 'critical' : n > 50 ? 'warning' : 'active'; } }
  });

  renderTable(document.getElementById("vmNetConnectionTable"), connections, {
    columns: ["DisplayName", "LocalAddress", "LocalPort", "RemoteAddress", "RemotePort", "State"]
  });

  renderTable(document.getElementById("vmNetFirewallTable"), firewall, {
    columns: ["DisplayName", "ProfileName", "Enabled", "DefaultInboundAction", "DefaultOutboundAction"],
    badges: { Enabled: (v) => v === true || v === 'true' ? 'active' : 'critical' }
  });
}

async function renderWindowsPatching() {
  els.viewTitle.textContent = "Patching Compliance";
  els.view.innerHTML = `<div class="status-bar">Loading patching data...</div>`;

  let compliance = [], missing = [], timeline = [];
  try {
    const data = await apiGet("/api/windows/patching");
    compliance = normalizeRows(data.compliance);
    missing = normalizeRows(data.missing);
    timeline = normalizeRows(data.timeline);
  } catch (err) {
    els.view.innerHTML = `<div class="status-bar error">Failed to load patching data: ${escapeHtml(err.message)}</div>`;
    return;
  }

  const nonCompliant = compliance.filter((r) => r.ComplianceStatus === 'Non-Compliant').length;
  const missingCritical = missing.filter((r) => r.IsRequired === true || r.IsRequired === 1).length;
  const avgScore = compliance.length > 0 ? Math.round(compliance.reduce((s, r) => s + Number(r.ComplianceScore), 0) / compliance.length) : 0;

  els.view.innerHTML = `
    <section class="ops-hero vm-hero">
      <div>
        <p class="eyebrow">VM Patching Compliance</p>
        <h2>${avgScore}% Average Compliance</h2>
        <p>Track patch compliance across VMs against defined baselines.</p>
      </div>
      <div class="ops-hero-actions">
        <button class="btn primary" id="btnRefreshPatchBaseline" type="button">Refresh Baseline</button>
      </div>
    </section>
    <div class="grid three">
      ${metricCard("Non-Compliant VMs", nonCompliant, "Below 80% compliance", nonCompliant > 0 ? "critical" : "active")}
      ${metricCard("Missing Critical", missingCritical, "Required patches not installed", missingCritical > 0 ? "warning" : "active")}
      ${metricCard("Missing Patches", missing.length, "Total missing across estate", missing.length > 0 ? "warning" : "active")}
    </div>
    <div class="card">
      <div class="card-header"><h3>Compliance Scorecard</h3><span>${compliance.length} target(s)</span></div>
      <div id="vmPatchComplianceTable"></div>
    </div>
    <div class="grid two">
      <div class="card">
        <div class="card-header"><h3>Missing Patches</h3><span>${missing.length} missing</span></div>
        <div id="vmPatchMissingTable"></div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Recent Patch Timeline</h3><span>Last 90 days</span></div>
        <div id="vmPatchTimelineTable"></div>
      </div>
    </div>
    ${missing.length === 0 ? '<div class="status-bar">No patch baseline defined. Add required patches to mon.WindowsPatchBaseline and click "Refresh Baseline" to auto-discover.</div>' : ''}
  `;

  renderTable(document.getElementById("vmPatchComplianceTable"), compliance, {
    columns: ["DisplayName", "TotalRequiredPatches", "InstalledPatches", "MissingCriticalPatches", "ComplianceScore", "ComplianceStatus"],
    badges: { ComplianceStatus: (v) => v === 'Compliant' ? 'active' : v === 'Partial' ? 'warning' : 'critical' }
  });

  renderTable(document.getElementById("vmPatchMissingTable"), missing, {
    columns: ["DisplayName", "HotFixID", "Severity", "IsRequired", "Category"],
    badges: { IsRequired: (v) => v === true || v === 1 ? 'critical' : '', Severity: (v) => v === 'Critical' ? 'critical' : v === 'Important' ? 'warning' : '' }
  });

  renderTable(document.getElementById("vmPatchTimelineTable"), timeline, {
    columns: ["DisplayName", "HotFixID", "InstalledOn"]
  });

  document.getElementById("btnRefreshPatchBaseline")?.addEventListener("click", async () => {
    showStatus("Refreshing patch baseline...");
    try {
      await apiPost("/api/windows/refresh-patch-baseline", {});
      showStatus("Patch baseline refreshed.");
      await renderWindowsPatching();
    } catch (err) {
      showError(err.message);
    }
  });
}

function renderWindowsTiles(container, rows) {
  rows = normalizeRows(rows);
  if (!container) return;
  if (!rows.length) {
    container.innerHTML = `<div class="details">No Windows VM samples have been collected yet. Deploy the Windows VM collector job from Deployment Center.</div>`;
    return;
  }
  container.innerHTML = rows.map((row) => {
    const tone = serverStatusTone(row.HealthPosture);
    return `
      <div class="server-tile ${tone}">
        <span class="server-status-dot"></span>
        <span class="server-name">${escapeHtml(row.DisplayName || row.ComputerName)}</span>
        <span class="server-status">${escapeHtml(row.HealthPosture || "Unknown")} · ${escapeHtml(row.HealthScore ?? "")}%</span>
        <span class="server-metrics">CPU ${escapeHtml(formatNumber(row.CPUPercent, 1))}% &middot; Memory ${escapeHtml(formatNumber(row.MemoryUsedPercent, 1))}% &middot; Disk ${escapeHtml(formatNumber(row.DiskUsedPercent, 1))}%</span>
      </div>
    `;
  }).join("");
}

function renderServerTiles(container, instances) {
  instances = normalizeRows(instances);
  if (!instances.length) {
    container.innerHTML = `<div class="details">No monitored servers returned.</div>`;
    return;
  }
  container.innerHTML = instances.map((inst) => {
    const tone = serverStatusTone(inst.Status);
    const cpu = formatNumber(inst.SqlCPUPercent, 1);
    const memory = formatNumber(inst.AvailablePhysicalMB, 0);
    const alerts = Number(inst.OpenAlertCount || 0);
    return `
      <button class="server-tile ${tone}" type="button" data-id="${escapeAttr(inst.InstanceID)}">
        <span class="server-status-dot"></span>
        <span class="server-name">${escapeHtml(inst.DisplayName || inst.ServerName || "Server")}</span>
        <span class="server-status">${escapeHtml(inst.Status || "Unknown")}</span>
        <span class="server-metrics">CPU ${escapeHtml(cpu)}% &middot; ${escapeHtml(memory)} MB free &middot; ${alerts} alerts</span>
      </button>
    `;
  }).join("");
  container.querySelectorAll(".server-tile").forEach((tile) => {
    tile.addEventListener("click", () => {
      els.instanceSelect.value = tile.dataset.id;
      setFeature(findFeature("health"));
    });
  });
}

function calculateInstancePosture(instances) {
  const rows = normalizeRows(instances);
  const counts = { healthy: 0, warning: 0, critical: 0, unknown: 0 };
  rows.forEach((inst) => {
    const tone = serverStatusTone(inst.Status);
    if (tone === "healthy") counts.healthy++;
    else if (tone === "warning") counts.warning++;
    else if (tone === "critical") counts.critical++;
    else counts.unknown++;
  });
  const total = rows.length;
  const weighted = total ? ((counts.healthy * 1) + (counts.warning * 0.55) + (counts.unknown * 0.25)) / total : 0;
  return {
    ...counts,
    total,
    score: total ? Math.max(0, Math.min(100, Math.round(weighted * 100))) : 0,
  };
}

function sumNumeric(rows, key, fallback = 0) {
  const values = normalizeRows(rows).map((row) => Number(row[key] || 0));
  if (!values.length) return fallback;
  return values.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
}

async function renderModule(feature) {
  const id = selectedInstanceId();
  els.view.innerHTML = `
    <div id="moduleConfiguredChart"></div>
    <div class="card">
      <div class="card-header">
        <h3>${escapeHtml(feature.title)}</h3>
        <div class="toolbar">
          <button class="btn primary" id="reloadModule">Reload</button>
        </div>
      </div>
      <div id="moduleTable"></div>
    </div>
  `;
  document.getElementById("reloadModule").addEventListener("click", () => renderModule(feature));
  const [data, configs] = await Promise.all([
    apiGet(`/api/module/${encodeURIComponent(feature.module)}?instanceId=${id}`),
    getModuleChartConfigs(),
  ]);
  const rows = normalizeRows(data.rows);
  renderConfiguredModuleChart(feature, rows, configs);
  renderTable(document.getElementById("moduleTable"), rows);
}

function getModuleFeatures() {
  return normalizeRows(state.bootstrap?.featureGroups).flatMap((group) => normalizeRows(group.features))
    .filter((feature) => feature.type === "module" && feature.module);
}

async function getModuleChartConfigs(force = false) {
  if (!force && Array.isArray(state.moduleChartConfigs)) return state.moduleChartConfigs;
  try {
    const result = await apiGet("/api/bi-insights/module-visuals");
    state.moduleChartConfigs = normalizeRows(result.rows);
  } catch {
    state.moduleChartConfigs = [];
  }
  return state.moduleChartConfigs;
}

function isTruthy(value) {
  return value === true || value === 1 || value === "1" || String(value).toLowerCase() === "true";
}

function renderConfiguredModuleChart(feature, rows, configs) {
  const host = document.getElementById("moduleConfiguredChart");
  if (!host) return;
  const config = normalizeRows(configs).find((item) => item.ModuleKey === feature.module);
  const chartId = `moduleConfiguredChartCanvas-${feature.module}`;
  destroyChart(chartId);
  if (!config || !isTruthy(config.IsEnabled)) {
    host.innerHTML = `
      <div class="module-chart-placeholder">
        <strong>BI module chart is disabled</strong>
        <span>Enable and design this chart in BI Insights Studio > Module Charts.</span>
      </div>
    `;
    return;
  }
  const fields = Object.keys(rows[0] || {});
  const visual = sanitizeModuleChartVisual(feature.module, {
    title: config.VisualTitle || `${feature.title} Chart`,
    visualType: config.VisualType || "line",
    axisField: config.AxisField || Object.keys(rows[0] || {})[0] || "",
    valueField: config.ValueField || "",
    legendField: config.LegendField || "",
  }, rows, fields, feature);
  host.innerHTML = `
    <div class="card module-chart-card">
      <div class="card-header">
        <h3>${escapeHtml(visual.title)}</h3>
        <span>Controlled by BI Insights Studio</span>
      </div>
      <div id="moduleConfiguredChartHost" class="module-chart-host"></div>
    </div>
  `;
  renderRowsVisual("moduleConfiguredChartHost", chartId, rows, visual);
}

async function renderMemoryAnalysis() {
  const data = await apiGet(`/api/memory-analysis?instanceId=${selectedInstanceId()}`);
  els.view.innerHTML = `
    ${normalizeRows(data.messages).length ? `<div class="status-bar error">${normalizeRows(data.messages).map(escapeHtml).join("<br>")}</div>` : ""}
    <div class="grid two">
      <div class="card"><div class="card-header"><h3>Memory Clerks</h3></div><div id="clerks"></div></div>
      <div class="card"><div class="card-header"><h3>Buffer Pool</h3></div><div id="bufferPool"></div></div>
    </div>
  `;
  renderTable(document.getElementById("clerks"), data.clerks || []);
  renderTable(document.getElementById("bufferPool"), data.bufferPool || []);
}

async function renderHealth() {
  const data = await apiGet(`/api/health?instanceId=${selectedInstanceId()}`);
  const health = data.health || [];
  const counts = {
    Healthy: health.filter((r) => r.HealthStatus === "Healthy").length,
    Warning: health.filter((r) => r.HealthStatus === "Warning").length,
    Critical: health.filter((r) => r.HealthStatus === "Critical").length,
    Never: health.filter((r) => r.HealthStatus === "Never Run").length,
  };
  els.view.innerHTML = `
    <div class="grid four">
      ${metricCard("Healthy", counts.Healthy, "Collector modules", "active")}
      ${metricCard("Warning", counts.Warning, "Needs review", "warning")}
      ${metricCard("Critical", counts.Critical, "Late or failed", "critical")}
      ${metricCard("Never Run", counts.Never, "No collection found")}
    </div>
    <div class="grid two">
      <div class="card"><div class="card-header"><h3>Collection Health</h3></div><div id="healthTable"></div></div>
      <div class="card"><div class="card-header"><h3>Collection Issues</h3></div><div id="gapsTable"></div></div>
    </div>
  `;
  renderTable(document.getElementById("healthTable"), health, { badges: { HealthStatus: statusClass } });
  renderTable(document.getElementById("gapsTable"), data.gaps || [], { badges: { Severity: severityClass } });
}

async function renderOpenAlerts() {
  const data = await apiGet(`/api/alerts/open?instanceId=${selectedInstanceId()}`);
  els.view.innerHTML = `
    <div class="card">
      <div class="card-header">
        <h3>Open Alerts</h3>
        <button class="btn good" id="ackSelected">Acknowledge Selected</button>
      </div>
      <div id="openAlerts"></div>
    </div>
    <div id="alertDetails" class="details hidden"></div>
  `;
  renderTable(document.getElementById("openAlerts"), data.rows || [], {
    selectable: true,
    idField: "AlertID",
    key: "openAlerts",
    columns: ["Severity", "DisplayName", "ModuleName", "AlertTitle", "RepeatCount", "AgeMinutes", "LastRepeatedAt"],
    labels: {
      DisplayName: "Instance",
      AlertTitle: "Alert",
      RepeatCount: "Repeats",
      AgeMinutes: "Age Min",
      LastRepeatedAt: "Last Seen",
    },
    badges: { Severity: severityClass },
    onSelect: (row) => showAlertDetails(row),
  });
  document.getElementById("ackSelected").addEventListener("click", async () => {
    const row = state.selectedRows.openAlerts;
    if (!row) return showError("Select an alert first.");
    await apiPost("/api/alerts/ack", { AlertID: row.AlertID });
    await renderOpenAlerts();
  });
}

async function renderAlertHistory() {
  els.view.innerHTML = `
    <div class="card">
      <div class="toolbar">
        <label class="select-label">Severity<select id="historySeverity"><option>All</option><option>Critical</option><option>Warning</option><option>Info</option></select></label>
        <label class="field inline"><input id="showAck" type="checkbox" checked> Show acknowledged</label>
        <button class="btn primary" id="loadHistory">Load History</button>
        <button class="btn good" id="ackHistory">Acknowledge Selected</button>
        <button class="btn" id="bulkAck">Bulk Acknowledge</button>
        <button class="btn danger" id="clearOld">Clear Older Than 90 Days</button>
        <button class="btn" id="exportCsv">Export CSV</button>
      </div>
    </div>
    <div class="card"><div class="card-header"><h3>Alert History</h3><span id="historyStats"></span></div><div id="historyTable"></div></div>
    <div id="alertDetails" class="details hidden"></div>
  `;
  const load = async () => {
    const sev = document.getElementById("historySeverity").value;
    const showAck = document.getElementById("showAck").checked;
    const data = await apiGet(`/api/alerts/history?instanceId=${selectedInstanceId()}&severity=${encodeURIComponent(sev)}&showAcknowledged=${showAck}`);
    const stats = data.stats || {};
    document.getElementById("historyStats").textContent = `${stats.TotalAlerts ?? 0} last 7 days, ${stats.UnacknowledgedCount ?? 0} unacknowledged`;
    renderTable(document.getElementById("historyTable"), data.rows || [], {
      selectable: true,
      idField: "AlertID",
      key: "history",
      badges: { Severity: severityClass, IsAcknowledged: ackClass },
      onSelect: (row) => showAlertDetails(row),
    });
  };
  document.getElementById("loadHistory").addEventListener("click", load);
  document.getElementById("ackHistory").addEventListener("click", async () => {
    const row = state.selectedRows.history;
    if (!row) return showError("Select an alert first.");
    await apiPost("/api/alerts/ack", { AlertID: row.AlertID });
    await load();
  });
  document.getElementById("bulkAck").addEventListener("click", async () => {
    if (!confirm("Acknowledge all unacknowledged alerts?")) return;
    await apiPost("/api/alerts/bulk-ack");
    await load();
  });
  document.getElementById("clearOld").addEventListener("click", async () => {
    if (!confirm("Delete alert history older than 90 days?")) return;
    await apiPost("/api/alerts/clear", { OlderThanDays: 90 });
    await load();
  });
  document.getElementById("exportCsv").addEventListener("click", () => exportTableCsv("historyTable", "AlertHistory.csv"));
  await load();
}

async function renderInstances() {
  const data = await apiGet("/api/instances");
  els.view.innerHTML = `
    <div class="card">
      <div class="card-header"><h3>Add or Update Server</h3></div>
      <div class="form-grid">
        ${inputField("Display Name", "instDisplayName")}
        ${inputField("SQL Instance", "instSqlInstance", "SERVER\\INSTANCE")}
        ${inputField("Repository Server", "instRepoServer", state.bootstrap.repository.server)}
        ${inputField("Repository Database", "instRepoDb", state.bootstrap.repository.database)}
        ${inputField("Environment", "instEnv", "Production")}
        <label class="field inline"><input id="instActive" type="checkbox" checked> Active</label>
      </div>
      <div class="toolbar" style="margin-top:12px">
        <button class="btn primary" id="saveInstance">Save Server</button>
        <button class="btn danger" id="deleteInstance">Delete Selected</button>
        <button class="btn" id="importInstances">Import CSV/TXT</button>
        <button class="btn" id="exportInstances">Export Servers</button>
        <input id="instanceImportFile" type="file" accept=".csv,.txt,text/csv,text/plain" hidden>
      </div>
    </div>
    <div class="card"><div class="card-header"><h3>Configured Instances</h3></div><div id="instancesTable"></div></div>
    <div class="card"><div class="card-header"><h3>Repository Instances</h3></div><div id="repoInstancesTable"></div></div>
  `;
  renderTable(document.getElementById("instancesTable"), data.configured || [], {
    selectable: true,
    key: "instances",
    idField: "DisplayName",
    badges: { IsActive: activeClass },
    onSelect: fillInstanceForm,
  });
  renderTable(document.getElementById("repoInstancesTable"), data.repository || [], { badges: { IsActive: activeClass } });
  document.getElementById("saveInstance").addEventListener("click", async () => {
    const payload = {
      DisplayName: valueOf("instDisplayName"),
      SqlInstance: valueOf("instSqlInstance"),
      RepositoryServer: valueOf("instRepoServer"),
      RepositoryDatabase: valueOf("instRepoDb"),
      Environment: valueOf("instEnv"),
      IsActive: document.getElementById("instActive").checked,
    };
    const saved = await apiPost("/api/instances", payload);
    refreshBootstrapInstances(saved);
    await renderInstances();
  });
  document.getElementById("deleteInstance").addEventListener("click", async () => {
    const row = state.selectedRows.instances;
    if (!row) return showError("Select an instance first.");
    if (!confirm(`Delete ${row.DisplayName}?`)) return;
    const deleted = await apiDelete(`/api/instances?displayName=${encodeURIComponent(row.DisplayName)}`);
    refreshBootstrapInstances(deleted);
    await renderInstances();
  });
  document.getElementById("exportInstances").addEventListener("click", () => exportRowsCsv(data.configured || [], "SQLMonitor-Servers.csv"));
  document.getElementById("importInstances").addEventListener("click", () => document.getElementById("instanceImportFile").click());
  document.getElementById("instanceImportFile").addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const rows = parseServerImportText(text);
    if (!rows.length) return showError("No server rows found in the selected file.");
    const result = await apiPost("/api/instances/import", { Rows: rows });
    refreshBootstrapInstances(result);
    showStatus(`Imported ${result.imported || 0}, updated ${result.updated || 0} servers.`);
    await renderInstances();
  });
}

function fillInstanceForm(row) {
  setValue("instDisplayName", row.DisplayName);
  setValue("instSqlInstance", row.SqlInstance);
  setValue("instRepoServer", row.RepositoryServer || state.bootstrap.repository.server);
  setValue("instRepoDb", row.RepositoryDatabase || state.bootstrap.repository.database);
  setValue("instEnv", row.Environment || "Production");
  document.getElementById("instActive").checked = Boolean(row.IsActive);
}

async function renderNotifications() {
  const config = await apiGet("/api/notifications");
  els.view.innerHTML = `
    <div class="card">
      <div class="card-header"><h3>Email and Teams Notifications</h3></div>
      <div class="form-grid">
        ${inputField("SMTP Server", "smtpServer", config.SMTP?.Server || "")}
        ${inputField("SMTP Port", "smtpPort", config.SMTP?.Port || 587)}
        ${inputField("From", "smtpFrom", config.SMTP?.From || "")}
        ${inputField("Username", "smtpUser", config.SMTP?.Username || "")}
        ${inputField("Password", "smtpPass", config.SMTP?.Password || "", "password")}
        ${inputField("Recipients", "notifRecipients", config.Notifications?.Recipients || "")}
        ${inputField("Minimum Severity", "notifSeverity", config.Notifications?.MinSeverity || "Warning")}
        ${inputField("Throttle Minutes", "notifThrottle", config.Notifications?.ThrottleMinutes || 30)}
        ${inputField("Dashboard URL", "notifUrl", config.Notifications?.DashboardURL || "")}
        ${inputField("Teams Webhook", "teamsWebhook", config.Teams?.WebhookURL || "")}
        <label class="field inline"><input id="notifEnabled" type="checkbox" ${config.Notifications?.Enabled ? "checked" : ""}> Email enabled</label>
        <label class="field inline"><input id="teamsEnabled" type="checkbox" ${config.Teams?.Enabled ? "checked" : ""}> Teams enabled</label>
        <label class="field inline"><input id="smtpSsl" type="checkbox" ${config.SMTP?.EnableSSL ? "checked" : ""}> Enable SSL</label>
        <label class="field inline"><input id="smtpDefaultCreds" type="checkbox" ${config.SMTP?.UseDefaultCredentials ? "checked" : ""}> Default credentials</label>
      </div>
      <div class="toolbar" style="margin-top:12px">
        <button class="btn primary" id="saveNotifications">Save Notifications</button>
        <button class="btn" id="testEmail">Send Test Email</button>
        <button class="btn" id="testTeams">Send Test Teams Message</button>
      </div>
    </div>
  `;
  document.getElementById("saveNotifications").addEventListener("click", async () => {
    const payload = {
      SMTP: {
        Server: valueOf("smtpServer"),
        Port: Number(valueOf("smtpPort") || 25),
        From: valueOf("smtpFrom"),
        Username: valueOf("smtpUser"),
        Password: valueOf("smtpPass"),
        EnableSSL: checked("smtpSsl"),
        UseDefaultCredentials: checked("smtpDefaultCreds"),
      },
      Notifications: {
        Enabled: checked("notifEnabled"),
        Recipients: valueOf("notifRecipients"),
        CCRecipients: [],
        MinSeverity: valueOf("notifSeverity"),
        ThrottleMinutes: Number(valueOf("notifThrottle") || 30),
        IncludeDashboardLink: true,
        DashboardURL: valueOf("notifUrl"),
        QuietHours: { Enabled: false, Start: "22:00", End: "07:00" },
      },
      Teams: { Enabled: checked("teamsEnabled"), WebhookURL: valueOf("teamsWebhook") },
    };
    await apiPost("/api/notifications", payload);
    showStatus("Notification configuration saved.");
  });
  document.getElementById("testEmail").addEventListener("click", async () => {
    const result = await apiPost("/api/notifications/test-email");
    showStatus(result.message || "Test email sent.");
  });
  document.getElementById("testTeams").addEventListener("click", async () => {
    const result = await apiPost("/api/notifications/test-teams");
    showStatus(result.message || "Test Teams message sent.");
  });
}

async function renderThresholds() {
  const data = await apiGet("/api/thresholds");
  els.view.innerHTML = `
    <div class="card">
      <div class="card-header"><h3>Alert Thresholds</h3></div>
      <div id="thresholdTable"></div>
    </div>
    <div class="card">
      <div class="card-header"><h3>Edit Selected Threshold</h3></div>
      <div class="form-grid">
        ${inputField("Threshold ID", "thrId", "", "number", true)}
        ${inputField("Module", "thrModule", "", "text", true)}
        ${inputField("Metric", "thrMetric", "", "text", true)}
        ${inputField("Warning", "thrWarning")}
        ${inputField("Critical", "thrCritical")}
        ${inputField("Comparison", "thrComparison")}
        ${inputField("Cooldown Minutes", "thrCooldown")}
        <label class="field inline"><input id="thrActive" type="checkbox" checked> Active</label>
      </div>
      <div class="toolbar" style="margin-top:12px">
        <button class="btn primary" id="saveThreshold">Save Threshold</button>
        <button class="btn" id="runAlertEngine">Run Alert Engine Now</button>
      </div>
    </div>
  `;
  renderTable(document.getElementById("thresholdTable"), data.rows || [], {
    selectable: true,
    key: "thresholds",
    idField: "ThresholdID",
    badges: { IsActive: activeClass },
    onSelect: fillThresholdForm,
  });
  document.getElementById("saveThreshold").addEventListener("click", async () => {
    await apiPost("/api/thresholds", {
      ThresholdID: Number(valueOf("thrId")),
      WarningValue: Number(valueOf("thrWarning")),
      CriticalValue: Number(valueOf("thrCritical")),
      ComparisonType: valueOf("thrComparison"),
      CooldownMinutes: Number(valueOf("thrCooldown")),
      IsActive: checked("thrActive"),
    });
    await renderThresholds();
  });
  document.getElementById("runAlertEngine").addEventListener("click", async () => showProcessResult(await apiPost("/api/run-alert-engine")));
}

function fillThresholdForm(row) {
  setValue("thrId", row.ThresholdID);
  setValue("thrModule", row.ModuleName);
  setValue("thrMetric", row.MetricName);
  setValue("thrWarning", row.WarningValue);
  setValue("thrCritical", row.CriticalValue);
  setValue("thrComparison", row.ComparisonType);
  setValue("thrCooldown", row.CooldownMinutes);
  document.getElementById("thrActive").checked = Boolean(row.IsActive);
}

async function renderAnalytics() {
  els.view.innerHTML = `
    <div class="card"><div class="toolbar">
      <label class="select-label">Range<select id="analyticsRange"><option>Last Hour</option><option>Last 6 Hours</option><option selected>Last 24 Hours</option><option>Last 7 Days</option><option>Last 30 Days</option></select></label>
      <button class="btn primary" id="loadAnalytics">Load Analytics</button>
    </div></div>
    <div id="analyticsBody"></div>
  `;
  const load = async () => {
    const range = document.getElementById("analyticsRange").value;
    const data = await apiGet(`/api/analytics?instanceId=${selectedInstanceId()}&range=${encodeURIComponent(range)}`, { timeoutMs: 45000 });
    const cpu = data.cpu || {};
    const mem = data.memory || {};
    const alerts = data.alerts || {};
    document.getElementById("analyticsBody").innerHTML = `
      ${data.repositoryError ? `<div class="status-bar error">Analytics repository warning: ${escapeHtml(data.repositoryError)}</div>` : ""}
      <div class="grid four">
        ${metricCard("Avg CPU", formatNumber(cpu.AvgCPU, 1) + "%", "Peak " + formatNumber(cpu.PeakCPU, 1) + "%")}
        ${metricCard("Min Memory", formatNumber(mem.MinMemory, 0) + " MB", "Average " + formatNumber(mem.AvgMemory, 0) + " MB")}
        ${metricCard("Alerts", alerts.AlertCount ?? 0, range)}
        ${metricCard("Samples", cpu.SampleCount ?? 0, "CPU samples")}
      </div>
      <div class="grid two">
        <div class="card"><div class="card-header"><h3>CPU Trend</h3></div><div class="chart-box"><canvas id="analyticsCpu"></canvas></div></div>
        <div class="card"><div class="card-header"><h3>Memory Trend</h3></div><div class="chart-box"><canvas id="analyticsMem"></canvas></div></div>
      </div>
      <div class="grid three">
        <div class="card"><div class="card-header"><h3>Top Queries</h3></div><div class="chart-box"><canvas id="analyticsTopQueries"></canvas></div></div>
        <div class="card"><div class="card-header"><h3>Jobs</h3></div><div class="chart-box"><canvas id="analyticsJobs"></canvas></div></div>
        <div class="card"><div class="card-header"><h3>Disks</h3></div><div class="chart-box"><canvas id="analyticsDisks"></canvas></div></div>
      </div>
      <div class="grid three">
        <div class="card"><div class="card-header"><h3>Deadlocks</h3></div><div class="chart-box"><canvas id="analyticsDeadlocks"></canvas></div></div>
        <div class="card"><div class="card-header"><h3>Blocking</h3></div><div class="chart-box"><canvas id="analyticsBlocking"></canvas></div></div>
        <div class="card"><div class="card-header"><h3>Active Users</h3></div><div class="chart-box"><canvas id="analyticsUsers"></canvas></div></div>
      </div>
      <div class="card"><div class="card-header"><h3>Top Issues</h3></div><div id="analyticsIssues"></div></div>
    `;
    drawLineChart("analyticsCpu", data.trends?.cpu || [], "CaptureTime", "SqlCPUPercent", "SQL CPU %", "#0969da");
    drawLineChart("analyticsMem", data.trends?.memory || [], "CaptureTime", "AvailablePhysicalMB", "Available MB", "#198754");
    drawLineChart("analyticsTopQueries", data.trends?.topQueries || [], "CaptureTime", "SqlCPUPercent", "Top Queries CPU %", "#d73a49");
    drawLineChart("analyticsJobs", data.trends?.jobs || [], "CaptureTime", "SuccessCount", "Job Successes", "#6f42c1");
    // Show disk utilization percentage as a bar chart
    drawBarChart("analyticsDisks", data.trends?.disks || [], "CaptureTime", "UsedPct", "Disk Used %", "#28a745");
    drawLineChart("analyticsDeadlocks", data.trends?.deadlocks || [], "CaptureTime", "DeadlockCount", "Deadlocks", "#cb2431");
    drawLineChart("analyticsBlocking", data.trends?.blocking || [], "CaptureTime", "BlockingCount", "Blocking Sessions", "#e36209");
    drawLineChart("analyticsUsers", data.trends?.users || [], "CaptureTime", "ActiveUserCount", "Active Users", "#0366d6");
    renderTable(document.getElementById("analyticsIssues"), data.topIssues || []);
  };
  document.getElementById("loadAnalytics").addEventListener("click", load);
  await load();
}

async function renderIncidentFlightRecorder() {
  const id = selectedInstanceId();
  const inst = selectedInstance();
  if (!id) {
    els.view.innerHTML = `<div class="card"><div class="card-header"><h3>Incident Flight Recorder</h3></div><p>Select an instance to reconstruct an incident timeline.</p></div>`;
    return;
  }
  const currentHours = document.getElementById("flightHours")?.value || "24";
  els.view.innerHTML = `
    <div class="card flight-hero">
      <div>
        <p class="eyebrow">Incident Flight Recorder</p>
        <h3>${escapeHtml(inst?.DisplayName || "Selected instance")}</h3>
        <p>Correlates alerts, telemetry, tickets, jobs, blocking, and collection health into one incident story.</p>
      </div>
      <div class="toolbar">
        <label class="select-label">Window<select id="flightHours"><option value="6">Last 6 Hours</option><option value="24" selected>Last 24 Hours</option><option value="72">Last 3 Days</option><option value="168">Last 7 Days</option></select></label>
        <button class="btn primary" id="runFlightRecorder">Reconstruct</button>
      </div>
    </div>
    <div id="flightBody" class="flight-shell">
      <div class="card"><div class="details">Ready to reconstruct the incident story.</div></div>
    </div>
  `;
  setValue("flightHours", currentHours);
  const load = async () => {
    const hours = valueOf("flightHours") || "24";
    const data = await apiGet(`/api/incident-flight-recorder?instanceId=${id}&hours=${encodeURIComponent(hours)}`, { timeoutMs: 60000 });
    renderFlightRecorderPayload(data);
  };
  document.getElementById("runFlightRecorder").addEventListener("click", load);
  await load();
}

function renderFlightRecorderPayload(data) {
  const summary = data.summary || {};
  const signals = normalizeRows(data.signals);
  const timeline = normalizeRows(data.timeline);
  const recommendations = normalizeRows(data.recommendations);
  const blast = data.blastRadius || {};
  const evidence = data.evidence || {};
  const risk = Number(summary.RiskScore || 0);
  const tone = risk >= 70 ? "critical" : risk >= 35 ? "warning" : "active";
  const body = document.getElementById("flightBody");
  if (!body) return;
  body.innerHTML = `
    <div class="grid four">
      ${metricCard("Risk Score", `${risk}%`, summary.Posture || "Unknown", tone)}
      ${metricCard("Likely Cause", summary.LikelyCause || "Unknown", "Highest weighted signal")}
      ${metricCard("Critical Alerts", summary.CriticalAlerts || 0, `${summary.WarningAlerts || 0} warning alerts`, Number(summary.CriticalAlerts || 0) ? "critical" : "active")}
      ${metricCard("Timeline Events", summary.TimelineEvents || timeline.length, `${summary.Tickets || 0} related tickets`)}
    </div>
    <div class="flight-layout">
      <section class="card flight-story-card">
        <div class="card-header"><h3>Incident Storyline</h3><span>${escapeHtml(data.windowHours || "")} hour window</span></div>
        <div class="flight-cause">
          <div class="flight-ring ${tone}" style="--score:${Math.max(0, Math.min(100, risk))}%"><strong>${risk}</strong><span>risk</span></div>
          <div>
            <h4>${escapeHtml(summary.LikelyCause || "No dominant cause")}</h4>
            <p>${escapeHtml(buildFlightNarrative(summary, signals))}</p>
          </div>
        </div>
        <div id="flightTimeline" class="flight-timeline"></div>
      </section>
      <aside class="flight-side">
        <div class="card">
          <div class="card-header"><h3>Cause Signals</h3></div>
          <div class="flight-signals">${signals.map(renderFlightSignal).join("") || `<div class="details">No risk signals detected.</div>`}</div>
        </div>
        <div class="card">
          <div class="card-header"><h3>Next Actions</h3></div>
          <ol class="flight-actions">${recommendations.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ol>
        </div>
      </aside>
    </div>
    <div class="grid two">
      <div class="card"><div class="card-header"><h3>Blast Radius</h3><span>${escapeHtml(blast.Instance || "")}</span></div><div id="flightBlastModules"></div></div>
      <div class="card"><div class="card-header"><h3>Affected Databases</h3><span>From blocking evidence</span></div><div id="flightBlastDatabases"></div></div>
    </div>
    <div class="tabs flight-tabs" role="tablist">
      <button class="tab active" data-flight-tab="alerts" type="button">Alerts</button>
      <button class="tab" data-flight-tab="blocking" type="button">Blocking</button>
      <button class="tab" data-flight-tab="jobs" type="button">Jobs</button>
      <button class="tab" data-flight-tab="tickets" type="button">Tickets</button>
      <button class="tab" data-flight-tab="health" type="button">Collector Health</button>
      <button class="tab" data-flight-tab="telemetry" type="button">Telemetry</button>
    </div>
    <section class="card"><div id="flightEvidence"></div></section>
  `;
  renderFlightTimeline(timeline);
  renderTable(document.getElementById("flightBlastModules"), normalizeRows(blast.AlertModules), { key: "flightBlastModules", pagination: false });
  renderTable(document.getElementById("flightBlastDatabases"), normalizeRows(blast.AffectedDatabases), { key: "flightBlastDatabases", pagination: false });
  const showEvidence = (name) => {
    document.querySelectorAll(".flight-tabs .tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.flightTab === name));
    const rows = name === "telemetry"
      ? normalizeRows(evidence.cpu).map((row) => ({ ...row, Source: "CPU" })).concat(normalizeRows(evidence.memory).map((row) => ({ ...row, Source: "Memory" })), normalizeRows(evidence.disk).map((row) => ({ ...row, Source: "Disk" })))
      : normalizeRows(evidence[name]);
    renderTable(document.getElementById("flightEvidence"), rows, { key: `flightEvidence-${name}`, badges: { Severity: severityClass, HealthStatus: statusClass, TicketSeverity: severityClass } });
  };
  document.querySelectorAll(".flight-tabs .tab").forEach((tab) => tab.addEventListener("click", () => showEvidence(tab.dataset.flightTab)));
  showEvidence("alerts");
}

function renderFlightSignal(signal) {
  return `
    <article class="flight-signal ${severityClass(signal.Severity || "")}">
      <div><strong>${escapeHtml(signal.Signal || "")}</strong><span>${escapeHtml(signal.Evidence || "")}</span></div>
      <b>${escapeHtml(signal.Score || 0)}</b>
    </article>
  `;
}

function renderFlightTimeline(rows) {
  const host = document.getElementById("flightTimeline");
  if (!host) return;
  host.innerHTML = normalizeRows(rows).map((row) => `
    <article class="flight-event ${severityClass(row.Severity || "")}">
      <time>${escapeHtml(row.EventTime || "")}</time>
      <div><strong>${escapeHtml(row.Title || "")}</strong><span>${escapeHtml(row.EventType || "")} · ${escapeHtml(row.Details || "")}</span></div>
    </article>
  `).join("") || `<div class="details">No timeline events were found in this window.</div>`;
}

function buildFlightNarrative(summary, signals) {
  const top = normalizeRows(signals).slice().sort((a, b) => Number(b.Score || 0) - Number(a.Score || 0)).slice(0, 3);
  if (!top.length) return "The selected window does not show a strong incident signature. Widen the window or continue monitoring.";
  return `The recorder weighted ${top.map((item) => item.Signal).join(", ")} as the strongest evidence. Use the timeline to validate order of events before taking action.`;
}

async function renderBiInsights() {
  const catalog = await apiGet("/api/bi-insights/catalog");
  const datasets = normalizeRows(catalog.datasets);
  const reports = normalizeRows(catalog.reports);
  const dataSources = normalizeRows(catalog.dataSources);
  const fields = normalizeRows(catalog.fields);
  const relationships = normalizeRows(catalog.relationships);
  const measures = normalizeRows(catalog.measures);
  const transformations = normalizeRows(catalog.transformations);
  const visualTypes = normalizeRows(catalog.visualTypes);
  const themes = normalizeRows(catalog.themes);
  const qaPrompts = normalizeRows(catalog.qaPrompts);
  const performance = normalizeRows(catalog.performance);
  const moduleVisuals = normalizeRows(catalog.moduleVisuals);
  state.moduleChartConfigs = moduleVisuals;
  let biDataCache = null;
  if (!state.biBuilderVisuals.length) {
    state.biBuilderVisuals = [
      { id: "bi-v1", title: "Open Alerts by Server", datasetKey: "server-scorecard", visualType: "clustered-column", axisField: "DisplayName", valueField: "OpenAlerts", legendField: "HealthPosture" },
      { id: "bi-v2", title: "Alert Trend by Severity", datasetKey: "alert-trends", visualType: "stacked-column", axisField: "AlertDate", valueField: "AlertCount", legendField: "Severity" },
      { id: "bi-v3", title: "Ticket Severity", datasetKey: "ticket-severity", visualType: "column", axisField: "TicketSeverity", valueField: "TicketCount", legendField: "" },
      { id: "bi-v4", title: "Task Priority", datasetKey: "task-priority", visualType: "column", axisField: "TaskPriority", valueField: "TaskCount", legendField: "" },
      { id: "bi-v5", title: "VM Health Score", datasetKey: "vm-scorecard", visualType: "clustered-column", axisField: "DisplayName", valueField: "HealthScore", legendField: "HealthPosture" },
      { id: "bi-v6", title: "VM Ticket SLA", datasetKey: "vm-ticket-sla", visualType: "stacked-bar", axisField: "Subcategory", valueField: "TicketCount", legendField: "SLAStatus" },
    ];
    state.biSelectedVisualId = "bi-v1";
  }
  const defaultBiDatasets = new Set(["server-scorecard", "health-posture", "alert-trends", "ticket-severity", "task-priority", "application-scorecard", "vm-scorecard", "vm-alert-trends", "vm-ticket-sla", "vm-capacity"]);
  const datasetChecks = datasets.map((dataset) => `
    <label class="field inline">
      <input class="bi-dataset-check" type="checkbox" value="${escapeAttr(dataset.DatasetKey)}" ${defaultBiDatasets.has(dataset.DatasetKey) ? "checked" : ""}>
      ${escapeHtml(dataset.DisplayName)} <span class="muted">${escapeHtml(dataset.DefaultVisual || "")}</span>
    </label>
  `).join("");
  const visualOptions = visualTypes.map((visual) => `<option value="${escapeAttr(visual.VisualTypeKey)}">${escapeHtml(visual.DisplayName)}</option>`).join("");
  const themeOptions = themes.map((theme) => `<option value="${escapeAttr(theme.ThemeID)}">${escapeHtml(theme.ThemeName)}${theme.IsDefault ? " (default)" : ""}</option>`).join("");
  els.view.innerHTML = `
    <div class="card">
      <div class="card-header"><h3>BI Insights Studio</h3><span>PowerBI-style operational analytics from SQL Monitor repository data.</span></div>
      <div class="toolbar">
        <label class="select-label">Range<select id="biRange"><option>Last 24 Hours</option><option selected>Last 7 Days</option><option>Last 30 Days</option><option>Last 90 Days</option></select></label>
        <button class="btn primary" id="loadBiInsights">Refresh</button>
        <button class="btn" id="newBiReport">New Report</button>
        <button class="btn" id="saveBiReport">Save Report</button>
        <button class="btn danger" id="deleteBiReport">Delete Saved Report</button>
        <button class="btn" id="exportBiScorecard">Export Scorecard</button>
        <button class="btn" id="exportBiAlerts">Export Noisy Alerts</button>
        <label class="select-label">Management Period<select id="biManagementPeriod"><option>Daily</option><option selected>Weekly</option><option>Monthly</option><option>Yearly</option></select></label>
        <button class="btn primary" id="exportBiManagementExcel">Export Management Excel</button>
      </div>
    </div>
    <div class="tabs bi-tabs" role="tablist" aria-label="BI Insights workspace">
      <button class="tab active" id="biReportTab" type="button">Report Canvas</button>
      <button class="tab" id="biBuilderTab" type="button">Report Builder</button>
      <button class="tab" id="biModuleChartsTab" type="button">Module Charts</button>
      <button class="tab" id="biDatasetsTab" type="button">Dataset Catalog</button>
      <button class="tab" id="biModelTab" type="button">Model</button>
      <button class="tab" id="biQueryTab" type="button">Power Query</button>
      <button class="tab" id="biVisualsTab" type="button">Visualizations</button>
      <button class="tab" id="biAskTab" type="button">Q&amp;A</button>
      <button class="tab" id="biPerformanceTab" type="button">Performance</button>
      <button class="tab" id="biSavedTab" type="button">Saved Reports</button>
    </div>
    <section id="biReportPanel" class="wiki-tab-panel active"><div id="biInsightsBody"></div></section>
    <section id="biBuilderPanel" class="wiki-tab-panel" hidden>
      <div class="card bi-builder-head">
        <div class="card-header"><h3>Report Builder</h3><span>Build visuals from repository datasets and arrange them on the report canvas.</span></div>
        <div class="form-grid">
          ${inputField("Report Name", "biReportName", "SQL Monitor Executive Overview")}
          ${inputField("Description", "biReportDescription", "Operational health, alert noise, and capacity insights.")}
          <label class="field">Theme<select id="biTheme">${themeOptions || "<option>SQL Monitor Default</option>"}</select></label>
          <label class="field inline"><input id="biReportShared" type="checkbox" checked> Shared report</label>
        </div>
      </div>
      <div class="bi-builder-shell">
        <div class="bi-builder-canvas">
          <div class="bi-builder-ribbon">
            <button class="btn primary" id="addBiVisual" type="button">New Visual</button>
            <button class="btn" id="updateBiVisual" type="button">Update Visual</button>
            <button class="btn danger" id="removeBiVisual" type="button">Remove Visual</button>
            <button class="btn" id="renderBiBuilder" type="button">Render</button>
          </div>
          <div id="biBuilderCanvas" class="bi-report-canvas"></div>
        </div>
        <aside class="bi-builder-pane">
          <div class="bi-pane-card">
            <div class="bi-pane-title"><strong>Visualizations</strong><span>Build visual</span></div>
            <div id="biVisualGallery" class="bi-visual-gallery"></div>
          </div>
          <div class="bi-pane-card">
            <div class="bi-pane-title"><strong>Fields</strong><span>Data wells</span></div>
            <label class="field">Dataset<select id="biBuildDataset"></select></label>
            <label class="field">Title<input id="biBuildTitle" placeholder="Visual title"></label>
            <label class="field">Axis / Category<select id="biBuildAxis"></select></label>
            <label class="field">Values<select id="biBuildValue"></select></label>
            <label class="field">Legend / Series<select id="biBuildLegend"></select></label>
            <div class="bi-field-hints" id="biFieldHints"></div>
          </div>
          <div class="bi-pane-card">
            <div class="bi-pane-title"><strong>Canvas Visuals</strong><span>${escapeHtml(state.biBuilderVisuals.length)} visual${state.biBuilderVisuals.length === 1 ? "" : "s"}</span></div>
            <div id="biVisualList" class="bi-visual-list"></div>
          </div>
        </div>
      </div>
    </section>
    <section id="biModuleChartsPanel" class="wiki-tab-panel" hidden>
      <div class="bi-workbench-grid">
        <div class="card bi-workbench-main">
          <div class="card-header"><h3>Module Charts</h3><span>Publish one governed chart into each SQL Monitor module page.</span></div>
          <div class="form-grid">
            <label class="field">Module<select id="biModuleChartModule"></select></label>
            <label class="field">Chart Title<input id="biModuleChartTitle" placeholder="Chart title"></label>
            <label class="field">Visual Type<select id="biModuleChartType"></select></label>
            <label class="field inline"><input id="biModuleChartEnabled" type="checkbox"> Enabled on module page</label>
          </div>
          <div class="form-grid">
            <label class="field">Axis / Category<select id="biModuleChartAxis"></select></label>
            <label class="field">Values<select id="biModuleChartValue"></select></label>
            <label class="field">Legend / Series<select id="biModuleChartLegend"></select></label>
            <div class="field module-chart-actions">
              <span>&nbsp;</span>
              <button class="btn" id="autoConfigureBiModuleChart" type="button">Auto Configure</button>
              <button class="btn primary" id="saveBiModuleChart" type="button">Save Module Chart</button>
            </div>
          </div>
          <div id="biModuleChartPreview" class="bi-module-preview"></div>
        </div>
        <aside class="bi-workbench-side">
          <div class="card"><div class="card-header"><h3>Published Charts</h3><span>Enabled state by module.</span></div><div id="biModuleChartCards" class="bi-mini-list"></div></div>
          <div class="card"><div class="card-header"><h3>Fields</h3><span>Live sample from selected module.</span></div><div id="biModuleChartFields" class="bi-field-hints"></div></div>
        </aside>
      </div>
    </section>
    <section id="biDatasetsPanel" class="wiki-tab-panel" hidden>
      <div class="bi-workbench-grid">
        <div class="card bi-workbench-main">
          <div class="card-header"><h3>Dataset Catalog</h3><span>Discover datasets and push them directly into Report Builder.</span></div>
          <div class="toolbar">
            <input id="biDatasetSearch" type="text" placeholder="Search datasets, categories, query names">
            <label class="select-label">Category<select id="biDatasetCategory"></select></label>
          </div>
          <div id="biDatasetCards" class="bi-action-grid"></div>
        </div>
        <aside class="bi-workbench-side">
          <div class="card"><div class="card-header"><h3>Catalog Health</h3></div><div id="biDatasetSummary" class="bi-summary-list"></div></div>
          <div class="card"><div class="card-header"><h3>Data Sources</h3><span>Available connector scope.</span></div><div id="biDataSourceCards" class="bi-mini-list"></div></div>
        </aside>
      </div>
    </section>
    <section id="biModelPanel" class="wiki-tab-panel" hidden>
      <div class="bi-workbench-grid">
        <div class="card bi-workbench-main">
          <div class="card-header"><h3>Semantic Model</h3><span>Review fields, measures, and relationships before building visuals.</span></div>
          <div id="biModelSummary" class="grid four"></div>
          <div class="grid two">
            <div><h4 class="bi-subtitle">Field Explorer</h4><div id="biFieldExplorer" class="bi-field-tree"></div></div>
            <div><h4 class="bi-subtitle">Measures</h4><div id="biMeasureCards" class="bi-mini-list"></div></div>
          </div>
        </div>
        <aside class="bi-workbench-side">
          <div class="card"><div class="card-header"><h3>Relationships</h3><span>Filter paths used by visuals.</span></div><div id="biRelationshipMap" class="bi-relationship-map"></div></div>
          <div class="card"><div class="card-header"><h3>Model Actions</h3></div><div class="bi-action-stack">
            <button class="btn" id="biAddScorecardModel">Build Scorecard Visual</button>
            <button class="btn" id="biAddTrendModel">Build Alert Trend Visual</button>
          </div></div>
        </aside>
      </div>
    </section>
    <section id="biQueryPanel" class="wiki-tab-panel" hidden>
      <div class="bi-workbench-grid">
        <div class="card bi-workbench-main">
          <div class="card-header"><h3>Power Query</h3><span>Inspect transformation pipelines and preview transformed rows.</span></div>
          <label class="select-label">Dataset<select id="biQueryDataset"></select></label>
          <div id="biTransformationPipeline" class="bi-pipeline"></div>
        </div>
        <aside class="bi-workbench-side">
          <div class="card"><div class="card-header"><h3>Preview</h3><span>Current transformed dataset.</span></div><div id="biQueryPreview"></div></div>
        </aside>
      </div>
    </section>
    <section id="biVisualsPanel" class="wiki-tab-panel" hidden>
      <div class="bi-workbench-grid">
        <div class="card bi-workbench-main">
          <div class="card-header"><h3>Visualizations</h3><span>Choose a visual type and add it to the active report.</span></div>
          <div id="biVisualizationLibrary" class="bi-visual-library"></div>
        </div>
        <aside class="bi-workbench-side">
          <div class="card"><div class="card-header"><h3>Themes</h3><span>Report styling presets.</span></div><div id="biThemeCards" class="bi-mini-list"></div></div>
          <div class="card"><div class="card-header"><h3>Recommended Pairings</h3></div><div id="biVisualRecommendations" class="bi-mini-list"></div></div>
        </aside>
      </div>
    </section>
    <section id="biAskPanel" class="wiki-tab-panel" hidden>
      <div class="card">
        <div class="card-header"><h3>BI Assistant Q&amp;A</h3><span>Natural language questions against curated SQL Monitor semantic datasets.</span></div>
        <div class="toolbar">
          <input id="biQuestion" type="text" placeholder="Ask about critical servers, noisy alerts, capacity, or health score">
          <button class="btn primary" id="askBiQuestion" type="button">Ask</button>
        </div>
        <div id="biAnswer" class="details">Ask a question to get a dataset recommendation and answer template.</div>
      </div>
      <div class="grid two">
        <div class="card"><div class="card-header"><h3>Verified Prompts</h3><span>Click a prompt to ask it.</span></div><div id="biPromptCards" class="bi-action-grid"></div></div>
        <div class="card"><div class="card-header"><h3>Suggested Visual</h3><span>Send the answer dataset to Report Builder.</span></div><div id="biQaVisualSuggestion" class="details">Ask a question to get a visual recommendation.</div></div>
      </div>
    </section>
    <section id="biPerformancePanel" class="wiki-tab-panel" hidden>
      <div class="bi-workbench-grid">
        <div class="card bi-workbench-main">
          <div class="card-header"><h3>Performance Analyzer</h3><span>Recent query cost, row volume, and slow dataset signals.</span></div>
          <div id="biPerformanceSummary" class="grid four"></div>
          <div id="biPerformanceTable"></div>
        </div>
        <aside class="bi-workbench-side">
          <div class="card"><div class="card-header"><h3>Bottlenecks</h3></div><div id="biPerformanceFindings" class="bi-mini-list"></div></div>
        </aside>
      </div>
    </section>
    <section id="biSavedPanel" class="wiki-tab-panel" hidden>
      <div class="card">
        <div class="card-header"><h3>Saved Reports</h3><span>Open, reuse, or govern shared report definitions stored in SQL.</span></div>
        <div id="biSavedReportCards" class="bi-action-grid"></div>
        <div id="biReportsTable" class="hidden"></div>
      </div>
    </section>
  `;
  const setBiTab = (name) => {
    const tabs = {
      report: ["biReportTab", "biReportPanel"],
      builder: ["biBuilderTab", "biBuilderPanel"],
      moduleCharts: ["biModuleChartsTab", "biModuleChartsPanel"],
      datasets: ["biDatasetsTab", "biDatasetsPanel"],
      model: ["biModelTab", "biModelPanel"],
      query: ["biQueryTab", "biQueryPanel"],
      visuals: ["biVisualsTab", "biVisualsPanel"],
      ask: ["biAskTab", "biAskPanel"],
      performance: ["biPerformanceTab", "biPerformancePanel"],
      saved: ["biSavedTab", "biSavedPanel"],
    };
    Object.entries(tabs).forEach(([key, ids]) => {
      const active = key === name;
      document.getElementById(ids[0]).classList.toggle("active", active);
      document.getElementById(ids[1]).hidden = !active;
      document.getElementById(ids[1]).classList.toggle("active", active);
    });
  };
  document.getElementById("biReportTab").addEventListener("click", () => setBiTab("report"));
  document.getElementById("biBuilderTab").addEventListener("click", () => setBiTab("builder"));
  document.getElementById("biModuleChartsTab").addEventListener("click", () => setBiTab("moduleCharts"));
  document.getElementById("biDatasetsTab").addEventListener("click", () => setBiTab("datasets"));
  document.getElementById("biModelTab").addEventListener("click", () => setBiTab("model"));
  document.getElementById("biQueryTab").addEventListener("click", () => setBiTab("query"));
  document.getElementById("biVisualsTab").addEventListener("click", () => setBiTab("visuals"));
  document.getElementById("biAskTab").addEventListener("click", () => setBiTab("ask"));
  document.getElementById("biPerformanceTab").addEventListener("click", () => setBiTab("performance"));
  document.getElementById("biSavedTab").addEventListener("click", () => setBiTab("saved"));
  const buildContext = () => ({ datasets, reports, dataSources, fields, relationships, measures, transformations, visualTypes, themes, qaPrompts, performance, moduleVisuals: state.moduleChartConfigs || moduleVisuals, data: biDataCache, setBiTab });
  renderBiDatasetWorkbench(buildContext());
  renderBiModelWorkbench(buildContext());
  renderBiQueryWorkbench(buildContext());
  renderBiVisualWorkbench(buildContext());
  renderBiQaWorkbench(buildContext());
  renderBiPerformanceWorkbench(buildContext());
  renderBiSavedReportsWorkbench(buildContext());
  renderBiModuleChartsWorkbench(buildContext());
  renderTable(document.getElementById("biPerformanceTable"), performance, { key: "biPerformance", columns: ["DatasetKey", "ReportID", "DurationMs", "RowCount", "ExecutedBy", "ExecutedAt"] });
  const renderBuilder = () => renderBiBuilderDesigner({ datasets, fields, data: biDataCache });
  renderBuilder();
  renderTable(document.getElementById("biReportsTable"), reports, {
    selectable: true,
    key: "biReports",
    idField: "ReportID",
    columns: ["ReportName", "ReportDescription", "IsShared", "CreatedBy", "CreatedAt", "ModifiedAt"],
    badges: { IsShared: activeClass },
    onSelect: (row) => {
      setValue("biReportName", row.ReportName || "");
      setValue("biReportDescription", row.ReportDescription || "");
      document.getElementById("biReportShared").checked = Boolean(row.IsShared);
      try {
        const layout = JSON.parse(row.LayoutJson || "[]");
        const visuals = Array.isArray(layout) ? layout.filter((item) => item.VisualType || item.visualType) : normalizeRows(layout.Visuals || layout.visuals);
        if (visuals.length) {
          state.biBuilderVisuals = visuals.map((item, index) => ({
            id: item.id || `bi-v${Date.now()}-${index}`,
            title: item.title || item.Title || item.DatasetKey || "Visual",
            datasetKey: item.datasetKey || item.DatasetKey,
            visualType: item.visualType || item.VisualType || item.DefaultVisual || "clustered-column",
            axisField: item.axisField || item.AxisField || "DisplayName",
            valueField: item.valueField || item.ValueField || "OpenAlerts",
            legendField: item.legendField || item.LegendField || "",
          }));
          state.biSelectedVisualId = state.biBuilderVisuals[0]?.id || null;
          renderBuilder();
        } else {
          const selected = new Set(layout.map((item) => String(item.DatasetKey)));
          document.querySelectorAll(".bi-dataset-check").forEach((cb) => cb.checked = selected.has(cb.value));
        }
      } catch {}
      try {
        const filters = JSON.parse(row.FilterJson || "{}");
        if (filters.Range) setValue("biRange", filters.Range);
        if (filters.ThemeID) setValue("biTheme", filters.ThemeID);
      } catch {}
      setBiTab("builder");
    },
  });
  const load = async () => {
    const range = valueOf("biRange");
    const data = await apiGet(`/api/bi-insights?range=${encodeURIComponent(range)}`, { timeoutMs: 60000 });
    biDataCache = data;
    const kpi = normalizeRows(data.kpis)[0] || {};
    const scorecard = normalizeRows(data.scorecard);
    const noisyAlerts = normalizeRows(data.noisyAlerts);
    const capacity = normalizeRows(data.capacity);
    const moduleHealth = normalizeRows(data.moduleHealth);
    const ticketSeverity = normalizeRows(data.ticketSeverity);
    const ticketStatus = normalizeRows(data.ticketStatus);
    const taskPriority = normalizeRows(data.taskPriority);
    const taskStatus = normalizeRows(data.taskStatus);
    const applicationGroups = normalizeRows(data.applicationGroups);
    const applicationScorecard = normalizeRows(data.applicationScorecard);
    const cpuPerformance = normalizeRows(data.cpuPerformance);
    const memoryPerformance = normalizeRows(data.memoryPerformance);
    const backupCompliance = normalizeRows(data.backupCompliance);
    const trends = normalizeRows(data.alertTrends);
    const vmKpi = normalizeRows(data.vmKpis)[0] || {};
    const vmScorecard = normalizeRows(data.vmScorecard);
    const vmAlertTrends = normalizeRows(data.vmAlertTrends);
    const vmTicketSla = normalizeRows(data.vmTicketSla);
    const vmCapacity = normalizeRows(data.vmCapacity);
    const vmProcessHotspots = normalizeRows(data.vmProcessHotspots);
    const vmEventLog = normalizeRows(data.vmEventLog);
    const vmPatchPosture = normalizeRows(data.vmPatchPosture);
    const posture = countBy(scorecard, "HealthPosture");
    const selectedDatasetValues = [...document.querySelectorAll(".bi-dataset-check:checked")].map((cb) => cb.value);
    const selectedDatasets = new Set(selectedDatasetValues);
    document.getElementById("biInsightsBody").innerHTML = `
      ${normalizeRows(data.messages).length ? `<div class="status-bar error">${normalizeRows(data.messages).map(escapeHtml).join("<br>")}</div>` : ""}
      <div class="toolbar page-tabs">
        <button class="btn active" type="button">Executive Overview</button>
        <button class="btn" type="button">Alert Noise</button>
        <button class="btn" type="button">Capacity</button>
        <button class="btn" type="button">Collectors</button>
      </div>
      <div class="grid four">
        ${metricCard("Servers", kpi.TotalServers ?? scorecard.length, "Visible monitoring scope")}
        ${metricCard("Open Alerts", kpi.OpenAlerts ?? 0, `${kpi.AlertRepeats ?? 0} total repeats`, Number(kpi.OpenAlerts || 0) ? "warning" : "active")}
        ${metricCard("Critical Servers", kpi.CriticalServers ?? 0, "Need immediate attention", Number(kpi.CriticalServers || 0) ? "critical" : "active")}
        ${metricCard("Health Score", calculateBiHealthScore(scorecard) + "%", "Weighted posture score")}
      </div>
      <div class="grid four">
        ${metricCard("Windows VMs", vmKpi.TotalVMs ?? vmScorecard.length, "VM Monitoring scope")}
        ${metricCard("Open VM Alerts", vmKpi.OpenVMAlerts ?? 0, `${vmKpi.CriticalVMAlerts ?? 0} critical`, Number(vmKpi.CriticalVMAlerts || 0) ? "critical" : Number(vmKpi.OpenVMAlerts || 0) ? "warning" : "active")}
        ${metricCard("Critical VMs", vmKpi.CriticalVMs ?? 0, "VMs in critical posture", Number(vmKpi.CriticalVMs || 0) ? "critical" : "active")}
        ${metricCard("Stale VM Samples", vmKpi.StaleVMs ?? 0, "Telemetry older than threshold", Number(vmKpi.StaleVMs || 0) ? "warning" : "active")}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("health-posture") ? `<div class="card"><div class="card-header"><h3>Health Posture</h3></div><div class="chart-box"><canvas id="biPostureChart"></canvas></div></div>` : ""}
        ${selectedDatasets.has("alert-trends") ? `<div class="card"><div class="card-header"><h3>Alert Trend</h3></div><div class="chart-box"><canvas id="biAlertTrendChart"></canvas></div></div>` : ""}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("ticket-severity") ? `<div class="card"><div class="card-header"><h3>Ticket Severity</h3><span>Includes zero-count severities so charts remain stable.</span></div><div id="biTicketSeverityVisual"></div></div>` : ""}
        ${selectedDatasets.has("task-priority") ? `<div class="card"><div class="card-header"><h3>Task Priority</h3><span>Includes zero-count priorities for consistent reporting.</span></div><div id="biTaskPriorityVisual"></div></div>` : ""}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("ticket-status") ? `<div class="card"><div class="card-header"><h3>Ticket Status</h3></div><div id="biTicketStatusVisual"></div></div>` : ""}
        ${selectedDatasets.has("task-status") ? `<div class="card"><div class="card-header"><h3>Task Status</h3></div><div id="biTaskStatusVisual"></div></div>` : ""}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("application-scorecard") ? `<div class="card"><div class="card-header"><h3>Application Scorecard</h3><span>Scoped by assigned application server groups.</span></div><div id="biApplicationScorecardTable"></div></div>` : ""}
        ${selectedDatasets.has("application-groups") ? `<div class="card"><div class="card-header"><h3>Application Server Groups</h3><span>Owners, assigned users, and server coverage.</span></div><div id="biApplicationGroupsTable"></div></div>` : ""}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("vm-scorecard") ? `<div class="card"><div class="card-header"><h3>VM Scorecard</h3><span>Windows VM health and alert posture.</span></div><div id="biVmScorecardTable"></div></div>` : ""}
        ${selectedDatasets.has("vm-alert-trends") ? `<div class="card"><div class="card-header"><h3>VM Alert Trends</h3><span>Open VM alert volume by severity and module.</span></div><div id="biVmAlertTrendVisual"></div></div>` : ""}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("vm-ticket-sla") ? `<div class="card"><div class="card-header"><h3>VM Ticket SLA</h3><span>Criticality, SLA status, and escalation ownership.</span></div><div id="biVmTicketSlaVisual"></div></div>` : ""}
        ${selectedDatasets.has("vm-capacity") ? `<div class="card"><div class="card-header"><h3>VM Capacity</h3><span>Windows drive utilization and remaining space.</span></div><div id="biVmCapacityVisual"></div></div>` : ""}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("vm-process-hotspots") ? `<div class="card"><div class="card-header"><h3>VM Process Hotspots</h3></div><div id="biVmProcessTable"></div></div>` : ""}
        ${selectedDatasets.has("vm-event-log") ? `<div class="card"><div class="card-header"><h3>VM Event Log Insights</h3></div><div id="biVmEventLogTable"></div></div>` : ""}
      </div>
      ${selectedDatasets.has("vm-patch-posture") ? `<div class="card"><div class="card-header"><h3>VM Patch Posture</h3></div><div id="biVmPatchPostureTable"></div></div>` : ""}
      <div class="grid two">
        ${selectedDatasets.has("cpu-performance") ? `<div class="card"><div class="card-header"><h3>CPU Performance</h3></div><div id="biCpuPerformanceVisual"></div></div>` : ""}
        ${selectedDatasets.has("memory-performance") ? `<div class="card"><div class="card-header"><h3>Memory Performance</h3></div><div id="biMemoryPerformanceVisual"></div></div>` : ""}
      </div>
      <div class="grid two">
        ${selectedDatasets.has("noisy-alerts") ? `<div class="card"><div class="card-header"><h3>Top Noisy Alerts</h3></div><div id="biNoisyAlertsTable"></div></div>` : ""}
        ${selectedDatasets.has("capacity-hotspots") ? `<div class="card"><div class="card-header"><h3>Capacity Hotspots</h3></div><div id="biCapacityTable"></div></div>` : ""}
      </div>
      ${selectedDatasets.has("backup-compliance") ? `<div class="card"><div class="card-header"><h3>Backup Compliance</h3></div><div id="biBackupComplianceTable"></div></div>` : ""}
      ${selectedDatasets.has("server-scorecard") ? `<div class="card"><div class="card-header"><h3>Server Scorecard</h3></div><div id="biScorecardTable"></div></div>` : ""}
      ${selectedDatasets.has("module-health") ? `<div class="card"><div class="card-header"><h3>Collection Module Health</h3></div><div id="biModuleHealthTable"></div></div>` : ""}
    `;
    if (selectedDatasets.has("health-posture")) drawDoughnutChart("biPostureChart", [
      { Label: "Healthy", Value: posture.Healthy || 0 },
      { Label: "Warning", Value: posture.Warning || 0 },
      { Label: "Critical", Value: posture.Critical || 0 },
    ], "Label", "Value", ["#198754", "#f2a900", "#d73a49"]);
    if (selectedDatasets.has("alert-trends")) drawStackedAlertTrend("biAlertTrendChart", trends);
    if (selectedDatasets.has("ticket-severity")) renderRowsVisual("biTicketSeverityVisual", "biTicketSeverityChart", ticketSeverity, { title: "Ticket Severity", visualType: "column", axisField: "TicketSeverity", valueField: "TicketCount", legendField: "" });
    if (selectedDatasets.has("task-priority")) renderRowsVisual("biTaskPriorityVisual", "biTaskPriorityChart", taskPriority, { title: "Task Priority", visualType: "column", axisField: "TaskPriority", valueField: "TaskCount", legendField: "" });
    if (selectedDatasets.has("ticket-status")) renderRowsVisual("biTicketStatusVisual", "biTicketStatusChart", ticketStatus, { title: "Ticket Status", visualType: "doughnut", axisField: "TicketStatus", valueField: "TicketCount", legendField: "" });
    if (selectedDatasets.has("task-status")) renderRowsVisual("biTaskStatusVisual", "biTaskStatusChart", taskStatus, { title: "Task Status", visualType: "doughnut", axisField: "TaskStatus", valueField: "TaskCount", legendField: "" });
    if (selectedDatasets.has("cpu-performance")) renderRowsVisual("biCpuPerformanceVisual", "biCpuPerformanceChart", cpuPerformance, { title: "CPU Performance", visualType: "clustered-column", axisField: "DisplayName", valueField: "PeakCPU", legendField: "" });
    if (selectedDatasets.has("memory-performance")) renderRowsVisual("biMemoryPerformanceVisual", "biMemoryPerformanceChart", memoryPerformance, { title: "Memory Performance", visualType: "clustered-column", axisField: "DisplayName", valueField: "MinAvailableMB", legendField: "" });
    if (selectedDatasets.has("noisy-alerts")) renderTable(document.getElementById("biNoisyAlertsTable"), noisyAlerts, { badges: { Severity: severityClass } });
    if (selectedDatasets.has("capacity-hotspots")) renderTable(document.getElementById("biCapacityTable"), capacity);
    if (selectedDatasets.has("application-scorecard")) renderTable(document.getElementById("biApplicationScorecardTable"), applicationScorecard, { badges: { HealthPosture: statusClass } });
    if (selectedDatasets.has("application-groups")) renderTable(document.getElementById("biApplicationGroupsTable"), applicationGroups);
    if (selectedDatasets.has("vm-scorecard")) renderTable(document.getElementById("biVmScorecardTable"), vmScorecard, { badges: { HealthPosture: statusClass } });
    if (selectedDatasets.has("vm-alert-trends")) renderRowsVisual("biVmAlertTrendVisual", "biVmAlertTrendChart", vmAlertTrends, { title: "VM Alert Trends", visualType: "stacked-column", axisField: "AlertDate", valueField: "AlertCount", legendField: "Severity" });
    if (selectedDatasets.has("vm-ticket-sla")) renderRowsVisual("biVmTicketSlaVisual", "biVmTicketSlaChart", vmTicketSla, { title: "VM Ticket SLA", visualType: "stacked-bar", axisField: "Subcategory", valueField: "TicketCount", legendField: "SLAStatus" });
    if (selectedDatasets.has("vm-capacity")) renderRowsVisual("biVmCapacityVisual", "biVmCapacityChart", vmCapacity, { title: "VM Capacity", visualType: "clustered-bar", axisField: "DisplayName", valueField: "PeakUsedPercent", legendField: "DriveLetter" });
    if (selectedDatasets.has("vm-process-hotspots")) renderTable(document.getElementById("biVmProcessTable"), vmProcessHotspots);
    if (selectedDatasets.has("vm-event-log")) renderTable(document.getElementById("biVmEventLogTable"), vmEventLog, { badges: { LevelName: severityClass } });
    if (selectedDatasets.has("vm-patch-posture")) renderTable(document.getElementById("biVmPatchPostureTable"), vmPatchPosture);
    if (selectedDatasets.has("backup-compliance")) renderTable(document.getElementById("biBackupComplianceTable"), backupCompliance);
    if (selectedDatasets.has("server-scorecard")) renderTable(document.getElementById("biScorecardTable"), scorecard, { badges: { HealthPosture: statusClass } });
    if (selectedDatasets.has("module-health")) renderTable(document.getElementById("biModuleHealthTable"), moduleHealth, { badges: { HealthStatus: statusClass } });
    renderBiDatasetWorkbench(buildContext());
    renderBiModelWorkbench(buildContext());
    renderBiQueryWorkbench(buildContext());
    renderBiVisualWorkbench(buildContext());
    renderBiQaWorkbench(buildContext());
    renderBiPerformanceWorkbench(buildContext());
    renderBiSavedReportsWorkbench(buildContext());
    renderBiModuleChartsWorkbench(buildContext());
    renderBuilder();
  };
  document.getElementById("loadBiInsights").addEventListener("click", load);
  document.querySelectorAll(".bi-dataset-check").forEach((cb) => cb.addEventListener("change", load));
  document.getElementById("newBiReport").addEventListener("click", () => {
    state.selectedRows.biReports = null;
    state.biBuilderVisuals = [
      { id: `bi-v${Date.now()}`, title: "Open Alerts by Server", datasetKey: "server-scorecard", visualType: "clustered-column", axisField: "DisplayName", valueField: "OpenAlerts", legendField: "HealthPosture" },
      { id: `bi-v${Date.now()}-tickets`, title: "Ticket Severity", datasetKey: "ticket-severity", visualType: "column", axisField: "TicketSeverity", valueField: "TicketCount", legendField: "" },
      { id: `bi-v${Date.now()}-tasks`, title: "Task Priority", datasetKey: "task-priority", visualType: "column", axisField: "TaskPriority", valueField: "TaskCount", legendField: "" },
      { id: `bi-v${Date.now()}-vm`, title: "VM Health Score", datasetKey: "vm-scorecard", visualType: "clustered-column", axisField: "DisplayName", valueField: "HealthScore", legendField: "HealthPosture" },
      { id: `bi-v${Date.now()}-vm-sla`, title: "VM Ticket SLA", datasetKey: "vm-ticket-sla", visualType: "stacked-bar", axisField: "Subcategory", valueField: "TicketCount", legendField: "SLAStatus" },
    ];
    state.biSelectedVisualId = state.biBuilderVisuals[0].id;
    setValue("biReportName", "SQL Monitor Executive Overview");
    setValue("biReportDescription", "Operational health, alert noise, and capacity insights.");
    document.getElementById("biReportShared").checked = true;
    document.querySelectorAll(".bi-dataset-check").forEach((cb) => cb.checked = defaultBiDatasets.has(cb.value));
    renderBuilder();
    setBiTab("builder");
    load();
  });
  document.getElementById("saveBiReport").addEventListener("click", async () => {
    const layout = state.biBuilderVisuals.map((visual, index) => ({ ...visual, Position: index + 1 }));
    const payload = {
      ReportID: state.selectedRows.biReports?.ReportID || 0,
      ReportName: valueOf("biReportName"),
      ReportDescription: valueOf("biReportDescription"),
      LayoutJson: JSON.stringify(layout),
      FilterJson: JSON.stringify({ Range: valueOf("biRange"), ThemeID: valueOf("biTheme") }),
      IsShared: checked("biReportShared"),
    };
    await apiPost("/api/bi-insights/reports", payload);
    showStatus("BI report saved.");
    await renderBiInsights();
  });
  document.getElementById("deleteBiReport").addEventListener("click", async () => {
    const report = state.selectedRows.biReports;
    if (!report?.ReportID) return showError("Select a saved report first.");
    if (!confirm(`Delete BI report ${report.ReportName}?`)) return;
    await apiDelete(`/api/bi-insights/reports?reportId=${report.ReportID}`);
    state.selectedRows.biReports = null;
    showStatus("BI report deleted.");
    await renderBiInsights();
  });
  document.getElementById("askBiQuestion").addEventListener("click", async () => {
    const question = valueOf("biQuestion");
    const result = await apiPost("/api/bi-insights/ask", { Question: question });
    document.getElementById("biAnswer").innerHTML = `
      <p><strong>Answer:</strong> ${escapeHtml(result.answer || "")}</p>
      <p><strong>Dataset:</strong> ${escapeHtml(result.datasetKey || "")}</p>
    `;
    const suggestion = document.getElementById("biQaVisualSuggestion");
    if (suggestion) {
      suggestion.innerHTML = `<button class="btn primary" id="biBuildAnswerVisual" type="button">Build ${escapeHtml(result.datasetKey || "answer")} visual</button>`;
      document.getElementById("biBuildAnswerVisual")?.addEventListener("click", () => {
        addBiVisualFromDataset(buildContext(), result.datasetKey || "server-scorecard");
        setBiTab("builder");
      });
    }
    setBiTab("ask");
  });
  document.getElementById("exportBiScorecard").addEventListener("click", () => exportTableCsv("biScorecardTable", "BI_ServerScorecard.csv"));
  document.getElementById("exportBiAlerts").addEventListener("click", () => exportTableCsv("biNoisyAlertsTable", "BI_NoisyAlerts.csv"));
  document.getElementById("exportBiManagementExcel").addEventListener("click", async () => {
    const period = valueOf("biManagementPeriod") || "Weekly";
    const report = await apiGet(`/api/bi-insights/management-report?period=${encodeURIComponent(period)}`, { timeoutMs: 90000 });
    exportBiManagementExcel(report);
  });
  await load();
}

function renderBiModuleChartsWorkbench(context) {
  const moduleSelect = document.getElementById("biModuleChartModule");
  if (!moduleSelect) return;
  const modules = getModuleFeatures();
  const configs = normalizeRows(context.moduleVisuals);
  const currentModule = moduleSelect.value || modules[0]?.module || "";
  moduleSelect.innerHTML = modules.map((feature) => `<option value="${escapeAttr(feature.module)}" ${feature.module === currentModule ? "selected" : ""}>${escapeHtml(feature.title)}</option>`).join("");
  const typeSelect = document.getElementById("biModuleChartType");
  if (typeSelect) {
    typeSelect.innerHTML = getBiBuilderVisualTypes().map((visual) => `<option value="${escapeAttr(visual.key)}">${escapeHtml(visual.label)}</option>`).join("");
  }
  const cards = document.getElementById("biModuleChartCards");
  if (cards) {
    cards.innerHTML = modules.map((feature) => {
      const config = configs.find((item) => item.ModuleKey === feature.module) || {};
      const enabled = isTruthy(config.IsEnabled);
      return `
        <button class="bi-module-chart-card ${feature.module === currentModule ? "active" : ""}" type="button" data-module-key="${escapeAttr(feature.module)}">
          <strong>${escapeHtml(feature.title)}</strong>
          <span>${escapeHtml(config.VisualTitle || "No chart title")} &middot; ${escapeHtml(config.VisualType || "table")}</span>
          <em class="${enabled ? "active" : ""}">${enabled ? "Enabled" : "Disabled"}</em>
        </button>
      `;
    }).join("") || `<div class="details">No module pages are available.</div>`;
    cards.querySelectorAll(".bi-module-chart-card").forEach((button) => {
      button.addEventListener("click", () => {
        moduleSelect.value = button.dataset.moduleKey;
        loadBiModuleChartDesigner(context);
      });
    });
  }
  moduleSelect.onchange = () => loadBiModuleChartDesigner(context);
  const saveButton = document.getElementById("saveBiModuleChart");
  if (saveButton) saveButton.onclick = async () => {
    const feature = modules.find((item) => item.module === valueOf("biModuleChartModule")) || {};
    const axis = valueOf("biModuleChartAxis");
    const value = valueOf("biModuleChartValue");
    const legend = valueOf("biModuleChartLegend");
    if (!axis) return showError("Axis / Category is required.");
    if (value && axis === value) return showError("Axis and Values must be different fields.");
    if (legend && /time|date/i.test(legend)) return showError("Time/date fields should be used as the X axis, not as Legend / Series.");
    const payload = {
      ModuleKey: feature.module || valueOf("biModuleChartModule"),
      ModuleTitle: feature.title || valueOf("biModuleChartModule"),
      VisualTitle: valueOf("biModuleChartTitle"),
      VisualType: valueOf("biModuleChartType"),
      AxisField: axis,
      ValueField: value,
      LegendField: legend,
      IsEnabled: checked("biModuleChartEnabled"),
    };
    const result = await apiPost("/api/bi-insights/module-visuals", payload);
    state.moduleChartConfigs = normalizeRows(result.moduleVisuals);
    showStatus("Module chart saved.");
    renderBiModuleChartsWorkbench({ ...context, moduleVisuals: state.moduleChartConfigs });
  };
  loadBiModuleChartDesigner(context);
}

function getModuleChartRecommendation(moduleKey, fields, feature = {}) {
  const available = new Set(normalizeRows(fields).map(String));
  const pick = (...names) => names.find((name) => available.has(name)) || "";
  const map = {
    cpu: { title: "SQL CPU Percent", visualType: "line", axisField: "CaptureTime", valueField: "SqlCPUPercent", legendField: "", aggregateMethod: "avg", rowScope: "all" },
    memory: { title: "Available Memory", visualType: "line", axisField: "CaptureTime", valueField: "AvailablePhysicalMB", legendField: "", aggregateMethod: "avg", rowScope: "all" },
    kpis: { title: "Page Life Expectancy", visualType: "line", axisField: "CaptureTime", valueField: "PageLifeExpectancy", legendField: "", aggregateMethod: "avg", rowScope: "all" },
    waits: { title: "Latest Wait Time by Type", visualType: "clustered-bar", axisField: "WaitType", valueField: "WaitTimeMs", legendField: "", aggregateMethod: "max", rowScope: "latest" },
    "top-queries": { title: "Latest Top Query CPU", visualType: "clustered-bar", axisField: "QueryText", valueField: "AvgCpuTime", legendField: "", aggregateMethod: "max", rowScope: "latest" },
    "execution-plans": { title: "Execution Plan CPU", visualType: "clustered-bar", axisField: "QueryText", valueField: "CpuTime", legendField: "WaitType", aggregateMethod: "max", rowScope: "latest" },
    disks: { title: "Latest Disk Used Percent", visualType: "clustered-bar", axisField: "VolumeMountPoint", valueField: "UsedPct", legendField: "", aggregateMethod: "max", rowScope: "latest-per-axis" },
    io: { title: "Latest I/O Stall by File", visualType: "clustered-bar", axisField: "LogicalName", valueField: "TotalStallMS", legendField: "FileType", aggregateMethod: "max", rowScope: "latest-per-axis" },
    tempdb: { title: "Latest TempDB Percent Full", visualType: "clustered-bar", axisField: "LogicalName", valueField: "PercentFull", legendField: "FileType", aggregateMethod: "max", rowScope: "latest-per-axis" },
    backups: { title: "Latest Backup Age by Database", visualType: "clustered-bar", axisField: "DatabaseName", valueField: "LastFullHours", legendField: "StatusText", aggregateMethod: "max", rowScope: "latest-per-axis" },
    "db-options": { title: "Latest Database Size", visualType: "clustered-bar", axisField: "DatabaseName", valueField: "SizeMB", legendField: "State", aggregateMethod: "max", rowScope: "latest-per-axis" },
    "missing-indexes": { title: "Latest Missing Index Benefit", visualType: "clustered-bar", axisField: "ObjectName", valueField: "ImprovementMeasure", legendField: "DatabaseName", aggregateMethod: "max", rowScope: "latest" },
    fragmentation: { title: "Latest Index Fragmentation", visualType: "clustered-bar", axisField: "ObjectName", valueField: "AvgFragmentationPercent", legendField: "DatabaseName", aggregateMethod: "max", rowScope: "latest" },
    config: { title: "MaxDOP Setting Trend", visualType: "line", axisField: "CaptureTime", valueField: "MaxDOPSetting", legendField: "", aggregateMethod: "max", rowScope: "all" },
    blocking: { title: "Current Blocking Wait Time", visualType: "clustered-bar", axisField: "SessionID", valueField: "WaitTimeMS", legendField: "WaitType", aggregateMethod: "max", rowScope: "latest" },
    "long-running": { title: "Current Long Running Duration", visualType: "clustered-bar", axisField: "SessionID", valueField: "DurationMinutes", legendField: "DatabaseName", aggregateMethod: "max", rowScope: "latest" },
    ag: { title: "Latest AG Sync Health", visualType: "clustered-bar", axisField: "AGName", valueField: "FailureConditionLevel", legendField: "SyncHealthDesc", aggregateMethod: "max", rowScope: "latest-per-axis" },
    listeners: { title: "Latest Listeners by State", visualType: "clustered-column", axisField: "State", valueField: "", legendField: "", aggregateMethod: "count", rowScope: "latest" },
    "agent-jobs": { title: "Latest Agent Job Success Percent", visualType: "clustered-bar", axisField: "JobName", valueField: "SuccessPctRecent", legendField: "LastStatus", aggregateMethod: "avg", rowScope: "latest-per-axis" },
    deadlocks: { title: "Deadlocks by Time", visualType: "clustered-column", axisField: "DeadlockTime", valueField: "", legendField: "", aggregateMethod: "count", rowScope: "all" },
  };
  const preferred = map[moduleKey] || {};
  const axisField = pick(preferred.axisField) || pick("CaptureTime", "CollectionDateTime", "DatabaseName", "ObjectName", "WaitType", "JobName", "SessionID", "VolumeMountPoint", "LogicalName") || fields[0] || "";
  const valueField = pick(preferred.valueField) || pick("UsedPct", "PercentFull", "WaitTimeMs", "WaitTimeMS", "AvgCpuTime", "CpuTime", "DurationMinutes", "ImprovementMeasure", "AvgFragmentationPercent", "SuccessPctRecent") || fields.find((field) => /percent|pct|count|ms|cpu|duration|used|free|size|reads|writes|level/i.test(field)) || "";
  const legendField = pick(preferred.legendField) || "";
  return {
    title: preferred.title || `${feature.title || moduleKey} Chart`,
    visualType: preferred.visualType || (axisField.match(/time|date/i) ? "line" : "clustered-bar"),
    axisField,
    valueField,
    legendField: legendField === axisField || legendField === valueField ? "" : legendField,
    aggregateMethod: preferred.aggregateMethod || inferBiAggregateMethod(valueField),
    rowScope: preferred.rowScope || "all",
  };
}

function sanitizeModuleChartVisual(moduleKey, visual, rows, fields, feature = {}) {
  const recommendation = getModuleChartRecommendation(moduleKey, fields, feature);
  const axis = visual.axisField || "";
  const value = visual.valueField || "";
  const legend = visual.legendField || "";
  const categoryAxis = !isBiMeasureField(axis);
  const timeAxis = isBiTimeDimensionField(axis);
  const invalidLegend = legend && isBiTimeDimensionField(legend);
  const invalidAxis = !axis || (isBiNumericField(rows, axis) && !categoryAxis && !timeAxis);
  const invalidType = ["line", "area"].includes(visual.visualType) && !timeAxis;
  if (invalidAxis || invalidLegend) {
    return { ...recommendation, title: visual.title || recommendation.title };
  }
  return {
    ...visual,
    visualType: invalidType ? recommendation.visualType : visual.visualType,
    valueField: value === axis ? recommendation.valueField : value,
    legendField: legend === axis || legend === value ? "" : legend,
    aggregateMethod: visual.aggregateMethod || recommendation.aggregateMethod,
    rowScope: visual.rowScope || recommendation.rowScope,
  };
}

function isBiTimeDimensionField(field) {
  return /capturetime|collectiondatetime|deadlocktime|createddate|lastruntime|nextruntime|alertdate|date$/i.test(field || "");
}

function isBiMeasureField(field) {
  return /percent|pct|count|ms|cpu|duration|used|free|size|reads|writes|gb|mb|hours|ratio|stall|ple|cost|impact|measure/i.test(field || "");
}

function isBiNumericField(rows, field) {
  if (!field) return false;
  const values = normalizeRows(rows).map((row) => row[field]).filter((value) => value !== null && value !== undefined && value !== "").slice(0, 20);
  return values.length > 0 && values.every((value) => Number.isFinite(Number(value)));
}

async function loadBiModuleChartDesigner(context) {
  const moduleKey = valueOf("biModuleChartModule");
  if (!moduleKey) return;
  const modules = getModuleFeatures();
  const feature = modules.find((item) => item.module === moduleKey) || { title: moduleKey, module: moduleKey };
  const config = normalizeRows(context.moduleVisuals).find((item) => item.ModuleKey === moduleKey) || {};
  const preview = document.getElementById("biModuleChartPreview");
  const chartId = "biModuleChartPreviewCanvas";
  destroyChart(chartId);
  const enabledInput = document.getElementById("biModuleChartEnabled");
  if (enabledInput) enabledInput.checked = isTruthy(config.IsEnabled);

  let rows = [];
  try {
    const data = await apiGet(`/api/module/${encodeURIComponent(moduleKey)}?instanceId=${selectedInstanceId()}`);
    rows = normalizeRows(data.rows);
  } catch (error) {
    if (preview) preview.innerHTML = `<div class="details">Preview unavailable: ${escapeHtml(error.message)}</div>`;
  }
  const rowFields = Object.keys(rows[0] || {});
  const fields = rowFields.length ? rowFields : [...new Set([config.AxisField, config.ValueField, config.LegendField].filter(Boolean))];
  const recommendation = getModuleChartRecommendation(moduleKey, fields, feature);
  let selected = config.ModuleKey ? {
    title: config.VisualTitle || recommendation.title,
    visualType: config.VisualType || recommendation.visualType,
    axisField: fields.includes(config.AxisField) ? config.AxisField : recommendation.axisField,
    valueField: fields.includes(config.ValueField) ? config.ValueField : recommendation.valueField,
    legendField: fields.includes(config.LegendField) && !/time|date/i.test(config.LegendField) ? config.LegendField : recommendation.legendField,
  } : recommendation;
  selected = sanitizeModuleChartVisual(moduleKey, selected, rows, fields, feature);
  setValue("biModuleChartTitle", selected.title || `${feature.title} Chart`);
  setValue("biModuleChartType", selected.visualType || "clustered-bar");
  const choose = (selector, selected, includeBlank = false) => {
    const element = document.getElementById(selector);
    if (!element) return;
    const current = selected || (includeBlank ? "" : fields[0] || "");
    element.innerHTML = `${includeBlank ? '<option value="">None / Count rows</option>' : ""}${fields.map((field) => `<option value="${escapeAttr(field)}" ${field === current ? "selected" : ""}>${escapeHtml(field)}</option>`).join("")}`;
  };
  choose("biModuleChartAxis", selected.axisField || recommendation.axisField || fields[0] || "");
  choose("biModuleChartValue", selected.valueField || recommendation.valueField || "", true);
  choose("biModuleChartLegend", selected.legendField || "", true);
  const hints = document.getElementById("biModuleChartFields");
  if (hints) hints.innerHTML = `
    <div class="bi-recommendation">
      <strong>Recommended</strong>
      <span>${escapeHtml(recommendation.visualType)} &middot; X: ${escapeHtml(recommendation.axisField || "Category")} &middot; Y: ${escapeHtml(recommendation.valueField || "Count")} &middot; Legend: ${escapeHtml(recommendation.legendField || "Metric")} &middot; Rows: ${escapeHtml(recommendation.rowScope || "all")}</span>
    </div>
    ${fields.map((field) => `<span>${escapeHtml(field)}</span>`).join("") || `<span>No sample fields loaded.</span>`}
  `;

  const rerenderPreview = () => {
    const visual = {
      title: valueOf("biModuleChartTitle") || `${feature.title} Chart`,
      visualType: valueOf("biModuleChartType") || "line",
      axisField: valueOf("biModuleChartAxis"),
      valueField: valueOf("biModuleChartValue"),
      legendField: valueOf("biModuleChartLegend"),
    };
    if (!preview) return;
    preview.innerHTML = `
      <div class="card module-chart-card">
        <div class="card-header"><h3>${escapeHtml(visual.title)}</h3><span>${escapeHtml(feature.title)} preview</span></div>
        <div id="biModuleChartPreviewHost" class="module-chart-host"></div>
      </div>
    `;
    renderRowsVisual("biModuleChartPreviewHost", chartId, rows, visual);
  };
  const applyRecommendation = () => {
    setValue("biModuleChartTitle", recommendation.title || `${feature.title} Chart`);
    setValue("biModuleChartType", recommendation.visualType || "clustered-bar");
    setValue("biModuleChartAxis", recommendation.axisField || "");
    setValue("biModuleChartValue", recommendation.valueField || "");
    setValue("biModuleChartLegend", recommendation.legendField || "");
    rerenderPreview();
  };
  const autoButton = document.getElementById("autoConfigureBiModuleChart");
  if (autoButton) autoButton.onclick = applyRecommendation;
  ["biModuleChartTitle", "biModuleChartType", "biModuleChartAxis", "biModuleChartValue", "biModuleChartLegend"].forEach((id) => {
    const element = document.getElementById(id);
    if (element) element.onchange = rerenderPreview;
  });
  rerenderPreview();
}

function renderBiDatasetWorkbench(context) {
  const categorySelect = document.getElementById("biDatasetCategory");
  const cards = document.getElementById("biDatasetCards");
  if (!categorySelect || !cards) return;
  const categories = ["All", ...new Set(normalizeRows(context.datasets).map((dataset) => dataset.Category || "Uncategorized"))];
  const currentCategory = categorySelect.value || "All";
  const search = document.getElementById("biDatasetSearch")?.value?.toLowerCase() || "";
  categorySelect.innerHTML = categories.map((category) => `<option ${category === currentCategory ? "selected" : ""}>${escapeHtml(category)}</option>`).join("");
  const filtered = normalizeRows(context.datasets).filter((dataset) => {
    const text = `${dataset.DisplayName || ""} ${dataset.Category || ""} ${dataset.Description || ""} ${dataset.QueryName || ""}`.toLowerCase();
    return (currentCategory === "All" || dataset.Category === currentCategory) && (!search || text.includes(search));
  });
  cards.innerHTML = filtered.map((dataset) => {
    const fieldCount = normalizeRows(context.fields).filter((field) => field.DatasetKey === dataset.DatasetKey).length;
    const rowCount = getBiDatasetRows(context.data, dataset.DatasetKey).length;
    return `
      <article class="bi-action-card">
        <div><strong>${escapeHtml(dataset.DisplayName || dataset.DatasetKey)}</strong><span>${escapeHtml(dataset.Category || "")} · ${escapeHtml(dataset.DefaultVisual || "table")}</span></div>
        <p>${escapeHtml(dataset.Description || "")}</p>
        <div class="bi-card-metrics"><span>${fieldCount} fields</span><span>${rowCount ? `${rowCount} live rows` : "metadata only"}</span></div>
        <div class="bi-card-actions">
          <button class="btn bi-build-dataset" data-dataset-key="${escapeAttr(dataset.DatasetKey)}" type="button">Build Visual</button>
          <button class="btn bi-preview-dataset" data-dataset-key="${escapeAttr(dataset.DatasetKey)}" type="button">Preview</button>
        </div>
      </article>
    `;
  }).join("") || `<div class="details">No datasets match the current filter.</div>`;
  const sourceHost = document.getElementById("biDataSourceCards");
  if (sourceHost) sourceHost.innerHTML = normalizeRows(context.dataSources).map((source) => `
    <div class="bi-mini-item"><strong>${escapeHtml(source.DisplayName)}</strong><span>${escapeHtml(source.SourceType)} · ${escapeHtml(source.ConnectorType)} · ${escapeHtml(source.ConnectionMode)}</span></div>
  `).join("") || `<div class="details">No data sources registered.</div>`;
  const summary = document.getElementById("biDatasetSummary");
  if (summary) summary.innerHTML = `
    <div><span>Datasets</span><strong>${escapeHtml(context.datasets.length)}</strong></div>
    <div><span>Fields</span><strong>${escapeHtml(context.fields.length)}</strong></div>
    <div><span>Sources</span><strong>${escapeHtml(context.dataSources.length)}</strong></div>
    <div><span>Active Visuals</span><strong>${escapeHtml(state.biBuilderVisuals.length)}</strong></div>
  `;
  categorySelect.onchange = () => renderBiDatasetWorkbench(context);
  const searchInput = document.getElementById("biDatasetSearch");
  if (searchInput) searchInput.oninput = () => renderBiDatasetWorkbench(context);
  cards.querySelectorAll(".bi-build-dataset").forEach((button) => {
    button.addEventListener("click", () => {
      addBiVisualFromDataset(context, button.dataset.datasetKey);
      context.setBiTab("builder");
    });
  });
  cards.querySelectorAll(".bi-preview-dataset").forEach((button) => {
    const datasetKey = button.dataset.datasetKey;
    button.addEventListener("click", () => {
      const dataset = normalizeRows(context.datasets).find((item) => item.DatasetKey === datasetKey);
      state.biBuilderVisuals = [{ id: `bi-v${Date.now()}`, title: `${dataset?.DisplayName || datasetKey} Preview`, datasetKey, visualType: "table", axisField: "", valueField: "", legendField: "" }];
      state.biSelectedVisualId = state.biBuilderVisuals[0].id;
      context.setBiTab("builder");
      renderBiBuilderDesigner(context);
    });
  });
}

function renderBiModelWorkbench(context) {
  const summary = document.getElementById("biModelSummary");
  if (!summary) return;
  const dimensions = normalizeRows(context.fields).filter((field) => /dimension/i.test(field.FieldRole || "")).length;
  const measuresCount = normalizeRows(context.measures).length;
  summary.innerHTML = `
    ${metricCard("Datasets", context.datasets.length, "Semantic tables")}
    ${metricCard("Dimensions", dimensions, "Filterable fields")}
    ${metricCard("Measures", measuresCount, "Reusable calculations")}
    ${metricCard("Relationships", context.relationships.length, "Cross-filter paths")}
  `;
  const fieldExplorer = document.getElementById("biFieldExplorer");
  if (fieldExplorer) {
    fieldExplorer.innerHTML = normalizeRows(context.datasets).map((dataset) => {
      const datasetFields = normalizeRows(context.fields).filter((field) => field.DatasetKey === dataset.DatasetKey);
      return `
        <details open>
          <summary>${escapeHtml(dataset.DisplayName || dataset.DatasetKey)} <span>${datasetFields.length}</span></summary>
          ${datasetFields.map((field) => `<button class="bi-field-pill" data-dataset-key="${escapeAttr(dataset.DatasetKey)}" data-field-name="${escapeAttr(field.FieldName)}">${escapeHtml(field.FieldName)}<span>${escapeHtml(field.FieldRole || field.DataType || "")}</span></button>`).join("")}
        </details>
      `;
    }).join("");
  }
  const measureCards = document.getElementById("biMeasureCards");
  if (measureCards) measureCards.innerHTML = normalizeRows(context.measures).map((measure) => `
    <div class="bi-mini-item"><strong>${escapeHtml(measure.MeasureName)}</strong><span>${escapeHtml(measure.DatasetKey)} · ${escapeHtml(measure.FormatString || "")}</span><code>${escapeHtml(measure.ExpressionText || "")}</code></div>
  `).join("") || `<div class="details">No measures registered.</div>`;
  const relationshipsHost = document.getElementById("biRelationshipMap");
  if (relationshipsHost) relationshipsHost.innerHTML = normalizeRows(context.relationships).map((rel) => `
    <div class="bi-relation-card"><strong>${escapeHtml(rel.FromDatasetKey)}.${escapeHtml(rel.FromField)}</strong><span>${escapeHtml(rel.Cardinality)} · ${escapeHtml(rel.CrossFilterDirection)}</span><strong>${escapeHtml(rel.ToDatasetKey)}.${escapeHtml(rel.ToField)}</strong></div>
  `).join("") || `<div class="details">No relationships registered yet.</div>`;
  document.getElementById("biAddScorecardModel")?.addEventListener("click", () => {
    addBiVisualFromDataset(context, "server-scorecard", "clustered-column");
    context.setBiTab("builder");
  });
  document.getElementById("biAddTrendModel")?.addEventListener("click", () => {
    addBiVisualFromDataset(context, "alert-trends", "stacked-column");
    context.setBiTab("builder");
  });
}

function renderBiQueryWorkbench(context) {
  const select = document.getElementById("biQueryDataset");
  const pipeline = document.getElementById("biTransformationPipeline");
  if (!select || !pipeline) return;
  const selected = select.value || context.datasets[0]?.DatasetKey || "";
  select.innerHTML = normalizeRows(context.datasets).map((dataset) => `<option value="${escapeAttr(dataset.DatasetKey)}" ${dataset.DatasetKey === selected ? "selected" : ""}>${escapeHtml(dataset.DisplayName || dataset.DatasetKey)}</option>`).join("");
  const steps = normalizeRows(context.transformations).filter((step) => step.DatasetKey === selected);
  pipeline.innerHTML = steps.map((step, index) => `
    <article class="bi-step-card"><span>${index + 1}</span><div><strong>${escapeHtml(step.StepName)}</strong><em>${escapeHtml(step.StepType)}</em><p>${escapeHtml(step.ExpressionText || "")}</p></div></article>
  `).join("") || `<div class="details">No transformation steps registered for this dataset. Data is read directly from repository views.</div>`;
  const previewHost = document.getElementById("biQueryPreview");
  if (previewHost) renderTable(previewHost, getBiDatasetRows(context.data, selected).slice(0, 20), { key: `biQueryPreview-${selected}`, pagination: false });
  select.onchange = () => renderBiQueryWorkbench(context);
}

function renderBiVisualWorkbench(context) {
  const library = document.getElementById("biVisualizationLibrary");
  if (!library) return;
  library.innerHTML = getBiBuilderVisualTypes().map((visual) => `
    <article class="bi-visual-library-card">
      <span class="bi-visual-icon ${escapeAttr(visual.icon)}"></span>
      <div><strong>${escapeHtml(visual.label)}</strong><p>${escapeHtml(getBiVisualUseCase(visual.key))}</p></div>
      <button class="btn bi-add-visual-type" data-visual-type="${escapeAttr(visual.key)}" type="button">Add</button>
    </article>
  `).join("");
  const themesHost = document.getElementById("biThemeCards");
  if (themesHost) themesHost.innerHTML = normalizeRows(context.themes).map((theme) => {
    const colors = parseBiThemeColors(theme.ThemeJson);
    return `<div class="bi-mini-item"><strong>${escapeHtml(theme.ThemeName)}</strong><span>${theme.IsDefault ? "Default" : "Custom"}</span><div class="bi-swatches">${colors.map((color) => `<i style="background:${escapeAttr(color)}"></i>`).join("")}</div></div>`;
  }).join("") || `<div class="details">No themes registered.</div>`;
  const recommendations = document.getElementById("biVisualRecommendations");
  if (recommendations) recommendations.innerHTML = `
    <div class="bi-mini-item"><strong>Alert Trend</strong><span>Stacked column by severity over time</span></div>
    <div class="bi-mini-item"><strong>Health Posture</strong><span>Doughnut or card for executive summary</span></div>
    <div class="bi-mini-item"><strong>Noisy Alerts</strong><span>Clustered bar sorted by repeat count</span></div>
  `;
  library.querySelectorAll(".bi-add-visual-type").forEach((button) => {
    button.addEventListener("click", () => {
      addBiVisualFromDataset(context, context.datasets[0]?.DatasetKey || "server-scorecard", button.dataset.visualType);
      context.setBiTab("builder");
    });
  });
}

function renderBiQaWorkbench(context) {
  const cards = document.getElementById("biPromptCards");
  if (!cards) return;
  cards.innerHTML = normalizeRows(context.qaPrompts).map((prompt) => `
    <article class="bi-action-card">
      <div><strong>${escapeHtml(prompt.PromptText)}</strong><span>${prompt.IsVerified ? "Verified" : "Draft"} · ${escapeHtml(prompt.DatasetKey || "")}</span></div>
      <p>${escapeHtml(prompt.AnswerTemplate || "")}</p>
      <button class="btn bi-run-prompt" data-prompt="${escapeAttr(prompt.PromptText)}" data-dataset-key="${escapeAttr(prompt.DatasetKey || "")}" type="button">Ask</button>
    </article>
  `).join("") || `<div class="details">No verified prompts registered.</div>`;
  cards.querySelectorAll(".bi-run-prompt").forEach((button) => {
    button.addEventListener("click", async () => {
      setValue("biQuestion", button.dataset.prompt);
      document.getElementById("askBiQuestion")?.click();
      const suggestion = document.getElementById("biQaVisualSuggestion");
      if (suggestion) suggestion.innerHTML = `<button class="btn primary bi-build-qa-visual" data-dataset-key="${escapeAttr(button.dataset.datasetKey)}" type="button">Build visual from ${escapeHtml(button.dataset.datasetKey || "answer dataset")}</button>`;
      suggestion?.querySelector(".bi-build-qa-visual")?.addEventListener("click", () => {
        addBiVisualFromDataset(context, button.dataset.datasetKey || "server-scorecard");
        context.setBiTab("builder");
      });
    });
  });
}

function renderBiPerformanceWorkbench(context) {
  const summary = document.getElementById("biPerformanceSummary");
  if (!summary) return;
  const runs = normalizeRows(context.performance);
  const avgMs = runs.length ? Math.round(runs.reduce((sum, run) => sum + Number(run.DurationMs || 0), 0) / runs.length) : 0;
  const maxRun = runs.slice().sort((a, b) => Number(b.DurationMs || 0) - Number(a.DurationMs || 0))[0] || {};
  const totalRows = runs.reduce((sum, run) => sum + Number(run.RowCount || 0), 0);
  summary.innerHTML = `
    ${metricCard("Runs", runs.length, "Tracked executions")}
    ${metricCard("Avg Duration", `${avgMs} ms`, "Recent BI calls")}
    ${metricCard("Slowest", `${Number(maxRun.DurationMs || 0)} ms`, maxRun.DatasetKey || "No runs")}
    ${metricCard("Rows", totalRows, "Rows returned")}
  `;
  const findings = document.getElementById("biPerformanceFindings");
  if (findings) {
    const slowRuns = runs.filter((run) => Number(run.DurationMs || 0) > 1000).slice(0, 5);
    findings.innerHTML = slowRuns.map((run) => `<div class="bi-mini-item"><strong>${escapeHtml(run.DatasetKey || "BI Query")}</strong><span>${escapeHtml(run.DurationMs)} ms · ${escapeHtml(run.RowCount)} rows · ${escapeHtml(run.ExecutedAt || "")}</span></div>`).join("") || `<div class="details">No slow BI runs detected.</div>`;
  }
}

function renderBiSavedReportsWorkbench(context) {
  const host = document.getElementById("biSavedReportCards");
  if (!host) return;
  host.innerHTML = normalizeRows(context.reports).map((report) => {
    const visualCount = countBiReportVisuals(report.LayoutJson);
    return `
      <article class="bi-action-card">
        <div><strong>${escapeHtml(report.ReportName)}</strong><span>${visualCount} visual${visualCount === 1 ? "" : "s"} &middot; ${report.IsShared ? "Shared" : "Personal"}</span></div>
        <p>${escapeHtml(report.ReportDescription || "No description.")}</p>
        <div class="bi-card-metrics"><span>${escapeHtml(report.CreatedBy || "")}</span><span>${escapeHtml(report.ModifiedAt || report.CreatedAt || "")}</span></div>
        <div class="bi-card-actions">
          <button class="btn primary bi-load-report" data-report-id="${escapeAttr(report.ReportID)}" type="button">Open Builder</button>
          <button class="btn bi-view-report" data-report-id="${escapeAttr(report.ReportID)}" type="button">Open Canvas</button>
          <button class="btn danger bi-delete-report-card" data-report-id="${escapeAttr(report.ReportID)}" type="button">Delete</button>
        </div>
      </article>
    `;
  }).join("") || `<div class="details">No saved reports yet. Build a report and click Save Report.</div>`;
  host.querySelectorAll(".bi-load-report,.bi-view-report").forEach((button) => {
    button.addEventListener("click", () => {
      const report = normalizeRows(context.reports).find((item) => String(item.ReportID) === String(button.dataset.reportId));
      if (!report) return;
      loadBiReportIntoBuilder(report);
      if (button.classList.contains("bi-view-report")) {
        renderBiSavedReportCanvas(report, context);
        context.setBiTab("report");
      } else {
        renderBiBuilderDesigner(context);
        context.setBiTab("builder");
      }
    });
  });
  host.querySelectorAll(".bi-delete-report-card").forEach((button) => {
    button.addEventListener("click", () => {
      const report = normalizeRows(context.reports).find((item) => String(item.ReportID) === String(button.dataset.reportId));
      if (report) {
        state.selectedRows.biReports = report;
        document.getElementById("deleteBiReport")?.click();
      }
    });
  });
}

function addBiVisualFromDataset(context, datasetKey, visualType = "") {
  const dataset = normalizeRows(context.datasets).find((item) => item.DatasetKey === datasetKey) || {};
  const defaults = getBiDefaultFields(context, datasetKey);
  const visual = {
    id: `bi-v${Date.now()}`,
    title: dataset.DisplayName || datasetKey || "Visual",
    datasetKey,
    visualType: visualType || dataset.DefaultVisual || "clustered-column",
    axisField: defaults.axisField,
    valueField: defaults.valueField,
    legendField: defaults.legendField,
  };
  state.biBuilderVisuals.push(visual);
  state.biSelectedVisualId = visual.id;
  renderBiBuilderDesigner(context);
}

function loadBiReportIntoBuilder(report) {
  try {
    const layout = JSON.parse(report.LayoutJson || "[]");
    const visuals = Array.isArray(layout) ? layout : normalizeRows(layout.visuals || layout.Visuals);
    state.biBuilderVisuals = visuals.map((item, index) => ({
      id: item.id || `bi-v${Date.now()}-${index}`,
      title: item.title || item.Title || item.DatasetKey || "Visual",
      datasetKey: item.datasetKey || item.DatasetKey,
      visualType: item.visualType || item.VisualType || item.DefaultVisual || "clustered-column",
      axisField: item.axisField || item.AxisField || "InstanceName",
      valueField: item.valueField || item.ValueField || "OpenAlertCount",
      legendField: item.legendField || item.LegendField || "",
    }));
    state.biSelectedVisualId = state.biBuilderVisuals[0]?.id || null;
    state.selectedRows.biReports = report;
    setValue("biReportName", report.ReportName || "");
    setValue("biReportDescription", report.ReportDescription || "");
    const shared = document.getElementById("biReportShared");
    if (shared) shared.checked = Boolean(report.IsShared);
  } catch {
    showError("Saved report layout could not be loaded.");
  }
}

function renderBiSavedReportCanvas(report, context) {
  const host = document.getElementById("biInsightsBody");
  if (!host) return;
  Object.keys(state.charts).filter((id) => id.startsWith("biSavedReportChart")).forEach(destroyChart);
  const visuals = state.biBuilderVisuals.length ? state.biBuilderVisuals : [];
  host.innerHTML = `
    <div class="card">
      <div class="card-header">
        <h3>${escapeHtml(report.ReportName || "Saved Report")}</h3>
        <span>${escapeHtml(report.ReportDescription || "Saved BI report canvas")}</span>
      </div>
    </div>
    <div class="bi-report-canvas bi-saved-report-canvas">
      ${visuals.length ? visuals.map((visual, index) => `
        <article class="bi-canvas-visual">
          <div class="bi-canvas-visual-head">
            <strong>${escapeHtml(visual.title || `Visual ${index + 1}`)}</strong>
            <span>${escapeHtml(visual.visualType || "")}</span>
          </div>
          <div id="biSavedReportHost${index}" class="bi-canvas-visual-body"></div>
        </article>
      `).join("") : `<div class="bi-empty-canvas">This saved report does not contain visuals.</div>`}
    </div>
  `;
  visuals.forEach((visual, index) => renderBiBuiltVisual(`biSavedReportHost${index}`, `biSavedReportChart${index}`, visual, context));
}

function countBiReportVisuals(layoutJson) {
  try {
    const layout = JSON.parse(layoutJson || "[]");
    return Array.isArray(layout) ? layout.length : normalizeRows(layout.visuals || layout.Visuals).length;
  } catch { return 0; }
}

function getBiVisualUseCase(type) {
  const map = {
    "stacked-bar": "Compare categories with series contribution.",
    "stacked-column": "Trend totals and severity mix over time.",
    "clustered-bar": "Rank servers, alerts, or capacity hotspots.",
    "clustered-column": "Compare measures across servers or modules.",
    line: "Show movement over time.",
    area: "Show volume trend with emphasis.",
    pie: "Show simple share of total.",
    doughnut: "Executive posture and status mix.",
    scatter: "Compare two numeric signals.",
    bubble: "Compare numeric signals with magnitude.",
    waterfall: "Explain contribution to a total.",
    funnel: "Show staged narrowing or priority queues.",
    treemap: "Show largest contributors in a compact layout.",
    gauge: "Track one KPI against a target.",
    card: "Show one headline number.",
    table: "Inspect row-level detail.",
    matrix: "Compare fields in tabular form.",
  };
  return map[type] || "Build a report visual.";
}

function parseBiThemeColors(themeJson) {
  try {
    const parsed = JSON.parse(themeJson || "{}");
    return normalizeRows(parsed.colors).slice(0, 6);
  } catch { return []; }
}

function getBiBuilderVisualTypes() {
  return [
    { key: "stacked-bar", label: "Stacked Bar", icon: "stack-bar" },
    { key: "stacked-column", label: "Stacked Column", icon: "stack-col" },
    { key: "clustered-bar", label: "Clustered Bar", icon: "bar" },
    { key: "clustered-column", label: "Clustered Column", icon: "col" },
    { key: "line", label: "Line", icon: "line" },
    { key: "area", label: "Area", icon: "area" },
    { key: "pie", label: "Pie", icon: "pie" },
    { key: "doughnut", label: "Doughnut", icon: "donut" },
    { key: "scatter", label: "Scatter", icon: "scatter" },
    { key: "bubble", label: "Bubble", icon: "bubble" },
    { key: "waterfall", label: "Waterfall", icon: "waterfall" },
    { key: "funnel", label: "Funnel", icon: "funnel" },
    { key: "treemap", label: "Treemap", icon: "treemap" },
    { key: "gauge", label: "Gauge", icon: "gauge" },
    { key: "card", label: "Card", icon: "card" },
    { key: "table", label: "Table", icon: "table" },
    { key: "matrix", label: "Matrix", icon: "matrix" },
  ];
}

function renderBiBuilderDesigner(context) {
  const datasetSelect = document.getElementById("biBuildDataset");
  const gallery = document.getElementById("biVisualGallery");
  if (!datasetSelect || !gallery) return;
  const datasets = normalizeRows(context.datasets);
  const selected = state.biBuilderVisuals.find((visual) => visual.id === state.biSelectedVisualId) || state.biBuilderVisuals[0] || {
    id: null,
    title: "New Visual",
    datasetKey: datasets[0]?.DatasetKey || "server-scorecard",
    visualType: "clustered-column",
    axisField: "",
    valueField: "",
    legendField: "",
  };
  state.biSelectedVisualId = selected.id;

  datasetSelect.innerHTML = datasets.map((dataset) => `<option value="${escapeAttr(dataset.DatasetKey)}" ${dataset.DatasetKey === selected.datasetKey ? "selected" : ""}>${escapeHtml(dataset.DisplayName || dataset.DatasetKey)}</option>`).join("");
  gallery.innerHTML = getBiBuilderVisualTypes().map((visual) => `
    <button class="bi-visual-btn ${visual.key === selected.visualType ? "active" : ""}" type="button" data-visual-type="${escapeAttr(visual.key)}" title="${escapeAttr(visual.label)}">
      <span class="bi-visual-icon ${escapeAttr(visual.icon)}"></span>
      <span>${escapeHtml(visual.label)}</span>
    </button>
  `).join("");
  setValue("biBuildTitle", selected.title || "");
  refreshBiBuilderFieldWells(context, selected);
  renderBiBuilderVisualList();
  renderBiBuilderCanvas(context);

  gallery.querySelectorAll(".bi-visual-btn").forEach((button) => {
    button.addEventListener("click", () => {
      const current = collectBiBuilderVisual();
      current.visualType = button.dataset.visualType;
      applyBiBuilderSelection(current);
      renderBiBuilderDesigner(context);
    });
  });
  datasetSelect.onchange = () => {
    const current = collectBiBuilderVisual();
    current.datasetKey = valueOf("biBuildDataset");
    const defaults = getBiDefaultFields(context, current.datasetKey);
    current.axisField = defaults.axisField;
    current.valueField = defaults.valueField;
    current.legendField = defaults.legendField;
    applyBiBuilderSelection(current);
    renderBiBuilderDesigner(context);
  };
  ["biBuildTitle", "biBuildAxis", "biBuildValue", "biBuildLegend"].forEach((id) => {
    const field = document.getElementById(id);
    if (field) field.onchange = () => applyBiBuilderSelection(collectBiBuilderVisual());
  });
  const addButton = document.getElementById("addBiVisual");
  if (addButton) addButton.onclick = () => {
    const base = collectBiBuilderVisual();
    const next = { ...base, id: `bi-v${Date.now()}`, title: base.title || `Visual ${state.biBuilderVisuals.length + 1}` };
    state.biBuilderVisuals.push(next);
    state.biSelectedVisualId = next.id;
    renderBiBuilderDesigner(context);
  };
  const updateButton = document.getElementById("updateBiVisual");
  if (updateButton) updateButton.onclick = () => {
    applyBiBuilderSelection(collectBiBuilderVisual());
    renderBiBuilderDesigner(context);
  };
  const removeButton = document.getElementById("removeBiVisual");
  if (removeButton) removeButton.onclick = () => {
    if (!state.biSelectedVisualId) return;
    state.biBuilderVisuals = state.biBuilderVisuals.filter((visual) => visual.id !== state.biSelectedVisualId);
    state.biSelectedVisualId = state.biBuilderVisuals[0]?.id || null;
    renderBiBuilderDesigner(context);
  };
  const renderButton = document.getElementById("renderBiBuilder");
  if (renderButton) renderButton.onclick = () => {
    applyBiBuilderSelection(collectBiBuilderVisual());
    renderBiBuilderCanvas(context);
  };
}

function refreshBiBuilderFieldWells(context, visual) {
  const fields = getBiFieldsForDataset(context, visual.datasetKey);
  const defaults = getBiDefaultFields(context, visual.datasetKey);
  const axisField = visual.axisField || defaults.axisField;
  const valueField = visual.valueField || defaults.valueField;
  const legendField = visual.legendField || defaults.legendField;
  const optionHtml = (selected, includeBlank = false) => `${includeBlank ? '<option value="">None</option>' : ""}${fields.map((field) => `<option value="${escapeAttr(field)}" ${field === selected ? "selected" : ""}>${escapeHtml(field)}</option>`).join("")}`;
  document.getElementById("biBuildAxis").innerHTML = optionHtml(axisField);
  document.getElementById("biBuildValue").innerHTML = optionHtml(valueField);
  document.getElementById("biBuildLegend").innerHTML = optionHtml(legendField, true);
  const hint = document.getElementById("biFieldHints");
  if (hint) hint.innerHTML = fields.map((field) => `<span>${escapeHtml(field)}</span>`).join("");
}

function collectBiBuilderVisual() {
  const selected = state.biBuilderVisuals.find((visual) => visual.id === state.biSelectedVisualId) || {};
  return {
    id: selected.id || state.biSelectedVisualId || `bi-v${Date.now()}`,
    title: valueOf("biBuildTitle") || selected.title || "Visual",
    datasetKey: valueOf("biBuildDataset") || selected.datasetKey || "server-scorecard",
    visualType: document.querySelector(".bi-visual-btn.active")?.dataset.visualType || selected.visualType || "clustered-column",
    axisField: valueOf("biBuildAxis") || selected.axisField || "",
    valueField: valueOf("biBuildValue") || selected.valueField || "",
    legendField: valueOf("biBuildLegend") || "",
  };
}

function applyBiBuilderSelection(visual) {
  const index = state.biBuilderVisuals.findIndex((item) => item.id === visual.id);
  if (index >= 0) state.biBuilderVisuals[index] = visual;
  else state.biBuilderVisuals.push(visual);
  state.biSelectedVisualId = visual.id;
}

function renderBiBuilderVisualList() {
  const list = document.getElementById("biVisualList");
  if (!list) return;
  if (!state.biBuilderVisuals.length) {
    list.innerHTML = `<div class="details">No visuals on canvas.</div>`;
    return;
  }
  list.innerHTML = state.biBuilderVisuals.map((visual, index) => `
    <button class="bi-visual-list-item ${visual.id === state.biSelectedVisualId ? "active" : ""}" type="button" data-visual-id="${escapeAttr(visual.id)}">
      <strong>${escapeHtml(visual.title || `Visual ${index + 1}`)}</strong>
      <span>${escapeHtml(visual.visualType)} · ${escapeHtml(visual.datasetKey)}</span>
    </button>
  `).join("");
  list.querySelectorAll(".bi-visual-list-item").forEach((button) => {
    button.addEventListener("click", () => {
      state.biSelectedVisualId = button.dataset.visualId;
      const context = window.__lastBiBuilderContext;
      if (context) renderBiBuilderDesigner(context);
    });
  });
}

function renderBiBuilderCanvas(context) {
  window.__lastBiBuilderContext = context;
  const canvas = document.getElementById("biBuilderCanvas");
  if (!canvas) return;
  Object.keys(state.charts).filter((id) => id.startsWith("biBuildChart")).forEach(destroyChart);
  if (!state.biBuilderVisuals.length) {
    canvas.innerHTML = `<div class="bi-empty-canvas">Add a visual to start building the report.</div>`;
    return;
  }
  canvas.innerHTML = state.biBuilderVisuals.map((visual, index) => `
    <article class="bi-canvas-visual ${visual.id === state.biSelectedVisualId ? "selected" : ""}" data-visual-id="${escapeAttr(visual.id)}">
      <div class="bi-canvas-visual-head">
        <strong>${escapeHtml(visual.title || `Visual ${index + 1}`)}</strong>
        <span>${escapeHtml(visual.visualType)}</span>
      </div>
      <div id="biBuildHost${index}" class="bi-canvas-visual-body"></div>
    </article>
  `).join("");
  state.biBuilderVisuals.forEach((visual, index) => renderBiBuiltVisual(`biBuildHost${index}`, `biBuildChart${index}`, visual, context));
  canvas.querySelectorAll(".bi-canvas-visual").forEach((card) => {
    card.addEventListener("click", () => {
      state.biSelectedVisualId = card.dataset.visualId;
      renderBiBuilderDesigner(context);
    });
  });
}

function renderBiBuiltVisual(hostId, chartId, visual, context) {
  renderRowsVisual(hostId, chartId, getBiDatasetRows(context.data, visual.datasetKey), visual);
}

function renderRowsVisual(hostId, chartId, rows, visual) {
  const host = document.getElementById(hostId);
  if (!host) return;
  destroyChart(chartId);
  if (visual.visualType === "table" || visual.visualType === "matrix") {
    host.innerHTML = `<div class="bi-canvas-table-frame" id="${escapeAttr(chartId)}Table"></div>`;
    renderTable(document.getElementById(`${chartId}Table`), rows.slice(0, 100), { key: `${chartId}Table`, pagination: false });
    return;
  }
  if (visual.visualType === "card" || visual.visualType === "gauge") {
    const total = aggregateBiRows(rows, visual).reduce((sum, item) => sum + Number(item.value || 0), 0);
    const pct = Math.max(0, Math.min(100, total));
    host.innerHTML = visual.visualType === "gauge"
      ? `<div class="bi-gauge"><span style="--value:${pct}%"></span><strong>${escapeHtml(Math.round(total))}</strong><em>${escapeHtml(visual.valueField || "Value")}</em></div>`
      : `<div class="bi-big-number">${escapeHtml(Math.round(total))}<span>${escapeHtml(visual.valueField || "Value")}</span></div>`;
    return;
  }
  if (["treemap", "funnel", "waterfall"].includes(visual.visualType)) {
    renderBiTileVisual(host, rows, visual);
    return;
  }
  host.innerHTML = `
    <div class="bi-chart-shell">
      <div class="bi-chart-meta">
        <span>X axis: ${escapeHtml(visual.axisField || "Category")}</span>
        <span>Y axis: ${escapeHtml(visual.valueField || "Count")}</span>
        <span>Legend: ${escapeHtml(visual.legendField || visual.valueField || "Count")}</span>
      </div>
      <div class="bi-chart-frame">
        <canvas id="${escapeAttr(chartId)}"></canvas>
      </div>
    </div>
  `;
  drawBiBuilderChart(chartId, rows, visual);
}

function getBiDatasetRows(data, datasetKey) {
  const source = data || {};
  if (datasetKey === "server-scorecard") return normalizeRows(source.scorecard);
  if (datasetKey === "alert-trends") return normalizeRows(source.alertTrends);
  if (datasetKey === "noisy-alerts") return normalizeRows(source.noisyAlerts);
  if (datasetKey === "capacity-hotspots") return normalizeRows(source.capacity);
  if (datasetKey === "module-health") return normalizeRows(source.moduleHealth);
  if (datasetKey === "ticket-status") return normalizeRows(source.ticketStatus);
  if (datasetKey === "ticket-severity") return normalizeRows(source.ticketSeverity);
  if (datasetKey === "ticket-assignment") return normalizeRows(source.ticketAssignment);
  if (datasetKey === "task-status") return normalizeRows(source.taskStatus);
  if (datasetKey === "task-priority") return normalizeRows(source.taskPriority);
  if (datasetKey === "task-assignment") return normalizeRows(source.taskAssignment);
  if (datasetKey === "application-groups") return normalizeRows(source.applicationGroups);
  if (datasetKey === "application-scorecard") return normalizeRows(source.applicationScorecard);
  if (datasetKey === "cpu-performance") return normalizeRows(source.cpuPerformance);
  if (datasetKey === "memory-performance") return normalizeRows(source.memoryPerformance);
  if (datasetKey === "disk-capacity-trend") return normalizeRows(source.diskCapacityTrend);
  if (datasetKey === "backup-compliance") return normalizeRows(source.backupCompliance);
  if (datasetKey === "wait-profile") return normalizeRows(source.waitProfile);
  if (datasetKey === "top-query-cpu") return normalizeRows(source.topQueryCpu);
  if (datasetKey === "vm-scorecard") return normalizeRows(source.vmScorecard);
  if (datasetKey === "vm-alert-trends") return normalizeRows(source.vmAlertTrends);
  if (datasetKey === "vm-ticket-sla") return normalizeRows(source.vmTicketSla);
  if (datasetKey === "vm-capacity") return normalizeRows(source.vmCapacity);
  if (datasetKey === "vm-process-hotspots") return normalizeRows(source.vmProcessHotspots);
  if (datasetKey === "vm-event-log") return normalizeRows(source.vmEventLog);
  if (datasetKey === "vm-patch-posture") return normalizeRows(source.vmPatchPosture);
  if (datasetKey === "health-posture") {
    const posture = countBy(normalizeRows(source.scorecard), "HealthPosture");
    return Object.entries(posture).map(([Posture, ServerCount]) => ({ Posture, ServerCount }));
  }
  return [];
}

function getBiFieldsForDataset(context, datasetKey) {
  const catalogFields = normalizeRows(context.fields).filter((field) => field.DatasetKey === datasetKey).map((field) => field.FieldName);
  const rowFields = Object.keys(getBiDatasetRows(context.data, datasetKey)[0] || {});
  return [...new Set([...catalogFields, ...rowFields])];
}

function getBiDefaultFields(context, datasetKey) {
  const rows = getBiDatasetRows(context.data, datasetKey);
  const fields = getBiFieldsForDataset(context, datasetKey);
  const row = rows[0] || {};
  const numeric = fields.find((field) => Number.isFinite(Number(row[field]))) || fields.find((field) => /count|percent|pct|used|free|score|value|alert|ticket|task|overdue|closed|server|avg|min|max|hours|cpu|memory|wait|duration/i.test(field)) || fields[1] || fields[0] || "";
  const axis = fields.find((field) => field !== numeric && /date|time|name|instance|posture|severity|priority|status|module|drive|title|application|group|owner|assigned|database|query|wait/i.test(field)) || fields.find((field) => field !== numeric) || fields[0] || "";
  const legend = fields.find((field) => field !== numeric && field !== axis && /severity|priority|status|posture|module|environment|application|group|owner/i.test(field)) || "";
  return { axisField: axis, valueField: numeric, legendField: legend };
}

function aggregateBiRows(rows, visual) {
  const axis = visual.axisField;
  const value = visual.valueField;
  const legend = visual.legendField;
  const method = visual.aggregateMethod || inferBiAggregateMethod(value);
  const scopedRows = scopeBiRowsForVisual(rows, visual);
  const map = new Map();
  scopedRows.forEach((row) => {
    const key = String(row[axis] ?? "Unknown");
    const series = legend ? String(row[legend] ?? "Value") : "Value";
    const id = `${key}::${series}`;
    const current = map.get(id) || { label: key, series, value: 0, count: 0 };
    const numeric = value ? Number(row[value]) : 1;
    const next = Number.isFinite(numeric) ? numeric : 0;
    if (method === "max") current.value = current.count ? Math.max(current.value, next) : next;
    else if (method === "min") current.value = current.count ? Math.min(current.value, next) : next;
    else current.value += next;
    current.count++;
    map.set(id, current);
  });
  return [...map.values()].map((item) => ({
    ...item,
    value: method === "avg" && item.count ? item.value / item.count : item.value,
  }));
}

function scopeBiRowsForVisual(rows, visual) {
  const list = normalizeRows(rows);
  const scope = visual.rowScope || "all";
  if (scope === "all" || list.length <= 1) return list;
  const timeField = getBiTimeField(list, visual);
  if (!timeField) return list;
  if (scope === "latest") {
    const latest = Math.max(...list.map((row) => Date.parse(row[timeField])).filter((value) => Number.isFinite(value)));
    if (!Number.isFinite(latest)) return list;
    return list.filter((row) => Date.parse(row[timeField]) === latest);
  }
  if (scope === "latest-per-axis") {
    const axis = visual.axisField;
    const latestByAxis = new Map();
    list.forEach((row) => {
      const key = String(row[axis] ?? "Unknown");
      const stamp = Date.parse(row[timeField]);
      if (!Number.isFinite(stamp)) return;
      const existing = latestByAxis.get(key);
      if (!existing || stamp > existing.stamp) latestByAxis.set(key, { stamp, rows: [row] });
      else if (stamp === existing.stamp) existing.rows.push(row);
    });
    const scoped = [...latestByAxis.values()].flatMap((item) => item.rows);
    return scoped.length ? scoped : list;
  }
  return list;
}

function getBiTimeField(rows, visual = {}) {
  const sample = normalizeRows(rows)[0] || {};
  const fields = Object.keys(sample);
  return [visual.axisField, "CaptureTime", "CollectionDateTime", "DeadlockTime", "LastRunTime", "CreatedDate", "AlertDate"]
    .find((field) => field && fields.includes(field) && isBiTimeDimensionField(field));
}

function inferBiAggregateMethod(valueField) {
  if (!valueField) return "count";
  if (/^avg|average|percent|pct|ratio|ple|success/i.test(valueField)) return "avg";
  if (/free/i.test(valueField)) return "min";
  if (/size|gb|mb|used|duration|wait|cpu|reads|writes|level|hours|setting|improvement|fragmentation|cost|impact/i.test(valueField)) return "max";
  return "sum";
}

function drawBiBuilderChart(id, rows, visual) {
  const ctx = document.getElementById(id);
  if (!ctx || !window.Chart) return;
  const aggregated = aggregateBiRows(rows, visual);
  const labels = sortBiChartLabels([...new Set(aggregated.map((item) => item.label))], visual);
  const series = [...new Set(aggregated.map((item) => item.series))].slice(0, 12);
  const colors = ["#0969da", "#198754", "#f2a900", "#d73a49", "#6f42c1", "#0a7c72", "#bf3989", "#57606a"];
  const chartType = ["pie", "doughnut", "scatter", "bubble"].includes(visual.visualType) ? visual.visualType : (["line", "area"].includes(visual.visualType) ? "line" : "bar");
  const isHorizontal = visual.visualType.includes("bar") && !visual.visualType.includes("column");
  const stacked = visual.visualType.includes("stacked");
  const axisTitle = visual.axisField || "Category";
  const valueTitle = visual.valueField || "Count";
  const datasets = chartType === "pie" || chartType === "doughnut"
    ? [{ label: valueTitle, data: labels.map((label) => aggregated.filter((item) => item.label === label).reduce((sum, item) => sum + item.value, 0)), backgroundColor: colors }]
    : series.map((name, index) => ({
        label: visual.legendField ? name : valueTitle,
        data: labels.map((label) => {
          const found = aggregated.find((item) => item.label === label && item.series === name);
          const value = found?.value || 0;
          if (chartType === "scatter") return { x: labels.indexOf(label) + 1, y: value };
          if (chartType === "bubble") return { x: labels.indexOf(label) + 1, y: value, r: Math.max(4, Math.min(22, Math.sqrt(Math.abs(value)))) };
          return value;
        }),
        backgroundColor: chartType === "line" ? colors[index % colors.length] + (visual.visualType === "area" ? "33" : "") : colors[index % colors.length],
        borderColor: colors[index % colors.length],
        fill: visual.visualType === "area",
        tension: 0.25,
      }));
  state.charts[id] = new Chart(ctx, {
    type: chartType,
    data: { labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      resizeDelay: 100,
      indexAxis: isHorizontal ? "y" : "x",
      scales: chartType === "pie" || chartType === "doughnut" ? {} : {
        x: { stacked, beginAtZero: isHorizontal, title: { display: true, text: isHorizontal ? valueTitle : axisTitle }, ticks: { callback: function(value) { return truncateBiChartLabel(this.getLabelForValue ? this.getLabelForValue(value) : value); } } },
        y: { stacked, beginAtZero: !isHorizontal, title: { display: true, text: isHorizontal ? axisTitle : valueTitle }, ticks: { callback: function(value) { return isHorizontal ? truncateBiChartLabel(this.getLabelForValue ? this.getLabelForValue(value) : value) : value; } } },
      },
      plugins: {
        legend: { display: true, position: "bottom", labels: { usePointStyle: true, boxWidth: 10 } },
        tooltip: {
          callbacks: {
            title: (items) => `${axisTitle}: ${items?.[0]?.label || ""}`,
            label: (item) => `${item.dataset.label || valueTitle}: ${Number(item.raw?.y ?? item.raw ?? 0).toLocaleString()}`,
          },
        },
      },
    },
  });
}

function sortBiChartLabels(labels, visual) {
  if (!/time|date/i.test(visual.axisField || "")) return labels;
  return [...labels].sort((a, b) => {
    const left = Date.parse(a);
    const right = Date.parse(b);
    if (Number.isNaN(left) || Number.isNaN(right)) return String(a).localeCompare(String(b));
    return left - right;
  });
}

function truncateBiChartLabel(value, maxLength = 34) {
  const text = String(value ?? "");
  return text.length > maxLength ? `${text.slice(0, maxLength - 1)}...` : text;
}

function renderBiTileVisual(host, rows, visual) {
  const aggregated = aggregateBiRows(rows, visual).sort((a, b) => b.value - a.value).slice(0, 12);
  const max = Math.max(1, ...aggregated.map((item) => Math.abs(item.value)));
  if (visual.visualType === "treemap") {
    host.innerHTML = `<div class="bi-treemap">${aggregated.map((item, index) => `<div style="flex:${Math.max(1, Math.abs(item.value))};background:${["#0969da","#198754","#f2a900","#d73a49","#6f42c1"][index % 5]}"><strong>${escapeHtml(item.label)}</strong><span>${escapeHtml(Math.round(item.value))}</span></div>`).join("")}</div>`;
    return;
  }
  host.innerHTML = `<div class="bi-bar-stack">${aggregated.map((item, index) => `<div><span>${escapeHtml(item.label)}</span><strong style="width:${Math.max(4, Math.round(Math.abs(item.value) / max * 100))}%;background:${["#0969da","#198754","#f2a900","#d73a49","#6f42c1"][index % 5]}">${escapeHtml(Math.round(item.value))}</strong></div>`).join("")}</div>`;
}

async function renderCollectorControl() {
  const inst = selectedInstance();
  const schedule = await apiGet(`/api/schedule?instanceId=${selectedInstanceId()}`);
  els.view.innerHTML = `
    <div class="grid two">
      <div class="card">
        <div class="card-header"><h3>Run Collectors</h3></div>
        <div class="toolbar">
          <label class="select-label">Collector Group<select id="collectorGroup"><option>Core</option><option>Advanced</option><option>Daily</option><option selected>All</option></select></label>
          <button class="btn primary" id="runCollectors">Run Now</button>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Schedule</h3><span>${escapeHtml(schedule.text || "")}</span></div>
        <div class="toolbar">
          <label class="select-label">Schedule Type<select id="scheduleType"><option>Manual only</option><option>Every 5 minutes</option><option>Every 30 minutes</option><option>Daily at</option></select></label>
          <input id="dailyAt" type="time" value="02:00">
          <button class="btn primary" id="saveSchedule">Save Schedule</button>
          <button class="btn" id="removeSchedule">Remove Schedule</button>
        </div>
      </div>
    </div>
    <div class="card"><div class="card-header"><h3>Output</h3></div><div id="collectorOutput" class="pre">Ready for ${escapeHtml(inst?.DisplayName || "selected instance")}.</div></div>
  `;
  document.getElementById("runCollectors").addEventListener("click", async () => {
    const payload = { DisplayName: selectedInstance()?.DisplayName, CollectorGroup: valueOf("collectorGroup") };
    document.getElementById("collectorOutput").textContent = "Running collectors...";
    showProcessResult(await apiPost("/api/run-collectors", payload), "collectorOutput");
  });
  document.getElementById("saveSchedule").addEventListener("click", async () => {
    await apiPost("/api/schedule", {
      InstanceID: selectedInstanceId(),
      DisplayName: selectedInstance()?.DisplayName,
      ScheduleType: valueOf("scheduleType"),
      CollectorGroup: valueOf("collectorGroup"),
      DailyAt: valueOf("dailyAt"),
    });
    await renderCollectorControl();
  });
  document.getElementById("removeSchedule").addEventListener("click", async () => {
    await apiDelete(`/api/schedule?instanceId=${selectedInstanceId()}`);
    await renderCollectorControl();
  });
}

async function renderInstanceGroup() {
  els.view.innerHTML = `
    <div class="card">
      <div class="toolbar">
        <label class="select-label">Collector Group<select id="groupCollector"><option>Core</option><option>Advanced</option><option>Daily</option><option>All</option></select></label>
        ${inputField("Instance Filter", "groupFilter")}
        <button class="btn primary" id="runGroup">Run Collectors</button>
      </div>
    </div>
    <div class="card"><div class="card-header"><h3>Execution Output</h3></div><div id="groupOutput" class="pre">Ready.</div></div>
  `;
  document.getElementById("runGroup").addEventListener("click", async () => {
    document.getElementById("groupOutput").textContent = "Running collectors...";
    const result = await apiPost("/api/instance-group/run", {
      CollectorGroup: valueOf("groupCollector"),
      InstanceFilter: valueOf("groupFilter"),
    });
    showProcessResult(result, "groupOutput");
  });
}

async function renderCollectorNodes() {
  const data = await apiGet("/api/collector-nodes");
  const nodes = normalizeRows(data.nodes);
  const instances = normalizeRows(data.instances);
  const assignments = normalizeRows(data.assignments);
  const heartbeats = normalizeRows(data.heartbeats);
  els.view.innerHTML = `
    <div class="grid two">
      <div class="card">
        <div class="card-header"><h3>Collector Nodes</h3><span>Distributed collection workers</span></div>
        <div id="collectorNodesTable"></div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Assign Server</h3><span>Route collection ownership</span></div>
        <div class="form-grid">
          <label class="select-label">Collector Node<select id="collectorNodeSelect">${nodes.map((node) => `<option value="${escapeAttr(node.CollectorNodeID)}">${escapeHtml(node.NodeName)}</option>`).join("")}</select></label>
          <label class="select-label">SQL Instance<select id="collectorInstanceSelect">${instances.map((inst) => `<option value="${escapeAttr(inst.InstanceID)}">${escapeHtml(inst.DisplayName)}</option>`).join("")}</select></label>
          <label class="select-label">Collector Group<select id="collectorAssignmentGroup"><option>All</option><option>Core</option><option>Advanced</option><option>Daily</option></select></label>
          <label class="field inline"><input id="collectorAssignmentEnabled" type="checkbox" checked> Enabled</label>
          <button class="btn primary" id="saveCollectorAssignment">Save Assignment</button>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h3>Central Repo Sync</h3><span>Push only new local repository rows to central</span></div>
      <details class="details" open>
        <summary>How to use</summary>
        <ol>
          <li>Create a linked server from this local repository SQL Server to the central SQL Monitor SQL Server. Deployment can do this with <code>-ConfigureCentralLinkedServer</code>.</li>
          <li>Confirm the central database has the same SQL Monitor schema by running Apply Latest Changes on the central repository.</li>
          <li>Enter the linked server name and central database below, then run Dry run first.</li>
          <li>Run Sync With Central Repo. The stored procedure remaps local InstanceID values to central InstanceID values and inserts only rows that are missing in central history tables.</li>
          <li>For automation, deploy SQL Agent jobs with Central Linked Server configured. The job <code>SQLMonitor - Central Repository Sync</code> will run on schedule.</li>
        </ol>
      </details>
      <div class="toolbar">
        ${inputField("Linked Server", "centralLinkedServer", "SQLMON_CENTRAL")}
        ${inputField("Central Database", "centralDatabase", "DBA_SQLMonitor")}
        ${inputField("Lookback Minutes", "centralLookback", "1440", "number")}
        <label class="field inline"><input id="centralDryRun" type="checkbox"> Dry run</label>
        <button class="btn primary" id="runCentralSync">Sync With Central Repo</button>
      </div>
      <div id="centralSyncOutput" class="pre hidden"></div>
      <div id="centralSyncRunTable"></div>
      <div id="centralSyncTablesTable"></div>
    </div>
    <div class="grid two">
      <div class="card"><div class="card-header"><h3>Assignments</h3></div><div id="collectorAssignmentsTable"></div></div>
      <div class="card"><div class="card-header"><h3>Recent Heartbeats</h3></div><div id="collectorHeartbeatTable"></div></div>
    </div>
  `;
  renderTable(document.getElementById("collectorNodesTable"), nodes, {
    key: "collectorNodes",
    badges: { HealthStatus: statusClass, IsEnabled: activeClass },
  });
  renderTable(document.getElementById("collectorAssignmentsTable"), assignments, {
    key: "collectorAssignments",
    badges: { IsEnabled: activeClass },
  });
  renderTable(document.getElementById("collectorHeartbeatTable"), heartbeats, {
    key: "collectorHeartbeats",
    badges: { Status: statusClass },
  });
  document.getElementById("saveCollectorAssignment")?.addEventListener("click", async () => {
    await apiPost("/api/collector-nodes/assignments", {
      CollectorNodeID: Number(valueOf("collectorNodeSelect")),
      InstanceID: Number(valueOf("collectorInstanceSelect")),
      CollectorGroup: valueOf("collectorAssignmentGroup"),
      IsEnabled: checked("collectorAssignmentEnabled"),
    });
    await renderCollectorNodes();
  });
  document.getElementById("runCentralSync")?.addEventListener("click", async () => {
    const output = document.getElementById("centralSyncOutput");
    output.classList.remove("hidden");
    output.textContent = "Running central repository sync...";
    const result = await apiPost("/api/central-sync/run", {
      CentralLinkedServer: valueOf("centralLinkedServer"),
      CentralDatabase: valueOf("centralDatabase"),
      LookbackMinutes: Number(valueOf("centralLookback") || 1440),
      DryRun: checked("centralDryRun"),
    });
    output.textContent = result.ok ? "Central repository sync completed." : "Central repository sync finished with issues.";
    renderTable(document.getElementById("centralSyncRunTable"), normalizeRows(result.run), {
      key: "centralSyncRun",
      badges: { Status: statusClass },
      pagination: false,
    });
    renderTable(document.getElementById("centralSyncTablesTable"), normalizeRows(result.tables), {
      key: "centralSyncTables",
      badges: { Status: statusClass },
    });
  });
}

async function renderDictionary() {
  const data = await apiGet("/api/dictionary");
  els.view.innerHTML = `<div class="card"><div class="card-header"><h3>SQL Server Dictionary</h3></div><div id="dictionaryTable"></div></div>`;
  renderTable(document.getElementById("dictionaryTable"), data.rows || []);
}

async function renderIssues() {
  const data = await apiGet("/api/issues");
  const rows = normalizeRows(data.rows).map((row, index) => ({
    ...row,
    SopID: Number(row.SopID || row.IssueID || index + 1),
  }));
  const isAdmin = state.currentUser?.RoleName === "Admin";
  const categoryOptions = ["Performance", "Memory", "Storage", "Availability", "Backup", "Security", "Operations", "Configuration", "Monitoring", "Maintenance", "General"];
  const frequencyOptions = ["Rare", "Low", "Medium", "High", "Recurring", "Daily", "Weekly", "Monthly"];

  els.view.innerHTML = `
    <div class="wiki-shell">
      <div class="card wiki-browser">
        <div class="card-header"><h3>Knowledge Wiki</h3><button class="btn" id="wikiNew">New Page</button></div>
        ${inputField("Search", "wikiSearch")}
        <div id="wikiList" class="wiki-list"></div>
      </div>
      <div class="card wiki-workbench">
        <div class="card-header wiki-workbench-header">
          <div>
            <h3>Page Workspace</h3>
            <span id="wikiMeta">Create or update SOPs, notes, links, commands, and reference data.</span>
          </div>
          <div class="tabs wiki-tabs" role="tablist" aria-label="Wiki workspace">
            <button class="tab active" id="wikiEditorTab" type="button" role="tab" aria-selected="true" aria-controls="wikiEditorPanel">Editor</button>
            <button class="tab" id="wikiPreviewTab" type="button" role="tab" aria-selected="false" aria-controls="wikiPreviewPanel">Preview</button>
          </div>
        </div>
        <div id="wikiEditorPanel" class="wiki-tab-panel active" role="tabpanel" aria-labelledby="wikiEditorTab">
          <input id="wikiSopId" type="hidden">
          <input id="wikiIssueId" type="hidden">
          <div class="form-grid compact">
            ${inputField("Title", "wikiTitle")}
            <label class="field">Category
              <select id="wikiCategory">
                ${categoryOptions.map((item) => `<option value="${escapeAttr(item)}">${escapeHtml(item)}</option>`).join("")}
              </select>
            </label>
            <label class="field">Severity
              <select id="wikiSeverity">
                <option>Info</option><option>Low</option><option>Medium</option><option>High</option><option>Critical</option>
              </select>
            </label>
            <label class="field">Frequency
              <select id="wikiFrequency">
                ${frequencyOptions.map((item) => `<option value="${escapeAttr(item)}">${escapeHtml(item)}</option>`).join("")}
              </select>
            </label>
            ${inputField("Owner", "wikiOwner")}
            ${inputField("Tags", "wikiTags")}
          </div>
          <label class="field wiki-description">Description
            <textarea id="wikiDescription" placeholder="Short summary, symptom, scope, or when to use this page."></textarea>
          </label>
          <label class="field wiki-body">Wiki Content
            <textarea id="wikiSopText" placeholder="# Runbook title&#10;&#10;## Checks&#10;- What to inspect&#10;- Query or command to run&#10;&#10;## Resolution&#10;1. Step one&#10;2. Step two"></textarea>
          </label>
          <div class="toolbar">
            <button class="btn primary" id="wikiSave">Save Page</button>
            <button class="btn danger" id="wikiDelete" ${isAdmin ? "" : "disabled"}>Delete</button>
            <button class="btn" id="wikiClear">Clear</button>
          </div>
        </div>
        <div id="wikiPreviewPanel" class="wiki-tab-panel" role="tabpanel" aria-labelledby="wikiPreviewTab" hidden>
          <div class="wiki-preview-head">
            <span class="eyebrow">Preview</span>
            <span id="wikiPreviewStamp"></span>
          </div>
          <div id="wikiPreview" class="wiki-preview"></div>
        </div>
      </div>
    </div>
  `;

  let currentRows = rows;
  const ensureWikiOption = (id, value) => {
    const select = document.getElementById(id);
    const text = String(value || "").trim();
    if (!select || !text) return;
    if (![...select.options].some((option) => option.value === text)) {
      select.add(new Option(text, text));
    }
  };

  const setWikiTab = (tabName) => {
    const isPreview = tabName === "preview";
    document.getElementById("wikiEditorTab").classList.toggle("active", !isPreview);
    document.getElementById("wikiPreviewTab").classList.toggle("active", isPreview);
    document.getElementById("wikiEditorTab").setAttribute("aria-selected", String(!isPreview));
    document.getElementById("wikiPreviewTab").setAttribute("aria-selected", String(isPreview));
    document.getElementById("wikiEditorPanel").hidden = isPreview;
    document.getElementById("wikiPreviewPanel").hidden = !isPreview;
    document.getElementById("wikiEditorPanel").classList.toggle("active", !isPreview);
    document.getElementById("wikiPreviewPanel").classList.toggle("active", isPreview);
    if (isPreview) updateWikiPreview();
  };

  const renderList = () => {
    const query = valueOf("wikiSearch").trim().toLowerCase();
    const filtered = currentRows.filter((row) => {
      const haystack = [row.Title, row.Category, row.Severity, row.Description, row.SOP, row.Owner, row.Tags].join(" ").toLowerCase();
      return !query || haystack.includes(query);
    });
    const host = document.getElementById("wikiList");
    host.innerHTML = filtered.length ? filtered.map((row) => `
      <button class="wiki-page" data-id="${escapeAttr(row.SopID)}">
        <span class="wiki-page-title">${escapeHtml(row.Title || "Untitled")}</span>
        <span class="wiki-page-meta">${escapeHtml([row.Category, row.Owner].filter(Boolean).join(" / ") || "General")}</span>
        <span class="badge ${severityClass(row.Severity || "Info")}">${escapeHtml(row.Severity || "Info")}</span>
      </button>
    `).join("") : `<div class="details">No pages match the current search.</div>`;
    host.querySelectorAll(".wiki-page").forEach((button) => {
      button.addEventListener("click", () => {
        const row = currentRows.find((item) => String(item.SopID) === String(button.dataset.id));
        if (row) loadWikiRow(row);
      });
    });
  };

  const loadWikiRow = (row) => {
    setValue("wikiSopId", row.SopID || "");
    setValue("wikiIssueId", row.IssueID || "");
    setValue("wikiTitle", row.Title || "");
    ensureWikiOption("wikiCategory", row.Category);
    ensureWikiOption("wikiFrequency", row.Frequency);
    setValue("wikiCategory", row.Category || "General");
    setValue("wikiSeverity", row.Severity || "Info");
    setValue("wikiFrequency", row.Frequency || "Medium");
    setValue("wikiOwner", row.Owner || "");
    setValue("wikiTags", row.Tags || "");
    setValue("wikiDescription", row.Description || "");
    setValue("wikiSopText", row.SOP || "");
    document.getElementById("wikiMeta").textContent = row.LastUpdatedBy ? `Last updated by ${row.LastUpdatedBy}` : "Repository-backed wiki page";
    document.querySelectorAll(".wiki-page").forEach((button) => button.classList.toggle("selected", String(button.dataset.id) === String(row.SopID)));
    updateWikiPreview();
  };

  const clearWikiForm = () => {
    ["wikiSopId", "wikiIssueId", "wikiTitle", "wikiOwner", "wikiTags", "wikiDescription", "wikiSopText"].forEach((id) => setValue(id, ""));
    setValue("wikiCategory", "General");
    setValue("wikiFrequency", "Medium");
    setValue("wikiSeverity", "Info");
    document.getElementById("wikiMeta").textContent = "New wiki page";
    document.querySelectorAll(".wiki-page").forEach((button) => button.classList.remove("selected"));
    updateWikiPreview();
  };

  const updateWikiPreview = () => {
    const title = valueOf("wikiTitle") || "Untitled Page";
    const description = valueOf("wikiDescription");
    const content = valueOf("wikiSopText");
    document.getElementById("wikiPreviewStamp").textContent = [valueOf("wikiCategory"), valueOf("wikiOwner")].filter(Boolean).join(" / ");
    document.getElementById("wikiPreview").innerHTML = `
      <h2>${escapeHtml(title)}</h2>
      ${description ? `<p class="wiki-summary">${escapeHtml(description)}</p>` : ""}
      ${renderWikiMarkdown(content || "_Start writing this page in the editor._")}
    `;
  };

  document.getElementById("wikiSearch").addEventListener("input", renderList);
  document.getElementById("wikiNew").addEventListener("click", clearWikiForm);
  document.getElementById("wikiClear").addEventListener("click", clearWikiForm);
  document.getElementById("wikiEditorTab").addEventListener("click", () => setWikiTab("editor"));
  document.getElementById("wikiPreviewTab").addEventListener("click", () => setWikiTab("preview"));
  ["wikiTitle", "wikiOwner", "wikiTags", "wikiDescription", "wikiSopText"].forEach((id) => {
    document.getElementById(id).addEventListener("input", updateWikiPreview);
  });
  ["wikiCategory", "wikiSeverity", "wikiFrequency"].forEach((id) => {
    document.getElementById(id).addEventListener("change", updateWikiPreview);
  });
  document.getElementById("wikiSave").addEventListener("click", async () => {
    const title = valueOf("wikiTitle").trim();
    if (!title) return showError("Title is required.");
    const result = await apiPost("/api/issues", {
      SopID: Number(valueOf("wikiSopId") || 0),
      IssueID: valueOf("wikiIssueId") ? Number(valueOf("wikiIssueId")) : null,
      Title: title,
      Category: valueOf("wikiCategory"),
      Severity: valueOf("wikiSeverity"),
      Description: valueOf("wikiDescription"),
      SOP: valueOf("wikiSopText"),
      Frequency: valueOf("wikiFrequency"),
      Owner: valueOf("wikiOwner"),
      Tags: valueOf("wikiTags"),
    });
    showStatus("Wiki page saved.");
    currentRows = normalizeRows(result.rows).map((row, index) => ({ ...row, SopID: Number(row.SopID || row.IssueID || index + 1) }));
    renderList();
    const saved = currentRows.find((row) => Number(row.SopID) === Number(result.SopID));
    if (saved) loadWikiRow(saved);
  });
  document.getElementById("wikiDelete").addEventListener("click", async () => {
    const sopId = Number(valueOf("wikiSopId") || 0);
    if (!sopId) return showError("Select a wiki page first.");
    if (!confirm("Delete this wiki page?")) return;
    const result = await apiDelete(`/api/issues?sopId=${sopId}`);
    showStatus("Wiki page deleted.");
    currentRows = normalizeRows(result.rows).map((row, index) => ({ ...row, SopID: Number(row.SopID || row.IssueID || index + 1) }));
    renderList();
    if (currentRows.length) loadWikiRow(currentRows[0]);
    else clearWikiForm();
  });

  renderList();
  if (currentRows.length) loadWikiRow(currentRows[0]);
  else clearWikiForm();
}

async function renderWebAgent() {
  const inst = selectedInstance();
  els.view.innerHTML = `
    <div class="agent-shell">
      <div class="card agent-console">
        <div class="card-header">
          <div>
            <h3>Web Solutions Agent</h3>
            <span>Investigate SQL errors, recent alerts, and instance symptoms with ranked remediation guidance.</span>
          </div>
        </div>
        <label class="field agent-query">Error text, symptom, or alert details
          <textarea id="webAgentQuery" placeholder="Paste an error message, alert detail, failed job message, wait symptom, or performance issue."></textarea>
        </label>
        <div class="toolbar">
          <button class="btn primary" id="webAgentSearch">Search Solutions</button>
          <button class="btn" id="webAgentRecent">Load Recent Alerts</button>
          <button class="btn warning" id="webAgentDiagnose">Diagnose Instance</button>
          <button class="btn" id="webAgentClear">Clear</button>
        </div>
      </div>
      <div class="grid three agent-quick-actions">
        ${metricCard("Investigation Scope", inst?.DisplayName || "No instance", "Uses selected dashboard instance")}
        ${metricCard("Sources", "Trusted", "Microsoft Learn and SQL Server community")}
        ${metricCard("Output", "Runbook", "Actions, relevance, links, and alert context")}
      </div>
      <div class="card agent-output-card">
        <div class="card-header">
          <h3>Agent Output</h3>
          <span id="webAgentStamp"></span>
        </div>
        <div id="webAgentResults" class="agent-results">
          <div class="details">Search an error, load recent alerts, or run instance diagnosis.</div>
        </div>
      </div>
    </div>
  `;
  document.getElementById("webAgentSearch").addEventListener("click", async () => {
    const query = valueOf("webAgentQuery").trim();
    if (!query) return showError("Enter an error message or click Load Current Errors first.");
    showStatus("Searching trusted SQL Server solution sources...");
    const data = await apiPost("/api/web-agent/search", { Query: query, DisplayName: inst?.DisplayName });
    renderWebAgentSolutions(data.rows || [], query);
  });
  document.getElementById("webAgentRecent").addEventListener("click", async () => {
    showStatus("Loading recent alerts for agent triage...");
    const data = await apiGet(`/api/web-agent/recent?displayName=${encodeURIComponent(inst?.DisplayName || "")}`);
    renderWebAgentRecent(data.rows || []);
  });
  document.getElementById("webAgentDiagnose").addEventListener("click", async () => {
    if (!inst?.DisplayName) return showError("Select an instance before running diagnosis.");
    showStatus("Diagnosing recent alerts and building solution guidance...");
    try {
      const data = await apiPost("/api/web-agent/diagnose", { DisplayName: inst.DisplayName, MaxAlerts: 3, MaxResultsPerAlert: 3 }, { timeoutMs: 60000 });
      renderWebAgentDiagnostics(data);
    } catch (error) {
      if (!String(error.message || "").includes("Route not found")) throw error;
      showStatus("Diagnosis route is not loaded on the server yet. Using compatible client-side diagnosis...");
      const data = await diagnoseWebAgentFromClient(inst);
      renderWebAgentDiagnostics(data);
    }
  });
  document.getElementById("webAgentClear").addEventListener("click", () => {
    setValue("webAgentQuery", "");
    document.getElementById("webAgentStamp").textContent = "";
    document.getElementById("webAgentResults").innerHTML = `<div class="details">Search an error, load recent alerts, or run instance diagnosis.</div>`;
  });
}

async function diagnoseWebAgentFromClient(inst) {
  const recent = await apiGet(`/api/web-agent/recent?displayName=${encodeURIComponent(inst?.DisplayName || "")}`);
  const alerts = normalizeRows(recent.rows || [])
    .filter((row) => String(row.IsAcknowledged).toLowerCase() !== "true")
    .sort((a, b) => severityRank(a.Severity) - severityRank(b.Severity) || Number(a.AgeMinutes || 0) - Number(b.AgeMinutes || 0))
    .slice(0, 3);
  const findings = [];
  for (const alert of alerts) {
    const query = [alert.AlertTitle, alert.AlertDetails].filter(Boolean).join("\n\n");
    let solutions = [];
    if (query.trim()) {
      try {
        const result = await apiPost("/api/web-agent/search", { Query: query, DisplayName: inst?.DisplayName }, { timeoutMs: 60000 });
        solutions = normalizeRows(result.rows || []).slice(0, 3);
      } catch (error) {
        solutions = [{
          Source: "Agent",
          Title: "Solution lookup failed",
          Type: "Diagnostic",
          Relevance: "Unavailable",
          Confidence: 0,
          Summary: error.message,
          RecommendedActionsText: "Check web connectivity from the dashboard host, then retry the diagnosis.",
        }];
      }
    }
    findings.push({ ...alert, Solutions: solutions });
  }
  return { findings, analyzedAlerts: findings.length, displayName: inst?.DisplayName, compatibilityMode: true };
}

function severityRank(value) {
  const text = String(value || "").toLowerCase();
  if (text.includes("critical")) return 0;
  if (text.includes("high")) return 1;
  if (text.includes("warn")) return 2;
  if (text.includes("medium")) return 3;
  return 4;
}

function renderWebAgentSolutions(rows, query = "") {
  rows = normalizeRows(rows);
  document.getElementById("webAgentStamp").textContent = rows.length ? `${rows.length} solution${rows.length === 1 ? "" : "s"} found` : "No matches";
  const host = document.getElementById("webAgentResults");
  if (!rows.length) {
    host.innerHTML = `<div class="details">No solution matches were returned. Try a fuller error message, error number, or alert details.</div>`;
    return;
  }
  host.innerHTML = `
    <div class="agent-summary">
      <strong>${escapeHtml(query || "Solution search")}</strong>
      <span>Ranked by source trust, SQL Server relevance, and matched error context.</span>
    </div>
    <div class="agent-solution-list">
      ${rows.map((row, index) => renderWebAgentSolutionCard(row, index)).join("")}
    </div>
  `;
  bindAgentCopyButtons(host);
}

function renderWebAgentSolutionCard(row, index = 0) {
  const actions = String(row.RecommendedActionsText || "").split(/\r?\n/).filter(Boolean);
  const copyText = [row.Title, row.Summary, row.RecommendedActionsText, row.Url].filter(Boolean).join("\n\n");
  return `
    <article class="agent-solution-card">
      <div class="agent-solution-head">
        <div>
          <p class="eyebrow">${escapeHtml(row.Source || "Source")} / ${escapeHtml(row.Type || "Solution")}</p>
          <h4>${escapeHtml(row.Title || `Solution ${index + 1}`)}</h4>
        </div>
        <span class="badge ${Number(row.Confidence || 0) >= 75 ? "active" : "warning"}">${escapeHtml(row.Relevance || "Ranked")} ${escapeHtml(row.Confidence || "")}</span>
      </div>
      ${row.Summary ? `<p class="agent-summary-text">${escapeHtml(row.Summary)}</p>` : ""}
      ${row.Snippet ? `<div class="agent-snippet">${escapeHtml(row.Snippet)}</div>` : ""}
      ${actions.length ? `<ol class="agent-actions">${actions.map((action) => `<li>${escapeHtml(action)}</li>`).join("")}</ol>` : ""}
      <div class="agent-card-actions">
        ${row.Url ? `<a class="btn" href="${escapeAttr(row.Url)}" target="_blank" rel="noopener">Open Source</a>` : ""}
        <button class="btn agent-copy-btn" type="button" data-copy="${escapeAttr(copyText)}">Copy Runbook</button>
      </div>
    </article>
  `;
}

function bindAgentCopyButtons(host) {
  host.querySelectorAll(".agent-copy-btn").forEach((button) => {
    button.addEventListener("click", async () => {
      const text = button.dataset.copy || "";
      try {
        await navigator.clipboard?.writeText(text);
        button.textContent = "Copied";
        setTimeout(() => { button.textContent = "Copy Runbook"; }, 1200);
      } catch {
        showToast("Unable to copy runbook text.", true);
      }
    });
  });
}

function renderWebAgentRecent(rows) {
  rows = normalizeRows(rows);
  document.getElementById("webAgentStamp").textContent = `${rows.length} recent alert${rows.length === 1 ? "" : "s"}`;
  const host = document.getElementById("webAgentResults");
  host.innerHTML = `
    <div id="webAgentRecentTable"></div>
    <div class="details agent-selected-alert">Select an alert to search solutions for its title and details.</div>
  `;
  renderTable(document.getElementById("webAgentRecentTable"), rows, {
    selectable: true,
    idField: "AlertID",
    key: "webAgentAlerts",
    columns: ["AlertTime", "Severity", "ModuleName", "AlertTitle", "AgeMinutes"],
    badges: { Severity: severityClass },
    onSelect: (row) => {
      const query = [row.AlertTitle, row.AlertDetails].filter(Boolean).join("\n\n");
      setValue("webAgentQuery", query);
      document.querySelector(".agent-selected-alert").innerHTML = `
        <strong>${escapeHtml(row.AlertTitle || "Selected alert")}</strong>
        <p>${escapeHtml(row.AlertDetails || "")}</p>
        <button class="btn primary" id="webAgentAnalyzeSelected">Analyze Selected Alert</button>
      `;
      document.getElementById("webAgentAnalyzeSelected").addEventListener("click", () => document.getElementById("webAgentSearch").click());
    },
  });
}

function renderWebAgentDiagnostics(data) {
  const findings = normalizeRows(data.findings || []);
  document.getElementById("webAgentStamp").textContent = `${findings.length} alert diagnosis item${findings.length === 1 ? "" : "s"}`;
  const host = document.getElementById("webAgentResults");
  if (!findings.length) {
    host.innerHTML = `<div class="details">No recent alert findings were available for diagnosis.</div>`;
    return;
  }
  host.innerHTML = findings.map((finding) => `
    <section class="agent-diagnosis">
      <div class="agent-diagnosis-head">
        <div>
          <p class="eyebrow">${escapeHtml(finding.ModuleName || "Alert")} / ${escapeHtml(finding.Severity || "")}</p>
          <h4>${escapeHtml(finding.AlertTitle || "Alert diagnosis")}</h4>
        </div>
        <span class="badge ${severityClass(finding.Severity || "")}">${escapeHtml(finding.AgeMinutes || "")} min</span>
      </div>
      <p>${escapeHtml(finding.AlertDetails || "")}</p>
      <div class="agent-solution-list">
        ${normalizeRows(finding.Solutions || []).map((row, index) => renderWebAgentSolutionCard(row, index)).join("") || `<div class="details">No ranked solution returned for this alert.</div>`}
      </div>
    </section>
  `).join("");
  bindAgentCopyButtons(host);
}

async function renderQueryAnalyzer() {
  const inst = selectedInstance();
  els.viewTitle.textContent = "Query Analyzer";
  els.view.innerHTML = `
    <div class="agent-shell">
      <div class="card agent-console">
        <div class="card-header"><div><h3>Query Analyzer</h3><span>Paste a SQL query to analyze for anti-patterns, missing indexes, and optimization opportunities.</span></div></div>
        <label class="field agent-query">SQL Query
          <textarea id="qaQuery" placeholder="Paste your SQL query here..." rows="8"></textarea>
        </label>
        <div class="toolbar">
          <button class="btn primary" id="qaAnalyze">Analyze Query</button>
          <button class="btn" id="qaClear">Clear</button>
        </div>
      </div>
      <div class="grid three agent-quick-actions">
        ${metricCard("Instance", inst?.DisplayName || "No instance", "Uses selected dashboard instance")}
        ${metricCard("Checks", "10+", "Anti-patterns, SARGability, hints, cursors")}
        ${metricCard("Data", "Repository", "Missing indexes & top queries from history")}
      </div>
      <div class="card agent-output-card">
        <div class="card-header"><h3>Analysis Results</h3><span id="qaStamp"></span></div>
        <div id="qaResults" class="agent-results"><div class="details">Paste a SQL query and click Analyze to begin.</div></div>
      </div>
    </div>
  `;
  document.getElementById("qaAnalyze").addEventListener("click", async () => {
    const query = valueOf("qaQuery").trim();
    if (!query) return showError("Enter a SQL query to analyze.");
    showStatus("Analyzing query...");
    try {
      const data = await apiPost("/api/assistant/query-analyze", { SqlText: query, DisplayName: inst?.DisplayName });
      let html = '';
      if (data.Recommendations && data.Recommendations.length > 0) {
        html += '<div class="card" style="margin-bottom:12px"><div class="card-header"><h3>Recommendations</h3></div><ul style="margin:0;padding-left:20px">';
        data.Recommendations.forEach(r => { html += `<li style="margin-bottom:6px">${escapeHtml(r)}</li>`; });
        html += '</ul></div>';
      } else {
        html += '<div class="status-bar">No anti-patterns detected. Query looks clean!</div>';
      }
      if (data.MissingIndexes && data.MissingIndexes.length > 0) {
        html += '<div class="card" style="margin-bottom:12px"><div class="card-header"><h3>Missing Index Recommendations</h3></div>';
        html += '<div id="qaMissingIdxTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("qaMissingIdxTable"), data.MissingIndexes, {
            columns: ["SchemaName", "TableName", "EqualityColumns", "InequalityColumns", "IncludedColumns", "ImpactScore"]
          });
        }, 50);
      }
      if (data.TopQueries && data.TopQueries.length > 0) {
        html += '<div class="card" style="margin-bottom:12px"><div class="card-header"><h3>Similar High-Cost Queries (Repository)</h3></div>';
        html += '<div id="qaTopQueriesTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("qaTopQueriesTable"), data.TopQueries, {
            columns: ["CaptureTime", "QueryPreview", "CpuTime", "ElapsedTime", "Reads", "WaitType"]
          });
        }, 50);
      }
      document.getElementById("qaResults").innerHTML = html;
      document.getElementById("qaStamp").textContent = `Analyzed at ${new Date().toLocaleTimeString()}`;
    } catch (err) { showError(err.message); }
  });
  document.getElementById("qaClear").addEventListener("click", () => {
    setValue("qaQuery", "");
    document.getElementById("qaResults").innerHTML = '<div class="details">Paste a SQL query and click Analyze to begin.</div>';
    document.getElementById("qaStamp").textContent = "";
  });
}

async function renderAlertTriage() {
  const inst = selectedInstance();
  els.viewTitle.textContent = "Alert Triage";
  els.view.innerHTML = `
    <div class="agent-shell">
      <div class="card agent-console">
        <div class="card-header"><div><h3>Alert Triage & Correlation</h3><span>Analyze recent alerts to find patterns, correlations, and related SOPs.</span></div></div>
        <label class="field">Time Range
          <select id="atHours">
            <option value="6">Last 6 hours</option>
            <option value="24" selected>Last 24 hours</option>
            <option value="72">Last 3 days</option>
            <option value="168">Last 7 days</option>
          </select>
        </label>
        <div class="toolbar">
          <button class="btn primary" id="atAnalyze">Analyze Alerts</button>
          <button class="btn" id="atClear">Clear</button>
        </div>
      </div>
      <div id="atResults" class="agent-results"><div class="details">Select a time range and click Analyze to begin.</div></div>
    </div>
  `;
  document.getElementById("atAnalyze").addEventListener("click", async () => {
    if (!inst?.DisplayName) return showError("Select an instance first.");
    const hours = valueOf("atHours") || "24";
    showStatus("Analyzing alerts and correlations...");
    try {
      const data = await apiPost("/api/assistant/alert-triage", { DisplayName: inst.DisplayName, HoursBack: parseInt(hours) });
      let html = `<div class="grid three"><div class="card metric"><div class="label">Total Alerts</div><div class="value">${data.totalAlerts}</div></div>`;
      html += `<div class="card metric"><div class="label">Correlations</div><div class="value">${data.correlations.length}</div></div>`;
      html += `<div class="card metric"><div class="label">Related SOPs</div><div class="value">${data.relatedSOPs.length}</div></div></div>`;
      if (data.correlations && data.correlations.length > 0) {
        html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Correlated Alert Groups</h3></div>';
        html += '<div id="atCorrTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("atCorrTable"), data.correlations, {
            columns: ["ModuleA", "ModuleB", "AlertCountA", "AlertCountB", "TimeSpanMinutes", "Likelihood", "Suggestion"],
            badges: { Likelihood: v => v === 'High' ? 'critical' : v === 'Medium' ? 'warning' : '' }
          });
        }, 50);
      }
      if (data.alerts && data.alerts.length > 0) {
        html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Recent Alerts</h3></div>';
        html += '<div id="atAlertTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("atAlertTable"), data.alerts.slice(0, 25), {
            columns: ["AlertTime", "Severity", "ModuleName", "AlertTitle", "AgeMinutes"],
            badges: { Severity: v => v === 'Critical' ? 'critical' : v === 'High' ? 'warning' : '' }
          });
        }, 50);
      }
      if (data.relatedSOPs && data.relatedSOPs.length > 0) {
        html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Related SOPs</h3></div>';
        html += '<div id="atSopTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("atSopTable"), data.relatedSOPs, {
            columns: ["Title", "Category", "Severity"]
          });
        }, 50);
      }
      document.getElementById("atResults").innerHTML = html;
    } catch (err) { showError(err.message); }
  });
  document.getElementById("atClear").addEventListener("click", () => {
    document.getElementById("atResults").innerHTML = '<div class="details">Select a time range and click Analyze to begin.</div>';
  });
}

async function renderVMHealthAssistant() {
  const inst = selectedInstance();
  els.viewTitle.textContent = "VM Health Report";
  els.view.innerHTML = `<div class="status-bar">Loading VM health report...</div>`;

  if (!inst?.DisplayName) {
    els.view.innerHTML = '<div class="status-bar warning">Select an instance to view its VM health report.</div>';
    return;
  }

  try {
    const data = await apiGet(`/api/assistant/vm-health?displayName=${encodeURIComponent(inst.DisplayName)}`);
    const sample = data.LatestSample && data.LatestSample.length > 0 ? data.LatestSample[0] : null;
    const score = sample ? sample.HealthScore : 0;
    const posture = sample ? sample.HealthPosture : 'Unknown';
    const scoreTone = score >= 85 ? 'active' : score >= 60 ? 'warning' : 'critical';

    const formatPercent = value => value === null || value === undefined || value === "" || Number.isNaN(Number(value))
      ? "N/A"
      : `${Number(value)}%`;

    let html = `
      <section class="ops-hero vm-hero">
        <div>
          <p class="eyebrow">VM Health Report</p>
          <h2>${escapeHtml(inst.DisplayName)}</h2>
          <p>${escapeHtml(data.Summary || 'No data available')}</p>
        </div>
      </section>
      <div class="grid four">
        ${metricCard("Health Score", score, posture, scoreTone)}
        ${metricCard("CPU", formatPercent(sample?.CPUPercent), "Current utilization", sample?.CPUPercent > 80 ? 'warning' : 'active')}
        ${metricCard("Memory", formatPercent(sample?.MemoryUsedPercent), "Current utilization", sample?.MemoryUsedPercent > 85 ? 'warning' : 'active')}
        ${metricCard("Disk", formatPercent(sample?.DiskUsedPercent), "Current utilization", sample?.DiskUsedPercent > 85 ? 'warning' : 'active')}
      </div>
    `;

    if (data.CapacityForecast && data.CapacityForecast.length > 0) {
      html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Capacity Forecast</h3></div>';
      html += '<div id="vmhCapacityTable"></div></div>';
      setTimeout(() => {
        renderTable(document.getElementById("vmhCapacityTable"), data.CapacityForecast, {
          columns: ["MetricName", "CurrentValue", "GrowthRatePerDay", "DaysUntilExhaustion", "ConfidencePercent", "RecommendedAction"],
          badges: { RecommendedAction: v => { const s = String(v).toLowerCase(); return s.includes('urgent') ? 'critical' : s.includes('plan') ? 'warning' : 'active'; } }
        });
      }, 50);
    }

    if (data.RecentAnomalies && data.RecentAnomalies.length > 0) {
      html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Recent Anomalies</h3></div>';
      html += '<div id="vmhAnomalyTable"></div></div>';
      setTimeout(() => {
        renderTable(document.getElementById("vmhAnomalyTable"), data.RecentAnomalies, {
          columns: ["MetricName", "DetectedAt", "ActualValue", "BaselineAvg", "DeviationMultiplier", "Severity"],
          badges: { Severity: v => v === 'Critical' ? 'critical' : 'warning' }
        });
      }, 50);
    }

    if (data.PatchCompliance && data.PatchCompliance.length > 0) {
      const pc = data.PatchCompliance[0];
      html += `<div class="grid three" style="margin-top:12px">
        ${metricCard("Patch Compliance", pc.ComplianceScore + '%', pc.ComplianceStatus, pc.ComplianceScore >= 95 ? 'active' : pc.ComplianceScore >= 80 ? 'warning' : 'critical')}
        ${metricCard("Installed", pc.InstalledPatches + '/' + pc.TotalRequiredPatches, "Required patches installed", "active")}
        ${metricCard("Missing Critical", pc.MissingCriticalPatches, "Required patches not installed", pc.MissingCriticalPatches > 0 ? 'critical' : 'active')}
      </div>`;
    }

    if (data.NetworkAdapters && data.NetworkAdapters.length > 0) {
      html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Network Adapters</h3></div>';
      html += '<div id="vmhNetTable"></div></div>';
      setTimeout(() => {
        renderTable(document.getElementById("vmhNetTable"), data.NetworkAdapters, {
          columns: ["AdapterName", "BytesTotalPerSec", "UtilizationPercent"],
          badges: { UtilizationPercent: v => { const n = Number(v); return n > 80 ? 'critical' : n > 50 ? 'warning' : 'active'; } }
        });
      }, 50);
    }

    if (data.FirewallStatus && data.FirewallStatus.length > 0) {
      html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Firewall Status</h3></div>';
      html += '<div id="vmhFwTable"></div></div>';
      setTimeout(() => {
        renderTable(document.getElementById("vmhFwTable"), data.FirewallStatus, {
          columns: ["ProfileName", "Enabled"],
          badges: { Enabled: v => v === true || v === 'true' ? 'active' : 'critical' }
        });
      }, 50);
    }

    els.view.innerHTML = html;
  } catch (err) {
    els.view.innerHTML = `<div class="status-bar error">Failed to load VM health report: ${escapeHtml(err.message)}</div>`;
  }
}

async function renderIncidentTimeline() {
  const inst = selectedInstance();
  els.viewTitle.textContent = "Incident Timeline";
  els.view.innerHTML = `
    <div class="agent-shell">
      <div class="card agent-console">
        <div class="card-header"><div><h3>Incident Timeline</h3><span>Correlate alerts, anomalies, and service changes across VMs and SQL instances.</span></div></div>
        <label class="field">Time Range
          <select id="itHours">
            <option value="6">Last 6 hours</option>
            <option value="24" selected>Last 24 hours</option>
            <option value="72">Last 3 days</option>
            <option value="168">Last 7 days</option>
          </select>
        </label>
        <div class="toolbar">
          <button class="btn primary" id="itLoad">Load Timeline</button>
          <button class="btn" id="itClear">Clear</button>
        </div>
      </div>
      <div id="itResults" class="agent-results"><div class="details">Select a time range and click Load to view the incident timeline.</div></div>
    </div>
  `;
  document.getElementById("itLoad").addEventListener("click", async () => {
    if (!inst?.DisplayName) return showError("Select an instance first.");
    const hours = valueOf("itHours") || "24";
    showStatus("Building incident timeline...");
    try {
      const data = await apiGet(`/api/assistant/incident-timeline?displayName=${encodeURIComponent(inst.DisplayName)}&hoursBack=${hours}`);
      let html = `<div class="grid three"><div class="card metric"><div class="label">Total Events</div><div class="value">${data.totalEvents}</div></div>`;
      html += `<div class="card metric"><div class="label">Time Range</div><div class="value">${data.timeRangeHours}h</div></div></div>`;
      if (data.timeline && data.timeline.length > 0) {
        html += '<div class="card" style="margin-top:12px"><div class="card-header"><h3>Event Timeline</h3></div>';
        html += '<div id="itTimelineTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("itTimelineTable"), data.timeline, {
            columns: ["EventTime", "EventType", "Severity", "Source", "Description"],
            badges: {
              EventType: v => v === 'Alert' ? 'warning' : v === 'Anomaly' ? 'critical' : v === 'Service' ? 'warning' : '',
              Severity: v => v === 'Critical' ? 'critical' : v === 'High' ? 'warning' : v === 'Warning' ? 'warning' : ''
            }
          });
        }, 50);
      } else {
        html += '<div class="status-bar" style="margin-top:12px">No events found in the selected time range.</div>';
      }
      document.getElementById("itResults").innerHTML = html;
    } catch (err) { showError(err.message); }
  });
  document.getElementById("itClear").addEventListener("click", () => {
    document.getElementById("itResults").innerHTML = '<div class="details">Select a time range and click Load to view the incident timeline.</div>';
  });
}

async function renderConfigDrift() {
  const inst = selectedInstance();
  els.viewTitle.textContent = "Config Drift Detector";
  els.view.innerHTML = `
    <div class="agent-shell">
      <div class="card agent-console">
        <div class="card-header"><div><h3>Configuration Drift Detector</h3><span>Compare current VM/SQL configuration against a baseline date to detect changes.</span></div></div>
        <label class="field">Baseline Date
          <input id="cdBaselineDate" type="date" value="${new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0]}">
        </label>
        <div class="toolbar">
          <button class="btn primary" id="cdDetect">Detect Drift</button>
          <button class="btn" id="cdClear">Clear</button>
        </div>
      </div>
      <div id="cdResults" class="agent-results"><div class="details">Set a baseline date and click Detect to find configuration changes.</div></div>
    </div>
  `;
  document.getElementById("cdDetect").addEventListener("click", async () => {
    if (!inst?.DisplayName) return showError("Select an instance first.");
    const baselineDate = valueOf("cdBaselineDate");
    if (!baselineDate) return showError("Select a baseline date.");
    showStatus("Detecting configuration drift...");
    try {
      const data = await apiPost("/api/assistant/config-drift", { DisplayName: inst.DisplayName, BaselineDate: baselineDate });
      let html = '';
      if (data.Changes && data.Changes.length > 0) {
        html += '<div class="card" style="margin-bottom:12px"><div class="card-header"><h3>Current Configuration</h3></div><ul style="margin:0;padding-left:20px">';
        data.Changes.forEach(c => { html += `<li style="margin-bottom:4px">${escapeHtml(c)}</li>`; });
        html += '</ul></div>';
      }
      if (data.NewPatchesSinceBaseline && data.NewPatchesSinceBaseline.length > 0) {
        html += `<div class="card" style="margin-bottom:12px"><div class="card-header"><h3>New Patches Since Baseline (${data.NewPatchCount})</h3></div>`;
        html += '<div id="cdPatchTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("cdPatchTable"), data.NewPatchesSinceBaseline, {
            columns: ["HotFixID", "InstalledOn", "Description"]
          });
        }, 50);
      }
      if (data.SqlConfigChanges && data.SqlConfigChanges.length > 0) {
        html += '<div class="card" style="margin-bottom:12px"><div class="card-header"><h3>SQL Configuration Changes (Last 30 Days)</h3></div>';
        html += '<div id="cdConfigTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("cdConfigTable"), data.SqlConfigChanges, {
            columns: ["CaptureTime", "ConfigName", "OldValue", "NewValue"]
          });
        }, 50);
      }
      if (data.CurrentAdapters && data.CurrentAdapters.length > 0) {
        html += '<div class="card" style="margin-bottom:12px"><div class="card-header"><h3>Current Network Adapters</h3></div>';
        html += '<div id="cdAdapterTable"></div></div>';
        setTimeout(() => {
          renderTable(document.getElementById("cdAdapterTable"), data.CurrentAdapters, {
            columns: ["AdapterName", "InterfaceDescription"]
          });
        }, 50);
      }
      if (!html) { html = '<div class="status-bar">No configuration drift detected since the baseline date.</div>'; }
      document.getElementById("cdResults").innerHTML = html;
    } catch (err) { showError(err.message); }
  });
  document.getElementById("cdClear").addEventListener("click", () => {
    document.getElementById("cdResults").innerHTML = '<div class="details">Set a baseline date and click Detect to find configuration changes.</div>';
  });
}

async function renderPatchManager() {
  const inst = selectedInstance();
  els.view.innerHTML = `
    <div class="card"><div class="toolbar">
      <button class="btn primary" id="patchRefresh">Refresh Patch Status</button>
      ${inputField("Download Path", "patchPath", "Patches")}
      <label class="field inline"><input id="patchForce" type="checkbox"> Force download</label>
      <button class="btn" id="patchDownload">Download Patches</button>
    </div></div>
    <div class="card"><div class="card-header"><h3>Patch Status</h3></div><div id="patchTable"></div></div>
    <div id="patchOutput" class="pre hidden"></div>
  `;
  const load = async () => {
    const data = await apiGet(`/api/patch/status?displayName=${encodeURIComponent(inst?.DisplayName || "")}`);
    renderTable(document.getElementById("patchTable"), data.rows || [], {
      key: "patchStatus",
      columns: [
        "InstanceName",
        "VersionName",
        "ProductVersion",
        "CurrentPatchKB",
        "LatestPatchKB",
        "RecommendedKB",
        "PatchStatus",
        "CurrentChannel",
        "LatestPatchBuild",
        "LastChecked",
      ],
      badges: { PatchStatus: patchClass },
    });
  };
  document.getElementById("patchRefresh").addEventListener("click", load);
  document.getElementById("patchDownload").addEventListener("click", async () => {
    const result = await apiPost("/api/patch/download", {
      DisplayName: inst?.DisplayName,
      DownloadPath: valueOf("patchPath"),
      Force: checked("patchForce"),
    });
    const out = document.getElementById("patchOutput");
    out.classList.remove("hidden");
    out.textContent = JSON.stringify(result, null, 2);
  });
  await load();
}

async function renderRepositoryUpgrade() {
  const repo = state.bootstrap.repository || {};
  const configured = normalizeRows(state.bootstrap.configuredInstances);
  els.view.innerHTML = `
    <div class="grid two">
      <div class="card">
        <div class="card-header"><h3>Apply Latest Changes</h3><span>${escapeHtml(repo.database || "")}</span></div>
        <div class="grid two">
          ${metricCard("Repository", repo.server || "", repo.database || "")}
          ${metricCard("Configured Servers", configured.length, "Instance list preserved")}
        </div>
        <div class="details" style="margin:12px 0">
          Push the latest application files and database schema changes without recreating the deployment or changing configured monitored servers.
        </div>
        <div class="form-grid">
          ${inputField("Source Path", "latestSourcePath", repo.sourcePath || "")}
          ${inputField("Install Path", "latestInstallPath", repo.installPath || "")}
          <label class="field inline"><input id="latestSqlJobs" type="checkbox" checked> Update SQL Agent jobs</label>
          <label class="field inline"><input id="latestPerInstanceJobs" type="checkbox"> Per-instance jobs</label>
          <label class="field inline"><input id="latestWindowsTasks" type="checkbox"> Windows Scheduled Tasks</label>
          <button class="btn primary" id="applyLatestChanges">Apply Latest App + Database Changes</button>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Latest Module Health</h3></div>
        <div id="upgradeHealthTable"></div>
      </div>
    </div>
    <div id="upgradeOutput" class="pre hidden"></div>
  `;
  try {
    const health = await apiGet("/api/module-health");
    renderTable(document.getElementById("upgradeHealthTable"), health.rows || [], { badges: { Status: statusClass } });
  } catch (error) {
    document.getElementById("upgradeHealthTable").innerHTML = `<div class="status-bar error">${escapeHtml(error.message)}</div>`;
  }
  document.getElementById("applyLatestChanges").addEventListener("click", async () => {
    const out = document.getElementById("upgradeOutput");
    out.classList.remove("hidden");
    out.textContent = "Applying latest application and database changes...";
    const result = await apiPost("/api/application/apply-latest", {
      SourcePath: valueOf("latestSourcePath"),
      InstallPath: valueOf("latestInstallPath"),
      UpdateSqlAgentJobs: checked("latestSqlJobs"),
      ConfigurePerInstanceJobs: checked("latestPerInstanceJobs"),
      ConfigureWindowsTasks: checked("latestWindowsTasks"),
    }, { timeoutMs: 900000 });
    showProcessResult(result, "upgradeOutput");
    const health = await apiGet("/api/module-health");
    renderTable(document.getElementById("upgradeHealthTable"), health.rows || [], { badges: { Status: statusClass } });
  });
}

async function renderDeploymentCenter() {
  const repo = state.bootstrap.repository || {};
  const configured = normalizeRows(state.bootstrap.configuredInstances);
  const instanceText = configured.map((row) => row.SqlInstance || row.DisplayName).filter(Boolean).join("\n");
  els.view.innerHTML = `
    <div class="deploy-center">
      <section class="deploy-hero card">
        <div>
          <p class="eyebrow">Administration</p>
          <h3>Deployment Center</h3>
          <div class="details">Run repository schema updates, application file sync, SQL Agent job setup, and central repository linking without leaving the dashboard.</div>
        </div>
        <div class="deploy-hero-metrics">
          ${metricCard("Repository", repo.server || "", repo.database || "")}
          ${metricCard("Configured Servers", configured.length, "Preserved during updates")}
          ${metricCard("Web Port", repo.webPort || "8090", "Dashboard listener")}
        </div>
      </section>
      <div class="grid two deploy-grid">
        <section class="card deploy-panel">
          <div class="card-header"><h3>Target</h3><span>Repository and install path</span></div>
          <div class="form-grid">
            ${inputField("Repository Server", "deployRepositoryServer", repo.server || "")}
            ${inputField("Repository Database", "deployRepositoryDatabase", repo.database || "DBA_SQLMonitor")}
            ${inputField("Source Path", "deploySourcePath", repo.sourcePath || repo.installPath || "")}
            ${inputField("Install Path", "deployInstallPath", repo.installPath || repo.sourcePath || "")}
            ${inputField("Web Dashboard Port", "deployWebPort", repo.webPort || "8090", "number")}
            <label class="field">Deployment Role
              <select id="deployRole">
                <option value="Standalone">Standalone</option>
                <option value="Central">Central</option>
                <option value="Collector">Collector</option>
              </select>
            </label>
            ${inputField("Job Server", "deployJobServer", "")}
          </div>
          <label class="field textarea-field">Monitored SQL Servers
            <textarea id="deployMonitoredInstances" rows="8">${escapeHtml(instanceText)}</textarea>
          </label>
        </section>
        <section class="card deploy-panel">
          <div class="card-header"><h3>Deployment Options</h3><span>Choose exactly what to push</span></div>
          <div class="deploy-check-grid">
            <label class="field inline"><input id="deployDatabase" type="checkbox" checked> Repository schema and SQL objects</label>
            <label class="field inline"><input id="deployScripts" type="checkbox" checked> Application files and launchers</label>
            <label class="field inline"><input id="deploySqlJobs" type="checkbox" checked> SQL Server Agent jobs</label>
            <label class="field inline"><input id="deployWindowsTasks" type="checkbox"> Windows Scheduled Tasks</label>
            <label class="field inline"><input id="deployPerInstanceJobs" type="checkbox"> Per-server collector jobs</label>
            <label class="field inline"><input id="deploySkipInstances" type="checkbox"> Skip instance configuration</label>
            <label class="field inline"><input id="deployForce" type="checkbox"> Force file overwrite</label>
          </div>
          <div class="form-grid">
            ${inputField("Core Interval Minutes", "deployCoreInterval", "5", "number")}
            ${inputField("Advanced Interval Minutes", "deployAdvancedInterval", "30", "number")}
            ${inputField("Daily Collectors At", "deployDailyTime", "02:00", "time")}
            ${inputField("Retention Purge At", "deployRetentionTime", "03:00", "time")}
            ${inputField("Collector Node Name", "deployCollectorNodeName", "")}
            ${inputField("Collector Site", "deployCollectorSite", "")}
            ${inputField("Collector Tags", "deployCollectorTags", "")}
          </div>
        </section>
      </div>
      <section class="card deploy-panel">
        <div class="card-header"><h3>Central Repository Sync</h3><span>Linked server setup for central monitoring</span></div>
        <div class="form-grid">
          <label class="field inline"><input id="deployConfigureCentral" type="checkbox"> Create or repair linked server</label>
          ${inputField("Linked Server", "deployCentralLinkedServer", "SQLMON_CENTRAL")}
          ${inputField("Central SQL Server", "deployCentralServerInstance", "")}
          ${inputField("Provider", "deployCentralProvider", "MSOLEDBSQL")}
          ${inputField("Sync Interval Minutes", "deployCentralSyncInterval", "15", "number")}
          ${inputField("SQL Login Optional", "deployCentralLogin", "")}
          ${inputField("SQL Password Optional", "deployCentralPassword", "", "password")}
        </div>
      </section>
      <section class="card deploy-actions-panel">
        <div class="deploy-action-grid">
          <button class="btn primary" data-deploy-action="full" type="button">One Click Full Deploy</button>
          <button class="btn primary" data-deploy-action="selected" type="button">Deploy Selected Options</button>
          <button class="btn" data-deploy-action="database" type="button">Database Only</button>
          <button class="btn" data-deploy-action="scripts" type="button">Files Only</button>
          <button class="btn" data-deploy-action="jobs" type="button">Configure Jobs Only</button>
          <button class="btn" data-deploy-action="apply-latest" type="button">Apply Latest Changes</button>
        </div>
      </section>
      <div id="deploymentOutput" class="pre hidden"></div>
    </div>
  `;

  document.querySelectorAll("[data-deploy-action]").forEach((button) => {
    button.addEventListener("click", async () => {
      const action = button.dataset.deployAction;
      const out = document.getElementById("deploymentOutput");
      out.classList.remove("hidden");
      out.textContent = `${button.textContent.trim()} started...`;
      const payload = deploymentPayload(action);
      const result = action === "apply-latest"
        ? await apiPost("/api/application/apply-latest", {
            SourcePath: payload.SourcePath,
            InstallPath: payload.InstallPath,
            UpdateSqlAgentJobs: payload.ConfigureSqlAgentJobs,
            ConfigurePerInstanceJobs: payload.ConfigurePerInstanceJobs,
            ConfigureWindowsTasks: payload.ConfigureWindowsTasks,
          }, { timeoutMs: 900000 })
        : await apiPost("/api/deployment/run", payload, { timeoutMs: 900000 });
      showProcessResult(result, "deploymentOutput");
    });
  });
}

function deploymentPayload(action) {
  return {
    Action: action,
    RepositoryServer: valueOf("deployRepositoryServer"),
    RepositoryDatabase: valueOf("deployRepositoryDatabase"),
    SourcePath: valueOf("deploySourcePath"),
    InstallPath: valueOf("deployInstallPath"),
    WebDashboardPort: Number(valueOf("deployWebPort") || 8090),
    DeploymentRole: valueOf("deployRole"),
    JobServer: valueOf("deployJobServer"),
    MonitoredInstances: valueOf("deployMonitoredInstances"),
    DeployDatabase: checked("deployDatabase"),
    DeployScripts: checked("deployScripts"),
    ConfigureSqlAgentJobs: checked("deploySqlJobs"),
    ConfigureWindowsTasks: checked("deployWindowsTasks"),
    ConfigurePerInstanceJobs: checked("deployPerInstanceJobs"),
    SkipInstanceConfiguration: checked("deploySkipInstances"),
    Force: checked("deployForce"),
    CoreIntervalMinutes: Number(valueOf("deployCoreInterval") || 5),
    AdvancedIntervalMinutes: Number(valueOf("deployAdvancedInterval") || 30),
    DailyTime: valueOf("deployDailyTime") || "02:00",
    RetentionTime: valueOf("deployRetentionTime") || "03:00",
    CollectorNodeName: valueOf("deployCollectorNodeName"),
    CollectorSite: valueOf("deployCollectorSite"),
    CollectorTags: valueOf("deployCollectorTags"),
    ConfigureCentralLinkedServer: checked("deployConfigureCentral"),
    CentralLinkedServer: valueOf("deployCentralLinkedServer"),
    CentralServerInstance: valueOf("deployCentralServerInstance"),
    CentralLinkedServerProvider: valueOf("deployCentralProvider"),
    CentralSyncIntervalMinutes: Number(valueOf("deployCentralSyncInterval") || 15),
    CentralLinkedServerLogin: valueOf("deployCentralLogin"),
    CentralLinkedServerPassword: valueOf("deployCentralPassword"),
  };
}

async function renderOverviewAdmin() {
  const [instances, users] = await Promise.all([
    apiGet("/api/instances"),
    apiGet("/api/users"),
  ]);
  const configuredInstances = normalizeRows(instances.configured);
  const userRows = normalizeRows(users.rows);
  const userInstances = normalizeRows(users.instances);
  const serverGroups = normalizeRows(users.groups);

  const instanceHost = document.getElementById("overviewInstances");
  instanceHost.innerHTML = `
    <div class="card">
      <div class="card-header"><h3>Instance Management</h3><button class="btn" id="ovOpenInstances">Open Module</button></div>
      <div class="form-grid compact">
        ${inputField("Display Name", "ovInstDisplayName")}
        ${inputField("SQL Instance", "ovInstSqlInstance", "SERVER\\INSTANCE")}
        ${inputField("Environment", "ovInstEnv", "Production")}
        <label class="field inline"><input id="ovInstActive" type="checkbox" checked> Active</label>
      </div>
      <div class="toolbar" style="margin-top:12px">
        <button class="btn primary" id="ovSaveInstance">Save Server</button>
        <button class="btn" id="ovNewInstance">New</button>
      </div>
      <div id="ovInstancesTable" style="margin-top:12px"></div>
    </div>
  `;
  renderTable(document.getElementById("ovInstancesTable"), configuredInstances, {
    selectable: true,
    key: "ovInstances",
    idField: "DisplayName",
    badges: { IsActive: activeClass },
    onSelect: (row) => {
      setValue("ovInstDisplayName", row.DisplayName);
      setValue("ovInstSqlInstance", row.SqlInstance);
      setValue("ovInstEnv", row.Environment || "Production");
      document.getElementById("ovInstActive").checked = Boolean(row.IsActive);
    },
  });
  document.getElementById("ovOpenInstances").addEventListener("click", () => setFeature(findFeature("instances")));
  document.getElementById("ovNewInstance").addEventListener("click", () => {
    ["ovInstDisplayName", "ovInstSqlInstance"].forEach((id) => setValue(id, ""));
    setValue("ovInstEnv", "Production");
    document.getElementById("ovInstActive").checked = true;
  });
  document.getElementById("ovSaveInstance").addEventListener("click", async () => {
    const saved = await apiPost("/api/instances", {
      DisplayName: valueOf("ovInstDisplayName"),
      SqlInstance: valueOf("ovInstSqlInstance"),
      RepositoryServer: state.bootstrap.repository.server,
      RepositoryDatabase: state.bootstrap.repository.database,
      Environment: valueOf("ovInstEnv"),
      IsActive: checked("ovInstActive"),
    });
    refreshBootstrapInstances(saved);
    await renderOverview();
  });

  const accessOptions = userInstances.map((inst) =>
    `<label class="field inline"><input class="ov-user-instance" type="checkbox" value="${inst.InstanceID}"> ${escapeHtml(inst.DisplayName)}</label>`
  ).join("");
  const groupOptions = serverGroups.map((group) =>
    `<label class="field inline"><input class="ov-user-group" type="checkbox" value="${group.GroupID}"> ${escapeHtml(group.GroupName)}</label>`
  ).join("");
  const userHost = document.getElementById("overviewUsers");
  userHost.innerHTML = `
    <div class="card">
      <div class="card-header"><h3>User Management</h3><button class="btn" id="ovOpenUsers">Open Module</button></div>
      <div class="form-grid compact">
        ${inputField("User ID", "ovUserId", "", "number", true)}
        ${inputField("User Name", "ovUserName")}
        ${inputField("Display Name", "ovUserDisplayName")}
        ${inputField("Email", "ovUserEmail")}
        ${inputField("Phone", "ovUserPhone")}
        ${inputField("Department", "ovUserDept")}
        <label class="field">Role<select id="ovUserRole"><option>Admin</option><option>AppOwner</option><option>ViewOnly</option><option>Limited</option></select></label>
        ${inputField("Password", "ovUserPassword", "", "password")}
        <label class="field inline"><input id="ovUserActive" type="checkbox" checked> Active</label>
      </div>
      <div class="details" style="margin-top:12px">
        <div class="card-header"><h3>Application Groups</h3></div>
        <div class="grid two">${groupOptions || "<span>No server groups created yet.</span>"}</div>
      </div>
      <div class="details" style="margin-top:12px">
        <div class="card-header"><h3>Direct Servers</h3></div>
        <div class="grid two">${accessOptions || "<span>No repository instances found.</span>"}</div>
      </div>
      <div class="toolbar" style="margin-top:12px">
        <button class="btn primary" id="ovSaveUser">Save User</button>
        <button class="btn" id="ovNewUser">New</button>
      </div>
      <div id="ovUsersTable" style="margin-top:12px"></div>
    </div>
  `;
  renderTable(document.getElementById("ovUsersTable"), userRows, {
    selectable: true,
    key: "ovUsers",
    idField: "UserID",
    badges: { IsActive: activeClass, MustChangePassword: activeClass },
    onSelect: async (row) => {
      setValue("ovUserId", row.UserID);
      setValue("ovUserName", row.UserName);
      setValue("ovUserDisplayName", row.DisplayName);
      setValue("ovUserEmail", row.EmailAddress || "");
      setValue("ovUserPhone", row.PhoneNumber || "");
      setValue("ovUserDept", row.Department || "");
      setValue("ovUserRole", row.RoleName);
      setValue("ovUserPassword", "");
      document.getElementById("ovUserActive").checked = Boolean(row.IsActive);
      const access = await apiGet(`/api/users?userId=${row.UserID}`);
      const ids = new Set((access.access || []).map((item) => String(item.InstanceID)));
      const groupIds = new Set((access.groupAccess || []).map((item) => String(item.GroupID)));
      document.querySelectorAll(".ov-user-instance").forEach((cb) => cb.checked = ids.has(cb.value));
      document.querySelectorAll(".ov-user-group").forEach((cb) => cb.checked = groupIds.has(cb.value));
    },
  });
  document.getElementById("ovOpenUsers").addEventListener("click", () => setFeature(findFeature("users")));
  document.getElementById("ovNewUser").addEventListener("click", () => {
    ["ovUserId", "ovUserName", "ovUserDisplayName", "ovUserPassword"].forEach((id) => setValue(id, ""));
    setValue("ovUserRole", "AppOwner");
    document.getElementById("ovUserActive").checked = true;
    document.querySelectorAll(".ov-user-instance").forEach((cb) => cb.checked = false);
    document.querySelectorAll(".ov-user-group").forEach((cb) => cb.checked = false);
  });
  document.getElementById("ovSaveUser").addEventListener("click", async () => {
    await apiPost("/api/users", {
      UserID: Number(valueOf("ovUserId") || 0),
      UserName: valueOf("ovUserName"),
      DisplayName: valueOf("ovUserDisplayName"),
      EmailAddress: valueOf("ovUserEmail"),
      PhoneNumber: valueOf("ovUserPhone"),
      Department: valueOf("ovUserDept"),
      RoleName: valueOf("ovUserRole"),
      Password: valueOf("ovUserPassword"),
      IsActive: checked("ovUserActive"),
      MustChangePassword: !valueOf("ovUserId"),
      InstanceIDs: [...document.querySelectorAll(".ov-user-instance:checked")].map((cb) => Number(cb.value)),
      GroupIDs: [...document.querySelectorAll(".ov-user-group:checked")].map((cb) => Number(cb.value)),
    });
    await renderOverview();
  });
}

async function renderUsers() {
  const [data, permissions, audit] = await Promise.all([
    apiGet("/api/users"),
    apiGet("/api/security/permissions"),
    apiGet("/api/audit?limit=100"),
  ]);
  const instances = normalizeRows(data.instances);
  const groups = normalizeRows(data.groups);
  const users = normalizeRows(data.rows);
  const serverOptions = instances.map((inst) =>
    `<option value="${escapeAttr(inst.InstanceID)}">${escapeHtml(inst.DisplayName)}${inst.EnvironmentName ? ` (${escapeHtml(inst.EnvironmentName)})` : ""}</option>`
  ).join("");
  const groupUserOptions = users.map((user) =>
    `<label class="field inline"><input class="group-user" type="checkbox" value="${user.UserID}"> ${escapeHtml(user.DisplayName || user.UserName)} <span class="muted">${escapeHtml(user.RoleName || "")}</span></label>`
  ).join("");
  const assignmentUserOptions = users.map((user) =>
    `<option value="${escapeAttr(user.UserID)}">${escapeHtml(user.DisplayName || user.UserName)} - ${escapeHtml(user.RoleName || "")}</option>`
  ).join("");
  els.view.innerHTML = `
    <div class="tabs user-management-tabs" role="tablist" aria-label="User Management workspace">
      <button class="tab active" id="usersEditorTab" type="button" role="tab" aria-selected="true" aria-controls="usersEditorPanel">Create or Update Users</button>
      <button class="tab" id="serverGroupsTab" type="button" role="tab" aria-selected="false" aria-controls="serverGroupsPanel">Application Server Groups</button>
      <button class="tab" id="serverAssignmentTab" type="button" role="tab" aria-selected="false" aria-controls="serverAssignmentPanel">Server Assignment</button>
    </div>
    <section id="usersEditorPanel" class="wiki-tab-panel active" role="tabpanel" aria-labelledby="usersEditorTab">
      <div class="card">
        <div class="card-header"><h3>Create or Update User</h3><span>Create users first. Application access is assigned from the group tab.</span></div>
        <div class="form-grid">
          ${inputField("User ID", "userId", "", "number", true)}
          ${inputField("User Name", "userName")}
          ${inputField("Display Name", "userDisplayName")}
          ${inputField("Email", "userEmail")}
          ${inputField("Phone", "userPhone")}
          ${inputField("Department", "userDept")}
          <label class="field">Role<select id="userRole"><option>Admin</option><option>AppOwner</option><option>ViewOnly</option><option>Limited</option></select></label>
          ${inputField("Password", "userPassword", "", "password")}
          <label class="field inline"><input id="userActive" type="checkbox" checked> Active</label>
          <label class="field inline"><input id="userMustChange" type="checkbox"> Must change password</label>
        </div>
        <div class="toolbar" style="margin-top:12px">
          <button class="btn primary" id="saveUser">Save User</button>
          <button class="btn danger" id="deleteUser">Delete Selected</button>
          <button class="btn" id="newUser">New</button>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Dashboard Users</h3></div>
        <div id="usersTable"></div>
      </div>
      <div class="grid two">
        <div class="card"><div class="card-header"><h3>Role Permissions Matrix</h3></div><div id="permissionsTable"></div></div>
        <div class="card"><div class="card-header"><h3>Audit Trail</h3></div><div id="auditTable"></div></div>
      </div>
    </section>
    <section id="serverGroupsPanel" class="wiki-tab-panel" role="tabpanel" aria-labelledby="serverGroupsTab" hidden>
      <div class="card">
        <div class="card-header"><h3>Application Server Groups</h3><span>Select users and servers to build each application ownership scope.</span></div>
        <div class="form-grid">
          ${inputField("Group ID", "serverGroupId", "", "number", true)}
          ${inputField("Group Name", "serverGroupName", "Payments Production")}
          ${inputField("Application", "serverGroupApp", "Payments")}
          ${inputField("Owner", "serverGroupOwner", "Application Owner")}
          ${inputField("Description", "serverGroupDescription")}
          <label class="field inline"><input id="serverGroupActive" type="checkbox" checked> Active</label>
        </div>
        <div class="details" style="margin-top:12px">
          <div class="card-header"><h3>Users In Application Group</h3><span>Choose application owners or viewers created in the Users tab.</span></div>
          <div class="grid three">${groupUserOptions || "<p>Create users before assigning application groups.</p>"}</div>
        </div>
        <div class="details" style="margin-top:12px">
          <div class="card-header"><h3>Servers In Application Group</h3></div>
          ${multiSelectField("Servers", "serverGroupInstances", serverOptions || "<option disabled>No repository instances found</option>")}
        </div>
        <div class="toolbar" style="margin-top:12px">
          <button class="btn primary" id="saveServerGroup">Save Group</button>
          <button class="btn danger" id="deleteServerGroup">Delete Selected Group</button>
          <button class="btn" id="newServerGroup">New Group</button>
        </div>
        <div id="serverGroupsTable" style="margin-top:12px"></div>
      </div>
    </section>
    <section id="serverAssignmentPanel" class="wiki-tab-panel" role="tabpanel" aria-labelledby="serverAssignmentTab" hidden>
      <div class="card">
        <div class="card-header"><h3>Server Assignment</h3><span>Assign direct server access to users created by admins.</span></div>
        <div class="form-grid">
          <label class="field">User<select id="serverAssignmentUser"><option value="">Select user</option>${assignmentUserOptions}</select></label>
          ${multiSelectField("Servers", "serverAssignmentInstances", serverOptions || "<option disabled>No repository instances found</option>")}
        </div>
        <div class="toolbar" style="margin-top:12px">
          <button class="btn primary" id="saveServerAssignment">Save Assignment</button>
          <button class="btn" id="clearServerAssignment">Clear Selection</button>
        </div>
        <div class="details" id="serverAssignmentSummary" style="margin-top:12px">Select a user to view current direct server assignments.</div>
      </div>
      <div class="card">
        <div class="card-header"><h3>User Access Summary</h3></div>
        <div id="serverAssignmentUsersTable"></div>
      </div>
    </section>
  `;
  const setUserManagementTab = (tabName) => {
    const tabs = {
      users: ["usersEditorTab", "usersEditorPanel"],
      groups: ["serverGroupsTab", "serverGroupsPanel"],
      assignment: ["serverAssignmentTab", "serverAssignmentPanel"],
    };
    Object.entries(tabs).forEach(([key, ids]) => {
      const active = key === tabName;
      document.getElementById(ids[0]).classList.toggle("active", active);
      document.getElementById(ids[0]).setAttribute("aria-selected", String(active));
      document.getElementById(ids[1]).hidden = !active;
      document.getElementById(ids[1]).classList.toggle("active", active);
    });
  };
  document.getElementById("usersEditorTab").addEventListener("click", () => setUserManagementTab("users"));
  document.getElementById("serverGroupsTab").addEventListener("click", () => setUserManagementTab("groups"));
  document.getElementById("serverAssignmentTab").addEventListener("click", () => setUserManagementTab("assignment"));

  renderTable(document.getElementById("serverGroupsTable"), groups, {
    selectable: true,
    key: "serverGroups",
    idField: "GroupID",
    columns: ["GroupName", "ApplicationName", "OwnerName", "ServerCount", "AssignedUserCount", "IsActive"],
    badges: { IsActive: activeClass },
    onSelect: async (row) => {
      setValue("serverGroupId", row.GroupID);
      setValue("serverGroupName", row.GroupName);
      setValue("serverGroupApp", row.ApplicationName || "");
      setValue("serverGroupOwner", row.OwnerName || "");
      setValue("serverGroupDescription", row.Description || "");
      document.getElementById("serverGroupActive").checked = Boolean(row.IsActive);
      const detail = await apiGet(`/api/server-groups?groupId=${row.GroupID}`);
      const memberIds = new Set(normalizeRows(detail.members).map((item) => String(item.InstanceID)));
      const userIds = new Set(normalizeRows(detail.users).map((item) => String(item.UserID)));
      setMultiSelectValues("serverGroupInstances", memberIds);
      document.querySelectorAll(".group-user").forEach((cb) => cb.checked = userIds.has(cb.value));
    },
  });
  renderTable(document.getElementById("permissionsTable"), permissions.rows || []);
  renderTable(document.getElementById("auditTable"), audit.rows || []);
  renderTable(document.getElementById("usersTable"), users, {
    selectable: true,
    key: "users",
    idField: "UserID",
    columns: ["UserName", "DisplayName", "Department", "RoleName", "EffectiveServerCount", "GroupCount", "IsActive", "MustChangePassword"],
    badges: { IsActive: activeClass, MustChangePassword: activeClass },
    onSelect: (row) => {
      setValue("userId", row.UserID);
      setValue("userName", row.UserName);
      setValue("userDisplayName", row.DisplayName);
      setValue("userEmail", row.EmailAddress || "");
      setValue("userPhone", row.PhoneNumber || "");
      setValue("userDept", row.Department || "");
      setValue("userRole", row.RoleName);
      setValue("userPassword", "");
      document.getElementById("userActive").checked = Boolean(row.IsActive);
      document.getElementById("userMustChange").checked = Boolean(row.MustChangePassword);
    },
  });
  renderTable(document.getElementById("serverAssignmentUsersTable"), users, {
    selectable: true,
    key: "serverAssignmentUsers",
    idField: "UserID",
    columns: ["UserName", "DisplayName", "RoleName", "DirectServerCount", "GroupCount", "EffectiveServerCount", "IsActive"],
    badges: { IsActive: activeClass },
    onSelect: (row) => {
      setValue("serverAssignmentUser", row.UserID);
      loadServerAssignmentForUser(row.UserID);
    },
  });
  document.getElementById("newServerGroup").addEventListener("click", () => {
    ["serverGroupId", "serverGroupName", "serverGroupApp", "serverGroupOwner", "serverGroupDescription"].forEach((id) => setValue(id, ""));
    document.getElementById("serverGroupActive").checked = true;
    setMultiSelectValues("serverGroupInstances", []);
    document.querySelectorAll(".group-user").forEach((cb) => cb.checked = false);
    state.selectedRows.serverGroups = null;
  });
  document.getElementById("saveServerGroup").addEventListener("click", async () => {
    await apiPost("/api/server-groups", {
      GroupID: Number(valueOf("serverGroupId") || 0),
      GroupName: valueOf("serverGroupName"),
      ApplicationName: valueOf("serverGroupApp"),
      OwnerName: valueOf("serverGroupOwner"),
      Description: valueOf("serverGroupDescription"),
      IsActive: checked("serverGroupActive"),
      UserIDs: [...document.querySelectorAll(".group-user:checked")].map((cb) => Number(cb.value)),
      InstanceIDs: selectedMultiValues("serverGroupInstances"),
    });
    await renderUsers();
  });
  document.getElementById("deleteServerGroup").addEventListener("click", async () => {
    const row = state.selectedRows.serverGroups;
    if (!row) return showError("Select a server group first.");
    if (!confirm(`Delete server group ${row.GroupName}?`)) return;
    await apiDelete(`/api/server-groups?groupId=${row.GroupID}`);
    await renderUsers();
  });
  document.getElementById("newUser").addEventListener("click", () => {
    ["userId", "userName", "userDisplayName", "userEmail", "userPhone", "userDept", "userPassword"].forEach((id) => setValue(id, ""));
    setValue("userRole", "AppOwner");
    document.getElementById("userActive").checked = true;
    document.getElementById("userMustChange").checked = true;
    state.selectedRows.users = null;
  });
  document.getElementById("saveUser").addEventListener("click", async () => {
    const payload = {
      UserID: Number(valueOf("userId") || 0),
      UserName: valueOf("userName"),
      DisplayName: valueOf("userDisplayName"),
      EmailAddress: valueOf("userEmail"),
      PhoneNumber: valueOf("userPhone"),
      Department: valueOf("userDept"),
      RoleName: valueOf("userRole"),
      Password: valueOf("userPassword"),
      IsActive: checked("userActive"),
      MustChangePassword: checked("userMustChange"),
    };
    await apiPost("/api/users", payload);
    await renderUsers();
  });
  document.getElementById("deleteUser").addEventListener("click", async () => {
    const row = state.selectedRows.users;
    if (!row) return showError("Select a user first.");
    if (!confirm(`Delete user ${row.UserName}?`)) return;
    await apiDelete(`/api/users?userId=${row.UserID}`);
    await renderUsers();
  });
  document.getElementById("serverAssignmentUser").addEventListener("change", (event) => loadServerAssignmentForUser(event.target.value));
  document.getElementById("clearServerAssignment").addEventListener("click", () => setMultiSelectValues("serverAssignmentInstances", []));
  document.getElementById("saveServerAssignment").addEventListener("click", async () => {
    const userId = Number(valueOf("serverAssignmentUser") || 0);
    if (!userId) return showError("Select a user first.");
    await apiPost("/api/user-server-access", {
      UserID: userId,
      InstanceIDs: selectedMultiValues("serverAssignmentInstances"),
    });
    await renderUsers();
  });

  async function loadServerAssignmentForUser(userId) {
    const selectedUserId = Number(userId || 0);
    if (!selectedUserId) {
      setMultiSelectValues("serverAssignmentInstances", []);
      document.getElementById("serverAssignmentSummary").textContent = "Select a user to view current direct server assignments.";
      return;
    }
    const access = await apiGet(`/api/users?userId=${selectedUserId}`);
    const directIds = new Set(normalizeRows(access.access).map((item) => String(item.InstanceID)));
    const effectiveCount = normalizeRows(access.effectiveAccess).length;
    const groupCount = normalizeRows(access.groupAccess).length;
    setMultiSelectValues("serverAssignmentInstances", directIds);
    document.getElementById("serverAssignmentSummary").textContent = `${directIds.size} direct server assignment${directIds.size === 1 ? "" : "s"}; ${groupCount} application group${groupCount === 1 ? "" : "s"}; ${effectiveCount} effective server${effectiveCount === 1 ? "" : "s"}.`;
  }
}

async function renderAccountSecurity() {
  const user = state.currentUser || {};
  const sessionMinutes = state.bootstrap?.settings?.SessionTimeoutMinutes || 30;
  const permissions = await apiGet("/api/security/permissions");
  els.view.innerHTML = `
    ${user.MustChangePassword ? `<div class="status-bar error">Password change is required before continuing.</div>` : ""}
    <div class="grid two">
      <div class="card">
        <div class="card-header"><h3>Password Change</h3><span>${escapeHtml(user.UserName || "")}</span></div>
        <div class="form-grid">
          ${inputField("Current Password", "currentPassword", "", "password")}
          ${inputField("New Password", "newPassword", "", "password")}
          ${inputField("Confirm New Password", "confirmPassword", "", "password")}
        </div>
        <div class="toolbar" style="margin-top:12px">
          <button class="btn primary" id="changePassword">Change Password</button>
        </div>
        <div id="passwordChangeResult" class="details hidden" style="margin-top:12px"></div>
      </div>
      <div class="card">
        <div class="card-header"><h3>Account</h3></div>
        <div class="grid two">
          ${metricCard("Role", user.RoleName || "", "Dashboard permission level")}
          ${metricCard("Session", `${sessionMinutes} min`, "Sliding inactivity timeout")}
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><h3>Role Permissions Matrix</h3></div>
      <div id="accountPermissionsTable"></div>
    </div>
  `;
  renderTable(document.getElementById("accountPermissionsTable"), permissions.rows || []);
  document.getElementById("changePassword").addEventListener("click", async () => {
    const current = valueOf("currentPassword");
    const next = valueOf("newPassword");
    const confirm = valueOf("confirmPassword");
    if (next !== confirm) return showError("New password and confirmation do not match.");
    const result = await apiPost("/api/account/password", { CurrentPassword: current, NewPassword: next });
    ["currentPassword", "newPassword", "confirmPassword"].forEach((id) => setValue(id, ""));
    state.currentUser.MustChangePassword = false;
    const box = document.getElementById("passwordChangeResult");
    box.classList.remove("hidden");
    box.textContent = result.message || "Password changed.";
    showApp();
  });
}

function renderWikiMarkdown(markdown) {
  const lines = String(markdown || "").split(/\r?\n/);
  let html = "";
  let listType = "";
  let inCode = false;
  let code = [];

  const closeList = () => {
    if (listType) {
      html += `</${listType}>`;
      listType = "";
    }
  };
  const inlineFormat = (text) => escapeHtml(text)
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, `<a href="$2" target="_blank" rel="noopener">$1</a>`)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/_([^_]+)_/g, "<em>$1</em>");

  for (const line of lines) {
    if (line.trim().startsWith("```")) {
      if (inCode) {
        html += `<pre class="pre">${escapeHtml(code.join("\n"))}</pre>`;
        code = [];
        inCode = false;
      } else {
        closeList();
        inCode = true;
      }
      continue;
    }
    if (inCode) {
      code.push(line);
      continue;
    }
    if (!line.trim()) {
      closeList();
      continue;
    }
    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) {
      closeList();
      const level = heading[1].length + 2;
      html += `<h${level}>${inlineFormat(heading[2])}</h${level}>`;
      continue;
    }
    const bullet = line.match(/^\s*[-*]\s+(.+)$/);
    if (bullet) {
      if (listType !== "ul") {
        closeList();
        html += "<ul>";
        listType = "ul";
      }
      html += `<li>${inlineFormat(bullet[1])}</li>`;
      continue;
    }
    const number = line.match(/^\s*\d+\.\s+(.+)$/);
    if (number) {
      if (listType !== "ol") {
        closeList();
        html += "<ol>";
        listType = "ol";
      }
      html += `<li>${inlineFormat(number[1])}</li>`;
      continue;
    }
    closeList();
    html += `<p>${inlineFormat(line)}</p>`;
  }
  closeList();
  if (inCode) html += `<pre class="pre">${escapeHtml(code.join("\n"))}</pre>`;
  return html;
}

function renderTable(container, rows, options = {}) {
  rows = normalizeRows(rows);
  if (!rows.length) {
    container.innerHTML = `<div class="details">No rows returned.</div>`;
    return;
  }
  const columns = options.columns || Object.keys(rows[0]);
  const labels = options.labels || {};
  const tableKey = options.key || container.id || "default";
  const storageKey = `sqlMonitorTablePageSize:${tableKey}`;
  if (!state.tablePrefs[tableKey]) {
    state.tablePrefs[tableKey] = {
      page: 1,
      pageSize: Number(localStorage.getItem(storageKey) || 25),
    };
  }
  const prefs = state.tablePrefs[tableKey];
  const allowedSizes = [10, 25, 50, 100, 250];
  if (!allowedSizes.includes(Number(prefs.pageSize))) prefs.pageSize = 25;
  const pageSize = options.pagination === false ? rows.length : Number(prefs.pageSize);
  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  prefs.page = Math.min(Math.max(1, Number(prefs.page || 1)), totalPages);
  const start = (prefs.page - 1) * pageSize;
  const visibleRows = rows.slice(start, start + pageSize);
  const template = document.getElementById("tableTemplate").content.cloneNode(true);
  const thead = template.querySelector("thead");
  const tbody = template.querySelector("tbody");
  const hasActions = options.actions && options.actions.length > 0;
  thead.innerHTML = `<tr>${columns.map((col) => `<th>${escapeHtml(labels[col] || col)}</th>`).join("")}${hasActions ? "<th>Actions</th>" : ""}</tr>`;
  tbody.innerHTML = visibleRows.map((row, index) => {
    const cells = columns.map((col) => `<td>${formatCell(row[col], col, options, row, start + index)}</td>`).join("");
    const actions = hasActions ? `<td>${options.actions.map((a, ai) => `<button class="btn sm" data-action="${ai}" type="button">${escapeHtml(a.label)}</button>`).join(" ")}</td>` : "";
    return `<tr data-index="${start + index}">${cells}${actions}</tr>`;
  }).join("");
  container.innerHTML = "";
  if (options.pagination !== false) {
    const pager = document.createElement("div");
    pager.className = "table-pager";
    pager.innerHTML = `
      <div class="table-pager-summary">${escapeHtml(rows.length)} rows · page ${escapeHtml(prefs.page)} of ${escapeHtml(totalPages)}</div>
      <div class="table-pager-controls">
        <button class="btn table-prev" type="button" ${prefs.page <= 1 ? "disabled" : ""}>Previous</button>
        <button class="btn table-next" type="button" ${prefs.page >= totalPages ? "disabled" : ""}>Next</button>
        <label class="select-label">Rows<select class="table-page-size">
          ${allowedSizes.map((size) => `<option value="${size}" ${size === pageSize ? "selected" : ""}>${size}</option>`).join("")}
        </select></label>
      </div>
    `;
    container.appendChild(pager);
  }
  container.appendChild(template);
  container.querySelectorAll("[data-table-link]").forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const col = link.dataset.tableLink;
      const row = rows[Number(link.dataset.index)];
      if (options.linkActions && options.linkActions[col]) options.linkActions[col](row);
    });
  });
  container.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const actionIndex = Number(btn.dataset.action);
      const rowIdx = Number(btn.closest("tr").dataset.index);
      if (options.actions && options.actions[actionIndex]) {
        options.actions[actionIndex].handler(rows[rowIdx]);
      }
    });
  });
  const rerender = () => renderTable(container, rows, options);
  container.querySelector(".table-prev")?.addEventListener("click", () => {
    prefs.page = Math.max(1, prefs.page - 1);
    rerender();
  });
  container.querySelector(".table-next")?.addEventListener("click", () => {
    prefs.page = Math.min(totalPages, prefs.page + 1);
    rerender();
  });
  container.querySelector(".table-page-size")?.addEventListener("change", (event) => {
    prefs.pageSize = Number(event.target.value || 25);
    prefs.page = 1;
    localStorage.setItem(storageKey, String(prefs.pageSize));
    rerender();
  });
  if (options.selectable) {
    container.querySelectorAll("tbody tr").forEach((tr) => {
      tr.addEventListener("click", () => {
        container.querySelectorAll("tr").forEach((row) => row.classList.remove("selected"));
        tr.classList.add("selected");
        const row = rows[Number(tr.dataset.index)];
        state.selectedRows[options.key || "default"] = row;
        if (options.onSelect) options.onSelect(row);
      });
    });
  }
}

function normalizeRows(rows) {
  if (!rows) return [];
  if (Array.isArray(rows)) return rows;
  if (typeof rows === "object") return [rows];
  return [];
}

function formatCell(value, col, options, row, rowIndex) {
  if (value === null || value === undefined) return "";
  const badges = options.badges || {};
  if (options.linkActions && options.linkActions[col]) {
    return `<a href="#" class="table-link" data-table-link="${escapeAttr(col)}" data-index="${escapeAttr(rowIndex)}">${escapeHtml(value)}</a>`;
  }
  if (badges[col]) return `<span class="badge ${badges[col](value)}">${escapeHtml(value)}</span>`;
  if (col === "RepeatCount") {
    const count = Number(value || 1);
    const tone = count > 1 ? "warning" : "";
    return `<span class="badge ${tone}">${escapeHtml(count)}</span>`;
  }
  const text = formatDisplayValue(value);
  if (/url$/i.test(col) && /^https?:\/\//i.test(text)) {
    return `<a href="${escapeAttr(text)}" target="_blank" rel="noopener">Open</a>`;
  }
  if (text.length > 220) return `<span title="${escapeHtml(text)}">${escapeHtml(text.slice(0, 220))}...</span>`;
  return escapeHtml(text);
}

function formatDisplayValue(value) {
  if (value === null || value === undefined) return "";
  if (value instanceof Date) return value.toLocaleString();
  if (typeof value === "object") {
    if (value.DateTime) return String(value.DateTime);
    if (value.dateTime) return String(value.dateTime);
    if (value.value) return String(value.value);
    if (value.DisplayValue) return String(value.DisplayValue);
    if (value.ToString && typeof value.ToString === "string") return value.ToString;
    return JSON.stringify(value);
  }
  return String(value);
}

function metricCard(label, value, hint, tone = "") {
  return `<div class="card metric ${tone}"><div class="label">${escapeHtml(label)}</div><div class="value">${escapeHtml(value)}</div><div class="hint">${escapeHtml(hint || "")}</div></div>`;
}

function signalCard(label, value, hint, tone = "", progress = null) {
  const hasProgress = progress !== null && progress !== undefined && !Number.isNaN(Number(progress));
  const pct = hasProgress ? Math.max(0, Math.min(100, Number(progress))) : 0;
  return `
    <div class="card ops-signal ${tone}">
      <div class="ops-signal-top">
        <span>${escapeHtml(label)}</span>
        <strong>${escapeHtml(value)}</strong>
      </div>
      <p>${escapeHtml(hint || "")}</p>
      ${hasProgress ? `<div class="ops-progress"><span style="width:${pct}%"></span></div>` : ""}
    </div>
  `;
}

function countBy(rows, key) {
  return normalizeRows(rows).reduce((acc, row) => {
    const value = row[key] || "Unknown";
    acc[value] = (acc[value] || 0) + 1;
    return acc;
  }, {});
}

function calculateBiHealthScore(rows) {
  const list = normalizeRows(rows);
  if (!list.length) return 100;
  const total = list.reduce((sum, row) => {
    const posture = String(row.HealthPosture || "").toLowerCase();
    if (posture === "healthy") return sum + 100;
    if (posture === "warning") return sum + 60;
    if (posture === "critical") return sum + 15;
    return sum + 40;
  }, 0);
  return Math.round(total / list.length);
}

function inputField(label, id, value = "", type = "text", readonly = false) {
  return `<label class="field">${escapeHtml(label)}<input id="${id}" type="${type}" value="${escapeAttr(value)}" ${readonly ? "readonly" : ""}></label>`;
}

function multiSelectField(label, id, optionsHtml) {
  return `<label class="field multi-select-field">${escapeHtml(label)}<select id="${escapeAttr(id)}" class="multi-select" multiple size="8">${optionsHtml}</select></label>`;
}

function selectedMultiValues(id) {
  const select = document.getElementById(id);
  if (!select) return [];
  return [...select.selectedOptions].map((option) => Number(option.value)).filter((value) => value > 0);
}

function setMultiSelectValues(id, values) {
  const select = document.getElementById(id);
  if (!select) return;
  const selected = new Set([...values].map((value) => String(value)));
  [...select.options].forEach((option) => {
    option.selected = selected.has(String(option.value));
  });
}

function showAlertDetails(row) {
  const box = document.getElementById("alertDetails");
  if (!box) return;
  box.classList.remove("hidden");
  box.innerHTML = `
    <h3>${escapeHtml(row.AlertTitle || "Alert Details")}</h3>
    <p><strong>Repeats:</strong> ${escapeHtml(row.RepeatCount || 1)} | <strong>First seen:</strong> ${escapeHtml(row.FirstAlertTime || row.AlertTime || "")} | <strong>Last seen:</strong> ${escapeHtml(row.LastRepeatedAt || row.AlertTime || "")}</p>
    <p>${escapeHtml(row.AlertDetails || "")}</p>
  `;
}

function drawBarChart(id, rows, labelField, valueField, label, color) {
  // Ensure rows is an array before using .map()
  rows = normalizeRows(rows);
  destroyChart(id);
  const ctx = document.getElementById(id);
  if (!ctx || !window.Chart) return;
  state.charts[id] = new Chart(ctx, {
    type: "bar",
    data: {
      labels: rows.map((r) => r[labelField]),
      datasets: [{ label, data: rows.map((r) => Number(r[valueField] || 0)), backgroundColor: color }],
    },
    options: { responsive: true, maintainAspectRatio: false },
  });
}

function drawLineChart(id, rows, labelField, valueField, label, color) {
  // Ensure rows is an array before using .map()
  rows = normalizeRows(rows);
  destroyChart(id);
  const ctx = document.getElementById(id);
  if (!ctx || !window.Chart) return;
  state.charts[id] = new Chart(ctx, {
    type: "line",
    data: {
      labels: rows.map((r) => r[labelField]),
      datasets: [{ label, data: rows.map((r) => Number(r[valueField] || 0)), borderColor: color, backgroundColor: color + "22", tension: 0.25, fill: true }],
    },
    options: { responsive: true, maintainAspectRatio: false },
  });
}

function drawDoughnutChart(id, rows, labelField, valueField, colors) {
  destroyChart(id);
  const ctx = document.getElementById(id);
  if (!ctx || !window.Chart) return;
  state.charts[id] = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: rows.map((r) => r[labelField]),
      datasets: [{ data: rows.map((r) => Number(r[valueField] || 0)), backgroundColor: colors }],
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } },
  });
}

function drawStackedAlertTrend(id, rows) {
  destroyChart(id);
  const ctx = document.getElementById(id);
  if (!ctx || !window.Chart) return;
  const normalized = normalizeRows(rows);
  const labels = [...new Set(normalized.map((row) => row.AlertDate))];
  const severities = ["Critical", "Warning", "Info"];
  const colors = { Critical: "#d73a49", Warning: "#f2a900", Info: "#0969da" };
  state.charts[id] = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: severities.map((severity) => ({
        label: severity,
        backgroundColor: colors[severity],
        data: labels.map((label) => {
          const row = normalized.find((item) => String(item.AlertDate) === String(label) && String(item.Severity) === severity);
          return Number(row?.AlertCount || 0);
        }),
      })),
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true } },
      plugins: { legend: { position: "bottom" } },
    },
  });
}

function drawWindowsTrendChart(id, rows, valueField, label, color) {
  destroyChart(id);
  const ctx = document.getElementById(id);
  if (!ctx || !window.Chart) return;
  rows = normalizeRows(rows);
  // Group rows by DisplayName for separate line series per VM target
  const targets = [...new Set(rows.map((r) => r.DisplayName).filter(Boolean))];
  const labels = [...new Set(rows.map((r) => r.CaptureTime).filter(Boolean))].sort();
  if (!labels.length) {
    ctx.parentElement.innerHTML = '<div class="details">No trend data available yet.</div>';
    return;
  }
  // Build lookup: DisplayName -> { CaptureTime -> value }
  const lookup = {};
  rows.forEach((r) => {
    const dn = r.DisplayName;
    const ct = r.CaptureTime;
    if (!dn || !ct) return;
    if (!lookup[dn]) lookup[dn] = {};
    lookup[dn][ct] = Number(r[valueField] || 0);
  });
  const datasets = targets.map((target, index) => {
    const hue = (index * 47 + 150) % 360;
    const border = color || `hsl(${hue}, 60%, 45%)`;
    return {
      label: target,
      data: labels.map((t) => lookup[target]?.[t] ?? null),
      borderColor: border,
      backgroundColor: border + "22",
      tension: 0.25,
      fill: false,
      spanGaps: false,
      pointRadius: 2,
    };
  });
  state.charts[id] = new Chart(ctx, {
    type: "line",
    data: { labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          ticks: { maxTicksLimit: 12, maxRotation: 45 },
          title: { display: true, text: "Capture Time" },
        },
        y: {
          beginAtZero: true,
          title: { display: true, text: label },
        },
      },
      plugins: {
        legend: { position: "bottom", labels: { boxWidth: 12, font: { size: 10 } } },
        tooltip: {
          mode: "index",
          intersect: false,
        },
      },
      interaction: { mode: "nearest", axis: "x", intersect: false },
    },
  });
}

function destroyChart(id) {
  if (state.charts[id]) {
    state.charts[id].destroy();
    delete state.charts[id];
  }
}

function showProcessResult(result, targetId = "collectorOutput") {
  const target = document.getElementById(targetId);
  if (!target) return;
  target.textContent = `Exit Code: ${result.exitCode}\n\nOUTPUT:\n${result.output || ""}\n\nERROR:\n${result.error || ""}`;
}

function exportTableCsv(containerId, filename) {
  const table = document.querySelector(`#${containerId} table`);
  if (!table) return;
  const lines = [...table.querySelectorAll("tr")].map((tr) =>
    [...tr.children].map((cell) => `"${cell.textContent.replace(/"/g, '""')}"`).join(",")
  );
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function exportRowsCsv(rows, filename) {
  rows = normalizeRows(rows);
  const columns = ["DisplayName", "SqlInstance", "RepositoryServer", "RepositoryDatabase", "Environment", "IsActive"];
  const lines = [columns.join(",")].concat(rows.map((row) =>
    columns.map((col) => `"${String(row[col] ?? "").replace(/"/g, '""')}"`).join(",")
  ));
  const blob = new Blob([lines.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function exportBiManagementExcel(report) {
  const period = report?.period || valueOf("biManagementPeriod") || "Weekly";
  const sheets = [
    { name: "Executive Summary", rows: normalizeRows(report?.summary) },
    { name: "Alert Details", rows: normalizeRows(report?.alertDetails) },
    { name: "Chart Alerts Trend", rows: withExcelVisualBars(report?.alertTrend) },
    { name: "Chart Alerts Severity", rows: withExcelVisualBars(report?.alertSeverity) },
    { name: "Chart Alerts Module", rows: withExcelVisualBars(report?.alertModule) },
    { name: "Ticket Details", rows: normalizeRows(report?.ticketDetails) },
    { name: "Chart Tickets Trend", rows: withExcelVisualBars(report?.ticketTrend) },
    { name: "Chart Tickets Status", rows: withExcelVisualBars(report?.ticketStatus) },
    { name: "Chart Tickets Severity", rows: withExcelVisualBars(report?.ticketSeverity) },
    { name: "Chart Tickets Owner", rows: withExcelVisualBars(report?.ticketAssignment) },
    { name: "Task Details", rows: normalizeRows(report?.taskDetails) },
    { name: "Chart Tasks Trend", rows: withExcelVisualBars(report?.taskTrend) },
    { name: "Chart Tasks Status", rows: withExcelVisualBars(report?.taskStatus) },
    { name: "Chart Tasks Priority", rows: withExcelVisualBars(report?.taskPriority) },
    { name: "Chart Tasks Owner", rows: withExcelVisualBars(report?.taskAssignment) },
  ];
  const workbook = buildExcelXmlWorkbook(sheets);
  const stamp = new Date().toISOString().slice(0, 10);
  downloadBlob(workbook, `SQLMonitor-Management-${period}-${stamp}.xls`, "application/vnd.ms-excel;charset=utf-8");
}

function withExcelVisualBars(rows) {
  const list = normalizeRows(rows);
  if (!list.length) return list;
  const fields = Object.keys(list[0] || {});
  const valueField = fields.find((field) => /count$/i.test(field)) || fields.find((field) => /repeat|overdue|avg|minutes|total|value/i.test(field));
  if (!valueField) return list;
  const values = list.map((row) => Number(row[valueField] || 0)).filter((value) => Number.isFinite(value));
  const max = Math.max(1, ...values);
  return list.map((row) => {
    const value = Number(row[valueField] || 0);
    const width = Math.max(1, Math.round((Number.isFinite(value) ? value : 0) / max * 40));
    return { ...row, VisualBar: "#".repeat(width) };
  });
}

function buildExcelXmlWorkbook(sheets) {
  const worksheetXml = sheets.map((sheet) => buildExcelXmlWorksheet(sheet.name, sheet.rows)).join("");
  return `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <Styles>
  <Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#0B6FCB" ss:Pattern="Solid"/></Style>
  <Style ss:ID="Text"><Alignment ss:Vertical="Top" ss:WrapText="1"/></Style>
  <Style ss:ID="Number"><NumberFormat ss:Format="General"/></Style>
 </Styles>
 ${worksheetXml}
</Workbook>`;
}

function buildExcelXmlWorksheet(name, rows) {
  rows = normalizeRows(rows);
  const columns = getExcelColumns(rows);
  const safeName = sanitizeExcelSheetName(name);
  const header = columns.length
    ? `<Row>${columns.map((column) => `<Cell ss:StyleID="Header"><Data ss:Type="String">${xmlEscape(column)}</Data></Cell>`).join("")}</Row>`
    : `<Row><Cell ss:StyleID="Header"><Data ss:Type="String">Message</Data></Cell></Row>`;
  const body = rows.length
    ? rows.map((row) => `<Row>${columns.map((column) => buildExcelXmlCell(row[column])).join("")}</Row>`).join("")
    : `<Row><Cell ss:StyleID="Text"><Data ss:Type="String">No data returned for this worksheet.</Data></Cell></Row>`;
  const columnXml = (columns.length ? columns : ["Message"]).map(() => `<Column ss:AutoFitWidth="1" ss:Width="150"/>`).join("");
  return `<Worksheet ss:Name="${xmlEscape(safeName)}"><Table>${columnXml}${header}${body}</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>1</SplitHorizontal><TopRowBottomPane>1</TopRowBottomPane><ActivePane>2</ActivePane></WorksheetOptions></Worksheet>`;
}

function getExcelColumns(rows) {
  const ordered = [];
  rows.forEach((row) => {
    Object.keys(row || {}).forEach((key) => {
      if (!ordered.includes(key)) ordered.push(key);
    });
  });
  return ordered;
}

function buildExcelXmlCell(value) {
  if (value === null || value === undefined) return `<Cell ss:StyleID="Text"><Data ss:Type="String"></Data></Cell>`;
  if (typeof value === "number" && Number.isFinite(value)) return `<Cell ss:StyleID="Number"><Data ss:Type="Number">${value}</Data></Cell>`;
  if (typeof value === "boolean") return `<Cell ss:StyleID="Text"><Data ss:Type="String">${value ? "Yes" : "No"}</Data></Cell>`;
  const text = String(value);
  if (/^-?\d+(\.\d+)?$/.test(text) && text.length < 16) return `<Cell ss:StyleID="Number"><Data ss:Type="Number">${xmlEscape(text)}</Data></Cell>`;
  return `<Cell ss:StyleID="Text"><Data ss:Type="String">${xmlEscape(text)}</Data></Cell>`;
}

function sanitizeExcelSheetName(name) {
  const safe = String(name || "Sheet").replace(/[\[\]:*?/\\]/g, " ").replace(/\s+/g, " ").trim() || "Sheet";
  return safe.slice(0, 31);
}

function xmlEscape(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function downloadBlob(content, filename, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function parseServerImportText(text) {
  const lines = String(text || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (!lines.length) return [];
  const first = splitDelimitedLine(lines[0]);
  const known = new Set(["displayname", "sqlinstance", "repositoryserver", "repositorydatabase", "environment", "isactive"]);
  const hasHeader = first.some((item) => known.has(item.trim().toLowerCase()));
  const headers = hasHeader ? first.map((h) => h.trim()) : ["SqlInstance", "DisplayName", "Environment", "RepositoryServer", "RepositoryDatabase", "IsActive"];
  const dataLines = hasHeader ? lines.slice(1) : lines;
  return dataLines.map((line) => {
    const values = splitDelimitedLine(line);
    const row = {};
    headers.forEach((header, index) => {
      row[header] = values[index] ?? "";
    });
    if (!row.SqlInstance && row.Server) row.SqlInstance = row.Server;
    if (!row.DisplayName) row.DisplayName = row.SqlInstance || values[0] || "";
    if (!row.SqlInstance) row.SqlInstance = row.DisplayName;
    return row;
  }).filter((row) => row.SqlInstance || row.DisplayName);
}

function splitDelimitedLine(line) {
  const delimiter = line.includes("\t") ? "\t" : ",";
  const values = [];
  let current = "";
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && line[i + 1] === '"') {
      current += '"';
      i++;
    } else if (ch === '"') {
      quoted = !quoted;
    } else if (ch === delimiter && !quoted) {
      values.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
  }
  values.push(current.trim());
  return values;
}

const NAV_ICON_PATHS = {
  activity: '<path d="M22 12h-4l-3 8-6-16-3 8H2"/>',
  "alert-triangle": '<path d="m21.7 18-8-14a2 2 0 0 0-3.4 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.7-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  archive: '<rect x="3" y="4" width="18" height="4" rx="1"/><path d="M5 8v11a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8"/><path d="M10 12h4"/>',
  "arrow-up-circle": '<circle cx="12" cy="12" r="9"/><path d="m8 12 4-4 4 4"/><path d="M12 16V8"/>',
  "bar-chart": '<path d="M4 20V10"/><path d="M12 20V4"/><path d="M20 20v-7"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
  "book-open": '<path d="M12 7v14"/><path d="M4 5a5 5 0 0 1 8 2v14a5 5 0 0 0-8-2Z"/><path d="M20 5a5 5 0 0 0-8 2v14a5 5 0 0 1 8-2Z"/>',
  boxes: '<path d="m7.5 4.3 4.5 2.6 4.5-2.6"/><path d="M12 22V6.9"/><path d="M3 9.2 12 14l9-4.8"/><path d="M3 9.2v5.6L12 20l9-5.2V9.2L12 4Z"/>',
  briefcase: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M3 13h18"/>',
  bug: '<path d="M8 2l1.5 2"/><path d="M16 2l-1.5 2"/><path d="M8 9h8"/><path d="M7 9v8a5 5 0 0 0 10 0V9A5 5 0 0 0 7 9Z"/><path d="M3 13h4"/><path d="M17 13h4"/><path d="M4 19l3-2"/><path d="m17 17 3 2"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/>',
  "chart-line": '<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-7"/>',
  "check-square": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="m8 12 3 3 5-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  cloud: '<path d="M17.5 19H7a5 5 0 1 1 1.1-9.9A7 7 0 0 1 21 12.5 3.5 3.5 0 0 1 17.5 19Z"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4"/><path d="M15 2v4"/><path d="M9 18v4"/><path d="M15 18v4"/><path d="M2 9h4"/><path d="M2 15h4"/><path d="M18 9h4"/><path d="M18 15h4"/>',
  database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  "pie-chart": '<path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9v9z"/><path d="M13 2.05A10 10 0 0 1 21.95 11H13z"/>',
  "file-search": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/><circle cx="11" cy="14" r="3"/><path d="m13.5 16.5 2 2"/>',
  "gauge-circle": '<circle cx="12" cy="12" r="9"/><path d="M12 12 16 8"/><path d="M7 14a5 5 0 0 1 10 0"/>',
  harddrive: '<path d="M22 12H2l3-8h14Z"/><path d="M5 12v8h14v-8"/><path d="M16 16h.01"/><path d="M19 16h.01"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v6h6"/><path d="M12 7v5l4 2"/>',
  key: '<circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.7 12.3 8-8"/><path d="m15 5 4 4"/><path d="m13 7 4 4"/>',
  "layout-dashboard": '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.1 0l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.1 0l-2 2A5 5 0 0 0 12 20.1l1.1-1.1"/>',
  list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  memory: '<rect x="4" y="7" width="16" height="10" rx="2"/><path d="M8 7V4"/><path d="M12 7V4"/><path d="M16 7V4"/><path d="M8 20v-3"/><path d="M12 20v-3"/><path d="M16 20v-3"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8"/><path d="M12 16v4"/><path d="m7 11 3-3 2 2 4-5"/>',
  network: '<rect x="16" y="16" width="5" height="5" rx="1"/><rect x="3" y="16" width="5" height="5" rx="1"/><rect x="9.5" y="3" width="5" height="5" rx="1"/><path d="M12 8v4"/><path d="M5.5 16v-2a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v2"/>',
  "play-circle": '<circle cx="12" cy="12" r="9"/><path d="m10 8 6 4-6 4Z"/>',
  rocket: '<path d="M4.5 16.5c-1 1-1.5 2.5-1.5 4.5 2 0 3.5-.5 4.5-1.5"/><path d="M9 15 6 18"/><path d="M15 9l-6 6"/><path d="M14 4c2.8-.8 5-.6 6 0 .6 1 .8 3.2 0 6l-4 4-6-6Z"/><path d="M14 4 20 10"/><circle cx="15" cy="9" r="1"/>',
  route: '<circle cx="6" cy="19" r="3"/><circle cx="18" cy="5" r="3"/><path d="M9 19h5a4 4 0 0 0 0-8h-4a4 4 0 0 1 0-8h5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
  server: '<rect x="4" y="3" width="16" height="8" rx="2"/><rect x="4" y="13" width="16" height="8" rx="2"/><path d="M8 7h.01"/><path d="M8 17h.01"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1A2 2 0 1 1 4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7A2 2 0 1 1 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3h.1a1.7 1.7 0 0 0 1-1.6V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.6h.1a1.7 1.7 0 0 0 1.9-.3l.1-.1A2 2 0 1 1 19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9v.1a1.7 1.7 0 0 0 1.6 1h.1a2 2 0 1 1 0 4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-5"/>',
  sparkles: '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8Z"/><path d="M5 3v4"/><path d="M3 5h4"/><path d="M19 17v4"/><path d="M17 19h4"/>',
  ticket: '<path d="M3 9a3 3 0 1 0 0 6v3a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3a3 3 0 1 0 0-6V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2Z"/><path d="M13 5v14"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1a4 4 0 0 1 0 7.8"/>',
  wrench: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4l-6.1 6.1a2 2 0 1 0 2.8 2.8l6.1-6.1a4 4 0 0 0 5.4-5.4l-2.8 2.8-2.1-2.1Z"/>',
};

const FEATURE_ICON_NAMES = {
  overview: "layout-dashboard",
  "collector-control": "play-circle",
  health: "activity",
  alerts: "bell",
  "alert-history": "history",
  tickets: "ticket",
  tasks: "check-square",
  analytics: "chart-line",
  "bi-insights": "pie-chart",
  "incident-flight-recorder": "radar",
  "account-security": "user",
  cpu: "cpu",
  memory: "memory",
  kpis: "gauge-circle",
  waits: "clock",
  "top-queries": "search",
  "execution-plans": "route",
  "memory-analysis": "memory",
  disks: "harddrive",
  io: "bar-chart",
  tempdb: "database",
  backups: "archive",
  "db-options": "settings",
  "missing-indexes": "file-search",
  fragmentation: "alert-triangle",
  config: "settings",
  blocking: "link",
  "long-running": "clock",
  ag: "cloud",
  listeners: "network",
  "agent-jobs": "briefcase",
  deadlocks: "bug",
  "patch-manager": "wrench",
  instances: "server",
  users: "users",
  notifications: "mail",
  thresholds: "sliders",
  "escalation-matrix": "arrow-up-circle",
  "collector-nodes": "network",
  "instance-group": "boxes",
  "deployment-center": "rocket",
  "repository-upgrade": "upload",
  dictionary: "book-open",
  issues: "shield",
  "web-agent": "sparkles",
  "vm-overview": "monitor",
  "vm-inventory": "server",
  "vm-performance": "activity",
  "vm-services": "settings",
};

NAV_ICON_PATHS.sliders = '<path d="M4 21v-7"/><path d="M4 10V3"/><path d="M12 21v-9"/><path d="M12 8V3"/><path d="M20 21v-5"/><path d="M20 12V3"/><path d="M2 14h4"/><path d="M10 8h4"/><path d="M18 16h4"/>';
NAV_ICON_PATHS.radar = '<circle cx="12" cy="12" r="9"/><path d="M12 12 19 8"/><path d="M12 3v3"/><path d="M12 18v3"/><path d="M3 12h3"/><path d="M18 12h3"/><circle cx="12" cy="12" r="3"/>';

function featureIcon(feature) {
  const iconName = FEATURE_ICON_NAMES[feature.key] || FEATURE_ICON_NAMES[feature.module] || feature.icon || "layout-dashboard";
  const paths = NAV_ICON_PATHS[iconName] || NAV_ICON_PATHS["layout-dashboard"];
  return `<svg class="nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" focusable="false">${paths}</svg>`;
}
function severityClass(value) {
  const normalized = String(value).toLowerCase();
  if (normalized.includes("critical") || normalized.includes("high")) return "critical";
  if (normalized.includes("warn") || normalized.includes("medium")) return "warning";
  return "info";
}

function statusClass(value) {
  const normalized = String(value).toLowerCase();
  if (normalized.includes("healthy") || normalized.includes("success") || normalized.includes("complete") || normalized.includes("ready")) return "healthy";
  if (normalized.includes("critical") || normalized.includes("fail") || normalized.includes("missing")) return "critical";
  if (normalized.includes("warn") || normalized.includes("never") || normalized.includes("blocked")) return "warning";
  return "info";
}

function percentTone(value) {
  const numeric = Number(value || 0);
  if (numeric >= 95) return "critical";
  if (numeric >= 85) return "warning";
  return "healthy";
}

function booleanTone(value) {
  return value === true || value === 1 || String(value).toLowerCase() === "true" ? "warning" : "healthy";
}

function serverStatusTone(value) {
  const normalized = String(value || "").toLowerCase();
  if (normalized.includes("critical") || normalized.includes("down") || normalized.includes("fail")) return "critical";
  if (normalized.includes("warning") || normalized.includes("warn") || normalized.includes("degraded")) return "warning";
  if (normalized.includes("healthy") || normalized.includes("online") || normalized.includes("ok") || normalized.includes("nosql")) return "healthy";
  return "unknown";
}

function activeClass(value) {
  return value === true || String(value).toLowerCase() === "true" ? "active" : "warning";
}

function ackClass(value) {
  return value === true || String(value).toLowerCase() === "true" ? "active" : "warning";
}

function patchClass(value) {
  const normalized = String(value).toLowerCase();
  if (normalized.includes("current") || normalized.includes("uptodate")) return "active";
  if (normalized.includes("available") || normalized.includes("behind")) return "warning";
  if (normalized.includes("error") || normalized.includes("unavailable")) return "critical";
  return "info";
}

function valueOf(id) {
  return document.getElementById(id)?.value ?? "";
}

function setValue(id, value) {
  const el = document.getElementById(id);
  if (el) el.value = value ?? "";
}

function checked(id) {
  return Boolean(document.getElementById(id)?.checked);
}

function formatNumber(value, digits = 0) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "0";
  return number.toFixed(digits);
}

function showStatus(message) {
  els.statusBar.classList.remove("error");
  els.statusBar.hidden = !message;
  els.statusBar.textContent = message || "";
}

function showError(message) {
  els.statusBar.classList.add("error");
  els.statusBar.hidden = false;
  els.statusBar.textContent = message;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}
