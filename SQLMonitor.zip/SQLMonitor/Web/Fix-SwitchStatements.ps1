# Fix switch statement syntax in Start-WebServer.ps1
# The issue is that switch cases are not properly formatted

$file = "Start-WebServer.ps1"
Write-Host "Reading file: $file"
$content = Get-Content $file -Raw
Write-Host "File length: $($content.Length)"

# Fix 1: TaskStatusID switch statement
Write-Host "`nFixing TaskStatusID switch statement..."
$oldTaskStatus = "@TaskStatusID = if (`$body.Status) { `$(switch([string]`$body.Status) { 'Open' {1} 'In Progress' {2} Pending {3} Completed {4} Cancelled {5} 'On Hold' {6} default {`$null} }) } else { `$null }"
$newTaskStatus = "@TaskStatusID = if (`$body.Status) { 
                switch([string]`$body.Status) { 
                    'Open' {1} 
                    'In Progress' {2} 
                    'Pending' {3} 
                    'Completed' {4} 
                    'Cancelled' {5} 
                    'On Hold' {6} 
                    default {`$null} 
                } 
            } else { `$null }"

if ($content.Contains($oldTaskStatus.Substring(0, 50))) {
    Write-Host "Found TaskStatusID pattern"
    # Replace the entire line with properly formatted switch
    $lines = $content -split "`n"
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match 'TaskStatusID = if \(\$body\.Status\)') {
            Write-Host "Found at line $($i+1)"
            $lines[$i] = "            TaskStatusID = if (`$body.Status) { "
            $lines[$i+1] = "                switch([string]`$body.Status) { "
            $lines[$i+2] = "                    'Open' {1} "
            $lines[$i+3] = "                    'In Progress' {2} "
            $lines[$i+4] = "                    'Pending' {3} "
            $lines[$i+5] = "                    'Completed' {4} "
            $lines[$i+6] = "                    'Cancelled' {5} "
            $lines[$i+7] = "                    'On Hold' {6} "
            $lines[$i+8] = "                    default {`$null} "
            $lines[$i+9] = "                } "
            $lines[$i+10] = "            } else { `$null }"
            break
        }
    }
    $content = $lines -join "`n"
}

# Fix 2: TaskPriorityID switch statement  
Write-Host "`nFixing TaskPriorityID switch statement..."
$lines = $content -split "`n"
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match 'TaskPriorityID = if \(\$body\.Priority\)') {
        Write-Host "Found TaskPriorityID at line $($i+1)"
        $lines[$i] = "            TaskPriorityID = if (`$body.Priority) { "
        $lines[$i+1] = "                switch([string]`$body.Priority) { "
        $lines[$i+2] = "                    'Critical' {1} "
        $lines[$i+3] = "                    'High' {2} "
        $lines[$i+4] = "                    'Medium' {3} "
        $lines[$i+5] = "                    'Low' {4} "
        $lines[$i+6] = "                    default {3} "
        $lines[$i+7] = "                } "
        $lines[$i+8] = "            } else { `$null }"
        break
    }
}
$content = $lines -join "`n"

# Save the file
Set-Content $file -Value $content -Encoding UTF8
Write-Host "`nFile saved!"

# Verify the fixes
Write-Host "`nVerifying fixes..."
$verify = Get-Content $file -Raw
$switchCount = ($verify.ToCharArray() | Where-Object { $_ -eq '{' }).Count
Write-Host "Open braces: $switchCount"
