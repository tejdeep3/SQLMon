param($Port=8090)
$body = @{Status='Open'}
$result = switch([string]$body.Status) { 
    'Open' {1} 
    'In Progress' {2} 
    'Pending' {3} 
    default {$null} 
}
Write-Host "Result: $result"
