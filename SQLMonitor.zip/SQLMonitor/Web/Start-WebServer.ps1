param(
    [int]$Port = 8090,
    [string]$RepositoryServer = '',
    [string]$RepositoryDatabase = ''
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$staticFilesDir = $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\WebAgent.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\PatchManager.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\PatchDownloader.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\DistributedCollectors.psm1') -Force -WarningAction SilentlyContinue

if ([string]::IsNullOrWhiteSpace($RepositoryServer) -or [string]::IsNullOrWhiteSpace($RepositoryDatabase)) {
    $repositorySettings = Get-SqlMonitorRepositorySettings
    if ([string]::IsNullOrWhiteSpace($RepositoryServer)) { $RepositoryServer = $repositorySettings.RepositoryServer }
    if ([string]::IsNullOrWhiteSpace($RepositoryDatabase)) { $RepositoryDatabase = $repositorySettings.RepositoryDatabase }
}

$script:RepositoryServer = $RepositoryServer
$script:RepositoryDatabase = $RepositoryDatabase
$script:Sessions = @{}
$script:MaxJsonBodyBytes = 1MB
$script:AllowedStaticExtensions = @('.html', '.css', '.js', '.ico', '.png', '.jpg', '.jpeg', '.svg', '.webp', '.woff', '.woff2')
$script:DashboardCsp = "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"

$script:FeatureGroups = @(
    @{
        name = 'VM Monitoring'
        features = @(
            @{ key = 'vm-overview'; title = 'VM Overview'; type = 'vm-overview'; icon = 'monitor' },
            @{ key = 'vm-inventory'; title = 'VM Inventory'; type = 'vm-inventory'; icon = 'server' },
            @{ key = 'vm-performance'; title = 'VM Performance'; type = 'vm-performance'; icon = 'activity' },
            @{ key = 'vm-services'; title = 'Windows Services'; type = 'vm-services'; icon = 'settings' },
            @{ key = 'vm-capacity'; title = 'Capacity Forecast'; type = 'vm-capacity'; icon = 'trending-up' },
            @{ key = 'vm-anomalies'; title = 'Anomaly Detection'; type = 'vm-anomalies'; icon = 'alert-triangle' },
            @{ key = 'vm-network'; title = 'Network Monitor'; type = 'vm-network'; icon = 'globe' },
            @{ key = 'vm-patching'; title = 'Patching Compliance'; type = 'vm-patching'; icon = 'shield' }
        )
    },
    @{
        name = 'Command Center'
        features = @(
            @{ key = 'vm-first-overview'; title = 'Server Overview'; type = 'vm-first-overview'; icon = 'layout-dashboard' },
            @{ key = 'collector-control'; title = 'Collectors & Schedule'; type = 'collector'; icon = 'play-circle' },
            @{ key = 'health'; title = 'Collection Health'; type = 'health'; icon = 'activity' },
            @{ key = 'alerts'; title = 'Open Alerts'; type = 'alerts'; icon = 'bell' },
            @{ key = 'alert-history'; title = 'Alert History'; type = 'alert-history'; icon = 'history' },
            @{ key = 'incident-flight-recorder'; title = 'Incident Flight Recorder'; type = 'incident-flight-recorder'; icon = 'radar' },
            @{ key = 'tickets'; title = 'Ticket System'; type = 'tickets'; icon = 'ticket' },
            @{ key = 'tasks'; title = 'Task Management'; type = 'tasks'; icon = 'check-square' },
            @{ key = 'analytics'; title = 'Performance Analytics'; type = 'analytics'; icon = 'chart-line' },
            @{ key = 'bi-insights'; title = 'BI Insights Studio'; type = 'bi-insights'; icon = 'pie-chart' },
            @{ key = 'account-security'; title = 'My Account'; type = 'account-security'; icon = 'user' }
        )
    },
    @{
        name = 'Performance'
        features = @(
            @{ key = 'cpu'; title = 'CPU Trend'; type = 'module'; module = 'cpu'; icon = 'cpu' },
            # Additional CPU resource metrics (e.g., CPU usage per core, scheduler stats)
            @{ key = 'memory'; title = 'Memory Trend'; type = 'module'; module = 'memory'; icon = 'memory' },
            @{ key = 'kpis'; title = 'KPIs'; type = 'module'; module = 'kpis'; icon = 'gauge-circle' },
            @{ key = 'waits'; title = 'Wait Stats'; type = 'module'; module = 'waits'; icon = 'clock' },
            @{ key = 'top-queries'; title = 'Top Queries'; type = 'module'; module = 'top-queries'; icon = 'search' },
            @{ key = 'execution-plans'; title = 'Execution Plans'; type = 'module'; module = 'execution-plans'; icon = 'route' },
            @{ key = 'memory-analysis'; title = 'Memory Analysis'; type = 'memory-analysis'; icon = 'memory' }
        )
    },
    @{
        name = 'Storage & Databases'
        features = @(
            @{ key = 'disks'; title = 'Disks'; type = 'module'; module = 'disks'; icon = 'harddrive' },
            @{ key = 'io'; title = 'I/O Files'; type = 'module'; module = 'io'; icon = 'bar-chart' },
            @{ key = 'tempdb'; title = 'TempDB'; type = 'module'; module = 'tempdb'; icon = 'database' },
            @{ key = 'backups'; title = 'Backups'; type = 'module'; module = 'backups'; icon = 'archive' },
            @{ key = 'db-options'; title = 'DB Options'; type = 'module'; module = 'db-options'; icon = 'settings' },
            @{ key = 'missing-indexes'; title = 'Missing Indexes'; type = 'module'; module = 'missing-indexes'; icon = 'file-search' },
            @{ key = 'fragmentation'; title = 'Fragmentation'; type = 'module'; module = 'fragmentation'; icon = 'alert-triangle' }
        )
    },
    @{
        name = 'Operations'
        features = @(
            @{ key = 'config'; title = 'SQL Config'; type = 'module'; module = 'config'; icon = 'settings' },
            @{ key = 'blocking'; title = 'Blocking'; type = 'module'; module = 'blocking'; icon = 'link' },
            @{ key = 'long-running'; title = 'Long Running'; type = 'module'; module = 'long-running'; icon = 'clock' },
            @{ key = 'ag'; title = 'Availability Groups'; type = 'module'; module = 'ag'; icon = 'cloud' },
            @{ key = 'listeners'; title = 'Listeners'; type = 'module'; module = 'listeners'; icon = 'network' },
            @{ key = 'agent-jobs'; title = 'Agent Jobs'; type = 'module'; module = 'agent-jobs'; icon = 'briefcase' },
            @{ key = 'deadlocks'; title = 'Deadlocks'; type = 'module'; module = 'deadlocks'; icon = 'bug' },
            @{ key = 'patch-manager'; title = 'Patch Manager'; type = 'patch-manager'; icon = 'wrench' }
        )
    },
    @{
        name = 'Administration'
        features = @(
            @{ key = 'instances'; title = 'Instance Management'; type = 'instances'; icon = 'server' },
            @{ key = 'users'; title = 'Users & Access'; type = 'users'; icon = 'users' },
            @{ key = 'notifications'; title = 'Notifications'; type = 'notifications'; icon = 'mail' },
            @{ key = 'thresholds'; title = 'Thresholds'; type = 'thresholds'; icon = 'sliders' },
            @{ key = 'escalation-matrix'; title = 'Escalation Matrix'; type = 'escalation-matrix'; icon = 'arrow-up-circle' },
            @{ key = 'collector-nodes'; title = 'Collector Nodes'; type = 'collector-nodes'; icon = 'network' },
            @{ key = 'instance-group'; title = 'Instance Group Execution'; type = 'instance-group'; icon = 'boxes' },
            @{ key = 'deployment-center'; title = 'Deployment Center'; type = 'deployment-center'; icon = 'rocket' },
            @{ key = 'repository-upgrade'; title = 'Apply Latest Changes'; type = 'repository-upgrade'; icon = 'upload' }
        )
    },
    @{
        name = 'Assistants'
        features = @(
            @{ key = 'dictionary'; title = 'SQL Dictionary'; type = 'dictionary'; icon = 'book-open' },
            @{ key = 'issues'; title = 'Common Issues & SOPs'; type = 'issues'; icon = 'shield' },
            @{ key = 'web-agent'; title = 'Web Solutions Agent'; type = 'web-agent'; icon = 'sparkles' },
            @{ key = 'query-analyzer'; title = 'Query Analyzer'; type = 'query-analyzer'; icon = 'search' },
            @{ key = 'alert-triage'; title = 'Alert Triage'; type = 'alert-triage'; icon = 'activity' },
            @{ key = 'vm-health'; title = 'VM Health Report'; type = 'vm-health'; icon = 'monitor' },
            @{ key = 'incident-timeline'; title = 'Incident Timeline'; type = 'incident-timeline'; icon = 'clock' },
            @{ key = 'config-drift'; title = 'Config Drift'; type = 'config-drift'; icon = 'git-compare' }
        )
    }
)

function ConvertTo-PlainRows {
    param([object]$Table)
    $rows = @()
    if ($null -eq $Table -or $null -eq $Table.Rows) { return $rows }
    foreach ($row in $Table.Rows) {
        $obj = [ordered]@{}
        foreach ($column in $Table.Columns) {
            $value = $row[$column.ColumnName]
            if ($value -is [System.DBNull]) { $value = $null }
            elseif ($value -is [datetime]) { $value = $value.ToString('yyyy-MM-dd HH:mm:ss') }
            $obj[$column.ColumnName] = $value
        }
        $rows += [pscustomobject]$obj
    }
    return $rows
}

function Invoke-RepoQuery {
    param([string]$Query, [hashtable]$Parameters = @{}, [int]$Timeout = 120)
    return Invoke-MonitorSqlQuery -ServerInstance $script:RepositoryServer -Database $script:RepositoryDatabase -Query $Query -Parameters $Parameters -CommandTimeout $Timeout
}

function Invoke-RepoScalar {
    param([string]$Query, [hashtable]$Parameters = @{}, [int]$Timeout = 120)
    return Invoke-MonitorSqlScalar -ServerInstance $script:RepositoryServer -Database $script:RepositoryDatabase -Query $Query -Parameters $Parameters -CommandTimeout $Timeout
}

function Invoke-RepoNonQuery {
    param([string]$Query, [hashtable]$Parameters = @{}, [int]$Timeout = 120)
    Invoke-MonitorSqlNonQuery -ServerInstance $script:RepositoryServer -Database $script:RepositoryDatabase -Query $Query -Parameters $Parameters -CommandTimeout $Timeout
}

function New-RepoSqlCommand {
    param([string]$Query, [hashtable]$Parameters = @{}, [int]$Timeout = 10)
    $connectionString = "Server=$script:RepositoryServer;Database=$script:RepositoryDatabase;Integrated Security=True;TrustServerCertificate=True;Connection Timeout=$Timeout;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = $Timeout
    foreach ($key in $Parameters.Keys) {
        $value = $Parameters[$key]
        if ($null -eq $value) { $value = [DBNull]::Value }
        if ($value -is [byte[]]) {
            $param = $command.Parameters.Add("@$key", [System.Data.SqlDbType]::VarBinary, $value.Length)
            $param.Value = $value
        }
        else {
            [void]$command.Parameters.AddWithValue("@$key", $value)
        }
    }
    return @{ Connection = $connection; Command = $command }
}

function Invoke-RepoQueryFast {
    param([string]$Query, [hashtable]$Parameters = @{}, [int]$Timeout = 10)
    $ctx = New-RepoSqlCommand -Query $Query -Parameters $Parameters -Timeout $Timeout
    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $ctx.Command
    $dataset = New-Object System.Data.DataSet
    try {
        $ctx.Connection.Open()
        [void]$adapter.Fill($dataset)
        if ($dataset.Tables.Count -gt 0) { return ,$dataset.Tables[0] }
        return ,(New-Object System.Data.DataTable)
    }
    finally {
        $ctx.Connection.Close()
        $ctx.Connection.Dispose()
    }
}

function Invoke-RepoNonQueryFast {
    param([string]$Query, [hashtable]$Parameters = @{}, [int]$Timeout = 10)
    $ctx = New-RepoSqlCommand -Query $Query -Parameters $Parameters -Timeout $Timeout
    try {
        $ctx.Connection.Open()
        [void]$ctx.Command.ExecuteNonQuery()
    }
    finally {
        $ctx.Connection.Close()
        $ctx.Connection.Dispose()
    }
}

function Test-RepositoryObjectExists {
    param([string]$ObjectName)
    try {
        $exists = Invoke-RepoScalar -Query 'SELECT CASE WHEN OBJECT_ID(@ObjectName) IS NULL THEN 0 ELSE 1 END;' -Parameters @{ ObjectName = $ObjectName } -Timeout 8
        return ([int]$exists -eq 1)
    }
    catch {
        Write-MonitorLog "Repository object check failed for $ObjectName`: $($_.Exception.Message)" -Level 'Warning'
        return $false
    }
}

function Set-SecurityHeaders {
    param($Response)
    if (-not $Response) { return }
    try {
        $Response.Headers['X-Content-Type-Options'] = 'nosniff'
        $Response.Headers['X-Frame-Options'] = 'DENY'
        $Response.Headers['Referrer-Policy'] = 'no-referrer'
        $Response.Headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
        $Response.Headers['Content-Security-Policy'] = $script:DashboardCsp
        $Response.Headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    }
    catch {
        Write-MonitorLog "Security headers could not be applied: $($_.Exception.Message)" -Level 'Warning'
    }
}

function Write-Response {
    param(
        $Response,
        [object]$Data,
        [int]$StatusCode = 200,
        [string]$ContentType = 'application/json'
    )
    if ($ContentType -eq 'application/json') {
        $payload = $Data | ConvertTo-Json -Depth 10
    }
    else {
        $payload = [string]$Data
    }
    $buffer = [System.Text.Encoding]::UTF8.GetBytes($payload)
    try {
        Set-SecurityHeaders -Response $Response
        $Response.StatusCode = $StatusCode
        $Response.ContentType = "$ContentType; charset=utf-8"
        $Response.ContentLength64 = $buffer.Length
        $Response.OutputStream.Write($buffer, 0, $buffer.Length)
    }
    catch {
        Write-MonitorLog "HTTP response write skipped because the client disconnected or response was already sent: $($_.Exception.Message)" -Level 'Warning'
    }
}

function Read-RequestJson {
    param($Request)
    $contentLength = 0
    try { $contentLength = [int64]$Request.ContentLength64 } catch { $contentLength = 0 }
    if ($contentLength -le 0 -and $Request.InputStream -and $Request.InputStream.CanSeek) {
        $contentLength = [int64]$Request.InputStream.Length
    }
    if ($contentLength -gt $script:MaxJsonBodyBytes) {
        throw "REQUEST_TOO_LARGE: JSON request body exceeds $($script:MaxJsonBodyBytes) bytes."
    }
    $reader = New-Object System.IO.StreamReader($Request.InputStream, $Request.ContentEncoding)
    try {
        $body = $reader.ReadToEnd()
        if ([string]::IsNullOrWhiteSpace($body)) { return [pscustomobject]@{} }
        return $body | ConvertFrom-Json
    }
    finally {
        $reader.Dispose()
    }
}

function Get-HttpErrorDetails {
    param([string]$Message)
    $messageText = [string]$Message
    $statusCode = 400
    if ($messageText -like 'AUTH_REQUIRED:*' -or $messageText -like 'AUTH_FAILED:*') { $statusCode = 401 }
    elseif ($messageText -like 'ACCESS_DENIED:*') { $statusCode = 403 }
    elseif ($messageText -like 'Route not found:*') { $statusCode = 404 }
    elseif ($messageText -like 'REQUEST_TOO_LARGE:*') { $statusCode = 413 }
    elseif ($messageText -match 'Exception calling|SqlException|System\.| at |[A-Za-z]:\\') { $statusCode = 500 }

    $clientMessage = $messageText -replace '^(AUTH_REQUIRED|AUTH_FAILED|ACCESS_DENIED|REQUEST_TOO_LARGE):\s*', ''
    if ($statusCode -eq 500) {
        $clientMessage = 'An unexpected server error occurred. Check the dashboard server log for details.'
    }
    return [pscustomobject]@{ StatusCode = $statusCode; Message = $clientMessage }
}

function Get-QueryValue {
    param($Request, [string]$Name, [string]$Default = '')
    $value = $Request.QueryString[$Name]
    if ([string]::IsNullOrWhiteSpace($value)) { return $Default }
    return [System.Uri]::UnescapeDataString($value)
}

function Get-IntQueryValue {
    param($Request, [string]$Name, [int]$Default = 0)
    $raw = Get-QueryValue -Request $Request -Name $Name
    $value = 0
    if ([int]::TryParse($raw, [ref]$value)) { return $value }
    return $Default
}

function Get-InstancesConfigPath { Join-Path $projectRoot 'Config\instances.json' }
function Get-NotificationsConfigPath { Join-Path $projectRoot 'Config\notifications.json' }
function Get-DashboardSettingsPath { Join-Path $projectRoot 'Config\dashboard-settings.json' }

function ConvertTo-HexString {
    param([byte[]]$Bytes)
    if ($null -eq $Bytes) { return '0x' }
    return '0x' + (($Bytes | ForEach-Object { $_.ToString('X2') }) -join '')
}

function New-PasswordSalt {
    $salt = New-Object byte[] 16
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($salt) }
    finally { $rng.Dispose() }
    return ,$salt
}

function Get-PasswordHashBytes {
    param([string]$Password, [byte[]]$Salt)
    $passwordBytes = [System.Text.Encoding]::Unicode.GetBytes($Password)
    $combined = New-Object byte[] ($Salt.Length + $passwordBytes.Length)
    [System.Buffer]::BlockCopy($Salt, 0, $combined, 0, $Salt.Length)
    [System.Buffer]::BlockCopy($passwordBytes, 0, $combined, $Salt.Length, $passwordBytes.Length)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return ,$sha.ComputeHash($combined) }
    finally { $sha.Dispose() }
}

function Test-ByteArrayEqual {
    param([byte[]]$Left, [byte[]]$Right)
    if ($null -eq $Left -or $null -eq $Right) { return $false }
    if ($Left.Length -ne $Right.Length) { return $false }
    $diff = 0
    for ($i = 0; $i -lt $Left.Length; $i++) {
        $diff = $diff -bor ($Left[$i] -bxor $Right[$i])
    }
    return ($diff -eq 0)
}

function Invoke-DashboardSecuritySchemaEnsure {
    $query = @"
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');

IF OBJECT_ID('mon.DashboardUsers', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUsers (
        UserID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardUsers PRIMARY KEY,
        UserName NVARCHAR(128) NOT NULL,
        DisplayName NVARCHAR(200) NULL,
        EmailAddress NVARCHAR(256) NULL,
        PhoneNumber NVARCHAR(20) NULL,
        Department NVARCHAR(100) NULL,
        PasswordSalt VARBINARY(16) NOT NULL,
        PasswordHash VARBINARY(32) NOT NULL,
        RoleName NVARCHAR(20) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_DashboardUsers_IsActive DEFAULT (1),
        MustChangePassword BIT NOT NULL CONSTRAINT DF_DashboardUsers_MustChangePassword DEFAULT (0),
        FailedLoginCount INT NOT NULL CONSTRAINT DF_DashboardUsers_FailedLoginCount DEFAULT (0),
        LastFailedLoginAt DATETIME2(0) NULL,
        LockoutUntil DATETIME2(0) NULL,
        PasswordChangedAt DATETIME2(0) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUsers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastLoginAt DATETIME2(0) NULL,
        CONSTRAINT UQ_DashboardUsers_UserName UNIQUE (UserName),
        CONSTRAINT CK_DashboardUsers_RoleName CHECK (RoleName IN ('Admin', 'AppOwner', 'ViewOnly', 'Limited'))
    );
END;

IF OBJECT_ID('mon.DashboardUserInstanceAccess', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUserInstanceAccess (
        UserID INT NOT NULL,
        InstanceID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUserInstanceAccess_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardUserInstanceAccess PRIMARY KEY (UserID, InstanceID),
        CONSTRAINT FK_DashboardUserInstanceAccess_Users FOREIGN KEY (UserID) REFERENCES mon.DashboardUsers(UserID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardUserInstanceAccess_Instances FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.DashboardServerGroups', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardServerGroups (
        GroupID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardServerGroups PRIMARY KEY,
        GroupName NVARCHAR(160) NOT NULL,
        ApplicationName NVARCHAR(160) NULL,
        OwnerName NVARCHAR(160) NULL,
        Description NVARCHAR(500) NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_DashboardServerGroups_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardServerGroups_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        CONSTRAINT UQ_DashboardServerGroups_GroupName UNIQUE (GroupName)
    );
END;

IF OBJECT_ID('mon.DashboardServerGroupMembers', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardServerGroupMembers (
        GroupID INT NOT NULL,
        InstanceID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardServerGroupMembers_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardServerGroupMembers PRIMARY KEY (GroupID, InstanceID),
        CONSTRAINT FK_DashboardServerGroupMembers_Groups FOREIGN KEY (GroupID) REFERENCES mon.DashboardServerGroups(GroupID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardServerGroupMembers_Instances FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.DashboardUserServerGroupAccess', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUserServerGroupAccess (
        UserID INT NOT NULL,
        GroupID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUserServerGroupAccess_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardUserServerGroupAccess PRIMARY KEY (UserID, GroupID),
        CONSTRAINT FK_DashboardUserServerGroupAccess_Users FOREIGN KEY (UserID) REFERENCES mon.DashboardUsers(UserID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardUserServerGroupAccess_Groups FOREIGN KEY (GroupID) REFERENCES mon.DashboardServerGroups(GroupID) ON DELETE CASCADE
    );
END;

IF OBJECT_ID('mon.DashboardAuditLog', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardAuditLog (
        AuditID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardAuditLog PRIMARY KEY,
        UserID INT NULL,
        UserName NVARCHAR(128) NULL,
        ActionName NVARCHAR(100) NOT NULL,
        Details NVARCHAR(1000) NULL,
        ClientHost NVARCHAR(128) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardAuditLog_CreatedAt DEFAULT (SYSDATETIME())
    );
END;

IF NOT EXISTS (SELECT 1 FROM mon.DashboardUsers)
BEGIN
    DECLARE @Salt VARBINARY(16) = 0x53514C4D4F4E41444D494E30303031;
    DECLARE @Password NVARCHAR(128) = N'Admin@123';

    INSERT INTO mon.DashboardUsers
        (UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword)
    VALUES
        (N'admin', N'Dashboard Administrator', @Salt, HASHBYTES('SHA2_256', @Salt + CONVERT(VARBINARY(MAX), @Password)), N'Admin', 1, 1);
END;

IF COL_LENGTH('mon.DashboardUsers', 'FailedLoginCount') IS NULL ALTER TABLE mon.DashboardUsers ADD FailedLoginCount INT NOT NULL CONSTRAINT DF_DashboardUsers_FailedLoginCount DEFAULT (0);
IF COL_LENGTH('mon.DashboardUsers', 'LastFailedLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastFailedLoginAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'LockoutUntil') IS NULL ALTER TABLE mon.DashboardUsers ADD LockoutUntil DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'PasswordChangedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD PasswordChangedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'UpdatedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD UpdatedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'LastLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastLoginAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'EmailAddress') IS NULL ALTER TABLE mon.DashboardUsers ADD EmailAddress NVARCHAR(256) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'PhoneNumber') IS NULL ALTER TABLE mon.DashboardUsers ADD PhoneNumber NVARCHAR(20) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'Department') IS NULL ALTER TABLE mon.DashboardUsers ADD Department NVARCHAR(100) NULL;

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_DashboardUsers_RoleName' AND parent_object_id = OBJECT_ID('mon.DashboardUsers'))
    ALTER TABLE mon.DashboardUsers DROP CONSTRAINT CK_DashboardUsers_RoleName;
ALTER TABLE mon.DashboardUsers ADD CONSTRAINT CK_DashboardUsers_RoleName CHECK (RoleName IN ('Admin', 'AppOwner', 'ViewOnly', 'Limited'));
"@
    Invoke-RepoNonQuery -Query $query
}

function Invoke-AlertTicketDedupSchemaEnsure {
    Invoke-RepoNonQuery -Query @"
IF OBJECT_ID('mon.AlertHistory', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.AlertHistory', 'IsTicketCreated') IS NULL
        ALTER TABLE mon.AlertHistory ADD IsTicketCreated BIT NOT NULL CONSTRAINT DF_AlertHistory_IsTicketCreated DEFAULT (0);
    IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL
        ALTER TABLE mon.AlertHistory ADD RepeatCount INT NOT NULL CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
    IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL
        ALTER TABLE mon.AlertHistory ADD FirstAlertTime DATETIME2 NULL;
    IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL
        ALTER TABLE mon.AlertHistory ADD LastRepeatedAt DATETIME2 NULL;

    UPDATE mon.AlertHistory
    SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
        LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
        RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
    WHERE FirstAlertTime IS NULL OR LastRepeatedAt IS NULL OR ISNULL(RepeatCount, 0) < 1;

    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID('mon.AlertHistory') AND name = 'IX_AlertHistory_OpenFingerprint')
        CREATE INDEX IX_AlertHistory_OpenFingerprint ON mon.AlertHistory (IsAcknowledged, InstanceID, ModuleName, AlertTitle, AlertTime DESC) INCLUDE (Severity, IsTicketCreated, RepeatCount, FirstAlertTime, LastRepeatedAt);
END;
"@

    Invoke-RepoNonQuery -Query @"
CREATE OR ALTER TRIGGER mon.trg_AlertHistory_RepeatCounter
ON mon.AlertHistory
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM inserted WHERE ISNULL(IsAcknowledged, 0) = 0)
        RETURN;

    UPDATE ah
    SET RepeatCount = CASE WHEN ISNULL(ah.RepeatCount, 0) < 1 THEN 1 ELSE ah.RepeatCount END,
        FirstAlertTime = COALESCE(ah.FirstAlertTime, ah.AlertTime),
        LastRepeatedAt = COALESCE(ah.LastRepeatedAt, ah.AlertTime)
    FROM mon.AlertHistory ah
    INNER JOIN inserted i ON ah.AlertID = i.AlertID;

    ;WITH mapped AS
    (
        SELECT
            i.AlertID AS InsertedAlertID,
            keeper.AlertID AS KeeperAlertID,
            ISNULL(i.RepeatCount, 1) AS InsertedRepeatCount,
            i.AlertTime,
            i.Severity,
            i.AlertDetails
        FROM inserted i
        CROSS APPLY
        (
            SELECT TOP (1) h.AlertID
            FROM mon.AlertHistory h
            WHERE ISNULL(h.IsAcknowledged, 0) = 0
              AND h.InstanceID = i.InstanceID
              AND h.ModuleName = i.ModuleName
              AND h.AlertTitle = i.AlertTitle
            ORDER BY COALESCE(h.FirstAlertTime, h.AlertTime), h.AlertID
        ) keeper
        WHERE ISNULL(i.IsAcknowledged, 0) = 0
          AND keeper.AlertID <> i.AlertID
    ),
    grouped AS
    (
        SELECT
            KeeperAlertID,
            SUM(InsertedRepeatCount) AS AddRepeatCount,
            MAX(AlertTime) AS LastRepeatedAt,
            MAX(CASE WHEN Severity = 'Critical' THEN 2 WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS MaxSeverityRank
        FROM mapped
        GROUP BY KeeperAlertID
    )
    UPDATE keeper
    SET RepeatCount = ISNULL(keeper.RepeatCount, 1) + grouped.AddRepeatCount,
        LastRepeatedAt = grouped.LastRepeatedAt,
        Severity = CASE
            WHEN grouped.MaxSeverityRank = 2 THEN 'Critical'
            WHEN grouped.MaxSeverityRank = 1 AND keeper.Severity <> 'Critical' THEN 'Warning'
            ELSE keeper.Severity
        END,
        AlertDetails = COALESCE(latest.AlertDetails, keeper.AlertDetails)
    FROM mon.AlertHistory keeper
    INNER JOIN grouped ON keeper.AlertID = grouped.KeeperAlertID
    OUTER APPLY
    (
        SELECT TOP (1) m.AlertDetails
        FROM mapped m
        WHERE m.KeeperAlertID = grouped.KeeperAlertID
        ORDER BY m.AlertTime DESC, m.InsertedAlertID DESC
    ) latest;

    DELETE ah
    FROM mon.AlertHistory ah
    INNER JOIN
    (
        SELECT DISTINCT InsertedAlertID
        FROM
        (
            SELECT
                i.AlertID AS InsertedAlertID,
                keeper.AlertID AS KeeperAlertID
            FROM inserted i
            CROSS APPLY
            (
                SELECT TOP (1) h.AlertID
                FROM mon.AlertHistory h
                WHERE ISNULL(h.IsAcknowledged, 0) = 0
                  AND h.InstanceID = i.InstanceID
                  AND h.ModuleName = i.ModuleName
                  AND h.AlertTitle = i.AlertTitle
                ORDER BY COALESCE(h.FirstAlertTime, h.AlertTime), h.AlertID
            ) keeper
            WHERE ISNULL(i.IsAcknowledged, 0) = 0
              AND keeper.AlertID <> i.AlertID
        ) x
    ) d ON ah.AlertID = d.InsertedAlertID;
END;
"@

    Invoke-RepoNonQuery -Query @"
CREATE OR ALTER VIEW mon.vw_OpenAlertsDetailed
AS
WITH ranked AS
(
    SELECT
        ah.AlertID,
        ah.InstanceID,
        mi.DisplayName,
        ah.AlertTime,
        ah.Severity,
        ah.ModuleName,
        ah.AlertTitle,
        ah.AlertDetails,
        ah.IsAcknowledged,
        SUM(ISNULL(ah.RepeatCount, 1)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS RepeatCount,
        MIN(COALESCE(ah.FirstAlertTime, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS FirstAlertTime,
        MAX(COALESCE(ah.LastRepeatedAt, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS LastRepeatedAt,
        ROW_NUMBER() OVER (
            PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle
            ORDER BY CASE ah.Severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, ah.AlertTime DESC, ah.AlertID DESC
        ) AS rn
    FROM mon.AlertHistory ah
    INNER JOIN mon.MonitoredInstances mi ON ah.InstanceID = mi.InstanceID
    WHERE ah.IsAcknowledged = 0
)
SELECT
    AlertID,
    InstanceID,
    DisplayName,
    AlertTime,
    DATEDIFF(MINUTE, FirstAlertTime, GETDATE()) AS AlertAgeMinutes,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    RepeatCount,
    FirstAlertTime,
    LastRepeatedAt
FROM ranked
WHERE rn = 1;
"@

    Invoke-RepoNonQuery -Query @"
CREATE OR ALTER PROCEDURE mon.usp_CreateTicketFromAlert
    @AlertID BIGINT,
    @CreatedBy NVARCHAR(128),
    @TicketSeverityID INT = 3,
    @AssignedTo NVARCHAR(128) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @InstanceID INT, @AlertTitle NVARCHAR(300), @AlertDetails NVARCHAR(MAX), @ModuleName NVARCHAR(100);
    DECLARE @ExistingTicketID BIGINT, @ExistingTicketNumber NVARCHAR(50);

    SELECT
        @InstanceID = InstanceID,
        @AlertTitle = AlertTitle,
        @AlertDetails = AlertDetails,
        @ModuleName = ModuleName
    FROM mon.AlertHistory
    WHERE AlertID = @AlertID;

    IF @InstanceID IS NULL
        THROW 51000, 'AlertID was not found.', 1;

    DECLARE @TicketType NVARCHAR(50) = CASE WHEN @ModuleName LIKE N'VM:%' THEN N'VM' ELSE N'SQL Server' END;

    SELECT TOP (1)
        @ExistingTicketID = t.TicketID,
        @ExistingTicketNumber = t.TicketNumber
    FROM mon.Tickets t
    INNER JOIN mon.AlertHistory ah ON t.AlertID = ah.AlertID
    WHERE t.IsActive = 1
      AND t.TicketStatusID IN (1, 2, 3, 6)
      AND ah.InstanceID = @InstanceID
      AND ah.ModuleName = @ModuleName
      AND ah.AlertTitle = @AlertTitle
    ORDER BY t.CreatedDate DESC, t.TicketID DESC;

    IF @ExistingTicketID IS NOT NULL
    BEGIN
        UPDATE ah
        SET IsTicketCreated = 1
        FROM mon.AlertHistory ah
        WHERE ah.IsAcknowledged = 0
          AND ah.InstanceID = @InstanceID
          AND ah.ModuleName = @ModuleName
          AND ah.AlertTitle = @AlertTitle;

        SELECT @ExistingTicketID AS TicketID, @ExistingTicketNumber AS TicketNumber, CAST(1 AS BIT) AS IsExistingTicket;
        RETURN;
    END;

    DECLARE @TicketNumber NVARCHAR(50);
    EXEC mon.usp_GetNextTicketNumber @TicketNumber OUTPUT;

    INSERT INTO mon.Tickets (AlertID, TicketNumber, TicketType, InstanceID, ErrorDescription, TicketSeverityID, CreatedBy, AssignedTo)
    VALUES (@AlertID, @TicketNumber, @TicketType, @InstanceID, 'Alert: ' + @AlertTitle + CHAR(13) + CHAR(10) + ISNULL(@AlertDetails, ''), @TicketSeverityID, @CreatedBy, @AssignedTo);

    DECLARE @TicketID BIGINT = SCOPE_IDENTITY();

    UPDATE ah
    SET IsTicketCreated = 1
    FROM mon.AlertHistory ah
    WHERE ah.IsAcknowledged = 0
      AND ah.InstanceID = @InstanceID
      AND ah.ModuleName = @ModuleName
      AND ah.AlertTitle = @AlertTitle;

    SELECT @TicketID AS TicketID, @TicketNumber AS TicketNumber, CAST(0 AS BIT) AS IsExistingTicket;
END;
"@

    Invoke-RepoNonQuery -Query @"
CREATE OR ALTER PROCEDURE mon.usp_AutoConvertAlertsToTickets
    @HoursBack INT = 24,
    @CreatedBy NVARCHAR(128) = 'system',
    @TicketsCreated INT = 0 OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @AlertID BIGINT, @Severity NVARCHAR(20), @TicketSeverityID INT;
    DECLARE @created TABLE (TicketID BIGINT, TicketNumber NVARCHAR(50), IsExistingTicket BIT);
    SET @TicketsCreated = 0;

    DECLARE alert_cursor CURSOR FAST_FORWARD FOR
    WITH candidates AS
    (
        SELECT
            ah.AlertID,
            ah.Severity,
            ROW_NUMBER() OVER (
                PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle
                ORDER BY CASE ah.Severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, ah.AlertTime DESC, ah.AlertID DESC
            ) AS rn
        FROM mon.AlertHistory ah
        WHERE ah.IsAcknowledged = 0
          AND ISNULL(ah.IsTicketCreated, 0) = 0
          AND ah.AlertTime > DATEADD(HOUR, -@HoursBack, SYSDATETIME())
          AND NOT EXISTS
          (
              SELECT 1
              FROM mon.Tickets t
              INNER JOIN mon.AlertHistory sourceAlert ON t.AlertID = sourceAlert.AlertID
              WHERE t.IsActive = 1
                AND t.TicketStatusID IN (1, 2, 3, 6)
                AND sourceAlert.InstanceID = ah.InstanceID
                AND sourceAlert.ModuleName = ah.ModuleName
                AND sourceAlert.AlertTitle = ah.AlertTitle
          )
    )
    SELECT AlertID, Severity
    FROM candidates
    WHERE rn = 1;

    OPEN alert_cursor;
    FETCH NEXT FROM alert_cursor INTO @AlertID, @Severity;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @TicketSeverityID = CASE @Severity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 WHEN 'Low' THEN 4 ELSE 3 END;

        BEGIN TRY
            DELETE FROM @created;
            INSERT INTO @created
            EXEC mon.usp_CreateTicketFromAlert @AlertID = @AlertID, @CreatedBy = @CreatedBy, @TicketSeverityID = @TicketSeverityID, @AssignedTo = NULL;

            IF EXISTS (SELECT 1 FROM @created WHERE IsExistingTicket = 0)
                SET @TicketsCreated = @TicketsCreated + 1;
        END TRY
        BEGIN CATCH
            PRINT 'Error creating ticket from alert ' + CAST(@AlertID AS VARCHAR(20)) + ': ' + ERROR_MESSAGE();
        END CATCH;

        FETCH NEXT FROM alert_cursor INTO @AlertID, @Severity;
    END;

    CLOSE alert_cursor;
    DEALLOCATE alert_cursor;
END;
"@
}

function Invoke-TaskManagementSchemaEnsure {
    if (-not (Test-RepositoryObjectExists -ObjectName 'mon.TaskComments') -or -not (Test-RepositoryObjectExists -ObjectName 'mon.Tasks')) {
        return
    }

    Invoke-RepoNonQuery -Query @"
IF OBJECT_ID('mon.Tickets', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('mon.Tickets', 'BusinessService') IS NULL ALTER TABLE mon.Tickets ADD BusinessService NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'TicketType') IS NULL ALTER TABLE mon.Tickets ADD TicketType NVARCHAR(50) NOT NULL CONSTRAINT DF_Tickets_TicketType DEFAULT (N'SQL Server');
    IF COL_LENGTH('mon.Tickets', 'Category') IS NULL ALTER TABLE mon.Tickets ADD Category NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'Subcategory') IS NULL ALTER TABLE mon.Tickets ADD Subcategory NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'Impact') IS NULL ALTER TABLE mon.Tickets ADD Impact NVARCHAR(40) NULL;
    IF COL_LENGTH('mon.Tickets', 'Urgency') IS NULL ALTER TABLE mon.Tickets ADD Urgency NVARCHAR(40) NULL;
    IF COL_LENGTH('mon.Tickets', 'AssignmentGroup') IS NULL ALTER TABLE mon.Tickets ADD AssignmentGroup NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'ContactType') IS NULL ALTER TABLE mon.Tickets ADD ContactType NVARCHAR(60) NULL;
    IF COL_LENGTH('mon.Tickets', 'ExternalReference') IS NULL ALTER TABLE mon.Tickets ADD ExternalReference NVARCHAR(160) NULL;
    IF COL_LENGTH('mon.Tickets', 'SLADueDate') IS NULL ALTER TABLE mon.Tickets ADD SLADueDate DATETIME2(7) NULL;
    IF COL_LENGTH('mon.Tickets', 'CloseCode') IS NULL ALTER TABLE mon.Tickets ADD CloseCode NVARCHAR(80) NULL;
    IF COL_LENGTH('mon.Tickets', 'WorkNotes') IS NULL ALTER TABLE mon.Tickets ADD WorkNotes NVARCHAR(MAX) NULL;

    UPDATE t
    SET TicketType = N'VM'
    FROM mon.Tickets t
    WHERE t.TicketType = N'SQL Server'
      AND (t.Category = N'VM Monitoring' OR EXISTS (SELECT 1 FROM mon.AlertHistory ah WHERE ah.AlertID = t.AlertID AND ah.ModuleName LIKE N'VM:%'));
END;
"@

    Invoke-RepoNonQuery -Query @"
IF COL_LENGTH('mon.TaskComments', 'ModifiedBy') IS NULL
    ALTER TABLE mon.TaskComments ADD ModifiedBy NVARCHAR(128) NULL;
IF COL_LENGTH('mon.TaskComments', 'ModifiedDate') IS NULL
    ALTER TABLE mon.TaskComments ADD ModifiedDate DATETIME2(7) NULL;
IF COL_LENGTH('mon.TaskComments', 'IsEdited') IS NULL
    ALTER TABLE mon.TaskComments ADD IsEdited BIT NOT NULL CONSTRAINT DF_TaskComments_IsEdited DEFAULT (0);
"@

    Invoke-RepoNonQuery -Query @"
CREATE OR ALTER VIEW mon.vw_TaskComments
AS
SELECT
    tc.CommentID,
    tc.TaskID,
    t.TaskTitle,
    tc.CommentText,
    tc.CreatedBy,
    tc.CreatedDate,
    tc.ModifiedBy,
    tc.ModifiedDate,
    tc.IsEdited
FROM mon.TaskComments tc
INNER JOIN mon.Tasks t ON tc.TaskID = t.TaskID
WHERE tc.IsActive = 1;
"@

    Invoke-RepoNonQuery -Query @"
CREATE OR ALTER VIEW mon.vw_TaskAuditTrail
AS
SELECT
    CAST(ta.ActivityID AS BIGINT) AS AuditID,
    ta.TaskID,
    t.TaskTitle,
    ta.CreatedDate,
    ta.CreatedBy AS UserName,
    ta.ActivityType AS ActionName,
    ta.ActivityDescription AS Details,
    CAST(N'TaskActivity' AS NVARCHAR(40)) AS AuditSource
FROM mon.TaskActivities ta
INNER JOIN mon.Tasks t ON ta.TaskID = t.TaskID;
"@

    Invoke-RepoNonQuery -Query @"
CREATE OR ALTER VIEW mon.vw_TicketAuditTrail
AS
SELECT
    dal.AuditID,
    CAST(NULL AS BIGINT) AS TicketID,
    dal.CreatedAt AS CreatedDate,
    dal.UserName,
    dal.ActionName,
    dal.Details,
    dal.ClientHost,
    CAST(N'DashboardAudit' AS NVARCHAR(40)) AS AuditSource
FROM mon.DashboardAuditLog dal
WHERE dal.ActionName LIKE N'%Ticket%';
"@
}

function Write-DashboardAudit {
    param([object]$User, [string]$ActionName, [string]$Details = '')
    try {
        Invoke-RepoNonQuery -Query 'INSERT INTO mon.DashboardAuditLog (UserID, UserName, ActionName, Details, ClientHost) VALUES (@UserID, @UserName, @ActionName, @Details, @ClientHost);' -Parameters @{
            UserID = if ($User) { [int]$User.UserID } else { $null }
            UserName = if ($User) { [string]$User.UserName } else { 'anonymous' }
            ActionName = $ActionName
            Details = $Details
            ClientHost = $env:COMPUTERNAME
        }
    }
    catch {
        Write-MonitorLog "Dashboard audit write failed: $($_.Exception.Message)" -Level 'Warning'
    }
}

function Convert-AuthUserForClient {
    param([object]$User)
    if (-not $User) { return $null }
    return [pscustomobject]@{
        UserID = [int]$User.UserID
        UserName = [string]$User.UserName
        DisplayName = [string]$User.DisplayName
        RoleName = [string]$User.RoleName
        MustChangePassword = [bool]$User.MustChangePassword
        AllowedInstanceIDs = @($User.AllowedInstanceIDs)
    }
}

function Get-HeaderValue {
    param($Request, [string]$Name)
    if ($null -eq $Request -or $null -eq $Request.Headers) { return '' }
    try {
        $value = $Request.Headers[$Name]
        if ([string]::IsNullOrWhiteSpace([string]$value)) {
            $value = $Request.Headers[$Name.ToLowerInvariant()]
        }
        return [string]$value
    } catch { return '' }
}

function Get-RequestAuthToken {
    param($Request)
    $auth = Get-HeaderValue -Request $Request -Name 'Authorization'
    if ($auth -match '^Bearer\s+(.+)$') { return $Matches[1] }
    return ''
}

function New-SessionToken {
    $bytes = New-Object byte[] 32
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) }
    finally { $rng.Dispose() }
    return ([Convert]::ToBase64String($bytes)).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}

function Get-SessionUser {
    param($Request)
    $token = Get-RequestAuthToken -Request $Request
    if ([string]::IsNullOrWhiteSpace($token) -or -not $script:Sessions.ContainsKey($token)) { return $null }
    $session = $script:Sessions[$token]
    if ($session.ExpiresAt -lt (Get-Date)) {
        $script:Sessions.Remove($token)
        return $null
    }
    $session.ExpiresAt = (Get-Date).AddMinutes((Get-SessionTimeoutMinutes))
    if ($session.User -and (Test-RoleRequiresAssignedInstanceAccess -RoleName ([string]$session.User.RoleName))) {
        $session.User.AllowedInstanceIDs = @(Get-AllowedInstanceIdsForUser -UserID ([int]$session.User.UserID))
    }
    return $session.User
}

function Get-SessionTimeoutMinutes {
    try {
        $settings = Get-DashboardSettings
        $minutes = [int]$settings.SessionTimeoutMinutes
        if ($minutes -lt 5) { return 30 }
        if ($minutes -gt 1440) { return 1440 }
        return $minutes
    }
    catch {
        return 30
    }
}

function Get-AccountLockoutThreshold { return 5 }
function Get-AccountLockoutMinutes { return 15 }

function Require-AuthenticatedUser {
    param($Request)
    $user = Get-SessionUser -Request $Request
    if (-not $user) { throw 'AUTH_REQUIRED: Login is required.' }
    return $user
}

function Require-AdminUser {
    param($Request, [string]$ActionName = 'This action')
    $user = Require-AuthenticatedUser -Request $Request
    if ([string]$user.RoleName -ne 'Admin') {
        throw "ACCESS_DENIED: $ActionName requires Admin access."
    }
    return $user
}

function Test-RoleRequiresAssignedInstanceAccess {
    param([string]$RoleName)
    return ($RoleName -in @('AppOwner', 'ViewOnly', 'Limited'))
}

function Test-UserCanAccessInstance {
    param([object]$User, [int]$InstanceID)
    if (-not $User) { return $false }
    if (-not (Test-RoleRequiresAssignedInstanceAccess -RoleName ([string]$User.RoleName))) { return $true }
    return (@($User.AllowedInstanceIDs) -contains $InstanceID)
}

function Assert-UserCanAccessInstance {
    param([object]$User, [int]$InstanceID)
    if ($InstanceID -le 0) { throw 'Select an instance first.' }
    if (-not (Test-UserCanAccessInstance -User $User -InstanceID $InstanceID)) {
        throw 'ACCESS_DENIED: You do not have access to the selected instance.'
    }
}

function Get-AllowedInstanceIdsForUser {
    param([int]$UserID)
    try {
        $allowedRows = Invoke-RepoQueryFast -Query @"
SELECT DISTINCT InstanceID
FROM (
    SELECT InstanceID
    FROM mon.DashboardUserInstanceAccess
    WHERE UserID = @UserID
    UNION
    SELECT gm.InstanceID
    FROM mon.DashboardUserServerGroupAccess uga
    INNER JOIN mon.DashboardServerGroups g ON uga.GroupID = g.GroupID AND g.IsActive = 1
    INNER JOIN mon.DashboardServerGroupMembers gm ON uga.GroupID = gm.GroupID
    WHERE uga.UserID = @UserID
) accessScope
ORDER BY InstanceID;
"@ -Parameters @{ UserID = $UserID } -Timeout 5
        return @(ConvertTo-PlainRows $allowedRows | ForEach-Object { [int]$_.InstanceID })
    }
    catch {
        Write-MonitorLog "Dashboard user access lookup failed: $($_.Exception.Message)" -Level 'Warning'
        return @()
    }
}

function Test-LocalFallbackAdminEnabled {
    $value = [string]$env:SQLMON_ENABLE_LOCAL_FALLBACK_ADMIN
    return ($value -eq '1' -or $value -ieq 'true' -or $value -ieq 'yes')
}

function Authenticate-WebUser {
    param([string]$UserName, [string]$Password)
    $trimmedUser = ([string]$UserName).Trim()
    $trimmedPassword = ([string]$Password).Trim()
    $isDefaultLocalAdmin = ($trimmedUser -ieq 'admin' -and $trimmedPassword -eq 'Admin@123')
    try {
        $dt = Invoke-RepoQueryFast -Query 'SELECT TOP 1 UserID, UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword, ISNULL(FailedLoginCount,0) AS FailedLoginCount, LockoutUntil FROM mon.DashboardUsers WHERE UserName = @UserName;' -Parameters @{ UserName = $trimmedUser } -Timeout 8
        if ($dt.Rows.Count -eq 0) {
            return $null
        }
        $row = $dt.Rows[0]
        if (-not [bool]$row['IsActive']) {
            throw 'This dashboard user is inactive.'
        }
        if ($row['LockoutUntil'] -isnot [System.DBNull] -and [datetime]$row['LockoutUntil'] -gt (Get-Date)) {
            throw "Account is locked until $(([datetime]$row['LockoutUntil']).ToString('yyyy-MM-dd HH:mm:ss'))."
        }
        $salt = [byte[]]$row['PasswordSalt']
        $expectedHash = [byte[]]$row['PasswordHash']
        $actualHash = Get-PasswordHashBytes -Password $Password -Salt $salt
        if (-not (Test-ByteArrayEqual -Left $expectedHash -Right $actualHash)) {
            Register-FailedLogin -UserID ([int]$row['UserID']) -UserName ([string]$row['UserName']) -CurrentFailedCount ([int]$row['FailedLoginCount'])
            return $null
        }
        $userId = [int]$row['UserID']
        $allowed = @(Get-AllowedInstanceIdsForUser -UserID $userId)
        try {
            Invoke-RepoNonQueryFast -Query 'UPDATE mon.DashboardUsers SET LastLoginAt = SYSDATETIME(), FailedLoginCount = 0, LastFailedLoginAt = NULL, LockoutUntil = NULL WHERE UserID = @UserID;' -Parameters @{ UserID = $userId } -Timeout 5
        }
        catch {
            Write-MonitorLog "Dashboard LastLoginAt update failed: $($_.Exception.Message)" -Level 'Warning'
        }
        return [pscustomobject]@{
            UserID = $userId
            UserName = [string]$row['UserName']
            DisplayName = [string]$row['DisplayName']
            RoleName = [string]$row['RoleName']
            MustChangePassword = [bool]$row['MustChangePassword']
            AllowedInstanceIDs = $allowed
            AuthSource = 'Repository'
        }
    }
    catch {
        $loginError = $_.Exception.Message
        if ($loginError -eq 'This dashboard user is inactive.' -or $loginError -like 'Account is locked until *') {
            throw $loginError
        }
        Write-MonitorLog "Repository dashboard login failed: $loginError" -Level 'Warning'
        if ($isDefaultLocalAdmin) {
            if (Test-LocalFallbackAdminEnabled) {
                Write-MonitorLog "Using temporary local fallback admin because repository authentication failed and SQLMON_ENABLE_LOCAL_FALLBACK_ADMIN is enabled." -Level 'Warning'
                return New-LocalFallbackAdminUser
            }
            Write-MonitorLog "Blocked default local fallback admin login because SQLMON_ENABLE_LOCAL_FALLBACK_ADMIN is not enabled." -Level 'Warning'
        }
        throw "Repository login failed: $loginError"
    }
}

function Register-FailedLogin {
    param([int]$UserID, [string]$UserName, [int]$CurrentFailedCount)
    $nextCount = $CurrentFailedCount + 1
    $threshold = Get-AccountLockoutThreshold
    $lockoutMinutes = Get-AccountLockoutMinutes
    $query = if ($nextCount -ge $threshold) {
        "UPDATE mon.DashboardUsers SET FailedLoginCount = @FailedLoginCount, LastFailedLoginAt = SYSDATETIME(), LockoutUntil = DATEADD(MINUTE, @LockoutMinutes, SYSDATETIME()) WHERE UserID = @UserID;"
    }
    else {
        "UPDATE mon.DashboardUsers SET FailedLoginCount = @FailedLoginCount, LastFailedLoginAt = SYSDATETIME() WHERE UserID = @UserID;"
    }
    try {
        Invoke-RepoNonQueryFast -Query $query -Parameters @{ UserID = $UserID; FailedLoginCount = $nextCount; LockoutMinutes = $lockoutMinutes } -Timeout 5
        Write-DashboardAudit -User ([pscustomobject]@{ UserID = $UserID; UserName = $UserName }) -ActionName 'FailedLogin' -Details "Failed login count $nextCount"
    }
    catch {
        Write-MonitorLog "Failed login tracking failed: $($_.Exception.Message)" -Level 'Warning'
    }
}

function Change-UserPassword {
    param([object]$User, [string]$CurrentPassword, [string]$NewPassword)
    # If the user is the local fallback admin (UserID = -1), create a repository-backed admin user
    if (-not $User) { throw 'Password change requires a user.' }
    if ([int]$User.UserID -le 0) {
        # Create admin user in the repository with the new password
        $salt = New-PasswordSalt
        $hash = Get-PasswordHashBytes -Password $NewPassword -Salt $salt
        $query = "INSERT INTO mon.DashboardUsers (UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword) VALUES (@UserName, @DisplayName, @PasswordSalt, @PasswordHash, @RoleName, @IsActive, @MustChangePassword);"
        $params = @{
            UserName          = 'admin'
            DisplayName       = 'Local Dashboard Administrator'
            PasswordSalt      = $salt
            PasswordHash      = $hash
            RoleName          = 'Admin'
            IsActive          = 1
            MustChangePassword = 0
        }
        Invoke-RepoNonQuery -Query $query -Parameters $params
        Write-DashboardAudit -User $User -ActionName 'CreateAdminUser' -Details 'Fallback admin created repository admin user'
        return @{ ok = $true; message = 'Admin user created and password set.' }
    }
    if ([string]::IsNullOrWhiteSpace($NewPassword) -or $NewPassword.Length -lt 8) { throw 'New password must be at least 8 characters.' }
    if ($NewPassword -notmatch '[A-Z]' -or $NewPassword -notmatch '[a-z]' -or $NewPassword -notmatch '\d') {
        throw 'New password must include uppercase, lowercase, and a number.'
    }
    $dt = Invoke-RepoQuery -Query 'SELECT PasswordSalt, PasswordHash FROM mon.DashboardUsers WHERE UserID = @UserID;' -Parameters @{ UserID = [int]$User.UserID }
    if ($dt.Rows.Count -eq 0) { throw 'User not found.' }
    $row = $dt.Rows[0]
    $actual = Get-PasswordHashBytes -Password $CurrentPassword -Salt ([byte[]]$row['PasswordSalt'])
    if (-not (Test-ByteArrayEqual -Left ([byte[]]$row['PasswordHash']) -Right $actual)) {
        throw 'Current password is incorrect.'
    }
    $salt = New-PasswordSalt
    $hash = Get-PasswordHashBytes -Password $NewPassword -Salt $salt
    $updateQuery = "UPDATE mon.DashboardUsers SET PasswordSalt = @PasswordSalt, PasswordHash = @PasswordHash, MustChangePassword = 0, FailedLoginCount = 0, LockoutUntil = NULL, PasswordChangedAt = SYSDATETIME(), UpdatedAt = SYSDATETIME() WHERE UserID = @UserID;"
    $updateParams = @{
        UserID       = [int]$User.UserID
        PasswordSalt = $salt
        PasswordHash = $hash
    }
    Invoke-RepoNonQuery -Query $updateQuery -Parameters $updateParams
    Write-DashboardAudit -User $User -ActionName 'ChangePassword' -Details 'User changed dashboard password'
    $User.MustChangePassword = $false
    return @{ ok = $true; message = 'Password changed successfully.' }
}

function New-LocalFallbackAdminUser {
    return [pscustomobject]@{
        UserID = -1
        UserName = 'admin'
        DisplayName = 'Local Dashboard Administrator'
        RoleName = 'Admin'
        MustChangePassword = $true
        AllowedInstanceIDs = @()
        AuthSource = 'LocalFallback'
    }
}

function Get-ConfiguredInstances {
    $path = Get-InstancesConfigPath
    if (-not (Test-Path $path)) { return @() }
    $json = Get-Content -Path $path -Raw
    if ([string]::IsNullOrWhiteSpace($json)) { return @() }
    $instances = $json | ConvertFrom-Json
    if ($instances -is [array]) { return @($instances) }
    return @($instances)
}

function Convert-ConfiguredInstancesForUi {
    $rows = @()
    $index = 1
    foreach ($instance in @(Get-ConfiguredInstances)) {
        $sqlInstance = if ([string]::IsNullOrWhiteSpace([string]$instance.SqlInstance)) { [string]$instance.DisplayName } else { [string]$instance.SqlInstance }
        $names = Split-SqlInstanceName -SqlInstance $sqlInstance
        $rows += [pscustomobject]@{
            InstanceID = $index
            DisplayName = if ([string]::IsNullOrWhiteSpace([string]$instance.DisplayName)) { $sqlInstance } else { [string]$instance.DisplayName }
            ServerName = $names.ServerName
            InstanceName = $names.InstanceName
            EnvironmentName = if ([string]::IsNullOrWhiteSpace([string]$instance.Environment)) { 'Production' } else { [string]$instance.Environment }
            IsActive = if ($null -eq $instance.IsActive) { $true } else { [bool]$instance.IsActive }
            Source = 'Config'
        }
        $index++
    }
    return $rows
}

function Save-ConfiguredInstances {
    param([object[]]$Instances)
    $path = Get-InstancesConfigPath
    @($Instances) | ConvertTo-Json -Depth 6 | Set-Content -Path $path -Encoding UTF8
    try { Sync-InstancesToRepository -Instances @($Instances) }
    catch { Write-MonitorLog "Instance repository sync failed: $($_.Exception.Message)" -Level 'Warning' }
}

function Import-ConfiguredInstances {
    param([object[]]$Rows)
    $instances = @(Get-ConfiguredInstances)
    $imported = 0
    $updated = 0
    foreach ($row in @($Rows)) {
        $sqlInstance = ([string]$row.SqlInstance).Trim()
        if ([string]::IsNullOrWhiteSpace($sqlInstance)) { $sqlInstance = ([string]$row.DisplayName).Trim() }
        if ([string]::IsNullOrWhiteSpace($sqlInstance)) { continue }
        $displayName = if ([string]::IsNullOrWhiteSpace([string]$row.DisplayName)) { $sqlInstance } else { ([string]$row.DisplayName).Trim() }
        $existing = $instances | Where-Object { $_.DisplayName -eq $displayName -or $_.SqlInstance -eq $sqlInstance } | Select-Object -First 1
        $activeText = ([string]$row.IsActive).Trim().ToLowerInvariant()
        $isActive = if ([string]::IsNullOrWhiteSpace($activeText)) {
            $true
        }
        elseif ($activeText -in @('1','true','yes','y','active','enabled')) {
            $true
        }
        elseif ($activeText -in @('0','false','no','n','inactive','disabled')) {
            $false
        }
        else {
            $true
        }
        if ($existing) {
            $existing.DisplayName = $displayName
            $existing.SqlInstance = $sqlInstance
            $existing.RepositoryServer = if ([string]::IsNullOrWhiteSpace([string]$row.RepositoryServer)) { $script:RepositoryServer } else { [string]$row.RepositoryServer }
            $existing.RepositoryDatabase = if ([string]::IsNullOrWhiteSpace([string]$row.RepositoryDatabase)) { $script:RepositoryDatabase } else { [string]$row.RepositoryDatabase }
            $existing.Environment = if ([string]::IsNullOrWhiteSpace([string]$row.Environment)) { 'Production' } else { [string]$row.Environment }
            $existing.IsActive = $isActive
            $updated++
        }
        else {
            $instances += [pscustomobject]@{
                DisplayName = $displayName
                SqlInstance = $sqlInstance
                RepositoryServer = if ([string]::IsNullOrWhiteSpace([string]$row.RepositoryServer)) { $script:RepositoryServer } else { [string]$row.RepositoryServer }
                RepositoryDatabase = if ([string]::IsNullOrWhiteSpace([string]$row.RepositoryDatabase)) { $script:RepositoryDatabase } else { [string]$row.RepositoryDatabase }
                Environment = if ([string]::IsNullOrWhiteSpace([string]$row.Environment)) { 'Production' } else { [string]$row.Environment }
                IsActive = $isActive
            }
            $imported++
        }
    }
    Save-ConfiguredInstances -Instances $instances
    $repoRows = @()
    $repoError = $null
    try { $repoRows = @(Get-RepositoryInstances) } catch { $repoError = $_.Exception.Message }
    $activeInstances = if ($repoRows.Count -gt 0) { @($repoRows | Where-Object { $_.IsActive }) } else { @(Convert-ConfiguredInstancesForUi | Where-Object { $_.IsActive }) }
    return @{ ok = $true; imported = $imported; updated = $updated; configured = Get-ConfiguredInstances; repository = $repoRows; instances = $activeInstances; repositoryError = $repoError }
}

function Split-SqlInstanceName {
    param([string]$SqlInstance)
    $parts = ([string]$SqlInstance).Split('\')
    return [pscustomobject]@{
        ServerName = $parts[0]
        InstanceName = if ($parts.Count -gt 1) { $parts[1] } else { 'MSSQLSERVER' }
    }
}

function Sync-InstancesToRepository {
    param([object[]]$Instances)
    foreach ($instance in @($Instances)) {
        $sqlInstance = if ([string]::IsNullOrWhiteSpace([string]$instance.SqlInstance)) { [string]$instance.DisplayName } else { [string]$instance.SqlInstance }
        if ([string]::IsNullOrWhiteSpace($sqlInstance)) { continue }
        $names = Split-SqlInstanceName -SqlInstance $sqlInstance
        $displayName = if ([string]::IsNullOrWhiteSpace([string]$instance.DisplayName)) { $sqlInstance } else { [string]$instance.DisplayName }
        $environment = if ([string]::IsNullOrWhiteSpace([string]$instance.Environment)) { 'Production' } else { [string]$instance.Environment }
        $isActive = if ($null -eq $instance.IsActive) { $true } else { [bool]$instance.IsActive }

        $query = @"
DECLARE @ExistingInstanceID INT;
SELECT @ExistingInstanceID = InstanceID
FROM mon.MonitoredInstances
WHERE DisplayName = @DisplayName
   OR (ServerName = @ServerName AND ISNULL(InstanceName, N'') = ISNULL(@InstanceName, N''));

IF @ExistingInstanceID IS NULL
BEGIN
    INSERT INTO mon.MonitoredInstances (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
    VALUES (@ServerName, @InstanceName, @DisplayName, @EnvironmentName, @IsActive);
END
ELSE
BEGIN
    UPDATE mon.MonitoredInstances
    SET ServerName = @ServerName,
        InstanceName = @InstanceName,
        DisplayName = @DisplayName,
        EnvironmentName = @EnvironmentName,
        IsActive = @IsActive
    WHERE InstanceID = @ExistingInstanceID;
END
"@
        Invoke-RepoNonQuery -Query $query -Parameters @{
            ServerName = $names.ServerName
            InstanceName = $names.InstanceName
            DisplayName = $displayName
            EnvironmentName = $environment
            IsActive = $isActive
        }
    }
}

function Get-RepositoryInstances {
    $query = @"
SELECT
    InstanceID,
    ServerName,
    InstanceName,
    DisplayName,
    EnvironmentName,
    IsActive,
    CreatedOn
FROM mon.MonitoredInstances
ORDER BY DisplayName;
"@
    return ConvertTo-PlainRows (Invoke-RepoQueryFast -Query $query -Timeout 10)
}

function Get-ActiveInstances {
    $query = @"
SELECT InstanceID, DisplayName, ServerName, InstanceName, EnvironmentName, IsActive
FROM mon.MonitoredInstances
WHERE IsActive = 1
ORDER BY DisplayName;
"@
    return ConvertTo-PlainRows (Invoke-RepoQueryFast -Query $query -Timeout 10)
}

function Filter-InstancesForUser {
    param([object[]]$Instances, [object]$User)
    if (-not $User -or -not (Test-RoleRequiresAssignedInstanceAccess -RoleName ([string]$User.RoleName))) {
        return @($Instances)
    }
    $allowed = @{}
    foreach ($id in @($User.AllowedInstanceIDs)) { $allowed[[int]$id] = $true }
    return @($Instances | Where-Object { $allowed.ContainsKey([int]$_.InstanceID) })
}

function Get-ModuleCatalog {
    return @(
        @{ Module = 'cpu'; Title = 'CPU Trend'; Objects = @('mon.CPUHistory') },
        # Include extra CPU resource objects for detailed view
        @{ Module = 'memory'; Title = 'Memory Trend'; Objects = @('mon.MemoryHistory') },
        @{ Module = 'kpis'; Title = 'KPIs'; Objects = @('mon.KPIHistory') },
        @{ Module = 'waits'; Title = 'Wait Stats'; Objects = @('dbo.WaitStats') },
        @{ Module = 'top-queries'; Title = 'Top Queries'; Objects = @('dbo.TopQueries') },
        @{ Module = 'execution-plans'; Title = 'Execution Plans'; Objects = @('mon.ExecutionPlansHistory') },
        @{ Module = 'memory-analysis'; Title = 'Memory Analysis'; Objects = @('mon.MemoryClerksHistory','mon.BufferPoolAnalysisHistory') },
        @{ Module = 'disks'; Title = 'Disks'; Objects = @('mon.DiskVolumeHistory') },
        @{ Module = 'io'; Title = 'I/O Files'; Objects = @('mon.IOFileHistory') },
        @{ Module = 'tempdb'; Title = 'TempDB'; Objects = @('mon.TempDBHistory') },
        @{ Module = 'backups'; Title = 'Backups'; Objects = @('mon.BackupStatusHistory') },
        @{ Module = 'db-options'; Title = 'DB Options'; Objects = @('mon.DBOptionsHistory') },
        @{ Module = 'missing-indexes'; Title = 'Missing Indexes'; Objects = @('dbo.MissingIndexes') },
        @{ Module = 'fragmentation'; Title = 'Fragmentation'; Objects = @('dbo.IndexFragmentation') },
        @{ Module = 'config'; Title = 'SQL Config'; Objects = @('mon.ConfigHistory') },
        @{ Module = 'blocking'; Title = 'Blocking'; Objects = @('mon.BlockingHistory') },
        @{ Module = 'long-running'; Title = 'Long Running'; Objects = @('mon.LongRunningHistory') },
        @{ Module = 'ag'; Title = 'Availability Groups'; Objects = @('mon.AGOverviewHistory') },
        @{ Module = 'listeners'; Title = 'Listeners'; Objects = @('mon.ListenerHistory') },
        @{ Module = 'agent-jobs'; Title = 'Agent Jobs'; Objects = @('mon.AgentJobHistory') },
        @{ Module = 'deadlocks'; Title = 'Deadlocks'; Objects = @('mon.DeadlockHistory') },
        @{ Module = 'alerts'; Title = 'Alerts'; Objects = @('mon.AlertHistory','mon.vw_OpenAlertsDetailed','mon.vw_AlertHistoryDetailed') },
        @{ Module = 'health'; Title = 'Collection Health'; Objects = @('mon.vw_CollectionHealth','mon.vw_CollectionGaps') },
        @{ Module = 'thresholds'; Title = 'Thresholds'; Objects = @('mon.AlertThresholds') },
        @{ Module = 'users'; Title = 'Users & Access'; Objects = @('mon.DashboardUsers','mon.DashboardUserInstanceAccess','mon.DashboardServerGroups','mon.DashboardServerGroupMembers','mon.DashboardUserServerGroupAccess') }
    )
}

function Get-ModuleHealth {
    $rows = @()
    foreach ($module in Get-ModuleCatalog) {
        $missing = @()
        foreach ($objectName in @($module.Objects)) {
            try {
                $exists = Invoke-RepoScalar -Query 'SELECT CASE WHEN OBJECT_ID(@ObjectName) IS NULL THEN 0 ELSE 1 END;' -Parameters @{ ObjectName = $objectName } -Timeout 8
                if ([int]$exists -ne 1) { $missing += $objectName }
            }
            catch {
                $missing += "Repository unavailable"
                break
            }
        }
        $status = if ($missing.Count -gt 0) { 'Missing SQL Object' } else { 'Ready' }
        $rows += [pscustomobject]@{
            Module = $module.Module
            Title = $module.Title
            Status = $status
            MissingObjects = ($missing -join ', ')
        }
    }
    return $rows
}

function Get-DashboardSettings {
    $path = Get-DashboardSettingsPath
    if (Test-Path $path) {
        $json = Get-Content -Path $path -Raw
        if (-not [string]::IsNullOrWhiteSpace($json)) { return $json | ConvertFrom-Json }
    }
    return [pscustomobject]@{ RefreshIntervalSeconds = 30; AutoRefreshEnabled = $true; SessionTimeoutMinutes = 30 }
}

function Save-DashboardSettings {
    param([object]$Settings)
    $settingsToSave = [pscustomobject]@{
        RefreshIntervalSeconds = [Math]::Max(5, [int]$Settings.RefreshIntervalSeconds)
        AutoRefreshEnabled = [bool]$Settings.AutoRefreshEnabled
        SessionTimeoutMinutes = [Math]::Min(1440, [Math]::Max(5, [int]$Settings.SessionTimeoutMinutes))
    }
    $settingsToSave | ConvertTo-Json -Depth 4 | Set-Content -Path (Get-DashboardSettingsPath) -Encoding UTF8
    return $settingsToSave
}

function Get-NotificationsConfig {
    $path = Get-NotificationsConfigPath
    if (Test-Path $path) {
        $json = Get-Content -Path $path -Raw
        if (-not [string]::IsNullOrWhiteSpace($json)) { return $json | ConvertFrom-Json }
    }
    return [pscustomobject]@{
        SMTP = @{ Server = ''; Port = 587; EnableSSL = $true; From = ''; Username = ''; Password = ''; UseDefaultCredentials = $true }
        Notifications = @{ Enabled = $true; Recipients = @(); CCRecipients = @(); MinSeverity = 'Warning'; QuietHours = @{ Enabled = $false; Start = '22:00'; End = '07:00' }; ThrottleMinutes = 30; IncludeDashboardLink = $true; DashboardURL = "http://localhost:$Port" }
        Teams = @{ Enabled = $false; WebhookURL = '' }
    }
}

function Save-NotificationsConfig {
    param([object]$Config)
    $Config | ConvertTo-Json -Depth 8 | Set-Content -Path (Get-NotificationsConfigPath) -Encoding UTF8
    return $Config
}

function Get-OverviewPayload {
    param([object]$User)
    $overviewQuery = @"
SELECT
    i.InstanceID,
    i.DisplayName,
    ISNULL(cpu.SqlCPUPercent, 0) AS SqlCPUPercent,
    ISNULL(cpu.OtherCPUPercent, 0) AS OtherCPUPercent,
    ISNULL(cpu.IdleCPUPercent, 0) AS IdleCPUPercent,
    ISNULL(mem.TotalPhysicalMB, 0) AS TotalPhysicalMB,
    ISNULL(mem.AvailablePhysicalMB, 0) AS AvailablePhysicalMB,
    ISNULL(mem.SqlMemoryUsedGB, 0) AS SqlMemoryUsedGB,
    ISNULL(mem.PLESeconds, 0) AS PLESeconds,
    ISNULL(mem.BufferCacheHitRatio, 0) AS BufferCacheHitRatio,
    ISNULL(alerts.OpenAlertCount, 0) AS OpenAlertCount,
    ISNULL(alerts.CriticalAlertCount, 0) AS CriticalAlertCount,
    ISNULL(alerts.WarningAlertCount, 0) AS WarningAlertCount,
    CASE
        WHEN ISNULL(alerts.CriticalAlertCount, 0) > 0 THEN 'Critical'
        WHEN ISNULL(alerts.WarningAlertCount, 0) > 0 THEN 'Warning'
        ELSE 'Healthy'
    END AS Status
FROM mon.MonitoredInstances i
LEFT JOIN (
    SELECT c1.InstanceID, c1.SqlCPUPercent, c1.OtherCPUPercent, c1.IdleCPUPercent
    FROM mon.CPUHistory c1
    INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime
        FROM mon.CPUHistory
        GROUP BY InstanceID
    ) c2 ON c1.InstanceID = c2.InstanceID AND c1.CaptureTime = c2.MaxTime
) cpu ON i.InstanceID = cpu.InstanceID
LEFT JOIN (
    SELECT m1.InstanceID, m1.TotalPhysicalMB, m1.AvailablePhysicalMB, m1.SqlMemoryUsedGB, m1.PLESeconds, m1.BufferCacheHitRatio
    FROM mon.MemoryHistory m1
    INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime
        FROM mon.MemoryHistory
        GROUP BY InstanceID
    ) m2 ON m1.InstanceID = m2.InstanceID AND m1.CaptureTime = m2.MaxTime
) mem ON i.InstanceID = mem.InstanceID
LEFT JOIN (
    SELECT InstanceID,
           COUNT(*) AS OpenAlertCount,
           SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
           SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
    FROM mon.AlertHistory
    WHERE IsAcknowledged = 0
    GROUP BY InstanceID
) alerts ON i.InstanceID = alerts.InstanceID
WHERE i.IsActive = 1
ORDER BY i.DisplayName;
"@
    $repositoryError = $null
    try {
        $instances = @(Filter-InstancesForUser -Instances (ConvertTo-PlainRows (Invoke-RepoQueryFast -Query $overviewQuery -Timeout 12)) -User $User)
        $alerts = Get-OpenAlerts -Limit 25 -User $User
    }
    catch {
        $repositoryError = $_.Exception.Message
        $instances = @(Filter-InstancesForUser -Instances @(Convert-ConfiguredInstancesForUi | ForEach-Object {
            [pscustomobject]@{
                InstanceID = $_.InstanceID
                DisplayName = $_.DisplayName
                ServerName = $_.ServerName
                InstanceName = $_.InstanceName
                EnvironmentName = $_.EnvironmentName
                IsActive = $_.IsActive
                SqlCPUPercent = 0
                OtherCPUPercent = 0
                IdleCPUPercent = 0
                TotalPhysicalMB = 0
                AvailablePhysicalMB = 0
                SqlMemoryUsedGB = 0
                PLESeconds = 0
                BufferCacheHitRatio = 0
                OpenAlertCount = 0
                CriticalAlertCount = 0
                WarningAlertCount = 0
                Status = if ($_.IsActive) { 'Healthy' } else { 'Inactive' }
            }
        }) -User $User)
        $alerts = @()
    }
    $summary = [ordered]@{
        TotalInstances = @($instances).Count
        Healthy = @($instances | Where-Object { $_.Status -eq 'Healthy' }).Count
        Warning = @($instances | Where-Object { $_.Status -eq 'Warning' }).Count
        Critical = @($instances | Where-Object { $_.Status -eq 'Critical' }).Count
        OpenAlerts = [int](($instances | Measure-Object -Property OpenAlertCount -Sum).Sum)
        CriticalAlerts = [int](($instances | Measure-Object -Property CriticalAlertCount -Sum).Sum)
        WarningAlerts = [int](($instances | Measure-Object -Property WarningAlertCount -Sum).Sum)
    }
    return @{
        summary = $summary
        instances = $instances
        alerts = $alerts
        capturedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        repositoryError = $repositoryError
    }
}

function Get-OpenAlerts {
    param([int]$InstanceID = 0, [int]$Limit = 200, [bool]$CriticalOnly = $false, [object]$User = $null)
    $instanceClause = if ($InstanceID -gt 0) { 'AND InstanceID = @InstanceID' } else { '' }
    if ($InstanceID -le 0 -and $User -and (Test-RoleRequiresAssignedInstanceAccess -RoleName ([string]$User.RoleName))) {
        $ids = @($User.AllowedInstanceIDs | ForEach-Object { [int]$_ })
        if ($ids.Count -eq 0) { return @() }
        $instanceClause = "AND InstanceID IN ($($ids -join ','))"
    }
    $severityClause = if ($CriticalOnly) { "AND Severity = 'Critical'" } else { '' }
    $query = @"
SELECT TOP ($Limit)
    AlertID,
    DisplayName,
    AlertTime,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    AlertAgeMinutes AS AgeMinutes,
    RepeatCount,
    FirstAlertTime,
    LastRepeatedAt
FROM mon.vw_OpenAlertsDetailed
WHERE 1=1
$instanceClause
$severityClause
ORDER BY AlertTime DESC;
"@
    return ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters @{ InstanceID = $InstanceID })
}

function Get-ModuleData {
    param([string]$Module, [int]$InstanceID)
    if ($InstanceID -le 0) { throw 'Select an instance first.' }

    $queries = @{
        'cpu' = @{ Object = 'mon.CPUHistory'; Query = "SELECT TOP 60 CaptureTime, SqlCPUPercent, OtherCPUPercent, IdleCPUPercent FROM mon.CPUHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC;" }
        'memory' = @{ Object = 'mon.MemoryHistory'; Query = "SELECT TOP 60 CaptureTime, TotalPhysicalMB, AvailablePhysicalMB, SqlMemoryUsedGB, PLESeconds, BufferCacheHitRatio FROM mon.MemoryHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC;" }
        'kpis' = @{ Object = 'mon.KPIHistory'; Query = "SELECT TOP 25 CaptureTime, PageLifeExpectancy, BufferCacheHitRatio, VisibleOnlineCPUs, MaxDOP, CostThresholdForParallelism FROM mon.KPIHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC;" }
        'disks' = @{ Object = 'mon.DiskVolumeHistory'; Query = "SELECT TOP 100 CaptureTime, VolumeMountPoint, LogicalVolumeName, TotalGB, FreeGB, UsedGB, UsedPct FROM mon.DiskVolumeHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, VolumeMountPoint;" }
        'config' = @{ Object = 'mon.ConfigHistory'; Query = "SELECT TOP 25 CaptureTime, MaxDOPSetting, CostThresholdSetting, MinServerMemorySetting, MaxServerMemorySetting, ProcessorCount, PhysicalMemoryMB FROM mon.ConfigHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC;" }
        'io' = @{ Object = 'mon.IOFileHistory'; Query = "SELECT TOP 100 CaptureTime, DatabaseName, FileType, LogicalName, PhysicalName, SizeMB, AvgReadMS, AvgWriteMS, TotalStallMS FROM mon.IOFileHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, AvgReadMS + AvgWriteMS DESC;" }
        'tempdb' = @{ Object = 'mon.TempDBHistory'; Query = "SELECT TOP 50 CaptureTime, FileType, LogicalName, SizeMB, UsedMB, PercentFull, TempDBDataFileCount, RecommendedFileCount FROM mon.TempDBHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC;" }
        'backups' = @{ Object = 'mon.BackupStatusHistory'; Query = "SELECT TOP 100 CaptureTime, DatabaseName, LastFullHours, LastDiffHours, LastLogHours, StatusText FROM mon.BackupStatusHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, DatabaseName;" }
        'db-options' = @{ Object = 'mon.DBOptionsHistory'; Query = "SELECT TOP 100 CaptureTime, DatabaseName, State, RecoveryModel, PageVerify, IsAutoClose, IsAutoShrink, IsEncrypted, SizeMB, AvailableSpaceMB, LogSizeMB FROM mon.DBOptionsHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, DatabaseName;" }
        'blocking' = @{ Object = 'mon.BlockingHistory'; Query = "SELECT TOP 100 CaptureTime, SessionID, BlockingSessionID, DatabaseName, WaitType, WaitTimeMS, LoginName, HostName, CommandText, StatementText FROM mon.BlockingHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, WaitTimeMS DESC;" }
        'long-running' = @{ Object = 'mon.LongRunningHistory'; Query = "SELECT TOP 100 CaptureTime, SessionID, DatabaseName, StartTime, DurationMinutes, WaitType, CPUms, Reads, Writes, CommandText, StatementText FROM mon.LongRunningHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, DurationMinutes DESC;" }
        'top-queries' = @{ Object = 'dbo.TopQueries'; Query = "SELECT TOP 100 CollectionDateTime, QueryID, PlanID, CAST(SUBSTRING(QueryText, 1, 250) AS NVARCHAR(250)) AS QueryText, AvgCpuTime, AvgDuration, AvgLogicalIOReads, AvgLogicalIOWrites, AvgPhysicalIOReads, CountExecutions, AvgRowCount FROM dbo.TopQueries WHERE InstanceID = @InstanceID ORDER BY AvgCpuTime DESC, CollectionDateTime DESC;" }
        'missing-indexes' = @{ Object = 'dbo.MissingIndexes'; Query = "SELECT TOP 100 CollectionDateTime, DatabaseName, ObjectName, EqualityColumns, InequalityColumns, IncludedColumns, UserSeeks, UserScans, UserLookups, UserUpdates, AvgTotalUserCost, AvgUserImpact, UniqueCompiles, ImprovementMeasure FROM dbo.MissingIndexes WHERE InstanceID = @InstanceID ORDER BY ImprovementMeasure DESC, CollectionDateTime DESC;" }
        'fragmentation' = @{ Object = 'dbo.IndexFragmentation'; Query = "SELECT TOP 100 CollectionDateTime, DatabaseName, ObjectName, IndexName, IndexType, AvgFragmentationPercent, AvgPageSpaceUsedPercent, RecordCount, PageCount, AvgRecordSizeBytes FROM dbo.IndexFragmentation WHERE InstanceID = @InstanceID ORDER BY AvgFragmentationPercent DESC, CollectionDateTime DESC;" }
        'ag' = @{ Object = 'mon.AGOverviewHistory'; Query = "SELECT TOP 100 CaptureTime, AGName, PrimaryReplica, SyncHealthDesc, BackupPreferenceDesc, FailureConditionLevel, ClusterTypeDesc FROM mon.AGOverviewHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, AGName;" }
        'listeners' = @{ Object = 'mon.ListenerHistory'; Query = "SELECT TOP 50 CaptureTime, DNSName, IPAddress, Port, State, AGName FROM mon.ListenerHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, DNSName;" }
        'agent-jobs' = @{ Object = 'mon.AgentJobHistory'; Query = "SELECT TOP 150 CaptureTime, JobName, Enabled, Category, LastRunTime, LastStatus, LastDurationSec, NextRunTime, SuccessPctRecent, LastFailureMessage FROM mon.AgentJobHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, LastRunTime DESC;" }
        'deadlocks' = @{ Object = 'mon.DeadlockHistory'; Query = "SELECT TOP 100 CaptureTime, DeadlockTime, DeadlockXml FROM mon.DeadlockHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC;" }
        'waits' = @{ Object = 'dbo.WaitStats'; Query = "SELECT TOP 100 CollectionDateTime, WaitType, WaitingTasksCount, WaitTimeMs, MaxWaitTimeMs, SignalWaitTimeMs FROM dbo.WaitStats WHERE InstanceID = @InstanceID ORDER BY WaitTimeMs DESC, CollectionDateTime DESC;" }
        'execution-plans' = @{ Object = 'mon.ExecutionPlansHistory'; Query = "SELECT TOP 100 CaptureTime, SqlText AS QueryText, CAST(NULL AS NVARCHAR(128)) AS PlanHandle, CpuTime, ElapsedTime, Reads, Writes, LogicalReads, WaitType, WaitTime, Recommendations AS OptimizationRecommendations FROM mon.ExecutionPlansHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, CpuTime DESC;" }
    }
    if (-not $queries.ContainsKey($Module)) { throw "Unknown module '$Module'." }
    $definition = $queries[$Module]
    if (-not (Test-RepositoryObjectExists -ObjectName $definition.Object)) {
        return @([pscustomobject]@{
            Status = 'NotDeployed'
            Module = $Module
            Message = "Repository object $($definition.Object) is not deployed. Run the SQL schema/deployment scripts for this module, then rerun collectors."
        })
    }
    try {
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query $definition.Query -Parameters @{ InstanceID = $InstanceID })
    }
    catch {
        return @([pscustomobject]@{
            Status = 'Error'
            Module = $Module
            Message = $_.Exception.Message
        })
    }
}

function Get-WindowsMonitoringPayload {
    $schemaReady = Invoke-RepoScalar -Query "SELECT CASE WHEN OBJECT_ID(N'mon.WindowsTargets', N'U') IS NULL THEN 0 ELSE 1 END;"
    if ([int]$schemaReady -ne 1) {
        return @{
            summary = @{ TotalVMs = 0; Critical = 0; Warning = 0; Healthy = 0; AvgHealthScore = 0 }
            targets = @()
            trend = @()
            disks = @()
            services = @()
            message = 'Windows monitoring schema is not deployed yet. Run Apply Latest Changes or Database Only from Deployment Center.'
        }
    }

    $targets = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT *
FROM mon.vw_WindowsLatestHealth
ORDER BY
    CASE HealthPosture WHEN N'Critical' THEN 1 WHEN N'Warning' THEN 2 WHEN N'Healthy' THEN 3 ELSE 4 END,
    DisplayName;
"@)

    $trend = @()
    try {
        $trend = ConvertTo-PlainRows (Invoke-RepoQuery -Query "EXEC mon.usp_GetWindowsPerformanceTrend @TopSamples = 240;")
    }
    catch {
        # Fall back to inline query if stored procedure does not exist yet
        Write-MonitorLog "usp_GetWindowsPerformanceTrend not found, using inline query: $($_.Exception.Message)" -Level 'Warning'
        $trend = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (240)
    t.DisplayName,
    ps.CaptureTime,
    ps.CPUPercent,
    ps.MemoryUsedPercent,
    ps.DiskUsedPercent,
    ps.HealthScore
FROM mon.WindowsPerformanceSamples ps
INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
ORDER BY ps.CaptureTime DESC;
"@)
    }

    $disks = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
WITH ranked AS
(
    SELECT
        t.DisplayName,
        ds.DriveLetter,
        ds.VolumeName,
        ds.TotalGB,
        ds.FreeGB,
        ds.UsedPercent,
        ds.CaptureTime,
        ROW_NUMBER() OVER (PARTITION BY ds.TargetID, ds.DriveLetter ORDER BY ds.CaptureTime DESC, ds.DiskSampleID DESC) AS rn
    FROM mon.WindowsDiskSamples ds
    INNER JOIN mon.WindowsTargets t ON ds.TargetID = t.TargetID
)
SELECT DisplayName, DriveLetter, VolumeName, TotalGB, FreeGB, UsedPercent, CaptureTime
FROM ranked
WHERE rn = 1
ORDER BY UsedPercent DESC, DisplayName, DriveLetter;
"@)

    $services = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (100)
    t.DisplayName AS ComputerName,
    ss.ServiceName,
    ss.DisplayName,
    ss.StartMode,
    ss.StateName,
    ss.IsCritical,
    ss.CaptureTime
FROM mon.WindowsServiceSamples ss
INNER JOIN mon.WindowsTargets t ON ss.TargetID = t.TargetID
ORDER BY ss.CaptureTime DESC, ss.IsCritical DESC, t.DisplayName, ss.ServiceName;
"@)

    $extendedReady = [int](Invoke-RepoScalar -Query "SELECT CASE WHEN OBJECT_ID(N'mon.WindowsProcessSamples', N'U') IS NOT NULL AND OBJECT_ID(N'mon.WindowsEventSamples', N'U') IS NOT NULL AND OBJECT_ID(N'mon.WindowsHotFixSamples', N'U') IS NOT NULL AND OBJECT_ID(N'mon.WindowsNetworkAdapterSamples', N'U') IS NOT NULL AND OBJECT_ID(N'mon.WindowsPerfCounterSamples', N'U') IS NOT NULL THEN 1 ELSE 0 END;")
    $processes = @()
    $events = @()
    $hotfixes = @()
    $networkAdapters = @()
    $perfCounters = @()
    $vmAlerts = @()
    $vmAlertRules = @()
    if ($extendedReady -eq 1) {
        $processes = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (80)
    t.DisplayName AS ComputerName,
    ps.RankingType,
    ps.ProcessName,
    ps.ProcessID,
    ps.CPUPercent,
    ps.WorkingSetMB,
    ps.VirtualMemoryMB,
    ps.CaptureTime
FROM mon.WindowsProcessSamples ps
INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
ORDER BY ps.CaptureTime DESC, ps.RankingType, COALESCE(ps.CPUPercent, ps.WorkingSetMB) DESC;
"@)
        $events = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (100)
    t.DisplayName AS ComputerName,
    es.EventTime,
    es.LogName,
    es.EventID,
    es.LevelName,
    es.ProviderName,
    es.Message
FROM mon.WindowsEventSamples es
INNER JOIN mon.WindowsTargets t ON es.TargetID = t.TargetID
ORDER BY es.EventTime DESC, es.EventSampleID DESC;
"@)
        $hotfixes = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (80)
    t.DisplayName AS ComputerName,
    hs.HotFixID,
    hs.InstalledOn,
    hs.Description,
    hs.CaptureTime
FROM mon.WindowsHotFixSamples hs
INNER JOIN mon.WindowsTargets t ON hs.TargetID = t.TargetID
ORDER BY hs.CaptureTime DESC, hs.InstalledOn DESC;
"@)
        $networkAdapters = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (80)
    t.DisplayName AS ComputerName,
    ns.AdapterName,
    ns.InterfaceDescription,
    ns.StatusName,
    ns.LinkSpeed,
    ns.MacAddress,
    ns.CaptureTime
FROM mon.WindowsNetworkAdapterSamples ns
INNER JOIN mon.WindowsTargets t ON ns.TargetID = t.TargetID
ORDER BY ns.CaptureTime DESC, t.DisplayName, ns.AdapterName;
"@)
        $perfCounters = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (120)
    t.DisplayName AS ComputerName,
    ps.CounterPath,
    ps.CookedValue,
    ps.CounterTime,
    ps.CaptureTime
FROM mon.WindowsPerfCounterSamples ps
INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
ORDER BY ps.CaptureTime DESC, ps.PerfCounterSampleID DESC;
"@)
    }

    $alertingReady = [int](Invoke-RepoScalar -Query "SELECT CASE WHEN OBJECT_ID(N'mon.vw_WindowsOpenAlerts', N'V') IS NOT NULL AND OBJECT_ID(N'mon.WindowsAlertRules', N'U') IS NOT NULL THEN 1 ELSE 0 END;")
    if ($alertingReady -eq 1) {
        $vmAlerts = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP (100)
    AlertID,
    TargetID,
    ComputerName,
    DisplayName,
    AlertTime,
    AlertAgeMinutes,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    RepeatCount,
    IsTicketCreated,
    TicketID,
    TicketNumber,
    SLADueDate,
    EscalationLevelID
FROM mon.vw_WindowsOpenAlerts
ORDER BY
    CASE Severity WHEN N'Critical' THEN 1 WHEN N'High' THEN 2 WHEN N'Medium' THEN 3 WHEN N'Warning' THEN 4 ELSE 5 END,
    AlertTime DESC;
"@)
        $vmAlertRules = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT RuleKey, Category, Subcategory, MetricName, WarningThreshold, CriticalThreshold, WarningSeverity, CriticalSeverity, WarningSlaMinutes, CriticalSlaMinutes, AssignmentGroup, IsAutoTicketEnabled, IsActive
FROM mon.WindowsAlertRules
ORDER BY Category, Subcategory, RuleKey;
"@)
    }

    $summary = @{
        TotalVMs = @($targets).Count
        Critical = @($targets | Where-Object { $_.HealthPosture -eq 'Critical' }).Count
        Warning = @($targets | Where-Object { $_.HealthPosture -eq 'Warning' }).Count
        Healthy = @($targets | Where-Object { $_.HealthPosture -eq 'Healthy' }).Count
        AvgHealthScore = if (@($targets).Count -gt 0) { [math]::Round((@($targets) | Measure-Object -Property HealthScore -Average).Average, 0) } else { 0 }
        OpenVMAlerts = @($vmAlerts).Count
        CriticalVMAlerts = @($vmAlerts | Where-Object { $_.Severity -eq 'Critical' }).Count
        VMTickets = @($vmAlerts | Where-Object { $_.TicketID }).Count
    }

    return @{
        summary = $summary
        targets = $targets
        trend = @($trend | Sort-Object CaptureTime)
        disks = $disks
        services = $services
        processes = $processes
        events = $events
        hotfixes = $hotfixes
        networkAdapters = $networkAdapters
        perfCounters = $perfCounters
        vmAlerts = $vmAlerts
        vmAlertRules = $vmAlertRules
    }
}

function Get-VMHierarchyPayload {
    <#
    .SYNOPSIS
        Returns VM-first hierarchy data for the dashboard.
        Each VM includes its SQL instances with health data.
    #>
    param([object]$User)

    $vms = @()
    $sqlInstances = @()
    $repositoryError = $null

    try {
        # Get VM summary data
        $vmRows = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    TargetID, ComputerName, DisplayName, EnvironmentName, IsEnabled, IsVMHost,
    CollectionMode, CollectionIntervalMinutes, CreatedAt, LastUpdatedAt
FROM mon.WindowsTargets
WHERE IsEnabled = 1
ORDER BY DisplayName;
"@)

        # Get latest VM performance
        $vmPerfRows = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT t.TargetID, ps.CPUPercent, ps.MemoryUsedPercent, ps.DiskUsedPercent,
       ps.HealthScore, ps.HealthPosture, ps.CaptureTime
FROM mon.WindowsPerformanceSamples ps
INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
WHERE ps.CaptureTime = (
    SELECT MAX(ps2.CaptureTime) FROM mon.WindowsPerformanceSamples ps2 WHERE ps2.TargetID = t.TargetID
);
"@)

        # Get SQL instances with VM context
        $sqlRows = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    mi.InstanceID, mi.DisplayName, mi.ServerName, mi.InstanceName,
    mi.EnvironmentName, mi.IsActive, mi.ParentVMID,
    ISNULL(cpu.SqlCPUPercent, 0) AS SqlCPUPercent,
    ISNULL(mem.AvailablePhysicalMB, 0) AS AvailablePhysicalMB,
    ISNULL(mem.PLESeconds, 0) AS PLESeconds,
    ISNULL(alerts.OpenAlertCount, 0) AS OpenAlertCount,
    ISNULL(alerts.CriticalAlertCount, 0) AS CriticalAlertCount,
    ISNULL(alerts.WarningAlertCount, 0) AS WarningAlertCount,
    CASE
        WHEN ISNULL(alerts.CriticalAlertCount, 0) > 0 THEN 'Critical'
        WHEN ISNULL(alerts.WarningAlertCount, 0) > 0 THEN 'Warning'
        ELSE 'Healthy'
    END AS SqlHealthPosture
FROM mon.MonitoredInstances mi
LEFT JOIN (
    SELECT c1.InstanceID, c1.SqlCPUPercent
    FROM mon.CPUHistory c1 INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime FROM mon.CPUHistory GROUP BY InstanceID
    ) c2 ON c1.InstanceID = c2.InstanceID AND c1.CaptureTime = c2.MaxTime
) cpu ON mi.InstanceID = cpu.InstanceID
LEFT JOIN (
    SELECT m1.InstanceID, m1.AvailablePhysicalMB, m1.PLESeconds
    FROM mon.MemoryHistory m1 INNER JOIN (
        SELECT InstanceID, MAX(CaptureTime) AS MaxTime FROM mon.MemoryHistory GROUP BY InstanceID
    ) m2 ON m1.InstanceID = m2.InstanceID AND m1.CaptureTime = m2.MaxTime
) mem ON mi.InstanceID = mem.InstanceID
LEFT JOIN (
    SELECT InstanceID,
           COUNT(*) AS OpenAlertCount,
           SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlertCount,
           SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlertCount
    FROM mon.AlertHistory WHERE IsAcknowledged = 0 GROUP BY InstanceID
) alerts ON mi.InstanceID = alerts.InstanceID
WHERE mi.IsActive = 1
ORDER BY mi.DisplayName;
"@)

        # Build lookup for VM performance
        $vmPerfLookup = @{}
        foreach ($row in $vmPerfRows) { $vmPerfLookup[[int]$row.TargetID] = $row }

        # Build lookup of SQL instances by VM
        # First pass: index VMs by ComputerName for auto-linking
        $vmByComputerName = @{}
        foreach ($vm in $vmRows) {
            $cn = [string]$vm.ComputerName
            if ($cn) { $vmByComputerName[$cn] = [int]$vm.TargetID }
        }

        $sqlByVM = @{}
        $standaloneSQL = @()
        foreach ($sql in $sqlRows) {
            $vmId = if ($sql.ParentVMID) { [int]$sql.ParentVMID } else { 0 }

            # Auto-link: if ParentVMID is NULL, try matching ServerName to a VM ComputerName
            if ($vmId -eq 0) {
                $serverName = [string]$sql.ServerName
                if ($serverName -and $vmByComputerName.ContainsKey($serverName)) {
                    $vmId = $vmByComputerName[$serverName]
                }
            }

            if ($vmId -gt 0) {
                if (-not $sqlByVM.ContainsKey($vmId)) { $sqlByVM[$vmId] = @() }
                $sqlByVM[$vmId] += $sql
            }
            else {
                $standaloneSQL += $sql
            }
        }

        # Build VM objects with nested SQL instances
        foreach ($vm in $vmRows) {
            $vmId = [int]$vm.TargetID
            $perf = $vmPerfLookup[$vmId]
            $children = @()
            if ($sqlByVM.ContainsKey($vmId)) { $children = $sqlByVM[$vmId] }

            # Calculate aggregated alert counts from children
            $childOpenAlerts = 0; $childCriticalAlerts = 0; $childWarningAlerts = 0
            foreach ($child in $children) {
                $childOpenAlerts += [int]$child.OpenAlertCount
                $childCriticalAlerts += [int]$child.CriticalAlertCount
                $childWarningAlerts += [int]$child.WarningAlertCount
            }

            # Overall posture: worst of VM and all SQL children
            $vmPosture = if ($perf) { [string]$perf.HealthPosture } else { 'Unknown' }
            $overallPosture = $vmPosture
            if ($childCriticalAlerts -gt 0) { $overallPosture = 'Critical' }
            elseif ($childWarningAlerts -gt 0 -and $overallPosture -ne 'Critical') { $overallPosture = 'Warning' }
            elseif ($children.Count -eq 0 -and $vmPosture -eq 'Unknown') { $overallPosture = 'NoSQL' }

            $vms += [pscustomobject]@{
                VMID              = $vmId
                ComputerName      = [string]$vm.ComputerName
                DisplayName       = [string]$vm.DisplayName
                EnvironmentName   = [string]$vm.EnvironmentName
                IsVMHost          = [bool]$vm.IsVMHost
                CPUPercent        = if ($perf) { [decimal]$perf.CPUPercent } else { 0 }
                MemoryUsedPercent = if ($perf) { [decimal]$perf.MemoryUsedPercent } else { 0 }
                DiskUsedPercent   = if ($perf) { [decimal]$perf.DiskUsedPercent } else { 0 }
                HealthScore       = if ($perf) { [int]$perf.HealthScore } else { 0 }
                HealthPosture     = $vmPosture
                OverallPosture    = $overallPosture
                LastSampleAt      = if ($perf) { [string]$perf.CaptureTime } else { $null }
                SQLInstanceCount  = $children.Count
                OpenAlertCount    = $childOpenAlerts
                CriticalAlertCount = $childCriticalAlerts
                WarningAlertCount = $childWarningAlerts
                SQLInstances      = $children
            }
        }

        $sqlInstances = $standaloneSQL
    }
    catch {
        $repositoryError = $_.Exception.Message
        Write-MonitorLog "ERROR in Get-VMHierarchyPayload: $repositoryError" -Level 'Error'
    }

    return @{
        vms = $vms
        standaloneSQL = $sqlInstances
        repositoryError = $repositoryError
    }
}

function Invoke-VMTreeQuery {
    <#
    .SYNOPSIS
        Executes mon.usp_GetVMTree and returns the result sets.
    #>
    param([int]$VMID = 0)
    $params = @{}
    if ($VMID -gt 0) { $params['VMID'] = $VMID }
    # Fall back to direct query since we can't easily call multi-resultset proc from here
    $vms = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TargetID AS VMID, ComputerName, DisplayName, EnvironmentName, IsEnabled
FROM mon.WindowsTargets
WHERE IsEnabled = 1 $(if ($VMID -gt 0) { 'AND TargetID = @VMID' })
ORDER BY DisplayName;
"@ -Parameters $params)

    $sql = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT mi.InstanceID, mi.DisplayName, mi.ServerName, mi.InstanceName,
       mi.EnvironmentName, mi.IsActive, mi.ParentVMID
FROM mon.MonitoredInstances mi
WHERE mi.IsActive = 1
$(if ($VMID -gt 0) { 'AND mi.ParentVMID = @VMID' })
ORDER BY mi.DisplayName;
"@ -Parameters $params)

    return @{ vms = $vms; sqlInstances = $sql }
}

function Get-MemoryAnalysisData {
    param([int]$InstanceID)
    if ($InstanceID -le 0) { throw 'Select an instance first.' }
    $clerks = @()
    $bufferPool = @()
    $messages = @()
    if (Test-RepositoryObjectExists -ObjectName 'mon.MemoryClerksHistory') {
        try { $clerks = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 100 CaptureTime, Type AS MemoryClerkType, Name AS ComponentDescription, CAST(PagesKB / 1024.0 AS DECIMAL(18,2)) AS MemoryUsedMB, CAST((ISNULL(VirtualMemoryCommittedKB,0) + ISNULL(AweAllocatedKB,0) + ISNULL(SharedMemoryCommittedKB,0)) / 1024.0 AS DECIMAL(18,2)) AS MemoryAllocatedMB, PressureLevel AS MemoryPressure, Recommendations AS ScalingRecommendation FROM mon.MemoryClerksHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, PagesKB DESC;' -Parameters @{ InstanceID = $InstanceID }) }
        catch { $messages += "Memory clerks query failed: $($_.Exception.Message)" }
    }
    else {
        $messages += 'Repository object mon.MemoryClerksHistory is not deployed.'
    }
    if (Test-RepositoryObjectExists -ObjectName 'mon.BufferPoolAnalysisHistory') {
        try { $bufferPool = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 100 CaptureTime, DatabaseName, PageCount AS PagesInBuffer, DirtyPages AS PagesDirty, CAST((DirtyPages * 100.0) / NULLIF(PageCount, 0) AS DECIMAL(8,2)) AS DirtyPageRatio, AvgSecondsSinceAccess AS AccessFrequency, Recommendations AS BufferPoolRecommendation FROM mon.BufferPoolAnalysisHistory WHERE InstanceID = @InstanceID ORDER BY CaptureTime DESC, PageCount DESC;' -Parameters @{ InstanceID = $InstanceID }) }
        catch { $messages += "Buffer pool query failed: $($_.Exception.Message)" }
    }
    else {
        $messages += 'Repository object mon.BufferPoolAnalysisHistory is not deployed.'
    }
    return @{
        clerks = $clerks
        bufferPool = $bufferPool
        messages = $messages
    }
}

function Get-HealthData {
    param([int]$InstanceID)
    if ($InstanceID -le 0) { throw 'Select an instance first.' }
    return @{
        health = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT ModuleName, HealthStatus, LastCollectionTime, MinutesAgo, LastStatus, DurationSeconds, ErrorMessage FROM mon.vw_CollectionHealth WHERE InstanceID = @InstanceID ORDER BY CASE HealthStatus WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 WHEN 'Healthy' THEN 3 ELSE 4 END, MinutesAgo DESC;" -Parameters @{ InstanceID = $InstanceID })
        gaps = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT ModuleName, LastCollectionTime, MinutesAgo, LastStatus, IssueDescription, Severity, ErrorMessage FROM mon.vw_CollectionGaps WHERE InstanceID = @InstanceID ORDER BY Severity DESC, MinutesAgo DESC;' -Parameters @{ InstanceID = $InstanceID })
    }
}

function Invoke-IncidentRecorderQuery {
    param([string]$ObjectName, [string]$Query, [hashtable]$Parameters)
    if (-not (Test-RepositoryObjectExists -ObjectName $ObjectName)) { return @() }
    try { return @(ConvertTo-PlainRows (Invoke-RepoQuery -Query $Query -Parameters $Parameters -Timeout 30)) }
    catch { return @([pscustomobject]@{ Status = 'QueryError'; Source = $ObjectName; Message = $_.Exception.Message }) }
}

function Get-IncidentFlightRecorder {
    param([int]$InstanceID, [int]$Hours = 24, [object]$User = $null)
    if ($InstanceID -le 0) { throw 'Select an instance first.' }
    if ($Hours -le 0) { $Hours = 24 }
    if ($Hours -gt 168) { $Hours = 168 }
    Assert-UserCanAccessInstance -User $User -InstanceID $InstanceID

    $params = @{ InstanceID = $InstanceID; Hours = $Hours }
    $instance = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 1 InstanceID, DisplayName, ServerName, InstanceName, EnvironmentName FROM mon.MonitoredInstances WHERE InstanceID = @InstanceID;' -Parameters @{ InstanceID = $InstanceID }) | Select-Object -First 1)
    $alerts = Invoke-IncidentRecorderQuery -ObjectName 'mon.vw_AlertHistoryDetailed' -Query @"
SELECT TOP 100 AlertID, DisplayName, AlertTime AS EventTime, Severity, ModuleName, AlertTitle, AlertDetails, IsAcknowledged, AcknowledgedBy
FROM mon.vw_AlertHistoryDetailed
WHERE InstanceID = @InstanceID
  AND AlertTime >= DATEADD(HOUR, -@Hours, SYSDATETIME())
ORDER BY AlertTime DESC;
"@ -Parameters $params
    $cpu = Invoke-IncidentRecorderQuery -ObjectName 'mon.CPUHistory' -Query @"
SELECT TOP 120 CaptureTime AS EventTime, SqlCPUPercent, OtherCPUPercent, IdleCPUPercent
FROM mon.CPUHistory
WHERE InstanceID = @InstanceID
  AND CaptureTime >= DATEADD(HOUR, -@Hours, SYSDATETIME())
ORDER BY CaptureTime DESC;
"@ -Parameters $params
    $memory = Invoke-IncidentRecorderQuery -ObjectName 'mon.MemoryHistory' -Query @"
SELECT TOP 120 CaptureTime AS EventTime, AvailablePhysicalMB, SqlMemoryUsedGB, PLESeconds, BufferCacheHitRatio
FROM mon.MemoryHistory
WHERE InstanceID = @InstanceID
  AND CaptureTime >= DATEADD(HOUR, -@Hours, SYSDATETIME())
ORDER BY CaptureTime DESC;
"@ -Parameters $params
    $disk = Invoke-IncidentRecorderQuery -ObjectName 'mon.DiskVolumeHistory' -Query @"
SELECT TOP 120 CaptureTime AS EventTime, VolumeMountPoint, LogicalVolumeName, FreeGB, UsedPct
FROM mon.DiskVolumeHistory
WHERE InstanceID = @InstanceID
  AND CaptureTime >= DATEADD(HOUR, -@Hours, SYSDATETIME())
ORDER BY UsedPct DESC, CaptureTime DESC;
"@ -Parameters $params
    $blocking = Invoke-IncidentRecorderQuery -ObjectName 'mon.BlockingHistory' -Query @"
SELECT TOP 80 CaptureTime AS EventTime, SessionID, BlockingSessionID, DatabaseName, WaitType, WaitTimeMS, LoginName, HostName, CommandText
FROM mon.BlockingHistory
WHERE InstanceID = @InstanceID
  AND CaptureTime >= DATEADD(HOUR, -@Hours, SYSDATETIME())
ORDER BY WaitTimeMS DESC, CaptureTime DESC;
"@ -Parameters $params
    $jobs = Invoke-IncidentRecorderQuery -ObjectName 'mon.AgentJobHistory' -Query @"
SELECT TOP 80 CaptureTime AS EventTime, JobName, LastStatus, LastRunTime, LastDurationSec, SuccessPctRecent, LastFailureMessage
FROM mon.AgentJobHistory
WHERE InstanceID = @InstanceID
  AND CaptureTime >= DATEADD(HOUR, -@Hours, SYSDATETIME())
  AND (LastStatus NOT IN ('Succeeded', 'Success') OR ISNULL(SuccessPctRecent, 100) < 90)
ORDER BY CaptureTime DESC, SuccessPctRecent ASC;
"@ -Parameters $params
    $tickets = Invoke-IncidentRecorderQuery -ObjectName 'mon.vw_TicketDetails' -Query @"
SELECT TOP 50 TicketID, TicketNumber, CreatedDate AS EventTime, TicketStatus, TicketSeverity, AssignedTo, AlertTitle, ErrorDescription, AgeMinutes
FROM mon.vw_TicketDetails
WHERE InstanceID = @InstanceID
  AND CreatedDate >= DATEADD(HOUR, -@Hours, SYSDATETIME())
ORDER BY CreatedDate DESC;
"@ -Parameters $params
    $health = Invoke-IncidentRecorderQuery -ObjectName 'mon.vw_CollectionHealth' -Query @"
SELECT ModuleName, HealthStatus, LastCollectionTime AS EventTime, MinutesAgo, LastStatus, ErrorMessage
FROM mon.vw_CollectionHealth
WHERE InstanceID = @InstanceID
ORDER BY CASE HealthStatus WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, MinutesAgo DESC;
"@ -Parameters @{ InstanceID = $InstanceID }

    $signals = @()
    $criticalAlerts = @($alerts | Where-Object { $_.Severity -eq 'Critical' }).Count
    $warningAlerts = @($alerts | Where-Object { $_.Severity -eq 'Warning' }).Count
    $maxCpu = [int](($cpu | Where-Object { $_.SqlCPUPercent -ne $null } | Measure-Object -Property SqlCPUPercent -Maximum).Maximum)
    $minMemory = [int](($memory | Where-Object { $_.AvailablePhysicalMB -ne $null } | Measure-Object -Property AvailablePhysicalMB -Minimum).Minimum)
    $maxDisk = [int](($disk | Where-Object { $_.UsedPct -ne $null } | Measure-Object -Property UsedPct -Maximum).Maximum)
    $maxBlockMs = [int](($blocking | Where-Object { $_.WaitTimeMS -ne $null } | Measure-Object -Property WaitTimeMS -Maximum).Maximum)
    $jobFailures = @($jobs).Count
    $collectorIssues = @($health | Where-Object { $_.HealthStatus -in @('Critical','Warning') }).Count

    if ($criticalAlerts -gt 0) { $signals += [pscustomobject]@{ Signal = 'Critical alert pressure'; Severity = 'Critical'; Score = [Math]::Min(35, $criticalAlerts * 7); Evidence = "$criticalAlerts critical alert(s) in the selected window." } }
    if ($warningAlerts -gt 0) { $signals += [pscustomobject]@{ Signal = 'Warning alert noise'; Severity = 'Warning'; Score = [Math]::Min(18, $warningAlerts * 3); Evidence = "$warningAlerts warning alert(s) in the selected window." } }
    if ($maxCpu -ge 85) { $signals += [pscustomobject]@{ Signal = 'CPU saturation'; Severity = 'Critical'; Score = 22; Evidence = "Peak SQL CPU reached $maxCpu%." } }
    elseif ($maxCpu -ge 70) { $signals += [pscustomobject]@{ Signal = 'CPU pressure'; Severity = 'Warning'; Score = 12; Evidence = "Peak SQL CPU reached $maxCpu%." } }
    if ($minMemory -gt 0 -and $minMemory -lt 1024) { $signals += [pscustomobject]@{ Signal = 'Low available memory'; Severity = 'Warning'; Score = 12; Evidence = "Available memory fell to $minMemory MB." } }
    if ($maxDisk -ge 90) { $signals += [pscustomobject]@{ Signal = 'Storage saturation'; Severity = 'Critical'; Score = 24; Evidence = "A volume reached $maxDisk% used." } }
    if ($maxBlockMs -ge 30000) { $signals += [pscustomobject]@{ Signal = 'Blocking chain'; Severity = 'Critical'; Score = 20; Evidence = "Blocking wait reached $maxBlockMs ms." } }
    if ($jobFailures -gt 0) { $signals += [pscustomobject]@{ Signal = 'Job failure pattern'; Severity = 'Warning'; Score = [Math]::Min(15, $jobFailures * 5); Evidence = "$jobFailures unhealthy SQL Agent job record(s)." } }
    if ($collectorIssues -gt 0) { $signals += [pscustomobject]@{ Signal = 'Collector visibility risk'; Severity = 'Warning'; Score = [Math]::Min(15, $collectorIssues * 5); Evidence = "$collectorIssues collector module(s) are warning or critical." } }

    $riskScore = [Math]::Min(100, [int](($signals | Measure-Object -Property Score -Sum).Sum))
    $likelyCause = if ($signals.Count -gt 0) { ($signals | Sort-Object Score -Descending | Select-Object -First 1).Signal } else { 'No dominant cause detected' }
    $posture = if ($riskScore -ge 70) { 'Critical' } elseif ($riskScore -ge 35) { 'Warning' } else { 'Stable' }

    $timeline = @()
    foreach ($row in @($alerts | Select-Object -First 30)) { $timeline += [pscustomobject]@{ EventTime = $row.EventTime; EventType = 'Alert'; Severity = $row.Severity; Title = $row.AlertTitle; Details = $row.ModuleName } }
    foreach ($row in @($blocking | Select-Object -First 12)) { $timeline += [pscustomobject]@{ EventTime = $row.EventTime; EventType = 'Blocking'; Severity = 'Warning'; Title = "$($row.WaitType) wait"; Details = "Session $($row.SessionID) blocked by $($row.BlockingSessionID), $($row.WaitTimeMS) ms" } }
    foreach ($row in @($jobs | Select-Object -First 12)) { $timeline += [pscustomobject]@{ EventTime = $row.EventTime; EventType = 'Agent Job'; Severity = 'Warning'; Title = $row.JobName; Details = $row.LastStatus } }
    foreach ($row in @($tickets | Select-Object -First 12)) { $timeline += [pscustomobject]@{ EventTime = $row.EventTime; EventType = 'Ticket'; Severity = $row.TicketSeverity; Title = $row.TicketNumber; Details = $row.TicketStatus } }
    $timeline = @($timeline | Sort-Object EventTime -Descending | Select-Object -First 60)

    $recommendations = @()
    if ($likelyCause -match 'CPU') { $recommendations += 'Open Top Queries and Wait Stats for the same window; look for parallelism, compile, or top CPU regressions.' }
    if ($likelyCause -match 'Storage') { $recommendations += 'Open Disks and I/O Files; validate free space, autogrowth, and high stall files before restarting services.' }
    if ($likelyCause -match 'Blocking') { $recommendations += 'Open Blocking and Long Running; capture the head blocker, command text, and database before killing a session.' }
    if ($criticalAlerts -gt 0) { $recommendations += 'Convert the dominant alert condition into one ticket and keep repeat alerts attached to that ticket.' }
    if ($collectorIssues -gt 0) { $recommendations += 'Fix collector gaps before declaring the incident resolved; visibility loss can hide the true start time.' }
    if (-not $recommendations.Count) { $recommendations += 'No dominant incident pattern was found. Keep monitoring, or widen the analysis window.' }

    return @{
        instance = @($instance | Select-Object -First 1)
        windowHours = $Hours
        summary = @{
            RiskScore = $riskScore
            Posture = $posture
            LikelyCause = $likelyCause
            CriticalAlerts = $criticalAlerts
            WarningAlerts = $warningAlerts
            Tickets = @($tickets).Count
            TimelineEvents = @($timeline).Count
        }
        signals = $signals
        timeline = $timeline
        recommendations = $recommendations
        blastRadius = @{
            Instance = if ($instance.Count) { $instance[0].DisplayName } else { "Instance $InstanceID" }
            AlertModules = @($alerts | Group-Object ModuleName | Sort-Object Count -Descending | Select-Object -First 6 | ForEach-Object { [pscustomobject]@{ ModuleName = $_.Name; Count = $_.Count } })
            AffectedDatabases = @($blocking | Where-Object { $_.DatabaseName } | Group-Object DatabaseName | Sort-Object Count -Descending | Select-Object -First 8 | ForEach-Object { [pscustomobject]@{ DatabaseName = $_.Name; Count = $_.Count } })
        }
        evidence = @{
            alerts = $alerts
            cpu = @($cpu | Select-Object -First 30)
            memory = @($memory | Select-Object -First 30)
            disk = @($disk | Select-Object -First 30)
            blocking = $blocking
            jobs = $jobs
            tickets = $tickets
            health = $health
        }
    }
}

function Get-AlertHistory {
    param($Request, [object]$User = $null)
    $severity = Get-QueryValue -Request $Request -Name 'severity' -Default 'All'
    $instanceId = Get-IntQueryValue -Request $Request -Name 'instanceId'
    $showAcknowledged = (Get-QueryValue -Request $Request -Name 'showAcknowledged' -Default 'true') -ne 'false'
    $where = ''
    $params = @{}
    if ($severity -and $severity -ne 'All') { $where += ' AND Severity = @Severity'; $params.Severity = $severity }
    if ($instanceId -gt 0) { $where += ' AND InstanceID = @InstanceID'; $params.InstanceID = $instanceId }
    elseif ($User -and (Test-RoleRequiresAssignedInstanceAccess -RoleName ([string]$User.RoleName))) {
        $ids = @($User.AllowedInstanceIDs | ForEach-Object { [int]$_ })
        if ($ids.Count -eq 0) { return @{ rows = @(); stats = @{} } }
        $where += " AND InstanceID IN ($($ids -join ','))"
    }
    if (-not $showAcknowledged) { $where += ' AND IsAcknowledged = 0' }
    $query = @"
SELECT TOP 1000
    AlertID,
    DisplayName,
    AlertTime,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    AcknowledgedTime,
    AcknowledgedBy,
    DATEDIFF(MINUTE, AlertTime, GETDATE()) AS AgeMinutes
FROM mon.vw_AlertHistoryDetailed
WHERE 1=1$where
ORDER BY AlertTime DESC;
"@
    $rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters $params)
    $stats = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT COUNT(*) AS TotalAlerts, COALESCE(SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END),0) AS CriticalCount, COALESCE(SUM(CASE WHEN Severity = 'Warning' THEN 1 ELSE 0 END),0) AS WarningCount, COALESCE(SUM(CASE WHEN IsAcknowledged = 1 THEN 1 ELSE 0 END),0) AS AcknowledgedCount, COALESCE(SUM(CASE WHEN IsAcknowledged = 0 THEN 1 ELSE 0 END),0) AS UnacknowledgedCount FROM mon.vw_AlertHistoryDetailed WHERE AlertTime >= DATEADD(DAY, -7, GETDATE())$where;" -Parameters $params)
    return @{ rows = $rows; stats = @($stats | Select-Object -First 1) }
}

function Get-BiInsights {
    param([object]$User = $null, [string]$Range = 'Last 7 Days')
    $startedAt = Get-Date
    $days = switch ($Range) {
        'Last 24 Hours' { 1 }
        'Last 7 Days' { 7 }
        'Last 30 Days' { 30 }
        'Last 90 Days' { 90 }
        default { 7 }
    }
    $params = @{ Days = $days }
    $scopeClause = ''
    $ticketScopeClause = ''
    $taskScopeClause = ''
    $groupScopeClause = ''
    $vmHealthScopeClause = ''
    $vmAlertScopeClause = ''
    if ($User -and (Test-RoleRequiresAssignedInstanceAccess -RoleName ([string]$User.RoleName))) {
        $ids = @($User.AllowedInstanceIDs | ForEach-Object { [int]$_ })
        if ($ids.Count -eq 0) {
            return @{
                kpis = @{}; scorecard = @(); alertTrends = @(); noisyAlerts = @(); capacity = @(); moduleHealth = @()
                ticketStatus = @(); ticketSeverity = @(); ticketAssignment = @()
                taskStatus = @(); taskPriority = @(); taskAssignment = @()
                applicationGroups = @(); applicationScorecard = @()
                cpuPerformance = @(); memoryPerformance = @(); diskCapacityTrend = @(); backupCompliance = @(); waitProfile = @(); topQueryCpu = @()
                vmKpis = @(); vmScorecard = @(); vmAlertTrends = @(); vmTicketSla = @(); vmCapacity = @(); vmProcessHotspots = @(); vmEventLog = @(); vmPatchPosture = @()
                messages = @('No assigned servers are available for this user.')
            }
        }
        $idList = $ids -join ','
        $params.CurrentUserID = [int]$User.UserID
        $scopeClause = " AND i.InstanceID IN ($idList)"
        $ticketScopeClause = " AND (td.InstanceID IS NULL OR td.InstanceID IN ($idList))"
        $taskScopeClause = " AND (td.InstanceID IS NULL OR td.InstanceID IN ($idList))"
        $groupScopeClause = " AND (g.GroupID IN (SELECT GroupID FROM mon.DashboardUserServerGroupAccess WHERE UserID = @CurrentUserID) OR gm.InstanceID IN ($idList))"
        $vmHealthScopeClause = " AND (map.InstanceID IS NULL OR map.InstanceID IN ($idList))"
        $vmAlertScopeClause = " AND (oa.InstanceID IS NULL OR oa.InstanceID IN ($idList))"
    }

    $messages = @()
    $kpis = @{}
    $scorecard = @()
    $alertTrends = @()
    $noisyAlerts = @()
    $capacity = @()
    $moduleHealth = @()
    $ticketStatus = @()
    $ticketSeverity = @()
    $ticketAssignment = @()
    $taskStatus = @()
    $taskPriority = @()
    $taskAssignment = @()
    $applicationGroups = @()
    $applicationScorecard = @()
    $cpuPerformance = @()
    $memoryPerformance = @()
    $diskCapacityTrend = @()
    $backupCompliance = @()
    $waitProfile = @()
    $topQueryCpu = @()
    $vmKpis = @()
    $vmScorecard = @()
    $vmAlertTrends = @()
    $vmTicketSla = @()
    $vmCapacity = @()
    $vmProcessHotspots = @()
    $vmEventLog = @()
    $vmPatchPosture = @()

    try {
        $kpiRows = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    COUNT(DISTINCT i.InstanceID) AS TotalServers,
    COALESCE(SUM(CASE WHEN recentAlerts.CriticalAlerts > 0 THEN 1 ELSE 0 END), 0) AS CriticalServers,
    COALESCE(SUM(CASE WHEN recentAlerts.WarningAlerts > 0 THEN 1 ELSE 0 END), 0) AS WarningServers,
    COALESCE(SUM(recentAlerts.OpenAlerts), 0) AS OpenAlerts,
    COALESCE(SUM(recentAlerts.RepeatCount), 0) AS AlertRepeats
FROM mon.MonitoredInstances i
OUTER APPLY (
    SELECT
        COUNT(*) AS OpenAlerts,
        SUM(CASE WHEN ah.Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlerts,
        SUM(CASE WHEN ah.Severity = 'Warning' THEN 1 ELSE 0 END) AS WarningAlerts,
        SUM(ISNULL(ah.RepeatCount, 1)) AS RepeatCount
    FROM mon.AlertHistory ah
    WHERE ah.InstanceID = i.InstanceID
      AND ISNULL(ah.IsAcknowledged, 0) = 0
      AND ah.AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())
) recentAlerts
WHERE i.IsActive = 1$scopeClause;
"@ -Parameters $params)
        $kpis = @($kpiRows | Select-Object -First 1)
    }
    catch { $messages += "BI KPI query failed: $($_.Exception.Message)" }

    try {
        $scorecard = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 100
    i.InstanceID,
    i.DisplayName,
    i.EnvironmentName,
    COALESCE(cpu.AvgCPU, 0) AS AvgCPU,
    COALESCE(cpu.PeakCPU, 0) AS PeakCPU,
    COALESCE(mem.MinMemoryMB, 0) AS MinMemoryMB,
    COALESCE(alerts.OpenAlerts, 0) AS OpenAlerts,
    COALESCE(alerts.CriticalAlerts, 0) AS CriticalAlerts,
    COALESCE(alerts.RepeatCount, 0) AS AlertRepeats,
    CASE
        WHEN COALESCE(alerts.CriticalAlerts, 0) > 0 OR COALESCE(cpu.PeakCPU, 0) >= 90 OR COALESCE(mem.MinMemoryMB, 999999) < 1024 THEN 'Critical'
        WHEN COALESCE(alerts.OpenAlerts, 0) > 0 OR COALESCE(cpu.AvgCPU, 0) >= 70 OR COALESCE(mem.MinMemoryMB, 999999) < 2048 THEN 'Warning'
        ELSE 'Healthy'
    END AS HealthPosture
FROM mon.MonitoredInstances i
OUTER APPLY (
    SELECT AVG(CAST(SqlCPUPercent AS FLOAT)) AS AvgCPU, MAX(CAST(SqlCPUPercent AS FLOAT)) AS PeakCPU
    FROM mon.CPUHistory c
    WHERE c.InstanceID = i.InstanceID AND c.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())
) cpu
OUTER APPLY (
    SELECT MIN(CAST(AvailablePhysicalMB AS FLOAT)) AS MinMemoryMB
    FROM mon.MemoryHistory m
    WHERE m.InstanceID = i.InstanceID AND m.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())
) mem
OUTER APPLY (
    SELECT COUNT(*) AS OpenAlerts,
           SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlerts,
           SUM(ISNULL(RepeatCount, 1)) AS RepeatCount
    FROM mon.AlertHistory ah
    WHERE ah.InstanceID = i.InstanceID
      AND ISNULL(ah.IsAcknowledged, 0) = 0
      AND ah.AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())
) alerts
WHERE i.IsActive = 1$scopeClause
ORDER BY CASE
    WHEN COALESCE(alerts.CriticalAlerts, 0) > 0 OR COALESCE(cpu.PeakCPU, 0) >= 90 OR COALESCE(mem.MinMemoryMB, 999999) < 1024 THEN 1
    WHEN COALESCE(alerts.OpenAlerts, 0) > 0 OR COALESCE(cpu.AvgCPU, 0) >= 70 OR COALESCE(mem.MinMemoryMB, 999999) < 2048 THEN 2
    ELSE 3
END, alerts.OpenAlerts DESC, i.DisplayName;
"@ -Parameters $params)
    }
    catch { $messages += "BI scorecard query failed: $($_.Exception.Message)" }

    try {
        $alertTrends = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    CONVERT(date, ah.AlertTime) AS AlertDate,
    ah.Severity,
    COUNT(*) AS AlertCount,
    SUM(ISNULL(ah.RepeatCount, 1)) AS RepeatCount
FROM mon.AlertHistory ah
INNER JOIN mon.MonitoredInstances i ON ah.InstanceID = i.InstanceID
WHERE ah.AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY CONVERT(date, ah.AlertTime), ah.Severity
ORDER BY AlertDate;
"@ -Parameters $params)
    }
    catch { $messages += "BI alert trend query failed: $($_.Exception.Message)" }

    try {
        $noisyAlerts = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 25
    i.DisplayName,
    ah.ModuleName,
    ah.AlertTitle,
    ah.Severity,
    COUNT(*) AS Occurrences,
    SUM(ISNULL(ah.RepeatCount, 1)) AS RepeatCount,
    MAX(ah.AlertTime) AS LastSeen
FROM mon.AlertHistory ah
INNER JOIN mon.MonitoredInstances i ON ah.InstanceID = i.InstanceID
WHERE ah.AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY i.DisplayName, ah.ModuleName, ah.AlertTitle, ah.Severity
ORDER BY RepeatCount DESC, Occurrences DESC, LastSeen DESC;
"@ -Parameters $params)
    }
    catch { $messages += "BI noisy alert query failed: $($_.Exception.Message)" }

    try {
        $capacity = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 25
    i.DisplayName,
    d.VolumeMountPoint,
    MAX(CAST(d.UsedPct AS FLOAT)) AS PeakUsedPct,
    MIN(CAST(d.FreeGB AS FLOAT)) AS MinFreeGB,
    MAX(d.CaptureTime) AS LastCapture
FROM mon.DiskVolumeHistory d
INNER JOIN mon.MonitoredInstances i ON d.InstanceID = i.InstanceID
WHERE d.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY i.DisplayName, d.VolumeMountPoint
ORDER BY PeakUsedPct DESC, MinFreeGB ASC;
"@ -Parameters $params)
    }
    catch { $messages += "BI capacity query failed: $($_.Exception.Message)" }

    try {
        if (Test-RepositoryObjectExists -ObjectName 'mon.vw_CollectionHealth') {
            $moduleHealth = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    h.ModuleName,
    h.HealthStatus,
    COUNT(*) AS ModuleCount
FROM mon.vw_CollectionHealth h
INNER JOIN mon.MonitoredInstances i ON h.InstanceID = i.InstanceID
WHERE 1 = 1$scopeClause
GROUP BY h.ModuleName, h.HealthStatus
ORDER BY h.ModuleName, h.HealthStatus;
"@ -Parameters $params)
        }
    }
    catch { $messages += "BI module health query failed: $($_.Exception.Message)" }

    try {
        $ticketStatus = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    ts.StatusName AS TicketStatus,
    COUNT(td.TicketID) AS TicketCount,
    AVG(CAST(td.AgeMinutes AS FLOAT)) AS AvgAgeMinutes,
    AVG(CAST(td.ResolutionMinutes AS FLOAT)) AS AvgResolutionMinutes
FROM mon.TicketStatus ts
LEFT JOIN mon.vw_TicketDetails td
    ON td.TicketStatusID = ts.TicketStatusID
   AND td.CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$ticketScopeClause
WHERE ts.IsActive = 1
GROUP BY ts.TicketStatusID, ts.StatusName
ORDER BY ts.TicketStatusID;
"@ -Parameters $params)

        $ticketSeverity = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    tsv.SeverityName AS TicketSeverity,
    COUNT(td.TicketID) AS TicketCount,
    AVG(CAST(td.ResolutionMinutes AS FLOAT)) AS AvgResolutionMinutes
FROM mon.TicketSeverity tsv
LEFT JOIN mon.vw_TicketDetails td
    ON td.TicketSeverityID = tsv.TicketSeverityID
   AND td.CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$ticketScopeClause
WHERE tsv.IsActive = 1
GROUP BY tsv.TicketSeverityID, tsv.SeverityName, tsv.SeverityOrder
ORDER BY tsv.SeverityOrder, tsv.TicketSeverityID;
"@ -Parameters $params)

        $ticketAssignment = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 25
    ISNULL(NULLIF(td.AssignedTo, ''), 'Unassigned') AS AssignedTo,
    COUNT(*) AS TicketCount,
    SUM(CASE WHEN td.TicketStatusID IN (4,5) THEN 1 ELSE 0 END) AS ClosedTicketCount,
    AVG(CAST(td.ResolutionMinutes AS FLOAT)) AS AvgResolutionMinutes
FROM mon.vw_TicketDetails td
WHERE td.CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$ticketScopeClause
GROUP BY ISNULL(NULLIF(td.AssignedTo, ''), 'Unassigned')
ORDER BY TicketCount DESC, AssignedTo;
"@ -Parameters $params)
    }
    catch { $messages += "BI ticket dataset query failed: $($_.Exception.Message)" }

    try {
        $taskStatus = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    ts.StatusName AS TaskStatus,
    COUNT(td.TaskID) AS TaskCount,
    SUM(CASE WHEN ISNULL(td.IsOverdue, 0) = 1 THEN 1 ELSE 0 END) AS OverdueCount
FROM mon.TaskStatus ts
LEFT JOIN mon.vw_TaskDetails td
    ON td.TaskStatusID = ts.TaskStatusID
   AND td.CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$taskScopeClause
WHERE ts.IsActive = 1
GROUP BY ts.TaskStatusID, ts.StatusName
ORDER BY ts.TaskStatusID;
"@ -Parameters $params)

        $taskPriority = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    tp.PriorityName AS TaskPriority,
    COUNT(td.TaskID) AS TaskCount,
    SUM(CASE WHEN ISNULL(td.IsOverdue, 0) = 1 THEN 1 ELSE 0 END) AS OverdueCount
FROM mon.TaskPriority tp
LEFT JOIN mon.vw_TaskDetails td
    ON td.TaskPriorityID = tp.TaskPriorityID
   AND td.CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$taskScopeClause
WHERE tp.IsActive = 1
GROUP BY tp.TaskPriorityID, tp.PriorityName, tp.PriorityOrder
ORDER BY tp.PriorityOrder, tp.TaskPriorityID;
"@ -Parameters $params)

        $taskAssignment = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 25
    ISNULL(NULLIF(td.AssignedTo, ''), 'Unassigned') AS AssignedTo,
    COUNT(*) AS TaskCount,
    SUM(CASE WHEN td.TaskStatusID = 4 THEN 1 ELSE 0 END) AS CompletedCount,
    SUM(CASE WHEN ISNULL(td.IsOverdue, 0) = 1 THEN 1 ELSE 0 END) AS OverdueCount
FROM mon.vw_TaskDetails td
WHERE td.CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$taskScopeClause
GROUP BY ISNULL(NULLIF(td.AssignedTo, ''), 'Unassigned')
ORDER BY TaskCount DESC, AssignedTo;
"@ -Parameters $params)
    }
    catch { $messages += "BI task dataset query failed: $($_.Exception.Message)" }

    try {
        $applicationGroups = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    g.GroupID,
    g.GroupName,
    ISNULL(NULLIF(g.ApplicationName, ''), g.GroupName) AS ApplicationName,
    g.OwnerName,
    COUNT(DISTINCT gm.InstanceID) AS ServerCount,
    COUNT(DISTINCT uga.UserID) AS AssignedUserCount
FROM mon.DashboardServerGroups g
LEFT JOIN mon.DashboardServerGroupMembers gm ON g.GroupID = gm.GroupID
LEFT JOIN mon.DashboardUserServerGroupAccess uga ON g.GroupID = uga.GroupID
WHERE g.IsActive = 1$groupScopeClause
GROUP BY g.GroupID, g.GroupName, g.ApplicationName, g.OwnerName
ORDER BY ApplicationName, g.GroupName;
"@ -Parameters $params)

        $applicationScorecard = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 250
    g.GroupID,
    g.GroupName,
    ISNULL(NULLIF(g.ApplicationName, ''), g.GroupName) AS ApplicationName,
    g.OwnerName,
    i.InstanceID,
    i.DisplayName,
    COALESCE(cpu.PeakCPU, 0) AS PeakCPU,
    COALESCE(mem.MinMemoryMB, 0) AS MinMemoryMB,
    COALESCE(alerts.OpenAlerts, 0) AS OpenAlerts,
    COALESCE(alerts.CriticalAlerts, 0) AS CriticalAlerts,
    CASE
        WHEN COALESCE(alerts.CriticalAlerts, 0) > 0 OR COALESCE(cpu.PeakCPU, 0) >= 90 OR COALESCE(mem.MinMemoryMB, 999999) < 1024 THEN 'Critical'
        WHEN COALESCE(alerts.OpenAlerts, 0) > 0 OR COALESCE(cpu.PeakCPU, 0) >= 70 OR COALESCE(mem.MinMemoryMB, 999999) < 2048 THEN 'Warning'
        ELSE 'Healthy'
    END AS HealthPosture
FROM mon.DashboardServerGroups g
INNER JOIN mon.DashboardServerGroupMembers gm ON g.GroupID = gm.GroupID
INNER JOIN mon.MonitoredInstances i ON gm.InstanceID = i.InstanceID AND i.IsActive = 1
OUTER APPLY (
    SELECT MAX(CAST(SqlCPUPercent AS FLOAT)) AS PeakCPU
    FROM mon.CPUHistory c
    WHERE c.InstanceID = i.InstanceID AND c.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())
) cpu
OUTER APPLY (
    SELECT MIN(CAST(AvailablePhysicalMB AS FLOAT)) AS MinMemoryMB
    FROM mon.MemoryHistory m
    WHERE m.InstanceID = i.InstanceID AND m.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())
) mem
OUTER APPLY (
    SELECT COUNT(*) AS OpenAlerts,
           SUM(CASE WHEN Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlerts
    FROM mon.AlertHistory ah
    WHERE ah.InstanceID = i.InstanceID
      AND ISNULL(ah.IsAcknowledged, 0) = 0
      AND ah.AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())
) alerts
WHERE g.IsActive = 1$groupScopeClause
ORDER BY ApplicationName, g.GroupName, HealthPosture, OpenAlerts DESC;
"@ -Parameters $params)
    }
    catch { $messages += "BI application group query failed: $($_.Exception.Message)" }

    try {
        $cpuPerformance = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 100
    i.DisplayName,
    AVG(CAST(c.SqlCPUPercent AS FLOAT)) AS AvgCPU,
    MAX(CAST(c.SqlCPUPercent AS FLOAT)) AS PeakCPU,
    COUNT(*) AS SampleCount
FROM mon.CPUHistory c
INNER JOIN mon.MonitoredInstances i ON c.InstanceID = i.InstanceID
WHERE c.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY i.DisplayName
ORDER BY PeakCPU DESC, AvgCPU DESC;
"@ -Parameters $params)

        $memoryPerformance = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 100
    i.DisplayName,
    MIN(CAST(m.AvailablePhysicalMB AS FLOAT)) AS MinAvailableMB,
    AVG(CAST(m.SqlMemoryUsedGB AS FLOAT)) AS AvgSqlMemoryGB,
    AVG(CAST(m.BufferCacheHitRatio AS FLOAT)) AS AvgBufferCacheHitRatio,
    COUNT(*) AS SampleCount
FROM mon.MemoryHistory m
INNER JOIN mon.MonitoredInstances i ON m.InstanceID = i.InstanceID
WHERE m.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY i.DisplayName
ORDER BY MinAvailableMB ASC, AvgSqlMemoryGB DESC;
"@ -Parameters $params)

        $diskCapacityTrend = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 150
    i.DisplayName,
    d.VolumeMountPoint,
    MAX(CAST(d.UsedPct AS FLOAT)) AS PeakUsedPct,
    MIN(CAST(d.FreeGB AS FLOAT)) AS MinFreeGB,
    MAX(d.CaptureTime) AS LastCapture
FROM mon.DiskVolumeHistory d
INNER JOIN mon.MonitoredInstances i ON d.InstanceID = i.InstanceID
WHERE d.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY i.DisplayName, d.VolumeMountPoint
ORDER BY PeakUsedPct DESC, MinFreeGB ASC;
"@ -Parameters $params)

        $backupCompliance = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 150
    i.DisplayName,
    b.DatabaseName,
    MAX(CAST(b.LastFullHours AS FLOAT)) AS LastFullHours,
    MAX(CAST(b.LastDiffHours AS FLOAT)) AS LastDiffHours,
    MAX(CAST(b.LastLogHours AS FLOAT)) AS LastLogHours,
    MAX(b.StatusText) AS StatusText,
    MAX(b.CaptureTime) AS LastCapture
FROM mon.BackupStatusHistory b
INNER JOIN mon.MonitoredInstances i ON b.InstanceID = i.InstanceID
WHERE b.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY i.DisplayName, b.DatabaseName
ORDER BY LastFullHours DESC, i.DisplayName, b.DatabaseName;
"@ -Parameters $params)
    }
    catch { $messages += "BI performance/capacity dataset query failed: $($_.Exception.Message)" }

    try {
        if (Test-RepositoryObjectExists -ObjectName 'dbo.WaitStats') {
            $waitProfile = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 50
    w.WaitType,
    SUM(CAST(w.WaitTimeMs AS FLOAT)) AS WaitTimeMs,
    SUM(CAST(w.WaitingTasksCount AS BIGINT)) AS WaitCount,
    MAX(CAST(w.MaxWaitTimeMs AS FLOAT)) AS MaxWaitTimeMs
FROM dbo.WaitStats w
INNER JOIN mon.MonitoredInstances i ON w.InstanceID = i.InstanceID
WHERE w.CollectionDateTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY w.WaitType
ORDER BY WaitTimeMs DESC;
"@ -Parameters $params)
        }
        if (Test-RepositoryObjectExists -ObjectName 'dbo.TopQueries') {
            $topQueryCpu = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 50
    i.DisplayName,
    CAST(SUBSTRING(t.QueryText, 1, 250) AS NVARCHAR(250)) AS QueryText,
    MAX(CAST(t.AvgCpuTime AS FLOAT)) AS AvgCpuTime,
    MAX(CAST(t.AvgDuration AS FLOAT)) AS AvgDuration,
    SUM(CAST(t.CountExecutions AS BIGINT)) AS CountExecutions
FROM dbo.TopQueries t
INNER JOIN mon.MonitoredInstances i ON t.InstanceID = i.InstanceID
WHERE t.CollectionDateTime >= DATEADD(DAY, -@Days, SYSDATETIME())$scopeClause
GROUP BY i.DisplayName, CAST(SUBSTRING(t.QueryText, 1, 250) AS NVARCHAR(250))
ORDER BY AvgCpuTime DESC, CountExecutions DESC;
"@ -Parameters $params)
        }
    }
    catch { $messages += "BI advanced performance dataset query failed: $($_.Exception.Message)" }

    try {
        if (Test-RepositoryObjectExists -ObjectName 'mon.vw_WindowsLatestHealth') {
            $vmKpiRows = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    COUNT(DISTINCT h.TargetID) AS TotalVMs,
    COALESCE(SUM(CASE WHEN h.HealthPosture = 'Critical' THEN 1 ELSE 0 END), 0) AS CriticalVMs,
    COALESCE(SUM(CASE WHEN h.HealthPosture = 'Warning' THEN 1 ELSE 0 END), 0) AS WarningVMs,
    COALESCE(SUM(CASE WHEN h.MinutesSinceLastSample >= 15 OR h.CaptureTime IS NULL THEN 1 ELSE 0 END), 0) AS StaleVMs,
    COALESCE((SELECT COUNT(*) FROM mon.vw_WindowsOpenAlerts oa WHERE 1 = 1$vmAlertScopeClause), 0) AS OpenVMAlerts,
    COALESCE((SELECT COUNT(*) FROM mon.vw_WindowsOpenAlerts oa WHERE oa.Severity = 'Critical'$vmAlertScopeClause), 0) AS CriticalVMAlerts
FROM mon.vw_WindowsLatestHealth h
LEFT JOIN mon.WindowsTargetInstanceMap map ON map.TargetID = h.TargetID
WHERE h.IsEnabled = 1$vmHealthScopeClause;
"@ -Parameters $params)
            $vmKpis = @($vmKpiRows | Select-Object -First 1)

            $vmScorecard = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 250
    h.TargetID,
    h.ComputerName,
    h.DisplayName,
    h.EnvironmentName,
    h.ApplicationName,
    h.SiteName,
    h.OSName,
    h.TotalMemoryGB,
    h.CaptureTime,
    h.CPUPercent,
    h.MemoryUsedPercent,
    h.MemoryAvailableGB,
    h.DiskUsedPercent,
    h.DiskFreeGB,
    h.ServiceStoppedCount,
    h.HealthScore,
    h.HealthPosture,
    h.MinutesSinceLastSample,
    COALESCE(alerts.OpenAlerts, 0) AS OpenAlerts,
    COALESCE(alerts.CriticalAlerts, 0) AS CriticalAlerts,
    COALESCE(tickets.OpenTickets, 0) AS OpenTickets
FROM mon.vw_WindowsLatestHealth h
LEFT JOIN mon.WindowsTargetInstanceMap map ON map.TargetID = h.TargetID
OUTER APPLY (
    SELECT COUNT(*) AS OpenAlerts,
           SUM(CASE WHEN oa.Severity = 'Critical' THEN 1 ELSE 0 END) AS CriticalAlerts
    FROM mon.vw_WindowsOpenAlerts oa
    WHERE oa.TargetID = h.TargetID
) alerts
OUTER APPLY (
    SELECT COUNT(*) AS OpenTickets
    FROM mon.vw_TicketDetails td
    WHERE td.Category = 'VM Monitoring'
      AND td.TicketStatus NOT IN ('Resolved', 'Closed', 'Cancelled')
      AND (td.InstanceID = map.InstanceID OR td.InstanceName = h.DisplayName)
) tickets
WHERE h.IsEnabled = 1$vmHealthScopeClause
ORDER BY CASE h.HealthPosture WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 WHEN 'Healthy' THEN 3 ELSE 4 END,
         COALESCE(alerts.OpenAlerts, 0) DESC,
         h.DisplayName;
"@ -Parameters $params)

            $vmAlertTrends = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    CONVERT(date, oa.AlertTime) AS AlertDate,
    oa.Severity,
    oa.ModuleName,
    COUNT(*) AS AlertCount,
    SUM(ISNULL(oa.RepeatCount, 1)) AS RepeatCount
FROM mon.vw_WindowsOpenAlerts oa
WHERE oa.AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())$vmAlertScopeClause
GROUP BY CONVERT(date, oa.AlertTime), oa.Severity, oa.ModuleName
ORDER BY AlertDate, oa.Severity, oa.ModuleName;
"@ -Parameters $params)

            $vmTicketSla = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    td.TicketSeverity,
    ISNULL(NULLIF(td.Subcategory, ''), 'General') AS Subcategory,
    ISNULL(NULLIF(td.AssignmentGroup, ''), 'Infrastructure Operations') AS AssignmentGroup,
    CASE
        WHEN td.TicketStatus IN ('Resolved', 'Closed', 'Cancelled') THEN 'Closed'
        WHEN td.SLADueDate IS NULL THEN 'No SLA'
        WHEN td.SLADueDate < SYSDATETIME() THEN 'Breached'
        WHEN td.SLADueDate < DATEADD(HOUR, 1, SYSDATETIME()) THEN 'Due Soon'
        ELSE 'Within SLA'
    END AS SLAStatus,
    COUNT(*) AS TicketCount,
    AVG(CAST(td.AgeMinutes AS FLOAT)) AS AvgAgeMinutes,
    MIN(td.SLADueDate) AS NextSLADue
FROM mon.vw_TicketDetails td
WHERE td.Category = 'VM Monitoring'
  AND td.CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$ticketScopeClause
GROUP BY td.TicketSeverity, ISNULL(NULLIF(td.Subcategory, ''), 'General'), ISNULL(NULLIF(td.AssignmentGroup, ''), 'Infrastructure Operations'),
    CASE
        WHEN td.TicketStatus IN ('Resolved', 'Closed', 'Cancelled') THEN 'Closed'
        WHEN td.SLADueDate IS NULL THEN 'No SLA'
        WHEN td.SLADueDate < SYSDATETIME() THEN 'Breached'
        WHEN td.SLADueDate < DATEADD(HOUR, 1, SYSDATETIME()) THEN 'Due Soon'
        ELSE 'Within SLA'
    END
ORDER BY CASE td.TicketSeverity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 WHEN 'Low' THEN 4 ELSE 5 END, TicketCount DESC;
"@ -Parameters $params)

            $vmCapacity = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 150
    wt.DisplayName,
    wt.ComputerName,
    ds.DriveLetter,
    MAX(CAST(ds.UsedPercent AS FLOAT)) AS PeakUsedPercent,
    MIN(CAST(ds.FreeGB AS FLOAT)) AS MinFreeGB,
    MAX(ds.CaptureTime) AS LastCapture
FROM mon.WindowsDiskSamples ds
INNER JOIN mon.WindowsTargets wt ON wt.TargetID = ds.TargetID
LEFT JOIN mon.WindowsTargetInstanceMap map ON map.TargetID = wt.TargetID
WHERE ds.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())$vmHealthScopeClause
GROUP BY wt.DisplayName, wt.ComputerName, ds.DriveLetter
ORDER BY PeakUsedPercent DESC, MinFreeGB ASC;
"@ -Parameters $params)

            $vmProcessHotspots = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 100
    wt.DisplayName,
    ps.RankingType,
    ps.ProcessName,
    MAX(CAST(ps.CPUPercent AS FLOAT)) AS PeakCPUPercent,
    MAX(CAST(ps.WorkingSetMB AS FLOAT)) AS PeakWorkingSetMB,
    COUNT(*) AS SampleCount,
    MAX(ps.CaptureTime) AS LastCapture
FROM mon.WindowsProcessSamples ps
INNER JOIN mon.WindowsTargets wt ON wt.TargetID = ps.TargetID
LEFT JOIN mon.WindowsTargetInstanceMap map ON map.TargetID = wt.TargetID
WHERE ps.CaptureTime >= DATEADD(DAY, -@Days, SYSDATETIME())$vmHealthScopeClause
GROUP BY wt.DisplayName, ps.RankingType, ps.ProcessName
ORDER BY PeakCPUPercent DESC, PeakWorkingSetMB DESC;
"@ -Parameters $params)

            $vmEventLog = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 100
    wt.DisplayName,
    es.LogName,
    es.LevelName,
    es.ProviderName,
    COUNT(*) AS EventCount,
    MAX(es.EventTime) AS LastEventTime
FROM mon.WindowsEventSamples es
INNER JOIN mon.WindowsTargets wt ON wt.TargetID = es.TargetID
LEFT JOIN mon.WindowsTargetInstanceMap map ON map.TargetID = wt.TargetID
WHERE es.EventTime >= DATEADD(DAY, -@Days, SYSDATETIME())$vmHealthScopeClause
GROUP BY wt.DisplayName, es.LogName, es.LevelName, es.ProviderName
ORDER BY EventCount DESC, LastEventTime DESC;
"@ -Parameters $params)

            $vmPatchPosture = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 150
    wt.DisplayName,
    wt.ComputerName,
    COUNT(DISTINCT hf.HotFixID) AS HotFixCount,
    MAX(hf.InstalledOn) AS LastInstalledOn,
    MAX(hf.CaptureTime) AS LastCapture,
    DATEDIFF(DAY, MAX(hf.InstalledOn), SYSDATETIME()) AS DaysSinceLastPatch
FROM mon.WindowsTargets wt
LEFT JOIN mon.WindowsHotFixSamples hf ON hf.TargetID = wt.TargetID
LEFT JOIN mon.WindowsTargetInstanceMap map ON map.TargetID = wt.TargetID
WHERE wt.IsEnabled = 1$vmHealthScopeClause
GROUP BY wt.DisplayName, wt.ComputerName
ORDER BY DaysSinceLastPatch DESC, wt.DisplayName;
"@ -Parameters $params)
        }
    }
    catch { $messages += "BI VM Monitoring dataset query failed: $($_.Exception.Message)" }

    try {
        Invoke-RepoNonQuery -Query 'INSERT INTO mon.BIInsightPerformanceRuns (DatasetKey, DurationMs, [RowCount], ExecutedBy) VALUES (@DatasetKey, @DurationMs, @RowCount, @ExecutedBy);' -Parameters @{
            DatasetKey = 'bi-insights'
            DurationMs = [int]([Math]::Max(0, ((Get-Date) - $startedAt).TotalMilliseconds))
            RowCount = @($scorecard).Count + @($noisyAlerts).Count + @($capacity).Count + @($moduleHealth).Count + @($ticketSeverity).Count + @($taskPriority).Count + @($applicationScorecard).Count + @($vmScorecard).Count + @($vmAlertTrends).Count + @($vmTicketSla).Count
            ExecutedBy = if ($User) { [string]$User.UserName } else { 'anonymous' }
        } -Timeout 5
    } catch {}

    return @{
        range = $Range
        kpis = $kpis
        scorecard = $scorecard
        alertTrends = $alertTrends
        noisyAlerts = $noisyAlerts
        capacity = $capacity
        moduleHealth = $moduleHealth
        ticketStatus = $ticketStatus
        ticketSeverity = $ticketSeverity
        ticketAssignment = $ticketAssignment
        taskStatus = $taskStatus
        taskPriority = $taskPriority
        taskAssignment = $taskAssignment
        applicationGroups = $applicationGroups
        applicationScorecard = $applicationScorecard
        cpuPerformance = $cpuPerformance
        memoryPerformance = $memoryPerformance
        diskCapacityTrend = $diskCapacityTrend
        backupCompliance = $backupCompliance
        waitProfile = $waitProfile
        topQueryCpu = $topQueryCpu
        vmKpis = $vmKpis
        vmScorecard = $vmScorecard
        vmAlertTrends = $vmAlertTrends
        vmTicketSla = $vmTicketSla
        vmCapacity = $vmCapacity
        vmProcessHotspots = $vmProcessHotspots
        vmEventLog = $vmEventLog
        vmPatchPosture = $vmPatchPosture
        messages = $messages
    }
}

function Get-BiManagementReportPeriod {
    param([string]$Period)
    $name = if ([string]::IsNullOrWhiteSpace($Period)) { 'Weekly' } else { [string]$Period }
    switch -Regex ($name) {
        '^Daily$' { return @{ Period = 'Daily'; Days = 1; BucketExpression = "CONVERT(NVARCHAR(13), EventDate, 120) + N':00'"; BucketLabel = 'Hour' } }
        '^Monthly$' { return @{ Period = 'Monthly'; Days = 30; BucketExpression = "CONVERT(NVARCHAR(10), EventDate, 120)"; BucketLabel = 'Date' } }
        '^Yearly$' { return @{ Period = 'Yearly'; Days = 365; BucketExpression = "CONVERT(NVARCHAR(7), EventDate, 120)"; BucketLabel = 'Month' } }
        default { return @{ Period = 'Weekly'; Days = 7; BucketExpression = "CONVERT(NVARCHAR(10), EventDate, 120)"; BucketLabel = 'Date' } }
    }
}

function Get-BiManagementReport {
    param([object]$User = $null, [string]$Period = 'Weekly')
    $periodInfo = Get-BiManagementReportPeriod -Period $Period
    $days = [int]$periodInfo.Days
    $bucketExpression = [string]$periodInfo.BucketExpression
    $params = @{ Days = $days }
    $alertScopeClause = ''
    $workScopeClause = ''
    if ($User -and (Test-RoleRequiresAssignedInstanceAccess -RoleName ([string]$User.RoleName))) {
        $ids = @($User.AllowedInstanceIDs | ForEach-Object { [int]$_ })
        if ($ids.Count -eq 0) {
            return @{
                period = $periodInfo.Period
                generatedAt = (Get-Date).ToString('s')
                summary = @([pscustomobject]@{ Metric = 'Access Scope'; Value = 'No assigned servers are available for this user.' })
                alertDetails = @(); ticketDetails = @(); taskDetails = @()
                alertTrend = @(); alertSeverity = @(); alertModule = @()
                ticketTrend = @(); ticketStatus = @(); ticketSeverity = @(); ticketAssignment = @()
                taskTrend = @(); taskStatus = @(); taskPriority = @(); taskAssignment = @()
            }
        }
        $idList = $ids -join ','
        $alertScopeClause = " AND (InstanceID IS NULL OR InstanceID IN ($idList))"
        $workScopeClause = " AND (InstanceName IS NULL OR InstanceName IN (SELECT DisplayName FROM mon.MonitoredInstances WHERE InstanceID IN ($idList)))"
    }

    $summary = @()
    $alertDetails = @()
    $ticketDetails = @()
    $taskDetails = @()
    $alertTrend = @()
    $alertSeverity = @()
    $alertModule = @()
    $ticketTrend = @()
    $ticketStatus = @()
    $ticketSeverity = @()
    $ticketAssignment = @()
    $taskTrend = @()
    $taskStatus = @()
    $taskPriority = @()
    $taskAssignment = @()
    $messages = @()

    try {
        $alertDetails = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 5000
    AlertID,
    DisplayName,
    AlertTime,
    Severity,
    ModuleName,
    AlertTitle,
    ISNULL(RepeatCount, 1) AS RepeatCount,
    IsAcknowledged,
    AcknowledgedBy,
    AcknowledgedTime,
    DATEDIFF(MINUTE, AlertTime, SYSDATETIME()) AS AgeMinutes
FROM mon.vw_AlertHistoryDetailed
WHERE AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())$alertScopeClause
ORDER BY AlertTime DESC;
"@ -Parameters $params)

        $alertTrend = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
WITH scoped AS (
    SELECT AlertTime AS EventDate, Severity, ISNULL(RepeatCount, 1) AS RepeatCount, InstanceID
    FROM mon.vw_AlertHistoryDetailed
    WHERE AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())$alertScopeClause
)
SELECT $bucketExpression AS PeriodBucket, Severity, COUNT(*) AS AlertCount, SUM(RepeatCount) AS RepeatCount
FROM scoped
GROUP BY $bucketExpression, Severity
ORDER BY PeriodBucket, Severity;
"@ -Parameters $params)

        $alertSeverity = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT Severity, COUNT(*) AS AlertCount, SUM(ISNULL(RepeatCount, 1)) AS RepeatCount
FROM mon.vw_AlertHistoryDetailed
WHERE AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())$alertScopeClause
GROUP BY Severity
ORDER BY CASE Severity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Warning' THEN 3 ELSE 4 END, Severity;
"@ -Parameters $params)

        $alertModule = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 25 ModuleName, COUNT(*) AS AlertCount, SUM(ISNULL(RepeatCount, 1)) AS RepeatCount, MAX(AlertTime) AS LastSeen
FROM mon.vw_AlertHistoryDetailed
WHERE AlertTime >= DATEADD(DAY, -@Days, SYSDATETIME())$alertScopeClause
GROUP BY ModuleName
ORDER BY RepeatCount DESC, AlertCount DESC;
"@ -Parameters $params)
    }
    catch { $messages += "Alert report query failed: $($_.Exception.Message)" }

    try {
        $ticketDetails = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 5000
    TicketID,
    TicketNumber,
    InstanceName,
    TicketStatus,
    TicketSeverity,
    CreatedBy,
    AssignedTo,
    BusinessService,
    Category,
    AssignmentGroup,
    CreatedDate,
    AcknowledgedDate,
    ResolvedDate,
    AgeMinutes,
    AcknowledgementMinutes,
    ResolutionMinutes,
    AlertTitle
FROM mon.vw_TicketDetails
WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause
ORDER BY CreatedDate DESC;
"@ -Parameters $params)

        $ticketTrend = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
WITH scoped AS (
    SELECT CreatedDate AS EventDate, TicketStatus, TicketSeverity
    FROM mon.vw_TicketDetails
    WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause
)
SELECT $bucketExpression AS PeriodBucket, TicketStatus, COUNT(*) AS TicketCount
FROM scoped
GROUP BY $bucketExpression, TicketStatus
ORDER BY PeriodBucket, TicketStatus;
"@ -Parameters $params)

        $ticketStatus = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT TicketStatus, COUNT(*) AS TicketCount, AVG(CAST(AgeMinutes AS FLOAT)) AS AvgAgeMinutes, AVG(CAST(ResolutionMinutes AS FLOAT)) AS AvgResolutionMinutes FROM mon.vw_TicketDetails WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause GROUP BY TicketStatus ORDER BY TicketCount DESC;" -Parameters $params)
        $ticketSeverity = ConvertTo-PlainRows (Invoke-RepoQuery -Query "WITH scoped AS (SELECT * FROM mon.vw_TicketDetails WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause) SELECT tsv.SeverityName AS TicketSeverity, COUNT(td.TicketID) AS TicketCount, AVG(CAST(td.ResolutionMinutes AS FLOAT)) AS AvgResolutionMinutes FROM mon.TicketSeverity tsv LEFT JOIN scoped td ON td.TicketSeverityID = tsv.TicketSeverityID WHERE tsv.IsActive = 1 GROUP BY tsv.TicketSeverityID, tsv.SeverityName, tsv.SeverityOrder ORDER BY tsv.SeverityOrder, tsv.TicketSeverityID;" -Parameters $params)
        $ticketAssignment = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT TOP 25 ISNULL(NULLIF(AssignedTo, ''), 'Unassigned') AS AssignedTo, COUNT(*) AS TicketCount, SUM(CASE WHEN TicketStatusID IN (4,5) THEN 1 ELSE 0 END) AS ClosedTicketCount, AVG(CAST(ResolutionMinutes AS FLOAT)) AS AvgResolutionMinutes FROM mon.vw_TicketDetails WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause GROUP BY ISNULL(NULLIF(AssignedTo, ''), 'Unassigned') ORDER BY TicketCount DESC;" -Parameters $params)
    }
    catch { $messages += "Ticket report query failed: $($_.Exception.Message)" }

    try {
        $taskDetails = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 5000
    TaskID,
    TaskTitle,
    CreatedBy,
    AssignedTo,
    TaskStatus,
    TaskPriority,
    InstanceName,
    DueDate,
    StartDate,
    CompletedDate,
    CreatedDate,
    ModifiedDate,
    IsOverdue
FROM mon.vw_TaskDetails
WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause
ORDER BY CreatedDate DESC;
"@ -Parameters $params)

        $taskTrend = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
WITH scoped AS (
    SELECT CreatedDate AS EventDate, TaskStatus, TaskPriority
    FROM mon.vw_TaskDetails
    WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause
)
SELECT $bucketExpression AS PeriodBucket, TaskStatus, COUNT(*) AS TaskCount
FROM scoped
GROUP BY $bucketExpression, TaskStatus
ORDER BY PeriodBucket, TaskStatus;
"@ -Parameters $params)

        $taskStatus = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT TaskStatus, COUNT(*) AS TaskCount, SUM(CASE WHEN IsOverdue = 1 THEN 1 ELSE 0 END) AS OverdueCount FROM mon.vw_TaskDetails WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause GROUP BY TaskStatus ORDER BY TaskCount DESC;" -Parameters $params)
        $taskPriority = ConvertTo-PlainRows (Invoke-RepoQuery -Query "WITH scoped AS (SELECT * FROM mon.vw_TaskDetails WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause) SELECT tp.PriorityName AS TaskPriority, COUNT(td.TaskID) AS TaskCount, SUM(CASE WHEN ISNULL(td.IsOverdue, 0) = 1 THEN 1 ELSE 0 END) AS OverdueCount FROM mon.TaskPriority tp LEFT JOIN scoped td ON td.TaskPriorityID = tp.TaskPriorityID WHERE tp.IsActive = 1 GROUP BY tp.TaskPriorityID, tp.PriorityName, tp.PriorityOrder ORDER BY tp.PriorityOrder, tp.TaskPriorityID;" -Parameters $params)
        $taskAssignment = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT TOP 25 ISNULL(NULLIF(AssignedTo, ''), 'Unassigned') AS AssignedTo, COUNT(*) AS TaskCount, SUM(CASE WHEN TaskStatusID = 4 THEN 1 ELSE 0 END) AS CompletedCount, SUM(CASE WHEN IsOverdue = 1 THEN 1 ELSE 0 END) AS OverdueCount FROM mon.vw_TaskDetails WHERE CreatedDate >= DATEADD(DAY, -@Days, SYSDATETIME())$workScopeClause GROUP BY ISNULL(NULLIF(AssignedTo, ''), 'Unassigned') ORDER BY TaskCount DESC;" -Parameters $params)
    }
    catch { $messages += "Task report query failed: $($_.Exception.Message)" }

    $summary += [pscustomobject]@{ Metric = 'Report Period'; Value = $periodInfo.Period }
    $summary += [pscustomobject]@{ Metric = 'Window Days'; Value = $days }
    $summary += [pscustomobject]@{ Metric = 'Generated At'; Value = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
    $summary += [pscustomobject]@{ Metric = 'Generated By'; Value = if ($User) { [string]$User.UserName } else { 'anonymous' } }
    $summary += [pscustomobject]@{ Metric = 'Alerts'; Value = @($alertDetails).Count }
    $summary += [pscustomobject]@{ Metric = 'Alert Repeats'; Value = [int]((@($alertDetails) | Measure-Object -Property RepeatCount -Sum).Sum) }
    $summary += [pscustomobject]@{ Metric = 'Critical Alerts'; Value = @($alertDetails | Where-Object { $_.Severity -eq 'Critical' }).Count }
    $summary += [pscustomobject]@{ Metric = 'Tickets'; Value = @($ticketDetails).Count }
    $summary += [pscustomobject]@{ Metric = 'Open Tickets'; Value = @($ticketDetails | Where-Object { $_.TicketStatus -notin @('Resolved','Closed') }).Count }
    $summary += [pscustomobject]@{ Metric = 'Tasks'; Value = @($taskDetails).Count }
    $summary += [pscustomobject]@{ Metric = 'Open Tasks'; Value = @($taskDetails | Where-Object { $_.TaskStatus -notin @('Completed','Cancelled') }).Count }
    $summary += [pscustomobject]@{ Metric = 'Overdue Tasks'; Value = @($taskDetails | Where-Object { [int]($_.IsOverdue) -eq 1 }).Count }
    foreach ($message in $messages) { $summary += [pscustomobject]@{ Metric = 'Warning'; Value = $message } }

    return @{
        period = $periodInfo.Period
        bucketLabel = $periodInfo.BucketLabel
        generatedAt = (Get-Date).ToString('s')
        summary = $summary
        alertDetails = $alertDetails
        ticketDetails = $ticketDetails
        taskDetails = $taskDetails
        alertTrend = $alertTrend
        alertSeverity = $alertSeverity
        alertModule = $alertModule
        ticketTrend = $ticketTrend
        ticketStatus = $ticketStatus
        ticketSeverity = $ticketSeverity
        ticketAssignment = $ticketAssignment
        taskTrend = $taskTrend
        taskStatus = $taskStatus
        taskPriority = $taskPriority
        taskAssignment = $taskAssignment
    }
}

function Invoke-BiInsightQuestion {
    param([string]$Question, [object]$User = $null)
    try { Invoke-BiInsightsSchemaEnsure } catch {}
    $text = ([string]$Question).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { throw 'Question is required.' }
    $lower = $text.ToLowerInvariant()
    $answer = 'I can answer operational questions about critical servers, Windows VMs, noisy alerts, capacity hotspots, health score, and collection health from the BI datasets.'
    $datasetKey = 'server-scorecard'
    if ($lower -match 'vm|windows|virtual machine') {
        if ($lower -match 'ticket|sla|breach|escalat') {
            $answer = 'Use VM Ticket SLA to review VM Monitoring tickets by severity, subcategory, assignment group, and SLA status.'
            $datasetKey = 'vm-ticket-sla'
        }
        elseif ($lower -match 'event|log') {
            $answer = 'Use VM Event Log Insights to rank Windows event volume by VM, log, level, and provider.'
            $datasetKey = 'vm-event-log'
        }
        elseif ($lower -match 'patch|hotfix|update') {
            $answer = 'Use VM Patch Posture to review latest hotfix capture and days since last installed patch by VM.'
            $datasetKey = 'vm-patch-posture'
        }
        else {
            $answer = 'Use VM Scorecard filtered to HealthPosture = Critical or Warning. It combines CPU, memory, disk, services, stale telemetry, open alerts, and open tickets.'
            $datasetKey = 'vm-scorecard'
        }
    }
    elseif ($lower -match 'critical|down|unhealthy') {
        $answer = 'Use Server Scorecard filtered to HealthPosture = Critical. It ranks servers by critical alerts, CPU pressure, and low memory.'
        $datasetKey = 'server-scorecard'
    }
    elseif ($lower -match 'noisy|repeat|repeated|alerts') {
        $answer = 'Use Top Noisy Alerts. It groups alert fingerprints and sorts by RepeatCount and occurrence count.'
        $datasetKey = 'noisy-alerts'
    }
    elseif ($lower -match 'disk|space|capacity|full') {
        $answer = 'Use Capacity Hotspots. It sorts volumes by PeakUsedPct and MinFreeGB.'
        $datasetKey = 'capacity-hotspots'
    }
    elseif ($lower -match 'health score|score') {
        $answer = 'Health Score is calculated from the visible server scorecard: Healthy = 100, Warning = 60, Critical = 15.'
        $datasetKey = 'health-posture'
    }
    return @{
        question = $text
        answer = $answer
        datasetKey = $datasetKey
        verifiedPrompts = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 5 PromptText, AnswerTemplate, DatasetKey, IsVerified FROM mon.BIInsightQAPrompts ORDER BY IsVerified DESC, PromptText;' -Timeout 10)
    }
}

function Get-BiInsightsCatalog {
    param([object]$User = $null)
    $userName = if ($User) { [string]$User.UserName } else { '' }
    try { Invoke-BiInsightsSchemaEnsure } catch {}
    return @{
        datasets = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT DatasetKey, DisplayName, Category, Description, DefaultVisual, QueryName, IsActive FROM mon.BIInsightDatasets WHERE IsActive = 1 ORDER BY Category, DisplayName;')
        reports = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT ReportID, ReportName, ReportDescription, LayoutJson, FilterJson, IsShared, CreatedBy, CreatedAt, ModifiedAt FROM mon.BIInsightReports WHERE IsShared = 1 OR CreatedBy = @UserName ORDER BY COALESCE(ModifiedAt, CreatedAt) DESC, ReportName;' -Parameters @{ UserName = $userName })
        dataSources = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT DataSourceKey, DisplayName, SourceType, ConnectorType, ConnectionMode, IsActive FROM mon.BIInsightDataSources WHERE IsActive = 1 ORDER BY SourceType, DisplayName;')
        fields = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT DatasetKey, FieldName, DataType, FieldRole, DisplayFolder, IsHidden FROM mon.BIInsightFields ORDER BY DatasetKey, DisplayFolder, FieldName;')
        relationships = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT RelationshipID, FromDatasetKey, FromField, ToDatasetKey, ToField, Cardinality, CrossFilterDirection, IsActive FROM mon.BIInsightRelationships ORDER BY FromDatasetKey, ToDatasetKey;')
        measures = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT MeasureID, DatasetKey, MeasureName, ExpressionText, FormatString, DisplayFolder, IsActive FROM mon.BIInsightMeasures WHERE IsActive = 1 ORDER BY DatasetKey, DisplayFolder, MeasureName;')
        transformations = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TransformationID, DatasetKey, StepName, StepType, ExpressionText, StepOrder, IsActive FROM mon.BIInsightTransformations WHERE IsActive = 1 ORDER BY DatasetKey, StepOrder;')
        visualTypes = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT VisualTypeKey, DisplayName, Category, SupportsDrillthrough, SupportsCrossFilter, IsActive FROM mon.BIInsightVisualTypes WHERE IsActive = 1 ORDER BY Category, DisplayName;')
        themes = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT ThemeID, ThemeName, ThemeJson, IsDefault FROM mon.BIInsightThemes ORDER BY IsDefault DESC, ThemeName;')
        qaPrompts = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT PromptID, PromptText, AnswerTemplate, DatasetKey, IsVerified FROM mon.BIInsightQAPrompts ORDER BY IsVerified DESC, PromptText;')
        performance = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 100 RunID, ReportID, DatasetKey, DurationMs, [RowCount] AS [RowCount], ExecutedBy, ExecutedAt FROM mon.BIInsightPerformanceRuns ORDER BY ExecutedAt DESC, RunID DESC;')
        moduleVisuals = Get-BiInsightModuleVisuals -SkipEnsure
    }
}

function Get-BiInsightModuleVisuals {
    param([switch]$SkipEnsure)
    if (-not $SkipEnsure) { try { Invoke-BiInsightsSchemaEnsure } catch {} }
    return ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT ModuleKey, ModuleTitle, VisualTitle, VisualType, AxisField, ValueField, LegendField, IsEnabled, CreatedBy, CreatedAt, ModifiedBy, ModifiedAt FROM mon.BIInsightModuleVisuals ORDER BY ModuleTitle;')
}

function Save-BiInsightModuleVisual {
    param([object]$Body, [object]$User)
    try { Invoke-BiInsightsSchemaEnsure } catch {}
    $moduleKey = ([string]$Body.ModuleKey).Trim()
    $moduleTitle = ([string]$Body.ModuleTitle).Trim()
    $visualTitle = ([string]$Body.VisualTitle).Trim()
    $visualType = ([string]$Body.VisualType).Trim()
    $axisField = ([string]$Body.AxisField).Trim()
    $valueField = ([string]$Body.ValueField).Trim()
    $legendField = ([string]$Body.LegendField).Trim()
    $isEnabled = if ($null -eq $Body.IsEnabled) { $false } else { [bool]$Body.IsEnabled }
    $userName = if ($User) { [string]$User.UserName } else { 'system' }

    if ([string]::IsNullOrWhiteSpace($moduleKey)) { throw 'Module key is required.' }
    if ([string]::IsNullOrWhiteSpace($moduleTitle)) { $moduleTitle = $moduleKey }
    if ([string]::IsNullOrWhiteSpace($visualTitle)) { $visualTitle = "$moduleTitle Chart" }
    if ([string]::IsNullOrWhiteSpace($visualType)) { $visualType = 'line' }

    $isValidModule = $false
    foreach ($group in $script:FeatureGroups) {
        foreach ($feature in @($group.features)) {
            if ($feature.type -eq 'module' -and $feature.module -eq $moduleKey) { $isValidModule = $true }
        }
    }
    if (-not $isValidModule) { throw "Unknown module '$moduleKey'." }

    $enabledValue = if ($isEnabled) { 1 } else { 0 }
    Invoke-RepoNonQuery -Query @"
MERGE mon.BIInsightModuleVisuals AS target
USING (SELECT @ModuleKey AS ModuleKey) AS source
ON target.ModuleKey = source.ModuleKey
WHEN MATCHED THEN
    UPDATE SET ModuleTitle = @ModuleTitle,
               VisualTitle = @VisualTitle,
               VisualType = @VisualType,
               AxisField = NULLIF(@AxisField, ''),
               ValueField = NULLIF(@ValueField, ''),
               LegendField = NULLIF(@LegendField, ''),
               IsEnabled = @IsEnabled,
               ModifiedBy = @ModifiedBy,
               ModifiedAt = SYSDATETIME()
WHEN NOT MATCHED THEN
    INSERT (ModuleKey, ModuleTitle, VisualTitle, VisualType, AxisField, ValueField, LegendField, IsEnabled, CreatedBy)
    VALUES (@ModuleKey, @ModuleTitle, @VisualTitle, @VisualType, NULLIF(@AxisField, ''), NULLIF(@ValueField, ''), NULLIF(@LegendField, ''), @IsEnabled, @ModifiedBy);
"@ -Parameters @{
        ModuleKey = $moduleKey
        ModuleTitle = $moduleTitle
        VisualTitle = $visualTitle
        VisualType = $visualType
        AxisField = $axisField
        ValueField = $valueField
        LegendField = $legendField
        IsEnabled = $enabledValue
        ModifiedBy = $userName
    }
    return @{ ok = $true; moduleVisuals = Get-BiInsightModuleVisuals }
}

function Save-BiInsightReport {
    param([object]$Body, [object]$User)
    try { Invoke-BiInsightsSchemaEnsure } catch {}
    $reportId = if ($null -eq $Body.ReportID) { 0 } else { [int]$Body.ReportID }
    $name = ([string]$Body.ReportName).Trim()
    $description = if ($null -ne $Body.ReportDescription) { ([string]$Body.ReportDescription).Trim() } else { '' }
    $layoutJson = if ($null -ne $Body.LayoutJson) { [string]$Body.LayoutJson } else { '[]' }
    $filterJson = if ($null -ne $Body.FilterJson) { [string]$Body.FilterJson } else { '{}' }
    $isShared = if ($null -eq $Body.IsShared) { $false } else { [bool]$Body.IsShared }
    $userName = if ($User) { [string]$User.UserName } else { 'system' }
    if ([string]::IsNullOrWhiteSpace($name)) { throw 'Report name is required.' }
    $sharedValue = if ($isShared) { 1 } else { 0 }
    if ($reportId -le 0) {
        $reportId = [int](Invoke-RepoScalar -Query 'INSERT INTO mon.BIInsightReports (ReportName, ReportDescription, LayoutJson, FilterJson, IsShared, CreatedBy) VALUES (@ReportName, @ReportDescription, @LayoutJson, @FilterJson, @IsShared, @CreatedBy); SELECT CAST(SCOPE_IDENTITY() AS INT);' -Parameters @{ ReportName = $name; ReportDescription = $description; LayoutJson = $layoutJson; FilterJson = $filterJson; IsShared = $sharedValue; CreatedBy = $userName })
    }
    else {
        Invoke-RepoNonQuery -Query 'UPDATE mon.BIInsightReports SET ReportName = @ReportName, ReportDescription = @ReportDescription, LayoutJson = @LayoutJson, FilterJson = @FilterJson, IsShared = @IsShared, ModifiedAt = SYSDATETIME() WHERE ReportID = @ReportID AND (CreatedBy = @UserName OR @CanAdmin = 1);' -Parameters @{ ReportID = $reportId; ReportName = $name; ReportDescription = $description; LayoutJson = $layoutJson; FilterJson = $filterJson; IsShared = $sharedValue; UserName = $userName; CanAdmin = if ($User -and [string]$User.RoleName -eq 'Admin') { 1 } else { 0 } }
    }
    return @{ ok = $true; reportId = $reportId; catalog = Get-BiInsightsCatalog -User $User }
}

function Remove-BiInsightReport {
    param([int]$ReportID, [object]$User)
    if ($ReportID -le 0) { throw 'ReportID is required.' }
    $userName = if ($User) { [string]$User.UserName } else { '' }
    Invoke-RepoNonQuery -Query 'DELETE FROM mon.BIInsightReports WHERE ReportID = @ReportID AND (CreatedBy = @UserName OR @CanAdmin = 1);' -Parameters @{ ReportID = $ReportID; UserName = $userName; CanAdmin = if ($User -and [string]$User.RoleName -eq 'Admin') { 1 } else { 0 } }
    return @{ ok = $true; catalog = Get-BiInsightsCatalog -User $User }
}

function Acknowledge-AlertId {
    param([int64]$AlertID, [string]$User = 'WebDashboard')
    if ($AlertID -le 0) { throw 'AlertID is required.' }
    Invoke-RepoNonQuery -Query @"
DECLARE @InstanceID INT, @ModuleName NVARCHAR(100), @AlertTitle NVARCHAR(300);

SELECT @InstanceID = InstanceID, @ModuleName = ModuleName, @AlertTitle = AlertTitle
FROM mon.AlertHistory
WHERE AlertID = @AlertID;

UPDATE mon.AlertHistory
SET IsAcknowledged = 1,
    AcknowledgedOn = SYSDATETIME(),
    AcknowledgedBy = @AcknowledgedBy
WHERE IsAcknowledged = 0
  AND InstanceID = @InstanceID
  AND ModuleName = @ModuleName
  AND AlertTitle = @AlertTitle;
"@ -Parameters @{ AlertID = $AlertID; AcknowledgedBy = $User }
    $row = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT AlertID, IsAcknowledged, AcknowledgedOn, AcknowledgedBy FROM mon.AlertHistory WHERE AlertID = @AlertID;' -Parameters @{ AlertID = $AlertID })
    return @{ ok = $true; alert = @($row | Select-Object -First 1) }
}

function Get-Thresholds {
    $query = 'SELECT ThresholdID, ModuleName, MetricName, WarningValue, CriticalValue, ComparisonType, CooldownMinutes, IsActive FROM mon.AlertThresholds ORDER BY ModuleName, MetricName;'
    return ConvertTo-PlainRows (Invoke-RepoQuery -Query $query)
}

function Save-Threshold {
    param([object]$Body)
    Invoke-RepoNonQuery -Query 'UPDATE mon.AlertThresholds SET WarningValue = @WarningValue, CriticalValue = @CriticalValue, ComparisonType = @ComparisonType, CooldownMinutes = @CooldownMinutes, IsActive = @IsActive WHERE ThresholdID = @ThresholdID;' -Parameters @{
        ThresholdID = [int]$Body.ThresholdID
        WarningValue = [decimal]$Body.WarningValue
        CriticalValue = [decimal]$Body.CriticalValue
        ComparisonType = [string]$Body.ComparisonType
        CooldownMinutes = [int]$Body.CooldownMinutes
        IsActive = [bool]$Body.IsActive
    }
    return @{ ok = $true; thresholds = Get-Thresholds }
}

function Get-CollectorNodesPayload {
    $nodesQuery = @"
SELECT
    cn.CollectorNodeID,
    cn.NodeName,
    cn.HostName,
    cn.DeploymentRole,
    cn.SiteName,
    cn.Tags,
    cn.IsEnabled,
    cn.RegisteredAt,
    cn.LastHeartbeat,
    cn.LastSeenStatus,
    COUNT(CASE WHEN ca.IsEnabled = 1 THEN 1 END) AS AssignedInstances,
    DATEDIFF(MINUTE, cn.LastHeartbeat, SYSDATETIME()) AS MinutesSinceHeartbeat,
    CASE
        WHEN cn.IsEnabled = 0 THEN N'Disabled'
        WHEN cn.LastHeartbeat IS NULL THEN N'Never Seen'
        WHEN DATEDIFF(MINUTE, cn.LastHeartbeat, SYSDATETIME()) <= 10 THEN N'Online'
        WHEN DATEDIFF(MINUTE, cn.LastHeartbeat, SYSDATETIME()) <= 60 THEN N'Stale'
        ELSE N'Offline'
    END AS HealthStatus
FROM mon.CollectorNodes cn
LEFT JOIN mon.CollectorAssignments ca ON cn.CollectorNodeID = ca.CollectorNodeID
GROUP BY cn.CollectorNodeID, cn.NodeName, cn.HostName, cn.DeploymentRole, cn.SiteName, cn.Tags, cn.IsEnabled, cn.RegisteredAt, cn.LastHeartbeat, cn.LastSeenStatus
ORDER BY cn.NodeName;
"@
    $assignmentsQuery = @"
SELECT
    ca.AssignmentID,
    ca.CollectorNodeID,
    cn.NodeName,
    ca.InstanceID,
    mi.DisplayName,
    ca.CollectorGroup,
    ca.Priority,
    ca.IsEnabled,
    ca.AssignedAt,
    ca.AssignedBy
FROM mon.CollectorAssignments ca
INNER JOIN mon.CollectorNodes cn ON ca.CollectorNodeID = cn.CollectorNodeID
INNER JOIN mon.MonitoredInstances mi ON ca.InstanceID = mi.InstanceID
ORDER BY cn.NodeName, ca.Priority, mi.DisplayName;
"@
    $heartbeatQuery = @"
SELECT TOP 100
    hb.HeartbeatTime,
    cn.NodeName,
    hb.Status,
    hb.CollectorGroup,
    hb.InstanceCount,
    hb.MessageText
FROM mon.CollectorNodeHeartbeat hb
INNER JOIN mon.CollectorNodes cn ON hb.CollectorNodeID = cn.CollectorNodeID
ORDER BY hb.HeartbeatTime DESC;
"@
    return @{
        nodes = ConvertTo-PlainRows (Invoke-RepoQuery -Query $nodesQuery)
        assignments = ConvertTo-PlainRows (Invoke-RepoQuery -Query $assignmentsQuery)
        heartbeats = ConvertTo-PlainRows (Invoke-RepoQuery -Query $heartbeatQuery)
        instances = Get-RepositoryInstances
    }
}

function Save-CollectorAssignment {
    param([object]$Body, [object]$User)

    $collectorNodeId = [int]$Body.CollectorNodeID
    $instanceId = [int]$Body.InstanceID
    $collectorGroup = if ([string]::IsNullOrWhiteSpace([string]$Body.CollectorGroup)) { 'All' } else { [string]$Body.CollectorGroup }
    $enabled = if ($null -eq $Body.IsEnabled) { $true } else { [bool]$Body.IsEnabled }
    if ($collectorNodeId -le 0) { throw 'CollectorNodeID is required.' }
    if ($instanceId -le 0) { throw 'InstanceID is required.' }

    $query = @"
IF EXISTS (
    SELECT 1
    FROM mon.CollectorAssignments
    WHERE CollectorNodeID = @CollectorNodeID
      AND InstanceID = @InstanceID
      AND CollectorGroup = @CollectorGroup
)
BEGIN
    UPDATE mon.CollectorAssignments
    SET IsEnabled = @IsEnabled,
        AssignedAt = SYSDATETIME(),
        AssignedBy = @AssignedBy
    WHERE CollectorNodeID = @CollectorNodeID
      AND InstanceID = @InstanceID
      AND CollectorGroup = @CollectorGroup;
END
ELSE
BEGIN
    INSERT INTO mon.CollectorAssignments (CollectorNodeID, InstanceID, CollectorGroup, IsEnabled, AssignedBy)
    VALUES (@CollectorNodeID, @InstanceID, @CollectorGroup, @IsEnabled, @AssignedBy);
END;
"@
    Invoke-RepoNonQuery -Query $query -Parameters @{
        CollectorNodeID = $collectorNodeId
        InstanceID = $instanceId
        CollectorGroup = $collectorGroup
        IsEnabled = $enabled
        AssignedBy = [string]$User.UserName
    }
    return @{ ok = $true; data = Get-CollectorNodesPayload }
}

function Invoke-CentralRepositorySync {
    param([object]$Body)

    $linkedServer = [string]$Body.CentralLinkedServer
    if ([string]::IsNullOrWhiteSpace($linkedServer)) { $linkedServer = 'SQLMON_CENTRAL' }
    $centralDatabase = [string]$Body.CentralDatabase
    if ([string]::IsNullOrWhiteSpace($centralDatabase)) { $centralDatabase = $script:RepositoryDatabase }
    $lookback = [int]$Body.LookbackMinutes
    if ($lookback -le 0) { $lookback = 1440 }
    $dryRun = if ([bool]$Body.DryRun) { 1 } else { 0 }

    Invoke-RepoNonQuery -Query @"
EXEC mon.usp_SyncRepositoryToCentral
    @CentralLinkedServer = @CentralLinkedServer,
    @CentralDatabase = @CentralDatabase,
    @LookbackMinutes = @LookbackMinutes,
    @DryRun = @DryRun;
"@ -Parameters @{
        CentralLinkedServer = $linkedServer
        CentralDatabase = $centralDatabase
        LookbackMinutes = $lookback
        DryRun = $dryRun
    } -Timeout 0

    $run = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 1 * FROM mon.CentralSyncRuns ORDER BY SyncRunID DESC;' -Timeout 30)
    $syncRunId = if ($run.Count -gt 0) { [int64]$run[0].SyncRunID } else { 0 }
    $tables = if ($syncRunId -gt 0) {
        ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT * FROM mon.CentralSyncTableRuns WHERE SyncRunID = @SyncRunID ORDER BY SyncTableRunID;' -Parameters @{ SyncRunID = $syncRunId } -Timeout 30)
    }
    else { @() }

    return @{
        ok = ($run.Count -gt 0 -and [string]$run[0].Status -in @('Success', 'DryRun'))
        run = $run
        tables = $tables
    }
}

function Get-Analytics {
    param([int]$InstanceID, [string]$Range)
    if ($InstanceID -le 0) { throw 'Select an instance first.' }
    $hours = switch ($Range) {
        'Last Hour' { 1 }
        'Last 6 Hours' { 6 }
        'Last 7 Days' { 168 }
        'Last 30 Days' { 720 }
        default { 24 }
    }
    $params = @{ InstanceID = $InstanceID; Hours = $hours }
    try {
        $cpu = ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT AVG(SqlCPUPercent) AS AvgCPU, MAX(SqlCPUPercent) AS PeakCPU, COUNT(*) AS SampleCount FROM mon.CPUHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE());' -Parameters $params -Timeout 8)
        $mem = ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT AVG(AvailablePhysicalMB) AS AvgMemory, MIN(AvailablePhysicalMB) AS MinMemory, COUNT(*) AS SampleCount FROM mon.MemoryHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE());' -Parameters $params -Timeout 8)
        $alerts = ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT COUNT(*) AS AlertCount FROM mon.vw_AlertHistoryDetailed WHERE InstanceID = @InstanceID AND AlertTime >= DATEADD(HOUR, -1 * @Hours, GETDATE());' -Parameters $params -Timeout 8)
        $trends = [ordered]@{
            cpu = ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 200 CaptureTime, SqlCPUPercent FROM mon.CPUHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE()) ORDER BY CaptureTime;' -Parameters $params -Timeout 8)
            memory = ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 200 CaptureTime, AvailablePhysicalMB FROM mon.MemoryHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE()) ORDER BY CaptureTime;' -Parameters $params -Timeout 8)
            topQueries = try { ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 200 CollectionDateTime AS CaptureTime, CAST(QueryID AS NVARCHAR(100)) AS QueryHash, AvgCpuTime AS SqlCPUPercent FROM dbo.TopQueries WHERE InstanceID = @InstanceID AND CollectionDateTime >= DATEADD(HOUR, -1 * @Hours, GETDATE()) ORDER BY CollectionDateTime;' -Parameters $params -Timeout 8) } catch { @() };
            jobs = try { ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 200 CaptureTime, JobName, 0 AS SuccessCount, 0 AS FailureCount FROM mon.AgentJobHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE()) ORDER BY CaptureTime;' -Parameters $params -Timeout 8) } catch { @() };
            # Include size metrics for disk history visualization
            disks = try { ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 200 CaptureTime, VolumeMountPoint AS DiskName, TotalGB, FreeGB, UsedGB, UsedPct FROM mon.DiskVolumeHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE()) ORDER BY CaptureTime;' -Parameters $params -Timeout 8) } catch { @() };
            deadlocks = try { ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 200 CaptureTime, 1 AS DeadlockCount FROM mon.DeadlockHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE()) ORDER BY CaptureTime;' -Parameters $params -Timeout 8) } catch { @() };
            blocking = try { ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 200 CaptureTime, 1 AS BlockingCount FROM mon.BlockingHistory WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(HOUR, -1 * @Hours, GETDATE()) ORDER BY CaptureTime;' -Parameters $params -Timeout 8) } catch { @() };
            # User management trends - count distinct active users per day from audit log
            users = try {
                ConvertTo-PlainRows (
                    Invoke-RepoQueryFast -Query 'SELECT TOP 200 CAST(CreatedAt AS DATE) AS CaptureTime, COUNT(DISTINCT UserID) AS ActiveUserCount FROM mon.DashboardAuditLog WHERE InstanceID = @InstanceID AND CreatedAt >= DATEADD(DAY, -@Hours/24, GETDATE()) GROUP BY CAST(CreatedAt AS DATE) ORDER BY CaptureTime;' -Parameters $params -Timeout 8
                )
            } catch { @() };
        }
        $issues = ConvertTo-PlainRows (Invoke-RepoQueryFast -Query 'SELECT TOP 10 ModuleName, AlertTitle, COUNT(*) AS Frequency, MAX(AlertTime) AS LastOccurrence FROM mon.vw_AlertHistoryDetailed WHERE InstanceID = @InstanceID AND AlertTime >= DATEADD(DAY, -1, GETDATE()) GROUP BY ModuleName, AlertTitle ORDER BY Frequency DESC, LastOccurrence DESC;' -Parameters @{ InstanceID = $InstanceID } -Timeout 8)
        return @{ cpu = @($cpu | Select-Object -First 1); memory = @($mem | Select-Object -First 1); alerts = @($alerts | Select-Object -First 1); trends = $trends; topIssues = $issues }
    }
    catch {
        return @{
            cpu = @{ AvgCPU = 0; PeakCPU = 0; SampleCount = 0 }
            memory = @{ AvgMemory = 0; MinMemory = 0; SampleCount = 0 }
            alerts = @{ AlertCount = 0 }
            trends = @{ cpu = @(); memory = @() }
            topIssues = @()
            repositoryError = $_.Exception.Message
        }
    }
}

function Get-DictionaryItems {
    return @(
        @{ category = 'Performance Metrics'; term = 'CPU Utilization'; definition = 'Percentage of CPU time used by SQL Server. Normal is below 80%, warning is 80-90%, critical is above 90%.' },
        @{ category = 'Performance Metrics'; term = 'Page Life Expectancy'; definition = 'How long pages stay in memory before being flushed. Low PLE often points to memory pressure.' },
        @{ category = 'Performance Metrics'; term = 'Buffer Cache Hit Ratio'; definition = 'Percentage of data requests served from memory cache. Values above 95% are usually healthy.' },
        @{ category = 'System Resources'; term = 'TempDB'; definition = 'Shared workspace for temporary objects, sorting, version store, and internal operations. Monitor space and contention.' },
        @{ category = 'System Resources'; term = 'Wait Statistics'; definition = 'Time SQL Server spends waiting for resources. High waits guide tuning work.' },
        @{ category = 'Database Objects'; term = 'Missing Indexes'; definition = 'Optimizer recommendations for indexes that may reduce cost. Validate before creating.' },
        @{ category = 'Database Objects'; term = 'Fragmentation'; definition = 'Logical page ordering drift in indexes. High fragmentation can hurt scans and maintenance windows.' },
        @{ category = 'High Availability'; term = 'Availability Groups'; definition = 'SQL Server HA/DR feature with primary and secondary replicas. Monitor synchronization and failover health.' },
        @{ category = 'Backup & Recovery'; term = 'Recovery Model'; definition = 'Controls transaction log behavior and point-in-time recovery options.' },
        @{ category = 'Troubleshooting'; term = 'Blocking'; definition = 'One session holds locks needed by another. Find the head blocker and tune or resolve the transaction.' },
        @{ category = 'Troubleshooting'; term = 'Deadlock'; definition = 'Two or more sessions block each other and SQL Server terminates one as a victim.' }
    )
}

function Invoke-SopWikiSchemaEnsure {
    $query = @"
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');

IF OBJECT_ID('mon.SOPs', 'U') IS NULL
BEGIN
    CREATE TABLE mon.SOPs (
        SopID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SOPs PRIMARY KEY,
        IssueID INT NULL,
        Title NVARCHAR(200) NOT NULL,
        Category NVARCHAR(100) NULL,
        Severity NVARCHAR(20) NULL,
        Description NVARCHAR(MAX) NULL,
        SOPText NVARCHAR(MAX) NULL,
        Frequency NVARCHAR(50) NULL,
        Owner NVARCHAR(100) NULL,
        Tags NVARCHAR(400) NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_SOPs_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_SOPs_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastUpdatedBy NVARCHAR(128) NULL
    );
END;

IF COL_LENGTH('mon.SOPs', 'SopID') IS NULL ALTER TABLE mon.SOPs ADD SopID INT IDENTITY(1,1) NOT NULL;
IF COL_LENGTH('mon.SOPs', 'IssueID') IS NULL ALTER TABLE mon.SOPs ADD IssueID INT NULL;
IF COL_LENGTH('mon.SOPs', 'Title') IS NULL ALTER TABLE mon.SOPs ADD Title NVARCHAR(200) NULL;
IF COL_LENGTH('mon.SOPs', 'Category') IS NULL ALTER TABLE mon.SOPs ADD Category NVARCHAR(100) NULL;
IF COL_LENGTH('mon.SOPs', 'Severity') IS NULL ALTER TABLE mon.SOPs ADD Severity NVARCHAR(20) NULL;
IF COL_LENGTH('mon.SOPs', 'Description') IS NULL ALTER TABLE mon.SOPs ADD Description NVARCHAR(MAX) NULL;
IF COL_LENGTH('mon.SOPs', 'SOPText') IS NULL ALTER TABLE mon.SOPs ADD SOPText NVARCHAR(MAX) NULL;
IF COL_LENGTH('mon.SOPs', 'Frequency') IS NULL ALTER TABLE mon.SOPs ADD Frequency NVARCHAR(50) NULL;
IF COL_LENGTH('mon.SOPs', 'Owner') IS NULL ALTER TABLE mon.SOPs ADD Owner NVARCHAR(100) NULL;
IF COL_LENGTH('mon.SOPs', 'Tags') IS NULL ALTER TABLE mon.SOPs ADD Tags NVARCHAR(400) NULL;
IF COL_LENGTH('mon.SOPs', 'IsActive') IS NULL ALTER TABLE mon.SOPs ADD IsActive BIT NOT NULL CONSTRAINT DF_SOPs_IsActive_Upgrade DEFAULT (1);
IF COL_LENGTH('mon.SOPs', 'CreatedAt') IS NULL ALTER TABLE mon.SOPs ADD CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_SOPs_CreatedAt_Upgrade DEFAULT (SYSDATETIME());
IF COL_LENGTH('mon.SOPs', 'UpdatedAt') IS NULL ALTER TABLE mon.SOPs ADD UpdatedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.SOPs', 'LastUpdatedBy') IS NULL ALTER TABLE mon.SOPs ADD LastUpdatedBy NVARCHAR(128) NULL;
"@
    Invoke-RepoNonQuery -Query $query
}

function Initialize-SopWikiDefaults {
    Invoke-SopWikiSchemaEnsure
}

function Get-SopWikiItems {
    try {
        Initialize-SopWikiDefaults
        $query = @"
SELECT
    SopID,
    IssueID,
    Title,
    Category,
    Severity,
    Description,
    SOPText AS SOP,
    Frequency,
    Owner,
    Tags,
    LastUpdatedBy,
    CreatedAt,
    UpdatedAt
FROM mon.SOPs
WHERE IsActive = 1
ORDER BY COALESCE(UpdatedAt, CreatedAt) DESC, Title;
"@
        return ConvertTo-PlainRows (Invoke-RepoQueryFast -Query $query -Timeout 15)
    }
    catch {
        Write-MonitorLog "SOP wiki lookup failed: $($_.Exception.Message)" -Level 'Warning'
        throw "SOP wiki is unavailable because the repository table could not be read. Run deployment to create mon.SOPs, then try again. $($_.Exception.Message)"
    }
}

function Save-SopWikiItem {
    param([object]$Body, [object]$User)

    Initialize-SopWikiDefaults
    $sopId = if ($null -eq $Body.SopID) { 0 } else { [int]$Body.SopID }
    $issueId = if ($null -eq $Body.IssueID -or [string]::IsNullOrWhiteSpace([string]$Body.IssueID)) { $null } else { [int]$Body.IssueID }
    $title = ([string]$Body.Title).Trim()
    $category = ([string]$Body.Category).Trim()
    $severity = ([string]$Body.Severity).Trim()
    $description = [string]$Body.Description
    $sopText = [string]$Body.SOP
    $frequency = ([string]$Body.Frequency).Trim()
    $owner = ([string]$Body.Owner).Trim()
    $tags = ([string]$Body.Tags).Trim()
    $updatedBy = if ($User -and -not [string]::IsNullOrWhiteSpace([string]$User.UserName)) { [string]$User.UserName } else { 'WebDashboard' }

    if ([string]::IsNullOrWhiteSpace($title)) { throw 'Title is required.' }
    if ([string]::IsNullOrWhiteSpace($sopText) -and [string]::IsNullOrWhiteSpace($description)) { throw 'Add SOP content or a description before saving.' }
    if ([string]::IsNullOrWhiteSpace($severity)) { $severity = 'Info' }

    $parameters = @{
        SopID = $sopId
        IssueID = $issueId
        Title = $title
        Category = $category
        Severity = $severity
        Description = $description
        SOPText = $sopText
        Frequency = $frequency
        Owner = $owner
        Tags = $tags
        LastUpdatedBy = $updatedBy
    }

    if ($sopId -gt 0) {
        Invoke-RepoNonQuery -Query 'UPDATE mon.SOPs SET IssueID = @IssueID, Title = @Title, Category = @Category, Severity = @Severity, Description = @Description, SOPText = @SOPText, Frequency = @Frequency, Owner = @Owner, Tags = @Tags, IsActive = 1, UpdatedAt = SYSDATETIME(), LastUpdatedBy = @LastUpdatedBy WHERE SopID = @SopID;' -Parameters $parameters
    }
    else {
        $sopId = [int](Invoke-RepoScalar -Query 'INSERT INTO mon.SOPs (IssueID, Title, Category, Severity, Description, SOPText, Frequency, Owner, Tags, IsActive, LastUpdatedBy) VALUES (@IssueID, @Title, @Category, @Severity, @Description, @SOPText, @Frequency, @Owner, @Tags, 1, @LastUpdatedBy); SELECT CAST(SCOPE_IDENTITY() AS INT);' -Parameters $parameters)
    }

    Write-DashboardAudit -User $User -ActionName 'SaveSopWiki' -Details $title
    return @{ ok = $true; SopID = $sopId; rows = @(Get-SopWikiItems) }
}

function Remove-SopWikiItem {
    param([int]$SopID, [object]$User)
    if ($SopID -le 0) { throw 'sopId is required.' }
    Initialize-SopWikiDefaults
    Invoke-RepoNonQuery -Query 'UPDATE mon.SOPs SET IsActive = 0, UpdatedAt = SYSDATETIME(), LastUpdatedBy = @LastUpdatedBy WHERE SopID = @SopID;' -Parameters @{
        SopID = $SopID
        LastUpdatedBy = if ($User) { [string]$User.UserName } else { 'WebDashboard' }
    }
    Write-DashboardAudit -User $User -ActionName 'DeleteSopWiki' -Details ("SopID {0}" -f $SopID)
    return @{ ok = $true; rows = @(Get-SopWikiItems) }
}

function Invoke-ProcessCapture {
    param([string]$FilePath, [string[]]$Arguments, [string]$WorkingDirectory = $projectRoot)
    if (-not (Test-Path $FilePath) -and -not (Get-Command $FilePath -ErrorAction SilentlyContinue)) {
        throw "Executable or script not found: $FilePath"
    }
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $FilePath
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.WorkingDirectory = $WorkingDirectory
    $startInfo.Arguments = (@($Arguments) | ForEach-Object {
        $arg = [string]$_
        if ($arg -match '[\s"]') { '"' + ($arg -replace '"', '\"') + '"' } else { $arg }
    }) -join ' '
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    [void]$process.Start()
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    return @{ exitCode = $process.ExitCode; output = $stdout; error = $stderr }
}

function Get-BodyStringValue {
    param([object]$Body, [string]$Name, [string]$Default = "")
    if ($null -ne $Body -and $Body.PSObject.Properties[$Name] -and -not [string]::IsNullOrWhiteSpace([string]$Body.$Name)) {
        return [string]$Body.$Name
    }
    return $Default
}

function Get-BodyBoolValue {
    param([object]$Body, [string]$Name, [bool]$Default = $false)
    if ($null -ne $Body -and $Body.PSObject.Properties[$Name]) { return [bool]$Body.$Name }
    return $Default
}

function Get-BodyIntValue {
    param([object]$Body, [string]$Name, [int]$Default)
    if ($null -ne $Body -and $Body.PSObject.Properties[$Name]) {
        $value = 0
        if ([int]::TryParse([string]$Body.$Name, [ref]$value)) { return $value }
    }
    return $Default
}

function Get-BodyListValue {
    param([object]$Body, [string]$Name)
    if ($null -eq $Body -or -not $Body.PSObject.Properties[$Name]) { return @() }
    $raw = $Body.$Name
    if ($null -eq $raw) { return @() }
    if ($raw -is [array]) {
        return @($raw | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    }
    return @(([string]$raw) -split '\r?\n|,' | ForEach-Object { $_.Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
}

function Invoke-DeploymentCenterRun {
    param([object]$Body, [int]$Port)

    $deployScript = Join-Path $projectRoot 'Deploy-SQLMonitor.ps1'
    if (-not (Test-Path $deployScript -PathType Leaf)) { throw "Deployment script not found: $deployScript" }

    $repositoryServer = Get-BodyStringValue -Body $Body -Name 'RepositoryServer' -Default $script:RepositoryServer
    $repositoryDatabase = Get-BodyStringValue -Body $Body -Name 'RepositoryDatabase' -Default $script:RepositoryDatabase
    $installPath = Get-BodyStringValue -Body $Body -Name 'InstallPath' -Default $projectRoot
    $deploymentRole = Get-BodyStringValue -Body $Body -Name 'DeploymentRole' -Default 'Standalone'
    if ($deploymentRole -notin @('Standalone','Central','Collector')) { $deploymentRole = 'Standalone' }
    $action = (Get-BodyStringValue -Body $Body -Name 'Action' -Default 'selected').ToLowerInvariant()

    $args = @(
        '-NoProfile',
        '-ExecutionPolicy','Bypass',
        '-File',$deployScript,
        '-RepositoryServer',$repositoryServer,
        '-RepositoryDatabase',$repositoryDatabase,
        '-InstallPath',$installPath,
        '-DeploymentRole',$deploymentRole,
        '-CoreIntervalMinutes',([string](Get-BodyIntValue -Body $Body -Name 'CoreIntervalMinutes' -Default 5)),
        '-AdvancedIntervalMinutes',([string](Get-BodyIntValue -Body $Body -Name 'AdvancedIntervalMinutes' -Default 30)),
        '-WebDashboardPort',([string](Get-BodyIntValue -Body $Body -Name 'WebDashboardPort' -Default $Port)),
        '-DailyTime',(Get-BodyStringValue -Body $Body -Name 'DailyTime' -Default '02:00'),
        '-RetentionTime',(Get-BodyStringValue -Body $Body -Name 'RetentionTime' -Default '03:00')
    )

    foreach ($name in @('CollectorNodeName','CollectorSite','CollectorTags','JobServer')) {
        $value = Get-BodyStringValue -Body $Body -Name $name
        if (-not [string]::IsNullOrWhiteSpace($value)) { $args += @("-$name", $value) }
    }

    $monitoredInstances = @(Get-BodyListValue -Body $Body -Name 'MonitoredInstances')
    if ($monitoredInstances.Count -gt 0) {
        $args += '-MonitoredInstances'
        foreach ($instance in $monitoredInstances) { $args += $instance }
    }

    switch ($action) {
        'full' {
            $args += '-All'
            if (Get-BodyBoolValue -Body $Body -Name 'ConfigureWindowsTasks') { $args += '-ConfigureWindowsTasks' }
            if (Get-BodyBoolValue -Body $Body -Name 'ConfigurePerInstanceJobs') { $args += '-ConfigurePerInstanceJobs' }
        }
        'database' { $args += @('-DeployDatabase','-SkipInstanceConfiguration') }
        'scripts' { $args += '-DeployScripts' }
        'jobs' { $args += '-ConfigureSqlAgentJobs'; if (Get-BodyBoolValue -Body $Body -Name 'ConfigurePerInstanceJobs') { $args += '-ConfigurePerInstanceJobs' } }
        default {
            if (Get-BodyBoolValue -Body $Body -Name 'DeployDatabase' -Default $true) { $args += '-DeployDatabase' }
            if (Get-BodyBoolValue -Body $Body -Name 'DeployScripts' -Default $true) { $args += '-DeployScripts' }
            if (Get-BodyBoolValue -Body $Body -Name 'ConfigureSqlAgentJobs' -Default $true) { $args += '-ConfigureSqlAgentJobs' }
            if (Get-BodyBoolValue -Body $Body -Name 'ConfigureWindowsTasks') { $args += '-ConfigureWindowsTasks' }
            if (Get-BodyBoolValue -Body $Body -Name 'ConfigurePerInstanceJobs') { $args += '-ConfigurePerInstanceJobs' }
        }
    }

    if (Get-BodyBoolValue -Body $Body -Name 'SkipInstanceConfiguration') { $args += '-SkipInstanceConfiguration' }
    if (Get-BodyBoolValue -Body $Body -Name 'Force') { $args += '-Force' }

    if (Get-BodyBoolValue -Body $Body -Name 'ConfigureCentralLinkedServer') {
        $args += '-ConfigureCentralLinkedServer'
        $args += @('-CentralLinkedServer', (Get-BodyStringValue -Body $Body -Name 'CentralLinkedServer' -Default 'SQLMON_CENTRAL'))
        $args += @('-CentralServerInstance', (Get-BodyStringValue -Body $Body -Name 'CentralServerInstance'))
        $args += @('-CentralLinkedServerProvider', (Get-BodyStringValue -Body $Body -Name 'CentralLinkedServerProvider' -Default 'MSOLEDBSQL'))
        $login = Get-BodyStringValue -Body $Body -Name 'CentralLinkedServerLogin'
        $password = Get-BodyStringValue -Body $Body -Name 'CentralLinkedServerPassword'
        if (-not [string]::IsNullOrWhiteSpace($login)) { $args += @('-CentralLinkedServerLogin', $login) }
        if (-not [string]::IsNullOrWhiteSpace($password)) { $args += @('-CentralLinkedServerPassword', $password) }
    }
    $args += @('-CentralSyncIntervalMinutes', ([string](Get-BodyIntValue -Body $Body -Name 'CentralSyncIntervalMinutes' -Default 15)))

    return Invoke-ProcessCapture -FilePath (Resolve-SqlMonitorPowerShellPath) -Arguments $args -WorkingDirectory $projectRoot
}

function Get-ScheduleTaskName { param([int]$InstanceID) "SQLMonitor-Collectors-Instance-$InstanceID" }

function Get-ScheduleStatus {
    param([int]$InstanceID)
    try {
        $task = Get-ScheduledTask -TaskName (Get-ScheduleTaskName -InstanceID $InstanceID) -ErrorAction SilentlyContinue
        if (-not $task) { return @{ status = 'none'; text = 'Schedule: none' } }
        $trigger = $task.Triggers | Select-Object -First 1
        return @{ status = [string]$task.State; text = "Schedule: configured ($($task.State))"; trigger = $trigger }
    }
    catch {
        return @{ status = 'unavailable'; text = $_.Exception.Message }
    }
}

function Get-PatchStatusPayload {
    param([string]$DisplayName = '')
    $instances = @(Get-ConfiguredInstances | Where-Object { $_.IsActive })
    if (-not [string]::IsNullOrWhiteSpace($DisplayName)) {
        $instances = @($instances | Where-Object { $_.DisplayName -eq $DisplayName -or $_.SqlInstance -eq $DisplayName })
    }
    $rows = @()
    try {
        $rows = @(Get-SQLServerPatchStatus -Instances $instances)
    }
    catch {
        $errorMessage = $_.Exception.Message
        return @($instances | ForEach-Object {
            [pscustomobject]@{
                InstanceName = $_.DisplayName
                SqlInstance = $_.SqlInstance
                VersionName = ''
                ProductVersion = ''
                CurrentUpdate = ''
                CurrentPatchKB = ''
                CurrentPatchBuild = ''
                CurrentChannel = ''
                PatchStatus = 'Error'
                RecommendedKB = ''
                RecommendedBuild = ''
                LatestPatchKB = ''
                LatestPatchBuild = ''
                LatestPatchLabel = ''
                LatestCumulativeUpdateKB = ''
                LatestCumulativeUpdateBuild = ''
                LatestSecurityUpdateKB = ''
                LatestSecurityUpdateBuild = ''
                LastChecked = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                StatusSummary = "Patch status could not be checked: $errorMessage"
                MicrosoftCatalogUrl = 'https://www.catalog.update.microsoft.com/Home.aspx'
                SupportUrl = 'https://learn.microsoft.com/troubleshoot/sql/releases/download-and-install-latest-updates'
            }
        })
    }
    return @($rows | ForEach-Object {
        $catalogUrl = ''
        $supportUrl = ''
        if ($_.RecommendedPatch) {
            $catalogUrl = [string]$_.RecommendedPatch.CatalogUrl
            $supportUrl = [string]$_.RecommendedPatch.SupportUrl
        }
        $catalogKb = if (-not [string]::IsNullOrWhiteSpace([string]$_.RecommendedKB)) { [string]$_.RecommendedKB } else { [string]$_.LatestPatchKB }
        if ([string]::IsNullOrWhiteSpace($catalogUrl) -and -not [string]::IsNullOrWhiteSpace($catalogKb)) {
            $catalogUrl = "https://www.catalog.update.microsoft.com/Search.aspx?q=$([System.Uri]::EscapeDataString($catalogKb))"
        }
        [pscustomobject]@{
            InstanceName = $_.InstanceName
            SqlInstance = $_.SqlInstance
            VersionName = $_.VersionName
            ProductVersion = $_.ProductVersion
            CurrentUpdate = $_.CurrentUpdate
            CurrentPatchKB = $_.CurrentPatchKB
            CurrentPatchBuild = $_.CurrentPatchBuild
            CurrentChannel = $_.CurrentChannel
            PatchStatus = $_.PatchStatus
            RecommendedKB = $_.RecommendedKB
            RecommendedBuild = $_.RecommendedBuild
            LatestPatchKB = $_.LatestPatchKB
            LatestPatchBuild = $_.LatestPatchBuild
            LatestPatchLabel = $_.LatestPatchLabel
            LatestCumulativeUpdateKB = $_.LatestCumulativeUpdateKB
            LatestCumulativeUpdateBuild = $_.LatestCumulativeUpdateBuild
            LatestSecurityUpdateKB = $_.LatestSecurityUpdateKB
            LatestSecurityUpdateBuild = $_.LatestSecurityUpdateBuild
            LastChecked = if ($_.LastChecked -is [datetime]) { $_.LastChecked.ToString('yyyy-MM-dd HH:mm:ss') } else { [string]$_.LastChecked }
            StatusSummary = $_.StatusSummary
            MicrosoftCatalogUrl = $catalogUrl
            SupportUrl = $supportUrl
        }
    })
}

function Get-Users {
    $query = @"
SELECT
    u.UserID,
    u.UserName,
    u.DisplayName,
    u.EmailAddress,
    u.PhoneNumber,
    u.Department,
    u.RoleName,
    u.IsActive,
    u.MustChangePassword,
    u.FailedLoginCount,
    u.LastFailedLoginAt,
    u.LockoutUntil,
    u.PasswordChangedAt,
    u.CreatedAt,
    u.LastLoginAt,
    ISNULL(directAccess.DirectServerCount, 0) AS DirectServerCount,
    ISNULL(groupAccess.GroupCount, 0) AS GroupCount,
    ISNULL(effectiveAccess.EffectiveServerCount, 0) AS EffectiveServerCount
FROM mon.DashboardUsers u
OUTER APPLY (
    SELECT COUNT(*) AS DirectServerCount
    FROM mon.DashboardUserInstanceAccess dua
    WHERE dua.UserID = u.UserID
) directAccess
OUTER APPLY (
    SELECT COUNT(*) AS GroupCount
    FROM mon.DashboardUserServerGroupAccess uga
    WHERE uga.UserID = u.UserID
) groupAccess
OUTER APPLY (
    SELECT COUNT(DISTINCT accessScope.InstanceID) AS EffectiveServerCount
    FROM (
        SELECT InstanceID
        FROM mon.DashboardUserInstanceAccess
        WHERE UserID = u.UserID
        UNION
        SELECT gm.InstanceID
        FROM mon.DashboardUserServerGroupAccess uga
        INNER JOIN mon.DashboardServerGroups g ON uga.GroupID = g.GroupID AND g.IsActive = 1
        INNER JOIN mon.DashboardServerGroupMembers gm ON uga.GroupID = gm.GroupID
        WHERE uga.UserID = u.UserID
    ) accessScope
) effectiveAccess
ORDER BY u.UserName;
"@
    try { return ConvertTo-PlainRows (Invoke-RepoQuery -Query $query) }
    catch { return @() }
}

function Get-RolePermissionsMatrix {
    # Load matrix from JSON file if it exists; otherwise fall back to static defaults.
    $jsonPath = Join-Path $PSScriptRoot '..\Config\rolePermissions.json'
    if (Test-Path $jsonPath) {
        try {
            $json = Get-Content $jsonPath -Raw -Encoding UTF8
            $matrix = $json | ConvertFrom-Json -ErrorAction Stop
            return $matrix | ForEach-Object { [pscustomobject]$_ }
        }
        catch {
            # If parsing fails, show a warning and use defaults.
            Show-Notification -Message "Failed to read rolePermissions.json   using defaults." -Type Warning -Title "Role Permissions"
        }
    }

    # ----- STATIC DEFAULTS (unchanged) -----
    return @(
        [pscustomobject]@{ Role = 'Admin'; ServerOverview = 'View all'; RunCollectors = 'Yes'; InstanceManagement = 'Yes'; UserManagement = 'Yes'; Thresholds = 'Yes'; Notifications = 'Yes'; PatchManager = 'Yes'; RepositoryUpgrade = 'Yes' },
        [pscustomobject]@{ Role = 'AppOwner'; ServerOverview = 'Assigned only'; RunCollectors = 'No'; InstanceManagement = 'No'; UserManagement = 'No'; Thresholds = 'No'; Notifications = 'No'; PatchManager = 'No'; RepositoryUpgrade = 'No' },
        [pscustomobject]@{ Role = 'Limited'; ServerOverview = 'Assigned only'; RunCollectors = 'No'; InstanceManagement = 'No'; UserManagement = 'No'; Thresholds = 'No'; Notifications = 'No'; PatchManager = 'No'; RepositoryUpgrade = 'No' },
        [pscustomobject]@{ Role = 'ViewOnly'; ServerOverview = 'Assigned only'; RunCollectors = 'No'; InstanceManagement = 'No'; UserManagement = 'No'; Thresholds = 'No'; Notifications = 'No'; PatchManager = 'No'; RepositoryUpgrade = 'No' }
    )
}

function Get-Permission {
    param(
        [string]$Role,
        [string]$Permission   # column name e.g. 'RunCollectors'
    )
    $row = (Get-RolePermissionsMatrix) | Where-Object { $_.Role -eq $Role }
    if ($null -eq $row) { return $false }
    $value = $row.$Permission
    return ($value -eq 'Yes' -or $value -eq 'View all' -or $value -eq 'Assigned only')
}

function Get-DashboardAuditRows {
    param([int]$Limit = 200)
    try {
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP (@Limit) AuditID, CreatedAt, UserName, ActionName, Details, ClientHost FROM mon.DashboardAuditLog ORDER BY CreatedAt DESC, AuditID DESC;' -Parameters @{ Limit = [Math]::Min(500, [Math]::Max(25, $Limit)) })
    }
    catch {
        return @([pscustomobject]@{ Status = 'Error'; Message = $_.Exception.Message })
    }
}

function Get-UserAccess {
    param([int]$UserID)
    try {
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT InstanceID FROM mon.DashboardUserInstanceAccess WHERE UserID = @UserID ORDER BY InstanceID;' -Parameters @{ UserID = $UserID })
    }
    catch {
        return @()
    }
}

function Invoke-BiInsightsSchemaEnsure {
    $schemaPath = Join-Path $projectRoot 'Sql\13_BIInsightsStudio.sql'
    if (Test-Path $schemaPath -PathType Leaf) {
        Invoke-RepoNonQuery -Query (Get-Content -Path $schemaPath -Raw)
        return
    }
    Invoke-RepoNonQuery -Query @"
IF OBJECT_ID('mon.BIInsightDatasets', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightDatasets (
        DatasetKey NVARCHAR(80) NOT NULL CONSTRAINT PK_BIInsightDatasets PRIMARY KEY,
        DisplayName NVARCHAR(160) NOT NULL,
        Category NVARCHAR(80) NOT NULL,
        Description NVARCHAR(500) NULL,
        DefaultVisual NVARCHAR(40) NOT NULL CONSTRAINT DF_BIInsightDatasets_DefaultVisual DEFAULT ('table'),
        QueryName NVARCHAR(128) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_BIInsightDatasets_IsActive DEFAULT (1),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightDatasets_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL
    );
END;

IF OBJECT_ID('mon.BIInsightReports', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightReports (
        ReportID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightReports PRIMARY KEY,
        ReportName NVARCHAR(160) NOT NULL,
        ReportDescription NVARCHAR(500) NULL,
        LayoutJson NVARCHAR(MAX) NOT NULL,
        FilterJson NVARCHAR(MAX) NULL,
        IsShared BIT NOT NULL CONSTRAINT DF_BIInsightReports_IsShared DEFAULT (0),
        CreatedBy NVARCHAR(128) NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightReports_CreatedAt DEFAULT (SYSDATETIME()),
        ModifiedAt DATETIME2(0) NULL
    );
END;

IF OBJECT_ID('mon.BIInsightBookmarks', 'U') IS NULL
BEGIN
    CREATE TABLE mon.BIInsightBookmarks (
        BookmarkID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_BIInsightBookmarks PRIMARY KEY,
        ReportID INT NOT NULL,
        BookmarkName NVARCHAR(160) NOT NULL,
        StateJson NVARCHAR(MAX) NOT NULL,
        CreatedBy NVARCHAR(128) NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_BIInsightBookmarks_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT FK_BIInsightBookmarks_Reports FOREIGN KEY (ReportID) REFERENCES mon.BIInsightReports(ReportID) ON DELETE CASCADE
    );
END;

MERGE mon.BIInsightDatasets AS target
USING (VALUES
    (N'server-scorecard', N'Server Scorecard', N'Operations', N'Health, CPU, memory, open alerts, and repeat counts by SQL Server.', N'table', N'Get-BiInsights.Scorecard'),
    (N'alert-trends', N'Alert Trends', N'Alerts', N'Daily alert volume by severity for trending and SLA reporting.', N'stacked-bar', N'Get-BiInsights.AlertTrends'),
    (N'noisy-alerts', N'Noisy Alerts', N'Alerts', N'Most repeated alert fingerprints across monitored servers.', N'table', N'Get-BiInsights.NoisyAlerts'),
    (N'capacity-hotspots', N'Capacity Hotspots', N'Capacity', N'Disk volumes with highest utilization and lowest free space.', N'table', N'Get-BiInsights.Capacity'),
    (N'module-health', N'Collection Module Health', N'Collectors', N'Collection module status distribution across monitored servers.', N'table', N'Get-BiInsights.ModuleHealth'),
    (N'health-posture', N'Health Posture', N'Executive', N'Healthy, warning, and critical server posture distribution.', N'doughnut', N'Get-BiInsights.HealthPosture'),
    (N'vm-scorecard', N'VM Scorecard', N'VM Monitoring', N'Windows VM health, CPU, memory, disk, services, telemetry freshness, alerts, and tickets.', N'table', N'Get-BiInsights.VMScorecard'),
    (N'vm-alert-trends', N'VM Alert Trends', N'VM Monitoring', N'Windows VM alert volume by day, severity, and monitoring module.', N'stacked-column', N'Get-BiInsights.VMAlertTrends'),
    (N'vm-ticket-sla', N'VM Ticket SLA', N'VM Monitoring', N'VM Monitoring tickets by severity, assignment group, and SLA status.', N'clustered-bar', N'Get-BiInsights.VMTicketSla'),
    (N'vm-capacity', N'VM Capacity', N'VM Monitoring', N'Windows VM disk utilization and free-space risk by drive.', N'clustered-bar', N'Get-BiInsights.VMCapacity')
) AS source (DatasetKey, DisplayName, Category, Description, DefaultVisual, QueryName)
ON target.DatasetKey = source.DatasetKey
WHEN MATCHED THEN
    UPDATE SET DisplayName = source.DisplayName, Category = source.Category, Description = source.Description, DefaultVisual = source.DefaultVisual, QueryName = source.QueryName, IsActive = 1, UpdatedAt = SYSDATETIME()
WHEN NOT MATCHED THEN
    INSERT (DatasetKey, DisplayName, Category, Description, DefaultVisual, QueryName)
    VALUES (source.DatasetKey, source.DisplayName, source.Category, source.Description, source.DefaultVisual, source.QueryName);
"@
}

function Get-UserGroupAccess {
    param([int]$UserID)
    try {
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT GroupID FROM mon.DashboardUserServerGroupAccess WHERE UserID = @UserID ORDER BY GroupID;' -Parameters @{ UserID = $UserID })
    }
    catch {
        return @()
    }
}

function Get-EffectiveUserAccess {
    param([int]$UserID)
    try {
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT DISTINCT accessScope.InstanceID
FROM (
    SELECT InstanceID
    FROM mon.DashboardUserInstanceAccess
    WHERE UserID = @UserID
    UNION
    SELECT gm.InstanceID
    FROM mon.DashboardUserServerGroupAccess uga
    INNER JOIN mon.DashboardServerGroups g ON uga.GroupID = g.GroupID AND g.IsActive = 1
    INNER JOIN mon.DashboardServerGroupMembers gm ON uga.GroupID = gm.GroupID
    WHERE uga.UserID = @UserID
) accessScope
ORDER BY accessScope.InstanceID;
"@ -Parameters @{ UserID = $UserID })
    }
    catch {
        return @()
    }
}

function Save-UserAccess {
    param([int]$UserID, [int[]]$InstanceIDs, [int[]]$GroupIDs)
    Invoke-RepoNonQuery -Query 'DELETE FROM mon.DashboardUserInstanceAccess WHERE UserID = @UserID;' -Parameters @{ UserID = $UserID }
    foreach ($instanceId in @($InstanceIDs)) {
        Invoke-RepoNonQuery -Query 'INSERT INTO mon.DashboardUserInstanceAccess (UserID, InstanceID) VALUES (@UserID, @InstanceID);' -Parameters @{ UserID = $UserID; InstanceID = [int]$instanceId }
    }
    Invoke-RepoNonQuery -Query 'DELETE FROM mon.DashboardUserServerGroupAccess WHERE UserID = @UserID;' -Parameters @{ UserID = $UserID }
    foreach ($groupId in @($GroupIDs)) {
        Invoke-RepoNonQuery -Query 'INSERT INTO mon.DashboardUserServerGroupAccess (UserID, GroupID) VALUES (@UserID, @GroupID);' -Parameters @{ UserID = $UserID; GroupID = [int]$groupId }
    }
}

function Save-DirectUserServerAccess {
    param([object]$Body)
    $userId = if ($null -eq $Body.UserID) { 0 } else { [int]$Body.UserID }
    $instanceIds = @($Body.InstanceIDs | ForEach-Object { [int]$_ } | Where-Object { $_ -gt 0 } | Select-Object -Unique)
    if ($userId -le 0) { throw 'Select a user first.' }
    Invoke-RepoNonQuery -Query 'DELETE FROM mon.DashboardUserInstanceAccess WHERE UserID = @UserID;' -Parameters @{ UserID = $userId }
    foreach ($instanceId in $instanceIds) {
        Invoke-RepoNonQuery -Query 'INSERT INTO mon.DashboardUserInstanceAccess (UserID, InstanceID) VALUES (@UserID, @InstanceID);' -Parameters @{ UserID = $userId; InstanceID = [int]$instanceId }
    }
    return @{ ok = $true; access = Get-UserAccess -UserID $userId; groupAccess = Get-UserGroupAccess -UserID $userId; effectiveAccess = Get-EffectiveUserAccess -UserID $userId; users = Get-Users }
}

function Get-ServerGroups {
    try {
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT
    g.GroupID,
    g.GroupName,
    g.ApplicationName,
    g.OwnerName,
    g.Description,
    g.IsActive,
    COUNT(DISTINCT gm.InstanceID) AS ServerCount,
    COUNT(DISTINCT uga.UserID) AS AssignedUserCount,
    g.CreatedAt,
    g.UpdatedAt
FROM mon.DashboardServerGroups g
LEFT JOIN mon.DashboardServerGroupMembers gm ON g.GroupID = gm.GroupID
LEFT JOIN mon.DashboardUserServerGroupAccess uga ON g.GroupID = uga.GroupID
GROUP BY g.GroupID, g.GroupName, g.ApplicationName, g.OwnerName, g.Description, g.IsActive, g.CreatedAt, g.UpdatedAt
ORDER BY g.ApplicationName, g.GroupName;
"@)
    }
    catch { return @() }
}

function Get-ServerGroupMembers {
    param([int]$GroupID = 0)
    try {
        $where = if ($GroupID -gt 0) { 'WHERE gm.GroupID = @GroupID' } else { '' }
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT gm.GroupID, gm.InstanceID, mi.DisplayName, mi.EnvironmentName
FROM mon.DashboardServerGroupMembers gm
INNER JOIN mon.MonitoredInstances mi ON gm.InstanceID = mi.InstanceID
$where
ORDER BY mi.DisplayName;
"@ -Parameters @{ GroupID = $GroupID })
    }
    catch { return @() }
}

function Get-ServerGroupUsers {
    param([int]$GroupID = 0)
    try {
        $where = if ($GroupID -gt 0) { 'WHERE uga.GroupID = @GroupID' } else { '' }
        return ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT uga.GroupID, uga.UserID, u.UserName, u.DisplayName, u.RoleName, u.Department, u.IsActive
FROM mon.DashboardUserServerGroupAccess uga
INNER JOIN mon.DashboardUsers u ON uga.UserID = u.UserID
$where
ORDER BY u.DisplayName, u.UserName;
"@ -Parameters @{ GroupID = $GroupID })
    }
    catch { return @() }
}

function Save-ServerGroup {
    param([object]$Body)
    $groupId = if ($null -eq $Body.GroupID) { 0 } else { [int]$Body.GroupID }
    $groupName = ([string]$Body.GroupName).Trim()
    $applicationName = if ($null -ne $Body.ApplicationName) { ([string]$Body.ApplicationName).Trim() } else { '' }
    $ownerName = if ($null -ne $Body.OwnerName) { ([string]$Body.OwnerName).Trim() } else { '' }
    $description = if ($null -ne $Body.Description) { ([string]$Body.Description).Trim() } else { '' }
    $isActive = if ($null -eq $Body.IsActive) { $true } else { [bool]$Body.IsActive }
    $instanceIds = @($Body.InstanceIDs | ForEach-Object { [int]$_ } | Where-Object { $_ -gt 0 } | Select-Object -Unique)
    $userIds = @($Body.UserIDs | ForEach-Object { [int]$_ } | Where-Object { $_ -gt 0 } | Select-Object -Unique)

    if ([string]::IsNullOrWhiteSpace($groupName)) { throw 'Group name is required.' }
    if ($instanceIds.Count -eq 0) { throw 'Select at least one server for the group.' }
    if ($userIds.Count -eq 0) { throw 'Select at least one user for the application server group.' }
    $activeValue = if ($isActive) { 1 } else { 0 }

    if ($groupId -le 0) {
        $groupId = [int](Invoke-RepoScalar -Query 'INSERT INTO mon.DashboardServerGroups (GroupName, ApplicationName, OwnerName, Description, IsActive) VALUES (@GroupName, @ApplicationName, @OwnerName, @Description, @IsActive); SELECT CAST(SCOPE_IDENTITY() AS INT);' -Parameters @{ GroupName = $groupName; ApplicationName = $applicationName; OwnerName = $ownerName; Description = $description; IsActive = $activeValue })
    }
    else {
        Invoke-RepoNonQuery -Query 'UPDATE mon.DashboardServerGroups SET GroupName = @GroupName, ApplicationName = @ApplicationName, OwnerName = @OwnerName, Description = @Description, IsActive = @IsActive, UpdatedAt = SYSDATETIME() WHERE GroupID = @GroupID;' -Parameters @{ GroupID = $groupId; GroupName = $groupName; ApplicationName = $applicationName; OwnerName = $ownerName; Description = $description; IsActive = $activeValue }
    }

    Invoke-RepoNonQuery -Query 'DELETE FROM mon.DashboardServerGroupMembers WHERE GroupID = @GroupID;' -Parameters @{ GroupID = $groupId }
    foreach ($instanceId in $instanceIds) {
        Invoke-RepoNonQuery -Query 'INSERT INTO mon.DashboardServerGroupMembers (GroupID, InstanceID) VALUES (@GroupID, @InstanceID);' -Parameters @{ GroupID = $groupId; InstanceID = [int]$instanceId }
    }
    Invoke-RepoNonQuery -Query 'DELETE FROM mon.DashboardUserServerGroupAccess WHERE GroupID = @GroupID;' -Parameters @{ GroupID = $groupId }
    foreach ($assignedUserId in $userIds) {
        Invoke-RepoNonQuery -Query 'INSERT INTO mon.DashboardUserServerGroupAccess (UserID, GroupID) VALUES (@UserID, @GroupID);' -Parameters @{ UserID = [int]$assignedUserId; GroupID = $groupId }
    }
    return @{ ok = $true; groups = Get-ServerGroups; members = Get-ServerGroupMembers -GroupID $groupId; users = Get-ServerGroupUsers -GroupID $groupId }
}

function Delete-ServerGroup {
    param([int]$GroupID)
    if ($GroupID -le 0) { throw 'GroupID is required.' }
    Invoke-RepoNonQuery -Query 'DELETE FROM mon.DashboardServerGroups WHERE GroupID = @GroupID;' -Parameters @{ GroupID = $GroupID }
    return @{ ok = $true; groups = Get-ServerGroups }
}

function Save-User {
    param([object]$Body)
    $userId = if ($null -eq $Body.UserID) { 0 } else { [int]$Body.UserID }
    $userName = ([string]$Body.UserName).Trim()
    $displayName = ([string]$Body.DisplayName).Trim()
    $roleName = if ([string]::IsNullOrWhiteSpace([string]$Body.RoleName)) { 'ViewOnly' } else { [string]$Body.RoleName }
    $emailAddress = if ($null -ne $Body.EmailAddress) { [string]$Body.EmailAddress } else { $null }
    $phoneNumber = if ($null -ne $Body.PhoneNumber) { [string]$Body.PhoneNumber } else { $null }
    $department = if ($null -ne $Body.Department) { [string]$Body.Department } else { $null }
    $isActive = if ($null -eq $Body.IsActive) { $true } else { [bool]$Body.IsActive }
    $mustChange = if ($null -eq $Body.MustChangePassword) { $false } else { [bool]$Body.MustChangePassword }
    $password = [string]$Body.Password
    $bodyProperties = @($Body.PSObject.Properties.Name)
    $hasAccessPayload = ($bodyProperties -contains 'InstanceIDs' -or $bodyProperties -contains 'GroupIDs')
    $instanceIds = if ($bodyProperties -contains 'InstanceIDs') { @($Body.InstanceIDs | ForEach-Object { [int]$_ } | Where-Object { $_ -gt 0 } | Select-Object -Unique) } else { @() }
    $groupIds = if ($bodyProperties -contains 'GroupIDs') { @($Body.GroupIDs | ForEach-Object { [int]$_ } | Where-Object { $_ -gt 0 } | Select-Object -Unique) } else { @() }

    if ([string]::IsNullOrWhiteSpace($userName)) { throw 'User name is required.' }
    if ($roleName -notin @('Admin', 'AppOwner', 'ViewOnly', 'Limited')) { throw 'Role must be Admin, AppOwner, ViewOnly, or Limited.' }
    $activeValue = if ($isActive) { 1 } else { 0 }
    $mustChangeValue = if ($mustChange) { 1 } else { 0 }

    if ($userId -le 0) {
        if ([string]::IsNullOrWhiteSpace($password) -or $password.Length -lt 8) { throw 'Password must be at least 8 characters for new users.' }
        $salt = New-PasswordSalt
        $hash = Get-PasswordHashBytes -Password $password -Salt $salt
        $query = 'INSERT INTO mon.DashboardUsers (UserName, DisplayName, EmailAddress, PhoneNumber, Department, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword) VALUES (@UserName, @DisplayName, @EmailAddress, @PhoneNumber, @Department, @PasswordSalt, @PasswordHash, @RoleName, @ActiveValue, @MustChangeValue); SELECT CAST(SCOPE_IDENTITY() AS INT);'
        $userId = [int](Invoke-RepoScalar -Query $query -Parameters @{ UserName = $userName; DisplayName = $displayName; EmailAddress = $emailAddress; PhoneNumber = $phoneNumber; Department = $department; PasswordSalt = $salt; PasswordHash = $hash; RoleName = $roleName; ActiveValue = $activeValue; MustChangeValue = $mustChangeValue })
    }
    else {
        Invoke-RepoNonQuery -Query 'UPDATE mon.DashboardUsers SET UserName = @UserName, DisplayName = @DisplayName, EmailAddress = @EmailAddress, PhoneNumber = @PhoneNumber, Department = @Department, RoleName = @RoleName, IsActive = @ActiveValue, MustChangePassword = @MustChangeValue, UpdatedAt = SYSDATETIME() WHERE UserID = @UserID;' -Parameters @{ UserID = $userId; UserName = $userName; DisplayName = $displayName; EmailAddress = $emailAddress; PhoneNumber = $phoneNumber; Department = $department; RoleName = $roleName; ActiveValue = $activeValue; MustChangeValue = $mustChangeValue }
        if (-not [string]::IsNullOrWhiteSpace($password)) {
            if ($password.Length -lt 8) { throw 'Password must be at least 8 characters.' }
            $salt = New-PasswordSalt
            $hash = Get-PasswordHashBytes -Password $password -Salt $salt
            Invoke-RepoNonQuery -Query 'UPDATE mon.DashboardUsers SET PasswordSalt = @PasswordSalt, PasswordHash = @PasswordHash, FailedLoginCount = 0, LockoutUntil = NULL, PasswordChangedAt = SYSDATETIME(), UpdatedAt = SYSDATETIME() WHERE UserID = @UserID;' -Parameters @{ UserID = $userId; PasswordSalt = $salt; PasswordHash = $hash }
        }
    }

    if ($hasAccessPayload) {
        Save-UserAccess -UserID $userId -InstanceIDs $instanceIds -GroupIDs $groupIds
    }
    return @{ ok = $true; users = Get-Users; access = Get-UserAccess -UserID $userId; groupAccess = Get-UserGroupAccess -UserID $userId; effectiveAccess = Get-EffectiveUserAccess -UserID $userId }
}

function Get-RouteResult {
    param($Request)
    $path = $Request.Url.LocalPath.TrimEnd('/')
    if ($path -eq '') { $path = '/' }
    $method = $Request.HttpMethod.ToUpperInvariant()

    if ($method -eq 'POST' -and $path -eq '/api/login') {
        $body = Read-RequestJson -Request $Request
        $user = Authenticate-WebUser -UserName ([string]$body.UserName) -Password ([string]$body.Password)
        if (-not $user) { throw 'AUTH_FAILED: Invalid user name or password.' }
        $token = New-SessionToken
        $script:Sessions[$token] = [pscustomobject]@{
            User = $user
            CreatedAt = Get-Date
            ExpiresAt = (Get-Date).AddMinutes((Get-SessionTimeoutMinutes))
        }
        if ([int]$user.UserID -gt 0) {
            Write-DashboardAudit -User $user -ActionName 'Login' -Details 'Web dashboard login'
        }
        return @{ ok = $true; token = $token; user = Convert-AuthUserForClient -User $user }
    }

    if ($method -eq 'GET' -and $path -eq '/api/session') {
        $user = Get-SessionUser -Request $Request
        return @{ authenticated = [bool]$user; user = Convert-AuthUserForClient -User $user }
    }

    if ($method -eq 'POST' -and $path -eq '/api/logout') {
        $token = Get-RequestAuthToken -Request $Request
        if (-not [string]::IsNullOrWhiteSpace($token) -and $script:Sessions.ContainsKey($token)) {
            $script:Sessions.Remove($token)
        }
        return @{ ok = $true }
    }

    $currentUser = Require-AuthenticatedUser -Request $Request

    if ($method -eq 'POST' -and $path -eq '/api/account/password') {
        $body = Read-RequestJson -Request $Request
        return Change-UserPassword -User $currentUser -CurrentPassword ([string]$body.CurrentPassword) -NewPassword ([string]$body.NewPassword)
    }

    if ($method -eq 'GET' -and $path -eq '/api/security/permissions') {
        return @{ rows = Get-RolePermissionsMatrix }
    }

    if ($method -eq 'GET' -and $path -eq '/api/bootstrap') {
        $configured = @(Get-ConfiguredInstances)
        $repositoryInstances = @()
        $activeInstances = @()
        $repositoryError = $null
        try {
            $repositoryInstances = @(Get-RepositoryInstances)
            $activeInstances = @(Filter-InstancesForUser -Instances @($repositoryInstances | Where-Object { $_.IsActive }) -User $currentUser)
        }
        catch {
            $repositoryError = $_.Exception.Message
            $activeInstances = @(Filter-InstancesForUser -Instances @(Convert-ConfiguredInstancesForUi | Where-Object { $_.IsActive }) -User $currentUser)
        }
        # Get VM hierarchy data
        $vmHierarchy = $null
        try {
            $vmHierarchy = Get-VMHierarchyPayload -User $currentUser
        }
        catch {
            Write-MonitorLog "WARNING: Could not load VM hierarchy: $($_.Exception.Message)" -Level 'Warning'
        }

        return @{
            repository = @{ server = $script:RepositoryServer; database = $script:RepositoryDatabase; sourcePath = $projectRoot; installPath = $projectRoot }
            featureGroups = $script:FeatureGroups
            instances = $activeInstances
            allInstances = $repositoryInstances
            configuredInstances = $configured
            settings = Get-DashboardSettings
            notifications = Get-NotificationsConfig
            user = Convert-AuthUserForClient -User $currentUser
            repositoryError = $repositoryError
            vmHierarchy = $vmHierarchy
        }
    }

    if ($currentUser.MustChangePassword) {
        throw 'PASSWORD_CHANGE_REQUIRED: Change your password before continuing.'
    }

    # VM Hierarchy endpoints
    if ($method -eq 'GET' -and $path -eq '/api/vms') {
        return Get-VMHierarchyPayload -User $currentUser
    }
    if ($method -eq 'GET' -and $path -eq '/api/vms/tree') {
        $vmId = Get-IntQueryValue -Request $Request -Name 'vmId'
        return Invoke-VMTreeQuery -VMID $vmId
    }
    if ($method -eq 'GET' -and $path -eq '/api/overview') { return Get-OverviewPayload -User $currentUser }
    if ($method -eq 'GET' -and $path -eq '/api/windows/overview') { return Get-WindowsMonitoringPayload }
    if ($method -eq 'POST' -and $path -eq '/api/windows/evaluate-alerts') {
        [void](Require-AdminUser -Request $Request -ActionName 'Evaluating VM alerts')
        $result = ConvertTo-PlainRows (Invoke-RepoQuery -Query "DECLARE @TicketsCreatedResult INT = 0; EXEC mon.usp_EvaluateWindowsVMAlerts @TargetID = NULL, @AutoCreateTickets = 1, @CreatedBy = N'web-dashboard', @TicketsCreated = @TicketsCreatedResult OUTPUT;")
        Write-DashboardAudit -User $currentUser -ActionName 'EvaluateVMAlerts' -Details 'VM alert evaluation requested'
        return @{ ok = $true; rows = $result }
    }
    if ($method -eq 'GET' -and $path -eq '/api/windows/capacity') {
        $capacity = @()
        $sampleStatus = $null
        if (Test-RepositoryObjectExists 'mon.vw_WindowsCapacityDashboard') {
            $capacity = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsCapacityDashboard ORDER BY DaysUntilExhaustion ASC, DisplayName;")
        }
        elseif (Test-RepositoryObjectExists 'mon.WindowsCapacityForecast') {
            $capacity = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT f.ForecastID,
       f.TargetID,
       t.ComputerName,
       t.DisplayName,
       f.MetricName,
       f.CurrentValue,
       f.GrowthRatePerDay,
       f.ForecastExhaustionDate,
       f.DaysUntilExhaustion,
       f.ConfidencePercent,
       f.RecommendedAction,
       f.CalculatedAt
FROM mon.WindowsCapacityForecast f
LEFT JOIN mon.WindowsTargets t ON f.TargetID = t.TargetID
ORDER BY f.DaysUntilExhaustion ASC, t.DisplayName;
"@)
        }
        if ($capacity.Count -eq 0 -and (Test-RepositoryObjectExists 'mon.WindowsPerformanceSamples')) {
            $sampleStatus = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT t.DisplayName,
       t.ComputerName,
       COUNT(*) AS TotalSamples,
       COUNT(DISTINCT CAST(ps.CaptureTime AS DATE)) AS DistinctDays,
       MIN(ps.CaptureTime) AS EarliestSample,
       MAX(ps.CaptureTime) AS LatestSample,
       SUM(CASE WHEN ps.DiskUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS DiskSamples,
       SUM(CASE WHEN ps.MemoryUsedPercent IS NOT NULL THEN 1 ELSE 0 END) AS MemorySamples
FROM mon.WindowsPerformanceSamples ps
INNER JOIN mon.WindowsTargets t ON ps.TargetID = t.TargetID
WHERE t.IsEnabled = 1
GROUP BY t.TargetID, t.DisplayName, t.ComputerName
ORDER BY t.DisplayName;
"@)
        }
        return @{ capacity = $capacity; sampleStatus = $sampleStatus }
    }
    if ($method -eq 'GET' -and $path -eq '/api/windows/anomalies') {
        $anomalies = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsAnomalySummary ORDER BY DetectedAt DESC;")
        return @{ anomalies = $anomalies }
    }
    if ($method -eq 'GET' -and $path -eq '/api/windows/baselines') {
        if (Test-RepositoryObjectExists 'mon.vw_WindowsBaselineSummary') {
            $baselines = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsBaselineSummary ORDER BY DisplayName, MetricName;")
        }
        elseif (Test-RepositoryObjectExists 'mon.WindowsPerformanceBaseline') {
            $baselines = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT b.TargetID,
       t.DisplayName,
       b.MetricName,
       b.AvgValue AS CurrentHourAvg,
       b.StdDevValue AS CurrentHourStdDev,
       b.SampleCount,
       b.LastCalculatedAt
FROM mon.WindowsPerformanceBaseline b
LEFT JOIN mon.WindowsTargets t ON b.TargetID = t.TargetID
ORDER BY COALESCE(t.DisplayName, N''), b.MetricName;
"@)
        }
        else {
            $baselines = @()
        }
        return @{ baselines = $baselines }
    }
    if ($method -eq 'POST' -and $path -eq '/api/windows/calculate-baselines') {
        [void](Require-AdminUser -Request $Request -ActionName 'Calculating VM baselines')
        $body = Read-RequestJson -Request $Request
        $lookback = if ($body.LookbackDays) { [int]$body.LookbackDays } else { 30 }
        $result = ConvertTo-PlainRows (Invoke-RepoQuery -Query "EXEC mon.usp_CalculateWindowsBaselines @TargetID = NULL, @LookbackDays = $lookback;")
        return @{ ok = $true; baselinesUpdated = $result[0].BaselinesUpdated }
    }
    if ($method -eq 'POST' -and $path -eq '/api/windows/detect-anomalies') {
        [void](Require-AdminUser -Request $Request -ActionName 'Detecting VM anomalies')
        $body = Read-RequestJson -Request $Request
        $threshold = if ($body.StdDevThreshold) { [decimal]$body.StdDevThreshold } else { 2.5 }
        $result = ConvertTo-PlainRows (Invoke-RepoQuery -Query "EXEC mon.usp_DetectWindowsAnomalies @TargetID = NULL, @StdDevThreshold = $threshold;")
        return @{ ok = $true; anomaliesDetected = $result[0].AnomaliesDetected }
    }
    if ($method -eq 'POST' -and $path -eq '/api/windows/calculate-forecast') {
        [void](Require-AdminUser -Request $Request -ActionName 'Calculating VM capacity forecast')
        $body = Read-RequestJson -Request $Request
        $lookback = if ($body.LookbackDays) { [int]$body.LookbackDays } else { 90 }
        $result = ConvertTo-PlainRows (Invoke-RepoQuery -Query "EXEC mon.usp_CalculateWindowsCapacityForecast @TargetID = NULL, @LookbackDays = $lookback;")
        return @{ ok = $true; forecastsUpdated = $result[0].ForecastsUpdated }
    }
    if ($method -eq 'POST' -and $path -eq '/api/windows/acknowledge-anomaly') {
        $body = Read-RequestJson -Request $Request
        $anomalyId = [int]$body.AnomalyID
        $notes = if ($body.Notes) { [string]$body.Notes } else { '' }
        $user = if ($currentUser) { $currentUser.Username } else { 'unknown' }
        Invoke-RepoNonQuery -Query @"
UPDATE mon.WindowsAnomalyLog
SET IsAcknowledged = 1, AcknowledgedBy = @User, AcknowledgedAt = SYSDATETIME(), Notes = @Notes
WHERE AnomalyID = @AnomalyID;
"@ -Parameters @{ AnomalyID = $anomalyId; User = $user; Notes = $notes }
        return @{ ok = $true }
    }
    if ($method -eq 'GET' -and $path -eq '/api/windows/network') {
        $connections = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsNetworkConnectionSummary ORDER BY CaptureTime DESC;")
        $adapterStats = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsNetworkAdapterUtilization ORDER BY DisplayName, AdapterName;")
        $firewall = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsFirewallDashboard ORDER BY DisplayName, ProfileName;")
        return @{ connections = $connections; adapterStats = $adapterStats; firewall = $firewall }
    }
    if ($method -eq 'GET' -and $path -eq '/api/windows/patching') {
        $compliance = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsPatchCompliance ORDER BY ComplianceScore ASC, DisplayName;")
        $missing = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsMissingPatches ORDER BY IsRequired DESC, Severity DESC, DisplayName;")
        $timeline = ConvertTo-PlainRows (Invoke-RepoQuery -Query "SELECT * FROM mon.vw_WindowsPatchTimeline ORDER BY InstalledOn DESC, DisplayName;")
        return @{ compliance = $compliance; missing = $missing; timeline = $timeline }
    }
    if ($method -eq 'POST' -and $path -eq '/api/windows/refresh-patch-baseline') {
        [void](Require-AdminUser -Request $Request -ActionName 'Refreshing patch baseline')
        $result = ConvertTo-PlainRows (Invoke-RepoQuery -Query "EXEC mon.usp_RefreshWindowsPatchBaseline;")
        return @{ ok = $true; newPatchesAdded = $result[0].NewPatchesAdded }
    }
    if ($method -eq 'GET' -and $path -eq '/api/module-health') { return @{ rows = Get-ModuleHealth } }
    if ($method -eq 'GET' -and $path -eq '/api/instances') {
        $repoRows = @()
        $repoError = $null
        try { $repoRows = @(Get-RepositoryInstances) }
        catch { $repoError = $_.Exception.Message }
        return @{ configured = Get-ConfiguredInstances; repository = $repoRows; repositoryError = $repoError }
    }
    if ($method -eq 'POST' -and $path -eq '/api/instances') {
        [void](Require-AdminUser -Request $Request -ActionName 'Saving instances')
        $body = Read-RequestJson -Request $Request
        $instances = @(Get-ConfiguredInstances)
        $sqlInstance = ([string]$body.SqlInstance).Trim()
        if ([string]::IsNullOrWhiteSpace($sqlInstance)) { throw 'SQL Instance is required.' }
        $displayName = if ([string]::IsNullOrWhiteSpace([string]$body.DisplayName)) { $sqlInstance } else { ([string]$body.DisplayName).Trim() }
        $existing = $instances | Where-Object { $_.DisplayName -eq $displayName -or $_.SqlInstance -eq $sqlInstance } | Select-Object -First 1
        if ($existing) {
            $existing.DisplayName = $displayName
            $existing.SqlInstance = $sqlInstance
            $existing.RepositoryServer = if ([string]::IsNullOrWhiteSpace([string]$body.RepositoryServer)) { $script:RepositoryServer } else { [string]$body.RepositoryServer }
            $existing.RepositoryDatabase = if ([string]::IsNullOrWhiteSpace([string]$body.RepositoryDatabase)) { $script:RepositoryDatabase } else { [string]$body.RepositoryDatabase }
            $existing.Environment = if ([string]::IsNullOrWhiteSpace([string]$body.Environment)) { 'Production' } else { [string]$body.Environment }
            $existing.IsActive = if ($null -eq $body.IsActive) { $true } else { [bool]$body.IsActive }
        }
        else {
            $instances += [pscustomobject]@{
                DisplayName = $displayName
                SqlInstance = $sqlInstance
                RepositoryServer = if ([string]::IsNullOrWhiteSpace([string]$body.RepositoryServer)) { $script:RepositoryServer } else { [string]$body.RepositoryServer }
                RepositoryDatabase = if ([string]::IsNullOrWhiteSpace([string]$body.RepositoryDatabase)) { $script:RepositoryDatabase } else { [string]$body.RepositoryDatabase }
                Environment = if ([string]::IsNullOrWhiteSpace([string]$body.Environment)) { 'Production' } else { [string]$body.Environment }
                IsActive = if ($null -eq $body.IsActive) { $true } else { [bool]$body.IsActive }
            }
        }
        Save-ConfiguredInstances -Instances $instances
        Write-DashboardAudit -User $currentUser -ActionName 'SaveInstance' -Details $displayName
        $repoRows = @()
        $repoError = $null
        try { $repoRows = @(Get-RepositoryInstances) }
        catch { $repoError = $_.Exception.Message }
        $activeInstances = if ($repoRows.Count -gt 0) { @($repoRows | Where-Object { $_.IsActive }) } else { @(Convert-ConfiguredInstancesForUi | Where-Object { $_.IsActive }) }
        return @{ ok = $true; configured = Get-ConfiguredInstances; repository = $repoRows; instances = $activeInstances; repositoryError = $repoError }
    }
    if ($method -eq 'POST' -and $path -eq '/api/instances/import') {
        [void](Require-AdminUser -Request $Request -ActionName 'Importing instances')
        $body = Read-RequestJson -Request $Request
        $result = Import-ConfiguredInstances -Rows @($body.Rows)
        Write-DashboardAudit -User $currentUser -ActionName 'ImportInstances' -Details ("Imported {0} rows" -f @($body.Rows).Count)
        return $result
    }
    if ($method -eq 'DELETE' -and $path -eq '/api/instances') {
        [void](Require-AdminUser -Request $Request -ActionName 'Deleting instances')
        $displayName = Get-QueryValue -Request $Request -Name 'displayName'
        if ([string]::IsNullOrWhiteSpace($displayName)) { throw 'displayName is required.' }
        $instances = @(Get-ConfiguredInstances | Where-Object { $_.DisplayName -ne $displayName })
        Save-ConfiguredInstances -Instances $instances
        Write-DashboardAudit -User $currentUser -ActionName 'DeleteInstance' -Details $displayName
        $repoRows = @()
        $repoError = $null
        try {
            Invoke-RepoNonQuery -Query 'DELETE FROM mon.MonitoredInstances WHERE DisplayName = @DisplayName;' -Parameters @{ DisplayName = $displayName }
            $repoRows = @(Get-RepositoryInstances)
        }
        catch { $repoError = $_.Exception.Message }
        $activeInstances = if ($repoRows.Count -gt 0) { @($repoRows | Where-Object { $_.IsActive }) } else { @(Convert-ConfiguredInstancesForUi | Where-Object { $_.IsActive }) }
        return @{ ok = $true; configured = Get-ConfiguredInstances; repository = $repoRows; instances = $activeInstances; repositoryError = $repoError }
    }
    if ($method -eq 'GET' -and $path -match '^/api/module/([^/]+)$') { $id = Get-IntQueryValue -Request $Request -Name 'instanceId'; Assert-UserCanAccessInstance -User $currentUser -InstanceID $id; return @{ rows = Get-ModuleData -Module $Matches[1] -InstanceID $id } }
    if ($method -eq 'GET' -and $path -eq '/api/memory-analysis') { $id = Get-IntQueryValue -Request $Request -Name 'instanceId'; Assert-UserCanAccessInstance -User $currentUser -InstanceID $id; return Get-MemoryAnalysisData -InstanceID $id }
    if ($method -eq 'GET' -and $path -eq '/api/health') { $id = Get-IntQueryValue -Request $Request -Name 'instanceId'; Assert-UserCanAccessInstance -User $currentUser -InstanceID $id; return Get-HealthData -InstanceID $id }
    if ($method -eq 'GET' -and $path -eq '/api/alerts/open') { $id = Get-IntQueryValue -Request $Request -Name 'instanceId'; if ($id -gt 0) { Assert-UserCanAccessInstance -User $currentUser -InstanceID $id }; return @{ rows = Get-OpenAlerts -InstanceID $id -CriticalOnly ((Get-QueryValue -Request $Request -Name 'criticalOnly') -eq 'true') -User $currentUser } }
    if ($method -eq 'GET' -and $path -eq '/api/alerts/history') { return Get-AlertHistory -Request $Request -User $currentUser }
    if ($method -eq 'GET' -and $path -eq '/api/incident-flight-recorder') { $id = Get-IntQueryValue -Request $Request -Name 'instanceId'; $hours = Get-IntQueryValue -Request $Request -Name 'hours'; return Get-IncidentFlightRecorder -InstanceID $id -Hours $hours -User $currentUser }
    if ($method -eq 'POST' -and $path -eq '/api/alerts/ack') { $body = Read-RequestJson -Request $Request; return Acknowledge-AlertId -AlertID ([int64]$body.AlertID) -User ([string]$currentUser.UserName) }
    if ($method -eq 'POST' -and $path -eq '/api/alerts/bulk-ack') {
        [void](Require-AdminUser -Request $Request -ActionName 'Bulk alert acknowledgement')
        Invoke-RepoNonQuery -Query 'UPDATE mon.AlertHistory SET IsAcknowledged = 1, AcknowledgedOn = SYSDATETIME(), AcknowledgedBy = ''WebDashboard Bulk Operation'' WHERE IsAcknowledged = 0;'
        return @{ ok = $true }
    }
    if ($method -eq 'POST' -and $path -eq '/api/alerts/clear') {
        [void](Require-AdminUser -Request $Request -ActionName 'Clearing alert history')
        $days = [int](Read-RequestJson -Request $Request).OlderThanDays
        if ($days -le 0) { $days = 90 }
        Invoke-RepoNonQuery -Query 'DELETE FROM mon.AlertHistory WHERE AlertTime < DATEADD(DAY, -1 * @Days, GETDATE());' -Parameters @{ Days = $days }
        return @{ ok = $true }
    }
    # ----- TICKET SYSTEM API ENDPOINTS -----
    if ($method -eq 'GET' -and $path -eq '/api/tickets') {
        $severity = Get-QueryValue -Request $Request -Name 'severity' -Default ''
        $status = Get-QueryValue -Request $Request -Name 'status' -Default ''
        $assignedTo = Get-QueryValue -Request $Request -Name 'assignedTo' -Default ''
        $includeClosed = (Get-QueryValue -Request $Request -Name 'includeClosed' -Default 'false') -ne 'false'
        $query = 'SELECT * FROM mon.vw_TicketDetails WHERE 1=1'
        $params = @{}
        if ($severity) { $query += " AND TicketSeverity = @Severity"; $params.Severity = $severity }
        if ($status) { $query += " AND TicketStatus = @Status"; $params.Status = $status }
        if ($assignedTo) { $query += " AND AssignedTo = @AssignedTo"; $params.AssignedTo = $assignedTo }
        if (-not $includeClosed) { $query += " AND TicketStatusID NOT IN (4, 5)" }
        $query += " ORDER BY CreatedDate DESC;"
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters $params) }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tickets/closure-insights') {
        $days = [Math]::Min(365, [Math]::Max(7, (Get-IntQueryValue -Request $Request -Name 'days' -Default 30)))
        $topClosers = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
WITH closedTickets AS (
    SELECT
        td.TicketID,
        td.TicketNumber,
        td.AlertTitle,
        td.InstanceName,
        td.TicketSeverity,
        td.Category,
        td.Subcategory,
        td.CloseCode,
        td.ResolvedBy,
        td.ResolvedDate,
        td.ResolutionNotes,
        td.ResolutionMinutes,
        td.CreatedDate
    FROM mon.vw_TicketDetails td
    WHERE td.TicketStatus IN ('Resolved', 'Closed')
      AND td.ResolvedDate >= DATEADD(DAY, -@Days, SYSDATETIME())
      AND NULLIF(td.ResolvedBy, '') IS NOT NULL
),
evidence AS (
    SELECT
        ct.*,
        comments.CommentCount,
        comments.LastCommentAt,
        comments.LastCommentBy,
        comments.LastComment,
        updates.UpdateCount,
        updates.LastUpdateAt,
        CASE WHEN NULLIF(ct.ResolutionNotes, '') IS NOT NULL THEN 1 ELSE 0 END AS HasResolutionNotes,
        CASE WHEN NULLIF(ct.CloseCode, '') IS NOT NULL THEN 1 ELSE 0 END AS HasCloseCode,
        CASE WHEN ISNULL(comments.CommentCount, 0) > 0 THEN 1 ELSE 0 END AS HasComments,
        CASE WHEN ISNULL(updates.UpdateCount, 0) > 0 THEN 1 ELSE 0 END AS HasUpdates,
        CASE WHEN ct.ResolutionMinutes IS NOT NULL AND ct.ResolutionMinutes <= 240 THEN 1 ELSE 0 END AS FastClose
    FROM closedTickets ct
    OUTER APPLY (
        SELECT
            COUNT(*) AS CommentCount,
            MAX(c.CreatedDate) AS LastCommentAt,
            MAX(c.CreatedBy) AS LastCommentBy,
            MAX(CAST(LEFT(c.CommentText, 500) AS NVARCHAR(500))) AS LastComment
        FROM mon.TicketComments c
        WHERE c.TicketID = ct.TicketID
          AND ISNULL(c.IsActive, 1) = 1
    ) comments
    OUTER APPLY (
        SELECT
            COUNT(*) AS UpdateCount,
            MAX(a.CreatedDate) AS LastUpdateAt
        FROM mon.vw_TicketAuditTrail a
        WHERE a.ActionName IN ('UpdateTicket', 'ResolveTicket', 'AcknowledgeTicket')
          AND (a.TicketID = ct.TicketID OR a.Details LIKE CONCAT('%TicketID ', ct.TicketID, '%'))
    ) updates
)
SELECT TOP 10
    ResolvedBy AS UserName,
    COUNT(*) AS ClosedTickets,
    SUM(CASE WHEN TicketSeverity IN ('Critical', 'High') THEN 1 ELSE 0 END) AS HighImpactClosed,
    SUM(HasResolutionNotes) AS ResolutionNotesCount,
    SUM(HasCloseCode) AS CloseCodeCount,
    SUM(HasComments) AS CommentedClosures,
    SUM(HasUpdates) AS UpdatedClosures,
    CAST(AVG(CAST(ISNULL(ResolutionMinutes, 0) AS FLOAT)) AS DECIMAL(18,1)) AS AvgResolutionMinutes,
    CAST(AVG(CAST((HasResolutionNotes + HasCloseCode + HasComments + HasUpdates + FastClose) * 20 AS FLOAT)) AS DECIMAL(18,1)) AS SmartCloseScore,
    MAX(ResolvedDate) AS LastClosureAt
FROM evidence
GROUP BY ResolvedBy
ORDER BY ClosedTickets DESC, SmartCloseScore DESC, HighImpactClosed DESC, LastClosureAt DESC;
"@ -Parameters @{ Days = $days })
        $recentClosures = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 20
    td.TicketID,
    td.TicketNumber,
    td.AlertTitle,
    td.InstanceName,
    td.TicketSeverity,
    td.Category,
    td.Subcategory,
    td.CloseCode,
    td.ResolvedBy,
    td.ResolvedDate,
    td.ResolutionMinutes,
    CAST(LEFT(COALESCE(NULLIF(td.ResolutionNotes, ''), comments.LastComment, td.ErrorDescription, ''), 600) AS NVARCHAR(600)) AS ClosureSummary,
    comments.CommentCount,
    comments.LastCommentAt,
    comments.LastCommentBy,
    updates.UpdateCount,
    updates.LastUpdateAt
FROM mon.vw_TicketDetails td
OUTER APPLY (
    SELECT
        COUNT(*) AS CommentCount,
        MAX(c.CreatedDate) AS LastCommentAt,
        MAX(c.CreatedBy) AS LastCommentBy,
        MAX(CAST(LEFT(c.CommentText, 600) AS NVARCHAR(600))) AS LastComment
    FROM mon.TicketComments c
    WHERE c.TicketID = td.TicketID
      AND ISNULL(c.IsActive, 1) = 1
) comments
OUTER APPLY (
    SELECT
        COUNT(*) AS UpdateCount,
        MAX(a.CreatedDate) AS LastUpdateAt
    FROM mon.vw_TicketAuditTrail a
    WHERE a.ActionName IN ('UpdateTicket', 'ResolveTicket', 'AcknowledgeTicket')
      AND (a.TicketID = td.TicketID OR a.Details LIKE CONCAT('%TicketID ', td.TicketID, '%'))
) updates
WHERE td.TicketStatus IN ('Resolved', 'Closed')
  AND td.ResolvedDate >= DATEADD(DAY, -@Days, SYSDATETIME())
ORDER BY td.ResolvedDate DESC, td.TicketID DESC;
"@ -Parameters @{ Days = $days })
        return @{ days = $days; topClosers = $topClosers; recentClosures = $recentClosures }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tickets/create-from-alert') {
        $body = Read-RequestJson -Request $Request
        $alertId = [int64]$body.AlertID
        if ($alertId -le 0) { throw 'AlertID is required.' }
        $severity = if ([string]::IsNullOrWhiteSpace([string]$body.Severity)) { 'Medium' } else { [string]$body.Severity }
        $assignedTo = if ([string]::IsNullOrWhiteSpace([string]$body.AssignedTo)) { $null } else { [string]$body.AssignedTo }
        $result = Invoke-RepoQuery -Query 'EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;' -Parameters @{
            AlertID = $alertId
            CreatedBy = [string]$currentUser.UserName
            TicketSeverityID = $(switch($severity) { 'Critical' {1}; 'High' {2}; 'Medium' {3}; 'Low' {4}; default {3} })
            AssignedTo = $assignedTo
        }
        $ticket = @(ConvertTo-PlainRows $result | Select-Object -First 1)
        $existing = if ($ticket.Count -gt 0) { [bool]$ticket[0].IsExistingTicket } else { $false }
        Write-DashboardAudit -User $currentUser -ActionName 'CreateTicketFromAlert' -Details "AlertID $alertId"
        return @{
            ok = $true
            ticket = @($ticket | Select-Object -First 1)
            message = if ($existing) { 'An active ticket already exists for this alert condition.' } else { 'Ticket created.' }
        }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tickets/acknowledge') {
        $body = Read-RequestJson -Request $Request
        $ticketId = [int64]$body.TicketID
        if ($ticketId -le 0) { throw 'TicketID is required.' }
        Invoke-RepoNonQuery -Query 'EXEC mon.usp_AcknowledgeTicket @TicketID, @AcknowledgedBy;' -Parameters @{
            TicketID = $ticketId
            AcknowledgedBy = [string]$currentUser.UserName
        }
        Write-DashboardAudit -User $currentUser -ActionName 'AcknowledgeTicket' -Details "TicketID $ticketId"
        return @{ ok = $true }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tickets/update') {
        $body = Read-RequestJson -Request $Request
        $ticketId = [int64]$body.TicketID
        if ($ticketId -le 0) { throw 'TicketID is required.' }
        $statusId = if ([string]::IsNullOrWhiteSpace([string]$body.Status)) { $null } else { switch ([string]$body.Status) { 'New' {1}; 'Acknowledged' {2}; 'In Progress' {3}; 'Resolved' {4}; 'Closed' {5}; 'Reopened' {6}; default {$null} } }
        $severityId = if ([string]::IsNullOrWhiteSpace([string]$body.Severity)) { $null } else { switch ([string]$body.Severity) { 'Critical' {1}; 'High' {2}; 'Medium' {3}; 'Low' {4}; default {$null} } }
        $slaDueDate = if ([string]::IsNullOrWhiteSpace([string]$body.SLADueDate)) { $null } else { try { [datetime]$body.SLADueDate } catch { $null } }
        Invoke-RepoNonQuery -Query @"
UPDATE mon.Tickets
SET AssignedTo = @AssignedTo,
    TicketStatusID = ISNULL(@TicketStatusID, TicketStatusID),
    TicketSeverityID = ISNULL(@TicketSeverityID, TicketSeverityID),
    BusinessService = @BusinessService,
    Category = @Category,
    Subcategory = @Subcategory,
    Impact = @Impact,
    Urgency = @Urgency,
    AssignmentGroup = @AssignmentGroup,
    ContactType = @ContactType,
    ExternalReference = @ExternalReference,
    SLADueDate = @SLADueDate,
    CloseCode = @CloseCode,
    WorkNotes = @WorkNotes,
    ModifiedDate = SYSDATETIME()
WHERE TicketID = @TicketID;
"@ -Parameters @{
            TicketID = $ticketId
            AssignedTo = if ([string]::IsNullOrWhiteSpace([string]$body.AssignedTo)) { $null } else { [string]$body.AssignedTo }
            TicketStatusID = $statusId
            TicketSeverityID = $severityId
            BusinessService = if ([string]::IsNullOrWhiteSpace([string]$body.BusinessService)) { $null } else { [string]$body.BusinessService }
            Category = if ([string]::IsNullOrWhiteSpace([string]$body.Category)) { $null } else { [string]$body.Category }
            Subcategory = if ([string]::IsNullOrWhiteSpace([string]$body.Subcategory)) { $null } else { [string]$body.Subcategory }
            Impact = if ([string]::IsNullOrWhiteSpace([string]$body.Impact)) { $null } else { [string]$body.Impact }
            Urgency = if ([string]::IsNullOrWhiteSpace([string]$body.Urgency)) { $null } else { [string]$body.Urgency }
            AssignmentGroup = if ([string]::IsNullOrWhiteSpace([string]$body.AssignmentGroup)) { $null } else { [string]$body.AssignmentGroup }
            ContactType = if ([string]::IsNullOrWhiteSpace([string]$body.ContactType)) { $null } else { [string]$body.ContactType }
            CloseCode = if ([string]::IsNullOrWhiteSpace([string]$body.CloseCode)) { $null } else { [string]$body.CloseCode }
            ExternalReference = if ([string]::IsNullOrWhiteSpace([string]$body.ExternalReference)) { $null } else { [string]$body.ExternalReference }
            SLADueDate = $slaDueDate
            WorkNotes = if ([string]::IsNullOrWhiteSpace([string]$body.WorkNotes)) { $null } else { [string]$body.WorkNotes }
        }
        Write-DashboardAudit -User $currentUser -ActionName 'UpdateTicket' -Details "TicketID $ticketId"
        return @{ ok = $true }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tickets/resolve') {
        $body = Read-RequestJson -Request $Request
        $ticketId = [int64]$body.TicketID
        if ($ticketId -le 0) { throw 'TicketID is required.' }
        $resolutionNotes = [string]$body.ResolutionNotes
        if ([string]::IsNullOrWhiteSpace($resolutionNotes)) { throw 'Resolution notes are required.' }
        $resolveResult = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
DECLARE @InstanceID INT, @ModuleName NVARCHAR(100), @AlertTitle NVARCHAR(300);

SELECT
    @InstanceID = ah.InstanceID,
    @ModuleName = ah.ModuleName,
    @AlertTitle = ah.AlertTitle
FROM mon.Tickets t
LEFT JOIN mon.AlertHistory ah ON t.AlertID = ah.AlertID
WHERE t.TicketID = @TicketID;

UPDATE mon.Tickets
SET TicketStatusID = 4,
    ResolvedBy = @ResolvedBy,
    ResolvedDate = SYSDATETIME(),
    ResolutionNotes = @ResolutionNotes,
    ModifiedDate = SYSDATETIME()
WHERE TicketID = @TicketID;

DECLARE @TicketsResolved INT = @@ROWCOUNT;
DECLARE @AlertsClosed INT = 0;

IF @TicketsResolved > 0 AND OBJECT_ID('mon.TicketComments', 'U') IS NOT NULL
BEGIN
    INSERT INTO mon.TicketComments (TicketID, CommentText, CreatedBy)
    VALUES (@TicketID, CONCAT(N'Resolution: ', @ResolutionNotes), @ResolvedBy);
END;

IF @TicketsResolved > 0 AND @InstanceID IS NOT NULL
BEGIN
    UPDATE ah
    SET IsAcknowledged = 1,
        AcknowledgedOn = SYSDATETIME(),
        AcknowledgedBy = @ResolvedBy
    FROM mon.AlertHistory ah
    WHERE ISNULL(ah.IsAcknowledged, 0) = 0
      AND ah.InstanceID = @InstanceID
      AND ah.ModuleName = @ModuleName
      AND ah.AlertTitle = @AlertTitle;

    SET @AlertsClosed = @@ROWCOUNT;
END;

SELECT @TicketsResolved AS TicketsResolved,
       @AlertsClosed AS AlertsClosed;
"@ -Parameters @{
            TicketID = $ticketId
            ResolvedBy = [string]$currentUser.UserName
            ResolutionNotes = $resolutionNotes
        })
        $closedCount = if ($resolveResult.Count -gt 0) { [int]$resolveResult[0].AlertsClosed } else { 0 }
        Write-DashboardAudit -User $currentUser -ActionName 'ResolveTicket' -Details "TicketID $ticketId; closed $closedCount linked alert row(s)"
        return @{ ok = $true; alertsClosed = $closedCount; message = if ($closedCount -gt 0) { "Ticket resolved and linked alert condition closed." } else { "Ticket resolved." } }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tickets/unacknowledged') {
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT * FROM mon.vw_UnacknowledgedTickets ORDER BY CreatedDate DESC;') }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tickets/pending-escalation') {
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT * FROM mon.vw_TicketsPendingEscalation ORDER BY CreatedDate DESC;') }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tickets/audit') {
        $ticketId = Get-IntQueryValue -Request $Request -Name 'ticketId'
        $limit = [Math]::Min(500, [Math]::Max(25, (Get-IntQueryValue -Request $Request -Name 'limit' -Default 200)))
        $pattern = if ($ticketId -gt 0) { "%TicketID $ticketId%" } else { '%' }
        $query = @"
SELECT TOP (@Limit)
    AuditID,
    TicketID,
    CreatedDate,
    UserName,
    ActionName,
    Details,
    ClientHost,
    AuditSource
FROM mon.vw_TicketAuditTrail
WHERE (@TicketID <= 0 OR TicketID = @TicketID OR Details LIKE @Pattern)
ORDER BY CreatedDate DESC, AuditID DESC;
"@
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters @{ Limit = $limit; TicketID = $ticketId; Pattern = $pattern }) }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tickets/auto-convert') {
        [void](Require-AdminUser -Request $Request -ActionName 'Auto-converting alerts to tickets')
        $body = Read-RequestJson -Request $Request
        $hoursBack = if ($body.HoursBack) { [int]$body.HoursBack } else { 24 }
        $params = @{
            HoursBack = $hoursBack
            CreatedBy = [string]$currentUser.UserName
        }
        $result = Invoke-RepoQuery -Query 'DECLARE @TicketsCreated INT; EXEC mon.usp_AutoConvertAlertsToTickets @HoursBack = @HoursBack, @CreatedBy = @CreatedBy, @TicketsCreated = @TicketsCreated OUTPUT; SELECT @TicketsCreated AS TicketsCreated;' -Parameters $params
        $ticketsCreated = 0
        if ($result -and $result.Rows.Count -gt 0) {
            $ticketsCreated = [int]($result.Rows[0].TicketsCreated)
        }
        Write-DashboardAudit -User $currentUser -ActionName 'AutoConvertAlertsToTickets' -Details "Created $ticketsCreated ticket(s) from alerts"
        return @{ ok = $true; ticketsCreated = $ticketsCreated; message = "Created $ticketsCreated ticket(s) from alerts." }
    }
    # ----- TASK MANAGEMENT API ENDPOINTS -----
    if ($method -eq 'GET' -and $path -eq '/api/tasks/users') {
        $query = 'SELECT UserName, DisplayName, RoleName, Department, EmailAddress FROM mon.DashboardUsers WHERE IsActive = 1 ORDER BY DisplayName, UserName;'
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query) }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tasks') {
        $assignedTo = Get-QueryValue -Request $Request -Name 'assignedTo' -Default ''
        $status = Get-QueryValue -Request $Request -Name 'status' -Default ''
        $priority = Get-QueryValue -Request $Request -Name 'priority' -Default ''
        $includeCompleted = (Get-QueryValue -Request $Request -Name 'includeCompleted' -Default 'false') -ne 'false'
        $query = 'EXEC mon.usp_GetTasks @AssignedTo, @CreatedBy, @TaskStatusID, @TaskPriorityID, @InstanceID, @IncludeCompleted'
        $params = @{
            AssignedTo = if ($assignedTo) { $assignedTo } else { $null }
            CreatedBy = $null
            TaskStatusID = if ($status) { $(switch($status) { 'Open' {1}; 'In Progress' {2}; 'Pending' {3}; 'Completed' {4}; 'Cancelled' {5}; 'On Hold' {6}; default {$null} }) } else { $null }
            TaskPriorityID = if ($priority) { $(switch($priority) { 'Critical' {1}; 'High' {2}; 'Medium' {3}; 'Low' {4}; default {3} }) } else { $null }
            InstanceID = $null
            IncludeCompleted = if ($includeCompleted) { 1 } else { 0 }
        }
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters $params) }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tasks/create') {
        $body = Read-RequestJson -Request $Request
        $title = ([string]$body.Title).Trim()
        if ([string]::IsNullOrWhiteSpace($title)) { throw 'Task title is required.' }
        $result = Invoke-RepoQuery -Query 'EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;' -Parameters @{
            TaskTitle = $title
            TaskDescription = [string]$body.Description
            CreatedBy = [string]$currentUser.UserName
            AssignedTo = if ([string]::IsNullOrWhiteSpace([string]$body.AssignedTo)) { $null } else { [string]$body.AssignedTo }
            TaskPriorityID = $(switch([string]$body.Priority) { 'Critical' {1}; 'High' {2}; 'Medium' {3}; 'Low' {4}; default {3} })
            InstanceID = if ($body.InstanceID) { [int]$body.InstanceID } else { $null }
            DueDate = if ($body.DueDate) { [datetime]$body.DueDate } else { $null }
        }
        $createdTask = @(ConvertTo-PlainRows $result | Select-Object -First 1)
        Write-DashboardAudit -User $currentUser -ActionName 'CreateTask' -Details $title
        return @{ ok = $true; taskId = [int]$createdTask.TaskID }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tasks/update') {
        $body = Read-RequestJson -Request $Request
        $taskId = [int]$body.TaskID
        if ($taskId -le 0) { throw 'TaskID is required.' }

        # Compute derived values before building the parameter hashtable
        $taskStatusId = if ($body.Status) {
            switch ([string]$body.Status) {
                'Open' { 1 }
                'In Progress' { 2 }
                'Pending' { 3 }
                'Completed' { 4 }
                'Cancelled' { 5 }
                'On Hold' { 6 }
                default { $null }
            }
        } else { $null }

        $taskPriorityId = if ($body.Priority) {
            switch ([string]$body.Priority) {
                'Critical' { 1 }
                'High' { 2 }
                'Medium' { 3 }
                'Low' { 4 }
                default { $null }
            }
        } else { $null }

        $dueDate = if ($body.DueDate) {
            try { [DateTime]::Parse([string]$body.DueDate).ToString('yyyy-MM-dd') } catch { $null }
        } else { $null }

        Invoke-RepoNonQuery -Query 'EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;' -Parameters @{
            TaskID = $taskId
            TaskTitle = if ([string]::IsNullOrWhiteSpace([string]$body.Title)) { $null } else { [string]$body.Title }
            TaskDescription = if ([string]::IsNullOrWhiteSpace([string]$body.Description)) { $null } else { [string]$body.Description }
            AssignedTo = if ([string]::IsNullOrWhiteSpace([string]$body.AssignedTo)) { $null } else { [string]$body.AssignedTo }
            TaskStatusID = $taskStatusId
            TaskPriorityID = $taskPriorityId
            DueDate = $dueDate
            ModifiedBy = [string]$currentUser.UserName
        }
        Write-DashboardAudit -User $currentUser -ActionName 'UpdateTask' -Details "Task $taskId"
        return @{ ok = $true }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tasks/comments') {
        $taskId = Get-IntQueryValue -Request $Request -Name 'taskId'
        if ($taskId -le 0) { throw 'TaskID is required.' }
        $query = 'SELECT * FROM mon.vw_TaskComments WHERE TaskID = @TaskID ORDER BY CreatedDate;'
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters @{ TaskID = $taskId }) }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tasks/activities') {
        $taskId = Get-IntQueryValue -Request $Request -Name 'taskId'
        if ($taskId -le 0) { throw 'TaskID is required.' }
        $query = 'SELECT ActivityID, TaskID, ActivityType, ActivityDescription, CreatedBy, CreatedDate FROM mon.TaskActivities WHERE TaskID = @TaskID ORDER BY CreatedDate DESC, ActivityID DESC;'
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters @{ TaskID = $taskId }) }
    }
    if ($method -eq 'GET' -and $path -eq '/api/tasks/audit') {
        $taskId = Get-IntQueryValue -Request $Request -Name 'taskId'
        $limit = [Math]::Min(500, [Math]::Max(25, (Get-IntQueryValue -Request $Request -Name 'limit' -Default 200)))
        $pattern = if ($taskId -gt 0) { "%Task $taskId%" } else { '%' }
        $query = @"
SELECT TOP (@Limit)
    auditRows.AuditID,
    auditRows.TaskID,
    auditRows.TaskTitle,
    auditRows.CreatedDate,
    auditRows.UserName,
    auditRows.ActionName,
    auditRows.Details,
    auditRows.ClientHost,
    auditRows.AuditSource
FROM (
    SELECT
        AuditID,
        TaskID,
        TaskTitle,
        CreatedDate,
        UserName,
        ActionName,
        Details,
        CAST(NULL AS NVARCHAR(128)) AS ClientHost,
        AuditSource
    FROM mon.vw_TaskAuditTrail
    WHERE @TaskID <= 0 OR TaskID = @TaskID

    UNION ALL

    SELECT
        AuditID,
        CAST(NULL AS INT) AS TaskID,
        CAST(NULL AS NVARCHAR(255)) AS TaskTitle,
        CreatedAt AS CreatedDate,
        UserName,
        ActionName,
        Details,
        ClientHost,
        CAST(N'DashboardAudit' AS NVARCHAR(40)) AS AuditSource
    FROM mon.DashboardAuditLog
    WHERE ActionName LIKE N'%Task%'
      AND (@TaskID <= 0 OR Details LIKE @Pattern)
) auditRows
ORDER BY auditRows.CreatedDate DESC, auditRows.AuditID DESC;
"@
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters @{ Limit = $limit; TaskID = $taskId; Pattern = $pattern }) }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tasks/comment') {
        $body = Read-RequestJson -Request $Request
        $taskId = [int]$body.TaskID
        $commentText = ([string]$body.CommentText).Trim()
        if ($taskId -le 0) { throw 'TaskID is required.' }
        if ([string]::IsNullOrWhiteSpace($commentText)) { throw 'Comment text is required.' }
        Invoke-RepoNonQuery -Query 'EXEC mon.usp_AddTaskComment @TaskID = @TaskID, @CommentText = @CommentText, @CreatedBy = @CreatedBy;' -Parameters @{
            TaskID = $taskId
            CommentText = $commentText
            CreatedBy = [string]$currentUser.UserName
        }
        Write-DashboardAudit -User $currentUser -ActionName 'AddTaskComment' -Details "Task $taskId"
        return @{ ok = $true }
    }
    if ($method -eq 'POST' -and $path -eq '/api/tasks/comment/update') {
        $body = Read-RequestJson -Request $Request
        $commentId = [int]$body.CommentID
        $commentText = ([string]$body.CommentText).Trim()
        if ($commentId -le 0) { throw 'CommentID is required.' }
        if ([string]::IsNullOrWhiteSpace($commentText)) { throw 'Comment text is required.' }
        Invoke-RepoNonQuery -Query @"
DECLARE @TaskID INT;
SELECT @TaskID = TaskID FROM mon.TaskComments WHERE CommentID = @CommentID;

UPDATE mon.TaskComments
SET CommentText = @CommentText,
    ModifiedBy = @ModifiedBy,
    ModifiedDate = SYSDATETIME(),
    IsEdited = 1
WHERE CommentID = @CommentID
  AND IsActive = 1;

IF @@ROWCOUNT > 0 AND @TaskID IS NOT NULL
BEGIN
    INSERT INTO mon.TaskActivities (TaskID, ActivityType, ActivityDescription, CreatedBy)
    VALUES (@TaskID, N'CommentEdited', N'Comment edited by ' + @ModifiedBy, @ModifiedBy);
END;
"@ -Parameters @{
            CommentID = $commentId
            CommentText = $commentText
            ModifiedBy = [string]$currentUser.UserName
        }
        Write-DashboardAudit -User $currentUser -ActionName 'UpdateTaskComment' -Details "Comment $commentId"
        return @{ ok = $true }
    }
    if ($method -eq 'GET' -and $path -eq '/api/escalation/rules') {
        $severity = Get-QueryValue -Request $Request -Name 'severity' -Default ''
        $activeFilter = Get-QueryValue -Request $Request -Name 'isActive' -Default 'true'
        $params = @{}
        $where = 'WHERE 1=1'
        if (-not [string]::IsNullOrWhiteSpace($severity) -and $severity -ne 'All') {
            $where += ' AND tsv.SeverityName = @SeverityName'
            $params.SeverityName = $severity
        }
        if ($activeFilter -ne 'all') {
            $where += ' AND em.IsActive = @IsActive'
            $params.IsActive = if ($activeFilter -eq 'false') { 0 } else { 1 }
        }
        $query = @"
SELECT
    em.EscalationMatrixID,
    tsv.SeverityName,
    el.LevelName,
    em.EscalationTimeMinutes,
    em.EscalationTo,
    em.NotificationTemplate,
    em.IsActive
FROM mon.EscalationMatrix em
INNER JOIN mon.TicketSeverity tsv ON em.TicketSeverityID = tsv.TicketSeverityID
INNER JOIN mon.EscalationLevels el ON em.EscalationLevelID = el.EscalationLevelID
$where
ORDER BY tsv.SeverityOrder, el.LevelOrder;
"@
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters $params) }
    }
    if ($method -eq 'GET' -and $path -eq '/api/escalation/history') {
        $ticketId = Get-IntQueryValue -Request $Request -Name 'ticketId'
        $query = 'SELECT * FROM mon.vw_EscalationHistory'
        if ($ticketId -gt 0) { $query += " WHERE TicketID = @TicketID" }
        $query += " ORDER BY EscalatedOn DESC;"
        return @{ rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query $query -Parameters @{ TicketID = $ticketId }) }
    }
    if ($method -eq 'GET' -and $path -eq '/api/thresholds') { return @{ rows = Get-Thresholds } }
    if ($method -eq 'POST' -and $path -eq '/api/thresholds') { [void](Require-AdminUser -Request $Request -ActionName 'Saving thresholds'); $result = Save-Threshold -Body (Read-RequestJson -Request $Request); Write-DashboardAudit -User $currentUser -ActionName 'SaveThreshold' -Details 'Threshold configuration changed'; return $result }
    if ($method -eq 'GET' -and $path -eq '/api/notifications') { return Get-NotificationsConfig }
    if ($method -eq 'POST' -and $path -eq '/api/notifications') { [void](Require-AdminUser -Request $Request -ActionName 'Saving notifications'); $result = Save-NotificationsConfig -Config (Read-RequestJson -Request $Request); Write-DashboardAudit -User $currentUser -ActionName 'SaveNotifications' -Details 'Notification configuration changed'; return $result }
    if ($method -eq 'POST' -and $path -eq '/api/notifications/test-email') {
        [void](Require-AdminUser -Request $Request -ActionName 'Testing email notifications')
        $config = Get-NotificationsConfig
        if (-not $config.Notifications.Enabled) { throw 'Email notifications are not enabled.' }
        if ([string]::IsNullOrWhiteSpace([string]$config.SMTP.Server)) { throw 'SMTP server is not configured.' }
        if ([string]::IsNullOrWhiteSpace([string]$config.Notifications.Recipients)) { throw 'Recipients are not configured.' }
        $testTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        Send-SqlMonitorEmail -SmtpConfig $config.SMTP -To $config.Notifications.Recipients -Cc $config.Notifications.CCRecipients -Subject "[SQL Monitor Test] Web Dashboard Email - $testTime" -Body "<h2>SQL Monitor Web Dashboard Test</h2><p>Test time: $testTime</p>" -BodyAsHtml
        Write-DashboardAudit -User $currentUser -ActionName 'TestEmailNotification' -Details ([string]$config.Notifications.Recipients)
        return @{ ok = $true; message = "Test email sent to $($config.Notifications.Recipients)." }
    }
    if ($method -eq 'POST' -and $path -eq '/api/notifications/test-teams') {
        [void](Require-AdminUser -Request $Request -ActionName 'Testing Teams notifications')
        $config = Get-NotificationsConfig
        if (-not $config.Teams.Enabled) { throw 'Teams notifications are not enabled.' }
        $webhookUrl = [string]$config.Teams.WebhookURL
        if ([string]::IsNullOrWhiteSpace($webhookUrl) -or $webhookUrl -like '*YOUR-WEBHOOK-URL-HERE*') { throw 'Teams webhook URL is not configured.' }
        $body = @{
            '@type' = 'MessageCard'
            '@context' = 'http://schema.org/extensions'
            themeColor = '0078d4'
            summary = 'SQL Monitor Web Dashboard Test'
            sections = @(@{ activityTitle = 'SQL Monitor Web Dashboard Test'; text = "Webhook test sent at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" })
        } | ConvertTo-Json -Depth 5
        Invoke-RestMethod -Uri $webhookUrl -Method Post -Body $body -ContentType 'application/json' | Out-Null
        Write-DashboardAudit -User $currentUser -ActionName 'TestTeamsNotification' -Details 'Teams webhook test sent'
        return @{ ok = $true; message = 'Test Teams message sent.' }
    }
    if ($method -eq 'GET' -and $path -eq '/api/settings') { return Get-DashboardSettings }
    if ($method -eq 'POST' -and $path -eq '/api/settings') { [void](Require-AdminUser -Request $Request -ActionName 'Saving settings'); $result = Save-DashboardSettings -Settings (Read-RequestJson -Request $Request); Write-DashboardAudit -User $currentUser -ActionName 'SaveDashboardSettings' -Details 'Dashboard settings changed'; return $result }
    if ($method -eq 'POST' -and $path -eq '/api/repository/upgrade') {
        [void](Require-AdminUser -Request $Request -ActionName 'Upgrading repository')
        $body = Read-RequestJson -Request $Request
        $upgradeScript = Join-Path $projectRoot 'Upgrade-SQLMonitorRepository.ps1'
        if (-not (Test-Path $upgradeScript)) { throw "Repository upgrade script not found: $upgradeScript" }
        $args = @(
            '-NoProfile',
            '-ExecutionPolicy','Bypass',
            '-File',$upgradeScript,
            '-RepositoryServer',$script:RepositoryServer,
            '-RepositoryDatabase',$script:RepositoryDatabase,
            '-InstallPath',$projectRoot,
            '-WebDashboardPort',([string]$Port)
        )
        $updateSqlAgentJobs = $true
        if ($null -ne $body.PSObject.Properties['UpdateSqlAgentJobs']) { $updateSqlAgentJobs = [bool]$body.UpdateSqlAgentJobs }
        if ($updateSqlAgentJobs) { $args += '-UpdateSqlAgentJobs' }
        if ([bool]$body.ConfigurePerInstanceJobs) { $args += '-ConfigurePerInstanceJobs' }
        if ([bool]$body.ConfigureWindowsTasks) {
            $args += '-ConfigureWindowsTasks'
            $args += '-WindowsTaskRunAs'
            $args += 'System'
        }
        Write-DashboardAudit -User $currentUser -ActionName 'UpgradeRepository' -Details 'Repository upgrade requested from web dashboard'
        return Invoke-ProcessCapture -FilePath (Resolve-SqlMonitorPowerShellPath) -Arguments $args -WorkingDirectory $projectRoot
    }
    if ($method -eq 'POST' -and $path -eq '/api/application/apply-latest') {
        [void](Require-AdminUser -Request $Request -ActionName 'Applying latest SQL Monitor changes')
        $body = Read-RequestJson -Request $Request
        $sourcePath = if ([string]::IsNullOrWhiteSpace([string]$body.SourcePath)) { $projectRoot } else { [string]$body.SourcePath }
        $installPath = if ([string]::IsNullOrWhiteSpace([string]$body.InstallPath)) { $projectRoot } else { [string]$body.InstallPath }
        $applyScript = Join-Path $sourcePath 'Apply-LatestChanges.ps1'
        if (-not (Test-Path $applyScript -PathType Leaf)) {
            $applyScript = Join-Path $projectRoot 'Apply-LatestChanges.ps1'
        }
        if (-not (Test-Path $applyScript -PathType Leaf)) { throw "Apply latest changes script not found. Checked source path and current dashboard path." }
        $args = @(
            '-NoProfile',
            '-ExecutionPolicy','Bypass',
            '-File',$applyScript,
            '-RepositoryServer',$script:RepositoryServer,
            '-RepositoryDatabase',$script:RepositoryDatabase,
            '-SourcePath',$sourcePath,
            '-InstallPath',$installPath,
            '-WebDashboardPort',([string]$Port)
        )
        if ([bool]$body.UpdateSqlAgentJobs) { $args += '-UpdateSqlAgentJobs' }
        if ([bool]$body.ConfigurePerInstanceJobs) { $args += '-ConfigurePerInstanceJobs' }
        if ([bool]$body.ConfigureWindowsTasks) {
            $args += '-ConfigureWindowsTasks'
            $args += '-WindowsTaskRunAs'
            $args += 'System'
        }
        $workingDirectory = if (Test-Path -LiteralPath $sourcePath -PathType Container) { $sourcePath } else { $projectRoot }
        Write-DashboardAudit -User $currentUser -ActionName 'ApplyLatestChanges' -Details "Source=$sourcePath; Install=$installPath"
        return Invoke-ProcessCapture -FilePath (Resolve-SqlMonitorPowerShellPath) -Arguments $args -WorkingDirectory $workingDirectory
    }
    if ($method -eq 'POST' -and $path -eq '/api/deployment/run') {
        [void](Require-AdminUser -Request $Request -ActionName 'Running deployment center action')
        $body = Read-RequestJson -Request $Request
        $result = Invoke-DeploymentCenterRun -Body $body -Port $Port
        Write-DashboardAudit -User $currentUser -ActionName 'DeploymentCenterRun' -Details ((Get-BodyStringValue -Body $body -Name 'Action' -Default 'selected') + ' deployment action requested from web dashboard')
        return $result
    }
    if ($method -eq 'GET' -and $path -eq '/api/analytics') { $id = Get-IntQueryValue -Request $Request -Name 'instanceId'; Assert-UserCanAccessInstance -User $currentUser -InstanceID $id; return Get-Analytics -InstanceID $id -Range (Get-QueryValue -Request $Request -Name 'range' -Default 'Last 24 Hours') }
    if ($method -eq 'GET' -and $path -eq '/api/bi-insights') { return Get-BiInsights -User $currentUser -Range (Get-QueryValue -Request $Request -Name 'range' -Default 'Last 7 Days') }
    if ($method -eq 'GET' -and $path -eq '/api/bi-insights/catalog') { return Get-BiInsightsCatalog -User $currentUser }
    if ($method -eq 'GET' -and $path -eq '/api/bi-insights/management-report') { return Get-BiManagementReport -User $currentUser -Period (Get-QueryValue -Request $Request -Name 'period' -Default 'Weekly') }
    if ($method -eq 'GET' -and $path -eq '/api/bi-insights/module-visuals') { return @{ rows = Get-BiInsightModuleVisuals } }
    if ($method -eq 'POST' -and $path -eq '/api/bi-insights/ask') { return Invoke-BiInsightQuestion -Question ([string](Read-RequestJson -Request $Request).Question) -User $currentUser }
    if ($method -eq 'POST' -and $path -eq '/api/bi-insights/reports') { $result = Save-BiInsightReport -Body (Read-RequestJson -Request $Request) -User $currentUser; Write-DashboardAudit -User $currentUser -ActionName 'SaveBiInsightReport' -Details 'BI Insights report saved'; return $result }
    if ($method -eq 'POST' -and $path -eq '/api/bi-insights/module-visuals') { [void](Require-AdminUser -Request $Request -ActionName 'Managing BI module charts'); $result = Save-BiInsightModuleVisual -Body (Read-RequestJson -Request $Request) -User $currentUser; Write-DashboardAudit -User $currentUser -ActionName 'SaveBiModuleVisual' -Details 'BI module chart saved'; return $result }
    if ($method -eq 'DELETE' -and $path -eq '/api/bi-insights/reports') { $reportId = Get-IntQueryValue -Request $Request -Name 'reportId'; $result = Remove-BiInsightReport -ReportID $reportId -User $currentUser; Write-DashboardAudit -User $currentUser -ActionName 'DeleteBiInsightReport' -Details "ReportID $reportId"; return $result }
    if ($method -eq 'GET' -and $path -eq '/api/dictionary') { return @{ rows = Get-DictionaryItems } }
    if ($method -eq 'GET' -and $path -eq '/api/issues') {
        return @{ rows = @(Get-SopWikiItems) }
    }
    if ($method -eq 'POST' -and $path -eq '/api/issues') {
        $body = Read-RequestJson -Request $Request
        return Save-SopWikiItem -Body $body -User $currentUser
    }
    if ($method -eq 'DELETE' -and $path -eq '/api/issues') {
        [void](Require-AdminUser -Request $Request -ActionName 'Deleting wiki entries')
        return Remove-SopWikiItem -SopID (Get-IntQueryValue -Request $Request -Name 'sopId') -User $currentUser
    }
    if ($method -eq 'GET' -and $path -eq '/api/collector-nodes') { [void](Require-AdminUser -Request $Request -ActionName 'Viewing collector nodes'); return Get-CollectorNodesPayload }
    if ($method -eq 'POST' -and $path -eq '/api/collector-nodes/assignments') {
        [void](Require-AdminUser -Request $Request -ActionName 'Managing collector assignments')
        $result = Save-CollectorAssignment -Body (Read-RequestJson -Request $Request) -User $currentUser
        Write-DashboardAudit -User $currentUser -ActionName 'SaveCollectorAssignment' -Details 'Collector assignment saved'
        return $result
    }
    if ($method -eq 'POST' -and $path -eq '/api/central-sync/run') {
        [void](Require-AdminUser -Request $Request -ActionName 'Syncing central repository')
        $result = Invoke-CentralRepositorySync -Body (Read-RequestJson -Request $Request)
        Write-DashboardAudit -User $currentUser -ActionName 'RunCentralRepositorySync' -Details 'Central repository sync requested'
        return $result
    }
    if ($method -eq 'POST' -and $path -eq '/api/run-collectors') {
        [void](Require-AdminUser -Request $Request -ActionName 'Running collectors')
        $body = Read-RequestJson -Request $Request
        $displayName = [string]$body.DisplayName
        $collectorGroup = if ([string]::IsNullOrWhiteSpace([string]$body.CollectorGroup)) { 'All' } else { [string]$body.CollectorGroup }
        if ([string]::IsNullOrWhiteSpace($displayName)) { throw 'Select an instance before running collectors.' }
        Write-DashboardAudit -User $currentUser -ActionName 'RunCollectors' -Details "$displayName / $collectorGroup"
        return Invoke-ProcessCapture -FilePath (Resolve-SqlMonitorPowerShellPath) -Arguments @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $projectRoot 'Jobs\Run-Collectors-InstanceGroup.ps1'),'-CollectorGroup',$collectorGroup,'-InstanceFilter',$displayName) -WorkingDirectory $projectRoot
    }
    if ($method -eq 'POST' -and $path -eq '/api/run-alert-engine') {
        [void](Require-AdminUser -Request $Request -ActionName 'Running alert engine')
        Write-DashboardAudit -User $currentUser -ActionName 'RunAlertEngine' -Details 'Alert engine run requested'
        return Invoke-ProcessCapture -FilePath (Resolve-SqlMonitorPowerShellPath) -Arguments @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $projectRoot 'Jobs\Run-AlertEngine.ps1')) -WorkingDirectory $projectRoot
    }
    if ($method -eq 'POST' -and $path -eq '/api/instance-group/run') {
        [void](Require-AdminUser -Request $Request -ActionName 'Running instance group collectors')
        $body = Read-RequestJson -Request $Request
        $collectorGroup = if ([string]::IsNullOrWhiteSpace([string]$body.CollectorGroup)) { 'All' } else { [string]$body.CollectorGroup }
        $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $projectRoot 'Jobs\Run-Collectors-InstanceGroup.ps1'),'-CollectorGroup',$collectorGroup)
        if (-not [string]::IsNullOrWhiteSpace([string]$body.InstanceFilter)) { $args += @('-InstanceFilter',[string]$body.InstanceFilter) }
        Write-DashboardAudit -User $currentUser -ActionName 'RunInstanceGroupCollectors' -Details $collectorGroup
        return Invoke-ProcessCapture -FilePath (Resolve-SqlMonitorPowerShellPath) -Arguments $args -WorkingDirectory $projectRoot
    }
    if ($method -eq 'GET' -and $path -eq '/api/schedule') { return Get-ScheduleStatus -InstanceID (Get-IntQueryValue -Request $Request -Name 'instanceId') }
    if ($method -eq 'POST' -and $path -eq '/api/schedule') {
        [void](Require-AdminUser -Request $Request -ActionName 'Saving schedules')
        $body = Read-RequestJson -Request $Request
        $instanceId = [int]$body.InstanceID
        $displayName = [string]$body.DisplayName
        $scheduleType = [string]$body.ScheduleType
        $collectorGroup = if ([string]::IsNullOrWhiteSpace([string]$body.CollectorGroup)) { 'All' } else { [string]$body.CollectorGroup }
        $dailyAt = if ([string]::IsNullOrWhiteSpace([string]$body.DailyAt)) { '02:00' } else { [string]$body.DailyAt }
        if ($instanceId -le 0) { throw 'InstanceID is required.' }
        if ([string]::IsNullOrWhiteSpace($displayName)) { throw 'DisplayName is required.' }

        $taskName = Get-ScheduleTaskName -InstanceID $instanceId
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
        if ($scheduleType -eq 'Manual only') {
            Write-DashboardAudit -User $currentUser -ActionName 'SaveSchedule' -Details "$displayName / Manual only"
            return @{ ok = $true; schedule = Get-ScheduleStatus -InstanceID $instanceId }
        }

        $runFilePath = Join-Path $projectRoot 'Run-Collectors.bat'
        if (-not (Test-Path $runFilePath)) { throw "Run-Collectors.bat not found at $runFilePath" }
        $action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$runFilePath`" `"$displayName`" `"$collectorGroup`""
        $trigger = switch ($scheduleType) {
            'Every 5 minutes' { New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 365) }
            'Every 30 minutes' { New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 30) -RepetitionDuration (New-TimeSpan -Days 365) }
            'Daily at' { New-ScheduledTaskTrigger -Daily -At $dailyAt }
            default { throw "Unsupported schedule type: $scheduleType" }
        }
        $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2)
        Register-ScheduledTask -TaskName $taskName -InputObject (New-ScheduledTask -Action $action -Trigger $trigger -Settings $settings) -Force | Out-Null
        Write-DashboardAudit -User $currentUser -ActionName 'SaveSchedule' -Details "$displayName / $scheduleType / $collectorGroup"
        return @{ ok = $true; schedule = Get-ScheduleStatus -InstanceID $instanceId }
    }
    if ($method -eq 'DELETE' -and $path -eq '/api/schedule') {
        [void](Require-AdminUser -Request $Request -ActionName 'Removing schedules')
        $instanceId = Get-IntQueryValue -Request $Request -Name 'instanceId'
        Unregister-ScheduledTask -TaskName (Get-ScheduleTaskName -InstanceID $instanceId) -Confirm:$false -ErrorAction SilentlyContinue
        Write-DashboardAudit -User $currentUser -ActionName 'DeleteSchedule' -Details ("InstanceID {0}" -f $instanceId)
        return @{ ok = $true; schedule = Get-ScheduleStatus -InstanceID $instanceId }
    }
    if ($method -eq 'POST' -and $path -eq '/api/web-agent/search') {
        $body = Read-RequestJson -Request $Request
        $queryText = ([string]$body.Query).Trim()
        if ([string]::IsNullOrWhiteSpace($queryText)) {
            throw 'Enter an error message or click Load Current Errors first.'
        }
        $instance = @(Get-ConfiguredInstances | Where-Object { $_.DisplayName -eq [string]$body.DisplayName -or $_.SqlInstance -eq [string]$body.DisplayName } | Select-Object -First 1)
        $results = @(Invoke-WebSolutionsAgent -ErrorMessage $queryText -Instance ($instance | Select-Object -First 1) -MaxResults 10)
        return @{ rows = $results }
    }
    if ($method -eq 'GET' -and $path -eq '/api/web-agent/recent') {
        $displayName = Get-QueryValue -Request $Request -Name 'displayName'
        $repoInstances = Get-RepositoryInstances
        $instanceId = ($repoInstances | Where-Object { $_.DisplayName -eq $displayName } | Select-Object -First 1).InstanceID
        if (-not $instanceId) { throw 'Selected instance is not registered in the repository.' }
        $rows = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 25 AlertID, DisplayName, AlertTime, Severity, ModuleName, AlertTitle, AlertDetails, IsAcknowledged, DATEDIFF(MINUTE, AlertTime, GETDATE()) AS AgeMinutes FROM mon.vw_AlertHistoryDetailed WHERE InstanceID = @InstanceID ORDER BY AlertTime DESC;' -Parameters @{ InstanceID = [int]$instanceId })
        return @{ rows = $rows }
    }
    if ($method -eq 'POST' -and $path -eq '/api/web-agent/diagnose') {
        $body = Read-RequestJson -Request $Request
        $displayName = [string]$body.DisplayName
        $maxAlerts = if ($body.MaxAlerts) { [Math]::Min(5, [Math]::Max(1, [int]$body.MaxAlerts)) } else { 3 }
        $maxResults = if ($body.MaxResultsPerAlert) { [Math]::Min(5, [Math]::Max(1, [int]$body.MaxResultsPerAlert)) } else { 3 }
        $repoInstances = Get-RepositoryInstances
        $repoInstance = $repoInstances | Where-Object { $_.DisplayName -eq $displayName } | Select-Object -First 1
        if (-not $repoInstance) { throw 'Selected instance is not registered in the repository.' }
        $configuredInstance = Get-ConfiguredInstances | Where-Object { $_.DisplayName -eq $displayName -or $_.SqlInstance -eq $displayName } | Select-Object -First 1
        $alerts = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP (@Limit) AlertID, DisplayName, AlertTime, Severity, ModuleName, AlertTitle, AlertDetails, IsAcknowledged, DATEDIFF(MINUTE, AlertTime, GETDATE()) AS AgeMinutes FROM mon.vw_AlertHistoryDetailed WHERE InstanceID = @InstanceID AND ISNULL(IsAcknowledged, 0) = 0 ORDER BY CASE WHEN Severity = ''Critical'' THEN 0 WHEN Severity = ''High'' THEN 1 WHEN Severity = ''Warning'' THEN 2 ELSE 3 END, AlertTime DESC;' -Parameters @{ InstanceID = [int]$repoInstance.InstanceID; Limit = $maxAlerts } -Timeout 30)
        if (@($alerts).Count -eq 0) {
            $alerts = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP (@Limit) AlertID, DisplayName, AlertTime, Severity, ModuleName, AlertTitle, AlertDetails, IsAcknowledged, DATEDIFF(MINUTE, AlertTime, GETDATE()) AS AgeMinutes FROM mon.vw_AlertHistoryDetailed WHERE InstanceID = @InstanceID ORDER BY AlertTime DESC;' -Parameters @{ InstanceID = [int]$repoInstance.InstanceID; Limit = $maxAlerts } -Timeout 30)
        }
        $findings = @()
        foreach ($alert in @($alerts)) {
            $queryText = @($alert.AlertTitle, $alert.AlertDetails) -join "`n`n"
            $solutions = @()
            if (-not [string]::IsNullOrWhiteSpace($queryText)) {
                try {
                    $solutions = @(Invoke-WebSolutionsAgent -ErrorMessage $queryText -AlertTitle ([string]$alert.AlertTitle) -Instance $configuredInstance -MaxResults $maxResults)
                }
                catch {
                    $solutions = @([pscustomobject]@{
                        Source = 'Agent'
                        Title = 'Solution lookup failed'
                        Type = 'Diagnostic'
                        Relevance = 'Unavailable'
                        Confidence = 0
                        Summary = $_.Exception.Message
                        RecommendedActionsText = 'Check web connectivity from the dashboard host, then retry the diagnosis.'
                    })
                }
            }
            $findings += [pscustomobject]@{
                AlertID = $alert.AlertID
                DisplayName = $alert.DisplayName
                AlertTime = $alert.AlertTime
                Severity = $alert.Severity
                ModuleName = $alert.ModuleName
                AlertTitle = $alert.AlertTitle
                AlertDetails = $alert.AlertDetails
                AgeMinutes = $alert.AgeMinutes
                Solutions = @($solutions)
            }
        }
        return @{ findings = $findings; analyzedAlerts = @($findings).Count; displayName = $displayName }
    }
    # Query Analyzer Assistant
    if ($method -eq 'POST' -and $path -eq '/api/assistant/query-analyze') {
        $body = Read-RequestJson -Request $Request
        $sqlText = ([string]$body.SqlText).Trim()
        if ([string]::IsNullOrWhiteSpace($sqlText)) { throw 'Enter a SQL query to analyze.' }
        $displayName = [string]$body.DisplayName
        $analysis = [ordered]@{}
        $analysis.QueryText = $sqlText
        $analysis.EstimatedCost = $null
        $analysis.Recommendations = @()
        $analysis.MissingIndexes = @()
        $analysis.TopQueries = @()
        # Check for common anti-patterns
        $upperSql = $sqlText.ToUpper()
        if ($upperSql -match 'SELECT\s+\*\s+FROM') { $analysis.Recommendations += 'Avoid SELECT * - specify only needed columns to reduce I/O and memory.' }
        if ($upperSql -match 'WHERE\s+.*\(\s*SELECT') { $analysis.Recommendations += 'Correlated subquery detected - consider rewriting as a JOIN for better performance.' }
        if ($upperSql -match 'NOT\s+IN\s*\(\s*SELECT') { $analysis.Recommendations += 'NOT IN with subquery can be slow - consider NOT EXISTS or LEFT JOIN/IS NULL.' }
        if ($upperSql -match 'CURSOR|FETCH\s+NEXT\s+FROM') { $analysis.Recommendations += 'Cursor detected - consider set-based operations instead of row-by-row processing.' }
        if ($upperSql -match 'NOLOCK|READ\s+UNCOMMITTED') { $analysis.Recommendations += 'NOLOCK hint detected - can cause dirty reads. Use READ COMMITTED SNAPSHOT isolation instead.' }
        if ($upperSql -match 'CONVERT\s*\(\s*DATETIME|GETDATE\s*\(\s*\)\s*BETWEEN') { $analysis.Recommendations += 'Non-SARGable date filter detected - avoid wrapping columns in functions for index usage.' }
        if ($upperSql -match 'OR\s+') { $analysis.Recommendations += 'OR conditions can prevent index usage - consider UNION ALL or indexed computed columns.' }
        if ($upperSql -match 'ORDER\s+BY\s+NEWID\s*\(\s*\)') { $analysis.Recommendations += 'ORDER BY NEWID() is expensive for large tables - consider TABLESAMPLE or alternative pagination.' }
        if ($upperSql -match 'EXEC\s*\(\s*@|EXECUTE\s*\(\s*@|SP_EXECUTESQL\s+@') { $analysis.Recommendations += 'Dynamic SQL detected - ensure parameters are properly sanitized to prevent SQL injection.' }
        if ($upperSql -match 'WAITFOR\s+DELAY|WAITFOR\s+TIME') { $analysis.Recommendations += 'WAITFOR detected - ensure this is intentional and not blocking other queries.' }
        # Look up similar top queries from repository
        if (-not [string]::IsNullOrWhiteSpace($displayName)) {
            $repoInstances = Get-RepositoryInstances
            $repoInstance = $repoInstances | Where-Object { $_.DisplayName -eq $displayName } | Select-Object -First 1
            if ($repoInstance) {
                $analysis.TopQueries = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 5 CaptureTime, LEFT(SqlText, 200) AS QueryPreview, CpuTime, ElapsedTime, Reads, LogicalReads, WaitType, Recommendations FROM mon.ExecutionPlansHistory WHERE InstanceID = @InstanceID ORDER BY CpuTime DESC;' -Parameters @{ InstanceID = [int]$repoInstance.InstanceID } -Timeout 15))
                $analysis.MissingIndexes = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 5 mi.DatabaseName AS SchemaName, mi.ObjectName AS TableName, mi.EqualityColumns, mi.InequalityColumns, mi.IncludedColumns, ISNULL(mi.AvgTotalUserCost, 0) * ISNULL(mi.AvgUserImpact, 0) * ISNULL(mi.UserSeeks + mi.UserScans, 0) AS ImpactScore FROM dbo.MissingIndexes mi WHERE mi.InstanceID = @InstanceID ORDER BY ImpactScore DESC;' -Parameters @{ InstanceID = [int]$repoInstance.InstanceID } -Timeout 15))
            }
        }
        return $analysis
    }
    # Alert Triage Assistant
    if ($method -eq 'POST' -and $path -eq '/api/assistant/alert-triage') {
        $body = Read-RequestJson -Request $Request
        $displayName = [string]$body.DisplayName
        $hoursBack = if ($body.HoursBack) { [Math]::Min(168, [Math]::Max(1, [int]$body.HoursBack)) } else { 24 }
        $repoInstances = Get-RepositoryInstances
        $repoInstance = $repoInstances | Where-Object { $_.DisplayName -eq $displayName } | Select-Object -First 1
        if (-not $repoInstance) { throw 'Selected instance is not registered in the repository.' }
        $since = (Get-Date).AddHours(-$hoursBack).ToString('yyyy-MM-dd HH:mm:ss')
        $alerts = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT AlertID, DisplayName, AlertTime, Severity, ModuleName, AlertTitle, AlertDetails, IsAcknowledged, DATEDIFF(MINUTE, AlertTime, GETDATE()) AS AgeMinutes FROM mon.vw_AlertHistoryDetailed WHERE InstanceID = @InstanceID AND AlertTime >= @Since ORDER BY AlertTime DESC;' -Parameters @{ InstanceID = [int]$repoInstance.InstanceID; Since = $since } -Timeout 30)
        # Group by module and find correlations
        $moduleGroups = @{}
        foreach ($alert in $alerts) {
            $mod = [string]$alert.ModuleName
            if (-not $moduleGroups.ContainsKey($mod)) { $moduleGroups[$mod] = @() }
            $moduleGroups[$mod] += $alert
        }
        $correlations = @()
        $moduleKeys = @($moduleGroups.Keys)
        for ($i = 0; $i -lt $moduleKeys.Count; $i++) {
            for ($j = $i + 1; $j -lt $moduleKeys.Count; $j++) {
                $a = $moduleGroups[$moduleKeys[$i]]
                $b = $moduleGroups[$moduleKeys[$j]]
                if ($a.Count -gt 0 -and $b.Count -gt 0) {
                    $timeSpan = if ($a.Count -gt 0 -and $b.Count -gt 0) {
                        $aMax = ($a | Measure-Object -Property AgeMinutes -Minimum).Minimum
                        $bMax = ($b | Measure-Object -Property AgeMinutes -Minimum).Minimum
                        [Math]::Abs($aMax - $bMax)
                    } else { 999 }
                    if ($timeSpan -lt 60) {
                        $correlations += [ordered]@{
                            ModuleA = $moduleKeys[$i]
                            ModuleB = $moduleKeys[$j]
                            AlertCountA = $a.Count
                            AlertCountB = $b.Count
                            TimeSpanMinutes = $timeSpan
                            Likelihood = if ($timeSpan -lt 15) { 'High' } elseif ($timeSpan -lt 30) { 'Medium' } else { 'Low' }
                            Suggestion = "Alerts from $($moduleKeys[$i]) and $($moduleKeys[$j]) occurred within $timeSpan minutes - possible common root cause."
                        }
                    }
                }
            }
        }
        # Find related SOPs
        $relatedSOPs = @()
        foreach ($alert in $alerts | Select-Object -First 10) {
            $title = [string]$alert.AlertTitle
            if (-not [string]::IsNullOrWhiteSpace($title)) {
                $sopRows = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 3 SopID, Title, Category, Severity FROM mon.SOPs WHERE IsActive = 1 AND (Title LIKE @Search OR Category LIKE @Search OR Tags LIKE @Search) ORDER BY CASE Severity WHEN ''Critical'' THEN 0 WHEN ''High'' THEN 1 WHEN ''Medium'' THEN 2 ELSE 3 END;' -Parameters @{ Search = "%$title%" } -Timeout 15)
                foreach ($sop in $sopRows) { $relatedSOPs += $sop }
            }
        }
        return @{
            alerts = $alerts
            totalAlerts = @($alerts).Count
            moduleGroups = ($moduleGroups | ConvertTo-Json -Compress | ConvertFrom-Json)
            correlations = $correlations
            relatedSOPs = ($relatedSOPs | Select-Object -First 10)
            timeRangeHours = $hoursBack
        }
    }
    # VM Health Assistant
    if ($method -eq 'GET' -and $path -eq '/api/assistant/vm-health') {
        $displayName = Get-QueryValue -Request $Request -Name 'displayName'
        $repoInstances = Get-RepositoryInstances
        $repoInstance = $repoInstances | Where-Object { $_.DisplayName -eq $displayName } | Select-Object -First 1
        if (-not $repoInstance) { throw 'Selected instance is not registered in the repository.' }
        $targetId = Invoke-RepoScalar -Query @"
DECLARE @targetId INT;
IF OBJECT_ID(N'mon.WindowsTargetInstanceMap','U') IS NOT NULL
BEGIN
    SELECT TOP 1 @targetId = t.TargetID
    FROM mon.WindowsTargets t
    INNER JOIN mon.WindowsTargetInstanceMap tim ON t.TargetID = tim.TargetID
    INNER JOIN mon.MonitoredInstances mi ON tim.InstanceID = mi.InstanceID
    WHERE mi.DisplayName = @Name OR t.ComputerName = @Name OR t.DisplayName = @Name;
END
ELSE
BEGIN
    SELECT TOP 1 @targetId = TargetID
    FROM mon.WindowsTargets
    WHERE ComputerName = @Name OR DisplayName = @Name;
END
SELECT @targetId;
"@ -Parameters @{ Name = $displayName } -Timeout 15
        if (-not $targetId) { throw 'No VM target found for the selected instance.' }
        $health = [ordered]@{}
        # Latest performance sample
        $health.LatestSample = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
SELECT TOP 1
    ps.CaptureTime,
    ps.CPUPercent,
    COALESCE(
        ps.MemoryUsedPercent,
        latestMemory.MemoryUsedPercent,
        CASE
            WHEN inv.TotalMemoryGB > 0 AND COALESCE(ps.MemoryAvailableGB, latestMemory.MemoryAvailableGB) IS NOT NULL
            THEN CAST(ROUND(((inv.TotalMemoryGB - COALESCE(ps.MemoryAvailableGB, latestMemory.MemoryAvailableGB)) / inv.TotalMemoryGB) * 100, 2) AS DECIMAL(6,2))
            ELSE NULL
        END
    ) AS MemoryUsedPercent,
    COALESCE(ps.MemoryAvailableGB, latestMemory.MemoryAvailableGB) AS MemoryAvailableGB,
    ps.DiskUsedPercent,
    ps.HealthScore,
    ps.HealthPosture,
    ps.ProcessCount,
    ps.ServiceStoppedCount
FROM mon.WindowsPerformanceSamples ps
LEFT JOIN mon.WindowsInventory inv ON inv.TargetID = ps.TargetID
OUTER APPLY (
    SELECT TOP 1 MemoryUsedPercent, MemoryAvailableGB
    FROM mon.WindowsPerformanceSamples
    WHERE TargetID = @TargetID
      AND (MemoryUsedPercent IS NOT NULL OR MemoryAvailableGB IS NOT NULL)
    ORDER BY CaptureTime DESC, SampleID DESC
) latestMemory
WHERE ps.TargetID = @TargetID
ORDER BY ps.CaptureTime DESC, ps.SampleID DESC;
"@ -Parameters @{ TargetID = [int]$targetId } -Timeout 15))
        # Capacity forecast
        $health.CapacityForecast = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT MetricName, CurrentValue, GrowthRatePerDay, DaysUntilExhaustion, ConfidencePercent, RecommendedAction FROM mon.WindowsCapacityForecast WHERE TargetID = @TargetID;' -Parameters @{ TargetID = [int]$targetId } -Timeout 15))
        # Recent anomalies
        $health.RecentAnomalies = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 10 MetricName, DetectedAt, ActualValue, BaselineAvg, DeviationMultiplier, Severity FROM mon.WindowsAnomalyLog WHERE TargetID = @TargetID AND IsAcknowledged = 0 ORDER BY DetectedAt DESC;' -Parameters @{ TargetID = [int]$targetId } -Timeout 15))
        # Patch compliance
        $health.PatchCompliance = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
IF OBJECT_ID(N'mon.vw_WindowsPatchCompliance','V') IS NOT NULL
BEGIN
    SELECT ComplianceScore, ComplianceStatus, TotalRequiredPatches, InstalledPatches, MissingCriticalPatches
    FROM mon.vw_WindowsPatchCompliance
    WHERE TargetID = @TargetID;
END
ELSE
BEGIN
    SELECT
        COUNT(*) AS TotalRequiredPatches,
        SUM(CASE WHEN hf.HotFixID IS NOT NULL THEN 1 ELSE 0 END) AS InstalledPatches,
        SUM(CASE WHEN pb.IsRequired = 1 AND hf.HotFixID IS NULL THEN 1 ELSE 0 END) AS MissingCriticalPatches,
        CASE WHEN COUNT(*) = 0 THEN 100.0 ELSE CAST(ROUND(SUM(CASE WHEN hf.HotFixID IS NOT NULL THEN 1.0 ELSE 0 END) / COUNT(*) * 100, 1) AS DECIMAL(5,1)) END AS ComplianceScore,
        CASE
            WHEN COUNT(*) = 0 THEN N'Compliant'
            WHEN CAST(ROUND(SUM(CASE WHEN hf.HotFixID IS NOT NULL THEN 1.0 ELSE 0 END) / COUNT(*) * 100, 1) AS DECIMAL(5,1)) >= 95 THEN N'Compliant'
            WHEN CAST(ROUND(SUM(CASE WHEN hf.HotFixID IS NOT NULL THEN 1.0 ELSE 0 END) / COUNT(*) * 100, 1) AS DECIMAL(5,1)) >= 80 THEN N'Partial'
            ELSE N'Non-Compliant'
        END AS ComplianceStatus
    FROM mon.WindowsPatchBaseline pb
    CROSS JOIN (SELECT TargetID FROM mon.WindowsTargets WHERE TargetID = @TargetID) t
    LEFT JOIN mon.WindowsHotFixSamples hf ON t.TargetID = hf.TargetID AND pb.HotFixID = hf.HotFixID
    WHERE pb.IsActive = 1;
END
"@ -Parameters @{ TargetID = [int]$targetId } -Timeout 15))
        # Network status
        $health.NetworkAdapters = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
IF OBJECT_ID(N'mon.vw_WindowsNetworkAdapterUtilization','V') IS NOT NULL
BEGIN
    DECLARE @sql NVARCHAR(MAX);
    IF COL_LENGTH(N'mon.vw_WindowsNetworkAdapterUtilization', 'TargetID') IS NOT NULL
    BEGIN
        SET @sql = N'
            SELECT AdapterName, BytesTotalPerSec, UtilizationPercent
            FROM mon.vw_WindowsNetworkAdapterUtilization
            WHERE TargetID = @TargetID;
        ';
    END
    ELSE
    BEGIN
        SET @sql = N'
            SELECT AdapterName, BytesTotalPerSec, UtilizationPercent
            FROM mon.vw_WindowsNetworkAdapterUtilization
            WHERE DisplayName = @Name OR ComputerName = @Name;
        ';
    END
    EXEC sp_executesql @sql, N'@TargetID INT, @Name NVARCHAR(400)', @TargetID = @TargetID, @Name = @Name;
END
ELSE
BEGIN
    SELECT TOP 10 AdapterName, BytesReceivedPerSec, BytesSentPerSec, BytesTotalPerSec, CurrentBandwidth,
        CASE WHEN CurrentBandwidth > 0 AND BytesTotalPerSec IS NOT NULL THEN CAST(ROUND(CAST(BytesTotalPerSec AS FLOAT) / CurrentBandwidth * 100, 2) AS DECIMAL(6,2)) ELSE NULL END AS UtilizationPercent
    FROM mon.WindowsNetworkAdapterStats
    WHERE TargetID = @TargetID
    ORDER BY CaptureTime DESC;
END
"@ -Parameters @{ TargetID = [int]$targetId; Name = $displayName } -Timeout 15))
        $health.FirewallStatus = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
IF OBJECT_ID(N'mon.vw_WindowsFirewallDashboard','V') IS NOT NULL
BEGIN
    DECLARE @sql NVARCHAR(MAX);
    IF COL_LENGTH(N'mon.vw_WindowsFirewallDashboard', 'TargetID') IS NOT NULL
    BEGIN
        SET @sql = N'
            SELECT ProfileName, Enabled
            FROM mon.vw_WindowsFirewallDashboard
            WHERE TargetID = @TargetID;
        ';
    END
    ELSE
    BEGIN
        SET @sql = N'
            SELECT ProfileName, Enabled
            FROM mon.vw_WindowsFirewallDashboard
            WHERE DisplayName = @Name OR ComputerName = @Name;
        ';
    END
    EXEC sp_executesql @sql, N'@TargetID INT, @Name NVARCHAR(400)', @TargetID = @TargetID, @Name = @Name;
END
ELSE
BEGIN
    SELECT ProfileName, Enabled
    FROM (
        SELECT ProfileName, Enabled, ROW_NUMBER() OVER (PARTITION BY ProfileName ORDER BY CaptureTime DESC) AS rn
        FROM mon.WindowsFirewallStatus
        WHERE TargetID = @TargetID
    ) fw
    WHERE rn = 1;
END
"@ -Parameters @{ TargetID = [int]$targetId; Name = $displayName } -Timeout 15))
        # Open alerts count
        $health.OpenAlerts = [int](Invoke-RepoScalar -Query @"
IF OBJECT_ID(N'mon.vw_WindowsOpenAlerts','V') IS NOT NULL
BEGIN
    SELECT COUNT(1) FROM mon.vw_WindowsOpenAlerts WHERE TargetID = @TargetID;
END
ELSE
BEGIN
    SELECT COUNT(1) FROM mon.AlertHistory WHERE InstanceID = @InstanceID AND IsAcknowledged = 0 AND ModuleName LIKE N'VM:%';
END
"@ -Parameters @{ TargetID = [int]$targetId; InstanceID = [int]$repoInstance.InstanceID } -Timeout 15)
        # Generate summary
        $summaryParts = @()
        if ($health.LatestSample.Count -gt 0) {
            $s = $health.LatestSample[0]
            $summaryParts += "Health Score: $($s.HealthScore) ($($s.HealthPosture))"
            if ($s.CPUPercent) { $summaryParts += "CPU: $($s.CPUPercent)%" }
            if ($null -ne $s.MemoryUsedPercent) { $summaryParts += "Memory: $($s.MemoryUsedPercent)%" }
            if ($s.DiskUsedPercent) { $summaryParts += "Disk: $($s.DiskUsedPercent)%" }
        }
        if ($health.CapacityForecast.Count -gt 0) {
            foreach ($cf in $health.CapacityForecast) {
                if ($cf.DaysUntilExhaustion -and $cf.DaysUntilExhaustion -lt 90) {
                    $summaryParts += "$($cf.MetricName) exhaustion in $($cf.DaysUntilExhaustion) days"
                }
            }
        }
        if ($health.PatchCompliance.Count -gt 0 -and $health.PatchCompliance[0].ComplianceScore -lt 95) {
            $summaryParts += "Patch compliance: $($health.PatchCompliance[0].ComplianceScore)% ($($health.PatchCompliance[0].ComplianceStatus))"
        }
        if ($health.RecentAnomalies.Count -gt 0) {
            $summaryParts += "$($health.RecentAnomalies.Count) unacknowledged anomalies"
        }
        $health.Summary = $summaryParts -join ' | '
        return $health
    }
    # Incident Timeline Assistant
    if ($method -eq 'GET' -and $path -eq '/api/assistant/incident-timeline') {
        $displayName = Get-QueryValue -Request $Request -Name 'displayName'
        $hoursBack = [Math]::Min(168, [Math]::Max(1, [int](Get-QueryValue -Request $Request -Name 'hoursBack' -DefaultValue '24')))
        $repoInstances = Get-RepositoryInstances
        $repoInstance = $repoInstances | Where-Object { $_.DisplayName -eq $displayName } | Select-Object -First 1
        if (-not $repoInstance) { throw 'Selected instance is not registered in the repository.' }
        $since = (Get-Date).AddHours(-$hoursBack).ToString('yyyy-MM-dd HH:mm:ss')
        $targetId = Invoke-RepoScalar -Query @"
DECLARE @targetId INT;
IF OBJECT_ID(N'mon.WindowsTargetInstanceMap','U') IS NOT NULL
BEGIN
    SELECT TOP 1 @targetId = t.TargetID
    FROM mon.WindowsTargets t
    INNER JOIN mon.WindowsTargetInstanceMap tim ON t.TargetID = tim.TargetID
    INNER JOIN mon.MonitoredInstances mi ON tim.InstanceID = mi.InstanceID
    WHERE mi.DisplayName = @Name OR t.ComputerName = @Name OR t.DisplayName = @Name;
END
ELSE
BEGIN
    SELECT TOP 1 @targetId = TargetID
    FROM mon.WindowsTargets
    WHERE ComputerName = @Name OR DisplayName = @Name;
END
SELECT @targetId;
"@ -Parameters @{ Name = $displayName } -Timeout 15
        $timeline = @()
        # Alert events
        $alerts = ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
IF OBJECT_ID(N'mon.vw_AlertHistoryDetailed','V') IS NOT NULL
BEGIN
    SELECT AlertTime AS EventTime, Severity, ModuleName AS Source, AlertTitle AS Description, N'Alert' AS EventType
    FROM mon.vw_AlertHistoryDetailed
    WHERE InstanceID = @InstanceID AND AlertTime >= @Since;
END
ELSE
BEGIN
    SELECT AlertTime AS EventTime, Severity, ModuleName AS Source, AlertTitle AS Description, N'Alert' AS EventType
    FROM mon.AlertHistory
    WHERE InstanceID = @InstanceID AND AlertTime >= @Since;
END
"@ -Parameters @{ InstanceID = [int]$repoInstance.InstanceID; Since = $since } -Timeout 30)
        foreach ($a in $alerts) { $timeline += $a }
        # VM events (anomalies)
        if ($targetId) {
            $anomalies = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT DetectedAt AS EventTime, Severity, MetricName AS Source, CONCAT(''Deviation: '', DeviationMultiplier, ''x from baseline'') AS Description, ''Anomaly'' AS EventType FROM mon.WindowsAnomalyLog WHERE TargetID = @TargetID AND DetectedAt >= @Since;' -Parameters @{ TargetID = [int]$targetId; Since = $since } -Timeout 15)
            foreach ($a in $anomalies) { $timeline += $a }
            # Service state changes
            $svcChanges = ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT CaptureTime AS EventTime, ''Warning'' AS Severity, ServiceName AS Source, CONCAT(''Service state: '', StateName) AS Description, ''Service'' AS EventType FROM mon.WindowsServiceSamples WHERE TargetID = @TargetID AND CaptureTime >= @Since AND StateName != ''Running'';' -Parameters @{ TargetID = [int]$targetId; Since = $since } -Timeout 15)
            foreach ($s in $svcChanges) { $timeline += $s }
        }
        # Sort by time descending
        $timeline = @($timeline | Sort-Object -Property EventTime -Descending | Select-Object -First 100)
        return @{ timeline = $timeline; totalEvents = @($timeline).Count; timeRangeHours = $hoursBack }
    }
    # Configuration Drift Detector
    if ($method -eq 'POST' -and $path -eq '/api/assistant/config-drift') {
        $body = Read-RequestJson -Request $Request
        $displayName = [string]$body.DisplayName
        $baselineDate = [string]$body.BaselineDate
        $repoInstances = Get-RepositoryInstances
        $repoInstance = $repoInstances | Where-Object { $_.DisplayName -eq $displayName } | Select-Object -First 1
        if (-not $repoInstance) { throw 'Selected instance is not registered in the repository.' }
        $targetId = Invoke-RepoScalar -Query @"
DECLARE @targetId INT;
IF OBJECT_ID(N'mon.WindowsTargetInstanceMap','U') IS NOT NULL
BEGIN
    SELECT TOP 1 @targetId = t.TargetID
    FROM mon.WindowsTargets t
    INNER JOIN mon.WindowsTargetInstanceMap tim ON t.TargetID = tim.TargetID
    INNER JOIN mon.MonitoredInstances mi ON tim.InstanceID = mi.InstanceID
    WHERE mi.DisplayName = @Name OR t.ComputerName = @Name OR t.DisplayName = @Name;
END
ELSE
BEGIN
    SELECT TOP 1 @targetId = TargetID
    FROM mon.WindowsTargets
    WHERE ComputerName = @Name OR DisplayName = @Name;
END
SELECT @targetId;
"@ -Parameters @{ Name = $displayName } -Timeout 15
        $drift = [ordered]@{}
        $drift.Changes = @()
        $drift.BaselineDate = $baselineDate
        # Compare current inventory vs baseline inventory
        if ($targetId) {
            $currentInv = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT TOP 1 * FROM mon.WindowsInventory WHERE TargetID = @TargetID ORDER BY LastInventoryAt DESC;' -Parameters @{ TargetID = [int]$targetId } -Timeout 15))
            if ($currentInv.Count -gt 0) {
                $ci = $currentInv[0]
                $drift.CurrentInventory = $ci
                # Check for OS changes
                if ($ci.OSVersion) { $drift.Changes += "Current OS: $($ci.OSVersion) (Build $($ci.OSBuild))" }
                if ($ci.TotalMemoryGB) { $drift.Changes += "Memory: $($ci.TotalMemoryGB) GB" }
                if ($ci.LogicalProcessorCount) { $drift.Changes += "CPUs: $($ci.LogicalProcessorCount) logical processors" }
            }
            # Compare current hotfixes vs baseline date
            if (-not [string]::IsNullOrWhiteSpace($baselineDate)) {
                $newPatches = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT HotFixID, InstalledOn, Description FROM mon.WindowsHotFixSamples WHERE TargetID = @TargetID AND InstalledOn > @BaselineDate ORDER BY InstalledOn DESC;' -Parameters @{ TargetID = [int]$targetId; BaselineDate = $baselineDate } -Timeout 15))
                $drift.NewPatchesSinceBaseline = $newPatches
                $drift.NewPatchCount = @($newPatches).Count
            }
            # Network adapter changes
            $currentAdapters = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query 'SELECT DISTINCT AdapterName, InterfaceDescription FROM mon.WindowsNetworkAdapterSamples WHERE TargetID = @TargetID AND CaptureTime >= DATEADD(DAY, -1, SYSDATETIME());' -Parameters @{ TargetID = [int]$targetId } -Timeout 15))
            $drift.CurrentAdapters = $currentAdapters
        }
        # SQL config changes (compare current vs historical)
        $configChanges = @(ConvertTo-PlainRows (Invoke-RepoQuery -Query @"
DECLARE @hasOldNew BIT = CASE WHEN COL_LENGTH(N'mon.ConfigHistory', N'OldValue') IS NOT NULL AND COL_LENGTH(N'mon.ConfigHistory', N'NewValue') IS NOT NULL THEN 1 ELSE 0 END;
DECLARE @hasConfigNameValue BIT = CASE WHEN COL_LENGTH(N'mon.ConfigHistory', N'ConfigName') IS NOT NULL AND COL_LENGTH(N'mon.ConfigHistory', N'ConfigValue') IS NOT NULL THEN 1 ELSE 0 END;
DECLARE @sql NVARCHAR(MAX);
IF @hasOldNew = 1
BEGIN
    SET @sql = N'
        SELECT TOP 20 CaptureTime, ConfigName, OldValue, NewValue
        FROM mon.ConfigHistory
        WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(DAY, -30, SYSDATETIME())
        ORDER BY CaptureTime DESC;
    ';
END
ELSE IF @hasConfigNameValue = 1
BEGIN
    SET @sql = N'
        SELECT TOP 20 CaptureTime, ConfigName, NULL AS OldValue, ConfigValue AS NewValue
        FROM mon.ConfigHistory
        WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(DAY, -30, SYSDATETIME())
        ORDER BY CaptureTime DESC;
    ';
END
ELSE
BEGIN
    SET @sql = N'
        SELECT TOP 20 CaptureTime, N''ConfigSnapshot'' AS ConfigName,
            NULL AS OldValue,
            CONCAT(
                N''CPU='', ISNULL(CAST(ProcessorCount AS NVARCHAR(20)), N''NULL''), N''; '',
                N''MemoryMB='', ISNULL(CAST(PhysicalMemoryMB AS NVARCHAR(20)), N''NULL''), N''; '',
                N''MAXDOP='', ISNULL(CAST(MAXDOP AS NVARCHAR(20)), N''NULL''), N''; '',
                N''CostThreshold='', ISNULL(CAST(CostThresholdForParallelism AS NVARCHAR(20)), N''NULL'')
            ) AS NewValue
        FROM mon.ConfigHistory
        WHERE InstanceID = @InstanceID AND CaptureTime >= DATEADD(DAY, -30, SYSDATETIME())
        ORDER BY CaptureTime DESC;
    ';
END
EXEC sp_executesql @sql, N'@InstanceID INT', @InstanceID = @InstanceID;
"@ -Parameters @{ InstanceID = [int]$repoInstance.InstanceID } -Timeout 15))
        $drift.SqlConfigChanges = $configChanges
        return $drift
    }
    if ($method -eq 'GET' -and $path -eq '/api/patch/status') { return @{ rows = Get-PatchStatusPayload -DisplayName (Get-QueryValue -Request $Request -Name 'displayName') } }
    if ($method -eq 'POST' -and $path -eq '/api/patch/download') {
        [void](Require-AdminUser -Request $Request -ActionName 'Downloading patches')
        $body = Read-RequestJson -Request $Request
        $instance = Get-ConfiguredInstances | Where-Object { $_.DisplayName -eq [string]$body.DisplayName -or $_.SqlInstance -eq [string]$body.DisplayName } | Select-Object -First 1
        if (-not $instance) { throw 'Select an instance first.' }
        $downloadPath = if ([string]::IsNullOrWhiteSpace([string]$body.DownloadPath)) { Join-Path $projectRoot 'Patches' } else { [string]$body.DownloadPath }
        if (-not (Test-Path $downloadPath)) { New-Item -ItemType Directory -Path $downloadPath -Force | Out-Null }
        $downloads = @(Invoke-SQLServerPatchDownloader -Instance $instance -DownloadPath $downloadPath -Force:([bool]$body.Force))
        return @{ ok = $true; rows = $downloads; downloadPath = $downloadPath }
    }
    if ($method -eq 'GET' -and $path -eq '/api/users') {
        [void](Require-AdminUser -Request $Request -ActionName 'Viewing users')
        $userId = Get-IntQueryValue -Request $Request -Name 'userId'
        $userInstances = @()
        $userInstanceError = $null
        try { $userInstances = @(Get-RepositoryInstances) }
        catch {
            $userInstanceError = $_.Exception.Message
            $userInstances = @(Convert-ConfiguredInstancesForUi)
        }
        return @{
            rows = @(Get-Users)
            access = if ($userId -gt 0) { @(Get-UserAccess -UserID $userId) } else { @() }
            groupAccess = if ($userId -gt 0) { @(Get-UserGroupAccess -UserID $userId) } else { @() }
            effectiveAccess = if ($userId -gt 0) { @(Get-EffectiveUserAccess -UserID $userId) } else { @() }
            groups = @(Get-ServerGroups)
            groupMembers = @(Get-ServerGroupMembers)
            groupUsers = @(Get-ServerGroupUsers)
            instances = $userInstances
            repositoryError = $userInstanceError
        }
    }
    if ($method -eq 'GET' -and $path -eq '/api/server-groups') {
        [void](Require-AdminUser -Request $Request -ActionName 'Viewing server groups')
        $groupId = Get-IntQueryValue -Request $Request -Name 'groupId'
        return @{ groups = @(Get-ServerGroups); members = @(Get-ServerGroupMembers -GroupID $groupId); users = @(Get-ServerGroupUsers -GroupID $groupId) }
    }
    if ($method -eq 'POST' -and $path -eq '/api/server-groups') {
        [void](Require-AdminUser -Request $Request -ActionName 'Saving server groups')
        $result = Save-ServerGroup -Body (Read-RequestJson -Request $Request)
        Write-DashboardAudit -User $currentUser -ActionName 'SaveServerGroup' -Details 'Application server group save'
        return $result
    }
    if ($method -eq 'POST' -and $path -eq '/api/user-server-access') {
        [void](Require-AdminUser -Request $Request -ActionName 'Assigning user servers')
        $result = Save-DirectUserServerAccess -Body (Read-RequestJson -Request $Request)
        Write-DashboardAudit -User $currentUser -ActionName 'SaveUserServerAccess' -Details 'Direct user server assignment save'
        return $result
    }
    if ($method -eq 'DELETE' -and $path -eq '/api/server-groups') {
        [void](Require-AdminUser -Request $Request -ActionName 'Deleting server groups')
        $groupId = Get-IntQueryValue -Request $Request -Name 'groupId'
        $result = Delete-ServerGroup -GroupID $groupId
        Write-DashboardAudit -User $currentUser -ActionName 'DeleteServerGroup' -Details ("GroupID {0}" -f $groupId)
        return $result
    }
    if ($method -eq 'GET' -and $path -eq '/api/audit') {
        [void](Require-AdminUser -Request $Request -ActionName 'Viewing audit trail')
        return @{ rows = Get-DashboardAuditRows -Limit (Get-IntQueryValue -Request $Request -Name 'limit' -Default 200) }
    }
    if ($method -eq 'POST' -and $path -eq '/api/users') { [void](Require-AdminUser -Request $Request -ActionName 'Saving users'); $result = Save-User -Body (Read-RequestJson -Request $Request); Write-DashboardAudit -User $currentUser -ActionName 'SaveUser' -Details 'Web dashboard user save'; return $result }
    if ($method -eq 'DELETE' -and $path -eq '/api/users') {
        [void](Require-AdminUser -Request $Request -ActionName 'Deleting users')
        $delUserId = Get-IntQueryValue -Request $Request -Name 'userId'
        if ($delUserId -le 0) { throw 'userId is required.' }
        if ($delUserId -eq [int]$currentUser.UserID) { throw 'You cannot delete the account you are currently using.' }
        Invoke-RepoNonQuery -Query 'DELETE FROM mon.DashboardUsers WHERE UserID = @UserID;' -Parameters @{ UserID = $delUserId }
        Write-DashboardAudit -User $currentUser -ActionName 'DeleteUser' -Details ("UserID {0}" -f $delUserId)
        return @{ ok = $true; rows = Get-Users }
    }

    throw "Route not found: $method $path"
}

function Write-StaticFile {
    param($Request, $Response)
    $path = $Request.Url.LocalPath
    $fileName = if ($path -eq '/') { 'index.html' } else { [System.Uri]::UnescapeDataString($path.TrimStart('/')).Replace('/', [System.IO.Path]::DirectorySeparatorChar) }
    if ([string]::IsNullOrWhiteSpace($fileName) -or $fileName -match '\.\.' -or [System.IO.Path]::IsPathRooted($fileName)) {
        throw 'ACCESS_DENIED: Invalid static file path.'
    }
    $extension = [System.IO.Path]::GetExtension($fileName).ToLowerInvariant()
    if ($script:AllowedStaticExtensions -notcontains $extension) {
        throw 'ACCESS_DENIED: Static file type is not allowed.'
    }
    $staticRoot = [System.IO.Path]::GetFullPath($staticFilesDir).TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
    $filePath = [System.IO.Path]::GetFullPath((Join-Path $staticFilesDir $fileName))
    if (-not $filePath.StartsWith($staticRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'ACCESS_DENIED: Static file path is outside the web root.'
    }
    if (-not (Test-Path $filePath -PathType Leaf)) {
        Write-Response -Response $Response -Data 'Not found' -StatusCode 404 -ContentType 'text/plain'
        return
    }
    $contentType = switch ($extension) {
        '.html' { 'text/html' }
        '.css' { 'text/css' }
        '.js' { 'application/javascript' }
        '.png' { 'image/png' }
        '.jpg' { 'image/jpeg' }
        '.jpeg' { 'image/jpeg' }
        '.svg' { 'image/svg+xml' }
        '.webp' { 'image/webp' }
        '.ico' { 'image/x-icon' }
        '.woff' { 'font/woff' }
        '.woff2' { 'font/woff2' }
        default { 'application/octet-stream' }
    }
    $buffer = [System.IO.File]::ReadAllBytes($filePath)
    Set-SecurityHeaders -Response $Response
    $Response.StatusCode = 200
    $Response.ContentType = $contentType
    $Response.ContentLength64 = $buffer.Length
    $Response.OutputStream.Write($buffer, 0, $buffer.Length)
}

function New-MemoryResponse {
    return [pscustomobject]@{
        StatusCode = 200
        ContentType = 'application/octet-stream'
        ContentLength64 = 0
        Headers = @{}
        OutputStream = New-Object System.IO.MemoryStream
    }
}

function Write-TcpHttpResponse {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        $Response
    )

    $body = $Response.OutputStream.ToArray()
    $statusCode = if ($Response.StatusCode) { [int]$Response.StatusCode } else { 200 }
    $reason = switch ($statusCode) {
        200 { 'OK' }
        400 { 'Bad Request' }
        401 { 'Unauthorized' }
        403 { 'Forbidden' }
        404 { 'Not Found' }
        413 { 'Payload Too Large' }
        500 { 'Internal Server Error' }
        default { 'OK' }
    }
    $contentType = if ($Response.ContentType) { [string]$Response.ContentType } else { 'application/octet-stream' }
    $headerLines = @(
        "HTTP/1.1 $statusCode $reason",
        "Content-Length: $($body.Length)",
        "Content-Type: $contentType"
    )
    if ($Response.Headers) {
        foreach ($key in $Response.Headers.Keys) {
            if ([string]::IsNullOrWhiteSpace([string]$key)) { continue }
            $headerLines += ("{0}: {1}" -f $key, $Response.Headers[$key])
        }
    }
    if (-not $Response.Headers -or -not $Response.Headers.ContainsKey('Cache-Control')) {
        $headerLines += 'Cache-Control: no-store, no-cache, must-revalidate'
    }
    $headerLines += 'Connection: close'
    $header = ($headerLines -join "`r`n") + "`r`n`r`n"
    try {
        $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
        $Stream.Write($headerBytes, 0, $headerBytes.Length)
        if ($body.Length -gt 0) {
            $Stream.Write($body, 0, $body.Length)
        }
    }
    catch {
        Write-MonitorLog "TCP response write skipped because the client disconnected: $($_.Exception.Message)" -Level 'Warning'
    }
}

function Get-AvailableDashboardPort {
    param([int]$PreferredPort)
    for ($candidate = $PreferredPort; $candidate -lt ($PreferredPort + 50); $candidate++) {
        $probe = $null
        try {
            $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $candidate)
            $probe.Start()
            return $candidate
        }
        catch {
            continue
        }
        finally {
            if ($probe) { $probe.Stop() }
        }
    }
    throw "No available dashboard port found between $PreferredPort and $($PreferredPort + 49)."
}

function Start-TcpDashboardServer {
    param([int]$Port)

    $listenPort = Get-AvailableDashboardPort -PreferredPort $Port
    if ($listenPort -ne $Port) {
        Write-Host "Port $Port is already in use. Using http://localhost:$listenPort/ instead." -ForegroundColor Yellow
    }

    $tcp = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $listenPort)
    $tcp.Start()
    Write-Host "SQL Monitor Web Dashboard: http://localhost:$listenPort/ (TcpListener fallback)" -ForegroundColor Green
    Write-Host "Repository: $script:RepositoryServer / $script:RepositoryDatabase" -ForegroundColor DarkGray
    Write-Host 'Press Ctrl+C to stop the server.'

    try {
        while ($true) {
            $client = $tcp.AcceptTcpClient()
            try {
                $stream = $client.GetStream()
                $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8, $false, 4096, $true)
                $requestLine = $reader.ReadLine()
                if ([string]::IsNullOrWhiteSpace($requestLine)) { continue }
                $parts = $requestLine -split ' '
                $method = $parts[0]
                $target = $parts[1]
                $headers = @{}
                while ($true) {
                    $line = $reader.ReadLine()
                    if ($null -eq $line -or $line -eq '') { break }
                    $colon = $line.IndexOf(':')
                    if ($colon -gt 0) {
                        $headers[$line.Substring(0, $colon).Trim().ToLowerInvariant()] = $line.Substring($colon + 1).Trim()
                    }
                }
                $contentLength = if ($headers.ContainsKey('content-length')) { [int]$headers['content-length'] } else { 0 }
                $body = ''
                if ($contentLength -gt 0) {
                    $chars = New-Object char[] $contentLength
                    [void]$reader.ReadBlock($chars, 0, $contentLength)
                    $body = -join $chars
                }

                $uri = [uri]"http://localhost:$listenPort$target"
                $query = New-Object System.Collections.Specialized.NameValueCollection
                $rawQuery = $uri.Query.TrimStart('?')
                if (-not [string]::IsNullOrWhiteSpace($rawQuery)) {
                    foreach ($pair in $rawQuery -split '&') {
                        if ([string]::IsNullOrWhiteSpace($pair)) { continue }
                        $kv = $pair -split '=', 2
                        $key = [System.Uri]::UnescapeDataString($kv[0].Replace('+', ' '))
                        $value = if ($kv.Count -gt 1) { [System.Uri]::UnescapeDataString($kv[1].Replace('+', ' ')) } else { '' }
                        $query[$key] = $value
                    }
                }
                $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($body)
                $request = [pscustomobject]@{
                    HttpMethod = $method
                    Url = $uri
                    QueryString = $query
                    Headers = $headers
                    InputStream = [System.IO.MemoryStream]::new($bodyBytes)
                    ContentEncoding = [System.Text.Encoding]::UTF8
                    ContentLength64 = $bodyBytes.Length
                }
                $response = New-MemoryResponse

                try {
                    Write-Host "$method $($uri.LocalPath)"
                    if ($uri.LocalPath -like '/api/*') {
                        Write-Response -Response $response -Data (Get-RouteResult -Request $request)
                    }
                    else {
                        Write-StaticFile -Request $request -Response $response
                    }
                }
                catch {
                    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
                    $response = New-MemoryResponse
                    $errorDetails = Get-HttpErrorDetails -Message $_.Exception.Message
                    Write-Response -Response $response -Data @{ error = $errorDetails.Message } -StatusCode $errorDetails.StatusCode
                }

                Write-TcpHttpResponse -Stream $stream -Response $response
            }
            finally {
                $client.Close()
            }
        }
    }
    finally {
        $tcp.Stop()
    }
}

try {
    Invoke-DashboardSecuritySchemaEnsure
    Invoke-AlertTicketDedupSchemaEnsure
    Invoke-TaskManagementSchemaEnsure
    Invoke-SopWikiSchemaEnsure
    Invoke-BiInsightsSchemaEnsure
}
catch {
    Write-MonitorLog "Dashboard startup schema ensure failed: $($_.Exception.Message)" -Level 'Warning'
    Write-Host "Dashboard startup schema check failed: $($_.Exception.Message)" -ForegroundColor Yellow
}

try {
    $listener = New-Object System.Net.HttpListener
}
catch {
    Write-Host "HttpListener unavailable: $($_.Exception.Message)" -ForegroundColor Yellow
    Start-TcpDashboardServer -Port $Port
    return
}
$listener.Prefixes.Add("http://localhost:$Port/")

try {
    $listener.Start()
    Write-Host "SQL Monitor Web Dashboard: http://localhost:$Port/" -ForegroundColor Green
    Write-Host "Repository: $script:RepositoryServer / $script:RepositoryDatabase" -ForegroundColor DarkGray
    Write-Host 'Press Ctrl+C to stop the server.'

    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        try {
            Write-Host "$($request.HttpMethod) $($request.Url.LocalPath)"
            if ($request.Url.LocalPath -like '/api/*') {
                Write-Response -Response $response -Data (Get-RouteResult -Request $request)
            }
            else {
                Write-StaticFile -Request $request -Response $response
            }
        }
        catch {
            Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
            $errorDetails = Get-HttpErrorDetails -Message $_.Exception.Message
            Write-Response -Response $response -Data @{ error = $errorDetails.Message } -StatusCode $errorDetails.StatusCode
        }
        finally {
            $response.Close()
        }
    }
}
catch [System.Net.HttpListenerException] {
    Write-Host "HttpListener could not bind http://localhost:$Port/: $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host "Falling back to the built-in TCP listener." -ForegroundColor Yellow
    Start-TcpDashboardServer -Port $Port
}
finally {
    if ($listener -and $listener.IsListening) { $listener.Stop() }
}




































































