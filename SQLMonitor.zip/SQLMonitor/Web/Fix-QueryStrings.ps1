# Fix-QueryStrings.ps1
# Repairs malformed query string / parameter separator text in Start-WebServer.ps1.

$ErrorActionPreference = 'Stop'

$filePath = Join-Path $PSScriptRoot 'Start-WebServer.ps1'

Write-Host "Reading file..."
$content = Get-Content -LiteralPath $filePath -Raw
Write-Host "File read: $($content.Length) characters"

$replacements = @{
    'WHERE UserName = @UserName;"''-Parameters'   = "WHERE UserName = @UserName;' -Parameters"
    'WHERE InstanceID = @InstanceID;"''-Parameters' = "WHERE InstanceID = @InstanceID;' -Parameters"
    'WHERE TicketID = @TicketID;"''-Parameters'   = "WHERE TicketID = @TicketID;' -Parameters"
    'WHERE UserID = @UserID;"''-Parameters'       = "WHERE UserID = @UserID;' -Parameters"
}

$changed = $false
foreach ($item in $replacements.GetEnumerator()) {
    if ($content.Contains($item.Key)) {
        Write-Host "Found malformed pattern: $($item.Key)"
        $content = $content.Replace($item.Key, $item.Value)
        $changed = $true
    }
}

$genericPattern = '"''-Parameters'
$genericCount = ([regex]::Matches($content, [regex]::Escape($genericPattern))).Count
Write-Host "Found $genericCount generic malformed parameter separators"

if ($genericCount -gt 0) {
    $content = $content.Replace($genericPattern, "' -Parameters")
    $changed = $true
}

if ($changed) {
    Write-Host "Saving file..."
    Set-Content -LiteralPath $filePath -Value $content -Encoding UTF8
    Write-Host "File saved. New length: $((Get-Content -LiteralPath $filePath -Raw).Length) characters"
} else {
    Write-Host "No malformed query strings found."
}

Write-Host "`nChecking PowerShell syntax..."
$tokens = $null
$errors = $null
[System.Management.Automation.Language.Parser]::ParseFile($filePath, [ref]$tokens, [ref]$errors) | Out-Null
if ($errors.Count -gt 0) {
    Write-Host "Found $($errors.Count) syntax errors:" -ForegroundColor Red
    $errors | ForEach-Object {
        Write-Host ("  Line {0}: {1}" -f $_.Extent.StartLineNumber, $_.Message)
    }
    exit 1
}

Write-Host "No syntax errors found!" -ForegroundColor Green
