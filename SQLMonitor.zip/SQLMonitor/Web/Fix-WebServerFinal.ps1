# Fix Start-WebServer.ps1 PowerShell syntax errors
# Strategy: Parse the file as PowerShell AST and fix issues programmatically

$file = "Start-WebServer.ps1"
Write-Host "Reading file: $file"
$content = Get-Content $file -Raw
Write-Host "File length: $($content.Length) characters"

# Fix 1: Replace double-quoted SQL strings with single-quoted strings
# These cause splatting errors when @variables are inside double quotes
Write-Host "`nFix 1: Replacing double-quoted SQL strings..."

# Pattern to find: -Query "SQL with @variables"
# Replace with: -Query 'SQL with @variables'

$lines = $content -split "`n"
$fixedLines = @()
$fixedCount = 0

for ($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]
    
    # Check if line contains -Query followed by double quote
    if ($line -match '-Query\s+"') {
        $originalLine = $line
        
        # Find the double-quoted string
        $queryPos = $line.IndexOf('-Query ')
        if ($queryPos -ge 0) {
            $afterQuery = $line.Substring($queryPos + 7)
            $doubleQuotePos = $afterQuery.IndexOf('"')
            
            if ($doubleQuotePos -ge 0) {
                # Find the closing double quote
                $startOfString = $queryPos + 7 + $doubleQuotePos
                $closingQuotePos = $line.IndexOf('"', $startOfString + 1)
                
                if ($closingQuotePos -ge 0) {
                    # Replace opening double quote with single quote
                    $line = $line.Remove($startOfString, 1).Insert($startOfString, "'")
                    
                    # Replace closing double quote with single quote (position shifted by 1)
                    $closingQuotePos++
                    $line = $line.Remove($closingQuotePos, 1).Insert($closingQuotePos, "'")
                    
                    if ($line -ne $originalLine) {
                        $fixedCount++
                        if ($fixedCount -le 5) {
                            Write-Host "Fixed line $($i+1): $($line.Substring(0, [Math]::Min(80, $line.Length)))..."
                        }
                    }
                }
            }
        }
    }
    
    $fixedLines += $line
}

Write-Host "Total lines fixed: $fixedCount"

# Fix 2: Ensure -Parameters @{ is on the same line as -Query
Write-Host "`nFix 2: Checking -Parameters placement..."
$content = $fixedLines -join "`n"
$lines = $content -split "`n"
$fixedLines = @()

for ($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]
    
    # Check if line has -Query with single-quoted string followed by -Parameters
    if ($line -match "-Query\s+'[^']*'\s+-Parameters\s+@\{") {
        # This is correct format, keep as is
        $fixedLines += $line
    }
    elseif ($line -match "-Query\s+'[^']*'\s+-Parameters\s+@\{" -and $line -match "-Parameters\s+@\{") {
        # Check if -Parameters is on the next line
        if ($i -lt $lines.Count - 1 -and $lines[$i+1] -match '^\s*-Parameters\s+@\{') {
            # Move -Parameters to the same line
            $line = $line.TrimEnd() + " -Parameters @{"
            $fixedLines += $line
            $i++ # Skip the next line since we merged it
        } else {
            $fixedLines += $line
        }
    }
    else {
        $fixedLines += $line
    }
}

$content = $fixedLines -join "`n"

# Save the fixed file
Write-Host "`nSaving fixed file..."
Set-Content $file -Value $content -Encoding UTF8
Write-Host "File saved!"

# Verify the fixes
Write-Host "`nVerifying fixes..."
$verify = Get-Content $file -Raw

# Check for double-quoted SQL strings
$badQuotes = 0
$lines = $verify -split "`n"
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '-Query\s+"') {
        Write-Host "WARNING: Line $($i+1) still has double quotes: $($lines[$i].Substring(0, [Math]::Min(80, $lines[$i].Length)))"
        $badQuotes++
    }
}

if ($badQuotes -eq 0) {
    Write-Host "All double-quoted SQL strings have been fixed!"
} else {
    Write-Host "Still have $badQuotes lines with double quotes"
}

# Try to parse the file to check for syntax errors
Write-Host "`nChecking PowerShell syntax..."
$errors = $null
$tokens = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($file, [ref]$tokens, [ref]$errors)
if ($errors.Count -eq 0) {
    Write-Host "No syntax errors found!"
} else {
    Write-Host "Found $($errors.Count) syntax errors:"
    $errors | Select-Object -First 10 | ForEach-Object {
        Write-Host "  Line $($_.Extent.StartLineNumber): $($_.Message)"
    }
}
