param($method, $path, $body)

if ($method -eq 'POST' -and $path -eq '/api/tasks/update') {
    $taskId = [int]$body.TaskID
    if ($taskId -le 0) { throw 'TaskID is required.' }
    Invoke-RepoNonQuery -Query 'EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;' -Parameters @{
        TaskID = $taskId
        TaskTitle = if ([string]::IsNullOrWhiteSpace([string]$body.Title)) { $null } else { [string]$body.Title }
        TaskDescription = if ([string]::IsNullOrWhiteSpace([string]$body.Description)) { $null } else { [string]$body.Description }
        AssignedTo = if ([string]::IsNullOrWhiteSpace([string]$body.AssignedTo)) { $null } else { [string]$body.AssignedTo }
        TaskStatusID = if ($body.Status) { 
            switch([string]$body.Status) { 
                'Open' {1} 
                'In Progress' {2} 
                'Pending' {3} 
                'Completed' {4} 
                'Cancelled' {5} 
                'On Hold' {6} 
                default {$null} 
            } 
        } else { $null }
        TaskPriorityID = if ($body.Priority) { 
            switch([string]$body.Priority) { 
                'Critical' {1} 
                'High' {2} 
                'Medium' {3} 
                'Low' {4} 
                default {3} 
            } 
        } else { $null }
        DueDate = if ($body.DueDate) { [datetime]$body.DueDate } else { $null }
        ModifiedBy = [string]$currentUser.UserName
    }
    Write-Host "Task updated: $taskId"
    return @{ ok = $true }
}
