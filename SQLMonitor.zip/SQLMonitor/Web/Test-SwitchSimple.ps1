$body = @{Status = 'Open'}
$TaskStatusID = if ($body.Status) { 
    switch([string]$body.Status) { 
        'Open' {1} 
        'In Progress' {2} 
        'Pending' {3} 
        'Completed' {4} 
        'Cancelled' {5} 
        'On Hold' {6} 
        default {$null} 
    } 
} else { $null }
Write-Host "Result: $TaskStatusID"
