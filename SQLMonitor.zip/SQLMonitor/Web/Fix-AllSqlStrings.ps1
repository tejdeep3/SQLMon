# Fix ALL double-quoted SQL strings in Start-WebServer.ps1
# These cause PowerShell syntax errors when @variables are used inside double quotes

$file = "Start-WebServer.ps1"
Write-Host "Reading file: $file"
$lines = Get-Content $file
Write-Host "Total lines: $($lines.Count)"

$fixedCount = 0

for ($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]
    
    # Check if line has -Query followed by double quote
    if ($line -match '-Query\s*"') {
        $originalLine = $line
        
        # Find the -Query parameter and fix the quotes
        # We need to change -Query "SQL" to -Query 'SQL'
        
        # Find position of -Query
        $queryPos = $line.IndexOf('-Query ')
        if ($queryPos -ge 0) {
            # Find the double quote after -Query
            $afterQuery = $line.Substring($queryPos + 7)  # Length of "-Query "
            $doubleQuotePos = $afterQuery.IndexOf('"')
            
            if ($doubleQuotePos -ge 0) {
                # Found double quote, now find the closing double quote
                $startOfString = $queryPos + 7 + $doubleQuotePos
                $closingQuotePos = $line.IndexOf('"', $startOfString + 1)
                
                if ($closingQuotePos -ge 0) {
                    # Replace opening double quote with single quote
                    $line = $line.Remove($startOfString, 1).Insert($startOfString, "'")
                    
                    # Replace closing double quote with single quote (position shifted by 1)
                    $closingQuotePos++  # Because we inserted a character
                    $line = $line.Remove($closingQuotePos, 1).Insert($closingQuotePos, "'")
                    
                    if ($line -ne $originalLine) {
                        $lines[$i] = $line
                        $fixedCount++
                        if ($fixedCount -le 10) {
                            Write-Host "Fixed line $($i+1): $($line.Substring(0, [Math]::Min(80, $line.Length)))..."
                        }
                    }
                }
            }
        }
    }
}

Write-Host "`nTotal lines fixed: $fixedCount"

if ($fixedCount -gt 0) {
    Write-Host "Saving file..."
    $lines | Set-Content $file -Encoding UTF8
    Write-Host "File saved!"
    
    # Verify the fixes
    Write-Host "`nVerifying fixes..."
    $verify = Get-Content $file
    $doubleQuoteCount = 0
    for ($i = 0; $i -lt $verify.Count; $i++) {
        if ($verify[$i] -match '-Query\s*"') {
            Write-Host "WARNING: Line $($i+1) still has double quotes: $($verify[$i].Substring(0, [Math]::Min(80, $verify[$i].Length)))"
            $doubleQuoteCount++
        }
    }
    
    if ($doubleQuoteCount -eq 0) {
        Write-Host "All double-quoted SQL strings have been fixed!"
    } else {
        Write-Host "Still have $doubleQuoteCount lines with double quotes"
    }
} else {
    Write-Host "No lines needed fixing"
}

# Also check for $query = "..." patterns
Write-Host "`nChecking for `$query = `"`" patterns..."
$queryPatternCount = 0
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\s*\$query\s*=\s*"') {
        Write-Host "Line $($i+1): $($lines[$i].Substring(0, [Math]::Min(80, $lines[$i].Length)))"
        $queryPatternCount++
    }
}

if ($queryPatternCount -gt 0) {
    Write-Host "Found $queryPatternCount lines with `$query = `"`" pattern"
    Write-Host "These might need to be fixed too if they contain @variables"
} else {
    Write-Host "No problematic `$query patterns found"
}
