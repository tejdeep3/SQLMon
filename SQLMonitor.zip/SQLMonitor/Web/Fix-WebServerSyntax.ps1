# Fix all double-quoted SQL strings in Start-WebServer.ps1
# These cause PowerShell splatting errors when @variable is used inside double quotes

$file = "Start-WebServer.ps1"
Write-Host "Reading file: $file"
$lines = Get-Content $file
Write-Host "Total lines: $($lines.Count)"

$fixedCount = 0

for ($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]
    
    # Check if line has Invoke-RepoNonQuery or Invoke-RepoNonQueryFast with double-quoted string
    if (($line -match 'Invoke-RepoNonQuery.*-Query.*"' -or $line -match 'Invoke-RepoNonQueryFast.*-Query.*"') -and $line -notmatch "-Query '") {
        
        # Replace double quotes with single quotes around the SQL query
        # Pattern: -Query "SQL" -> -Query 'SQL'
        $originalLine = $line
        
        # Find the -Query parameter and fix the quotes
        if ($line -match '-Query "') {
            # Replace -Query " with -Query '
            $line = $line -replace '-Query "', "-Query '"
            
            # Now find the closing double quote and replace with single quote
            # The SQL string ends with ;" or something similar
            $semiColonPos = $line.IndexOf(';"')
            if ($semiColonPos -ge 0) {
                $line = $line.Remove($semiColonPos, 2).Insert($semiColonPos, ";'")
            } else {
                # Try to find just the closing double quote
                $lastQuotePos = $line.LastIndexOf('"')
                if ($lastQuotePos -ge 0 -and $lastQuotePos -gt $line.IndexOf("-Query '")) {
                    $line = $line.Remove($lastQuotePos, 1).Insert($lastQuotePos, "'")
                }
            }
        }
        
        if ($line -ne $originalLine) {
            $lines[$i] = $line
            $fixedCount++
            Write-Host "Fixed line $($i+1): $($line.Substring(0, [Math]::Min(80, $line.Length)))..."
        }
    }
}

Write-Host "Total lines fixed: $fixedCount"

if ($fixedCount -gt 0) {
    Write-Host "Saving file..."
    $lines | Set-Content $file -Encoding UTF8
    Write-Host "File saved!"
    
    # Verify the fixes
    Write-Host "`nVerifying fixes..."
    $verify = Get-Content $file
    $doubleQuoteCount = 0
    for ($i = 0; $i -lt $verify.Count; $i++) {
        if ($verify[$i] -match 'Invoke-RepoNonQuery.*-Query "' -or $verify[$i] -match 'Invoke-RepoNonQueryFast.*-Query "') {
            Write-Host "WARNING: Line $($i+1) still has double quotes: $($verify[$i].Substring(0, [Math]::Min(80, $verify[$i].Length)))"
            $doubleQuoteCount++
        }
    }
    
    if ($doubleQuoteCount -eq 0) {
        Write-Host "All double-quoted SQL strings have been fixed!"
    } else {
        Write-Host "Still have $doubleQuoteCount lines with double quotes"
    }
} else {
    Write-Host "No lines needed fixing"
}
