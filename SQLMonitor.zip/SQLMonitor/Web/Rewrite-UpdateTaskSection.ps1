# Rewrite the UpdateTask section in Start-WebServer.ps1
# The issue is that the TaskStatusID and TaskPriorityID lines are malformed

$file = "Start-WebServer.ps1"
Write-Host "Reading file: $file"
$content = Get-Content $file -Raw
Write-Host "File length: $($content.Length) characters"

# Find the UpdateTask section
$updateTaskPattern = "usp_UpdateTask"
$idx = $content.IndexOf($updateTaskPattern)
if ($idx -eq -1) {
    Write-Host "ERROR: Could not find UpdateTask section"
    exit 1
}

Write-Host "Found UpdateTask at index: $idx"

# Find the start of the UpdateTask block (look for the if statement before it)
$searchStart = $content.LastIndexOf("`n", $idx) + 1
$blockStart = $content.LastIndexOf("`n    }`n    if (`$method -eq 'POST' -and `$path -eq '/api/tasks/update')", $idx)
if ($blockStart -eq -1) {
    Write-Host "ERROR: Could not find start of UpdateTask block"
    exit 1
}

# Find the end of the UpdateTask block (look for the next if statement or closing brace)
$blockEnd = $content.IndexOf("`n    }`n    # -----", $idx)
if ($blockEnd -eq -1) {
    Write-Host "ERROR: Could not find end of UpdateTask block"
    exit 1
}

$blockEnd += "`n    }`n    # -----".Length

Write-Host "Block start: $blockStart, Block end: $blockEnd"
Write-Host "Block length: $($blockEnd - $blockStart) characters"

# Get the original block
$originalBlock = $content.Substring($blockStart, $blockEnd - $blockStart)
Write-Host "`nOriginal block:"
Write-Host $originalBlock

# Create the new, properly formatted block
$newBlock = @"
    if (`$method -eq 'POST' -and `$path -eq '/api/tasks/update') {
        `$body = Read-RequestJson -Request `$Request
        `$taskId = [int]`$body.TaskID
        if (`$taskId -le 0) { throw 'TaskID is required.' }
        Invoke-RepoNonQuery -Query 'EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;' -Parameters @{
            TaskID = `$taskId
            TaskTitle = if ([string]::IsNullOrWhiteSpace([string]`$body.Title)) { `$null } else { [string]`$body.Title }
            TaskDescription = if ([string]::IsNullOrWhiteSpace([string]`$body.Description)) { `$null } else { [string]`$body.Description }
            AssignedTo = if ([string]::IsNullOrWhiteSpace([string]`$body.AssignedTo)) { `$null } else { [string]`$body.AssignedTo }
            TaskStatusID = if (`$body.Status) { 
                switch([string]`$body.Status) { 
                    'Open' {1} 
                    'In Progress' {2} 
                    'Pending' {3} 
                    'Completed' {4} 
                    'Cancelled' {5} 
                    'On Hold' {6} 
                    default {`$null} 
                } 
            } else { `$null }
            TaskPriorityID = if (`$body.Priority) { 
                switch([string]`$body.Priority) { 
                    'Critical' {1} 
                    'High' {2} 
                    'Medium' {3} 
                    'Low' {4} 
                    default {3} 
                } 
            } else { `$null }
            DueDate = if (`$body.DueDate) { [datetime]`$body.DueDate } else { `$null }
            ModifiedBy = [string]`$currentUser.UserName
        }
        Write-DashboardAudit -User `$currentUser -ActionName 'UpdateTask' -Details "TaskID `$taskId"
        return @{ ok = `$true }
    }
"@

Write-Host "`nNew block:"
Write-Host $newBlock

# Replace the block
$newContent = $content.Remove($blockStart, $blockEnd - $blockStart).Insert($blockStart, $newBlock)
Set-Content $file -Value $newContent -Encoding UTF8
Write-Host "`nFile saved!"

# Verify the fix
Write-Host "`nVerifying..."
$verify = Get-Content $file -Raw
$errors = $null
$tokens = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($file, [ref]$tokens, [ref]$errors)
if ($errors.Count -eq 0) {
    Write-Host "No syntax errors found!"
} else {
    Write-Host "Found $($errors.Count) syntax errors:"
    $errors | ForEach-Object { Write-Host "  Line $($_.Extent.StartLineNumber): $($_.Message)" }
}
