# Fix-StartWebServer.ps1
# Script to fix all syntax issues in Start-WebServer.ps1

$filePath = Join-Path $PSScriptRoot "Start-WebServer.ps1"
$backupPath = Join-Path $PSScriptRoot "Start-WebServer.ps1.backup"

# Read the backup file
Write-Host "Reading backup file..."
$content = Get-Content $backupPath -Raw
Write-Host "File read: $($content.Length) characters"

# Fix 1: Replace malformed query strings that have "'-Parameters" with proper syntax
# These are queries where the closing quote is before -Parameters
Write-Host "Fixing malformed query strings..."
$content = $content -replace "ORDER BY AlertTime DESC;""'-Parameters", "ORDER BY AlertTime DESC;' -Parameters"
$content = $content -replace "ORDER BY CaptureTime DESC;""'-Parameters", "ORDER BY CaptureTime DESC;' -Parameters"

# Fix 2: Fix the CreateTask section - ensure proper -Parameters syntax
Write-Host "Fixing CreateTask section..."
$content = $content -replace "(usp_CreateTask.*@DueDate); -Parameters", '$1;'' -Parameters'

# Fix 3: Fix UpdateTask sections - compute values before hashtable
# Find all UpdateTask sections and fix them
Write-Host "Fixing UpdateTask sections..."

# Pattern to match the entire UpdateTask block
$updateTaskPattern = '(if \(\$method -eq ''POST'' -and \$path -eq ''/api/tasks/update''\) \{\s*\$body = Read-RequestJson -Request \$Request\s*\$taskId = \[int\]\$body\.TaskID\s*if \(\$taskId -le 0\) \{ throw ''TaskID is required\.'' \}\s*Invoke-RepoNonQuery -Query ''EXEC mon\.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;'' -Parameters \{\s*TaskID = \$taskId\s*TaskTitle = .*?\s*TaskDescription = .*?\s*AssignedTo = .*?\s*)(TaskStatusID = if \(\$body\.Status\) \{\s*switch\(\[string\]\$body\.Status\) \{\s*''Open'' \{1\}\s*''In Progress'' \{2\}\s*''Pending'' \{3\}\s*''Completed'' \{4\}\s*''Cancelled'' \{5\}\s*''On Hold'' \{6\}\s*default \{\$null\}\s*\}\s*\} else \{ \$null \}\s*)(TaskPriorityID = if \(\$body\.Priority\) \{\s*switch\(\[string\]\$body\.Priority\) \{\s*''Low'' \{1\}\s*''Medium'' \{2\}\s*''High'' \{3\}\s*''Critical'' \{4\}\s*default \{\$null\}\s*\}\s*\} else \{ \$null \}\s*)(DueDate = if \(\$body\.DueDate\) \{\s*try \{ \[DateTime\]::Parse\(\[string\]\$body\.DueDate\)\.ToString\(''yyyy-MM-dd''\) \} catch \{ \$null \}\s*\} else \{ \$null \}\s*ModifiedBy = .*?\s*\})'

# Replace with fixed version that computes values before hashtable
$fixedUpdateTask = '$1' + '
        # Compute derived values before building the parameter hashtable
        $taskStatusId = if ($body.Status) {
            switch ([string]$body.Status) {
                ''Open'' { 1 }
                ''In Progress'' { 2 }
                ''Pending'' { 3 }
                ''Completed'' { 4 }
                ''Cancelled'' { 5 }
                ''On Hold'' { 6 }
                default { $null }
            }
        } else { $null }

        $taskPriorityId = if ($body.Priority) {
            switch ([string]$body.Priority) {
                ''Low'' { 1 }
                ''Medium'' { 2 }
                ''High'' { 3 }
                ''Critical'' { 4 }
                default { $null }
            }
        } else { $null }

        $dueDate = if ($body.DueDate) {
            try { [DateTime]::Parse([string]$body.DueDate).ToString(''yyyy-MM-dd'') } catch { $null }
        } else { $null }
' + '$2' + '
            TaskStatusID = $taskStatusId
            TaskPriorityID = $taskPriorityId
            DueDate = $dueDate
            ModifiedBy = if ([string]::IsNullOrWhiteSpace([string]$body.ModifiedBy)) { ''WebDashboard'' } else { [string]$body.ModifiedBy }
        }'

# Apply the fix
$content = [regex]::Replace($content, $updateTaskPattern, $fixedUpdateTask, [System.Text.RegularExpressions.RegexOptions]::Singleline)

# Save the fixed content
Write-Host "Saving fixed file..."
Set-Content -Path $filePath -Value $content -Encoding UTF8
Write-Host "File saved. New length: $((Get-Content $filePath -Raw).Length) characters"

# Verify the fix
Write-Host "Verifying fix..."
$fixedContent = Get-Content $filePath -Raw
$updateTaskCount = ([regex]::Matches($fixedContent, "switch\(\[string\]\\\$body\.Status\)")).Count
Write-Host "Found $updateTaskCount switch statements in UpdateTask sections"

# Check for syntax errors
Write-Host "Checking for syntax errors..."
$errors = @()
$tokens = [System.Management.Automation.PSParser]::Tokenize($fixedContent, [ref]$errors)
if ($errors.Count -gt 0) {
    Write-Host "Found $($errors.Count) syntax errors:"
    $errors | ForEach-Object { Write-Host "  Line $($_.Token.StartLine): $($_.Message)" }
} else {
    Write-Host "No syntax errors found!"
}
