param($x)
$body = @{Status='Open'}
$taskStatusId = if ($body.Status) {
    switch ([string]$body.Status) {
        'Open' { 1 }
        'In Progress' { 2 }
        default { $null }
    }
} else { $null }
Write-Host "TaskStatusId: $taskStatusId"
