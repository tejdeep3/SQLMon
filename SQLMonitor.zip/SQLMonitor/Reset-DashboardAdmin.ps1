param(
    [string]$RepositoryServer = "",
    [string]$RepositoryDatabase = "DBA_SQLMonitor",
    [string]$UserName = "admin",
    [string]$NewPassword = "Admin@123",
    [string]$DisplayName = "Dashboard Administrator"
)

$ErrorActionPreference = "Stop"

function New-PasswordSalt {
    $salt = New-Object byte[] 16
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($salt) }
    finally { $rng.Dispose() }
    return ,$salt
}

function Get-PasswordHashBytes {
    param([string]$Password, [byte[]]$Salt)
    $passwordBytes = [System.Text.Encoding]::Unicode.GetBytes($Password)
    $combined = New-Object byte[] ($Salt.Length + $passwordBytes.Length)
    [System.Buffer]::BlockCopy($Salt, 0, $combined, 0, $Salt.Length)
    [System.Buffer]::BlockCopy($passwordBytes, 0, $combined, $Salt.Length, $passwordBytes.Length)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return ,$sha.ComputeHash($combined) }
    finally { $sha.Dispose() }
}

function Add-SqlParameter {
    param(
        [System.Data.SqlClient.SqlCommand]$Command,
        [string]$Name,
        [object]$Value
    )

    if ($null -eq $Value) { $Value = [DBNull]::Value }
    if ($Value -is [byte[]]) {
        $parameter = $Command.Parameters.Add("@$Name", [System.Data.SqlDbType]::VarBinary, $Value.Length)
        $parameter.Value = $Value
        return
    }
    [void]$Command.Parameters.AddWithValue("@$Name", $Value)
}

if ([string]::IsNullOrWhiteSpace($RepositoryServer)) {
    $commonModule = Join-Path $PSScriptRoot "Modules\Common.psm1"
    if (Test-Path -LiteralPath $commonModule -PathType Leaf) {
        Import-Module $commonModule -Force -WarningAction SilentlyContinue
        $settings = Get-SqlMonitorRepositorySettings
        $RepositoryServer = $settings.RepositoryServer
        if ([string]::IsNullOrWhiteSpace($RepositoryDatabase)) { $RepositoryDatabase = $settings.RepositoryDatabase }
    }
}

if ([string]::IsNullOrWhiteSpace($RepositoryServer)) { throw "RepositoryServer is required." }
if ([string]::IsNullOrWhiteSpace($RepositoryDatabase)) { $RepositoryDatabase = "DBA_SQLMonitor" }
if ([string]::IsNullOrWhiteSpace($UserName)) { throw "UserName is required." }
if ([string]::IsNullOrWhiteSpace($NewPassword)) { throw "NewPassword is required." }

$salt = New-PasswordSalt
$hash = Get-PasswordHashBytes -Password $NewPassword -Salt $salt

$query = @"
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');

IF OBJECT_ID('mon.DashboardUsers', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUsers (
        UserID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardUsers PRIMARY KEY,
        UserName NVARCHAR(128) NOT NULL,
        DisplayName NVARCHAR(200) NULL,
        EmailAddress NVARCHAR(256) NULL,
        PhoneNumber NVARCHAR(20) NULL,
        Department NVARCHAR(100) NULL,
        PasswordSalt VARBINARY(16) NOT NULL,
        PasswordHash VARBINARY(32) NOT NULL,
        RoleName NVARCHAR(20) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_DashboardUsers_IsActive DEFAULT (1),
        MustChangePassword BIT NOT NULL CONSTRAINT DF_DashboardUsers_MustChangePassword DEFAULT (0),
        FailedLoginCount INT NOT NULL CONSTRAINT DF_DashboardUsers_FailedLoginCount DEFAULT (0),
        LastFailedLoginAt DATETIME2(0) NULL,
        LockoutUntil DATETIME2(0) NULL,
        PasswordChangedAt DATETIME2(0) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUsers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastLoginAt DATETIME2(0) NULL,
        CONSTRAINT UQ_DashboardUsers_UserName UNIQUE (UserName),
        CONSTRAINT CK_DashboardUsers_RoleName CHECK (RoleName IN ('Admin', 'AppOwner', 'ViewOnly', 'Limited'))
    );
END;

IF COL_LENGTH('mon.DashboardUsers', 'FailedLoginCount') IS NULL ALTER TABLE mon.DashboardUsers ADD FailedLoginCount INT NOT NULL CONSTRAINT DF_DashboardUsers_FailedLoginCount_Reset DEFAULT (0);
IF COL_LENGTH('mon.DashboardUsers', 'LastFailedLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastFailedLoginAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'LockoutUntil') IS NULL ALTER TABLE mon.DashboardUsers ADD LockoutUntil DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'PasswordChangedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD PasswordChangedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'UpdatedAt') IS NULL ALTER TABLE mon.DashboardUsers ADD UpdatedAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'LastLoginAt') IS NULL ALTER TABLE mon.DashboardUsers ADD LastLoginAt DATETIME2(0) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'EmailAddress') IS NULL ALTER TABLE mon.DashboardUsers ADD EmailAddress NVARCHAR(256) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'PhoneNumber') IS NULL ALTER TABLE mon.DashboardUsers ADD PhoneNumber NVARCHAR(20) NULL;
IF COL_LENGTH('mon.DashboardUsers', 'Department') IS NULL ALTER TABLE mon.DashboardUsers ADD Department NVARCHAR(100) NULL;

IF EXISTS (SELECT 1 FROM mon.DashboardUsers WHERE UserName = @UserName)
BEGIN
    UPDATE mon.DashboardUsers
    SET DisplayName = COALESCE(NULLIF(@DisplayName, N''), DisplayName),
        PasswordSalt = @PasswordSalt,
        PasswordHash = @PasswordHash,
        RoleName = N'Admin',
        IsActive = 1,
        MustChangePassword = 1,
        FailedLoginCount = 0,
        LastFailedLoginAt = NULL,
        LockoutUntil = NULL,
        PasswordChangedAt = SYSDATETIME(),
        UpdatedAt = SYSDATETIME()
    WHERE UserName = @UserName;
END
ELSE
BEGIN
    INSERT INTO mon.DashboardUsers
        (UserName, DisplayName, PasswordSalt, PasswordHash, RoleName, IsActive, MustChangePassword, PasswordChangedAt)
    VALUES
        (@UserName, @DisplayName, @PasswordSalt, @PasswordHash, N'Admin', 1, 1, SYSDATETIME());
END;
"@

$connectionString = "Server=$RepositoryServer;Database=$RepositoryDatabase;Integrated Security=True;TrustServerCertificate=True;"
$connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
$command = $connection.CreateCommand()
$command.CommandText = $query
$command.CommandTimeout = 120
Add-SqlParameter -Command $command -Name "UserName" -Value $UserName
Add-SqlParameter -Command $command -Name "DisplayName" -Value $DisplayName
Add-SqlParameter -Command $command -Name "PasswordSalt" -Value $salt
Add-SqlParameter -Command $command -Name "PasswordHash" -Value $hash

try {
    $connection.Open()
    [void]$command.ExecuteNonQuery()
    Write-Host "Dashboard admin login repaired for '$UserName' on $RepositoryServer / $RepositoryDatabase." -ForegroundColor Green
    Write-Host "Temporary password: $NewPassword" -ForegroundColor Yellow
    Write-Host "The user must change the password after login." -ForegroundColor Yellow
}
finally {
    $connection.Close()
    $connection.Dispose()
}
