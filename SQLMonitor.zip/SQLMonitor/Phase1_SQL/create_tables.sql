USE DBA_SQLMonitor;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');
GO

CREATE TABLE mon.MonitoredInstances
(
    InstanceID            INT IDENTITY(1,1) PRIMARY KEY,
    ServerName            NVARCHAR(128) NOT NULL,
    InstanceName          NVARCHAR(128) NULL,
    DisplayName           NVARCHAR(200) NOT NULL,
    EnvironmentName       NVARCHAR(50) NULL,
    IsActive              BIT NOT NULL DEFAULT 1,
    CreatedOn             DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
GO

CREATE TABLE mon.CollectionRuns
(
    RunID                 BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    ModuleName            NVARCHAR(100) NOT NULL,
    StartTime             DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    EndTime               DATETIME2 NULL,
    Status                NVARCHAR(20) NOT NULL DEFAULT 'Started',
    ErrorMessage          NVARCHAR(MAX) NULL
);
GO

CREATE TABLE mon.CPUHistory
(
    CPUHistoryID          BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    SqlCPUPercent         DECIMAL(5,2) NULL,
    OtherCPUPercent       DECIMAL(5,2) NULL,
    IdleCPUPercent        DECIMAL(5,2) NULL
);
GO

CREATE TABLE mon.MemoryHistory
(
    MemoryHistoryID       BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    TotalPhysicalMB       BIGINT NULL,
    AvailablePhysicalMB   BIGINT NULL,
    SqlMemoryUsedGB       DECIMAL(18,2) NULL,
    PLESeconds            BIGINT NULL,
    BufferCacheHitRatio   DECIMAL(10,2) NULL
);
GO

CREATE TABLE mon.DiskVolumeHistory
(
    DiskHistoryID         BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    VolumeMountPoint      NVARCHAR(260) NOT NULL,
    LogicalVolumeName     NVARCHAR(260) NULL,
    TotalGB               DECIMAL(18,2) NULL,
    FreeGB                DECIMAL(18,2) NULL,
    UsedGB                DECIMAL(18,2) NULL,
    UsedPct               DECIMAL(6,2) NULL
);
GO

CREATE TABLE mon.IOFileHistory
(
    IOHistoryID           BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    DatabaseName          SYSNAME NULL,
    FileType              NVARCHAR(10) NULL,
    LogicalName           SYSNAME NULL,
    PhysicalName          NVARCHAR(260) NULL,
    SizeMB                DECIMAL(18,2) NULL,
    AvgReadMS             DECIMAL(18,2) NULL,
    AvgWriteMS            DECIMAL(18,2) NULL,
    TotalStallMS          BIGINT NULL
);
GO

CREATE TABLE mon.TempDBHistory
(
    TempDBHistoryID       BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    FileType              NVARCHAR(10) NULL,
    LogicalName           SYSNAME NULL,
    PhysicalName          NVARCHAR(260) NULL,
    SizeMB                DECIMAL(18,2) NULL,
    UsedMB                DECIMAL(18,2) NULL,
    PercentFull           DECIMAL(6,2) NULL,
    TempDBDataFileCount   INT NULL,
    RecommendedFileCount  INT NULL
);
GO

CREATE TABLE mon.BackupStatusHistory
(
    BackupHistoryID       BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    DatabaseName          SYSNAME NOT NULL,
    LastFullHours         INT NULL,
    LastDiffHours         INT NULL,
    LastLogHours          INT NULL,
    StatusText            NVARCHAR(50) NULL
);
GO

CREATE TABLE mon.BlockingHistory
(
    BlockingHistoryID     BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    SessionID             INT NULL,
    BlockingSessionID     INT NULL,
    DatabaseName          SYSNAME NULL,
    WaitType              NVARCHAR(120) NULL,
    WaitTimeMS            BIGINT NULL,
    LoginName             NVARCHAR(128) NULL,
    HostName              NVARCHAR(128) NULL,
    CommandText           NVARCHAR(64) NULL,
    StatementText         NVARCHAR(MAX) NULL
);
GO

CREATE TABLE mon.LongRunningHistory
(
    LongRunHistoryID      BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    CaptureTime           DATETIME2 NOT NULL,
    SessionID             INT NULL,
    DatabaseName          SYSNAME NULL,
    StartTime             DATETIME2 NULL,
    DurationMinutes       INT NULL,
    StatusText            NVARCHAR(60) NULL,
    WaitType              NVARCHAR(120) NULL,
    CPUms                 BIGINT NULL,
    Reads                 BIGINT NULL,
    Writes                BIGINT NULL,
    CommandText           NVARCHAR(64) NULL,
    StatementText         NVARCHAR(MAX) NULL
);
GO

CREATE TABLE mon.AlertHistory
(
    AlertID               BIGINT IDENTITY(1,1) PRIMARY KEY,
    InstanceID            INT NOT NULL,
    AlertTime             DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    Severity              NVARCHAR(20) NOT NULL,
    ModuleName            NVARCHAR(100) NOT NULL,
    AlertTitle            NVARCHAR(300) NOT NULL,
    AlertDetails          NVARCHAR(MAX) NULL,
    IsAcknowledged        BIT NOT NULL DEFAULT 0,
    AcknowledgedBy        NVARCHAR(128) NULL,
    AcknowledgedOn        DATETIME2 NULL
);
GO

CREATE TABLE mon.AlertThresholds
(
    ThresholdID           INT IDENTITY(1,1) PRIMARY KEY,
    ModuleName            NVARCHAR(100) NOT NULL,
    MetricName            NVARCHAR(100) NOT NULL,
    WarningValue          DECIMAL(18,2) NULL,
    CriticalValue         DECIMAL(18,2) NULL,
    IsActive              BIT NOT NULL DEFAULT 1
);
GO