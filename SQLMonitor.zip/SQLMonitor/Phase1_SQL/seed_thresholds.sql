USE DBA_SQLMonitor;
GO

INSERT INTO mon.AlertThresholds (ModuleName, MetricName, WarningValue, CriticalValue, IsActive)
SELECT 'CPU', 'SqlCPUPercent', 70, 85, 1
WHERE NOT EXISTS (
    SELECT 1 FROM mon.AlertThresholds WHERE ModuleName = 'CPU' AND MetricName = 'SqlCPUPercent'
);

INSERT INTO mon.AlertThresholds (ModuleName, MetricName, WarningValue, CriticalValue, IsActive)
SELECT 'Memory', 'AvailablePhysicalMB', 8192, 4096, 1
WHERE NOT EXISTS (
    SELECT 1 FROM mon.AlertThresholds WHERE ModuleName = 'Memory' AND MetricName = 'AvailablePhysicalMB'
);

INSERT INTO mon.AlertThresholds (ModuleName, MetricName, WarningValue, CriticalValue, IsActive)
SELECT 'Memory', 'PLESeconds', 3000, 1000, 1
WHERE NOT EXISTS (
    SELECT 1 FROM mon.AlertThresholds WHERE ModuleName = 'Memory' AND MetricName = 'PLESeconds'
);
GO