USE DBA_SQLMonitor;
GO

INSERT INTO mon.MonitoredInstances
(
    ServerName,
    InstanceName,
    DisplayName,
    EnvironmentName,
    IsActive
)
VALUES
(
    N'BBLBHLAP860',
    N'BBDBTESTSQL',
    N'BBLBHLAP860\BBDBTESTSQL',
    N'Production',
    1
);
GO