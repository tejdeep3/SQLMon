-- Check the actual parameters for usp_RecordEscalation
SELECT PARAMETER_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.PARAMETERS
WHERE SPECIFIC_SCHEMA = 'mon' 
  AND SPECIFIC_NAME = 'usp_RecordEscalation'
ORDER BY ORDINAL_POSITION;

-- Get the procedure definition to see what it expects
SELECT OBJECT_DEFINITION(OBJECT_ID('mon.usp_RecordEscalation')) AS ProcDef;
