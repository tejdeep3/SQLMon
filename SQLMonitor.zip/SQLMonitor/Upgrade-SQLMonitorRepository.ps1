param(
    [string]$RepositoryServer = "",
    [string]$RepositoryDatabase = "",
    [string]$InstallPath = (Split-Path -Parent $MyInvocation.MyCommand.Path),
    [string[]]$MonitoredInstances = @(),
    [switch]$UpdateSqlAgentJobs,
    [switch]$ConfigurePerInstanceJobs,
    [switch]$ConfigureWindowsTasks,
    [ValidateSet("System", "CurrentUser")]
    [string]$WindowsTaskRunAs = "System",
    [int]$WebDashboardPort = 8090,
    [switch]$Json
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DeployScript = Join-Path $ProjectRoot "Deploy-SQLMonitor.ps1"

Import-Module (Join-Path $ProjectRoot "Modules\Common.psm1") -Force -WarningAction SilentlyContinue

function Write-UpgradeLog {
    param([string]$Message, [string]$Level = "Info")
    if ($Json) { return }
    $color = switch ($Level) {
        "Success" { "Green" }
        "Warning" { "Yellow" }
        "Error" { "Red" }
        default { "Gray" }
    }
    Write-Host $Message -ForegroundColor $color
}

function New-UpgradeSqlConnection {
    param([string]$Database)
    $connectionString = "Server=$RepositoryServer;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    return New-Object System.Data.SqlClient.SqlConnection $connectionString
}

function Invoke-UpgradeScalar {
    param([string]$Database, [string]$Query, [hashtable]$Parameters = @{})
    $connection = New-UpgradeSqlConnection -Database $Database
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = 30
    foreach ($key in $Parameters.Keys) {
        [void]$command.Parameters.AddWithValue("@$key", $Parameters[$key])
    }
    try {
        $connection.Open()
        return $command.ExecuteScalar()
    }
    finally {
        $connection.Dispose()
    }
}

function Get-ConfiguredInstanceNames {
    $path = Join-Path $ProjectRoot "Config\instances.json"
    if (-not (Test-Path $path)) { return @() }
    try {
        $instances = @(Get-Content -Path $path -Raw | ConvertFrom-Json)
        return @($instances | Where-Object { $_.SqlInstance } | ForEach-Object { [string]$_.SqlInstance })
    }
    catch {
        Write-UpgradeLog "Could not read configured instances from ${path}: $($_.Exception.Message)" "Warning"
        return @()
    }
}

function Get-ExpectedRepositorySchema {
    return @(
        [pscustomobject]@{ ObjectName = "mon.MonitoredInstances"; ObjectType = "Table"; RequiredColumns = @("InstanceID","ServerName","InstanceName","DisplayName","EnvironmentName","IsActive") },
        [pscustomobject]@{ ObjectName = "mon.CollectionRuns"; ObjectType = "Table"; RequiredColumns = @("RunID","InstanceID","ModuleName","StartTime","EndTime","Status","ErrorMessage") },
        [pscustomobject]@{ ObjectName = "mon.CPUHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","SqlCPUPercent","OtherCPUPercent","IdleCPUPercent") },
        [pscustomobject]@{ ObjectName = "mon.MemoryHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","TotalPhysicalMB","AvailablePhysicalMB","SqlMemoryUsedGB","PLESeconds","BufferCacheHitRatio") },
        [pscustomobject]@{ ObjectName = "mon.KPIHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","PageLifeExpectancy","BufferCacheHitRatio","AvailablePhysicalMemoryMB","TotalPhysicalMemoryMB","ProcessMemoryMB","VisibleOnlineCPUs","MaxDOP","CostThresholdForParallelism") },
        [pscustomobject]@{ ObjectName = "mon.ConfigHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","MachineName","InstanceName","ServerVersion","Edition","ProcessorCount","PhysicalMemoryMB","MaxDOPSetting","CostThresholdSetting") },
        [pscustomobject]@{ ObjectName = "mon.DBOptionsHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","DatabaseName","State","RecoveryModel","PageVerify","IsAutoClose","IsAutoShrink","SizeMB","AvailableSpaceMB","LogSizeMB","MDFUsedMB","LDFUsedMB") },
        [pscustomobject]@{ ObjectName = "mon.DiskVolumeHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","VolumeMountPoint","LogicalVolumeName","TotalGB","FreeGB","UsedGB","UsedPct") },
        [pscustomobject]@{ ObjectName = "mon.IOFileHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","DatabaseName","FileType","LogicalName","PhysicalName","SizeMB","AvgReadMS","AvgWriteMS","TotalStallMS") },
        [pscustomobject]@{ ObjectName = "mon.TempDBHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","FileType","LogicalName","PhysicalName","SizeMB","UsedMB","PercentFull","TempDBDataFileCount") },
        [pscustomobject]@{ ObjectName = "mon.BackupStatusHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","DatabaseName","LastFullHours","LastDiffHours","LastLogHours") },
        [pscustomobject]@{ ObjectName = "mon.AlertHistory"; ObjectType = "Table"; RequiredColumns = @("AlertID","InstanceID","AlertTime","Severity","ModuleName","AlertTitle","AlertDetails","IsAcknowledged","AcknowledgedBy","AcknowledgedOn") },
        [pscustomobject]@{ ObjectName = "mon.ExecutionPlansHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","SessionId","SqlText","QueryPlanXml","Recommendations") },
        [pscustomobject]@{ ObjectName = "mon.MemoryClerksHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","Type","Name","PagesKB","PressureLevel","Recommendations") },
        [pscustomobject]@{ ObjectName = "mon.BufferPoolAnalysisHistory"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CaptureTime","DatabaseName","SizeMB","PageCount","Recommendations") },
        [pscustomobject]@{ ObjectName = "mon.DashboardUsers"; ObjectType = "Table"; RequiredColumns = @("UserID","UserName","DisplayName","PasswordHash","PasswordSalt","RoleName","IsActive","MustChangePassword","FailedLoginCount","LastFailedLoginAt","LockoutUntil","PasswordChangedAt") },
        [pscustomobject]@{ ObjectName = "mon.DashboardUserInstanceAccess"; ObjectType = "Table"; RequiredColumns = @("UserID","InstanceID") },
        [pscustomobject]@{ ObjectName = "mon.DashboardAuditLog"; ObjectType = "Table"; RequiredColumns = @("AuditID","UserID","UserName","ActionName","Details","ClientHost","CreatedAt") },
        [pscustomobject]@{ ObjectName = "dbo.WaitStats"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CollectionDateTime","WaitType","WaitingTasksCount","WaitTimeMs","SignalWaitTimeMs") },
        [pscustomobject]@{ ObjectName = "dbo.TopQueries"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CollectionDateTime","QueryID","QueryText","AvgCpuTime","AvgDuration","AvgLogicalIOReads","CountExecutions") },
        [pscustomobject]@{ ObjectName = "dbo.MissingIndexes"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CollectionDateTime","DatabaseName","ObjectName","EqualityColumns","IncludedColumns","ImprovementMeasure") },
        [pscustomobject]@{ ObjectName = "dbo.IndexFragmentation"; ObjectType = "Table"; RequiredColumns = @("InstanceID","CollectionDateTime","DatabaseName","ObjectName","IndexName","AvgFragmentationPercent") },
        [pscustomobject]@{ ObjectName = "mon.vw_Overview"; ObjectType = "View"; RequiredColumns = @() },
        [pscustomobject]@{ ObjectName = "mon.vw_LatestOverview"; ObjectType = "View"; RequiredColumns = @() },
        [pscustomobject]@{ ObjectName = "mon.vw_OpenAlertsDetailed"; ObjectType = "View"; RequiredColumns = @() },
        [pscustomobject]@{ ObjectName = "mon.vw_AlertHistoryDetailed"; ObjectType = "View"; RequiredColumns = @() },
        [pscustomobject]@{ ObjectName = "mon.vw_CollectionHealth"; ObjectType = "View"; RequiredColumns = @() },
        [pscustomobject]@{ ObjectName = "mon.vw_InstanceHealthSummary"; ObjectType = "View"; RequiredColumns = @() },
        [pscustomobject]@{ ObjectName = "mon.usp_AcknowledgeAlert"; ObjectType = "Procedure"; RequiredColumns = @() },
        [pscustomobject]@{ ObjectName = "mon.usp_PurgeRetention"; ObjectType = "Procedure"; RequiredColumns = @() }
    )
}

function Test-RepositorySchema {
    param([string]$Phase)
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($item in Get-ExpectedRepositorySchema) {
        try {
            $exists = [int](Invoke-UpgradeScalar -Database $RepositoryDatabase -Query "SELECT CASE WHEN OBJECT_ID(@ObjectName) IS NULL THEN 0 ELSE 1 END;" -Parameters @{ ObjectName = $item.ObjectName })
            if ($exists -ne 1) {
                $rows.Add([pscustomobject]@{ Phase = $Phase; ObjectName = $item.ObjectName; ObjectType = $item.ObjectType; Status = "MissingObject"; MissingColumns = "" })
                continue
            }

            $missingColumns = @()
            foreach ($column in @($item.RequiredColumns)) {
                $columnExists = [int](Invoke-UpgradeScalar -Database $RepositoryDatabase -Query "SELECT CASE WHEN COL_LENGTH(@ObjectName, @ColumnName) IS NULL THEN 0 ELSE 1 END;" -Parameters @{ ObjectName = $item.ObjectName; ColumnName = $column })
                if ($columnExists -ne 1) { $missingColumns += $column }
            }

            $rows.Add([pscustomobject]@{
                Phase          = $Phase
                ObjectName     = $item.ObjectName
                ObjectType     = $item.ObjectType
                Status         = if ($missingColumns.Count -gt 0) { "MissingColumns" } else { "Ready" }
                MissingColumns = ($missingColumns -join ", ")
            })
        }
        catch {
            $rows.Add([pscustomobject]@{ Phase = $Phase; ObjectName = $item.ObjectName; ObjectType = $item.ObjectType; Status = "CheckFailed"; MissingColumns = $_.Exception.Message })
        }
    }
    return @($rows)
}

function Get-SqlAgentJobStatus {
    try {
        $jobCount = Invoke-UpgradeScalar -Database "msdb" -Query "SELECT COUNT(*) FROM dbo.sysjobs WHERE name LIKE N'SQLMonitor - %';"
        return [pscustomobject]@{ Check = "SQL Agent Jobs"; Status = if ([int]$jobCount -gt 0) { "Ready" } else { "Missing" }; Detail = "$jobCount SQLMonitor jobs found" }
    }
    catch {
        return [pscustomobject]@{ Check = "SQL Agent Jobs"; Status = "CheckFailed"; Detail = $_.Exception.Message }
    }
}

function Invoke-DeploymentUpgrade {
    if (-not (Test-Path $DeployScript)) {
        throw "Deployment script not found: $DeployScript"
    }

    $arguments = @(
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", $DeployScript,
        "-RepositoryServer", $RepositoryServer,
        "-RepositoryDatabase", $RepositoryDatabase,
        "-InstallPath", $InstallPath,
        "-DeployDatabase",
        "-DeployScripts",
        "-SkipInstanceConfiguration",
        "-WebDashboardPort", ([string]$WebDashboardPort),
        "-Force"
    )

    if ($UpdateSqlAgentJobs) { $arguments += "-ConfigureSqlAgentJobs" }
    if ($MonitoredInstances.Count -gt 0) {
        $arguments += "-MonitoredInstances"
        foreach ($instanceName in $MonitoredInstances) { $arguments += $instanceName }
    }
    if ($ConfigurePerInstanceJobs) {
        $arguments += "-ConfigurePerInstanceJobs"
    }
    if ($ConfigureWindowsTasks) {
        $arguments += "-ConfigureWindowsTasks"
        $arguments += "-WindowsTaskRunAs"
        $arguments += $WindowsTaskRunAs
    }

    Write-UpgradeLog "Running self-healing repository upgrade..."
    if ($Json) {
        $deployOutput = & powershell.exe @arguments 2>&1
        if ($LASTEXITCODE -ne 0) {
            throw "Repository upgrade failed with exit code $LASTEXITCODE. $($deployOutput -join [Environment]::NewLine)"
        }
        return ($deployOutput -join [Environment]::NewLine)
    }
    else {
        & powershell.exe @arguments
        if ($LASTEXITCODE -ne 0) {
            throw "Repository upgrade failed with exit code $LASTEXITCODE."
        }
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($RepositoryServer) -or [string]::IsNullOrWhiteSpace($RepositoryDatabase)) {
        $settings = Get-SqlMonitorRepositorySettings
        if ([string]::IsNullOrWhiteSpace($RepositoryServer)) { $RepositoryServer = $settings.RepositoryServer }
        if ([string]::IsNullOrWhiteSpace($RepositoryDatabase)) { $RepositoryDatabase = $settings.RepositoryDatabase }
    }

    if ($MonitoredInstances.Count -eq 0) {
        $MonitoredInstances = @(Get-ConfiguredInstanceNames)
    }

    Write-UpgradeLog "Repository: $RepositoryServer / $RepositoryDatabase"
    Write-UpgradeLog "Install path: $InstallPath"

    $before = @(Test-RepositorySchema -Phase "Before")
    $deployOutput = Invoke-DeploymentUpgrade
    $after = @(Test-RepositorySchema -Phase "After")
    $jobStatus = Get-SqlAgentJobStatus

    $summary = [pscustomobject]@{
        RepositoryServer   = $RepositoryServer
        RepositoryDatabase = $RepositoryDatabase
        StartedAt          = (Get-Date).ToString("s")
        BeforeIssues       = @($before | Where-Object { $_.Status -ne "Ready" }).Count
        AfterIssues        = @($after | Where-Object { $_.Status -ne "Ready" }).Count
        SqlAgentJobs       = $jobStatus
        DeployOutput       = $deployOutput
        Before             = $before
        After              = $after
    }

    if ($Json) {
        $summary | ConvertTo-Json -Depth 8
    }
    else {
        Write-UpgradeLog "Self-healing repository upgrade complete." "Success"
        Write-Host ""
        Write-Host "Before issues: $($summary.BeforeIssues)"
        Write-Host "After issues:  $($summary.AfterIssues)"
        Write-Host "$($jobStatus.Check): $($jobStatus.Status) - $($jobStatus.Detail)"
        Write-Host ""
        $after | Where-Object { $_.Status -ne "Ready" } | Format-Table ObjectName, ObjectType, Status, MissingColumns -AutoSize
    }
}
catch {
    if ($Json) {
        [pscustomobject]@{ error = $_.Exception.Message } | ConvertTo-Json -Depth 3
    }
    else {
        Write-UpgradeLog $_.Exception.Message "Error"
    }
    exit 1
}
