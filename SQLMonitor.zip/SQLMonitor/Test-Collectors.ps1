# Test All Fixed Collectors
# Run this to test each collector individually

$ErrorActionPreference = "Stop"

# Import modules
$ProjectRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

Import-Module (Join-Path $ProjectRoot "Modules\Common.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-KPIs.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-Disks.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-Config.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-CPU.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-Memory.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-MemoryClerks.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-IO.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-TempDB.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-DBOptions.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-Blocking.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-LongRunning.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Collect-Waits.psm1") -Force

# Load instance configuration
$configPath = Join-Path $ProjectRoot "Config\instances.json"
$instances = Get-Content $configPath | ConvertFrom-Json

# Test with first active instance
$instance = $instances | Where-Object { $_.IsActive } | Select-Object -First 1

if (-not $instance) {
    Write-Host "ERROR: No active instances found in config" -ForegroundColor Red
    exit 1
}

Write-Host "`n=== Testing Collectors for $($instance.DisplayName) ===" -ForegroundColor Cyan

$collectors = @(
    @{ Name = "KPIs"; Function = "Invoke-KPIsCollector" },
    @{ Name = "Disks"; Function = "Invoke-DisksCollector" },
    @{ Name = "Config"; Function = "Invoke-ConfigCollector" },
    @{ Name = "CPU"; Function = "Invoke-CPUCollector" },
    @{ Name = "Memory"; Function = "Invoke-MemoryCollector" },
    @{ Name = "Memory Clerks"; Function = "Invoke-MemoryClerkCollector" },
    @{ Name = "I/O"; Function = "Invoke-IOCollector" },
    @{ Name = "TempDB"; Function = "Invoke-TempDBCollector" },
    @{ Name = "DB Options"; Function = "Invoke-DBOptionsCollector" },
    @{ Name = "Blocking"; Function = "Invoke-BlockingCollector" },
    @{ Name = "Long Running"; Function = "Invoke-LongRunningCollector" },
    @{ Name = "Waits"; Function = "Invoke-WaitsCollector" }
)

$successCount = 0
$failCount = 0

foreach ($collector in $collectors) {
    Write-Host "`nTesting $($collector.Name)... " -NoNewline -ForegroundColor Yellow
    
    try {
        & $collector.Function -Instance $instance
        Write-Host "SUCCESS" -ForegroundColor Green
        $successCount++
    }
    catch {
        Write-Host "FAILED" -ForegroundColor Red
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        $failCount++
    }
}

Write-Host "`n=== Test Summary ===" -ForegroundColor Cyan
Write-Host "Total: $($collectors.Count)" -ForegroundColor White
Write-Host "Passed: $successCount" -ForegroundColor Green
Write-Host "Failed: $failCount" -ForegroundColor Red

if ($failCount -eq 0) {
    Write-Host "`nAll collectors working correctly!" -ForegroundColor Green
} else {
    Write-Host "`nSome collectors failed. Check the errors above." -ForegroundColor Yellow
}
