-- Check escalation time requirements vs ticket ages
SELECT 
    t.TicketID,
    t.TicketNumber,
    ts.SeverityName,
    t.CreatedDate,
    DATEDIFF(MINUTE, t.CreatedDate, SYSUTCDATETIME()) AS AgeMinutes,
    em.EscalationLevelID,
    em.EscalationTimeMinutes,
    em.EscalationTo
FROM [mon].[Tickets] t
JOIN [mon].[TicketSeverity] ts ON t.TicketSeverityID = ts.TicketSeverityID
JOIN [mon].[EscalationMatrix] em ON t.TicketSeverityID = em.TicketSeverityID
WHERE t.TicketStatusID = 1  -- Open tickets
  AND em.IsActive = 1
  AND em.EscalationLevelID = 1  -- First escalation level
ORDER BY AgeMinutes DESC;

-- Manually update some ticket ages to test escalation (for testing only)
-- Uncomment below to test:
/*
UPDATE [mon].[Tickets]
SET CreatedDate = DATEADD(HOUR, -2, CreatedDate)
WHERE TicketID IN (SELECT TOP 5 TicketID FROM [mon].[Tickets] ORDER BY TicketID);
*/
