-- Fix the EscalationMatrix schema and add proper foreign key
USE [DBA_SQLMonitor]
GO

-- First, check if EscalationMatrix has a primary key
SELECT COLUMN_NAME, CONSTRAINT_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = 'mon' AND TABLE_NAME = 'EscalationMatrix';

-- Add primary key to EscalationMatrix if missing
IF NOT EXISTS (SELECT * FROM sys.key_constraints WHERE parent_object_id = OBJECT_ID('mon.EscalationMatrix') AND type = 'PK')
BEGIN
    ALTER TABLE [mon].[EscalationMatrix]
    ADD CONSTRAINT [PK_EscalationMatrix] PRIMARY KEY ([EscalationMatrixID]);
    PRINT 'Added primary key to EscalationMatrix';
END
GO

-- Drop the failed foreign key if it exists
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID('mon.Tickets') AND name = 'FK_Tickets_EscalationLevel')
BEGIN
    ALTER TABLE [mon].[Tickets] DROP CONSTRAINT [FK_Tickets_EscalationLevel];
    PRINT 'Dropped FK_Tickets_EscalationLevel';
END
GO

-- Add correct foreign key referencing EscalationMatrixID instead
IF COL_LENGTH('mon.Tickets', 'EscalationLevelID') IS NOT NULL
BEGIN
    -- First, let's add a proper column that references EscalationMatrixID
    IF COL_LENGTH('mon.Tickets', 'EscalationMatrixID') IS NULL
    BEGIN
        ALTER TABLE [mon].[Tickets]
        ADD [EscalationMatrixID] INT NULL;
        
        ALTER TABLE [mon].[Tickets]
        ADD CONSTRAINT [FK_Tickets_EscalationMatrix]
            FOREIGN KEY ([EscalationMatrixID])
            REFERENCES [mon].[EscalationMatrix]([EscalationMatrixID]);
        
        PRINT 'Added EscalationMatrixID column and foreign key';
    END
    
    -- Update existing data - set EscalationMatrixID based on severity and level
    UPDATE t
    SET t.EscalationMatrixID = em.EscalationMatrixID
    FROM [mon].[Tickets] t
    JOIN [mon].[EscalationMatrix] em ON t.TicketSeverityID = em.TicketSeverityID
    WHERE t.EscalationMatrixID IS NULL AND em.EscalationLevelID = 1; -- Initial level
    
    -- Drop the old EscalationLevelID column if it exists
    -- (We'll use EscalationMatrixID instead)
END
GO

-- Check the result
SELECT TOP 5 TicketID, TicketNumber, TicketSeverityID, EscalationMatrixID
FROM [mon].[Tickets];
