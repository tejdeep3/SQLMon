# SQL Monitor - Enhancement Deployment Guide

## Overview
This guide deploys 3 major enhancements to your SQL Monitor platform:
1. ✅ Email & Teams Alert Notifications
2. ✅ Fixed Retention Procedure (all tables)
3. ✅ Collection Health Monitoring

---

## Step 1: Deploy Database Objects (5 minutes)

### Run these SQL scripts in order:

```sql
-- 1. Update retention procedure
sqlcmd -S BBLBHLAP860\BBDBTESTSQL -d DBA_SQLMonitor -i "C:\VS Code Projects\SQLMonitor\Sql\Update_Retention_Procedure.sql"

-- 2. Create health monitoring views
sqlcmd -S BBLBHLAP860\BBDBTESTSQL -d DBA_SQLMonitor -i "C:\VS Code Projects\SQLMonitor\Sql\Collection_Health_Monitoring.sql"
```

**Or run them manually in SSMS/Azure Data Studio**

### Verify deployment:

```sql
-- Test retention procedure
EXEC mon.usp_PurgeRetention @RetentionDays = 90, @Verbose = 1;

-- Test health views
SELECT * FROM mon.vw_CollectionHealth ORDER BY MinutesAgo DESC;
SELECT * FROM mon.vw_CollectionGaps;
SELECT * FROM mon.vw_InstanceHealthSummary;
```

---

## Step 2: Configure Email Notifications (2 minutes)

### Edit the notifications config file:

Open: `C:\VS Code Projects\SQLMonitor\Config\notifications.json`

### Update these settings:

```json
{
  "SMTP": {
    "Server": "your-smtp-server.company.com",      // Your SMTP server
    "Port": 587,                                     // Usually 587 or 25
    "EnableSSL": true,                               // true for most servers
    "From": "sqlmonitor@company.com",               // Sender email
    "Username": "",                                  // Leave empty for Windows auth
    "Password": "",                                  // Leave empty for Windows auth
    "UseDefaultCredentials": true                    // true = use Windows auth
  },
  "Notifications": {
    "Enabled": true,                                 // Set to true to enable
    "Recipients": [
      "dba@company.com",                            // Your email
      "dba-team@company.com"                        // Add more recipients
    ],
    "MinSeverity": "Warning",                        // Info, Warning, or Critical
    "ThrottleMinutes": 30,                           // Don't send same alert more than once per 30 min
    "IncludeDashboardLink": true,
    "DashboardURL": "http://localhost:8080"         // Update if needed
  }
}
```

### For Microsoft Teams Integration (Optional):

```json
{
  "Teams": {
    "Enabled": true,
    "WebhookURL": "https://outlook.office.com/webhook/YOUR-WEBHOOK-URL"
  }
}
```

**To get Teams webhook URL:**
1. Go to your Teams channel
2. Click ••• (More options) → Connectors
3. Search "Incoming Webhook" → Configure
4. Copy the URL

---

## Step 3: Test Email Notifications (1 minute)

### Create a test alert in database:

```sql
-- Insert a test alert
INSERT INTO mon.Alerts (
    InstanceID, AlertTime, Severity, AlertType, 
    MetricName, CurrentValue, ThresholdValue, AlertMessage, IsAcknowledged
)
SELECT 
    InstanceID,
    SYSDATETIME(),
    'Warning',
    'Test Alert',
    'TestMetric',
    85.5,
    80.0,
    'This is a test alert to verify email notifications are working',
    0
FROM mon.Instances 
WHERE DisplayName = 'BBLBHLAP860\BBDBTESTSQL';

-- Trigger alert engine
EXEC mon.usp_EvaluateAlerts @InstanceID = 1; -- Replace with your InstanceID
```

### Run alert engine manually:

```powershell
Import-Module "C:\VS Code Projects\SQLMonitor\Modules\Invoke-AlertEngine.psm1" -Force
Import-Module "C:\VS Code Projects\SQLMonitor\Modules\Common.psm1" -Force

$config = Get-Content "C:\VS Code Projects\SQLMonitor\Config\instances.json" | ConvertFrom-Json
Invoke-AlertEngine -Instance $config[0]
```

### Check logs:

```powershell
Get-Content "C:\VS Code Projects\SQLMonitor\Logs\SQLMonitor.log" -Tail 20
```

You should see: `"Alert notification sent: SQL Alert [Warning]: ..."`

---

## Step 4: Test Health Monitoring (1 minute)

### Run health check script:

```powershell
cd "C:\VS Code Projects\SQLMonitor"
.\Check-Health.ps1
```

This will show:
- ✅ Green = Collectors running normally
- ⚠️ Yellow = Collectors running late
- ❌ Red = Collectors failing or not running

### Query health views:

```sql
-- Show all collection status
SELECT 
    InstanceName,
    ModuleName,
    HealthStatus,
    LastCollectionTime,
    MinutesAgo,
    LastStatus
FROM mon.vw_CollectionHealth
ORDER BY 
    CASE HealthStatus 
        WHEN 'Critical' THEN 1 
        WHEN 'Warning' THEN 2 
        ELSE 3 
    END;

-- Show only problems
SELECT * FROM mon.vw_CollectionGaps;

-- Instance health scores
SELECT * FROM mon.vw_InstanceHealthSummary ORDER BY HealthScore;
```

---

## Step 5: Configure Health Alerts (Optional)

### Add health check to scheduled tasks:

The health check can now be monitored automatically. Add this to your monitoring routine:

```powershell
# Check health every 15 minutes
Import-Module "C:\VS Code Projects\SQLMonitor\Modules\Collect-HealthCheck.psm1" -Force

$config = Get-Content "C:\VS Code Projects\SQLMonitor\Config\instances.json" | ConvertFrom-Json
$healthy = Test-CollectorHealth -Instance $config[0]

if (-not $healthy) {
    $alertMessage = Send-HealthAlert -Instance $config[0]
    # Could send this via email/Teams
}
```

---

## What Was Deployed

### Files Created/Modified:

**New Files:**
- ✅ `Config/notifications.json` - Email/Teams notification settings
- ✅ `Modules/Collect-HealthCheck.psm1` - Health monitoring module
- ✅ `Sql/Update_Retention_Procedure.sql` - Updated retention for all tables
- ✅ `Sql/Collection_Health_Monitoring.sql` - Health views and procedures
- ✅ `Check-Health.ps1` - Standalone health check script

**Modified Files:**
- ✅ `Modules/Invoke-AlertEngine.psm1` - Added email & Teams notifications

### Database Objects Created:

**Views:**
- `mon.vw_CollectionHealth` - Last collection time & status per module
- `mon.vw_CollectionGaps` - Missing/overdue collections
- `mon.vw_CollectionPerformance` - Collection timing statistics
- `mon.vw_InstanceHealthSummary` - Overall health score per instance

**Procedures:**
- `mon.usp_PurgeRetention` - Updated to handle all 20 tables
- `mon.usp_CheckCollectionHealth` - Health check with filtering

---

## Quick Reference

### Check collector health:
```powershell
.\Check-Health.ps1
```

### View collection gaps:
```sql
SELECT * FROM mon.vw_CollectionGaps ORDER BY Severity DESC;
```

### Manually run retention cleanup:
```sql
EXEC mon.usp_PurgeRetention @RetentionDays = 90, @Verbose = 1;
```

### Test alert notifications:
```powershell
# Insert test alert and run alert engine
# See Step 3 above for full commands
```

### Check email throttle status:
```powershell
Get-Content "C:\VS Code Projects\SQLMonitor\Config\AlertThrottle.json" | ConvertFrom-Json
```

---

## Troubleshooting

### Emails not sending?
1. Check SMTP settings in `notifications.json`
2. Verify SMTP server allows relay from this machine
3. Check Windows Firewall for port 587/25
4. Test manually: `Send-MailMessage -To "you@company.com" -Subject "Test" -Body "Test" -SmtpServer "your-smtp-server"`

### Health check shows "Never Collected"?
- Scheduled tasks may not be running yet
- Run `.\Check-Health.ps1` to see details
- Check Task Scheduler for SQLMonitor tasks
- Verify tasks are running: `Get-ScheduledTask | Where-Object { $_.TaskName -like "SQLMonitor-*" }`

### Retention not cleaning up data?
- Run with verbose mode: `EXEC mon.usp_PurgeRetention @RetentionDays = 90, @Verbose = 1;`
- Check for errors in output
- Verify table names match your schema

### Teams notifications not working?
- Verify webhook URL is correct
- Test webhook: `Invoke-RestMethod -Uri "YOUR-WEBHOOK-URL" -Method Post -Body '{"text":"Test"}' -ContentType 'application/json'`
- Check Teams channel connector is active

---

## Next Steps

Now that these enhancements are deployed, consider:

1. **Configure alert thresholds** - Adjust what triggers alerts in your alert rules
2. **Set up quiet hours** - Prevent alerts during maintenance windows
3. **Add more recipients** - Include team members, managers
4. **Monitor the monitor** - Check health dashboard weekly
5. **Adjust retention** - Change from 90 days based on storage capacity

---

## Support

For issues or questions:
- Check logs: `Get-Content "C:\VS Code Projects\SQLMonitor\Logs\SQLMonitor.log" -Tail 50`
- Review health: `.\Check-Health.ps1`
- Query database: Use the views listed above

**All enhancements are now active and will start working automatically!** 🎉
