# Fix-StartWebServerSimple.ps1
$filePath = Join-Path $PSScriptRoot "Web\Start-WebServer.ps1"
$content = Get-Content $filePath -Raw

# Fix the UpdateTask section - change double quotes to single quotes for SQL strings
# The issue is that PowerShell interprets @TaskID inside double-quoted string as splatting

# Pattern 1: UpdateTask
$oldPattern1 = 'Invoke-RepoNonQuery -Query "EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;" -Parameters @{'
$newPattern1 = "Invoke-RepoNonQuery -Query 'EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;' -Parameters @{"

if ($content.Contains($oldPattern1)) {
    $content = $content.Replace($oldPattern1, $newPattern1)
    Write-Host "Fixed UpdateTask section"
} else {
    Write-Host "Pattern 1 not found"
}

# Pattern 2: CreateTask  
$oldPattern2 = 'Invoke-RepoQuery -Query "EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;" -Parameters @{'
$newPattern2 = "Invoke-RepoQuery -Query 'EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;' -Parameters @{"

if ($content.Contains($oldPattern2)) {
    $content = $content.Replace($oldPattern2, $newPattern2)
    Write-Host "Fixed CreateTask section"
} else {
    Write-Host "Pattern 2 not found"
}

# Pattern 3: CreateTicketFromAlert
$oldPattern3 = 'Invoke-RepoQuery -Query "EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;" -Parameters @{'
$newPattern3 = "Invoke-RepoQuery -Query 'EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;' -Parameters @{"

if ($content.Contains($oldPattern3)) {
    $content = $content.Replace($oldPattern3, $newPattern3)
    Write-Host "Fixed CreateTicketFromAlert section"
} else {
    Write-Host "Pattern 3 not found"
}

# Save the file
Set-Content -Path $filePath -Value $content -Encoding UTF8
Write-Host "File saved: $filePath"
