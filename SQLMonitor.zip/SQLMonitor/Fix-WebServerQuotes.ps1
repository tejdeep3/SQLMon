# Fix-StartWebServer.ps1
$filePath = Join-Path $PSScriptRoot "Web\Start-WebServer.ps1"
$content = Get-Content $filePath -Raw

# Fix 1: Change double quotes to single quotes for SQL strings that have @ parameters
$content = $content -replace 'Invoke-RepoNonQuery -Query "EXEC mon\.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;"', 'Invoke-RepoNonQuery -Query ''EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;'''

# Fix 2: Also fix any other similar patterns
$content = $content -replace 'Invoke-RepoNonQuery -Query "EXEC mon\.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;"', 'Invoke-RepoNonQuery -Query ''EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;'''

$content = $content -replace 'Invoke-RepoQuery -Query "EXEC mon\.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;"', 'Invoke-RepoQuery -Query ''EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;'''

Set-Content -Path $filePath -Value $content -Encoding UTF8
Write-Host "Fixed SQL string quotes in Start-WebServer.ps1"
