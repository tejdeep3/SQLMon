-- Simplify: Just add EscalationLevelID to Tickets and track escalation level
USE [DBA_SQLMonitor]
GO

-- Drop the problematic foreign key if it exists
IF EXISTS (SELECT * FROM sys.foreign_keys WHERE parent_object_id = OBJECT_ID('mon.Tickets') AND name = 'FK_Tickets_EscalationLevel')
BEGIN
    ALTER TABLE [mon].[Tickets] DROP CONSTRAINT [FK_Tickets_EscalationLevel];
    PRINT 'Dropped FK_Tickets_EscalationLevel';
END
GO

-- Make sure EscalationLevelID column exists and is nullable
IF COL_LENGTH('mon.Tickets', 'EscalationLevelID') IS NOT NULL
BEGIN
    PRINT 'EscalationLevelID column exists in Tickets table';
    -- Just update it to be nullable if not already
    -- (We don't need a foreign key - we'll join on SeverityID + LevelID)
END
ELSE
BEGIN
    ALTER TABLE [mon].[Tickets]
    ADD [EscalationLevelID] INT NULL;
    PRINT 'Added EscalationLevelID column to Tickets';
END
GO

-- Create a simple stored procedure to process escalations
CREATE OR ALTER PROCEDURE [mon].[usp_ProcessTicketEscalations]
    @BatchSize INT = 50,
    @ProcessedCount INT = 0 OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @TicketID BIGINT, @TicketSeverityID INT, @CurrentLevelID INT;
    DECLARE @NextLevelID INT, @EscalationTo NVARCHAR(255), @EscalationTimeMinutes INT;
    
    -- Find tickets that need escalation
    DECLARE escalation_cursor CURSOR FAST_FORWARD FOR
    SELECT TOP (@BatchSize)
        t.TicketID,
        t.TicketSeverityID,
        ISNULL(t.EscalationLevelID, 0) AS CurrentLevelID
    FROM [mon].[Tickets] t
    WHERE t.TicketStatusID = 1  -- Open tickets only
      AND EXISTS (
          SELECT 1 FROM [mon].[EscalationMatrix] em
          WHERE em.TicketSeverityID = t.TicketSeverityID
            AND em.IsActive = 1
            AND em.EscalationLevelID > ISNULL(t.EscalationLevelID, 0)
      )
    ORDER BY t.CreatedDate ASC;
    
    SET @ProcessedCount = 0;
    
    OPEN escalation_cursor;
    FETCH NEXT FROM escalation_cursor INTO @TicketID, @TicketSeverityID, @CurrentLevelID;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Find the next escalation level
            SELECT TOP 1
                @NextLevelID = em.EscalationLevelID,
                @EscalationTo = em.EscalationTo,
                @EscalationTimeMinutes = em.EscalationTimeMinutes
            FROM [mon].[EscalationMatrix] em
            WHERE em.TicketSeverityID = @TicketSeverityID
              AND em.IsActive = 1
              AND em.EscalationLevelID > @CurrentLevelID
            ORDER BY em.EscalationLevelID ASC;
            
            IF @NextLevelID IS NOT NULL
            BEGIN
                -- Record the escalation
                EXEC [mon].[usp_RecordEscalation] 
                    @TicketID = @TicketID,
                    @EscalationLevelID = @NextLevelID,
                    @EscalatedTo = @EscalationTo,
                    @NotificationSent = 1;
                
                -- Update ticket's escalation level
                UPDATE [mon].[Tickets]
                SET [EscalationLevelID] = @NextLevelID,
                    [ModifiedDate] = SYSUTCDATETIME()
                WHERE [TicketID] = @TicketID;
                
                -- Log in comments
                INSERT INTO [mon].[TicketComments] ([TicketID], [CommentText], [CreatedBy])
                VALUES (@TicketID, 
                        'Ticket escalated to level ' + CAST(@NextLevelID AS NVARCHAR(10)) + ' (' + @EscalationTo + ')', 
                        'system');
                
                SET @ProcessedCount = @ProcessedCount + 1;
                PRINT 'Escalated ticket ID ' + CAST(@TicketID AS NVARCHAR(20));
            END
        END TRY
        BEGIN CATCH
            PRINT 'Error escalating ticket ID ' + CAST(@TicketID AS NVARCHAR(20)) + ': ' + ERROR_MESSAGE();
        END CATCH
        
        FETCH NEXT FROM escalation_cursor INTO @TicketID, @TicketSeverityID, @CurrentLevelID;
    END
    
    CLOSE escalation_cursor;
    DEALLOCATE escalation_cursor;
    
    PRINT 'Escalation processing completed. Processed ' + CAST(@ProcessedCount AS NVARCHAR(10)) + ' ticket(s).';
END
GO

-- Test the procedure
DECLARE @Count INT;
EXEC [mon].[usp_ProcessTicketEscalations] @BatchSize = 10, @ProcessedCount = @Count OUTPUT;
SELECT @Count AS TicketsEscalated;
