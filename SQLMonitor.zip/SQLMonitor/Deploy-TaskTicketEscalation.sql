-- Deploy-TaskTicketEscalation.sql
-- Deployment script for Task Management, Ticketing System, Alert-to-Ticket integration, and Escalation Matrix
-- Run this script to deploy all enhancements to DBA_SQLMonitor database

USE [DBA_SQLMonitor]
GO

PRINT 'Starting deployment of Task, Ticket, Alert-to-Ticket & Escalation enhancements...'
PRINT '============================================================'

-- Run Phase 8 Table Creation (if not already run)
PRINT 'Creating tables...'
:r ".\Phase8_TaskTicketEscalation.sql"

-- Run Phase 8 Procedures and Views (if not already run)
PRINT 'Creating stored procedures and views...'
:r ".\Phase8_ProceduresAndViews.sql"

-- Run alert-to-ticket integration updates, including duplicate prevention
PRINT 'Creating alert-to-ticket integration objects...'
:r ".\Phase8B_AlertToTicketIntegration.sql"

-- Run latest escalation processing procedures
PRINT 'Creating escalation processing objects...'
:r ".\Phase8C_Fixed.sql"

-- Repair ticket escalation-level marker and lookup foreign key
PRINT 'Repairing ticket escalation-level column...'
:r ".\Add-EscalationLevelColumn.sql"

-- Run web dashboard content tables used by Common Issues & SOPs
PRINT 'Creating web dashboard content tables...'
:r ".\Sql\12_WebDashboard_Content.sql"

-- Verify deployment
PRINT 'Verifying deployment...'

-- Check tables
IF EXISTS (SELECT * FROM sysobjects WHERE name='Tasks' AND xtype='U')
    PRINT '✓ Tasks table created successfully.'
ELSE
    PRINT '✗ Tasks table NOT found!'

IF EXISTS (SELECT * FROM sysobjects WHERE name='Tickets' AND xtype='U')
    PRINT '✓ Tickets table created successfully.'
ELSE
    PRINT '✗ Tickets table NOT found!'

IF EXISTS (SELECT * FROM sysobjects WHERE name='EscalationMatrix' AND xtype='U')
    PRINT '✓ EscalationMatrix table created successfully.'
ELSE
    PRINT '✗ EscalationMatrix table NOT found!'

-- Check views
IF EXISTS (SELECT * FROM sys.views WHERE name='vw_TaskDetails' AND schema_id = SCHEMA_ID('mon'))
    PRINT '✓ Task views created successfully.'
ELSE
    PRINT '✗ Task views NOT found!'

IF EXISTS (SELECT * FROM sys.views WHERE name='vw_TicketDetails' AND schema_id = SCHEMA_ID('mon'))
    PRINT '✓ Ticket views created successfully.'
ELSE
    PRINT '✗ Ticket views NOT found!'

IF EXISTS (SELECT * FROM sys.views WHERE name='vw_EscalationHistory' AND schema_id = SCHEMA_ID('mon'))
    PRINT '✓ Escalation views created successfully.'
ELSE
    PRINT '✗ Escalation views NOT found!'

-- Check stored procedures
IF EXISTS (SELECT * FROM sys.procedures WHERE name='usp_CreateTask' AND schema_id = SCHEMA_ID('mon'))
    PRINT '✓ Task stored procedures created successfully.'
ELSE
    PRINT '✗ Task stored procedures NOT found!'

IF EXISTS (SELECT * FROM sys.procedures WHERE name='usp_CreateTicketFromAlert' AND schema_id = SCHEMA_ID('mon'))
    PRINT '✓ Ticket stored procedures created successfully.'
ELSE
    PRINT '✗ Ticket stored procedures NOT found!'

IF EXISTS (SELECT * FROM sys.procedures WHERE name='usp_ConfigureEscalation' AND schema_id = SCHEMA_ID('mon'))
    PRINT '✓ Escalation stored procedures created successfully.'
ELSE
    PRINT '✗ Escalation stored procedures NOT found!'

IF EXISTS (SELECT * FROM sysobjects WHERE name='SOPs' AND xtype='U')
    PRINT 'SOP wiki table created successfully.'
ELSE
    PRINT 'SOP wiki table NOT found!'

PRINT '============================================================'
PRINT 'Deployment completed!'
PRINT ''
PRINT 'Next steps:'
PRINT '1. Run the PowerShell modules to test:'
PRINT '   - Modules\TaskManagement.psm1'
PRINT '   - Modules\TicketSystem.psm1'
PRINT '   - Modules\EscalationMatrix.psm1'
PRINT '2. Launch the GUI: Launch-TaskTicketGUI.bat'
PRINT '3. Schedule the job scripts:'
PRINT '   - Jobs\Run-EscalationCheck.ps1'
PRINT '   - Jobs\Create-TicketsFromAlerts.ps1'
GO
