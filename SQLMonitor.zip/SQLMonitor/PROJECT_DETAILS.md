# SQLMonitor Project Details

## Purpose

SQLMonitor is a repository-backed SQL Server monitoring and operations platform built primarily with PowerShell, SQL Server, and a lightweight web dashboard. It is designed to centralize SQL Server health, collection status, alerts, tickets, task management, troubleshooting knowledge, patching, and operational workflows.

The project aims to provide capabilities comparable to enterprise monitoring tools such as SCOM and SolarWinds while staying deployable with built-in Windows and SQL Server components.

## High-Level Architecture

- Repository database: `DBA_SQLMonitor`
- Primary schema: `mon`
- Collector runtime: PowerShell modules under `Modules`
- Scheduled execution: PowerShell scripts under `Jobs`
- Web dashboard: `Web/Start-WebServer.ps1`, `Web/index.html`, `Web/app.js`, `Web/ticket-system.js`, `Web/styles.css`
- Desktop dashboard: WinForms scripts under `GUI`
- Deployment center: `Launch-Deployment.bat` and `GUI/SQLMonitorDeployment.ps1`
- Main deployment engine: `Deploy-SQLMonitor.ps1`

## Main Folders

- `Config`: instance and notification configuration.
- `Docs`: deployment and implementation documentation.
- `GUI`: WinForms dashboards and deployment center.
- `Jobs`: scheduled collector, alert, ticket, escalation, and maintenance jobs.
- `Modules`: reusable PowerShell modules for collectors and operations.
- `Patches`: SQL Server patch download location.
- `Phase1_SQL`, `Sql`, and root `Phase*.sql`: repository schema, views, procedures, and upgrade scripts.
- `Remote`: remote server preparation and validation scripts.
- `Web`: web dashboard frontend and API host.
- `Logs`: deployment and runtime logs.

## Web Dashboard Information Architecture

The web dashboard is organized into six main sidebar sections. Each section exposes its own tabs inside the workspace.

### Command Center

- Server Overview
- Collectors & Schedule
- Collection Health
- Open Alerts
- Alert History
- Ticket System
- Task Management
- Performance Analytics
- My Account

### Performance

- CPU Trend
- Memory Trend
- KPIs
- Wait Stats
- Top Queries
- Execution Plans
- Memory Analysis

### Storage & Databases

- Disks
- I/O Files
- TempDB
- Backups
- DB Options
- Missing Indexes
- Fragmentation

### Operations

- SQL Config
- Blocking
- Long Running
- Availability Groups
- Listeners
- Agent Jobs
- Deadlocks
- Patch Manager

### Administration

- Instance Management
- Users & Access
- Notifications
- Thresholds
- Escalation Matrix
- Instance Group Execution
- Apply Latest Changes

### Assistants

- SQL Dictionary
- Common Issues & SOPs
- Web Solutions Agent

## Core Database Areas

### Monitoring

- `mon.MonitoredInstances`
- `mon.CollectionRuns`
- CPU, memory, disk, backup, TempDB, I/O, wait, query, plan, blocking, deadlock, AG, and job history tables
- Dashboard views for current and historical state

### Alerting

- `mon.AlertHistory`
- `mon.AlertThresholds`
- `mon.vw_OpenAlertsDetailed`
- `mon.vw_AlertHistoryDetailed`
- Repeat tracking columns:
  - `RepeatCount`
  - `FirstAlertTime`
  - `LastRepeatedAt`

Open alert deduplication is designed to prevent repeated alert rows from creating duplicate tickets for the same active alert condition.

### Ticketing

- `mon.Tickets`
- `mon.TicketComments`
- `mon.TicketStatus`
- `mon.TicketSeverity`
- `mon.EscalationMatrix`
- `mon.EscalationLevels`
- `mon.EscalationHistory`

Ticket functionality includes:

- create ticket from alert
- auto-convert alerts to tickets
- duplicate ticket prevention for repeated alerts
- acknowledge ticket
- resolve ticket with resolution notes UI
- resolving an alert-linked ticket closes the matching open alert condition so a future trigger starts a fresh alert age/repeat lifecycle
- Active Tickets and Historical Tickets tabs separate live work from resolved/closed ticket history
- Ticket Audit tab reviews ticket-specific dashboard audit events
- escalation processing
- ticket detail panel

### Task Management

- `mon.Tasks`
- `mon.TaskStatus`
- `mon.TaskPriority`
- `mon.TaskComments`
- `mon.TaskActivities`
- `mon.vw_TaskComments`
- `mon.vw_TaskAuditTrail`

Task Management supports:

- create task
- view active task queue
- review completed and cancelled tasks in Tasks History
- assign task to active application users from `mon.DashboardUsers`
- edit title, owner, status, priority, due date, and description
- close task by completing it
- add and edit comments
- activity tracking through database procedures
- Task Audit tab and per-task audit timeline

### Web Dashboard Security

- `mon.DashboardUsers`
- `mon.DashboardUserInstanceAccess`
- `mon.DashboardServerGroups`
- `mon.DashboardServerGroupMembers`
- `mon.DashboardUserServerGroupAccess`
- `mon.DashboardAuditLog`

Features include:

- dashboard login
- roles: `Admin`, `AppOwner`, `ViewOnly`, `Limited`
- direct per-instance access
- application/server groups for assigning application portfolios to owners
- User Management separates normal user creation, Application Server Groups, and direct Server Assignment.
- Application Server Groups and Server Assignment use multi-select server dropdowns.
- effective access from direct server assignments plus active server group membership
- password change
- login lockout tracking
- audit logging

### BI Insights Studio

BI Insights Studio is an in-app PowerBI-style operational analytics module. It uses SQL Monitor repository data directly and provides:

- SQL-backed semantic dataset catalog: `mon.BIInsightDatasets`
- SQL-backed saved reports: `mon.BIInsightReports`
- SQL-backed report bookmarks: `mon.BIInsightBookmarks`
- SQL-backed data source catalog: `mon.BIInsightDataSources`
- SQL-backed semantic fields, relationships, and measures: `mon.BIInsightFields`, `mon.BIInsightRelationships`, `mon.BIInsightMeasures`
- SQL-backed transformation steps: `mon.BIInsightTransformations`
- SQL-backed visual types, themes, report pages, Q&A prompts, and performance runs: `mon.BIInsightVisualTypes`, `mon.BIInsightThemes`, `mon.BIInsightReportPages`, `mon.BIInsightQAPrompts`, `mon.BIInsightPerformanceRuns`
- SQL-backed module chart publishing: `mon.BIInsightModuleVisuals`
- report canvas, report builder, module charts, dataset catalog, model, Power Query, visualizations, Q&A, performance analyzer, and saved reports tabs
- executive KPI tiles
- health score and posture charts
- alert trend visualization
- top noisy/repeated alerts
- capacity hotspots
- server scorecard
- collection module health
- fields pane, measure catalog, relationship view, transformation view, visual library, theme selector, and verified prompt catalog
- functional report builder with a PowerBI-style visualizations pane, field wells, live canvas visuals, and saved visual layouts
- supported builder visuals include stacked bar, stacked column, clustered bar, clustered column, line, area, pie, doughnut, scatter, bubble, waterfall, funnel, treemap, gauge, card, table, and matrix
- governed Module Charts tab where admins enable one chart per module, auto-configure the best module-specific visual, choose visualization type, axis/value/legend fields from live module data, preview it, and publish it into pages such as CPU Trend, Wait Stats, Disks, Backups, Blocking, Agent Jobs, and other standard modules
- module chart rendering includes axis titles, legends, semantic field guardrails, latest-snapshot scoping for snapshot modules, and module-aware defaults so every generic module uses meaningful category/value selections
- BI workspace tabs are actionable workbenches: dataset discovery builds visuals, model view exposes fields/measures/relationships, Power Query previews transformed data, visualizations add chart types, Q&A creates answer visuals, performance highlights slow BI runs, and saved reports reload layouts into the builder
- rule-based BI assistant endpoint for curated operational questions
- query execution tracking for the BI performance analyzer
- shared and personal report definitions
- CSV export for scorecard and alert reports
- Daily, Weekly, Monthly, and Yearly management Excel exports for Alerts, Ticket System, and Task Management with separate worksheets for executive summary, report details, and chart-ready trend/status/owner breakdowns

### Incident Flight Recorder

Incident Flight Recorder is a differentiating Command Center module that reconstructs incident context from repository evidence instead of showing isolated metrics.

It correlates:

- alert history and repeat alert patterns
- CPU, memory, disk, and blocking telemetry
- SQL Agent job failures
- related tickets
- collector health and visibility gaps

It provides:

- weighted incident risk score
- likely cause signal
- cause signal evidence cards
- correlated event timeline
- blast radius by alert module and affected database
- recommended next actions
- evidence tabs for alerts, blocking, jobs, tickets, collector health, and telemetry

### Knowledge Wiki

- `mon.SOPs`

The Common Issues & SOPs wiki is repository-backed. Wiki pages are stored in the database, not in static application files.

Fields include:

- title
- category
- severity
- description
- SOP content
- frequency
- owner
- tags
- active flag
- created and updated timestamps
- last updated by

The web editor includes:

- Create/Edit page
- Preview tab
- category dropdown
- frequency dropdown
- markdown-style preview rendering

## PowerShell Modules

Important modules include:

- `Common.psm1`: common SQL, logging, configuration, repository helpers.
- `Invoke-AlertEngine.psm1`: alert evaluation.
- `WebAgent.psm1`: SQL Server solution search and troubleshooting assistance.
- `PatchManager.psm1` and `PatchDownloader.psm1`: patch status and download workflow.
- `TaskManagement.psm1`: task management automation.
- `TicketSystem.psm1`: ticketing automation.
- `EscalationMatrix.psm1`: escalation rule handling.

Collector modules include:

- `Collect-CPU.psm1`
- `Collect-Memory.psm1`
- `Collect-KPIs.psm1`
- `Collect-Waits.psm1`
- `Collect-TopQueries.psm1`
- `Collect-ExecutionPlans.psm1`
- `Collect-MemoryClerks.psm1`
- `Collect-Disks.psm1`
- `Collect-IO.psm1`
- `Collect-TempDB.psm1`
- `Collect-Backups.psm1`
- `Collect-DBOptions.psm1`
- `Collect-MissingIndexes.psm1`
- `Collect-Fragmentation.psm1`
- `Collect-Config.psm1`
- `Collect-Blocking.psm1`
- `Collect-LongRunning.psm1`
- `Collect-AG.psm1`
- `Collect-ListenersEndpoints.psm1`
- `Collect-AgentJobs.psm1`
- `Collect-Deadlocks.psm1`

## Scheduled Jobs

Key job scripts:

- `Run-Collectors-Core.ps1`
- `Run-Collectors-Advanced.ps1`
- `Run-Collectors-Daily.ps1`
- `Run-Collectors-InstanceGroup.ps1`
- `Run-AlertEngine.ps1`
- `Create-TicketsFromAlerts.ps1`
- `Process-TicketEscalations.ps1`
- `Run-EscalationCheck.ps1`
- `Run-ExecutionPlans.ps1`
- `Run-MemoryClerks.ps1`
- `Run-PatchManager.ps1`
- `Run-WebAgent.ps1`
- `Purge-Retention.ps1`
- `Register-SQLMonitorTasks.ps1`

## Web API Areas

The web server exposes APIs from `Web/Start-WebServer.ps1`.

Major API groups:

- authentication and session
- bootstrap and feature metadata
- overview and module data
- collectors and schedules
- alerts and alert history
- tickets
- tasks
- escalation rules and history
- thresholds
- notifications
- dictionary
- SOP wiki
- Web Solutions Agent
- patch status/download
- users and audit
- apply latest application and database changes

## Deployment

Primary deployment entry points:

- `Launch-Deployment.bat`
- `GUI/SQLMonitorDeployment.ps1`
- `Deploy-SQLMonitor.ps1`
- `Apply-LatestChanges.ps1`
- `Reset-DashboardAdmin.ps1`

Main deployment responsibilities:

- copy application files to install path
- update configuration files
- ensure repository database exists
- deploy schema scripts
- deploy dashboard security
- deploy web dashboard content tables
- deploy task, ticket, alert, and escalation objects
- configure SQL Agent jobs
- optionally configure Windows scheduled tasks

### Applying Latest Changes In Place

Admins can push the latest application files and database schema changes without recreating the deployment:

- Deployment UI: open `Launch-Deployment.bat`, then use **Apply Latest Changes**.
- Web dashboard: Administration > **Apply Latest Changes**.
- Script/automation: run `Apply-LatestChanges.ps1` with repository, source path, and install path parameters.

This path runs the same database/script deployment chain as the full deployment, skips monitored-instance reconfiguration, preserves existing repository data, and can optionally refresh SQL Agent jobs, per-instance jobs, and Windows scheduled tasks.

Deployment data safety rules:

- Existing repository tables are updated in place; deployment scripts must use idempotent `IF NOT EXISTS`, `COL_LENGTH`, `CREATE OR ALTER`, or guarded `ALTER TABLE` patterns.
- Update deployments block unsafe `DROP TABLE`, `TRUNCATE TABLE`, `DROP DATABASE`, `DROP SCHEMA`, and top-level `DELETE FROM mon/dbo` statements before SQL is executed.
- Data cleanup is allowed only through explicit operational procedures, such as retention procedures, not through deployment scripts.
- **Database Only**, **Deploy Enhancements Only**, and **Apply Latest Changes** preserve existing monitored-instance configuration and do not rewrite the configured server list.

### Dashboard Admin Recovery

If the dashboard administrator account is disabled, locked, or the password is unknown, use the explicit recovery action:

- Deployment UI: open `Launch-Deployment.bat`, then use **Repair Admin Login**.
- Script/automation: run `Reset-DashboardAdmin.ps1`.

The recovery action resets the `admin` account to `Admin@123`, unlocks it, activates it, grants Admin role, and forces password change after login. Normal deployments do not silently reset existing dashboard passwords.

Important deployment scripts include:

- `Sql/00_CoreSchema.sql`
- `Phase4B_CreateTables.sql`
- `Phase5_AlertEngine.sql`
- `Phase5B_DashboardAlertViews.sql`
- `Phase5C_AlertAcknowledgement.sql`
- `Phase6_AdvancedCollectorTables.sql`
- `Sql/09_Dashboard_Views_Fix.sql`
- `Sql/10_DashboardSecurity.sql`
- `Sql/11_SelfHealing_Compatibility.sql`
- `Sql/12_WebDashboard_Content.sql`
- `Phase8_TaskTicketEscalation.sql`
- `Phase8_ProceduresAndViews.sql`
- `Phase8B_AlertToTicketIntegration.sql`
- `Phase8C_Fixed.sql`
- `Add-EscalationLevelColumn.sql`

## Current Web UI Enhancements

Recent web dashboard improvements include:

- animated login screen
- collapsible sidebar
- section-based sidebar navigation
- workspace-level tabs per section
- icon-based navigation
- refreshed glass-style dashboard shell, richer hover states, animated buttons, and subtle motion polish
- floating rule-based Smart Assistant that stays on screen without external AI/LLM connections, supports module search, smart shortcuts, and user favorites stored in browser preferences
- table pagination and rows-per-page selection across modules
- improved Ticket System layout
- resolution notes UI for ticket resolve
- improved Task Management tabs and assignee dropdowns
- Common Issues & SOPs wiki editor/preview tabs
- repository-backed SOP wiki content
- Web Solutions Agent workbench with search, recent alert triage, and diagnosis flow
- Command Center health score and posture cards

## Data Persistence Principle

Business data should be stored in SQL Server repository tables, not in the browser or application files.

Database-backed examples:

- alerts: `mon.AlertHistory`
- tickets: `mon.Tickets`
- ticket comments: `mon.TicketComments`
- tasks: `mon.Tasks`
- task comments: `mon.TaskComments`
- task activities: `mon.TaskActivities`
- users: `mon.DashboardUsers`
- SOP wiki pages: `mon.SOPs`
- audit records: `mon.DashboardAuditLog`

Browser local storage is used only for client-side session/preference data, such as:

- dashboard auth token
- sidebar collapsed preference

## Operational Notes

- After changing `Web/Start-WebServer.ps1`, restart the web dashboard server.
- After changing `Web/app.js`, `Web/ticket-system.js`, or `Web/styles.css`, bump the asset query version in `Web/index.html` or hard-refresh the browser.
- Use Apply Latest Changes after schema, procedure, dashboard, or script changes when the existing deployment should be updated in place.
- Logs are written to `Logs/SQLMonitor.log` and `Logs/Deployment.log`.

## Validation Commands

Useful local checks:

```powershell
node --check .\Web\app.js
node --check .\Web\ticket-system.js
```

PowerShell parse validation:

```powershell
$files = Get-ChildItem -Recurse -Include *.ps1,*.psm1 -File
foreach ($file in $files) {
    $tokens = $null
    $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors) | Out-Null
    $errors
}
```

## Known Important Behavior

- Alert repeat count is tracked so repeated alert conditions can be understood without creating duplicate active tickets.
- Ticket creation from alerts includes duplicate prevention logic.
- Task assignment uses active dashboard users.
- SOP wiki content is deployed and stored in `mon.SOPs`.
- Escalation level tracking on tickets references `mon.EscalationLevels`, not `mon.EscalationMatrix`.
