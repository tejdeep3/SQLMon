-- Check correct table names
SELECT TABLE_NAME, COLUMN_NAME 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = 'mon' 
  AND TABLE_NAME IN ('TicketSeverity', 'TicketStatus', 'EscalationMatrix')
ORDER BY TABLE_NAME, ORDINAL_POSITION;

-- Check escalation matrix with correct table names
SELECT em.*, 
       ts.StatusName, 
       tp.PriorityName 
FROM mon.EscalationMatrix em 
JOIN mon.TicketStatus ts ON em.TicketStatusID = ts.TicketStatusID 
JOIN mon.TicketSeverity tp ON em.TicketSeverityID = tp.TicketSeverityID 
ORDER BY em.TicketSeverityID, em.EscalationLevel;

-- Check pending escalations
SELECT COUNT(*) AS PendingEscalation 
FROM mon.vw_TicketsPendingEscalation;

-- Check tickets needing escalation
SELECT TOP 5 * FROM mon.vw_TicketsPendingEscalation;
