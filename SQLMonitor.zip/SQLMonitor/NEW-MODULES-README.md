# New Modules: WebAgent, PatchManager, and PatchDownloader

## Overview

Three new PowerShell modules have been added to enhance SQL Server monitoring with web-based intelligence and patch management capabilities.

## 1. WebAgent Module (WebAgent.psm1)

### Purpose
Provides web scraping capabilities to find solutions for SQL Server issues from trusted sources.

### Key Functions

#### Invoke-WebSolutionsAgent
Searches for solutions on approved web sources (StackOverflow, Microsoft Docs, SQLServerUpdates.com).

```powershell
# Search for solutions to a specific error
$solutions = Invoke-WebSolutionsAgent -ErrorMessage "Cannot open database requested by the login" -MaxResults 5

# Display results
foreach ($solution in $solutions) {
    Write-Host "$($solution.Title)" -ForegroundColor Green
    Write-Host "Source: $($solution.Source)" -ForegroundColor Yellow
    Write-Host "URL: $($solution.Url)" -ForegroundColor Cyan
    Write-Host ""
}
```

#### Get-SQLServerErrorSolutions
Gets solutions for common SQL Server errors.

```powershell
$solutions = Get-SQLServerErrorSolutions -ErrorNumber 18456 -ErrorMessage "Login failed"
```

### Usage
- Run manually: `.\Launch-WebAgent.bat`
- Run with specific error: `.\Jobs\Run-WebAgent.ps1 -ErrorMessage "your error message"`
- Automatically checks recent alerts from the database

## 2. PatchManager Module (PatchManager.psm1)

### Purpose
Retrieves current SQL Server version information and available patches for monitored instances.

### Key Functions

#### Get-SQLServerPatchInfo
Gets patch information for a specific SQL Server instance.

```powershell
$patchInfo = Get-SQLServerPatchInfo -Instance $instance
Write-Host "Version: $($patchInfo.VersionName) ($($patchInfo.ProductVersion))"
Write-Host "Available Patches: $($patchInfo.AvailablePatches.Count)"
```

#### Get-SQLServerPatchStatus
Gets patch status for all monitored SQL Server instances.

```powershell
$allPatchStatus = Get-SQLServerPatchStatus
$allPatchStatus | Format-Table InstanceName, VersionName, ProductVersion, @{Name="AvailablePatches";Expression={$_.AvailablePatches.Count}}
```

### Sources Searched
- Microsoft Update Catalog
- SQL Server Builds Blog (sqlserverbuilds.blogspot.com)
- Microsoft Download Center

## 3. PatchDownloader Module (PatchDownloader.psm1)

### Purpose
Downloads SQL Server patches from trusted sources, primarily sqlserverbuilds.blogspot.com.

### Key Functions

#### Invoke-SQLServerPatchDownloader
Downloads patches for a specific SQL Server instance.

```powershell
$downloads = Invoke-SQLServerPatchDownloader -Instance $instance -DownloadPath "C:\Patches"
```

#### Invoke-BulkPatchDownload
Downloads patches for all monitored instances.

```powershell
$allDownloads = Invoke-BulkPatchDownload -DownloadPath "C:\Patches" -Force
```

### Download Sources
- SQL Server Builds Blog (primary source)
- Microsoft Download Center
- Microsoft Update Catalog

## Job Scripts

### Run-WebAgent.ps1
- Checks recent alerts from the database
- Searches for solutions automatically
- Saves solution reports to Logs folder

### Run-PatchManager.ps1
- Retrieves patch status for all instances
- Optionally downloads available patches
- Saves reports in JSON format

## Batch Files

### Launch-WebAgent.bat
Launches the web solutions agent.

### Launch-PatchManager.bat
Launches patch management.
- `Launch-PatchManager.bat` - Check patch status only
- `Launch-PatchManager.bat download` - Check status and download patches

## Security Considerations

- Only scrapes from approved, trusted sources
- Uses HTTPS for all web requests
- Implements rate limiting and timeout controls
- Downloads are saved to a controlled Patches directory

## Integration with Dashboard

These modules can be integrated into the existing dashboard to:
- Show available patches for each instance
- Provide quick access to solutions for alerts
- Display patch compliance status

## File Structure

```
Modules/
├── WebAgent.psm1          # Web scraping for solutions
├── PatchManager.psm1      # Patch information retrieval
└── PatchDownloader.psm1   # Patch downloading

Jobs/
├── Run-WebAgent.ps1       # Web agent job script
└── Run-PatchManager.ps1   # Patch manager job script

Launch-WebAgent.bat        # Web agent launcher
Launch-PatchManager.bat    # Patch manager launcher

Patches/                   # Downloaded patch files (created automatically)
Logs/                      # Solution and patch reports
```

## Example Usage Scenarios

### Scenario 1: Finding Solutions for Errors
```powershell
# When an alert occurs, automatically search for solutions
.\Launch-WebAgent.bat
# Check Logs folder for WebSolutions_*.txt files
```

### Scenario 2: Patch Management
```powershell
# Check what patches are available
.\Launch-PatchManager.bat

# Download available patches
.\Launch-PatchManager.bat download
# Check Patches folder for downloaded files
```

### Scenario 3: Manual Error Research
```powershell
Import-Module .\Modules\WebAgent.psm1
$solutions = Invoke-WebSolutionsAgent -ErrorMessage "ORA-12541: TNS:no listener" -MaxResults 3
$solutions | Format-Table Title, Source, Type
```
