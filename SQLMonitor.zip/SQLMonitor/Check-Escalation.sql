-- Check ticket-related tables
SELECT TABLE_NAME 
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = 'mon' 
  AND TABLE_NAME LIKE '%Ticket%' 
ORDER BY TABLE_NAME;

-- Check escalation matrix with correct table names
SELECT em.*, 
       ts.StatusName, 
       tp.PriorityName 
FROM mon.EscalationMatrix em 
JOIN mon.TicketStatuses ts ON em.TicketStatusID = ts.TicketStatusID 
JOIN mon.TicketPriorities tp ON em.TicketSeverityID = tp.TicketPriorityID 
ORDER BY em.TicketSeverityID, em.EscalationLevel;

-- Check pending escalations
SELECT COUNT(*) AS PendingEscalation 
FROM mon.vw_TicketsPendingEscalation;
