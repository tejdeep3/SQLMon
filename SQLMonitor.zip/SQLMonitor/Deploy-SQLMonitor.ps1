param(
    [Parameter(Mandatory = $true)]
    [string]$RepositoryServer,

    [string]$RepositoryDatabase = "DBA_SQLMonitor",

    [string[]]$MonitoredInstances = @(),

    [string]$InstallPath = (Split-Path -Parent $MyInvocation.MyCommand.Path),

    [switch]$DeployDatabase,
    [switch]$DeployScripts,
    [switch]$ConfigureSqlAgentJobs,
    [switch]$ConfigureWindowsTasks,
    [switch]$ConfigurePerInstanceJobs,
    [switch]$All,
    [switch]$SkipInstanceConfiguration,

    [ValidateSet("Standalone", "Central", "Collector")]
    [string]$DeploymentRole = "Standalone",

    [string]$CollectorNodeName = $env:COMPUTERNAME,
    [string]$CollectorSite = "",
    [string]$CollectorTags = "",
    [string]$JobServer = "",
    [string]$CentralLinkedServer = "SQLMON_CENTRAL",
    [string]$CentralServerInstance = "",
    [switch]$ConfigureCentralLinkedServer,
    [string]$CentralLinkedServerProvider = "MSOLEDBSQL",
    [string]$CentralLinkedServerLogin = "",
    [string]$CentralLinkedServerPassword = "",
    [int]$CentralSyncIntervalMinutes = 15,

    [ValidateSet("System", "CurrentUser")]
    [string]$WindowsTaskRunAs = "System",

    [int]$CoreIntervalMinutes = 5,
    [int]$AdvancedIntervalMinutes = 30,
    [int]$WebDashboardPort = 8090,
    [string]$DailyTime = "02:00",
    [string]$RetentionTime = "03:00",
    [switch]$SkipInitialWindowsVMCollection,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogPath = Join-Path $ProjectRoot "Logs\Deployment.log"

function Write-DeployLog {
    param(
        [string]$Message,
        [ValidateSet("Info", "Warning", "Error", "Success")]
        [string]$Level = "Info"
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "$timestamp`t[$Level]`t$Message"

    try {
        $logDir = Split-Path -Parent $LogPath
        if (-not (Test-Path $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }
        Add-Content -Path $LogPath -Value $line
    }
    catch {
        $fallbackDir = Join-Path ([System.IO.Path]::GetTempPath()) "SQLMonitor"
        $fallbackLog = Join-Path $fallbackDir "Deployment.log"
        try {
            if (-not (Test-Path $fallbackDir)) {
                New-Item -ItemType Directory -Path $fallbackDir -Force | Out-Null
            }
            Add-Content -Path $fallbackLog -Value $line
            if (-not $script:DeploymentLogFallbackNotified) {
                Write-Host "Deployment log fallback: $fallbackLog" -ForegroundColor Yellow
                $script:DeploymentLogFallbackNotified = $true
            }
        }
        catch {
            if (-not $script:DeploymentLogFallbackNotified) {
                Write-Host "Deployment log could not be written; continuing without file logging." -ForegroundColor Yellow
                $script:DeploymentLogFallbackNotified = $true
            }
        }
    }

    $color = switch ($Level) {
        "Success" { "Green" }
        "Warning" { "Yellow" }
        "Error" { "Red" }
        default { "Gray" }
    }
    Write-Host $Message -ForegroundColor $color
}

function New-SqlConnection {
    param(
        [string]$ServerInstance,
        [string]$Database
    )

    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    return New-Object System.Data.SqlClient.SqlConnection $connectionString
}

function Invoke-DeploySqlNonQuery {
    param(
        [string]$ServerInstance,
        [string]$Database,
        [string]$Query,
        [int]$Timeout = 0
    )

    if ([string]::IsNullOrWhiteSpace($Query)) {
        return
    }

    $connection = New-SqlConnection -ServerInstance $ServerInstance -Database $Database
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = $Timeout

    try {
        $connection.Open()
        [void]$command.ExecuteNonQuery()
    }
    finally {
        $connection.Close()
        $connection.Dispose()
    }
}

function Invoke-DeploySqlScalar {
    param(
        [string]$ServerInstance,
        [string]$Database,
        [string]$Query
    )

    $connection = New-SqlConnection -ServerInstance $ServerInstance -Database $Database
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = 60

    try {
        $connection.Open()
        return $command.ExecuteScalar()
    }
    finally {
        $connection.Close()
        $connection.Dispose()
    }
}

function Split-SqlBatches {
    param([string]$Script)

    $batches = New-Object System.Collections.Generic.List[string]
    $builder = New-Object System.Text.StringBuilder
    foreach ($line in ($Script -split '\r?\n')) {
        if ($line -match '^\s*GO\s*(--.*)?$') {
            $batch = $builder.ToString().Trim()
            if (-not [string]::IsNullOrWhiteSpace($batch)) {
                $batches.Add($batch)
            }
            [void]$builder.Clear()
        }
        else {
            [void]$builder.AppendLine($line)
        }
    }

    $finalBatch = $builder.ToString().Trim()
    if (-not [string]::IsNullOrWhiteSpace($finalBatch)) {
        $batches.Add($finalBatch)
    }
    return $batches
}

function Normalize-SqlScript {
    param(
        [string]$Script,
        [string]$DatabaseName
    )

    $normalized = $Script
    $escapedDb = [regex]::Escape("DBA_SQLMonitor")
    $normalized = [regex]::Replace($normalized, "(?im)^\s*USE\s+\[?$escapedDb\]?\s*;?\s*$", "USE [$DatabaseName];")
    $normalized = [regex]::Replace($normalized, "(?i)\bDBA_SQLMonitor\b", $DatabaseName)
    return $normalized
}

function Remove-SqlCommentsForSafetyScan {
    param([string]$Script)

    $withoutBlockComments = [regex]::Replace($Script, "(?s)/\*.*?\*/", "")
    return [regex]::Replace($withoutBlockComments, "(?m)--.*$", "")
}

function Assert-SqlDeploymentScriptIsDataSafe {
    param(
        [string]$Path,
        [string]$Script
    )

    $scanText = Remove-SqlCommentsForSafetyScan -Script $Script
    $blockedPatterns = @(
        @{ Name = "DROP TABLE"; Pattern = '(?im)\bDROP\s+TABLE\s+(?!#|##)(?!IF\s+EXISTS\s+#)' },
        @{ Name = "TRUNCATE TABLE"; Pattern = '(?im)\bTRUNCATE\s+TABLE\b' },
        @{ Name = "DROP DATABASE"; Pattern = '(?im)\bDROP\s+DATABASE\b' },
        @{ Name = "DROP SCHEMA"; Pattern = '(?im)\bDROP\s+SCHEMA\b' }
    )

    foreach ($rule in $blockedPatterns) {
        if ($scanText -match $rule.Pattern) {
            throw "Unsafe SQL deployment statement blocked in ${Path}: $($rule.Name). Deployment scripts must preserve existing repository data."
        }
    }

    foreach ($batch in (Split-SqlBatches -Script $scanText)) {
        if ($batch -match '(?is)\bCREATE\s+OR\s+ALTER\s+PROCEDURE\b') {
            continue
        }
        if ($batch -match '(?im)\bDELETE\s+FROM\s+(?!@)(?:\[?(mon|dbo)\]?\.)') {
            throw "Unsafe SQL deployment statement blocked in ${Path}: DELETE FROM repository table. Data cleanup must be inside an explicit stored procedure or manual maintenance script."
        }
    }
}

function Invoke-SqlFile {
    param(
        [string]$Path,
        [string]$DatabaseName
    )

    if (-not (Test-Path $Path)) {
        throw "SQL file not found: $Path"
    }

    Write-DeployLog "Running SQL script: $Path"
    $script = Get-Content -Path $Path -Raw
    $script = Normalize-SqlScript -Script $script -DatabaseName $DatabaseName
    Assert-SqlDeploymentScriptIsDataSafe -Path $Path -Script $script
    foreach ($batch in (Split-SqlBatches -Script $script)) {
        Invoke-DeploySqlNonQuery -ServerInstance $RepositoryServer -Database $DatabaseName -Query $batch -Timeout 0
    }
}

function Ensure-RepositoryDatabase {
    $dbNameEscaped = $RepositoryDatabase.Replace("]", "]]")
    $query = @"
IF DB_ID(N'$($RepositoryDatabase.Replace("'", "''"))') IS NULL
BEGIN
    DECLARE @sql nvarchar(max) = N'CREATE DATABASE [$dbNameEscaped]';
    EXEC(@sql);
END;

DECLARE @alter nvarchar(max) = N'ALTER DATABASE [$dbNameEscaped] SET RECOVERY SIMPLE';
EXEC(@alter);
"@
    Write-DeployLog "Ensuring repository database [$RepositoryDatabase] exists on [$RepositoryServer]"
    Invoke-DeploySqlNonQuery -ServerInstance $RepositoryServer -Database "master" -Query $query -Timeout 0
}

function Deploy-RepositorySchema {
    Ensure-RepositoryDatabase

    $scripts = @(
        "Sql\00_CoreSchema.sql",
        "Phase4B_CreateTables.sql",
        "Phase6_AdvancedCollectorTables.sql",
        "Sql\Create_MissingIndexes_Table.sql",
        "Sql\Add_MissingIndexes_Columns.sql",
        "Sql\Add_BackupStatusHistory.sql",
        "Sql\07_Extended_Tables.sql",
        "Sql\Phase7_CompleteSchemaCoverage.sql",
        "Sql\09_Dashboard_Views_Fix.sql",
        "Phase5_AlertEngine.sql",
        "Phase5B_DashboardAlertViews.sql",
        "Phase5C_AlertAcknowledgement.sql",
        "Sql\08_Extended_Views.sql",
        "Sql\Collection_Health_Monitoring.sql",
        "Sql\Update_Retention_Procedure.sql",
        "Sql\10_DashboardSecurity.sql",
        "Sql\11_SelfHealing_Compatibility.sql",
        "Sql\12_WebDashboard_Content.sql",
        "Sql\13_BIInsightsStudio.sql",
        "Sql\14_CentralRepositorySync.sql",
        "Sql\15_WindowsMonitoring.sql",
        "Phase8_TaskTicketEscalation.sql",
        "Phase8B_AlertToTicketIntegration.sql",
        "Phase8_ProceduresAndViews.sql",
        "Phase8C_Fixed.sql",
        "Add-EscalationLevelColumn.sql",
        "Sql\16_WindowsVMAlerting.sql",
        "Sql\19_WindowsMemoryTrendProcedures.sql",
        "Sql\20_WindowsCapacityAndBaseline.sql",
        "Sql\21_WindowsNetworkAndPatching.sql",
        "Phase1_SQL\seed_thresholds.sql",
        "Sql\17_VM_SQL_Hierarchy.sql"
    )

    foreach ($relativePath in $scripts) {
        $path = Join-Path $ProjectRoot $relativePath
        if (Test-Path $path) {
            Invoke-SqlFile -Path $path -DatabaseName $RepositoryDatabase
        }
        else {
            throw "Required SQL deployment script is missing: $relativePath"
        }
    }

    Write-DeployLog "Repository schema deployment complete." -Level Success
}

function Ensure-JsonFile {
    param(
        [string]$Path,
        [object]$Value
    )

    if (Test-Path $Path) {
        return
    }

    $directory = Split-Path -Parent $Path
    if (-not (Test-Path $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }

    $Value | ConvertTo-Json -Depth 8 | Set-Content -Path $Path -Encoding UTF8
    Write-DeployLog "Created default configuration: $Path" -Level Success
}

function Update-NotificationDashboardUrl {
    param([string]$Path)

    if (-not (Test-Path $Path)) {
        return
    }

    try {
        $config = Get-Content -Path $Path -Raw | ConvertFrom-Json
    }
    catch {
        Write-DeployLog "Notification config is not valid JSON and was left unchanged: $Path" -Level Warning
        return
    }

    if ($null -eq $config.Notifications) {
        $config | Add-Member -MemberType NoteProperty -Name Notifications -Value ([pscustomobject]@{}) -Force
    }

    $dashboardUrl = "http://localhost:$WebDashboardPort"
    $currentUrl = [string]$config.Notifications.DashboardURL
    if ([string]::IsNullOrWhiteSpace($currentUrl) -or $currentUrl -match '^http://localhost:(8080|8090)/?$') {
        $config.Notifications | Add-Member -MemberType NoteProperty -Name DashboardURL -Value $dashboardUrl -Force
        $config | ConvertTo-Json -Depth 8 | Set-Content -Path $Path -Encoding UTF8
        Write-DeployLog "Updated dashboard notification URL: $dashboardUrl" -Level Success
    }
}

function Ensure-WebDashboardConfiguration {
    $targets = @($ProjectRoot)
    if (-not ((Resolve-Path $ProjectRoot).Path.TrimEnd('\')).Equals($InstallPath.TrimEnd('\'), [System.StringComparison]::OrdinalIgnoreCase)) {
        $targets += $InstallPath
    }

    foreach ($targetRoot in $targets) {
        foreach ($folder in @("Config", "Logs", "Patches")) {
            $folderPath = Join-Path $targetRoot $folder
            if (-not (Test-Path $folderPath)) {
                New-Item -ItemType Directory -Path $folderPath -Force | Out-Null
                Write-DeployLog "Created folder: $folderPath" -Level Success
            }
        }

        Ensure-JsonFile -Path (Join-Path $targetRoot "Config\dashboard-settings.json") -Value ([pscustomobject]@{
            RefreshIntervalSeconds = 30
            AutoRefreshEnabled     = $true
            SessionTimeoutMinutes  = 30
        })

        $distributedPath = Join-Path $targetRoot "Config\distributed.json"
        $distributedConfig = [pscustomobject]@{
            DeploymentRole            = $DeploymentRole
            CollectorNodeName         = if ([string]::IsNullOrWhiteSpace($CollectorNodeName)) { $env:COMPUTERNAME } else { $CollectorNodeName }
            SiteName                  = $CollectorSite
            Tags                      = $CollectorTags
            CentralRepositoryServer   = $RepositoryServer
            CentralRepositoryDatabase = $RepositoryDatabase
        }
        if (Test-Path $distributedPath) {
            try {
                $existing = Get-Content -Path $distributedPath -Raw | ConvertFrom-Json
                $existing | Add-Member -MemberType NoteProperty -Name DeploymentRole -Value $distributedConfig.DeploymentRole -Force
                $existing | Add-Member -MemberType NoteProperty -Name CollectorNodeName -Value $distributedConfig.CollectorNodeName -Force
                $existing | Add-Member -MemberType NoteProperty -Name SiteName -Value $distributedConfig.SiteName -Force
                $existing | Add-Member -MemberType NoteProperty -Name Tags -Value $distributedConfig.Tags -Force
                $existing | Add-Member -MemberType NoteProperty -Name CentralRepositoryServer -Value $distributedConfig.CentralRepositoryServer -Force
                $existing | Add-Member -MemberType NoteProperty -Name CentralRepositoryDatabase -Value $distributedConfig.CentralRepositoryDatabase -Force
                $existing | ConvertTo-Json -Depth 8 | Set-Content -Path $distributedPath -Encoding UTF8
            }
            catch {
                $distributedConfig | ConvertTo-Json -Depth 8 | Set-Content -Path $distributedPath -Encoding UTF8
            }
        }
        else {
            $distributedConfig | ConvertTo-Json -Depth 8 | Set-Content -Path $distributedPath -Encoding UTF8
        }

        $notificationsPath = Join-Path $targetRoot "Config\notifications.json"
        Ensure-JsonFile -Path $notificationsPath -Value ([pscustomobject]@{
            SMTP          = [pscustomobject]@{
                Server                = ""
                Port                  = 25
                From                  = ""
                Username              = ""
                Password              = ""
                EnableSSL             = $false
                UseDefaultCredentials = $true
            }
            Notifications = [pscustomobject]@{
                Enabled              = $false
                Recipients           = ""
                CCRecipients         = @()
                MinSeverity          = "Warning"
                QuietHours           = [pscustomobject]@{ Enabled = $false; Start = "22:00"; End = "07:00" }
                ThrottleMinutes      = 30
                IncludeDashboardLink = $true
                DashboardURL         = "http://localhost:$WebDashboardPort"
            }
            Teams         = [pscustomobject]@{
                Enabled    = $false
                WebhookURL = ""
            }
        })
        Update-NotificationDashboardUrl -Path $notificationsPath
    }
}

function ConvertTo-InstanceObject {
    param([string]$SqlInstance)

    $trimmed = $SqlInstance.Trim()
    if ([string]::IsNullOrWhiteSpace($trimmed)) {
        return $null
    }

    return [pscustomobject]@{
        DisplayName        = $trimmed
        SqlInstance        = $trimmed
        RepositoryServer   = $RepositoryServer
        RepositoryDatabase = $RepositoryDatabase
        Environment        = "Production"
        IsActive           = $true
    }
}

function Save-InstanceConfiguration {
    $instances = @()
    foreach ($instanceName in $MonitoredInstances) {
        $instance = ConvertTo-InstanceObject -SqlInstance $instanceName
        if ($null -ne $instance) {
            $instances += $instance
        }
    }

    if ($instances.Count -eq 0) {
        if ($DeploymentRole -ne 'Collector') {
            $instances += [pscustomobject]@{
                DisplayName        = $RepositoryServer
                SqlInstance        = $RepositoryServer
                RepositoryServer   = $RepositoryServer
                RepositoryDatabase = $RepositoryDatabase
                Environment        = "Production"
                IsActive           = $true
            }
        }
    }

    $configTargets = @($ProjectRoot)
    if (-not ((Resolve-Path $ProjectRoot).Path.TrimEnd('\')).Equals($InstallPath.TrimEnd('\'), [System.StringComparison]::OrdinalIgnoreCase)) {
        $configTargets += $InstallPath
    }

    foreach ($targetRoot in $configTargets) {
        $configDir = Join-Path $targetRoot "Config"
        if (-not (Test-Path $configDir)) {
            New-Item -ItemType Directory -Path $configDir -Force | Out-Null
        }

        $instancesPath = Join-Path $configDir "instances.json"
        $instancesJson = if ($instances.Count -eq 0) { '[]' } else { $instances | ConvertTo-Json -Depth 5 }
        $instancesJson | Set-Content -Path $instancesPath -Encoding UTF8
        Write-DeployLog "Updated instance configuration: $instancesPath" -Level Success
    }

    foreach ($instance in $instances) {
        $serverName = $instance.SqlInstance.Split('\')[0].Replace("'", "''")
        $instanceName = if ($instance.SqlInstance.Contains("\")) { $instance.SqlInstance.Split('\')[1] } else { "MSSQLSERVER" }
        $displayName = $instance.DisplayName.Replace("'", "''")
        $environment = $instance.Environment.Replace("'", "''")
        $sqlInstanceEscaped = $instance.SqlInstance.Replace("'", "''")
        $query = @"
IF NOT EXISTS (SELECT 1 FROM mon.MonitoredInstances WHERE DisplayName = N'$displayName')
BEGIN
    INSERT INTO mon.MonitoredInstances (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
    VALUES (N'$serverName', N'$($instanceName.Replace("'", "''"))', N'$displayName', N'$environment', 1);
END
ELSE
BEGIN
    UPDATE mon.MonitoredInstances
    SET ServerName = N'$serverName',
        InstanceName = N'$($instanceName.Replace("'", "''"))',
        EnvironmentName = N'$environment',
        IsActive = 1
    WHERE DisplayName = N'$displayName';
END;
"@
        Invoke-DeploySqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
        Write-DeployLog "Registered monitored instance: $sqlInstanceEscaped"
    }
}

function Register-DeploymentCollectorNode {
    if ($DeploymentRole -notin @('Standalone', 'Central', 'Collector')) {
        return
    }

    $nodeName = if ([string]::IsNullOrWhiteSpace($CollectorNodeName)) { $env:COMPUTERNAME } else { $CollectorNodeName }
    $nodeNameSql = Escape-SqlLiteral $nodeName
    $hostNameSql = Escape-SqlLiteral ([string]$env:COMPUTERNAME)
    $roleSql = Escape-SqlLiteral $DeploymentRole
    $siteSql = Escape-SqlLiteral $CollectorSite
    $tagsSql = Escape-SqlLiteral $CollectorTags
    $query = @"
MERGE mon.CollectorNodes AS target
USING (SELECT N'$nodeNameSql' AS NodeName) AS source
ON target.NodeName = source.NodeName
WHEN MATCHED THEN
    UPDATE SET HostName = N'$hostNameSql',
               DeploymentRole = N'$roleSql',
               SiteName = N'$siteSql',
               Tags = N'$tagsSql',
               IsEnabled = 1,
               LastHeartbeat = SYSDATETIME(),
               LastSeenStatus = N'Deployed'
WHEN NOT MATCHED THEN
    INSERT (NodeName, HostName, DeploymentRole, SiteName, Tags, IsEnabled, LastHeartbeat, LastSeenStatus)
    VALUES (N'$nodeNameSql', N'$hostNameSql', N'$roleSql', N'$siteSql', N'$tagsSql', 1, SYSDATETIME(), N'Deployed');
"@
    Invoke-DeploySqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
    Write-DeployLog "Registered collector node: $nodeName ($DeploymentRole)" -Level Success
}

function Sync-DefaultCollectorAssignments {
    $nodeName = if ([string]::IsNullOrWhiteSpace($CollectorNodeName)) { $env:COMPUTERNAME } else { $CollectorNodeName }
    $nodeNameSql = Escape-SqlLiteral $nodeName
    $query = @"
DECLARE @CollectorNodeID INT = (SELECT CollectorNodeID FROM mon.CollectorNodes WHERE NodeName = N'$nodeNameSql');
IF @CollectorNodeID IS NOT NULL
BEGIN
    INSERT INTO mon.CollectorAssignments (CollectorNodeID, InstanceID, CollectorGroup, IsEnabled, AssignedBy)
    SELECT @CollectorNodeID, mi.InstanceID, N'All', 1, N'Deployment'
    FROM mon.MonitoredInstances mi
    WHERE mi.IsActive = 1
      AND NOT EXISTS (
          SELECT 1
          FROM mon.CollectorAssignments ca
          WHERE ca.CollectorNodeID = @CollectorNodeID
            AND ca.InstanceID = mi.InstanceID
            AND ca.CollectorGroup = N'All'
            AND ca.IsEnabled = 1
      );
END;
"@
    Invoke-DeploySqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
    Write-DeployLog "Synchronized default collector assignments for $nodeName" -Level Success
}

function Copy-ApplicationFiles {
    $resolvedSource = (Resolve-Path $ProjectRoot).Path.TrimEnd('\')
    $target = $InstallPath.TrimEnd('\')

    if ($resolvedSource.Equals($target, [System.StringComparison]::OrdinalIgnoreCase)) {
        Write-DeployLog "Install path is the current project path; script copy skipped."
        return
    }

    if (Test-Path $target) {
        Write-DeployLog "Install path already exists; updating SQL Monitor files in place: $target"
    }
    else {
        Write-DeployLog "Creating install path: $target"
    }

    New-Item -ItemType Directory -Path $target -Force | Out-Null
    $excludeDirs = @(".git", ".qoder", "Logs", "Patches")
    $excludeFileNames = @("user_block.txt")
    $excludeFilePatterns = @("*.backup", "*.old", "*.new", "*.bak", "*.tmp", "Fix-*.ps1", "Rewrite-*.ps1")

    # Ensure new dashboard UI and WebAgent module files are included during deployment.
    # The recursive copy process deploys updated project files including Modules\WebAgent.psm1 and GUI\SQLMonitorDashboard.ps1.
    function Test-DeploymentItemExcluded {
        param([System.IO.FileSystemInfo]$Item)
        if ($Item.PSIsContainer) {
            return ($excludeDirs -contains $Item.Name)
        }
        if ($excludeFileNames -contains $Item.Name) { return $true }
        foreach ($pattern in $excludeFilePatterns) {
            if ($Item.Name -like $pattern) { return $true }
        }
        return $false
    }

    function Remove-ExcludedDeploymentFiles {
        param([string]$TargetDirectory)
        if (-not (Test-Path $TargetDirectory -PathType Container)) { return }
        $removed = 0
        Get-ChildItem -Path $TargetDirectory -Recurse -Force | Where-Object {
            -not $_.PSIsContainer -and (Test-DeploymentItemExcluded -Item $_)
        } | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Force
            $removed++
        }
        if ($removed -gt 0) {
            Write-DeployLog "Removed $removed excluded temporary or backup file(s) from $TargetDirectory"
        }
    }

    function Copy-DirectoryContents {
        param(
            [string]$SourceDirectory,
            [string]$DestinationDirectory
        )

        New-Item -ItemType Directory -Path $DestinationDirectory -Force | Out-Null
        Get-ChildItem -Path $SourceDirectory -Force | ForEach-Object {
            if (Test-DeploymentItemExcluded -Item $_) { return }
            $childDestination = Join-Path $DestinationDirectory $_.Name
            if ($_.PSIsContainer) {
                Copy-DirectoryContents -SourceDirectory $_.FullName -DestinationDirectory $childDestination
            }
            else {
                Copy-Item -LiteralPath $_.FullName -Destination $childDestination -Force
            }
        }
    }

    Remove-ExcludedDeploymentFiles -TargetDirectory $target

    Get-ChildItem -Path $ProjectRoot -Force | Where-Object { -not (Test-DeploymentItemExcluded -Item $_) } | ForEach-Object {
        $destination = Join-Path $target $_.Name
        if ($_.PSIsContainer) {
            Copy-DirectoryContents -SourceDirectory $_.FullName -DestinationDirectory $destination
        }
        else {
            Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
        }
    }

    Write-DeployLog "Application scripts copied to $target" -Level Success
}

function Escape-SqlLiteral {
    param([string]$Value)
    return $Value.Replace("'", "''")
}

function Get-AgentJobCommand {
    param(
        [string]$ScriptPath,
        [string]$Arguments = ""
    )

    $escapedScript = $ScriptPath.Replace('"', '\"')
    return "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$escapedScript`" $Arguments"
}

function Set-SqlAgentJob {
    param(
        [string]$JobName,
        [string]$Command,
        [string]$ScheduleName,
        [string]$Frequency,
        [int]$IntervalMinutes = 0,
        [string]$DailyStartTime = "020000"
    )

    $jobNameSql = Escape-SqlLiteral $JobName
    $commandSql = Escape-SqlLiteral $Command
    $scheduleNameSql = Escape-SqlLiteral $ScheduleName

    if ($Frequency -eq "Minutes") {
        $freqType = 4
        $freqSubdayType = 4
        $freqSubdayInterval = [Math]::Max(1, $IntervalMinutes)
        $activeStartTime = 0
    }
    else {
        $freqType = 4
        $freqSubdayType = 1
        $freqSubdayInterval = 0
        $activeStartTime = [int]$DailyStartTime
    }

    $sql = @"
USE [msdb];

DECLARE @jobId UNIQUEIDENTIFIER;

IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'$jobNameSql')
BEGIN
    EXEC dbo.sp_delete_job @job_name = N'$jobNameSql', @delete_unused_schedule = 1;
END;

EXEC dbo.sp_add_job
    @job_name = N'$jobNameSql',
    @enabled = 1,
    @description = N'SQL Monitor automated deployment job',
    @category_name = N'Database Maintenance',
    @job_id = @jobId OUTPUT;

EXEC dbo.sp_add_jobstep
    @job_id = @jobId,
    @step_name = N'Run SQL Monitor collector',
    @subsystem = N'CmdExec',
    @command = N'$commandSql',
    @database_name = N'master',
    @on_success_action = 1,
    @on_fail_action = 2;

EXEC dbo.sp_add_schedule
    @schedule_name = N'$scheduleNameSql',
    @enabled = 1,
    @freq_type = $freqType,
    @freq_interval = 1,
    @freq_subday_type = $freqSubdayType,
    @freq_subday_interval = $freqSubdayInterval,
    @active_start_time = $activeStartTime;

EXEC dbo.sp_attach_schedule
    @job_id = @jobId,
    @schedule_name = N'$scheduleNameSql';

EXEC dbo.sp_add_jobserver
    @job_id = @jobId,
    @server_name = N'(LOCAL)';
"@
    $targetJobServer = if ([string]::IsNullOrWhiteSpace($JobServer)) { $RepositoryServer } else { $JobServer }
    Invoke-DeploySqlNonQuery -ServerInstance $targetJobServer -Database "msdb" -Query $sql -Timeout 0
    Write-DeployLog "Configured SQL Agent job on ${targetJobServer}: $JobName" -Level Success
}

function Set-SqlAgentTsqlJob {
    param(
        [string]$JobName,
        [string]$Command,
        [string]$DatabaseName,
        [string]$ScheduleName,
        [int]$IntervalMinutes = 15
    )

    $jobNameSql = Escape-SqlLiteral $JobName
    $commandSql = Escape-SqlLiteral $Command
    $databaseNameSql = Escape-SqlLiteral $DatabaseName
    $scheduleNameSql = Escape-SqlLiteral $ScheduleName
    $freqSubdayInterval = [Math]::Max(1, $IntervalMinutes)

    $sql = @"
USE [msdb];

DECLARE @jobId UNIQUEIDENTIFIER;

IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'$jobNameSql')
BEGIN
    EXEC dbo.sp_delete_job @job_name = N'$jobNameSql', @delete_unused_schedule = 1;
END;

EXEC dbo.sp_add_job
    @job_name = N'$jobNameSql',
    @enabled = 1,
    @description = N'SQL Monitor central repository sync job',
    @category_name = N'Database Maintenance',
    @job_id = @jobId OUTPUT;

EXEC dbo.sp_add_jobstep
    @job_id = @jobId,
    @step_name = N'Sync local repository to central repository',
    @subsystem = N'TSQL',
    @command = N'$commandSql',
    @database_name = N'$databaseNameSql',
    @on_success_action = 1,
    @on_fail_action = 2;

EXEC dbo.sp_add_schedule
    @schedule_name = N'$scheduleNameSql',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 4,
    @freq_subday_interval = $freqSubdayInterval,
    @active_start_time = 0;

EXEC dbo.sp_attach_schedule
    @job_id = @jobId,
    @schedule_name = N'$scheduleNameSql';

EXEC dbo.sp_add_jobserver
    @job_id = @jobId,
    @server_name = N'(LOCAL)';
"@
    $targetJobServer = if ([string]::IsNullOrWhiteSpace($JobServer)) { $RepositoryServer } else { $JobServer }
    Invoke-DeploySqlNonQuery -ServerInstance $targetJobServer -Database "msdb" -Query $sql -Timeout 0
    Write-DeployLog "Configured SQL Agent job on ${targetJobServer}: $JobName" -Level Success
}

function Configure-CentralLinkedServer {
    if (-not $ConfigureCentralLinkedServer) {
        return
    }

    if ([string]::IsNullOrWhiteSpace($CentralLinkedServer)) {
        throw "Central linked server name is required when -ConfigureCentralLinkedServer is used."
    }
    if ([string]::IsNullOrWhiteSpace($CentralServerInstance)) {
        throw "Central destination SQL Server is required when -ConfigureCentralLinkedServer is used. Pass -CentralServerInstance <central SQL Server>."
    }

    $linkedServerSql = Escape-SqlLiteral $CentralLinkedServer
    $centralServerSql = Escape-SqlLiteral $CentralServerInstance
    $providerSql = Escape-SqlLiteral $CentralLinkedServerProvider
    $loginSql = Escape-SqlLiteral $CentralLinkedServerLogin
    $passwordSql = Escape-SqlLiteral $CentralLinkedServerPassword
    $useSelf = if ([string]::IsNullOrWhiteSpace($CentralLinkedServerLogin)) { "True" } else { "False" }
    $loginBlock = if ([string]::IsNullOrWhiteSpace($CentralLinkedServerLogin)) {
        "EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname = N'$linkedServerSql', @useself = N'True';"
    }
    else {
        "EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname = N'$linkedServerSql', @useself = N'False', @locallogin = NULL, @rmtuser = N'$loginSql', @rmtpassword = N'$passwordSql';"
    }

    $sql = @"
USE [master];

IF EXISTS (SELECT 1 FROM sys.servers WHERE name = N'$linkedServerSql')
BEGIN
    EXEC master.dbo.sp_dropserver @server = N'$linkedServerSql', @droplogins = 'droplogins';
END;

EXEC master.dbo.sp_addlinkedserver
    @server = N'$linkedServerSql',
    @srvproduct = N'',
    @provider = N'$providerSql',
    @datasrc = N'$centralServerSql';

$loginBlock

EXEC master.dbo.sp_serveroption @server=N'$linkedServerSql', @optname=N'data access', @optvalue=N'true';
EXEC master.dbo.sp_serveroption @server=N'$linkedServerSql', @optname=N'rpc', @optvalue=N'true';
EXEC master.dbo.sp_serveroption @server=N'$linkedServerSql', @optname=N'rpc out', @optvalue=N'true';
"@

    Invoke-DeploySqlNonQuery -ServerInstance $RepositoryServer -Database "master" -Query $sql -Timeout 0

    $testSql = "SELECT TOP (1) name FROM [$CentralLinkedServer].master.sys.databases;"
    Invoke-DeploySqlScalar -ServerInstance $RepositoryServer -Database "master" -Query $testSql | Out-Null
    Write-DeployLog "Configured linked server [$CentralLinkedServer] from [$RepositoryServer] to central SQL Server [$CentralServerInstance] using provider [$CentralLinkedServerProvider]." -Level Success
}

function Get-Hhmmss {
    param([string]$TimeValue)

    try {
        $parsed = [datetime]::Parse($TimeValue)
        return $parsed.ToString("HHmmss")
    }
    catch {
        return "020000"
    }
}

function Test-DeployIsAdministrator {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        return $false
    }
}

function Configure-SqlAgentJobs {
    if ($DeploymentRole -eq 'Collector' -and [string]::IsNullOrWhiteSpace($JobServer)) {
        throw "Collector-node SQL Agent jobs must be configured on the collector host. Re-run with -JobServer <collector SQL Agent instance> or use -ConfigureWindowsTasks."
    }

    $jobRoot = Join-Path $InstallPath "Jobs"
    if (-not (Test-Path $jobRoot)) {
        $jobRoot = Join-Path $ProjectRoot "Jobs"
    }

    $dailyStart = Get-Hhmmss -TimeValue $DailyTime
    $retentionStart = Get-Hhmmss -TimeValue $RetentionTime
    $runner = Join-Path $jobRoot "Run-Collectors-InstanceGroup.ps1"

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Core Collectors" `
        -Command (Get-AgentJobCommand -ScriptPath $runner -Arguments "-CollectorGroup Core") `
        -ScheduleName "SQLMonitor - Core Every $CoreIntervalMinutes Minutes" `
        -Frequency "Minutes" `
        -IntervalMinutes $CoreIntervalMinutes

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Advanced Collectors" `
        -Command (Get-AgentJobCommand -ScriptPath $runner -Arguments "-CollectorGroup Advanced") `
        -ScheduleName "SQLMonitor - Advanced Every $AdvancedIntervalMinutes Minutes" `
        -Frequency "Minutes" `
        -IntervalMinutes $AdvancedIntervalMinutes

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Daily Collectors" `
        -Command (Get-AgentJobCommand -ScriptPath $runner -Arguments "-CollectorGroup Daily") `
        -ScheduleName "SQLMonitor - Daily Collectors" `
        -Frequency "Daily" `
        -DailyStartTime $dailyStart

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Alert Engine" `
        -Command (Get-AgentJobCommand -ScriptPath (Join-Path $jobRoot "Run-AlertEngine.ps1")) `
        -ScheduleName "SQLMonitor - Alert Engine Every 2 Minutes" `
        -Frequency "Minutes" `
        -IntervalMinutes 2

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Windows VM Collectors" `
        -Command (Get-AgentJobCommand -ScriptPath (Join-Path $jobRoot "Run-WindowsVMCollectors.ps1")) `
        -ScheduleName "SQLMonitor - Windows VM Every $CoreIntervalMinutes Minutes" `
        -Frequency "Minutes" `
        -IntervalMinutes $CoreIntervalMinutes

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Windows VM Baseline Analysis" `
        -Command (Get-AgentJobCommand -ScriptPath (Join-Path $jobRoot "Run-WindowsBaselineAnalysis.ps1")) `
        -ScheduleName "SQLMonitor - Windows VM Baseline Analysis Daily" `
        -Frequency "Daily" `
        -DailyStartTime "010000"

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Retention Purge" `
        -Command (Get-AgentJobCommand -ScriptPath (Join-Path $jobRoot "Purge-Retention.ps1")) `
        -ScheduleName "SQLMonitor - Retention Purge" `
        -Frequency "Daily" `
        -DailyStartTime $retentionStart

    if (-not [string]::IsNullOrWhiteSpace($CentralLinkedServer)) {
        $centralLinkedServerSql = Escape-SqlLiteral $CentralLinkedServer
        $repositoryDatabaseSql = Escape-SqlLiteral $RepositoryDatabase
        $syncLookback = [Math]::Max(60, $CentralSyncIntervalMinutes * 4)
        Set-SqlAgentTsqlJob `
            -JobName "SQLMonitor - Central Repository Sync" `
            -Command "EXEC mon.usp_SyncRepositoryToCentral @CentralLinkedServer = N'$centralLinkedServerSql', @CentralDatabase = N'$repositoryDatabaseSql', @LookbackMinutes = $syncLookback;" `
            -DatabaseName $RepositoryDatabase `
            -ScheduleName "SQLMonitor - Central Sync Every $CentralSyncIntervalMinutes Minutes" `
            -IntervalMinutes $CentralSyncIntervalMinutes
    }

    # Add new jobs for Task/Ticket system
    Set-SqlAgentJob `
        -JobName "SQLMonitor - Auto-Convert Alerts to Tickets" `
        -Command (Get-AgentJobCommand -ScriptPath (Join-Path $jobRoot "Create-TicketsFromAlerts.ps1")) `
        -ScheduleName "SQLMonitor - Auto-Convert Every 5 Minutes" `
        -Frequency "Minutes" `
        -IntervalMinutes 5

    Set-SqlAgentJob `
        -JobName "SQLMonitor - Process Ticket Escalations" `
        -Command (Get-AgentJobCommand -ScriptPath (Join-Path $jobRoot "Process-TicketEscalations.ps1")) `
        -ScheduleName "SQLMonitor - Escalation Every 10 Minutes" `
        -Frequency "Minutes" `
        -IntervalMinutes 10

    if ($ConfigurePerInstanceJobs) {
        foreach ($instanceName in $MonitoredInstances) {
            if ([string]::IsNullOrWhiteSpace($instanceName)) { continue }
            $safeName = ($instanceName -replace '[\\/:*?"<>|]', '_')
            Set-SqlAgentJob `
                -JobName "SQLMonitor - $safeName - Core" `
                -Command (Get-AgentJobCommand -ScriptPath $runner -Arguments "-CollectorGroup Core -InstanceFilter `"$instanceName`"") `
                -ScheduleName "SQLMonitor - $safeName - Core Every $CoreIntervalMinutes Minutes" `
                -Frequency "Minutes" `
                -IntervalMinutes $CoreIntervalMinutes
        }
    }
}

function Configure-WindowsScheduledTasks {
    if ($WindowsTaskRunAs -eq "System" -and -not (Test-DeployIsAdministrator)) {
        $message = "Windows Scheduled Tasks were requested as SYSTEM, but this deployment session is not elevated."
        if ($ConfigureSqlAgentJobs) {
            Write-DeployLog "$message SQL Agent jobs were configured, so optional Windows Scheduled Tasks were skipped. Re-run as administrator if you also want SYSTEM scheduled tasks." -Level Warning
            return
        }

        throw "$message Re-run PowerShell or the deployment GUI as administrator, or deploy with -WindowsTaskRunAs CurrentUser."
    }

    $taskScript = Join-Path $ProjectRoot "Jobs\Register-SQLMonitorTasks.ps1"
    if (-not (Test-Path $taskScript)) {
        $taskScript = Join-Path $InstallPath "Jobs\Register-SQLMonitorTasks.ps1"
    }

    if (-not (Test-Path $taskScript)) {
        throw "Windows task registration script not found: $taskScript"
    }

    $taskRoot = Join-Path $InstallPath "Jobs"
    if (-not (Test-Path $taskRoot)) {
        $taskRoot = Join-Path $ProjectRoot "Jobs"
    }

    Write-DeployLog "Configuring Windows Scheduled Tasks from $taskScript"
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $taskScript -RunAs $WindowsTaskRunAs -TaskRoot $taskRoot
    if ($LASTEXITCODE -ne 0) {
        throw "Windows Scheduled Task registration failed with exit code $LASTEXITCODE."
    }
}

function Invoke-InitialWindowsVMCollection {
    if ($SkipInitialWindowsVMCollection) {
        Write-DeployLog "Skipping initial Windows VM collection because -SkipInitialWindowsVMCollection was specified."
        return
    }

    $collectorScript = Join-Path $InstallPath "Jobs\Run-WindowsVMCollectors.ps1"
    if (-not (Test-Path $collectorScript -PathType Leaf)) {
        $collectorScript = Join-Path $ProjectRoot "Jobs\Run-WindowsVMCollectors.ps1"
    }

    if (-not (Test-Path $collectorScript -PathType Leaf)) {
        Write-DeployLog "Initial Windows VM collection skipped; collector script was not found." -Level Warning
        return
    }

    try {
        Write-DeployLog "Running initial Windows VM collection to hydrate VM Monitoring dashboard data."
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $collectorScript -PerfSampleSeconds 1 -PerfSamples 1
        if ($LASTEXITCODE -ne 0) {
            Write-DeployLog "Initial Windows VM collection returned exit code $LASTEXITCODE. Scheduled collectors will retry on the next interval." -Level Warning
            return
        }
        Write-DeployLog "Initial Windows VM collection completed." -Level Success
    }
    catch {
        Write-DeployLog "Initial Windows VM collection failed: $($_.Exception.Message). Scheduled collectors will retry on the next interval." -Level Warning
    }
}

function Invoke-FullDeployment {
    if ($All) {
        $script:DeployDatabase = $true
        $script:DeployScripts = $true
        $script:ConfigureSqlAgentJobs = $true
    }

    if (-not ($DeployDatabase -or $DeployScripts -or $ConfigureSqlAgentJobs -or $ConfigureWindowsTasks)) {
        throw "No deployment action selected. Use -All or choose one or more deployment switches."
    }

    Write-DeployLog "Starting SQL Monitor deployment"
    Write-DeployLog "Repository: $RepositoryServer / $RepositoryDatabase"
    Write-DeployLog "Install path: $InstallPath"
    Write-DeployLog "Deployment role: $DeploymentRole"
    if ($ConfigureCentralLinkedServer) {
        Write-DeployLog "Central linked server: $CentralLinkedServer -> $CentralServerInstance"
    }

    if ($DeployScripts) {
        Copy-ApplicationFiles
    }

    Ensure-WebDashboardConfiguration

    if ($DeployDatabase) {
        Deploy-RepositorySchema
        Register-DeploymentCollectorNode
        Configure-CentralLinkedServer
        if (-not $SkipInstanceConfiguration) {
            Save-InstanceConfiguration
        }
        if ($DeploymentRole -in @('Standalone', 'Central')) {
            Sync-DefaultCollectorAssignments
        }
    }
    elseif ($MonitoredInstances.Count -gt 0 -and -not $SkipInstanceConfiguration) {
        Save-InstanceConfiguration
    }
    elseif ($ConfigureCentralLinkedServer) {
        Configure-CentralLinkedServer
    }

    if ($ConfigureSqlAgentJobs) {
        Configure-SqlAgentJobs
    }

    if ($ConfigureWindowsTasks) {
        Configure-WindowsScheduledTasks
    }

    if ($DeployDatabase -or $ConfigureSqlAgentJobs -or $ConfigureWindowsTasks -or $All) {
        Invoke-InitialWindowsVMCollection
    }

    Write-DeployLog "SQL Monitor deployment finished." -Level Success
    Write-DeployLog "Web dashboard: $InstallPath\Launch-WebDashboard.bat (default http://localhost:$WebDashboardPort/)" -Level Success
    Write-DeployLog "Fresh repository bootstrap login: admin / Admin@123. Existing repositories keep their current dashboard passwords." -Level Warning
}

try {
    Invoke-FullDeployment
}
catch {
    Write-DeployLog $_.Exception.Message -Level Error
    exit 1
}
