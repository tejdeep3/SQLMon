USE DBA_SQLMonitor;
GO

IF COL_LENGTH('mon.AlertHistory', 'RepeatCount') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory
    ADD RepeatCount INT NOT NULL
        CONSTRAINT DF_AlertHistory_RepeatCount DEFAULT (1);
END
GO

IF COL_LENGTH('mon.AlertHistory', 'FirstAlertTime') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD FirstAlertTime DATETIME2 NULL;
END
GO

IF COL_LENGTH('mon.AlertHistory', 'LastRepeatedAt') IS NULL
BEGIN
    ALTER TABLE mon.AlertHistory ADD LastRepeatedAt DATETIME2 NULL;
END
GO

UPDATE mon.AlertHistory
SET FirstAlertTime = ISNULL(FirstAlertTime, AlertTime),
    LastRepeatedAt = ISNULL(LastRepeatedAt, AlertTime),
    RepeatCount = CASE WHEN ISNULL(RepeatCount, 0) < 1 THEN 1 ELSE RepeatCount END
WHERE FirstAlertTime IS NULL
   OR LastRepeatedAt IS NULL
   OR ISNULL(RepeatCount, 0) < 1;
GO

CREATE OR ALTER PROCEDURE mon.usp_AcknowledgeAlert
    @AlertID BIGINT,
    @AcknowledgedBy NVARCHAR(128)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @InstanceID INT, @ModuleName NVARCHAR(100), @AlertTitle NVARCHAR(300);

    SELECT @InstanceID = InstanceID, @ModuleName = ModuleName, @AlertTitle = AlertTitle
    FROM mon.AlertHistory
    WHERE AlertID = @AlertID;

    UPDATE mon.AlertHistory
    SET
        IsAcknowledged = 1,
        AcknowledgedBy = @AcknowledgedBy,
        AcknowledgedOn = SYSDATETIME()
    WHERE InstanceID = @InstanceID
      AND ModuleName = @ModuleName
      AND AlertTitle = @AlertTitle
      AND IsAcknowledged = 0;

    SELECT @@ROWCOUNT AS RowsUpdated;
END
GO

CREATE OR ALTER VIEW mon.vw_OpenAlertsDetailed
AS
WITH ranked AS
(
    SELECT
        ah.AlertID,
        ah.InstanceID,
        mi.DisplayName,
        ah.AlertTime,
        ah.Severity,
        ah.ModuleName,
        ah.AlertTitle,
        ah.AlertDetails,
        ah.IsAcknowledged,
        SUM(ISNULL(ah.RepeatCount, 1)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS RepeatCount,
        MIN(COALESCE(ah.FirstAlertTime, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS FirstAlertTime,
        MAX(COALESCE(ah.LastRepeatedAt, ah.AlertTime)) OVER (PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle) AS LastRepeatedAt,
        ROW_NUMBER() OVER (
            PARTITION BY ah.InstanceID, ah.ModuleName, ah.AlertTitle
            ORDER BY CASE ah.Severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END, ah.AlertTime DESC, ah.AlertID DESC
        ) AS rn
    FROM mon.AlertHistory ah
    INNER JOIN mon.MonitoredInstances mi
        ON ah.InstanceID = mi.InstanceID
    WHERE ah.IsAcknowledged = 0
)
SELECT
    AlertID,
    InstanceID,
    DisplayName,
    AlertTime,
    DATEDIFF(MINUTE, FirstAlertTime, SYSDATETIME()) AS AlertAgeMinutes,
    Severity,
    ModuleName,
    AlertTitle,
    AlertDetails,
    IsAcknowledged,
    RepeatCount,
    FirstAlertTime,
    LastRepeatedAt
FROM ranked
WHERE rn = 1;
GO
