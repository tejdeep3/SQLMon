$projectRoot = $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force

$repositorySettings = Get-SqlMonitorRepositorySettings
$sqlFile = Join-Path $projectRoot 'Sql\09_Dashboard_Views_Fix.sql'

if (-not (Test-Path $sqlFile)) {
    Write-Host "ERROR: SQL file not found at $sqlFile" -ForegroundColor Red
    return
}

$sqlContent = Get-Content -Path $sqlFile -Raw
$statements = $sqlContent -split '(?m)^\s*GO\s*$'

Write-Host "Deploying missing dashboard views to $($repositorySettings.RepositoryServer).$($repositorySettings.RepositoryDatabase)..." -ForegroundColor Cyan

foreach ($statement in $statements) {
    $trimmedStatement = $statement.Trim()
    if ($trimmedStatement.StartsWith('USE ')) {
        continue
    }

    if ($trimmedStatement.Length -gt 0) {
        try {
            Invoke-MonitorSqlNonQuery `
                -ServerInstance $repositorySettings.RepositoryServer `
                -Database $repositorySettings.RepositoryDatabase `
                -Query $trimmedStatement
            Write-Host 'Executed statement successfully.' -ForegroundColor Green
        }
        catch {
            Write-Host "ERROR executing statement: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

Write-Host 'Deployment complete.' -ForegroundColor Green
