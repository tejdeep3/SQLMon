# Test Email and Teams Notifications
# Run this after configuring notifications.json

$ErrorActionPreference = "Stop"

$ProjectRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

Import-Module (Join-Path $ProjectRoot "Modules\Invoke-AlertEngine.psm1") -Force
Import-Module (Join-Path $ProjectRoot "Modules\Common.psm1") -Force

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  Testing SQL Monitor Notifications" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Load config
$configPath = Join-Path $ProjectRoot "Config\notifications.json"
Write-Host "Loading notification config..." -ForegroundColor Yellow

if (-not (Test-Path $configPath)) {
    Write-Host "ERROR: notifications.json not found!" -ForegroundColor Red
    exit 1
}

$notificationConfig = Get-Content $configPath | ConvertFrom-Json

Write-Host "  SMTP Server: $($notificationConfig.SMTP.Server)" -ForegroundColor Gray
Write-Host "  From: $($notificationConfig.SMTP.From)" -ForegroundColor Gray
Write-Host "  Recipients: $($notificationConfig.Notifications.Recipients -join ', ')" -ForegroundColor Gray
Write-Host "  Teams Enabled: $($notificationConfig.Teams.Enabled)" -ForegroundColor Gray
Write-Host ""

# Create test alert
$testAlert = @{
    'Severity' = 'Warning'
    'AlertType' = 'Test Alert'
    'DisplayName' = 'BBLBHLAP860\BBDBTESTSQL'
    'MetricName' = 'TestMetric'
    'CurrentValue' = '85.5'
    'ThresholdValue' = '80.0'
    'AlertMessage' = 'This is a test alert from SQL Monitor to verify notifications are working correctly.'
    'AlertTime' = (Get-Date).ToString()
    'InstanceID' = 1
}

# Create DataRow-like object
$testRow = New-Object System.Data.DataRow
$testTable = New-Object System.Data.DataTable
$testTable.Columns.Add("Severity", [string]) | Out-Null
$testTable.Columns.Add("AlertType", [string]) | Out-Null
$testTable.Columns.Add("DisplayName", [string]) | Out-Null
$testTable.Columns.Add("MetricName", [string]) | Out-Null
$testTable.Columns.Add("CurrentValue", [string]) | Out-Null
$testTable.Columns.Add("ThresholdValue", [string]) | Out-Null
$testTable.Columns.Add("AlertMessage", [string]) | Out-Null
$testTable.Columns.Add("AlertTime", [string]) | Out-Null
$testTable.Columns.Add("InstanceID", [int]) | Out-Null
$testRow = $testTable.NewRow()
$testRow['Severity'] = 'Warning'
$testRow['AlertType'] = 'Test Alert'
$testRow['DisplayName'] = 'BBLBHLAP860\BBDBTESTSQL'
$testRow['MetricName'] = 'TestMetric'
$testRow['CurrentValue'] = '85.5'
$testRow['ThresholdValue'] = '80.0'
$testRow['AlertMessage'] = 'This is a test alert from SQL Monitor to verify notifications are working correctly.'
$testRow['AlertTime'] = (Get-Date).ToString()
$testRow['InstanceID'] = 1
$testTable.Rows.Add($testRow)

# Test Email
Write-Host "Testing Email Notification..." -ForegroundColor Yellow
try {
    Send-AlertNotification -Alert $testRow -NotificationConfig $notificationConfig
    Write-Host "  OK - Email sent successfully!" -ForegroundColor Green
}
catch {
    Write-Host "  ERROR - Email failed: $(Get-SqlMonitorExceptionMessage -Exception $_.Exception)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting:" -ForegroundColor Yellow
    Write-Host "  1. Check your Office 365 credentials in notifications.json" -ForegroundColor Gray
    Write-Host "  2. Verify SMTP server: smtp.office365.com:587" -ForegroundColor Gray
    Write-Host "  3. Check if your organization requires app passwords" -ForegroundColor Gray
    Write-Host "  4. Verify firewall allows outbound port 587" -ForegroundColor Gray
}

# Test Teams
Write-Host "`nTesting Teams Notification..." -ForegroundColor Yellow
try {
    Send-TeamsNotification -Alert $testRow -NotificationConfig $notificationConfig
    Write-Host "  OK - Teams message sent successfully!" -ForegroundColor Green
}
catch {
    Write-Host "  ERROR - Teams failed: $(Get-SqlMonitorExceptionMessage -Exception $_.Exception)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Troubleshooting:" -ForegroundColor Yellow
    Write-Host "  1. Verify webhook URL is correct" -ForegroundColor Gray
    Write-Host "  2. Check webhook URL hasn't expired" -ForegroundColor Gray
    Write-Host "  3. Verify Teams connector is still active" -ForegroundColor Gray
}

Write-Host "`nTest complete! Check your email and Teams channel.`n" -ForegroundColor Cyan
