# Fix-WebServerSyntax.ps1 - Fix PowerShell syntax errors in Start-WebServer.ps1
$filePath = Join-Path $PSScriptRoot "Web\Start-WebServer.ps1"
$content = Get-Content $filePath -Raw

# Fix 1: Replace hashtable indexing with switch statements for TicketSeverityID
$content = $content -replace `
    'TicketSeverityID = \(@\{ Critical = 1; High = 2; Medium = 3; Low = 4 \}\[\\$severity\]\)', `
    'TicketSeverityID = $(switch($severity) { "Critical" {1} "High" {2} "Medium" {3} "Low" {4} default {3})'

# Fix 2: Replace hashtable indexing with switch statements for TaskStatusID (status parameter)
$content = $content -replace `
    'TaskStatusID = if \(\$status\) \{ \(@\{ ''Open'' = 1; ''In Progress'' = 2; Pending = 3; Completed = 4; Cancelled = 5; ''On Hold'' = 6 \}\[\\$status\] \) \} else \{ \$null \}', `
    'TaskStatusID = if ($status) { $(switch($status) { "Open" {1} "In Progress" {2} Pending {3} Completed {4} Cancelled {5} "On Hold" {6} default {$null}) } else { $null }'

# Fix 3: Replace hashtable indexing with switch statements for TaskPriorityID (priority parameter)
$content = $content -replace `
    'TaskPriorityID = if \(\$priority\) \{ \(@\{ Critical = 1; High = 2; Medium = 3; Low = 4 \}\[\\$priority\] \) \} else \{ \$null \}', `
    'TaskPriorityID = if ($priority) { $(switch($priority) { "Critical" {1} "High" {2} "Medium" {3} "Low" {4} default {3}) } else { $null }'

# Fix 4: Replace hashtable indexing with switch statements for TaskPriorityID (body.Priority)
$content = $content -replace `
    'TaskPriorityID = \(@\{ Critical = 1; High = 2; Medium = 3; Low = 4 \}\[\[string\]\$body\.Priority\] \)', `
    'TaskPriorityID = $(switch([string]$body.Priority) { "Critical" {1} "High" {2} "Medium" {3} "Low" {4} default {3})'

# Fix 5: Replace hashtable indexing with switch statements for TaskStatusID (body.Status)
$content = $content -replace `
    'TaskStatusID = if \(\$body\.Status\) \{ \(@\{ ''Open'' = 1; ''In Progress'' = 2; Pending = 3; Completed = 4; Cancelled = 5; ''On Hold'' = 6 \}\[\[string\]\$body\.Status\] \) \} else \{ \$null \}', `
    'TaskStatusID = if ($body.Status) { $(switch([string]$body.Status) { "Open" {1} "In Progress" {2} Pending {3} Completed {4} Cancelled {5} "On Hold" {6} default {$null}) } else { $null }'

# Fix 6: Replace hashtable indexing with switch statements for TaskPriorityID (body.Priority)
$content = $content -replace `
    'TaskPriorityID = if \(\$body\.Priority\) \{ \(@\{ Critical = 1; High = 2; Medium = 3; Low = 4 \}\[\[string\]\$body\.Priority\] \) \} else \{ \$null \}', `
    'TaskPriorityID = if ($body.Priority) { $(switch([string]$body.Priority) { "Critical" {1} "High" {2} "Medium" {3} "Low" {4} default {3}) } else { $null }'

Set-Content -Path $filePath -Value $content -Encoding UTF8
Write-Host "Syntax errors fixed in Start-WebServer.ps1"
