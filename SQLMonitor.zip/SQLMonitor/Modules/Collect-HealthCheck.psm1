# Collection Health Monitor - PowerShell Module
# Provides health checking and alerting for SQL Monitor collectors

Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force

function Get-CollectionHealth {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance,
        [switch]$IncludeOK
    )

    $query = @"
EXEC mon.usp_CheckCollectionHealth @IncludeOK = $(if($IncludeOK.IsPresent){1}else{0});
"@

    $result = Invoke-MonitorSqlQuery `
        -ServerInstance $Instance.RepositoryServer `
        -Database $Instance.RepositoryDatabase `
        -Query $query

    return $result
}

function Get-CollectionGaps {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $query = @"
SELECT * FROM mon.vw_CollectionGaps ORDER BY Severity DESC, MinutesAgo DESC;
"@

    $result = Invoke-MonitorSqlQuery `
        -ServerInstance $Instance.RepositoryServer `
        -Database $Instance.RepositoryDatabase `
        -Query $query

    return $result
}

function Test-CollectorHealth {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $gaps = Get-CollectionGaps -Instance $Instance
    
    if ($gaps.Rows.Count -gt 0) {
        Write-MonitorLog "WARNING: $($gaps.Rows.Count) collection issues detected for $($Instance.DisplayName)"
        
        foreach ($gap in $gaps.Rows) {
            $severity = if ($gap['Severity'] -eq 3) { "CRITICAL" } 
                       elseif ($gap['Severity'] -eq 2) { "WARNING" } 
                       else { "INFO" }
            
            Write-MonitorLog "$severity - $($gap['ModuleName']): $($gap['IssueDescription'])"
        }
        
        return $false
    }
    else {
        Write-MonitorLog "All collectors healthy for $($Instance.DisplayName)"
        return $true
    }
}

function Send-HealthAlert {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $gaps = Get-CollectionGaps -Instance $Instance
    
    if ($gaps.Rows.Count -gt 0) {
        $criticalIssues = $gaps.Rows | Where-Object { $_['Severity'] -eq 3 }
        
        if ($criticalIssues.Count -gt 0) {
            $alertMessage = "Collection Health Alert for $($Instance.DisplayName):`n`n"
            $alertMessage += "$($criticalIssues.Count) critical issue(s) detected:`n`n"
            
            foreach ($issue in $criticalIssues) {
                $alertMessage += "- $($issue['ModuleName']): $($issue['IssueDescription'])`n"
                if (-not [string]::IsNullOrWhiteSpace($issue['ErrorMessage'])) {
                    $alertMessage += "  Error: $($issue['ErrorMessage'])`n"
                }
            }
            
            Write-MonitorLog $alertMessage
            
            # Could integrate with email notification system here
            return $alertMessage
        }
    }
    
    return $null
}

Export-ModuleMember -Function Get-CollectionHealth, Get-CollectionGaps, Test-CollectorHealth, Send-HealthAlert
