function Invoke-DisksCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "Disks"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Disks collector started for $($Instance.DisplayName)"

        $query = @"
        SELECT DISTINCT
            vs.volume_mount_point as VolumeMountPoint,
            vs.logical_volume_name as LogicalVolumeName,
            CAST(vs.total_bytes / 1024.0 / 1024 / 1024 as decimal(10,2)) as TotalGB,
            CAST(vs.available_bytes / 1024.0 / 1024 / 1024 as decimal(10,2)) as FreeGB,
            CAST((vs.total_bytes - vs.available_bytes) / 1024.0 / 1024 / 1024 as decimal(10,2)) as UsedGB,
            CAST(((vs.total_bytes - vs.available_bytes) * 100.0 / vs.total_bytes) as decimal(5,2)) as UsedPct
        FROM sys.master_files mf
        CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) vs
"@

        $diskData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($diskData.Rows.Count -gt 0) {
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add("InstanceID", [int])
            [void]$targetTable.Columns.Add("CaptureTime", [datetime])
            [void]$targetTable.Columns.Add('VolumeMountPoint', [string])
            [void]$targetTable.Columns.Add('LogicalVolumeName', [string])
            [void]$targetTable.Columns.Add('TotalGB', [decimal])
            [void]$targetTable.Columns.Add('FreeGB', [decimal])
            [void]$targetTable.Columns.Add('UsedGB', [decimal])
            [void]$targetTable.Columns.Add('UsedPct', [decimal])

            $captureTime = [datetime]::Now

            foreach ($row in $diskData.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow["InstanceID"] = $instanceId
                $newRow["CaptureTime"] = $captureTime
                $newRow["VolumeMountPoint"] = $row["VolumeMountPoint"]
                $newRow["LogicalVolumeName"] = $row["LogicalVolumeName"]
                $newRow["TotalGB"] = $row["TotalGB"]
                $newRow["FreeGB"] = $row["FreeGB"]
                $newRow["UsedGB"] = $row["UsedGB"]
                $newRow["UsedPct"] = $row["UsedPct"]
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.DiskVolumeHistory" `
                -DataTable $targetTable

            Write-MonitorLog "Disks collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-DisksCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-DisksCollector
