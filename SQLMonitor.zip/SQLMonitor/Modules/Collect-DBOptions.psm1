function Invoke-DBOptionsCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "DBOptions"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "DB Options collector started for $($Instance.DisplayName)"

        # Updated query to be more robust
        $query = @"
        SELECT
            d.name as DatabaseName,
            d.state_desc as [State],
            d.recovery_model_desc as RecoveryModel,
            d.page_verify_option_desc as PageVerify,
            d.is_auto_close_on as AutoClose,
            d.is_auto_shrink_on as AutoShrink,
            d.is_auto_create_stats_on as IsAutoCreateStatistics,
            d.is_auto_update_stats_on as IsAutoUpdateStatistics,
            d.compatibility_level as CompatibilityLevel,
            d.is_encrypted as IsEncrypted,
            d.is_read_only as IsReadOnly,
            d.collation_name as Collation,
            SUM(CASE WHEN mf.type = 0 THEN mf.size * 8 / 1024.0 ELSE 0 END) as MDFSizeMB,
            CAST(NULL as decimal(18,2)) as MDFUsedMB,
            SUM(CASE WHEN mf.type = 1 THEN mf.size * 8 / 1024.0 ELSE 0 END) as LDFSizeMB,
            CAST(NULL as decimal(18,2)) as LDFUsedMB,
            SUM(CAST(mf.size * 8 / 1024.0 as decimal(18,2))) as SizeMB,
            CAST(0 as decimal(18,2)) as AvailableSpaceMB,
            SUM(CASE WHEN mf.type = 1 THEN mf.size * 8 / 1024.0 ELSE 0 END) as LogSizeMB
        FROM sys.databases d
        LEFT JOIN sys.master_files mf ON d.database_id = mf.database_id
        GROUP BY d.name, d.state_desc, d.recovery_model_desc, d.page_verify_option_desc, d.is_auto_close_on, d.is_auto_shrink_on, d.is_auto_create_stats_on, d.is_auto_update_stats_on, d.compatibility_level, d.is_encrypted, d.is_read_only, d.collation_name
"@

        $dbOptions = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($dbOptions.Rows.Count -gt 0) {
            # Create a DataTable that matches mon.DBOptionsHistory exactly
            $columns = @(Get-MonitorTableColumns -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -TableName 'mon.DBOptionsHistory')
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add("InstanceID", [int])
            [void]$targetTable.Columns.Add("CaptureTime", [datetime])
            [void]$targetTable.Columns.Add("DatabaseName", [string])
            [void]$targetTable.Columns.Add("State", [string])
            [void]$targetTable.Columns.Add("RecoveryModel", [string])
            [void]$targetTable.Columns.Add("PageVerify", [string])
            if ($columns -contains 'AutoClose') { [void]$targetTable.Columns.Add("AutoClose", [bool]) }
            if ($columns -contains 'IsAutoClose') { [void]$targetTable.Columns.Add("IsAutoClose", [bool]) }
            if ($columns -contains 'AutoShrink') { [void]$targetTable.Columns.Add("AutoShrink", [bool]) }
            if ($columns -contains 'IsAutoShrink') { [void]$targetTable.Columns.Add("IsAutoShrink", [bool]) }
            if ($columns -contains 'IsAutoCreateStatistics') { [void]$targetTable.Columns.Add("IsAutoCreateStatistics", [bool]) }
            if ($columns -contains 'IsAutoUpdateStatistics') { [void]$targetTable.Columns.Add("IsAutoUpdateStatistics", [bool]) }
            [void]$targetTable.Columns.Add("CompatibilityLevel", [int])
            [void]$targetTable.Columns.Add("IsEncrypted", [bool])
            [void]$targetTable.Columns.Add("IsReadOnly", [bool])
            if ($columns -contains 'Collation') { [void]$targetTable.Columns.Add("Collation", [string]) }
            if ($columns -contains 'MDFSizeMB') { [void]$targetTable.Columns.Add("MDFSizeMB", [decimal]) }
            if ($columns -contains 'MDFUsedMB') {
                [void]$targetTable.Columns.Add("MDFUsedMB", [decimal])
            }
            if ($columns -contains 'LDFSizeMB') { [void]$targetTable.Columns.Add("LDFSizeMB", [decimal]) }
            if ($columns -contains 'LDFUsedMB') {
                [void]$targetTable.Columns.Add("LDFUsedMB", [decimal])
            }
            if ($columns -contains 'SizeMB') { [void]$targetTable.Columns.Add("SizeMB", [decimal]) }
            if ($columns -contains 'AvailableSpaceMB') { [void]$targetTable.Columns.Add("AvailableSpaceMB", [decimal]) }
            if ($columns -contains 'LogSizeMB') { [void]$targetTable.Columns.Add("LogSizeMB", [decimal]) }

            $captureTime = [datetime]::Now

            foreach ($db in $dbOptions.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow["InstanceID"] = $instanceId
                $newRow["CaptureTime"] = $captureTime
                $newRow["DatabaseName"] = $db["DatabaseName"]
                $newRow["State"] = $db["State"]
                $newRow["RecoveryModel"] = $db["RecoveryModel"]
                $newRow["PageVerify"] = $db["PageVerify"]
                if ($targetTable.Columns.Contains('AutoClose')) { $newRow["AutoClose"] = $db["AutoClose"] }
                if ($targetTable.Columns.Contains('IsAutoClose')) { $newRow["IsAutoClose"] = $db["AutoClose"] }
                if ($targetTable.Columns.Contains('AutoShrink')) { $newRow["AutoShrink"] = $db["AutoShrink"] }
                if ($targetTable.Columns.Contains('IsAutoShrink')) { $newRow["IsAutoShrink"] = $db["AutoShrink"] }
                if ($targetTable.Columns.Contains('IsAutoCreateStatistics')) { $newRow["IsAutoCreateStatistics"] = $db["IsAutoCreateStatistics"] }
                if ($targetTable.Columns.Contains('IsAutoUpdateStatistics')) { $newRow["IsAutoUpdateStatistics"] = $db["IsAutoUpdateStatistics"] }
                $newRow["CompatibilityLevel"] = $db["CompatibilityLevel"]
                $newRow["IsEncrypted"] = $db["IsEncrypted"]
                $newRow["IsReadOnly"] = $db["IsReadOnly"]
                if ($targetTable.Columns.Contains('Collation')) { $newRow["Collation"] = $db["Collation"] }
                if ($targetTable.Columns.Contains('MDFSizeMB')) { $newRow["MDFSizeMB"] = $db["MDFSizeMB"] }
                if ($targetTable.Columns.Contains('MDFUsedMB')) {
                    $newRow["MDFUsedMB"] = if ($db["MDFUsedMB"] -is [System.DBNull]) { [DBNull]::Value } else { $db["MDFUsedMB"] }
                }
                if ($targetTable.Columns.Contains('LDFSizeMB')) { $newRow["LDFSizeMB"] = $db["LDFSizeMB"] }
                if ($targetTable.Columns.Contains('LDFUsedMB')) {
                    $newRow["LDFUsedMB"] = if ($db["LDFUsedMB"] -is [System.DBNull]) { [DBNull]::Value } else { $db["LDFUsedMB"] }
                }
                if ($targetTable.Columns.Contains('SizeMB')) { $newRow["SizeMB"] = $db["SizeMB"] }
                if ($targetTable.Columns.Contains('AvailableSpaceMB')) { $newRow["AvailableSpaceMB"] = if ($db["AvailableSpaceMB"] -is [System.DBNull]) { 0 } else { $db["AvailableSpaceMB"] } }
                if ($targetTable.Columns.Contains('LogSizeMB')) { $newRow["LogSizeMB"] = $db["LogSizeMB"] }
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.DBOptionsHistory" `
                -DataTable $targetTable

            Write-MonitorLog "DB Options collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-DBOptionsCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-DBOptionsCollector
