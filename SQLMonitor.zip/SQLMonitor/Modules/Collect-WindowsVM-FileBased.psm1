# Import the original Windows VM module to get all helper functions
# Note: Collect-WindowsVM.psm1 must be imported in the caller's session
# The Run-WindowsVMCollectors.ps1 script handles this import

function Invoke-WindowsVMCollector-FileBased {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RepositoryServer,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryDatabase,

        [string[]]$ComputerName = @(),

        [int]$InventoryRefreshHours = 12,

        [int]$MaxStoppedServices = 50,

        [int]$TopNProcesses = 25,

        [int]$EventHours = 12,

        [int]$PerfSampleSeconds = 3,

        [int]$PerfSamples = 3,

        [string]$OutDir = '',

        [bool]$EvaluateAlerts = $true,

        [bool]$AutoCreateTickets = $true
    )

    $targets = @()
    if ($ComputerName.Count -gt 0) {
        foreach ($name in $ComputerName) {
            if ([string]::IsNullOrWhiteSpace($name)) { continue }
            $targetId = Get-OrCreateWindowsTargetId -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -ComputerName $name.Trim()
            $targets += [pscustomobject]@{ TargetID = $targetId; ComputerName = $name.Trim(); DisplayName = $name.Trim() }
        }
    }
    else {
        $rows = Get-WindowsTargetRows -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase
        foreach ($row in $rows.Rows) {
            $targets += [pscustomobject]@{
                TargetID = [int]$row.TargetID
                ComputerName = [string]$row.ComputerName
                DisplayName = [string]$row.DisplayName
                CollectionMode = [string]$row.CollectionMode
                CollectionIntervalMinutes = [int]$row.CollectionIntervalMinutes
                LastSampleAt = $row.LastSampleAt
                LastInventoryAt = $row.LastInventoryAt
            }
        }
    }

    if ($targets.Count -eq 0) {
        $local = $env:COMPUTERNAME
        $targetId = Get-OrCreateWindowsTargetId -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -ComputerName $local
        $targets += [pscustomobject]@{ TargetID = $targetId; ComputerName = $local; DisplayName = $local }
    }

    $extendedSchemaReady = Test-WindowsExtendedSchemaReady -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase

    foreach ($target in $targets) {
        if ($ComputerName.Count -eq 0 -and -not (Test-WindowsCollectionDue -Target $target)) {
            Write-MonitorLog "Windows VM collector skipped for $($target.ComputerName); collection interval has not elapsed."
            continue
        }

        $runId = Start-CollectionRun -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -InstanceID 0 -ModuleName "WindowsVM"
        try {
            Write-MonitorLog "Windows VM collector (file-based) started for $($target.ComputerName)"
            $computer = [string]$target.ComputerName
            $isLocal = ($computer -eq $env:COMPUTERNAME -or $computer -eq "localhost" -or $computer -eq ".")

            # Use the file-based collection approach with Get-ComputerInfo, Get-Volume, Get-Counter
            $captureTime = Get-Date

            # Get basic system information using Get-ComputerInfo (local only)
            $computerInfo = Get-ComputerInfo -ErrorAction Stop

            # Get CPU information - use local CIM without -ComputerName to avoid remote WMI issues
            try {
                $cpuParams = @{ ClassName = 'Win32_Processor'; ErrorAction = 'Stop' }
                if (-not $isLocal) { $cpuParams.ComputerName = $computer }
                $cpuInfo = Get-CimInstance @cpuParams
            } catch {
                Write-MonitorLog "Get-CimInstance Win32_Processor failed for $computer`: $($_.Exception.Message)" -Level Warning
                $cpuInfo = @()
            }

            # Get CPU percent via counter (works locally without special permissions)
            try {
                $cpuPercent = (Get-Counter -Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 2 -ErrorAction Stop).CounterSamples[-1].CookedValue
            } catch {
                $cpuPercent = $null
            }

            # Get memory information
            try {
                $memParams = @{ ClassName = 'Win32_OperatingSystem'; ErrorAction = 'Stop' }
                if (-not $isLocal) { $memParams.ComputerName = $computer }
                $memoryInfo = Get-CimInstance @memParams
            } catch {
                Write-MonitorLog "Get-CimInstance Win32_OperatingSystem failed for $computer`: $($_.Exception.Message)" -Level Warning
                $memoryInfo = $null
            }

            $totalMemoryGb = if ($computerInfo.TotalPhysicalMemory) { [math]::Round($computerInfo.TotalPhysicalMemory / 1GB, 2) } else { 0 }
            $freeMemoryGb = if ($memoryInfo) { [math]::Round($memoryInfo.FreePhysicalMemory / 1MB, 2) } else { 0 }
            $usedMemoryGb = [math]::Round(($totalMemoryGb - $freeMemoryGb), 2)
            $memoryUsedPercent = if ($totalMemoryGb -gt 0) { [math]::Round(($usedMemoryGb / $totalMemoryGb) * 100, 2) } else { $null }

            # Get disk information using Get-Volume (local only)
            $disks = @()
            $totalDiskFreeGb = 0
            $totalDiskSizeGb = 0
            try {
                $diskInfo = Get-Volume -ErrorAction Stop | Where-Object { $_.DriveType -eq 'Fixed' -and $_.Size -gt 0 }
                foreach ($disk in $diskInfo) {
                    $sizeGb = [math]::Round($disk.Size / 1GB, 2)
                    $freeGb = [math]::Round($disk.SizeRemaining / 1GB, 2)
                    $usedPct = if ($sizeGb -gt 0) { [math]::Round((($sizeGb - $freeGb) / $sizeGb) * 100, 2) } else { $null }

                    $disks += [pscustomobject]@{
                        DeviceID = "$($disk.DriveLetter):"
                        VolumeName = $disk.FileSystemLabel
                        SizeGB = $sizeGb
                        FreeGB = $freeGb
                        UsedPct = $usedPct
                    }

                    $totalDiskFreeGb += $freeGb
                    $totalDiskSizeGb += $sizeGb
                }
            } catch {
                Write-MonitorLog "Get-Volume failed for $computer`: $($_.Exception.Message)" -Level Warning
            }

            $diskUsedPercent = if ($totalDiskSizeGb -gt 0) { [math]::Round((($totalDiskSizeGb - $totalDiskFreeGb) / $totalDiskSizeGb) * 100, 2) } else { $null }

            # Get network information (enhanced: per-adapter stats, TCP connections, firewall)
            $networkBytesPerSec = 0
            $networkInfo = @()
            $networkAdapterStats = @()
            $tcpConnections = @()
            $firewallProfiles = @()
            try {
                $networkInfo = Get-NetAdapter -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' }
                foreach ($adapter in $networkInfo) {
                    $bytesReceived = $null; $bytesSent = $null; $bytesTotal = 0
                    try {
                        $counter = Get-Counter -Counter "\Network Adapter($($adapter.Name))\Bytes Total/sec" -SampleInterval 1 -MaxSamples 2 -ErrorAction Stop
                        $bytesTotal = [int64]$counter.CounterSamples[-1].CookedValue
                        $networkBytesPerSec += $bytesTotal
                    } catch { }
                    try {
                        $rxCounter = Get-Counter -Counter "\Network Adapter($($adapter.Name))\Bytes Received/sec" -SampleInterval 1 -MaxSamples 1 -ErrorAction Stop
                        $bytesReceived = [int64]$rxCounter.CounterSamples[-1].CookedValue
                    } catch { }
                    try {
                        $txCounter = Get-Counter -Counter "\Network Adapter($($adapter.Name))\Bytes Sent/sec" -SampleInterval 1 -MaxSamples 1 -ErrorAction Stop
                        $bytesSent = [int64]$txCounter.CounterSamples[-1].CookedValue
                    } catch { }
                    $linkSpeedBps = [int64]0
                    try { $linkSpeedBps = [int64]$adapter.LinkSpeed } catch { }
                    $networkAdapterStats += [pscustomobject]@{
                        AdapterName = $adapter.Name
                        InterfaceDescription = $adapter.InterfaceDescription
                        BytesReceivedPerSec = $bytesReceived
                        BytesSentPerSec = $bytesSent
                        BytesTotalPerSec = $bytesTotal
                        CurrentBandwidth = $linkSpeedBps
                        LinkSpeed = $linkSpeedBps
                    }
                }
            } catch {
                Write-MonitorLog "Get-NetAdapter failed for $computer`: $($_.Exception.Message)" -Level Warning
            }
            # TCP connection tracking
            if ($extendedSchemaReady) {
                try {
                    $tcpConnections = Get-NetTCPConnection -State Listen,Established -ErrorAction Stop |
                        Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcess
                } catch {
                    Write-MonitorLog "Get-NetTCPConnection failed for $computer`: $($_.Exception.Message)" -Level Warning
                }
                # Firewall status via netsh (avoids COM interop issues)
                try {
                    $netshOutput = netsh advfirewall show allprofiles 2>&1
                    $currentProfile = $null
                    foreach ($line in $netshOutput) {
                        if ($line -match '^(Domain|Private|Public) Profile Settings:') {
                            $currentProfile = $Matches[1]
                        }
                        if ($currentProfile -and ($line -match 'State\s+(ON|OFF)')) {
                            $firewallProfiles += [pscustomobject]@{
                                ProfileName = $currentProfile
                                Enabled = ($Matches[1] -eq 'ON')
                                DefaultInboundAction = $null
                                DefaultOutboundAction = $null
                                LogAllowed = $null
                                LogBlocked = $null
                            }
                            $currentProfile = $null
                        }
                    }
                } catch {
                    Write-MonitorLog "Firewall status query failed for $computer`: $($_.Exception.Message)" -Level Warning
                }
            }

            # Get process information
            try {
                $processes = Get-Process -ErrorAction Stop
                $topCpu = $processes | Sort-Object -Property CPU -Descending | Select-Object -First $TopNProcesses Name, Id, CPU, WorkingSet
                $topMem = $processes | Sort-Object -Property WorkingSet -Descending | Select-Object -First $TopNProcesses Name, Id, CPU, WorkingSet
            } catch {
                Write-MonitorLog "Get-Process failed for $computer`: $($_.Exception.Message)" -Level Warning
                $processes = @()
                $topCpu = @()
                $topMem = @()
            }

            # Get service information
            try {
                $services = Get-Service -ErrorAction Stop
                $stoppedAutomatic = $services | Where-Object { $_.StartType -eq 'Automatic' -and $_.Status -ne 'Running' } | Select-Object -First $MaxStoppedServices
            } catch {
                Write-MonitorLog "Get-Service failed for $computer`: $($_.Exception.Message)" -Level Warning
                $services = @()
                $stoppedAutomatic = @()
            }

            # Get event log information
            $events = @()
            foreach ($log in @('System', 'Application')) {
                try {
                    $logEvents = Get-WinEvent -LogName $log -MaxEvents 100 -ErrorAction Stop |
                        Where-Object { $_.LevelDisplayName -in @('Critical', 'Error', 'Warning') } |
                        Select-Object -First 50 TimeCreated, LogName, Id, LevelDisplayName, ProviderName,
                            @{ Name = 'Message'; Expression = { $_.Message.Substring(0, [math]::Min(500, $_.Message.Length)) } }
                    $events += $logEvents
                } catch {
                    # Skip if we can't read the event log
                }
            }

            # Get performance counters
            $counterPaths = @(
                '\Processor(_Total)\% Processor Time',
                '\Memory\Available MBytes',
                '\LogicalDisk(_Total)\% Free Space',
                '\LogicalDisk(_Total)\Avg. Disk sec/Read',
                '\LogicalDisk(_Total)\Avg. Disk sec/Write',
                '\Network Interface(*)\Bytes Total/sec'
            )
            try {
                $perfCounters = Get-Counter -Counter $counterPaths -SampleInterval $PerfSampleSeconds -MaxSamples $PerfSamples -ErrorAction Stop
                $perfCounterSamples = $perfCounters.CounterSamples
            } catch {
                Write-MonitorLog "Get-Counter failed for $computer`: $($_.Exception.Message)" -Level Warning
                $perfCounterSamples = @()
            }

            # Get hotfix information
            try {
                $hotfixes = Get-HotFix -ErrorAction Stop | Sort-Object -Property InstalledOn -Descending | Select-Object -First 20 HotFixID, InstalledOn, Description
            } catch {
                Write-MonitorLog "Get-HotFix failed for $computer`: $($_.Exception.Message)" -Level Warning
                $hotfixes = @()
            }

            # Build snapshot object compatible with existing code
            $snapshot = [pscustomobject]@{
                CollectedAt = $captureTime
                ComputerName = $computer
                OS = [pscustomobject]@{
                    Caption = $computerInfo.OSName
                    Version = $computerInfo.OSVersion
                    BuildNumber = $computerInfo.WindowsCurrentVersion
                    InstallDate = $computerInfo.WindowsInstallDate
                    LastBootUpTime = $computerInfo.LastBootUpTime
                    SerialNumber = $computerInfo.BiosSerialNumber
                }
                Hardware = [pscustomobject]@{
                    Manufacturer = $computerInfo.Manufacturer
                    Model = $computerInfo.Model
                    DomainName = $computerInfo.Domain
                    BIOS = [pscustomobject]@{
                        SerialNumber = $computerInfo.BiosSerialNumber
                        Version = $computerInfo.BiosVersion
                    }
                    CPU = @($cpuInfo)
                    Memory = [pscustomobject]@{
                        TotalGB = $totalMemoryGb
                        FreeGB = $freeMemoryGb
                        UsedGB = $usedMemoryGb
                        UsedPct = $memoryUsedPercent
                        CommitLimitGB = if ($memoryInfo) { [math]::Round($memoryInfo.TotalVirtualMemorySize / 1MB / 1GB, 2) } else { $null }
                        CommitUsedGB = if ($memoryInfo) { [math]::Round(($memoryInfo.TotalVirtualMemorySize - $memoryInfo.FreeVirtualMemory) / 1MB / 1GB, 2) } else { $null }
                    }
                }
                VMHints = [pscustomobject]@{
                    IsVirtualMachine = ($computerInfo.Model -match 'Virtual|VMware|KVM|HVM|Xen|Hyper-V' -or $computerInfo.Manufacturer -match 'Microsoft|VMware|Xen|QEMU|Amazon|Google')
                    Model = $computerInfo.Model
                    Manufacturer = $computerInfo.Manufacturer
                    HypervisorPresent = $computerInfo.HypervisorPresent
                }
                Patching = [pscustomobject]@{ HotFixTop20 = $hotfixes }
                Storage = [pscustomobject]@{ LogicalDisks = $disks }
                Network = [pscustomobject]@{
                    Adapters = $networkInfo | Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress
                    IPConfiguration = @()
                    TopRemoteEstablishedTCP = @()
                    BytesTotalPerSec = [int64]$networkBytesPerSec
                }
                Services = [pscustomobject]@{
                    Summary = @($services | Group-Object Status | Select-Object Name, Count)
                    StoppedAutomatic = $stoppedAutomatic
                }
                Processes = [pscustomobject]@{
                    TopByCPU = $topCpu
                    TopByMemory = $topMem
                }
                PerfCounters = $perfCounterSamples
                Events = $events
                Summary = [pscustomobject]@{
                    CPUPercent = $cpuPercent
                    MemoryUsedPercent = $memoryUsedPercent
                    MemoryAvailableGB = $freeMemoryGb
                    DiskUsedPercent = $diskUsedPercent
                    DiskFreeGB = $totalDiskFreeGb
                    ProcessCount = $processes.Count
                    ServiceStoppedCount = $stoppedAutomatic.Count
                    NetworkBytesPerSec = [int64]$networkBytesPerSec
                }
            }

            # Export files if output directory is specified
            Export-WindowsSnapshotFiles -Snapshot $snapshot -OutDir $OutDir

            $os = $snapshot.OS
            $hardware = $snapshot.Hardware
            $summary = $snapshot.Summary
            $diskData = @($snapshot.Storage.LogicalDisks)
            $servicesData = @($snapshot.Services.StoppedAutomatic)

            $cpuPercent = $summary.CPUPercent
            $totalMemoryGb = $hardware.Memory.TotalGB
            $freeMemoryGb = $summary.MemoryAvailableGB
            $memoryUsedPercent = $summary.MemoryUsedPercent
            $diskFreeGb = $summary.DiskFreeGB
            $diskUsedPercent = $summary.DiskUsedPercent
            $serviceStoppedCount = $summary.ServiceStoppedCount
            $processCount = $summary.ProcessCount
            $networkBytesPerSec = $summary.NetworkBytesPerSec

            $score = 100
            if ($cpuPercent -ge 90) { $score -= 25 } elseif ($cpuPercent -ge 75) { $score -= 12 }
            if ($memoryUsedPercent -ge 90) { $score -= 25 } elseif ($memoryUsedPercent -ge 80) { $score -= 12 }
            if ($diskUsedPercent -ge 95) { $score -= 25 } elseif ($diskUsedPercent -ge 85) { $score -= 12 }
            if ($serviceStoppedCount -gt 0) { $score -= [Math]::Min(20, $serviceStoppedCount * 4) }
            $score = [Math]::Max(0, [Math]::Min(100, [int]$score))
            $posture = if ($score -ge 85) { 'Healthy' } elseif ($score -ge 60) { 'Warning' } else { 'Critical' }

            if ($inventoryDue) {
                $inventorySql = @"
MERGE mon.WindowsInventory AS target
USING (SELECT @TargetID AS TargetID) AS source
    ON target.TargetID = source.TargetID
WHEN MATCHED THEN UPDATE SET
    ComputerName = @ComputerName,
    DomainName = @DomainName,
    OSName = @OSName,
    OSVersion = @OSVersion,
    OSBuild = @OSBuild,
    Manufacturer = @Manufacturer,
    Model = @Model,
    ProcessorName = @ProcessorName,
    LogicalProcessorCount = @LogicalProcessorCount,
    TotalMemoryGB = @TotalMemoryGB,
    LastBootTime = @LastBootTime,
    LastInventoryAt = @CaptureTime
WHEN NOT MATCHED THEN
    INSERT (TargetID, ComputerName, DomainName, OSName, OSVersion, OSBuild, Manufacturer, Model, ProcessorName, LogicalProcessorCount, TotalMemoryGB, LastBootTime, LastInventoryAt)
    VALUES (@TargetID, @ComputerName, @DomainName, @OSName, @OSVersion, @OSBuild, @Manufacturer, @Model, @ProcessorName, @LogicalProcessorCount, @TotalMemoryGB, @LastBootTime, @CaptureTime);
"@
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $inventorySql -Parameters @{
                    TargetID = [int]$target.TargetID
                    ComputerName = $computer
                    DomainName = ConvertTo-DbValue $hardware.DomainName
                    OSName = ConvertTo-DbValue $os.Caption
                    OSVersion = ConvertTo-DbValue $os.Version
                    OSBuild = ConvertTo-DbValue $os.BuildNumber
                    Manufacturer = ConvertTo-DbValue $hardware.Manufacturer
                    Model = ConvertTo-DbValue $hardware.Model
                    ProcessorName = ConvertTo-DbValue (@($hardware.CPU) | Select-Object -First 1).Name
                    LogicalProcessorCount = ConvertTo-DbValue ((@($hardware.CPU) | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum)
                    TotalMemoryGB = ConvertTo-DbValue $totalMemoryGb
                    LastBootTime = ConvertTo-DbValue $os.LastBootUpTime
                    CaptureTime = $captureTime
                }
            }

            $sampleSql = @"
EXEC mon.usp_InsertWindowsPerformanceSample
    @TargetID = @TargetID,
    @CaptureTime = @CaptureTime,
    @CPUPercent = @CPUPercent,
    @MemoryUsedPercent = @MemoryUsedPercent,
    @MemoryAvailableGB = @MemoryAvailableGB,
    @DiskUsedPercent = @DiskUsedPercent,
    @DiskFreeGB = @DiskFreeGB,
    @NetworkBytesPerSec = @NetworkBytesPerSec,
    @ProcessCount = @ProcessCount,
    @ServiceStoppedCount = @ServiceStoppedCount,
    @HealthScore = @HealthScore,
    @HealthPosture = @HealthPosture;
"@
            Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $sampleSql -Parameters @{
                TargetID = [int]$target.TargetID
                CaptureTime = $captureTime
                CPUPercent = ConvertTo-DbValue $cpuPercent
                MemoryUsedPercent = ConvertTo-DbValue $memoryUsedPercent
                MemoryAvailableGB = ConvertTo-DbValue $freeMemoryGb
                DiskUsedPercent = ConvertTo-DbValue $diskUsedPercent
                DiskFreeGB = ConvertTo-DbValue $diskFreeGb
                NetworkBytesPerSec = ConvertTo-DbValue $networkBytesPerSec
                ProcessCount = ConvertTo-DbValue $processCount
                ServiceStoppedCount = $serviceStoppedCount
                HealthScore = $score
                HealthPosture = $posture
            }

            foreach ($disk in $diskData) {
                $totalGb = $disk.SizeGB
                $freeGb = $disk.FreeGB
                $usedPct = $disk.UsedPct
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsDiskSamples (TargetID, CaptureTime, DriveLetter, VolumeName, TotalGB, FreeGB, UsedPercent)
VALUES (@TargetID, @CaptureTime, @DriveLetter, @VolumeName, @TotalGB, @FreeGB, @UsedPercent);
"@ -Parameters @{
                    TargetID = [int]$target.TargetID
                    CaptureTime = $captureTime
                    DriveLetter = [string]$disk.DeviceID
                    VolumeName = ConvertTo-DbValue $disk.VolumeName
                    TotalGB = ConvertTo-DbValue $totalGb
                    FreeGB = ConvertTo-DbValue $freeGb
                    UsedPercent = ConvertTo-DbValue $usedPct
                }
            }

            foreach ($service in $servicesData) {
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsServiceSamples (TargetID, CaptureTime, ServiceName, DisplayName, StartMode, StateName, IsCritical)
VALUES (@TargetID, @CaptureTime, @ServiceName, @DisplayName, @StartMode, @StateName, @IsCritical);
"@ -Parameters @{
                    TargetID = [int]$target.TargetID
                    CaptureTime = $captureTime
                    ServiceName = [string]$service.Name
                    DisplayName = ConvertTo-DbValue $service.DisplayName
                    StartMode = ConvertTo-DbValue $service.StartType
                    StateName = ConvertTo-DbValue $service.Status
                    IsCritical = [bool]($service.Name -match 'MSSQL|SQLSERVERAGENT|WinRM|EventLog|LanmanServer')
                }
            }

            # Insert per-adapter network bandwidth stats
            if ($extendedSchemaReady) {
                foreach ($netStat in $networkAdapterStats) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsNetworkAdapterStats (TargetID, CaptureTime, AdapterName, InterfaceDescription, BytesReceivedPerSec, BytesSentPerSec, BytesTotalPerSec, CurrentBandwidth, LinkSpeed)
VALUES (@TargetID, @CaptureTime, @AdapterName, @InterfaceDescription, @BytesReceivedPerSec, @BytesSentPerSec, @BytesTotalPerSec, @CurrentBandwidth, @LinkSpeed);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        AdapterName = [string]$netStat.AdapterName
                        InterfaceDescription = ConvertTo-DbValue $netStat.InterfaceDescription
                        BytesReceivedPerSec = ConvertTo-DbValue $netStat.BytesReceivedPerSec
                        BytesSentPerSec = ConvertTo-DbValue $netStat.BytesSentPerSec
                        BytesTotalPerSec = ConvertTo-DbValue $netStat.BytesTotalPerSec
                        CurrentBandwidth = ConvertTo-DbValue $netStat.CurrentBandwidth
                        LinkSpeed = ConvertTo-DbValue $netStat.LinkSpeed
                    }
                }
            }

            # Insert TCP connection samples (top 100 per collection)
            if ($extendedSchemaReady) {
                $topConnections = $tcpConnections | Select-Object -First 100
                foreach ($conn in $topConnections) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsNetworkConnectionSamples (TargetID, CaptureTime, LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcessID)
VALUES (@TargetID, @CaptureTime, @LocalAddress, @LocalPort, @RemoteAddress, @RemotePort, @State, @OwningProcessID);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        LocalAddress = [string]$conn.LocalAddress
                        LocalPort = [int]$conn.LocalPort
                        RemoteAddress = [string]$conn.RemoteAddress
                        RemotePort = [int]$conn.RemotePort
                        State = [string]$conn.State
                        OwningProcessID = ConvertTo-DbValue $conn.OwningProcess
                    }
                }
            }

            # Insert firewall status
            if ($extendedSchemaReady) {
                foreach ($fw in $firewallProfiles) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsFirewallStatus (TargetID, CaptureTime, ProfileName, Enabled, DefaultInboundAction, DefaultOutboundAction, LogAllowed, LogBlocked)
VALUES (@TargetID, @CaptureTime, @ProfileName, @Enabled, @DefaultInboundAction, @DefaultOutboundAction, @LogAllowed, @LogBlocked);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        ProfileName = [string]$fw.ProfileName
                        Enabled = [bool]$fw.Enabled
                        DefaultInboundAction = [string]$fw.DefaultInboundAction
                        DefaultOutboundAction = [string]$fw.DefaultOutboundAction
                        LogAllowed = [bool]$fw.LogAllowed
                        LogBlocked = [bool]$fw.LogBlocked
                    }
                }
            }

            if ($extendedSchemaReady) {
                foreach ($hotfix in @($snapshot.Patching.HotFixTop20)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsHotFixSamples (TargetID, CaptureTime, HotFixID, InstalledOn, Description)
VALUES (@TargetID, @CaptureTime, @HotFixID, @InstalledOn, @Description);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        HotFixID = ConvertTo-DbValue $hotfix.HotFixID
                        InstalledOn = ConvertTo-DbValue $hotfix.InstalledOn
                        Description = ConvertTo-DbValue $hotfix.Description
                    }
                }

                foreach ($adapter in @($snapshot.Network.Adapters)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsNetworkAdapterSamples (TargetID, CaptureTime, AdapterName, InterfaceDescription, StatusName, LinkSpeed, MacAddress)
VALUES (@TargetID, @CaptureTime, @AdapterName, @InterfaceDescription, @StatusName, @LinkSpeed, @MacAddress);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        AdapterName = ConvertTo-DbValue $adapter.Name
                        InterfaceDescription = ConvertTo-DbValue $adapter.InterfaceDescription
                        StatusName = ConvertTo-DbValue $adapter.Status
                        LinkSpeed = ConvertTo-DbValue ([string]$adapter.LinkSpeed)
                        MacAddress = ConvertTo-DbValue $adapter.MacAddress
                    }
                }

                foreach ($ranked in @(
                    @{ Type = 'CPU'; Rows = @($snapshot.Processes.TopByCPU) },
                    @{ Type = 'Memory'; Rows = @($snapshot.Processes.TopByMemory) }
                )) {
                    foreach ($process in @($ranked.Rows)) {
                        Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsProcessSamples (TargetID, CaptureTime, RankingType, ProcessName, ProcessID, CPUPercent, WorkingSetMB, VirtualMemoryMB)
VALUES (@TargetID, @CaptureTime, @RankingType, @ProcessName, @ProcessID, @CPUPercent, @WorkingSetMB, @VirtualMemoryMB);
"@ -Parameters @{
                            TargetID = [int]$target.TargetID
                            CaptureTime = $captureTime
                            RankingType = [string]$ranked.Type
                            ProcessName = ConvertTo-DbValue $process.Name
                            ProcessID = ConvertTo-DbValue $process.Id
                            CPUPercent = ConvertTo-DbValue $process.CPU
                            WorkingSetMB = if ($process.WorkingSet) { [math]::Round(([double]$process.WorkingSet / 1MB), 2) } else { [DBNull]::Value }
                            VirtualMemoryMB = [DBNull]::Value
                        }
                    }
                }

                foreach ($event in @($snapshot.Events | Select-Object -First 200)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsEventSamples (TargetID, CaptureTime, EventTime, LogName, EventID, LevelName, ProviderName, Message)
VALUES (@TargetID, @CaptureTime, @EventTime, @LogName, @EventID, @LevelName, @ProviderName, @Message);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        EventTime = ConvertTo-DbValue $event.TimeCreated
                        LogName = ConvertTo-DbValue $event.LogName
                        EventID = ConvertTo-DbValue $event.Id
                        LevelName = ConvertTo-DbValue $event.LevelDisplayName
                        ProviderName = ConvertTo-DbValue $event.ProviderName
                        Message = ConvertTo-DbValue (ConvertTo-WindowsShortMessage -Message $event.Message)
                    }
                }

                foreach ($counter in @($snapshot.PerfCounters | Select-Object -First 300)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsPerfCounterSamples (TargetID, CaptureTime, CounterPath, CookedValue, CounterTime)
VALUES (@TargetID, @CaptureTime, @CounterPath, @CookedValue, @CounterTime);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        CounterPath = [string]$counter.Path
                        CookedValue = ConvertTo-DbValue $counter.CookedValue
                        CounterTime = ConvertTo-DbValue $counter.TimeStamp
                    }
                }
            }

            if ($EvaluateAlerts) {
                try {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
DECLARE @TicketsCreated INT;
EXEC mon.usp_EvaluateWindowsVMAlerts
    @TargetID = @TargetID,
    @AutoCreateTickets = @AutoCreateTickets,
    @CreatedBy = N'vm-alert-engine',
    @TicketsCreated = @TicketsCreated OUTPUT;
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        AutoCreateTickets = if ($AutoCreateTickets) { 1 } else { 0 }
                    }
                }
                catch {
                    Write-MonitorLog "Windows VM alert evaluation failed for ${computer}: $($_.Exception.Message)" -Level Warning
                }
            }

            Stop-CollectionRun -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -RunID $runId -Status "Success"
            Write-MonitorLog "Windows VM collector (file-based) completed for $computer. HealthScore=$score Posture=$posture"
        }
        catch {
            $message = $_.Exception.Message
            Write-MonitorLog "Windows VM collector (file-based) failed for $($target.ComputerName): $message"
            Stop-CollectionRun -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -RunID $runId -Status "Failed" -ErrorMessage $message
        }
    }
}

Export-ModuleMember -Function Invoke-WindowsVMCollector-FileBased