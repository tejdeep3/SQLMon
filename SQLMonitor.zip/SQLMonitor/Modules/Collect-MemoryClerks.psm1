# Collect-MemoryClerks.psm1
# Advanced SQL Server memory clerk analysis and pressure monitoring
# UNIQUE FEATURE: Detailed memory allocation analysis by SQL Server components with pressure prediction

function Get-SQLServerMemoryClerks {
    <#
    .SYNOPSIS
        Analyzes SQL Server memory allocation by internal components.
    .DESCRIPTION
        Monitors memory clerks to identify which SQL Server components are consuming memory
        and predicts potential memory pressure scenarios.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Instance,

        [Parameter(Mandatory = $false)]
        [switch]$IncludePressureAnalysis
    )

    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $query = @"
SELECT
    mc.type,
    mc.name,
    mc.memory_node_id,
    mc.pages_kb,
    mc.virtual_memory_reserved_kb,
    mc.virtual_memory_committed_kb,
    mc.awe_allocated_kb,
    mc.shared_memory_reserved_kb,
    mc.shared_memory_committed_kb,
    mc.single_pages_kb,
    mc.multi_pages_kb,
    mc.cached_pages_kb,
    os.total_physical_memory_kb,
    os.available_physical_memory_kb,
    os.system_memory_state_desc
FROM sys.dm_os_memory_clerks mc
CROSS JOIN sys.dm_os_sys_memory os
ORDER BY mc.pages_kb DESC
"@

    try {
        $results = Invoke-Sqlcmd -ServerInstance $Instance.SqlInstance -Database 'master' -Query $query -ErrorAction Stop

        $memoryAnalysis = @()
        foreach ($row in $results) {
            $analysis = [PSCustomObject]@{
                Type = $row.type
                Name = $row.name
                MemoryNodeId = $row.memory_node_id
                PagesKB = $row.pages_kb
                VirtualMemoryReservedKB = $row.virtual_memory_reserved_kb
                VirtualMemoryCommittedKB = $row.virtual_memory_committed_kb
                AweAllocatedKB = $row.awe_allocated_kb
                SharedMemoryReservedKB = $row.shared_memory_reserved_kb
                SharedMemoryCommittedKB = $row.shared_memory_committed_kb
                SinglePagesKB = $row.single_pages_kb
                MultiPagesKB = $row.multi_pages_kb
                CachedPagesKB = $row.cached_pages_kb
                TotalPhysicalMemoryKB = $row.total_physical_memory_kb
                AvailablePhysicalMemoryKB = $row.available_physical_memory_kb
                SystemMemoryState = $row.system_memory_state_desc
                PressureLevel = 'Normal'
                Recommendations = @()
            }

            if ($IncludePressureAnalysis) {
                $pressureAnalysis = Get-MemoryClerkPressureAnalysis -Clerk $analysis
                $analysis.PressureLevel = $pressureAnalysis.Level
                $analysis.Recommendations = $pressureAnalysis.Recommendations
            }

            $recommendations = if ($analysis.Recommendations.Count -gt 0) { ($analysis.Recommendations -join '; ').Replace("'", "''") } else { $null }
            $type = [string]$row.type -replace "'", "''"
            $name = [string]$row.name -replace "'", "''"
            $systemMemoryState = [string]$row.system_memory_state_desc -replace "'", "''"

            # Save to repository
            $query = @"
INSERT INTO [mon].[MemoryClerksHistory] (
    [InstanceID], [CaptureTime], [Type], [Name], [MemoryNodeId], [PagesKB],
    [VirtualMemoryReservedKB], [VirtualMemoryCommittedKB], [AweAllocatedKB],
    [SharedMemoryReservedKB], [SharedMemoryCommittedKB], [SinglePagesKB],
    [MultiPagesKB], [CachedPagesKB], [TotalPhysicalMemoryKB], [AvailablePhysicalMemoryKB],
    [SystemMemoryState], [PressureLevel], [Recommendations]
) VALUES (
    $instanceId,
    GETUTCDATE(), '$type', '$name', $($row.memory_node_id), $($row.pages_kb),
    $($row.virtual_memory_reserved_kb), $($row.virtual_memory_committed_kb), $($row.awe_allocated_kb),
    $($row.shared_memory_reserved_kb), $($row.shared_memory_committed_kb), $($row.single_pages_kb),
    $($row.multi_pages_kb), $($row.cached_pages_kb), $($row.total_physical_memory_kb), $($row.available_physical_memory_kb),
    '$systemMemoryState', '$($analysis.PressureLevel)',
    $(if ($recommendations) { "'$recommendations'" } else { 'NULL' })
)
"@

            try {
                Invoke-Sqlcmd -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -Query $query -ErrorAction Stop
            }
            catch {
                Write-MonitorLog "WARNING failed to save memory clerk data: $($_.Exception.Message)" -Level 'Warning'
            }

            $memoryAnalysis += $analysis
        }

        return $memoryAnalysis
    }
    catch {
        Write-MonitorLog "ERROR collecting memory clerks: $($_.Exception.Message)" -Level 'Error'
        return @()
    }
}

function Get-MemoryClerkPressureAnalysis {
    <#
    .SYNOPSIS
        Analyzes memory clerk data for pressure indicators and recommendations.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Clerk
    )

    $level = 'Normal'
    $recommendations = @()

    # Calculate memory usage ratios
    $totalMemoryUsed = $Clerk.PagesKB + $Clerk.VirtualMemoryCommittedKB + $Clerk.AweAllocatedKB
    $memoryPressureRatio = $totalMemoryUsed / $Clerk.TotalPhysicalMemoryKB

    # Check for high memory usage by clerk type
    switch ($Clerk.Type) {
        'MEMORYCLERK_SQLBUFFERPOOL' {
            if ($memoryPressureRatio -gt 0.8) {
                $level = 'High'
                $recommendations += "Buffer pool memory usage is high ($([math]::Round($memoryPressureRatio * 100, 1))% of total memory). Consider increasing server memory or optimizing queries."
            } elseif ($memoryPressureRatio -gt 0.6) {
                $level = 'Medium'
                $recommendations += "Buffer pool memory usage is elevated. Monitor for memory pressure symptoms."
            }
        }
        'MEMORYCLERK_SQLCLR' {
            if ($Clerk.PagesKB -gt 100000) { # 100MB
                $level = 'Medium'
                $recommendations += "CLR memory usage is high. Review CLR objects and assemblies for memory leaks."
            }
        }
        'MEMORYCLERK_SQLQUERYPLAN' {
            if ($Clerk.PagesKB -gt 50000) { # 50MB
                $level = 'Medium'
                $recommendations += "Query plan cache is large. Consider increasing server memory or clearing plan cache if needed."
            }
        }
        'MEMORYCLERK_SQLQUERYEXEC' {
            if ($Clerk.PagesKB -gt 100000) { # 100MB
                $level = 'High'
                $recommendations += "Query execution memory is high. Check for queries with excessive memory grants."
            }
        }
    }

    # System-wide memory pressure
    if ($Clerk.SystemMemoryState -eq 'Available physical memory is low') {
        $level = 'Critical'
        $recommendations += "System memory is low. Immediate action required to prevent memory-related failures."
    } elseif ($Clerk.AvailablePhysicalMemoryKB -lt ($Clerk.TotalPhysicalMemoryKB * 0.1)) {
        if ($level -ne 'Critical') { $level = 'High' }
        $recommendations += "Available physical memory is critically low. Add more RAM or reduce memory-intensive operations."
    }

    return [PSCustomObject]@{
        Level = $level
        Recommendations = $recommendations
    }
}

function Get-SQLServerBufferPoolAnalysis {
    <#
    .SYNOPSIS
        Analyzes buffer pool page distribution and access patterns.
    .DESCRIPTION
        UNIQUE FEATURE: Detailed analysis of what types of pages are cached in buffer pool
        and their access patterns for optimization recommendations.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Instance
    )

    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $query = @"
SELECT
    CASE
        WHEN database_id = 32767 THEN 'ResourceDB'
        ELSE DB_NAME(database_id)
    END AS database_name,
    COUNT(*) * 8 / 1024 AS size_mb,
    COUNT(*) AS page_count,
    SUM(CASE WHEN is_modified = 1 THEN 1 ELSE 0 END) AS dirty_pages,
    SUM(CASE WHEN last_access_time < DATEADD(minute, -60, GETDATE()) THEN 1 ELSE 0 END) AS old_pages,
    AVG(DATEDIFF(second, last_access_time, GETDATE())) AS avg_seconds_since_access
FROM sys.dm_os_buffer_descriptors
GROUP BY database_id
ORDER BY size_mb DESC
"@

    try {
        $results = Invoke-Sqlcmd -ServerInstance $Instance.SqlInstance -Database 'master' -Query $query -ErrorAction Stop

        $bufferAnalysis = @()
        foreach ($row in $results) {
            $analysis = [PSCustomObject]@{
                DatabaseName = $row.database_name
                SizeMB = [math]::Round($row.size_mb, 2)
                PageCount = $row.page_count
                DirtyPages = $row.dirty_pages
                OldPages = $row.old_pages
                AvgSecondsSinceAccess = [math]::Round($row.avg_seconds_since_access, 0)
                CleanPages = $row.page_count - $row.dirty_pages
                FreshPages = $row.page_count - $row.old_pages
                Recommendations = @()
            }

            # Generate recommendations
            if ($row.dirty_pages -gt ($row.page_count * 0.3)) {
                $analysis.Recommendations += "High dirty page ratio ($([math]::Round(($row.dirty_pages / $row.page_count) * 100, 1))%). Consider adjusting checkpoint frequency."
            }

            if ($row.old_pages -gt ($row.page_count * 0.5)) {
                $analysis.Recommendations += "Many pages haven't been accessed recently. Buffer pool may contain stale data."
            }

            if ($row.avg_seconds_since_access -gt 3600) { # 1 hour
                $analysis.Recommendations += "Average page age is high. Review workload patterns and memory allocation."
            }

            $databaseName = [string]$row.database_name -replace "'", "''"
            $recommendations = if ($analysis.Recommendations.Count -gt 0) { ($analysis.Recommendations -join '; ').Replace("'", "''") } else { $null }

            # Save to repository
            $query = @"
INSERT INTO [mon].[BufferPoolAnalysisHistory] (
    [InstanceID], [CaptureTime], [DatabaseName], [SizeMB], [PageCount], [DirtyPages],
    [OldPages], [AvgSecondsSinceAccess], [CleanPages], [FreshPages], [Recommendations]
) VALUES (
    $instanceId,
    GETUTCDATE(), '$databaseName', $($analysis.SizeMB), $($row.page_count), $($row.dirty_pages),
    $($row.old_pages), $($analysis.AvgSecondsSinceAccess), $($analysis.CleanPages), $($analysis.FreshPages),
    $(if ($recommendations) { "'$recommendations'" } else { 'NULL' })
)
"@

            try {
                Invoke-Sqlcmd -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -Query $query -ErrorAction Stop
            }
            catch {
                Write-MonitorLog "WARNING failed to save buffer pool analysis data: $($_.Exception.Message)" -Level 'Warning'
            }

            $bufferAnalysis += $analysis
        }

        return $bufferAnalysis
    }
    catch {
        Write-MonitorLog "ERROR analyzing buffer pool: $($_.Exception.Message)" -Level 'Error'
        return @()
    }
}

function Invoke-MemoryClerkCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "MemoryClerks"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Memory Clerks collector started for $($Instance.DisplayName)"

        $query = @"
SELECT
    mc.type,
    mc.name,
    mc.memory_node_id,
    mc.pages_kb,
    mc.virtual_memory_reserved_kb,
    mc.virtual_memory_committed_kb,
    mc.awe_allocated_kb,
    mc.shared_memory_reserved_kb,
    mc.shared_memory_committed_kb,
    mc.single_pages_kb,
    mc.multi_pages_kb,
    mc.cached_pages_kb,
    os.total_physical_memory_kb,
    os.available_physical_memory_kb,
    os.system_memory_state_desc,
    SYSDATETIME() AS CaptureTime
FROM sys.dm_os_memory_clerks mc
CROSS JOIN sys.dm_os_sys_memory os
ORDER BY mc.pages_kb DESC
"@

        $sourceRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $query `
            -CommandTimeout 120

        if ($sourceRows.Rows.Count -eq 0) {
            Write-MonitorLog "Memory Clerks query returned no result set for $($Instance.DisplayName)"
            Stop-CollectionRun `
                -RepositoryServer $Instance.RepositoryServer `
                -RepositoryDatabase $Instance.RepositoryDatabase `
                -RunID $runId `
                -Status "Success"
            return
        }

        $targetTable = New-Object System.Data.DataTable
        [void]$targetTable.Columns.Add("InstanceID", [int])
        [void]$targetTable.Columns.Add("CaptureTime", [datetime])
        [void]$targetTable.Columns.Add("Type", [string])
        [void]$targetTable.Columns.Add("Name", [string])
        [void]$targetTable.Columns.Add("MemoryNodeId", [int])
        [void]$targetTable.Columns.Add("PagesKB", [long])
        [void]$targetTable.Columns.Add("VirtualMemoryReservedKB", [long])
        [void]$targetTable.Columns.Add("VirtualMemoryCommittedKB", [long])
        [void]$targetTable.Columns.Add("AweAllocatedKB", [long])
        [void]$targetTable.Columns.Add("SharedMemoryReservedKB", [long])
        [void]$targetTable.Columns.Add("SharedMemoryCommittedKB", [long])
        [void]$targetTable.Columns.Add("SinglePagesKB", [long])
        [void]$targetTable.Columns.Add("MultiPagesKB", [long])
        [void]$targetTable.Columns.Add("CachedPagesKB", [long])
        [void]$targetTable.Columns.Add("TotalPhysicalMemoryKB", [long])
        [void]$targetTable.Columns.Add("AvailablePhysicalMemoryKB", [long])
        [void]$targetTable.Columns.Add("SystemMemoryState", [string])
        [void]$targetTable.Columns.Add("PressureLevel", [string])
        [void]$targetTable.Columns.Add("Recommendations", [string])

        foreach ($row in $sourceRows.Rows) {
            $newRow = $targetTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime]$row["CaptureTime"]
            $newRow["Type"] = if ($row["type"] -is [DBNull]) { $null } else { [string]$row["type"] }
            $newRow["Name"] = if ($row["name"] -is [DBNull]) { $null } else { [string]$row["name"] }
            $newRow["MemoryNodeId"] = if ($row["memory_node_id"] -is [DBNull]) { $null } else { [int]$row["memory_node_id"] }
            $newRow["PagesKB"] = if ($row["pages_kb"] -is [DBNull]) { $null } else { [long]$row["pages_kb"] }
            $newRow["VirtualMemoryReservedKB"] = if ($row["virtual_memory_reserved_kb"] -is [DBNull]) { $null } else { [long]$row["virtual_memory_reserved_kb"] }
            $newRow["VirtualMemoryCommittedKB"] = if ($row["virtual_memory_committed_kb"] -is [DBNull]) { $null } else { [long]$row["virtual_memory_committed_kb"] }
            $newRow["AweAllocatedKB"] = if ($row["awe_allocated_kb"] -is [DBNull]) { $null } else { [long]$row["awe_allocated_kb"] }
            $newRow["SharedMemoryReservedKB"] = if ($row["shared_memory_reserved_kb"] -is [DBNull]) { $null } else { [long]$row["shared_memory_reserved_kb"] }
            $newRow["SharedMemoryCommittedKB"] = if ($row["shared_memory_committed_kb"] -is [DBNull]) { $null } else { [long]$row["shared_memory_committed_kb"] }
            $newRow["SinglePagesKB"] = if ($row["single_pages_kb"] -is [DBNull]) { $null } else { [long]$row["single_pages_kb"] }
            $newRow["MultiPagesKB"] = if ($row["multi_pages_kb"] -is [DBNull]) { $null } else { [long]$row["multi_pages_kb"] }
            $newRow["CachedPagesKB"] = if ($row["cached_pages_kb"] -is [DBNull]) { $null } else { [long]$row["cached_pages_kb"] }
            $newRow["TotalPhysicalMemoryKB"] = if ($row["total_physical_memory_kb"] -is [DBNull]) { $null } else { [long]$row["total_physical_memory_kb"] }
            $newRow["AvailablePhysicalMemoryKB"] = if ($row["available_physical_memory_kb"] -is [DBNull]) { $null } else { [long]$row["available_physical_memory_kb"] }
            $newRow["SystemMemoryState"] = if ($row["system_memory_state_desc"] -is [DBNull]) { $null } else { [string]$row["system_memory_state_desc"] }
            $newRow["PressureLevel"] = "Normal"
            $newRow["Recommendations"] = $null
            $targetTable.Rows.Add($newRow)
        }

        Write-DataTableToSql `
            -ServerInstance $Instance.RepositoryServer `
            -Database $Instance.RepositoryDatabase `
            -DestinationTable "mon.MemoryClerksHistory" `
            -DataTable $targetTable

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"

        Write-MonitorLog "Memory Clerks collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "Memory Clerks collector failed for $($Instance.DisplayName): $msg" -Level 'Error'
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-MemoryClerkCollector, Get-SQLServerMemoryClerks, Get-SQLServerBufferPoolAnalysis
