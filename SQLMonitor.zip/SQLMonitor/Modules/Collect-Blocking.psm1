function Invoke-BlockingCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "Blocking"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Blocking collector started for $($Instance.DisplayName)"

        $query = @"
        SELECT
            er.session_id as SPID,
            er.blocking_session_id as BlockedBySPID,
            DB_NAME(er.database_id) as DatabaseName,
            er.wait_type as WaitType,
            er.wait_time as WaitTimeMS,
            es.login_name as LoginName,
            es.host_name as HostName,
            er.command as CommandType,
            SUBSTRING(st.text, er.statement_start_offset/2 + 1, 
                (CASE WHEN er.statement_end_offset = -1 THEN LEN(CONVERT(nvarchar(max), st.text)) * 2 
                ELSE er.statement_end_offset END - er.statement_start_offset)/2) as StatementText
        FROM sys.dm_exec_requests er
        INNER JOIN sys.dm_exec_sessions es ON er.session_id = es.session_id
        OUTER APPLY sys.dm_exec_sql_text(er.sql_handle) st
        WHERE er.blocking_session_id <> 0
"@

        $blockingData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($blockingData.Rows.Count -gt 0) {
            $columns = @(Get-MonitorTableColumns -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -TableName 'mon.BlockingHistory')
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add("InstanceID", [int])
            [void]$targetTable.Columns.Add("CaptureTime", [datetime])
            $sessionColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('SessionID', 'SPID', 'BlockedSessionID')
            $blockingColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('BlockingSessionID', 'BlockedBySPID')
            $commandColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('CommandText', 'CommandType', 'LastCommand')
            $statementColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('StatementText', 'LastStatement')

            foreach ($requiredColumn in @($sessionColumn, $blockingColumn, $commandColumn, $statementColumn)) {
                if ([string]::IsNullOrWhiteSpace($requiredColumn)) {
                    throw 'mon.BlockingHistory does not contain the expected session/command columns.'
                }
            }

            [void]$targetTable.Columns.Add($sessionColumn, [int])
            [void]$targetTable.Columns.Add($blockingColumn, [int])
            [void]$targetTable.Columns.Add("DatabaseName", [string])
            [void]$targetTable.Columns.Add("WaitType", [string])
            [void]$targetTable.Columns.Add("WaitTimeMs", [long])
            [void]$targetTable.Columns.Add("HostName", [string])
            [void]$targetTable.Columns.Add("LoginName", [string])
            [void]$targetTable.Columns.Add($commandColumn, [string])
            [void]$targetTable.Columns.Add($statementColumn, [string])

            $captureTime = Get-Date

            foreach ($block in $blockingData.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow["InstanceID"] = $instanceId
                $newRow["CaptureTime"] = $captureTime
                $newRow[$sessionColumn] = $block["SPID"]
                $newRow[$blockingColumn] = $block["BlockedBySPID"]
                $newRow["DatabaseName"] = $block["DatabaseName"]
                $newRow["WaitType"] = $block["WaitType"]
                $newRow["WaitTimeMs"] = $block["WaitTimeMS"]
                $newRow["HostName"] = $block["HostName"]
                $newRow["LoginName"] = $block["LoginName"]
                $newRow[$commandColumn] = $block["CommandType"]
                $newRow[$statementColumn] = $block["StatementText"]
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.BlockingHistory" `
                -DataTable $targetTable

            Write-MonitorLog "Blocking collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-BlockingCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-BlockingCollector
