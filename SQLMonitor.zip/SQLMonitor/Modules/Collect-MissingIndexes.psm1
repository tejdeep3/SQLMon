function Invoke-MissingIndexesCollector {
    param (
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$Instance
    )

    $moduleName = "MissingIndexes"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    $query = @"
SELECT TOP 20
    DB_NAME(d.database_id) AS database_name,
    OBJECT_NAME(d.[object_id], d.database_id) AS [object_name],
    d.equality_columns,
    d.inequality_columns,
    d.included_columns,
    gs.user_seeks,
    gs.user_scans,
    CAST(0 as bigint) as user_lookups,
    CAST(0 as bigint) as user_updates,
    gs.avg_total_user_cost,
    gs.avg_user_impact,
    gs.unique_compiles,
    (gs.user_seeks + gs.user_scans) * gs.avg_total_user_cost * (gs.avg_user_impact * 0.01) AS improvement_measure
FROM sys.dm_db_missing_index_details d
INNER JOIN sys.dm_db_missing_index_groups g ON d.index_handle = g.index_handle
INNER JOIN sys.dm_db_missing_index_group_stats gs ON g.index_group_handle = gs.group_handle
ORDER BY improvement_measure DESC
"@

    try {
        Write-MonitorLog "Missing indexes collector started for $($Instance.DisplayName)"
        
        $indexesData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($indexesData.Rows.Count -gt 0) {
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add('InstanceID', [int])
            [void]$targetTable.Columns.Add('CollectionDateTime', [datetime])
            [void]$targetTable.Columns.Add('DatabaseName', [string])
            [void]$targetTable.Columns.Add('ObjectName', [string])
            [void]$targetTable.Columns.Add('EqualityColumns', [string])
            [void]$targetTable.Columns.Add('InequalityColumns', [string])
            [void]$targetTable.Columns.Add('IncludedColumns', [string])
            [void]$targetTable.Columns.Add('UserSeeks', [long])
            [void]$targetTable.Columns.Add('UserScans', [long])
            [void]$targetTable.Columns.Add('UserLookups', [long])
            [void]$targetTable.Columns.Add('UserUpdates', [long])
            [void]$targetTable.Columns.Add('AvgTotalUserCost', [double])
            [void]$targetTable.Columns.Add('AvgUserImpact', [double])
            [void]$targetTable.Columns.Add('UniqueCompiles', [long])
            [void]$targetTable.Columns.Add('ImprovementMeasure', [double])

            $captureTime = [datetime](Get-Date)

            foreach ($index in $indexesData.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow['InstanceID'] = $instanceId
                $newRow['CollectionDateTime'] = $captureTime
                $newRow['DatabaseName'] = if ($index['database_name'] -is [System.DBNull]) { [DBNull]::Value } else { [string]$index['database_name'] }
                $newRow['ObjectName'] = if ($index['object_name'] -is [System.DBNull]) { [DBNull]::Value } else { [string]$index['object_name'] }
                $newRow['EqualityColumns'] = if ($index['equality_columns'] -is [System.DBNull]) { [DBNull]::Value } else { [string]$index['equality_columns'] }
                $newRow['InequalityColumns'] = if ($index['inequality_columns'] -is [System.DBNull]) { [DBNull]::Value } else { [string]$index['inequality_columns'] }
                $newRow['IncludedColumns'] = if ($index['included_columns'] -is [System.DBNull]) { [DBNull]::Value } else { [string]$index['included_columns'] }
                $newRow['UserSeeks'] = if ($index['user_seeks'] -is [System.DBNull]) { 0 } else { [long]$index['user_seeks'] }
                $newRow['UserScans'] = if ($index['user_scans'] -is [System.DBNull]) { 0 } else { [long]$index['user_scans'] }
                $newRow['UserLookups'] = if ($index['user_lookups'] -is [System.DBNull]) { 0 } else { [long]$index['user_lookups'] }
                $newRow['UserUpdates'] = if ($index['user_updates'] -is [System.DBNull]) { 0 } else { [long]$index['user_updates'] }
                $newRow['AvgTotalUserCost'] = if ($index['avg_total_user_cost'] -is [System.DBNull]) { [DBNull]::Value } else { [double]$index['avg_total_user_cost'] }
                $newRow['AvgUserImpact'] = if ($index['avg_user_impact'] -is [System.DBNull]) { [DBNull]::Value } else { [double]$index['avg_user_impact'] }
                $newRow['UniqueCompiles'] = if ($index['unique_compiles'] -is [System.DBNull]) { [DBNull]::Value } else { [long]$index['unique_compiles'] }
                $newRow['ImprovementMeasure'] = if ($index['improvement_measure'] -is [System.DBNull]) { 0 } else { [double]$index['improvement_measure'] }
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable 'dbo.MissingIndexes' `
                -DataTable $targetTable
            
            Write-MonitorLog "Missing indexes collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-MissingIndexesCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-MissingIndexesCollector
