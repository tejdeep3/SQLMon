# Collect-ExecutionPlans.psm1
# Advanced SQL Server execution plan monitoring and analysis
# UNIQUE FEATURE: Real-time query execution plan analysis with optimization recommendations

function Get-SQLServerExecutionPlans {
    <#
    .SYNOPSIS
        Retrieves and analyzes execution plans for running queries.
    .DESCRIPTION
        Monitors active queries, captures their execution plans, and provides optimization recommendations.
        This feature analyzes plan complexity, missing indexes, and performance bottlenecks.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Instance,

        [Parameter(Mandatory = $false)]
        [int]$TopQueries = 10,

        [Parameter(Mandatory = $false)]
        [switch]$IncludeRecommendations
    )

    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $query = @"
SELECT TOP ($TopQueries)
    r.session_id,
    r.start_time,
    r.status,
    r.command,
    r.cpu_time,
    r.total_elapsed_time,
    r.reads,
    r.writes,
    r.logical_reads,
    r.wait_type,
    r.wait_time,
    r.last_wait_type,
    r.wait_resource,
    st.text AS sql_text,
    qp.query_plan
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) st
CROSS APPLY sys.dm_exec_query_plan(r.plan_handle) qp
WHERE r.session_id <> @@SPID
ORDER BY r.cpu_time DESC
"@

    try {
        $results = Invoke-Sqlcmd -ServerInstance $Instance.SqlInstance -Database 'master' -Query $query -ErrorAction Stop

        $analyzedPlans = @()
        foreach ($row in $results) {
            $analysis = [PSCustomObject]@{
                SessionId = $row.session_id
                StartTime = $row.start_time
                Status = $row.status
                Command = $row.command
                CpuTime = $row.cpu_time
                ElapsedTime = $row.total_elapsed_time
                Reads = $row.reads
                Writes = $row.writes
                LogicalReads = $row.logical_reads
                WaitType = $row.wait_type
                WaitTime = $row.wait_time
                SqlText = $row.sql_text
                QueryPlanXml = $row.query_plan
                Recommendations = @()
            }

            if ($IncludeRecommendations) {
                $analysis.Recommendations = Get-ExecutionPlanRecommendations -PlanXml $row.query_plan -SqlText $row.sql_text
            }

            $sqlText = if ($row.sql_text) { ([string]$row.sql_text).Replace("'", "''") } else { $null }
            $queryPlan = if ($row.query_plan) { ([string]$row.query_plan).Replace("'", "''") } else { $null }
            $recommendations = if ($analysis.Recommendations.Count -gt 0) { ($analysis.Recommendations -join '; ').Replace("'", "''") } else { $null }

            # Save to repository
            $query = @"
INSERT INTO [mon].[ExecutionPlansHistory] (
    [InstanceID], [CaptureTime], [SessionId], [StartTime], [Status], [Command],
    [CpuTime], [ElapsedTime], [Reads], [Writes], [LogicalReads], [WaitType], [WaitTime],
    [SqlText], [QueryPlanXml], [Recommendations]
) VALUES (
    $instanceId,
    GETUTCDATE(), $($row.session_id), $(if ($row.start_time) { "'$($row.start_time.ToString('yyyy-MM-dd HH:mm:ss.fff'))'" } else { 'NULL' }),
    $(if ($row.status) { "'$($row.status)'" } else { 'NULL' }), $(if ($row.command) { "'$($row.command)'" } else { 'NULL' }),
    $($row.cpu_time), $($row.total_elapsed_time), $($row.reads), $($row.writes), $($row.logical_reads),
    $(if ($row.wait_type) { "'$($row.wait_type)'" } else { 'NULL' }), $($row.wait_time),
    $(if ($sqlText) { "'$sqlText'" } else { 'NULL' }),
    $(if ($queryPlan) { "'$queryPlan'" } else { 'NULL' }),
    $(if ($recommendations) { "'$recommendations'" } else { 'NULL' })
)
"@

            try {
                Invoke-Sqlcmd -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -Query $query -ErrorAction Stop
            }
            catch {
                Write-MonitorLog "WARNING failed to save execution plan data: $($_.Exception.Message)" -Level 'Warning'
            }

            $analyzedPlans += $analysis
        }

        return $analyzedPlans
    }
    catch {
        Write-MonitorLog "ERROR collecting execution plans: $($_.Exception.Message)" -Level 'Error'
        return @()
    }
}

function Get-ExecutionPlanRecommendations {
    <#
    .SYNOPSIS
        Analyzes execution plan XML and provides optimization recommendations.
    #>
    param(
        [string]$PlanXml,
        [string]$SqlText
    )

    $recommendations = @()

    if ([string]::IsNullOrWhiteSpace($PlanXml)) {
        return $recommendations
    }

    try {
        $xml = [xml]$PlanXml

        # Check for table scans
        $tableScans = $xml.SelectNodes("//RelOp[@PhysicalOp='Table Scan']")
        if ($tableScans.Count -gt 0) {
            $recommendations += "Consider adding indexes to eliminate table scans. Found $($tableScans.Count) table scan operations."
        }

        # Check for missing indexes
        $missingIndexes = $xml.SelectNodes("//MissingIndex")
        if ($missingIndexes.Count -gt 0) {
            $recommendations += "Missing indexes detected. Consider creating suggested indexes to improve query performance."
        }

        # Check for high cost operations
        $highCostOps = $xml.SelectNodes("//RelOp[@EstimatedTotalSubtreeCost > 1.0]")
        if ($highCostOps.Count -gt 0) {
            $recommendations += "High-cost operations detected (cost > 1.0). Review query structure and indexing strategy."
        }

        # Check for parallelism
        $parallelOps = $xml.SelectNodes("//RelOp[@Parallel='1']")
        if ($parallelOps.Count -gt 0) {
            $recommendations += "Query is using parallelism. Monitor for CXPACKET waits and consider MAXDOP settings."
        }

        # Check for sorts
        $sortOps = $xml.SelectNodes("//RelOp[@PhysicalOp='Sort']")
        if ($sortOps.Count -gt 0) {
            $recommendations += "Sort operations detected. Consider ORDER BY optimization or covering indexes."
        }

        # Analyze SQL text for potential issues
        if ($SqlText -match 'SELECT \*') {
            $recommendations += "SELECT * detected. Consider specifying only required columns to reduce I/O."
        }

        if ($SqlText -match '%LIKE.*[^]]%' -and $SqlText -notmatch 'LIKE.*\[.*\]') {
            $recommendations += "Leading wildcard in LIKE clause detected. Consider full-text search or different indexing strategy."
        }

    }
    catch {
        Write-MonitorLog "WARNING failed to analyze execution plan: $($_.Exception.Message)" -Level 'Warning'
    }

    return $recommendations
}

function Get-SQLServerQueryStoreInsights {
    <#
    .SYNOPSIS
        Analyzes Query Store data for performance insights and forced plan effectiveness.
    .DESCRIPTION
        UNIQUE FEATURE: Tracks effectiveness of forced execution plans and provides recommendations.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Instance,

        [Parameter(Mandatory = $false)]
        [int]$DaysBack = 7
    )

    $query = @"
SELECT TOP 50
    q.query_id,
    qt.query_text_id,
    qt.query_sql_text,
    rs.runtime_stats_id,
    rs.plan_id,
    p.is_forced_plan,
    rs.avg_duration,
    rs.avg_cpu_time,
    rs.avg_logical_io_reads,
    rs.avg_logical_io_writes,
    rs.count_executions,
    rs.last_execution_time,
    p.query_plan
FROM sys.query_store_query q
JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
JOIN sys.query_store_plan p ON q.query_id = p.query_id
LEFT JOIN sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
WHERE rs.last_execution_time >= DATEADD(day, -$DaysBack, GETUTCDATE())
ORDER BY rs.avg_duration DESC
"@

    try {
        $results = Invoke-Sqlcmd -ServerInstance $Instance.SqlInstance -Database 'master' -Query $query -ErrorAction Stop

        $insights = @()
        foreach ($row in $results) {
            $insight = [PSCustomObject]@{
                QueryId = $row.query_id
                QueryText = $row.query_sql_text
                PlanId = $row.plan_id
                IsForcedPlan = [bool]$row.is_forced_plan
                AvgDuration = $row.avg_duration
                AvgCpuTime = $row.avg_cpu_time
                AvgLogicalReads = $row.avg_logical_io_reads
                AvgLogicalWrites = $row.avg_logical_io_writes
                ExecutionCount = $row.count_executions
                LastExecutionTime = $row.last_execution_time
                Effectiveness = 'Unknown'
                Recommendations = @()
            }

            # Analyze forced plan effectiveness
            if ($row.is_forced_plan) {
                # Simple effectiveness check based on execution count and performance
                if ($row.count_executions -gt 10) {
                    $insight.Effectiveness = 'Effective'
                    $insight.Recommendations += "Forced plan appears effective with $($row.count_executions) executions."
                } else {
                    $insight.Effectiveness = 'Under Review'
                    $insight.Recommendations += "Forced plan has limited executions. Monitor performance over time."
                }
            }

            $insights += $insight
        }

        return $insights
    }
    catch {
        Write-MonitorLog "ERROR collecting Query Store insights: $($_.Exception.Message)" -Level 'Error'
        return @()
    }
}

Export-ModuleMember -Function Get-SQLServerExecutionPlans, Get-SQLServerQueryStoreInsights
