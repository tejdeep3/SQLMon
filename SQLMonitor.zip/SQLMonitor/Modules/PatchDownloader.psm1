# PatchDownloader.psm1
# Microsoft Update Catalog-backed patch download support for SQL Server

$commonModulePath = Join-Path $PSScriptRoot 'Common.psm1'
if (-not (Get-Module -Name Common)) {
    Import-Module $commonModulePath -Global -WarningAction SilentlyContinue
}

$patchManagerModulePath = Join-Path $PSScriptRoot 'PatchManager.psm1'
if (-not (Get-Module -Name PatchManager)) {
    Import-Module $patchManagerModulePath -Global -WarningAction SilentlyContinue
}

function Invoke-SQLServerPatchDownloader {
    <#
    .SYNOPSIS
        Downloads the recommended SQL Server patch for an instance.
    .DESCRIPTION
        Resolves the recommended patch from patch status, locates a Microsoft
        Update Catalog download link for the KB, and downloads the resulting file(s).
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Instance,

        [Parameter(Mandatory = $false)]
        [object]$Patch,

        [Parameter(Mandatory = $false)]
        [string]$DownloadPath,

        [Parameter(Mandatory = $false)]
        [switch]$Force
    )

    if (-not $DownloadPath) {
        $projectRoot = Get-SqlMonitorProjectRoot
        $DownloadPath = Join-Path $projectRoot 'Patches'
    }

    if (-not (Test-Path $DownloadPath)) {
        New-Item -ItemType Directory -Path $DownloadPath -Force | Out-Null
    }

    try {
        Write-MonitorLog "Starting patch download for $($Instance.DisplayName)"

        $patchInfo = Get-SQLServerPatchInfo -Instance $Instance
        $targetPatch = if ($Patch) { $Patch } else { $patchInfo.RecommendedPatch }

        if (-not $targetPatch) {
            Write-MonitorLog "No recommended patch was found for $($Instance.DisplayName). Patch status=$($patchInfo.PatchStatus)"
            return @()
        }

        $downloadInfo = Resolve-MicrosoftCatalogPatchDownload -Patch $targetPatch -VersionName $patchInfo.VersionName
        if (-not $downloadInfo -or $downloadInfo.DownloadLinks.Count -eq 0) {
            Write-MonitorLog "No catalog download links were resolved for $($targetPatch.KBNumber)" -Level 'Warning'
            return @()
        }

        $instanceFolderName = (($Instance.DisplayName -replace '[\\/:*?"<>|]', '_').Trim('_'))
        if ([string]::IsNullOrWhiteSpace($instanceFolderName)) {
            $instanceFolderName = 'SQLServer'
        }

        $targetFolder = Join-Path $DownloadPath $instanceFolderName
        if (-not (Test-Path $targetFolder)) {
            New-Item -ItemType Directory -Path $targetFolder -Force | Out-Null
        }

        $downloadedFiles = @()
        $downloadIndex = 1
        foreach ($link in $downloadInfo.DownloadLinks) {
            try {
                $fileName = Get-SqlServerPatchFileName -DownloadUrl $link -Patch $targetPatch -Index $downloadIndex
                $localPath = Join-Path $targetFolder $fileName

                if ((Test-Path $localPath) -and -not $Force) {
                    Write-MonitorLog "Patch already exists: $localPath"
                    $downloadIndex++
                    continue
                }

                Write-MonitorLog "Downloading patch $($targetPatch.KBNumber) from Microsoft Update Catalog to $localPath"
                Invoke-WebRequest -Uri $link -OutFile $localPath -UseBasicParsing -TimeoutSec 1800

                if (Test-Path $localPath) {
                    $fileInfo = Get-Item $localPath
                    $downloadedFiles += [PSCustomObject]@{
                        FileName       = $fileInfo.Name
                        LocalPath      = $localPath
                        Size           = $fileInfo.Length
                        DownloadDate   = Get-Date
                        KBNumber       = $targetPatch.KBNumber
                        Title          = $targetPatch.DisplayLabel
                        BuildVersion   = $targetPatch.BuildVersion
                        Source         = 'Microsoft Update Catalog'
                        CatalogUrl     = $targetPatch.CatalogUrl
                        SupportUrl     = $targetPatch.SupportUrl
                        CatalogUpdateId= $downloadInfo.UpdateId
                    }
                }

                $downloadIndex++
            }
            catch {
                Write-MonitorLog "ERROR downloading patch $($targetPatch.KBNumber): $($_.Exception.Message)" -Level 'Error'
            }
        }

        Write-MonitorLog "Patch download completed for $($Instance.DisplayName). Downloaded $($downloadedFiles.Count) file(s)."
        return $downloadedFiles
    }
    catch {
        Write-MonitorLog "ERROR in Invoke-SQLServerPatchDownloader for $($Instance.DisplayName): $($_.Exception.Message)" -Level 'Error'
        throw
    }
}

function Resolve-MicrosoftCatalogPatchDownload {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Patch,

        [string]$VersionName
    )

    $updateIds = @()
    if ($Patch.PSObject.Properties.Match('CatalogUpdateId').Count -gt 0 -and $Patch.CatalogUpdateId) {
        $updateIds += [string]$Patch.CatalogUpdateId
    }

    if ($updateIds.Count -eq 0) {
        $updateIds += Get-MicrosoftCatalogUpdateIds -KBNumber $Patch.KBNumber -VersionName $VersionName
    }

    foreach ($updateId in ($updateIds | Select-Object -Unique)) {
        $downloadLinks = Get-MicrosoftCatalogDownloadLinks -UpdateId $updateId
        if ($downloadLinks.Count -gt 0) {
            return [PSCustomObject]@{
                UpdateId      = $updateId
                DownloadLinks = @($downloadLinks)
            }
        }
    }

    return $null
}

function Get-MicrosoftCatalogUpdateIds {
    param(
        [Parameter(Mandatory = $true)]
        [string]$KBNumber,

        [string]$VersionName
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $kbDigits = $KBNumber -replace '[^\d]', ''
    if ([string]::IsNullOrWhiteSpace($kbDigits)) {
        return @()
    }

    $searchTerms = @(
        "KB$kbDigits"
    )

    if ($VersionName) {
        $searchTerms = @(
            "`"KB$kbDigits`" `"$VersionName`"",
            "$VersionName KB$kbDigits",
            "KB$kbDigits"
        )
    }

    foreach ($term in $searchTerms | Select-Object -Unique) {
        try {
            $encodedTerm = [System.Uri]::EscapeDataString($term)
            $searchUrl = "https://www.catalog.update.microsoft.com/Search.aspx?q=$encodedTerm"
            Write-MonitorLog "Searching Microsoft Update Catalog for update id: $term"

            $response = Invoke-WebRequest -Uri $searchUrl -UseBasicParsing -TimeoutSec 60
            if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
                continue
            }

            $updateIds = Extract-MicrosoftCatalogUpdateIdsFromHtml -Html $response.Content
            if ($updateIds.Count -gt 0) {
                return @($updateIds)
            }
        }
        catch {
            Write-MonitorLog "WARNING Microsoft Update Catalog search failed for '$term': $($_.Exception.Message)" -Level 'Warning'
        }
    }

    return @()
}

function Extract-MicrosoftCatalogUpdateIdsFromHtml {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Html
    )

    $guidPattern = '(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b'
    $patterns = @(
        '(?i)goToDetails\s*\(\s*["''](?<id>' + $guidPattern + ')["'']',
        '(?i)addToBasket\s*\(\s*["''](?<id>' + $guidPattern + ')["'']',
        '(?i)uidInfo["'']?\s*[:=]\s*["''](?<id>' + $guidPattern + ')["'']',
        '(?i)updateID["'']?\s*[:=]\s*["''](?<id>' + $guidPattern + ')["'']'
    )

    $ids = New-Object System.Collections.Generic.List[string]
    foreach ($pattern in $patterns) {
        foreach ($match in [regex]::Matches($Html, $pattern)) {
            $candidate = $match.Groups['id'].Value
            if (-not [string]::IsNullOrWhiteSpace($candidate) -and -not $ids.Contains($candidate)) {
                [void]$ids.Add($candidate)
            }
        }
    }

    if ($ids.Count -eq 0) {
        foreach ($match in [regex]::Matches($Html, $guidPattern)) {
            $candidate = $match.Value
            if (-not [string]::IsNullOrWhiteSpace($candidate) -and -not $ids.Contains($candidate)) {
                [void]$ids.Add($candidate)
            }
        }
    }

    return @($ids | Select-Object -First 10)
}

function Get-MicrosoftCatalogDownloadLinks {
    param(
        [Parameter(Mandatory = $true)]
        [string]$UpdateId
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    try {
        $payload = @{
            size     = 0
            updateID = $UpdateId
            uidInfo  = $UpdateId
        } | ConvertTo-Json -Compress

        $body = @{
            updateIDs = "[$payload]"
        }

        Write-MonitorLog "Resolving Microsoft Update Catalog download links for update id $UpdateId"
        $response = Invoke-WebRequest -Uri 'https://www.catalog.update.microsoft.com/DownloadDialog.aspx' -Method Post -Body $body -ContentType 'application/x-www-form-urlencoded' -UseBasicParsing -TimeoutSec 60
        if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
            return @()
        }

        $pattern = '(http[s]?\://dl\.delivery\.mp\.microsoft\.com/[^''""]*)|(http[s]?\://download\.windowsupdate\.com/[^''""]*)|(http[s]?\://catalog\.s\.download\.windowsupdate\.com/[^''""]*)'
        $links = [regex]::Matches($response.Content.Replace('www.download.windowsupdate', 'download.windowsupdate'), $pattern) |
            ForEach-Object { $_.Value } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            Select-Object -Unique

        return @($links)
    }
    catch {
        Write-MonitorLog "WARNING failed to resolve Microsoft Update Catalog download links for ${UpdateId}: $($_.Exception.Message)" -Level 'Warning'
        return @()
    }
}

function Get-SqlServerPatchFileName {
    param(
        [Parameter(Mandatory = $true)]
        [string]$DownloadUrl,

        [Parameter(Mandatory = $true)]
        [object]$Patch,

        [int]$Index = 1
    )

    $leaf = Split-Path $DownloadUrl -Leaf
    if (-not [string]::IsNullOrWhiteSpace($leaf) -and $leaf -match '\.') {
        return $leaf
    }

    $extension = '.exe'
    if ($DownloadUrl -match '\.zip(\?|$)') { $extension = '.zip' }
    elseif ($DownloadUrl -match '\.msi(\?|$)') { $extension = '.msi' }
    elseif ($DownloadUrl -match '\.cab(\?|$)') { $extension = '.cab' }

    $safeLabel = ([string]$Patch.DisplayLabel -replace '[^A-Za-z0-9._-]', '_').Trim('_')
    if ([string]::IsNullOrWhiteSpace($safeLabel)) {
        $safeLabel = 'SQLPatch'
    }

    return "{0}_{1}_{2}{3}" -f $Patch.KBNumber, $safeLabel, $Index, $extension
}

function Invoke-BulkPatchDownload {
    <#
    .SYNOPSIS
        Downloads recommended patches for all active monitored SQL Server instances.
    #>
    param(
        [Parameter(Mandatory = $false)]
        [string]$DownloadPath,

        [Parameter(Mandatory = $false)]
        [switch]$Force
    )

    if (-not $DownloadPath) {
        $projectRoot = Get-SqlMonitorProjectRoot
        $DownloadPath = Join-Path $projectRoot 'Patches'
    }

    $allDownloads = @()

    try {
        $instances = @(Get-SqlMonitorInstances | Where-Object { $_.IsActive })
        foreach ($instance in $instances) {
            $allDownloads += Invoke-SQLServerPatchDownloader -Instance $instance -DownloadPath $DownloadPath -Force:$Force
        }

        Write-MonitorLog "Bulk patch download completed. Downloaded $($allDownloads.Count) file(s) total."
        return $allDownloads
    }
    catch {
        Write-MonitorLog "ERROR in Invoke-BulkPatchDownload: $($_.Exception.Message)" -Level 'Error'
        throw
    }
}

# Export functions
Export-ModuleMember -Function Invoke-SQLServerPatchDownloader, Invoke-BulkPatchDownload, Resolve-MicrosoftCatalogPatchDownload, Get-MicrosoftCatalogDownloadLinks
