# WebAgent.psm1
# Structured web-solution search for SQL Server errors and alert text

$script:WebAgentUserAgent = 'SQLMonitor/1.0 (+https://learn.microsoft.com/sql/)'

function Invoke-WebSolutionsAgent {
    <#
    .SYNOPSIS
        Searches trusted web sources for SQL Server solutions.
    .DESCRIPTION
        Builds a structured search context from the error text and alert title, searches trusted
        sources, normalizes the results, and returns the best-ranked solutions.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string]$ErrorMessage,

        [Parameter(Mandatory = $false)]
        [string]$AlertTitle,

        [Parameter(Mandatory = $false)]
        [object]$Instance,

        [Parameter(Mandatory = $false)]
        [int]$MaxResults = 5
    )

    try {
        $logContext = if ([string]::IsNullOrWhiteSpace($AlertTitle)) { $ErrorMessage } else { "$AlertTitle | $ErrorMessage" }
        Write-MonitorLog "Web Solutions Agent started for error: $logContext"

        $context = Get-WebAgentSearchContext -ErrorMessage $ErrorMessage -AlertTitle $AlertTitle -Instance $Instance
        $results = @()

        if ($context.ErrorNumber) {
            $results += Search-MicrosoftLearnSqlErrorReference -Context $context
        }

        $results += Search-MicrosoftLearnContent -Context $context -MaxResults ([Math]::Max([Math]::Ceiling($MaxResults / 2), 2))
        $results += Search-StackOverflowExcerpts -Context $context -MaxResults ([Math]::Max($MaxResults, 3))

        $rankedResults = Merge-WebAgentResults -Results $results -Context $context
        $finalResults = @($rankedResults | Select-Object -First $MaxResults)

        Write-MonitorLog "Web Solutions Agent completed. Found $($finalResults.Count) structured solutions."
        return $finalResults
    }
    catch {
        Write-MonitorLog "ERROR in Invoke-WebSolutionsAgent: $($_.Exception.Message)" -Level 'Error'
        throw
    }
}

function Invoke-WebDiagnosticAssistant {
    <#
    .SYNOPSIS
        Generates a diagnostics summary and remediation guidance for SQL Server alerts.
    .DESCRIPTION
        Uses alert text, recognized SQL Server patterns, and repository evidence to produce a concise
        root cause summary, likely category, and recommended actions.
    #>
    param(
        [Parameter(Mandatory = $false)]
        [string]$AlertTitle,

        [Parameter(Mandatory = $true)]
        [string]$AlertDetails,

        [Parameter(Mandatory = $false)]
        [object]$Instance,

        [int]$MaxRecommendations = 4
    )

    try {
        $context = Get-WebAgentSearchContext -ErrorMessage $AlertDetails -AlertTitle $AlertTitle -Instance $Instance
        $category = Get-WebAgentDiagnosticCategory -Context $context
        $evidence = Get-WebAgentDiagnosticEvidence -Context $context -Instance $Instance
        $actions = Get-WebAgentDiagnosticRecommendations -Context $context -Category $category -MaxRecommendations $MaxRecommendations

        $summary = Get-WebAgentDiagnosticSummary -Context $context -Category $category -Evidence $evidence
        $confidence = if ($category -and $actions.Count -gt 0) { 84 } else { 62 }
        if ($context.ErrorNumber) { $confidence += 6 }
        if ($evidence.AlertCounts) { $confidence += 4 }
        if ($confidence -gt 98) { $confidence = 98 }

        return [PSCustomObject]@{
            AlertTitle          = $context.AlertTitle
            AlertDetails        = $context.CleanMessage
            Category            = $category
            ErrorNumber         = $context.ErrorNumber
            LikelyCause         = $summary.LikelyCause
            Summary             = $summary.Summary
            RecommendedActions  = $actions
            Evidence            = $evidence
            ConfidenceScore     = $confidence
            DiagnosticTimeUtc   = (Get-Date).ToUniversalTime()
        }
    }
    catch {
        Write-MonitorLog "ERROR in Invoke-WebDiagnosticAssistant: $($_.Exception.Message)" -Level 'Error'
        throw
    }
}

function Get-WebAgentDiagnosticCategory {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Context
    )

    $weights = @{}
    $text = @($Context.AlertTitle, $Context.NormalizedMessage, $Context.CleanMessage) -join ' '
    $text = $text.ToLowerInvariant()

    $mappings = @(
        @{ Category = 'Deadlock'; Pattern = 'deadlock|deadlocked|deadlock graph|deadlock chain' },
        @{ Category = 'Blocking'; Pattern = 'blocked|blocking|lock wait|lock timeout|lock escalation|lock request' },
        @{ Category = 'Memory Pressure'; Pattern = 'memory pressure|page life expectancy|ple|buffer pool|low memory|memory grant' },
        @{ Category = 'CPU High'; Pattern = 'cpu|processor|high cpu|percent processor time|scheduler|context switch' },
        @{ Category = 'IO / Storage'; Pattern = 'io|disk|read latency|write latency|throughput|physical read|physical write|io stall|page file|backup log full|transaction log' },
        @{ Category = 'TempDB Contention'; Pattern = 'tempdb|tempdb contention|tempdb allocation|tempdb spill|tempdb metadata' },
        @{ Category = 'Backup / Restore'; Pattern = 'backup failed|restore failed|log backup|backup job|restore|transaction log backup|log full' },
        @{ Category = 'Availability / AG'; Pattern = 'availability group|always on|replica|synchronization|failover|cluster|wsfc' },
        @{ Category = 'Security / Authentication'; Pattern = 'login failed|failed login|auditing|authentication|permission denied|access denied|credential' },
        @{ Category = 'Query Performance'; Pattern = 'long running|execution plan|missing index|slow query|plan guide|hash match|sort warning' }
    )

    foreach ($mapping in $mappings) {
        if ($text -match $mapping.Pattern) {
            $weights[$mapping.Category] = ($weights[$mapping.Category] + 10)
        }
    }

    if ($Context.ErrorNumber) {
        switch ($Context.ErrorNumber) {
            1205 { $weights['Deadlock'] = ($weights['Deadlock'] + 20) }
            1222 { $weights['Blocking'] = ($weights['Blocking'] + 20) }
            8651 { $weights['Memory Pressure'] = ($weights['Memory Pressure'] + 18) }
            1105 { $weights['IO / Storage'] = ($weights['IO / Storage'] + 18) }
            823 { $weights['IO / Storage'] = ($weights['IO / Storage'] + 18) }
            default { }
        }
    }

    if ($weights.Count -eq 0) {
        return 'General SQL Server Issue'
    }

    return ($weights.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 1).Name
}

function Get-WebAgentDiagnosticEvidence {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Context,

        [Parameter(Mandatory = $false)]
        [object]$Instance
    )

    $evidence = [PSCustomObject]@{
        AlertCounts = $null
        RecentModuleBreakdown = $null
        RecentAlerts = $null
        SourceNotes = @()
    }

    if (-not $Instance) {
        return $evidence
    }

    try {
        $instanceId = Get-MonitorInstanceId -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -DisplayName $Instance.DisplayName -SqlInstance $Instance.SqlInstance
        if (-not $instanceId) { return $evidence }

        $moduleSql = @"
SELECT TOP 5
    ModuleName,
    Severity,
    COUNT(*) AS AlertCount
FROM mon.vw_AlertHistoryDetailed
WHERE InstanceID = @InstanceID
  AND AlertTime > DATEADD(MINUTE, -60, GETDATE())
GROUP BY ModuleName, Severity
ORDER BY AlertCount DESC, Severity DESC;
"@
        $alertBreakdown = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $moduleSql -Parameters @{ InstanceID = $instanceId }
        if ($alertBreakdown -and $alertBreakdown.Rows.Count -gt 0) {
            $evidence.RecentModuleBreakdown = $alertBreakdown | Select-Object -First 5
            $evidence.AlertCounts = @{
                Critical = ($alertBreakdown | Where-Object { $_.Severity -eq 'Critical' } | Measure-Object -Sum AlertCount).Sum
                Warning  = ($alertBreakdown | Where-Object { $_.Severity -eq 'Warning' } | Measure-Object -Sum AlertCount).Sum
                Informational = ($alertBreakdown | Where-Object { $_.Severity -eq 'Informational' } | Measure-Object -Sum AlertCount).Sum
            }
        }

        $recentAlerts = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
SELECT TOP 5 AlertTime, Severity, ModuleName, AlertTitle
FROM mon.vw_AlertHistoryDetailed
WHERE InstanceID = @InstanceID
  AND AlertTime > DATEADD(MINUTE, -120, GETDATE())
ORDER BY AlertTime DESC;
"@ -Parameters @{ InstanceID = $instanceId }
        if ($recentAlerts -and $recentAlerts.Rows.Count -gt 0) {
            $evidence.RecentAlerts = $recentAlerts | Select-Object -First 5
        }

        if ($evidence.RecentModuleBreakdown) {
            $evidence.SourceNotes += 'Repository evidence collected from recent alert history.'
        }
    }
    catch {
        Write-MonitorLog "WARNING inability to build diagnostic evidence: $($_.Exception.Message)" -Level 'Warning'
    }

    return $evidence
}

function Get-WebAgentDiagnosticRecommendations {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Context,

        [Parameter(Mandatory = $true)]
        [string]$Category,

        [int]$MaxRecommendations = 4
    )

    $recommendations = @()

    switch ($Category) {
        'Deadlock' {
            $recommendations += 'Capture the deadlock graph and identify the conflicting statements.'
            $recommendations += 'Review transaction scope and shorten long-running transactions.'
            $recommendations += 'Ensure proper indexing and access order for frequently updated tables.'
            $recommendations += 'Consider using READ_COMMITTED_SNAPSHOT for read/write contention reduction.'
        }
        'Blocking' {
            $recommendations += 'Identify the blocker session and check the associated query text.'
            $recommendations += 'Review open transactions and commit or rollback long-running work promptly.'
            $recommendations += 'Add or tune indexes to reduce lock escalation and scan duration.'
            $recommendations += 'Use lower isolation levels where safe to reduce lock duration.'
        }
        'Memory Pressure' {
            $recommendations += 'Review buffer pool usage and consider increasing SQL Server max memory.'
            $recommendations += 'Inspect query plans for spills and large memory grants.'
            $recommendations += 'Check for external memory pressure from other processes on the host.'
            $recommendations += 'Tune indexes or queries to reduce memory consumption where possible.'
        }
        'CPU High' {
            $recommendations += 'Identify top CPU-consuming queries and examine their execution plans.'
            $recommendations += 'Look for missing indexes, inefficient scans, and parallelism overhead.'
            $recommendations += 'Verify whether CPU pressure is sustained or due to a one-time workload spike.'
            $recommendations += 'Consider scaling compute or moving heavy workloads off peak hours.'
        }
        'IO / Storage' {
            $recommendations += 'Review disk latency and throughput counters for the underlying storage.'
            $recommendations += 'Check tempdb placement, file growth settings, and autogrowth events.'
            $recommendations += 'Evaluate query and index design for excessive logical reads.'
            $recommendations += 'Validate backup, restore, and transaction log maintenance schedules.'
        }
        'TempDB Contention' {
            $recommendations += 'Validate tempdb file layout and ensure equal sized files with simple growth.'
            $recommendations += 'Review requests for PAGELATCH_UP/EX and allocation contention.'
            $recommendations += 'Reduce tempdb usage in ad hoc queries, spool operators, and large sorts.'
            $recommendations += 'Consider changing tempdb to a fast local disk or mapped SSD if available.'
        }
        'Backup / Restore' {
            $recommendations += 'Check the failure details in SQL Server Agent job history and error logs.'
            $recommendations += 'Verify backup destinations, permissions, and free disk space.'
            $recommendations += 'Ensure transaction log backups are running frequently enough for the recovery model.'
            $recommendations += 'Validate backup strategy and restore tests for the affected databases.'
        }
        'Availability / AG' {
            $recommendations += 'Inspect AG replica synchronization state and network connectivity.'
            $recommendations += 'Review SQL Server error logs on all replicas for related failures.'
            $recommendations += 'Confirm health of underlying cluster and WSFC resources.'
            $recommendations += 'Validate database backup and failover readiness for the availability group.'
        }
        'Security / Authentication' {
            $recommendations += 'Review failed login details in the SQL Server error log.'
            $recommendations += 'Confirm the account exists, is enabled, and has correct credentials.'
            $recommendations += 'Check host-based firewalls and connection string user context.'
            $recommendations += 'Investigate whether too many invalid logins are causing lockout conditions.'
        }
        'Query Performance' {
            $recommendations += 'Collect the actual execution plan for the affected query.'
            $recommendations += 'Review missing index recommendations and expensive operators.'
            $recommendations += 'Check parameter sniffing and query compilation statistics.'
            $recommendations += 'Consider rewriting the query or adding filtered indexes where needed.'
        }
        default {
            $recommendations += 'Review the alert details and correlate with the latest instance performance metrics.'
            $recommendations += 'Check recent error logs, wait stats, and top queries for the selected instance.'
            $recommendations += 'Confirm whether the issue is transient or indicative of an ongoing resource problem.'
            $recommendations += 'Document the likely cause and monitor for recurrence after remediation.'
        }
    }

    if ($Context.ErrorNumber) {
        $recommendations = @("Review SQL Server error $($Context.ErrorNumber) details in Microsoft Learn or SQL Server Books Online.") + $recommendations
    }

    return $recommendations | Select-Object -First $MaxRecommendations
}

function Get-WebAgentDiagnosticSummary {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Context,

        [Parameter(Mandatory = $true)]
        [string]$Category,

        [Parameter(Mandatory = $true)]
        [object]$Evidence
    )

    $likelyCause = "The issue appears to be related to $Category."
    if ($Context.ErrorNumber) {
        $likelyCause = "The issue is likely driven by SQL Server error $($Context.ErrorNumber) and associated $Category signals."
    }

    $summaryLines = @()
    if ($Context.AlertTitle -ne '') {
        $summaryLines += "Alert summary: $($Context.AlertTitle)"
    }
    else {
        $summaryLines += "Alert summary: $($Context.OriginalMessage)"
    }
    $summaryLines += "Detected category: $Category"
    if ($Evidence.AlertCounts) {
        $criticalCount = $Evidence.AlertCounts.Critical
        $warningCount  = $Evidence.AlertCounts.Warning
        $informationalCount = $Evidence.AlertCounts.Informational
        $summaryLines += "Recent alert volume: Critical=$criticalCount, Warning=$warningCount, Informational=$informationalCount"
    }

    if ($Evidence.RecentModuleBreakdown) {
        $moduleNames = ($Evidence.RecentModuleBreakdown | Select-Object -ExpandProperty ModuleName | Select-Object -Unique) -join ', '
        if ($moduleNames) {
            $summaryLines += "Recent alert modules: $moduleNames"
        }
    }

    if ($Evidence.SourceNotes.Count -gt 0) {
        $summaryLines += "Evidence: $($Evidence.SourceNotes -join '; ')"
    }

    return [PSCustomObject]@{
        LikelyCause = $likelyCause
        Summary     = ($summaryLines -join ' ')
    }
}

function Format-WebAgentDiagnosisResult {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Diagnosis
    )

    if (-not $Diagnosis) {
        return 'No diagnostic result could be generated.'
    }

    $lines = @()
    $lines += "AI Diagnostic Summary"
    $lines += "====================="
    $lines += "Alert Title: $($Diagnosis.AlertTitle)"
    if ($Diagnosis.ErrorNumber) { $lines += "Detected Error Number: $($Diagnosis.ErrorNumber)" }
    $lines += "Likely Category: $($Diagnosis.Category)"
    $lines += "Confidence Score: $($Diagnosis.ConfidenceScore)%"
    $lines += ""
    $lines += "Likely Cause:"
    $lines += $Diagnosis.LikelyCause
    $lines += ""
    $lines += "Summary:"
    $lines += $Diagnosis.Summary

    if ($Diagnosis.Evidence -and $Diagnosis.Evidence.AlertCounts) {
        $lines += ""
        $lines += "Repository Evidence:"
        $lines += "  Critical alerts: $($Diagnosis.Evidence.AlertCounts.Critical)"
        $lines += "  Warning alerts:  $($Diagnosis.Evidence.AlertCounts.Warning)"
        $lines += "  Informational alerts: $($Diagnosis.Evidence.AlertCounts.Informational)"
        if ($Diagnosis.Evidence.RecentModuleBreakdown) {
            $lines += "  Recent modules: $((($Diagnosis.Evidence.RecentModuleBreakdown | Select-Object -ExpandProperty ModuleName | Select-Object -Unique) -join ', '))"
        }
    }

    if ($Diagnosis.RecommendedActions -and $Diagnosis.RecommendedActions.Count -gt 0) {
        $lines += ""
        $lines += "Recommended Actions:"
        foreach ($action in $Diagnosis.RecommendedActions) {
            $lines += " - $action"
        }
    }

    if ($Diagnosis.Evidence -and $Diagnosis.Evidence.RecentAlerts) {
        $lines += ""
        $lines += "Recent Alerts (latest 5):"
        foreach ($row in $Diagnosis.Evidence.RecentAlerts) {
            $lines += "  [$($row.AlertTime)] $($row.Severity) / $($row.ModuleName) - $($row.AlertTitle)"
        }
    }

    return ($lines -join "`r`n")
}

function Get-WebAgentKeyTerms {
    <#
    .SYNOPSIS
        Generates enhanced search queries based on recognized alert patterns.
    .DESCRIPTION
        Maps specific SQL Server alerts to better search queries that focus on
        the root cause rather than generic symptom matching.
    #>
    param(
        [string]$AlertTitle,
        [string]$ErrorMessage,
        [int]$ErrorNumber
    )

    $queries = @()
    $combinedText = @($AlertTitle, $ErrorMessage) -join ' ' | ForEach-Object { ($_ -replace '\s+', ' ').Trim() }
    $lowerText = $combinedText.ToLowerInvariant()

    # Alert pattern mappings to better search keywords
    if ($lowerText -match 'page life expectancy|ple') {
        $queries += @(
            'SQL Server page life expectancy buffer pool memory',
            'SQL Server buffer pool hit ratio optimization',
            'SQL Server memory pressure PLE tuning',
            'SQL Server memory grant waits memory optimization',
            'page life expectancy low memory query optimization'
        )
    }

    if ($lowerText -match 'available physical memory|low memory' -and $lowerText -notmatch 'page life') {
        $queries += @(
            'SQL Server memory pressure insufficient memory',
            'SQL Server external memory pressure optimization',
            'SQL Server buffer pool memory grant tuning',
            'SQL Server out of memory troubleshooting',
            'SQL Server memory leak diagnostic'
        )
    }

    if ($lowerText -match 'blocking|blocked|wait') {
        $queries += @(
            'SQL Server blocked process troubleshooting',
            'SQL Server deadlock detection resolution',
            'SQL Server lock timeout optimization',
            'SQL Server blocking chain investigation'
        )
    }

    if ($lowerText -match 'cpu|processor' -and $lowerText -notmatch 'block') {
        $queries += @(
            'SQL Server high CPU usage troubleshooting',
            'SQL Server query optimization CPU',
            'SQL Server missing index CPU impact',
            'SQL Server excessive CPU load balancing'
        )
    }

    if ($lowerText -match 'disk|io|read|write|latency' -and $lowerText -notmatch 'block') {
        $queries += @(
            'SQL Server disk IO performance optimization',
            'SQL Server high latency slow queries',
            'SQL Server storage performance tuning',
            'SQL Server IO bottleneck diagnosis'
        )
    }

    if ($lowerText -match 'tempdb') {
        $queries += @(
            'SQL Server tempdb contention resolution',
            'SQL Server tempdb performance tuning',
            'SQL Server tempdb allocation errors',
            'SQL Server internal object tempdb optimization'
        )
    }

    if ($lowerText -match 'fragmentation|fragment') {
        $queries += @(
            'SQL Server index fragmentation defragmentation',
            'SQL Server page fragmentation impact',
            'SQL Server rebuild reorganize indexes'
        )
    }

    if ($lowerText -match 'growth|expand' -and $lowerText -notmatch 'block') {
        $queries += @(
            'SQL Server database file autogrowth settings',
            'SQL Server log file growth performance',
            'SQL Server instant file initialization'
        )
    }

    if ($lowerText -match 'transaction log|log file' -and $lowerText -notmatch 'growth') {
        $queries += @(
            'SQL Server transaction log full troubleshooting',
            'SQL Server log backup strategy recovery model',
            'SQL Server log file cleanup maintenance'
        )
    }

    if ($lowerText -match 'backup|restore' -and $lowerText -notmatch 'log file') {
        $queries += @(
            'SQL Server backup strategy maintenance',
            'SQL Server backup compression performance',
            'SQL Server restore time optimization'
        )
    }

    return $queries
}

function Get-WebAgentSearchContext {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ErrorMessage,

        [Parameter(Mandatory = $false)]
        [string]$AlertTitle,

        [object]$Instance
    )

    $normalized = ($ErrorMessage -replace '\s+', ' ').Trim()
    $normalizedAlert = if ([string]::IsNullOrWhiteSpace($AlertTitle)) { '' } else { ($AlertTitle -replace '\s+', ' ').Trim() }
    $errorNumber = $null
    $severity = $null
    $state = $null

    # Enhanced error number patterns to catch more formats
    $patterns = @(
        '(?i)(?:^|[^\d])(?<ErrorNumber>\d{4,6})(?:[^\d]|$)',  # Standalone number like "4004"
        '(?i)\bMSSQLSERVER[_\s-]?(?<ErrorNumber>\d{4,6})\b',
        '(?i)\b(?:SQL\s*Server\s*)?Error(?:\s*Number)?[\s:#-]*(?<ErrorNumber>\d{4,6})\b',
        '(?i)\bMsg\s+(?<ErrorNumber>\d{4,6})(?:,\s*Level\s+(?<Severity>\d+))?(?:,\s*State\s+(?<State>\d+))?',
        '(?i)\[(?<ErrorNumber>\d{4,6})\]',  # Error in brackets like [4004]
        '(?i)Error[\s_-]*\[?(?<ErrorNumber>\d{4,6})\]?'  # Various Error formats
    )

    foreach ($pattern in $patterns) {
        $match = [regex]::Match($normalized, $pattern)
        if ($match.Success) {
            if ($match.Groups['ErrorNumber'].Success) {
                $potentialNumber = [int]$match.Groups['ErrorNumber'].Value
                # Validate SQL Server error number range (typically 50000-53999 or lower)
                if ($potentialNumber -ge 1 -and $potentialNumber -le 99999) {
                    $errorNumber = $potentialNumber
                }
            }
            if ($match.Groups['Severity'].Success) {
                $severity = $match.Groups['Severity'].Value
            }
            if ($match.Groups['State'].Success) {
                $state = $match.Groups['State'].Value
            }
            if ($errorNumber) { break }
        }
    }

    # Also try to extract error number from alert title
    if (-not $errorNumber -and -not [string]::IsNullOrWhiteSpace($normalizedAlert)) {
        foreach ($pattern in $patterns) {
            $match = [regex]::Match($normalizedAlert, $pattern)
            if ($match.Success -and $match.Groups['ErrorNumber'].Success) {
                $potentialNumber = [int]$match.Groups['ErrorNumber'].Value
                if ($potentialNumber -ge 1 -and $potentialNumber -le 99999) {
                    $errorNumber = $potentialNumber
                    break
                }
            }
        }
    }

    $cleanMessage = $normalized
    if ($errorNumber) {
        # Remove the error number from the clean message for better search results
        $cleanMessage = $cleanMessage -replace "(?i)(?:^|[^\d])$errorNumber(?:[^\d]|$)", ' '
        $cleanMessage = $cleanMessage -replace "(?i)\bMSSQLSERVER[_\s-]?$errorNumber\b", ''
        $cleanMessage = $cleanMessage -replace "(?i)\b(?:SQL\s*Server\s*)?Error(?:\s*Number)?[\s:#-]*$errorNumber\b", ''
        $cleanMessage = $cleanMessage -replace "(?i)\bMsg\s+$errorNumber(?:,\s*Level\s+\d+)?(?:,\s*State\s+\d+)?", ''
        $cleanMessage = $cleanMessage -replace "(?i)\[$errorNumber\]", ''
        $cleanMessage = ($cleanMessage -replace '\s+', ' ').Trim(' ', '-', ':', ';', ',')
    }

    if ([string]::IsNullOrWhiteSpace($cleanMessage)) {
        $cleanMessage = $normalized
    }

    $queryCandidates = @()
    
    # Generate priority queries
    if ($errorNumber) {
        # Error number has highest priority
        $queryCandidates += "SQL Server error $errorNumber"
        $queryCandidates += "MSSQLSERVER $errorNumber $cleanMessage"
        $queryCandidates += "SQL Server $errorNumber $cleanMessage"
    }
    
    # Get enhanced queries based on recognized alert patterns - these are more specific
    $enhancedQueries = @(Get-WebAgentEnhancedQueries -AlertTitle $normalizedAlert -ErrorMessage $ErrorMessage -ErrorNumber $errorNumber)
    if ($enhancedQueries.Count -gt 0) {
        # Add enhanced queries at the start for higher priority
        $queryCandidates = @($enhancedQueries) + $queryCandidates
    }
    
    # Add alert-based queries if available and no enhanced queries matched
    if (-not [string]::IsNullOrWhiteSpace($normalizedAlert) -and $enhancedQueries.Count -eq 0) {
        $queryCandidates += "$normalizedAlert SQL Server"
        if ($errorNumber) {
            $queryCandidates += "$normalizedAlert SQL Server error $errorNumber"
        }
        $queryCandidates += "$normalizedAlert troubleshoot"
    }
    
    # Add the clean message queries
    if (-not [string]::IsNullOrWhiteSpace($cleanMessage) -and $cleanMessage -ne $normalized) {
        $queryCandidates += "$cleanMessage SQL Server"
        if ($errorNumber) {
            $queryCandidates += "$cleanMessage error $errorNumber"
        }
    }
    
    $queryCandidates += $normalized

    $queries = @(
        $queryCandidates |
            ForEach-Object { ($_ -replace '\s+', ' ').Trim() } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
            Select-Object -Unique
    )

    $matchedTerms = @()
    if ($errorNumber) { $matchedTerms += "Error $errorNumber" }
    if ($severity) { $matchedTerms += "Severity $severity" }
    if ($state) { $matchedTerms += "State $state" }
    if (-not [string]::IsNullOrWhiteSpace($normalizedAlert)) { $matchedTerms += "Alert: $normalizedAlert" }
    $matchedTerms += Get-WebAgentKeyTerms -Text $cleanMessage

    return [PSCustomObject]@{
        OriginalMessage    = $ErrorMessage
        NormalizedMessage  = $normalized
        CleanMessage       = $cleanMessage
        AlertTitle         = $normalizedAlert
        ErrorNumber        = $errorNumber
        Severity           = $severity
        State              = $state
        Queries            = $queries
        MatchedTerms       = @($matchedTerms | Where-Object { $_ } | Select-Object -Unique)
        InstanceName       = if ($Instance -and $Instance.DisplayName) { [string]$Instance.DisplayName } else { $null }
        SqlInstance        = if ($Instance -and $Instance.SqlInstance) { [string]$Instance.SqlInstance } else { $null }
    }
}

function Get-WebAgentKeyTerms {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Text
    )

    $stopWords = @(
        'the', 'and', 'for', 'with', 'that', 'this', 'from', 'into', 'your', 'when',
        'while', 'sql', 'server', 'error', 'message', 'occurred', 'failed'
    )

    return @(
        ($Text -split '[^A-Za-z0-9_]+') |
            Where-Object {
                $_.Length -ge 4 -and $stopWords -notcontains $_.ToLowerInvariant()
            } |
            Select-Object -First 6
    )
}

function Test-IsRelevantSQLServerResult {
    <#
    .SYNOPSIS
        Tests if a search result is actually relevant to SQL Server troubleshooting.
    .DESCRIPTION
        Filters out false positives that mention generic terms but aren't SQL Server-specific.
    #>
    param(
        [string]$Title,
        [string]$Url,
        [string]$Summary,
        [string]$Query
    )

    $allText = @($Title, $Url, $Summary, $Query) -join ' ' | ForEach-Object { $_.ToLowerInvariant() }
    
    # Check for SQL Server-specific keywords
    $sqlKeywords = @(
        'sql server', 'mssql', 'tsql', 't-sql', 'database engine',
        'buffer pool', 'memory pressure', 'page life expectancy', 'ple', 'buffer pool hit ratio',
        'memory optimization', 'query optimization', 'index',
        'tempdb', 'transaction log', 'backups', 'restore', 'replication',
        'always on', 'availability group', 'failover', 'cluster', 'deadlock',
        'trace flag', 'extended events', 'profiler', 'execution plan',
        'statistics', 'cardinality', 'histogram'
    )

    # Exclude generic/irrelevant content patterns
    $excludePatterns = @(
        'power automate',        # Browser automation
        'date and time functions', # Unrelated T-SQL functions
        'entra id|identity protection|risk detection', # Azure AD, not SQL Server
        'azure devops',          # Not SQL Server troubleshooting
        'sharepoint',            # Collaboration tool, not SQL Server
        'browser automation',    # WebDriver automation
        'free tier|free offer',  # Azure pricing
        'javascript|node.js|react|angular' # Web development, not SQL Server
    )

    # Check for exclusion patterns
    foreach ($pattern in $excludePatterns) {
        if ($allText -match $pattern) {
            return $false
        }
    }

    # Check for SQL Server keywords
    foreach ($keyword in $sqlKeywords) {
        if ($allText -match [regex]::Escape($keyword)) {
            return $true
        }
    }

    # If contains "SQL Server" in title or URL, likely relevant
    if ($Title -match 'sql\s*server' -or $Url -match 'sql') {
        return $true
    }

    return $false
}

function Search-MicrosoftLearnSqlErrorReference {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Context
    )

    $results = @()
    if (-not $Context.ErrorNumber) {
        return $results
    }

    $url = "https://learn.microsoft.com/en-us/sql/relational-databases/errors-events/mssqlserver-$($Context.ErrorNumber)-database-engine-error?view=sql-server-ver17"

    try {
        $response = Invoke-WebAgentTextRequest -Uri $url -TimeoutSec 30
        if ([string]::IsNullOrWhiteSpace($response.Content)) {
            return $results
        }

        $title = Get-WebAgentHtmlTitle -Html $response.Content
        if ($title -notmatch [string]$Context.ErrorNumber) {
            return $results
        }

        $summary = Get-WebAgentSectionText -Html $response.Content -Heading 'Explanation'
        if ([string]::IsNullOrWhiteSpace($summary)) {
            $summary = Get-WebAgentMetaDescription -Html $response.Content
        }

        $userAction = Get-WebAgentSectionText -Html $response.Content -Heading 'User action'
        $actions = Get-WebAgentActionItems -Text $userAction

        $results += (New-WebSolutionResult -Source 'Microsoft Learn' `
            -Title $title `
            -Url $url `
            -Type 'Official Error Reference' `
            -Confidence 98 `
            -Context $Context `
            -Summary $summary `
            -Snippet (Get-WebAgentFirstLine -Text $summary) `
            -RecommendedActions $actions `
            -AdditionalProperties @{
                QueryUsed = "SQL Server error $($Context.ErrorNumber)"
            })
    }
    catch {
        Write-MonitorLog "WARNING failed to query Microsoft Learn error reference for $($Context.ErrorNumber): $($_.Exception.Message)" -Level 'Warning'
    }

    return $results
}

function Search-MicrosoftLearnContent {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Context,

        [int]$MaxResults = 3
    )

    $results = @()
    $queryCount = [Math]::Min($Context.Queries.Count, 4)

    foreach ($query in $Context.Queries | Select-Object -First $queryCount) {
        $encodedQuery = [System.Uri]::EscapeDataString($query)
        $endpoints = @(
            "https://learn.microsoft.com/api/search?search=$encodedQuery&locale=en-us&`$top=$MaxResults",
            "https://docs.microsoft.com/api/search?search=$encodedQuery&locale=en-us&`$top=$MaxResults"
        )

        $payload = $null
        foreach ($endpoint in $endpoints) {
            try {
                Write-MonitorLog "Searching Microsoft Learn content: $endpoint"
                $response = Invoke-WebAgentJsonRequest -Uri $endpoint -TimeoutSec 30
                if ($response) {
                    $payload = $response
                    break
                }
            }
            catch {
                Write-MonitorLog "WARNING Microsoft Learn search attempt failed for '$query': $($_.Exception.Message)" -Level 'Warning'
            }
        }

        if ($null -eq $payload) {
            continue
        }

        $searchResults = @()
        if ($payload.results) {
            $searchResults = @($payload.results)
        }
        elseif ($payload.value) {
            $searchResults = @($payload.value)
        }

        foreach ($item in $searchResults | Select-Object -First $MaxResults) {
            if (-not $item.url) { continue }

            $title = [string]$item.title
            if ([string]::IsNullOrWhiteSpace($title)) {
                $title = [string]$item.url
            }

            $summary = @($item.description, $item.searchSnippet, $item.excerpt) |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
                Select-Object -First 1

            # Filter out irrelevant results
            if (-not (Test-IsRelevantSQLServerResult -Title $title -Url ([string]$item.url) -Summary $summary -Query $query)) {
                continue
            }

            $confidence = 70
            if ($Context.ErrorNumber -and $title -match [regex]::Escape([string]$Context.ErrorNumber)) {
                $confidence += 15
            }
            # Boost confidence if alert title matches the content
            if (-not [string]::IsNullOrWhiteSpace($Context.AlertTitle)) {
                if ($title -match [regex]::Escape($Context.AlertTitle)) {
                    $confidence += 20
                }
                elseif ($title -match $Context.AlertTitle) {
                    $confidence += 12
                }
            }
            if ($item.url -match '/sql/' -or $item.url -match '/troubleshoot/sql/') {
                $confidence += 10
            }
            # Boost confidence for SQL Server-specific keywords
            if ($title -match 'buffer pool|memory optimization|query optimization|execution plan|index' -or
                $summary -match 'buffer pool|memory optimization|query optimization|execution plan') {
                $confidence += 8
            }

            $results += (New-WebSolutionResult -Source 'Microsoft Learn' `
                -Title $title `
                -Url ([string]$item.url) `
                -Type 'Documentation' `
                -Confidence $confidence `
                -Context $Context `
                -Summary $summary `
                -Snippet (Get-WebAgentFirstLine -Text $summary) `
                -RecommendedActions @() `
                -AdditionalProperties @{
                    QueryUsed = $query
                    Breadcrumb = [string]$item.breadcrumb
                })
        }
    }

    return $results
}

function Search-StackOverflowExcerpts {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Context,

        [int]$MaxResults = 5
    )

    $results = @()
    $queries = $Context.Queries | Select-Object -First 2
    if (-not $queries -or $queries.Count -eq 0) {
        return $results
    }

    foreach ($query in $queries) {
        if ([string]::IsNullOrWhiteSpace($query)) {
            continue
        }

        try {
            $encodedQuery = [System.Uri]::EscapeDataString($query)
            $uri = "https://api.stackexchange.com/2.3/search/excerpts?order=desc&sort=relevance&site=stackoverflow&tagged=sql-server&q=$encodedQuery&pagesize=$MaxResults"

            Write-MonitorLog "Searching Stack Overflow excerpts: $uri"
            $payload = Invoke-WebAgentJsonRequest -Uri $uri -TimeoutSec 30
        }
        catch {
            Write-MonitorLog "WARNING failed to query Stack Overflow API for '$query': $($_.Exception.Message)" -Level 'Warning'
            continue
        }

        if ($null -eq $payload -or $null -eq $payload.items) {
            continue
        }

        foreach ($item in @($payload.items) | Where-Object { $_.item_type -eq 'question' } | Select-Object -First $MaxResults) {
            $questionId = [string]$item.question_id
            if ([string]::IsNullOrWhiteSpace($questionId)) { continue }

            $title = ConvertFrom-WebAgentHtmlFragment -Html ([string]$item.title)
            $body = ConvertFrom-WebAgentHtmlFragment -Html ([string]$item.body)
            $excerpt = ConvertFrom-WebAgentHtmlFragment -Html ([string]$item.excerpt)
            $snippet = if (-not [string]::IsNullOrWhiteSpace($excerpt)) { $excerpt } else { Get-WebAgentFirstLine -Text $body }

            # Filter out irrelevant results
            if (-not (Test-IsRelevantSQLServerResult -Title $title -Url "https://stackoverflow.com/questions/$questionId" -Summary $body -Query $query)) {
                continue
            }

            $url = "https://stackoverflow.com/questions/$questionId"
            $confidence = 58
            if ($item.has_accepted_answer) { $confidence += 14 }
            if ($item.answer_count -ge 2) { $confidence += 6 }
            if ($item.question_score -ge 3) { $confidence += 6 }
            if ($Context.ErrorNumber -and $title -match [regex]::Escape([string]$Context.ErrorNumber)) { $confidence += 8 }
            # Boost confidence if alert title matches the question
            if (-not [string]::IsNullOrWhiteSpace($Context.AlertTitle)) {
                if ($title -match [regex]::Escape($Context.AlertTitle)) {
                    $confidence += 16
                }
                elseif ($title -match $Context.AlertTitle) {
                    $confidence += 8
                }
            }
            # Boost for SQL Server-specific keywords
            if ($title -match 'buffer pool|memory optimization|query optimization|execution plan|index' -or
                $body -match 'buffer pool|memory optimization|query optimization|execution plan') {
                $confidence += 6
            }

            $results += (New-WebSolutionResult -Source 'Stack Overflow' `
                -Title $title `
                -Url $url `
                -Type 'Community Solution' `
                -Confidence $confidence `
                -Context $Context `
                -Summary $body `
                -Snippet $snippet `
                -RecommendedActions @() `
                -AdditionalProperties @{
                    QueryUsed = $query
                    AnswerCount = [int]$item.answer_count
                    HasAcceptedAnswer = [bool]$item.has_accepted_answer
                    Score = [int]$item.question_score
                    Tags = @($item.tags)
                })
        }
    }

    return $results
}

function Merge-WebAgentResults {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Results,

        [Parameter(Mandatory = $true)]
        [object]$Context
    )

    $merged = @()
    $groups = $Results |
        Where-Object { $_ -and -not [string]::IsNullOrWhiteSpace($_.Url) } |
        Group-Object Url

    foreach ($group in $groups) {
        $best = $group.Group | Sort-Object Confidence -Descending | Select-Object -First 1
        $best.Relevance = Get-WebAgentRelevanceLabel -Confidence $best.Confidence
        $merged += $best
    }

    return @(
        $merged |
            Sort-Object @{ Expression = 'Confidence'; Descending = $true }, @{ Expression = 'Source'; Descending = $false }, @{ Expression = 'Title'; Descending = $false }
    )
}

function New-WebSolutionResult {
    param(
        [string]$Source,
        [string]$Title,
        [string]$Url,
        [string]$Type,
        [int]$Confidence,
        [object]$Context,
        [string]$Summary,
        [string]$Snippet,
        [object[]]$RecommendedActions = @(),
        [hashtable]$AdditionalProperties = @{}
    )

    $matchedTerms = @($Context.MatchedTerms)
    $properties = [ordered]@{
        Source                 = $Source
        Title                  = $Title
        Url                    = $Url
        Type                   = $Type
        Relevance              = Get-WebAgentRelevanceLabel -Confidence $Confidence
        Confidence             = $Confidence
        ErrorNumber            = if ($Context.ErrorNumber) { [string]$Context.ErrorNumber } else { '' }
        Severity               = if ($Context.Severity) { [string]$Context.Severity } else { '' }
        State                  = if ($Context.State) { [string]$Context.State } else { '' }
        Query                  = if ($AdditionalProperties.ContainsKey('QueryUsed')) { [string]$AdditionalProperties['QueryUsed'] } else { $Context.NormalizedMessage }
        InstanceName           = if ($Context.InstanceName) { $Context.InstanceName } else { '' }
        MatchedTerms           = ($matchedTerms -join ', ')
        Snippet                = $Snippet
        Summary                = $Summary
        RecommendedActions     = @($RecommendedActions)
        RecommendedActionsText = (@($RecommendedActions) -join [Environment]::NewLine)
        RetrievedAt            = Get-Date
    }

    foreach ($key in $AdditionalProperties.Keys) {
        if (-not $properties.Contains($key)) {
            $properties[$key] = $AdditionalProperties[$key]
        }
    }

    return [PSCustomObject]$properties
}

function Get-WebAgentRelevanceLabel {
    param(
        [int]$Confidence
    )

    if ($Confidence -ge 90) { return 'Very High' }
    if ($Confidence -ge 75) { return 'High' }
    if ($Confidence -ge 60) { return 'Medium' }
    return 'Low'
}

function Get-WebAgentHtmlTitle {
    param([string]$Html)

    $match = [regex]::Match($Html, '(?is)<title[^>]*>(?<value>.*?)</title>')
    if (-not $match.Success) {
        return ''
    }

    return (ConvertFrom-WebAgentHtmlFragment -Html $match.Groups['value'].Value)
}

function Get-WebAgentMetaDescription {
    param([string]$Html)

    $match = [regex]::Match($Html, '(?is)<meta[^>]+name=["'']description["''][^>]+content=["''](?<value>.*?)["'']')
    if (-not $match.Success) {
        return ''
    }

    return (ConvertFrom-WebAgentHtmlFragment -Html $match.Groups['value'].Value)
}

function Get-WebAgentSectionText {
    param(
        [string]$Html,
        [string]$Heading
    )

    $pattern = '(?is)<h[1-6][^>]*>\s*' + [regex]::Escape($Heading) + '\s*</h[1-6]>\s*(?<body>.*?)(?=<h[1-6][^>]*>|</article>|</main>|$)'
    $match = [regex]::Match($Html, $pattern)
    if (-not $match.Success) {
        return ''
    }

    return (ConvertFrom-WebAgentHtmlFragment -Html $match.Groups['body'].Value)
}

function Get-WebAgentActionItems {
    param(
        [string]$Text
    )

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return @()
    }

    $lines = @(
        $Text -split "(`r`n|`n|`r)" |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ -and $_.Length -ge 12 }
    )

    return @($lines | Select-Object -First 6)
}

function Get-WebAgentFirstLine {
    param(
        [string]$Text
    )

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ''
    }

    $normalized = ($Text -replace '\s+', ' ').Trim()
    if ($normalized.Length -le 240) {
        return $normalized
    }

    return $normalized.Substring(0, 237) + '...'
}

function ConvertFrom-WebAgentHtmlFragment {
    param(
        [AllowEmptyString()]
        [string]$Html
    )

    if ([string]::IsNullOrWhiteSpace($Html)) {
        return ''
    }

    $text = [regex]::Replace($Html, '(?is)<script.*?</script>', ' ')
    $text = [regex]::Replace($text, '(?is)<style.*?</style>', ' ')
    $text = [regex]::Replace($text, '(?is)<br\s*/?>', [Environment]::NewLine)
    $text = [regex]::Replace($text, '(?is)</p>', [Environment]::NewLine)
    $text = [regex]::Replace($text, '(?is)<[^>]+>', ' ')
    $text = [System.Net.WebUtility]::HtmlDecode($text)
    $text = $text -replace '[\u00A0]', ' '
    $text = $text -replace '\s+', ' '
    return $text.Trim()
}

function Invoke-WebAgentJsonRequest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [int]$TimeoutSec = 30
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $headers = @{
        'User-Agent' = $script:WebAgentUserAgent
        'Accept'     = 'application/json,text/json,*/*'
    }

    $response = Invoke-WebRequest -Uri $Uri -Headers $headers -UseBasicParsing -TimeoutSec $TimeoutSec
    if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
        throw "Unexpected HTTP status $($response.StatusCode) from $Uri"
    }

    if ([string]::IsNullOrWhiteSpace($response.Content)) {
        return $null
    }

    return ($response.Content | ConvertFrom-Json)
}

function Invoke-WebAgentTextRequest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [int]$TimeoutSec = 30
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $headers = @{
        'User-Agent' = $script:WebAgentUserAgent
        'Accept'     = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }

    $response = Invoke-WebRequest -Uri $Uri -Headers $headers -UseBasicParsing -TimeoutSec $TimeoutSec
    if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
        throw "Unexpected HTTP status $($response.StatusCode) from $Uri"
    }

    return $response
}

function Get-SQLServerErrorSolutions {
    <#
    .SYNOPSIS
        Gets structured solutions for SQL Server errors from trusted web sources.
    #>
    param(
        [Parameter(Mandatory = $false)]
        [int]$ErrorNumber,

        [Parameter(Mandatory = $true)]
        [string]$ErrorMessage,

        [Parameter(Mandatory = $false)]
        [string]$AlertTitle
    )

    $searchQuery = $ErrorMessage
    if ($ErrorNumber) {
        $searchQuery = "SQL Server Error $ErrorNumber $ErrorMessage"
    }

    return Invoke-WebSolutionsAgent -ErrorMessage $searchQuery -AlertTitle $AlertTitle
}

# Export functions
Export-ModuleMember -Function Invoke-WebSolutionsAgent, Invoke-WebDiagnosticAssistant, Format-WebAgentDiagnosisResult, Get-SQLServerErrorSolutions
