function Invoke-TempDBCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "TempDB"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "tempdb collector started for $($Instance.DisplayName)"

        $query = @"
        SELECT 
            type_desc as FileType,
            name as LogicalName,
            physical_name as PhysicalName,
            CAST(size * 8 / 1024.0 as decimal(10,2)) as SizeMB,
            CAST(FILEPROPERTY(name, 'SpaceUsed') * 8 / 1024.0 as decimal(10,2)) as UsedMB,
            CAST((CAST(FILEPROPERTY(name, 'SpaceUsed') * 8 / 1024.0 as decimal(10,2)) / NULLIF(CAST(size * 8 / 1024.0 as decimal(10,2)), 0)) * 100 as decimal(5,2)) as PercentFull
        FROM tempdb.sys.database_files
"@

        $tempdbData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "tempdb" -Query $query
        
        # Get CPU count for recommendations
        $cpuCountQuery = "SELECT cpu_count FROM sys.dm_os_sys_info"
        $cpuResult = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $cpuCountQuery
        $cpuCount = if ($cpuResult.Rows.Count -gt 0) { $cpuResult.Rows[0]['cpu_count'] } else { 4 }
        $recommendedFiles = if ($cpuCount -le 8) { $cpuCount } else { 8 }

        if ($tempdbData.Rows.Count -gt 0) {
            # Count data files
            $dataFileCount = ($tempdbData.Rows | Where-Object { $_['FileType'].ToString() -eq 'ROWS' }).Count

            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add("InstanceID", [int])
            [void]$targetTable.Columns.Add("CaptureTime", [datetime])
            [void]$targetTable.Columns.Add("FileType", [string])
            [void]$targetTable.Columns.Add("LogicalName", [string])
            [void]$targetTable.Columns.Add("PhysicalName", [string])
            [void]$targetTable.Columns.Add("SizeMB", [decimal])
            [void]$targetTable.Columns.Add("UsedMB", [decimal])
            [void]$targetTable.Columns.Add("PercentFull", [decimal])
            [void]$targetTable.Columns.Add("TempDBDataFileCount", [int])
            [void]$targetTable.Columns.Add("RecommendedFileCount", [int])

            $captureTime = [datetime]::Now

            foreach ($file in $tempdbData.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow["InstanceID"] = $instanceId
                $newRow["CaptureTime"] = $captureTime
                $newRow["FileType"] = $file["FileType"]
                $newRow["LogicalName"] = $file["LogicalName"]
                $newRow["PhysicalName"] = $file["PhysicalName"]
                $newRow["SizeMB"] = $file["SizeMB"]
                $newRow["UsedMB"] = $file["UsedMB"]
                $newRow["PercentFull"] = $file["PercentFull"]
                $newRow["TempDBDataFileCount"] = $dataFileCount
                $newRow["RecommendedFileCount"] = $recommendedFiles
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.TempDBHistory" `
                -DataTable $targetTable

            Write-MonitorLog "tempdb collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-TempDBCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-TempDBCollector
