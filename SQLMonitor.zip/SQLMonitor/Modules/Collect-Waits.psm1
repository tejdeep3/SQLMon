function Invoke-WaitsCollector {
    param (
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$Instance
    )

    $moduleName = "Waits"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    $query = @"
SELECT
    wait_type,
    waiting_tasks_count,
    wait_time_ms,
    max_wait_time_ms,
    signal_wait_time_ms
FROM sys.dm_os_wait_stats
WHERE wait_type NOT IN (
    'BROKER_EVENTHANDLER', 'BROKER_RECEIVE_WAITFOR',
    'BROKER_TASK_STOP', 'BROKER_TO_FLUSH', 'BROKER_TRANSMITTER',
    'CHECKPOINT_QUEUE', 'CHKPT', 'CLR_AUTO_EVENT', 'CLR_MANUAL_EVENT',
    'CLR_SEMAPHORE', 'DBMIRROR_DBM_EVENT', 'DBMIRROR_EVENTS_QUEUE',
    'DBMIRROR_WORKER_QUEUE', 'DBMIRRORING_CMD', 'DIRTY_PAGE_POLL',
    'DISPATCHER_QUEUE_SEMAPHORE', 'EXECSYNC', 'FSAGENT', 'FT_IFTS_SCHEDULER_IDLE_WAIT',
    'FT_IFTSHC_MUTEX', 'HADR_CLUSAPI_CALL', 'HADR_FILESTREAM_IOMGR_IOCOMPLETION',
    'HADR_LOGCAPTURE_WAIT', 'HADR_NOTIFICATION_DEQUEUE', 'HADR_TIMER_TASK',
    'HADR_WORK_QUEUE', 'KSOURCE_WAKEUP', 'LAZYWRITER_SLEEP', 'LOGMGR_QUEUE',
    'MEMORY_ALLOCATION_EXT', 'ONDEMAND_TASK_QUEUE', 'PWAIT_ALL_COMPONENTS_INITIALIZED',
    'PWAIT_DIRECTLOGCONSUMER_GETNEXT', 'PWAIT_EXTENSIBILITY_CLEANUP_TASK',
    'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP', 'QDS_ASYNC_QUEUE', 'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
    'QDS_SHUTDOWN_QUEUE', 'REDO_THREAD_PENDING_WORK', 'REQUEST_FOR_DEADLOCK_SEARCH',
    'RESOURCE_QUEUE', 'SERVER_IDLE_CHECK', 'SLEEP_BPOOL_FLUSH', 'SLEEP_DBSTARTUP',
    'SLEEP_DCOMSTART', 'SLEEP_MASTERDBREADY', 'SLEEP_MASTERMDREADY', 'SLEEP_MASTERUPGRADED',
    'SLEEP_MSDBSTART', 'SLEEP_SYSTEMTASK', 'SLEEP_TASK', 'SLEEP_TEMPDBSTART',
    'SP_SERVER_DIAGNOSTICS_SLEEP', 'SQLTRACE_BUFFER_FLUSH', 'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
    'SQLTRACE_WAIT_ENTRIES', 'WAIT_FOR_RESULTS', 'WAITFOR', 'WAITFOR_TASKSHUTDOWN',
    'WAIT_XTP_HOST_WAIT', 'WAIT_XTP_OFFLINE_CKPT_NEW_LOG', 'WAIT_XTP_CKPT_CLOSE',
    'XE_BUFFERMGR_ALLPROCESSED_EVENT', 'XE_DISPATCHER_JOIN', 'XE_DISPATCHER_WAIT',
    'XE_LIVE_TARGET_TVF', 'XE_TIMER_EVENT'
)
AND waiting_tasks_count > 0
ORDER BY wait_time_ms DESC
"@

    try {
        Write-MonitorLog "Waits collector started for $($Instance.DisplayName)"
        
        $waitsData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($waitsData.Rows.Count -gt 0) {
            # Note: Phase 7 schema uses dbo.WaitStats or mon.WaitStats? 
            # In Sql/07_Complete_Schema.sql line 275 it refers to dbo.WaitStats
            
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add("InstanceID", [int])
            [void]$targetTable.Columns.Add("CollectionDateTime", [System.DateTime])
            [void]$targetTable.Columns.Add("WaitType", [string])
            [void]$targetTable.Columns.Add("WaitingTasksCount", [long])
            [void]$targetTable.Columns.Add("WaitTimeMs", [long])
            [void]$targetTable.Columns.Add("MaxWaitTimeMs", [long])
            [void]$targetTable.Columns.Add("SignalWaitTimeMs", [long])

            $captureTime = Get-Date

            foreach ($wait in $waitsData.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow["InstanceID"] = $instanceId
                $newRow["CollectionDateTime"] = [System.DateTime]$captureTime
                $newRow["WaitType"] = $wait["wait_type"]
                $newRow["WaitingTasksCount"] = $wait["waiting_tasks_count"]
                $newRow["WaitTimeMs"] = $wait["wait_time_ms"]
                $newRow["MaxWaitTimeMs"] = $wait["max_wait_time_ms"]
                $newRow["SignalWaitTimeMs"] = $wait["signal_wait_time_ms"]
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "dbo.WaitStats" `
                -DataTable $targetTable

            Write-MonitorLog "Waits collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-WaitsCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-WaitsCollector
