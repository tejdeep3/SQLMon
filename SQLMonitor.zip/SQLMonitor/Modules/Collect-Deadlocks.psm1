function Invoke-DeadlocksCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "Deadlocks"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        $query = @"
BEGIN TRY
    ;WITH se AS
    (
        SELECT CAST(t.target_data AS XML) AS x
        FROM sys.dm_xe_session_targets t
        INNER JOIN sys.dm_xe_sessions s
            ON s.address = t.event_session_address
        WHERE s.name = 'system_health'
          AND t.target_name = 'ring_buffer'
    )
    SELECT
        SYSDATETIME() AS CaptureTime,
        XEvent.value('(event/@timestamp)[1]', 'datetime2(0)') AS DeadlockTime,
        CONVERT(NVARCHAR(MAX), XEvent.query('.')) AS DeadlockXml
    FROM se
    CROSS APPLY x.nodes('//RingBufferTarget/event[@name="xml_deadlock_report"]') AS T(XEvent)
    ORDER BY DeadlockTime DESC;
END TRY
BEGIN CATCH
    SELECT
        SYSDATETIME() AS CaptureTime,
        CAST(NULL AS datetime2(0)) AS DeadlockTime,
        CAST(NULL AS nvarchar(max)) AS DeadlockXml
    WHERE 1 = 0;
END CATCH;
"@

    $sourceRows = $null
    try {
        $sourceRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $query `
            -CommandTimeout 180
    }
    catch {
        Write-MonitorLog "Deadlocks collector query failed for $($Instance.DisplayName): $($_.Exception.Message)" -Level 'Error'
        throw
    }

    if ($null -eq $sourceRows -or $null -eq $sourceRows.Rows) {
        Write-MonitorLog "Deadlocks collector returned no result set for $($Instance.DisplayName)" -Level 'Warning'
            Stop-CollectionRun `
                -RepositoryServer $Instance.RepositoryServer `
                -RepositoryDatabase $Instance.RepositoryDatabase `
                -RunID $runId `
                -Status "Success"
            return
        }

        $targetTable = New-DeadlockHistoryTable
        if ($null -eq $targetTable) { throw "Failed to initialize DeadlockHistoryTable." }

        foreach ($row in $sourceRows.Rows) {
            $newRow = $targetTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime]$row["CaptureTime"]
            $newRow["DeadlockTime"] = if ($row["DeadlockTime"] -is [DBNull]) { [DBNull]::Value } else { [datetime]$row["DeadlockTime"] }
            $newRow["DeadlockXml"] = if ($row["DeadlockXml"] -is [DBNull]) { [DBNull]::Value } else { [string]$row["DeadlockXml"] }
            $targetTable.Rows.Add($newRow)
        }

        if ($targetTable.Rows.Count -gt 0) {
            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.DeadlockHistory" `
                -DataTable $targetTable
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-DeadlocksCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-DeadlocksCollector
