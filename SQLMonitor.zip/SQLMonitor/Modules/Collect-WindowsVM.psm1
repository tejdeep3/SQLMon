function Get-WindowsTargetRows {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase
    )

    $query = @"
SELECT t.TargetID, t.ComputerName, t.DisplayName, t.EnvironmentName, t.ApplicationName, t.SiteName
    , CollectionMode, CollectionIntervalMinutes
    , (
        SELECT MAX(CaptureTime)
        FROM mon.WindowsPerformanceSamples ps
        WHERE ps.TargetID = t.TargetID
      ) AS LastSampleAt
    , (
        SELECT LastInventoryAt
        FROM mon.WindowsInventory inv
        WHERE inv.TargetID = t.TargetID
      ) AS LastInventoryAt
FROM mon.WindowsTargets t
WHERE IsEnabled = 1
ORDER BY DisplayName;
"@
    return Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query
}

function Get-OrCreateWindowsTargetId {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [string]$ComputerName,
        [string]$DisplayName = $null
    )

    $query = @"
DECLARE @TargetID INT;
EXEC mon.usp_UpsertWindowsTarget
    @ComputerName = @ComputerName,
    @DisplayName = @DisplayName,
    @TargetID = @TargetID OUTPUT;
SELECT @TargetID;
"@
    return [int](Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters @{
        ComputerName = $ComputerName
        DisplayName = if ([string]::IsNullOrWhiteSpace($DisplayName)) { $ComputerName } else { $DisplayName }
    })
}

function ConvertTo-DbValue {
    param([object]$Value)
    if ($null -eq $Value) { return [DBNull]::Value }
    if ($Value -is [string] -and [string]::IsNullOrWhiteSpace($Value)) { return [DBNull]::Value }
    if ($Value -is [uint16]) { return [int]$Value }
    if ($Value -is [uint32]) { return [int64]$Value }
    if ($Value -is [uint64]) { return [decimal]$Value }
    return $Value
}

function Test-WindowsExtendedSchemaReady {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase
    )

    $query = @"
SELECT CASE WHEN
    OBJECT_ID(N'mon.WindowsHotFixSamples', N'U') IS NOT NULL AND
    OBJECT_ID(N'mon.WindowsProcessSamples', N'U') IS NOT NULL AND
    OBJECT_ID(N'mon.WindowsEventSamples', N'U') IS NOT NULL AND
    OBJECT_ID(N'mon.WindowsNetworkAdapterSamples', N'U') IS NOT NULL AND
    OBJECT_ID(N'mon.WindowsPerfCounterSamples', N'U') IS NOT NULL
THEN 1 ELSE 0 END;
"@
    try {
        return ([int](Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query) -eq 1)
    }
    catch {
        return $false
    }
}

function Test-WindowsCollectionDue {
    param(
        [object]$Target,
        [datetime]$Now = (Get-Date)
    )

    if ($null -eq $Target.LastSampleAt -or [DBNull]::Value -eq $Target.LastSampleAt) { return $true }
    $interval = 5
    if ($Target.PSObject.Properties.Name -contains 'CollectionIntervalMinutes' -and $Target.CollectionIntervalMinutes) {
        $interval = [Math]::Max(1, [int]$Target.CollectionIntervalMinutes)
    }
    return ([datetime]$Target.LastSampleAt).AddMinutes($interval) -le $Now
}

function Test-WindowsInventoryDue {
    param(
        [object]$Target,
        [int]$InventoryRefreshHours,
        [datetime]$Now = (Get-Date)
    )

    if ($InventoryRefreshHours -le 0) { return $true }
    if ($null -eq $Target.LastInventoryAt -or [DBNull]::Value -eq $Target.LastInventoryAt) { return $true }
    return ([datetime]$Target.LastInventoryAt).AddHours($InventoryRefreshHours) -le $Now
}

function Get-WindowsCpuPercent {
    param([string]$ComputerName)

    try {
        $cpuTotal = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Processor -ComputerName $ComputerName -Filter "Name='_Total'" -ErrorAction Stop
        return [decimal]$cpuTotal.PercentProcessorTime
    }
    catch {
        $cpu = @(Get-CimInstance -ClassName Win32_Processor -ComputerName $ComputerName -ErrorAction Stop)
        if ($cpu.Count -eq 0) { return $null }
        return [decimal](($cpu | Measure-Object -Property LoadPercentage -Average).Average)
    }
}

function Get-WindowsProcessCount {
    param([string]$ComputerName)

    try {
        $system = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_System -ComputerName $ComputerName -ErrorAction Stop
        return [int]$system.Processes
    }
    catch {
        return $null
    }
}

function Get-WindowsNetworkBytesPerSec {
    param([string]$ComputerName)

    try {
        $interfaces = @(Get-CimInstance -ClassName Win32_PerfFormattedData_Tcpip_NetworkInterface -ComputerName $ComputerName -ErrorAction Stop | Where-Object {
            $_.Name -notmatch 'Loopback|ISATAP|Teredo|Pseudo|Tunnel'
        })
        if ($interfaces.Count -eq 0) { return $null }
        return [int64](($interfaces | Measure-Object -Property BytesTotalPersec -Sum).Sum)
    }
    catch {
        return $null
    }
}

function Invoke-WindowsTryGet {
    param(
        [scriptblock]$ScriptBlock,
        [object]$Default = $null
    )

    try { & $ScriptBlock } catch { $Default }
}

function ConvertTo-WindowsShortMessage {
    param(
        [string]$Message,
        [int]$MaxLength = 1000
    )

    if ([string]::IsNullOrEmpty($Message)) { return $null }
    $clean = $Message -replace '\s+', ' '
    if ($clean.Length -le $MaxLength) { return $clean }
    return $clean.Substring(0, $MaxLength)
}

function Export-WindowsSnapshotFiles {
    param(
        [object]$Snapshot,
        [string]$OutDir
    )

    if ([string]::IsNullOrWhiteSpace($OutDir)) { return }
    if (-not (Test-Path -LiteralPath $OutDir)) {
        New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    }

    $safeComputer = ([string]$Snapshot.ComputerName) -replace '[^\w.-]', '_'
    $stamp = ([datetime]$Snapshot.CollectedAt).ToString('yyyyMMdd_HHmmss')
    $base = Join-Path $OutDir "$safeComputer`_$stamp"

    $Snapshot | ConvertTo-Json -Depth 8 | Set-Content -Path "$base.monitoring.json" -Encoding UTF8
    @($Snapshot.Storage.LogicalDisks) | Export-Csv -Path "$base.disks.csv" -NoTypeInformation -Encoding UTF8
    @($Snapshot.Network.Adapters) | Export-Csv -Path "$base.netadapters.csv" -NoTypeInformation -Encoding UTF8
    @($Snapshot.Services.StoppedAutomatic) | Export-Csv -Path "$base.services.csv" -NoTypeInformation -Encoding UTF8
    @($Snapshot.Processes.TopByCPU) | Export-Csv -Path "$base.topcpu.csv" -NoTypeInformation -Encoding UTF8
    @($Snapshot.Processes.TopByMemory) | Export-Csv -Path "$base.topmem.csv" -NoTypeInformation -Encoding UTF8
    @($Snapshot.PerfCounters) | Export-Csv -Path "$base.perfcounters.csv" -NoTypeInformation -Encoding UTF8
    @($Snapshot.Events) | Export-Csv -Path "$base.events.csv" -NoTypeInformation -Encoding UTF8
}

function Get-WindowsVMSnapshot {
    param(
        [string]$ComputerName,
        [int]$TopNProcesses = 25,
        [int]$EventHours = 12,
        [int]$PerfSampleSeconds = 3,
        [int]$PerfSamples = 3,
        [int]$MaxStoppedServices = 50
    )

    $captureTime = Get-Date
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $ComputerName -ErrorAction Stop
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $ComputerName -ErrorAction Stop
    $bios = Invoke-WindowsTryGet { Get-CimInstance -ClassName Win32_BIOS -ComputerName $ComputerName -ErrorAction Stop }
    $cpu = @(Get-CimInstance -ClassName Win32_Processor -ComputerName $ComputerName -ErrorAction Stop)
    $lastBoot = $os.LastBootUpTime
    $uptime = if ($lastBoot) { $captureTime - ([datetime]$lastBoot) } else { $null }

    $totalMemoryGb = [math]::Round(([double]$os.TotalVisibleMemorySize * 1KB / 1GB), 2)
    $freeMemoryGb = [math]::Round(([double]$os.FreePhysicalMemory * 1KB / 1GB), 2)
    $usedMemoryGb = [math]::Round(($totalMemoryGb - $freeMemoryGb), 2)
    $commitLimitGb = [math]::Round(([double]$os.TotalVirtualMemorySize * 1KB / 1GB), 2)
    $commitUsedGb = [math]::Round((([double]$os.TotalVirtualMemorySize - [double]$os.FreeVirtualMemory) * 1KB / 1GB), 2)

    $logicalDisks = @(Get-CimInstance -ClassName Win32_LogicalDisk -ComputerName $ComputerName -Filter "DriveType=3" -ErrorAction Stop | ForEach-Object {
        $sizeGb = if ($_.Size) { [math]::Round(([double]$_.Size / 1GB), 2) } else { $null }
        $freeGb = if ($_.FreeSpace) { [math]::Round(([double]$_.FreeSpace / 1GB), 2) } else { $null }
        [pscustomobject]@{
            DeviceID = $_.DeviceID
            VolumeName = $_.VolumeName
            SizeGB = $sizeGb
            FreeGB = $freeGb
            FreePct = if ($_.Size) { [math]::Round(([double]$_.FreeSpace / [double]$_.Size) * 100, 2) } else { $null }
            UsedPct = if ($_.Size) { [math]::Round((([double]$_.Size - [double]$_.FreeSpace) / [double]$_.Size) * 100, 2) } else { $null }
        }
    })

    $adapters = @(Invoke-WindowsTryGet {
        Get-CimInstance -Namespace root/StandardCimv2 -ClassName MSFT_NetAdapter -ComputerName $ComputerName -ErrorAction Stop |
            Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress
    } @())

    $ipcfg = @(Invoke-WindowsTryGet {
        Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -ComputerName $ComputerName -Filter "IPEnabled=True" -ErrorAction Stop |
            Select-Object Description, MACAddress, IPAddress, DefaultIPGateway, DNSServerSearchOrder
    } @())

    $tcpConnSummary = @(Invoke-WindowsTryGet {
        Get-CimInstance -Namespace root/StandardCimv2 -ClassName MSFT_NetTCPConnection -ComputerName $ComputerName -ErrorAction Stop |
            Where-Object { $_.State -eq 5 } |
            Group-Object -Property RemoteAddress |
            Sort-Object Count -Descending |
            Select-Object -First 25 Name, Count
    } @())

    $services = @(Get-CimInstance -ClassName Win32_Service -ComputerName $ComputerName -ErrorAction Stop)
    $stoppedAutomatic = @($services | Where-Object { $_.StartMode -eq 'Auto' -and $_.State -ne 'Running' } | Select-Object -First $MaxStoppedServices)

    $processCounters = @(Invoke-WindowsTryGet {
        Get-CimInstance -ClassName Win32_PerfFormattedData_PerfProc_Process -ComputerName $ComputerName -ErrorAction Stop |
            Where-Object { $_.IDProcess -gt 0 -and $_.Name -ne '_Total' } |
            Select-Object Name, IDProcess, PercentProcessorTime, WorkingSet, VirtualBytes
    } @())
    $topCpu = @($processCounters | Sort-Object PercentProcessorTime -Descending | Select-Object -First $TopNProcesses)
    $topMem = @($processCounters | Sort-Object WorkingSet -Descending | Select-Object -First $TopNProcesses)

    $since = $captureTime.AddHours(-1 * [math]::Max(1, $EventHours))
    $events = foreach ($log in @('System', 'Application')) {
        Invoke-WindowsTryGet {
            Get-WinEvent -ComputerName $ComputerName -FilterHashtable @{ LogName = $log; StartTime = $since } -ErrorAction Stop |
                Where-Object { $_.LevelDisplayName -in @('Critical', 'Error', 'Warning') } |
                Select-Object -First 100 TimeCreated, LogName, Id, LevelDisplayName, ProviderName,
                    @{ Name = 'Message'; Expression = { ConvertTo-WindowsShortMessage -Message $_.Message } }
        } @()
    }

    $counterPaths = @(
        '\Processor(_Total)\% Processor Time',
        '\Memory\Available MBytes',
        '\LogicalDisk(_Total)\% Free Space',
        '\LogicalDisk(_Total)\Avg. Disk sec/Read',
        '\LogicalDisk(_Total)\Avg. Disk sec/Write',
        '\Network Interface(*)\Bytes Total/sec'
    )
    $perfCounters = @(Invoke-WindowsTryGet {
        Get-Counter -ComputerName $ComputerName -Counter $counterPaths -SampleInterval $PerfSampleSeconds -MaxSamples $PerfSamples -ErrorAction Stop |
            Select-Object -ExpandProperty CounterSamples |
            Select-Object Path, CookedValue, TimeStamp
    } @())

    $hotfix = @(Invoke-WindowsTryGet {
        Get-HotFix -ComputerName $ComputerName -ErrorAction Stop |
            Sort-Object InstalledOn -Descending |
            Select-Object -First 20 HotFixID, InstalledOn, Description
    } @())

    $cpuPercent = Get-WindowsCpuPercent -ComputerName $ComputerName
    $diskUsedPercent = if ($logicalDisks.Count -gt 0) {
        $total = ($logicalDisks | Measure-Object -Property SizeGB -Sum).Sum
        $free = ($logicalDisks | Measure-Object -Property FreeGB -Sum).Sum
        if ($total -gt 0) { [math]::Round((($total - $free) / $total) * 100, 2) } else { $null }
    } else { $null }

    $networkBytesPerSec = $null
    $networkCounterRows = @($perfCounters | Where-Object { $_.Path -like '*\network interface(*)\bytes total/sec' -or $_.Path -like '*\network interface(*\bytes total/sec' })
    if ($networkCounterRows.Count -gt 0) {
        $networkBytesPerSec = [int64](($networkCounterRows | Measure-Object -Property CookedValue -Average).Average)
    }
    if ($null -eq $networkBytesPerSec) { $networkBytesPerSec = Get-WindowsNetworkBytesPerSec -ComputerName $ComputerName }

    $manufacturer = [string]$cs.Manufacturer
    $model = [string]$cs.Model
    $isVm = ($model -match 'Virtual|VMware|KVM|HVM|Xen|Hyper-V' -or $manufacturer -match 'Microsoft|VMware|Xen|QEMU|Amazon|Google')

    return [pscustomobject]@{
        CollectedAt = $captureTime
        ComputerName = $ComputerName
        OS = [pscustomobject]@{
            Caption = $os.Caption
            Version = $os.Version
            BuildNumber = $os.BuildNumber
            InstallDate = $os.InstallDate
            LastBootUpTime = $lastBoot
            Uptime = if ($uptime) { [string]$uptime } else { $null }
            SerialNumber = $os.SerialNumber
        }
        Hardware = [pscustomobject]@{
            Manufacturer = $manufacturer
            Model = $model
            DomainName = $cs.Domain
            BIOS = $bios
            CPU = $cpu
            Memory = [pscustomobject]@{
                TotalGB = $totalMemoryGb
                FreeGB = $freeMemoryGb
                UsedGB = $usedMemoryGb
                UsedPct = if ($totalMemoryGb -gt 0) { [math]::Round(($usedMemoryGb / $totalMemoryGb) * 100, 2) } else { $null }
                CommitLimitGB = $commitLimitGb
                CommitUsedGB = $commitUsedGb
            }
        }
        VMHints = [pscustomobject]@{
            IsVirtualMachine = $isVm
            Model = $model
            Manufacturer = $manufacturer
            HypervisorPresent = Invoke-WindowsTryGet { $cs.HypervisorPresent }
        }
        Patching = [pscustomobject]@{ HotFixTop20 = $hotfix }
        Storage = [pscustomobject]@{ LogicalDisks = $logicalDisks }
        Network = [pscustomobject]@{
            Adapters = $adapters
            IPConfiguration = $ipcfg
            TopRemoteEstablishedTCP = $tcpConnSummary
            BytesTotalPerSec = $networkBytesPerSec
        }
        Services = [pscustomobject]@{
            Summary = @($services | Group-Object State | Select-Object Name, Count)
            StoppedAutomatic = $stoppedAutomatic
        }
        Processes = [pscustomobject]@{
            TopByCPU = $topCpu
            TopByMemory = $topMem
        }
        PerfCounters = $perfCounters
        Events = @($events)
        Summary = [pscustomobject]@{
            CPUPercent = $cpuPercent
            MemoryUsedPercent = if ($totalMemoryGb -gt 0) { [math]::Round(($usedMemoryGb / $totalMemoryGb) * 100, 2) } else { $null }
            MemoryAvailableGB = $freeMemoryGb
            DiskUsedPercent = $diskUsedPercent
            DiskFreeGB = ($logicalDisks | Measure-Object -Property FreeGB -Sum).Sum
            ProcessCount = Get-WindowsProcessCount -ComputerName $ComputerName
            ServiceStoppedCount = @($stoppedAutomatic).Count
            NetworkBytesPerSec = $networkBytesPerSec
        }
    }
}

function Invoke-WindowsVMCollector {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RepositoryServer,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryDatabase,

        [string[]]$ComputerName = @(),

        [int]$InventoryRefreshHours = 12,

        [int]$MaxStoppedServices = 50,

        [int]$TopNProcesses = 25,

        [int]$EventHours = 12,

        [int]$PerfSampleSeconds = 3,

        [int]$PerfSamples = 3,

        [string]$OutDir = '',

        [bool]$EvaluateAlerts = $true,

        [bool]$AutoCreateTickets = $true
    )

    $targets = @()
    if ($ComputerName.Count -gt 0) {
        foreach ($name in $ComputerName) {
            if ([string]::IsNullOrWhiteSpace($name)) { continue }
            $targetId = Get-OrCreateWindowsTargetId -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -ComputerName $name.Trim()
            $targets += [pscustomobject]@{ TargetID = $targetId; ComputerName = $name.Trim(); DisplayName = $name.Trim() }
        }
    }
    else {
        $rows = Get-WindowsTargetRows -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase
        foreach ($row in $rows.Rows) {
            $targets += [pscustomobject]@{
                TargetID = [int]$row.TargetID
                ComputerName = [string]$row.ComputerName
                DisplayName = [string]$row.DisplayName
                CollectionMode = [string]$row.CollectionMode
                CollectionIntervalMinutes = [int]$row.CollectionIntervalMinutes
                LastSampleAt = $row.LastSampleAt
                LastInventoryAt = $row.LastInventoryAt
            }
        }
    }

    if ($targets.Count -eq 0) {
        $local = $env:COMPUTERNAME
        $targetId = Get-OrCreateWindowsTargetId -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -ComputerName $local
        $targets += [pscustomobject]@{ TargetID = $targetId; ComputerName = $local; DisplayName = $local }
    }

    $extendedSchemaReady = Test-WindowsExtendedSchemaReady -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase

    foreach ($target in $targets) {
        if ($ComputerName.Count -eq 0 -and -not (Test-WindowsCollectionDue -Target $target)) {
            Write-MonitorLog "Windows VM collector skipped for $($target.ComputerName); collection interval has not elapsed."
            continue
        }

        $runId = Start-CollectionRun -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -InstanceID 0 -ModuleName "WindowsVM"
        try {
            Write-MonitorLog "Windows VM collector started for $($target.ComputerName)"
            $computer = [string]$target.ComputerName
            $snapshot = Get-WindowsVMSnapshot -ComputerName $computer -TopNProcesses $TopNProcesses -EventHours $EventHours -PerfSampleSeconds $PerfSampleSeconds -PerfSamples $PerfSamples -MaxStoppedServices $MaxStoppedServices
            Export-WindowsSnapshotFiles -Snapshot $snapshot -OutDir $OutDir

            $captureTime = [datetime]$snapshot.CollectedAt
            $inventoryDue = Test-WindowsInventoryDue -Target $target -InventoryRefreshHours $InventoryRefreshHours -Now $captureTime
            $os = $snapshot.OS
            $hardware = $snapshot.Hardware
            $summary = $snapshot.Summary
            $disks = @($snapshot.Storage.LogicalDisks)
            $services = @($snapshot.Services.StoppedAutomatic)

            $cpuPercent = $summary.CPUPercent
            $totalMemoryGb = $hardware.Memory.TotalGB
            $freeMemoryGb = $summary.MemoryAvailableGB
            $memoryUsedPercent = $summary.MemoryUsedPercent
            $diskFreeGb = $summary.DiskFreeGB
            $diskUsedPercent = $summary.DiskUsedPercent
            $serviceStoppedCount = $summary.ServiceStoppedCount
            $processCount = $summary.ProcessCount
            $networkBytesPerSec = $summary.NetworkBytesPerSec

            $score = 100
            if ($cpuPercent -ge 90) { $score -= 25 } elseif ($cpuPercent -ge 75) { $score -= 12 }
            if ($memoryUsedPercent -ge 90) { $score -= 25 } elseif ($memoryUsedPercent -ge 80) { $score -= 12 }
            if ($diskUsedPercent -ge 95) { $score -= 25 } elseif ($diskUsedPercent -ge 85) { $score -= 12 }
            if ($serviceStoppedCount -gt 0) { $score -= [Math]::Min(20, $serviceStoppedCount * 4) }
            $score = [Math]::Max(0, [Math]::Min(100, [int]$score))
            $posture = if ($score -ge 85) { 'Healthy' } elseif ($score -ge 60) { 'Warning' } else { 'Critical' }

            if ($inventoryDue) {
                $inventorySql = @"
MERGE mon.WindowsInventory AS target
USING (SELECT @TargetID AS TargetID) AS source
    ON target.TargetID = source.TargetID
WHEN MATCHED THEN UPDATE SET
    ComputerName = @ComputerName,
    DomainName = @DomainName,
    OSName = @OSName,
    OSVersion = @OSVersion,
    OSBuild = @OSBuild,
    Manufacturer = @Manufacturer,
    Model = @Model,
    ProcessorName = @ProcessorName,
    LogicalProcessorCount = @LogicalProcessorCount,
    TotalMemoryGB = @TotalMemoryGB,
    LastBootTime = @LastBootTime,
    LastInventoryAt = @CaptureTime
WHEN NOT MATCHED THEN
    INSERT (TargetID, ComputerName, DomainName, OSName, OSVersion, OSBuild, Manufacturer, Model, ProcessorName, LogicalProcessorCount, TotalMemoryGB, LastBootTime, LastInventoryAt)
    VALUES (@TargetID, @ComputerName, @DomainName, @OSName, @OSVersion, @OSBuild, @Manufacturer, @Model, @ProcessorName, @LogicalProcessorCount, @TotalMemoryGB, @LastBootTime, @CaptureTime);
"@
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $inventorySql -Parameters @{
                    TargetID = [int]$target.TargetID
                    ComputerName = $computer
                    DomainName = ConvertTo-DbValue $hardware.DomainName
                    OSName = ConvertTo-DbValue $os.Caption
                    OSVersion = ConvertTo-DbValue $os.Version
                    OSBuild = ConvertTo-DbValue $os.BuildNumber
                    Manufacturer = ConvertTo-DbValue $hardware.Manufacturer
                    Model = ConvertTo-DbValue $hardware.Model
                    ProcessorName = ConvertTo-DbValue (@($hardware.CPU) | Select-Object -First 1).Name
                    LogicalProcessorCount = ConvertTo-DbValue ((@($hardware.CPU) | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum)
                    TotalMemoryGB = ConvertTo-DbValue $totalMemoryGb
                    LastBootTime = ConvertTo-DbValue $os.LastBootUpTime
                    CaptureTime = $captureTime
                }
            }

            $sampleSql = @"
EXEC mon.usp_InsertWindowsPerformanceSample
    @TargetID = @TargetID,
    @CaptureTime = @CaptureTime,
    @CPUPercent = @CPUPercent,
    @MemoryUsedPercent = @MemoryUsedPercent,
    @MemoryAvailableGB = @MemoryAvailableGB,
    @DiskUsedPercent = @DiskUsedPercent,
    @DiskFreeGB = @DiskFreeGB,
    @NetworkBytesPerSec = @NetworkBytesPerSec,
    @ProcessCount = @ProcessCount,
    @ServiceStoppedCount = @ServiceStoppedCount,
    @HealthScore = @HealthScore,
    @HealthPosture = @HealthPosture;
"@
            Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $sampleSql -Parameters @{
                TargetID = [int]$target.TargetID
                CaptureTime = $captureTime
                CPUPercent = ConvertTo-DbValue $cpuPercent
                MemoryUsedPercent = ConvertTo-DbValue $memoryUsedPercent
                MemoryAvailableGB = ConvertTo-DbValue $freeMemoryGb
                DiskUsedPercent = ConvertTo-DbValue $diskUsedPercent
                DiskFreeGB = ConvertTo-DbValue $diskFreeGb
                NetworkBytesPerSec = ConvertTo-DbValue $networkBytesPerSec
                ProcessCount = ConvertTo-DbValue $processCount
                ServiceStoppedCount = $serviceStoppedCount
                HealthScore = $score
                HealthPosture = $posture
            }

            foreach ($disk in $disks) {
                $totalGb = $disk.SizeGB
                $freeGb = $disk.FreeGB
                $usedPct = $disk.UsedPct
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsDiskSamples (TargetID, CaptureTime, DriveLetter, VolumeName, TotalGB, FreeGB, UsedPercent)
VALUES (@TargetID, @CaptureTime, @DriveLetter, @VolumeName, @TotalGB, @FreeGB, @UsedPercent);
"@ -Parameters @{
                    TargetID = [int]$target.TargetID
                    CaptureTime = $captureTime
                    DriveLetter = [string]$disk.DeviceID
                    VolumeName = ConvertTo-DbValue $disk.VolumeName
                    TotalGB = ConvertTo-DbValue $totalGb
                    FreeGB = ConvertTo-DbValue $freeGb
                    UsedPercent = ConvertTo-DbValue $usedPct
                }
            }

            foreach ($service in $services) {
                Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsServiceSamples (TargetID, CaptureTime, ServiceName, DisplayName, StartMode, StateName, IsCritical)
VALUES (@TargetID, @CaptureTime, @ServiceName, @DisplayName, @StartMode, @StateName, @IsCritical);
"@ -Parameters @{
                    TargetID = [int]$target.TargetID
                    CaptureTime = $captureTime
                    ServiceName = [string]$service.Name
                    DisplayName = ConvertTo-DbValue $service.DisplayName
                    StartMode = ConvertTo-DbValue $service.StartMode
                    StateName = ConvertTo-DbValue $service.State
                    IsCritical = [bool]($service.Name -match 'MSSQL|SQLSERVERAGENT|WinRM|EventLog|LanmanServer')
                }
            }

            if ($extendedSchemaReady) {
                foreach ($hotfix in @($snapshot.Patching.HotFixTop20)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsHotFixSamples (TargetID, CaptureTime, HotFixID, InstalledOn, Description)
VALUES (@TargetID, @CaptureTime, @HotFixID, @InstalledOn, @Description);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        HotFixID = ConvertTo-DbValue $hotfix.HotFixID
                        InstalledOn = ConvertTo-DbValue $hotfix.InstalledOn
                        Description = ConvertTo-DbValue $hotfix.Description
                    }
                }

                foreach ($adapter in @($snapshot.Network.Adapters)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsNetworkAdapterSamples (TargetID, CaptureTime, AdapterName, InterfaceDescription, StatusName, LinkSpeed, MacAddress)
VALUES (@TargetID, @CaptureTime, @AdapterName, @InterfaceDescription, @StatusName, @LinkSpeed, @MacAddress);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        AdapterName = ConvertTo-DbValue $adapter.Name
                        InterfaceDescription = ConvertTo-DbValue $adapter.InterfaceDescription
                        StatusName = ConvertTo-DbValue $adapter.Status
                        LinkSpeed = ConvertTo-DbValue ([string]$adapter.LinkSpeed)
                        MacAddress = ConvertTo-DbValue $adapter.MacAddress
                    }
                }

                foreach ($ranked in @(
                    @{ Type = 'CPU'; Rows = @($snapshot.Processes.TopByCPU) },
                    @{ Type = 'Memory'; Rows = @($snapshot.Processes.TopByMemory) }
                )) {
                    foreach ($process in @($ranked.Rows)) {
                        Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsProcessSamples (TargetID, CaptureTime, RankingType, ProcessName, ProcessID, CPUPercent, WorkingSetMB, VirtualMemoryMB)
VALUES (@TargetID, @CaptureTime, @RankingType, @ProcessName, @ProcessID, @CPUPercent, @WorkingSetMB, @VirtualMemoryMB);
"@ -Parameters @{
                            TargetID = [int]$target.TargetID
                            CaptureTime = $captureTime
                            RankingType = [string]$ranked.Type
                            ProcessName = ConvertTo-DbValue $process.Name
                            ProcessID = ConvertTo-DbValue $process.IDProcess
                            CPUPercent = ConvertTo-DbValue $process.PercentProcessorTime
                            WorkingSetMB = if ($process.WorkingSet) { [math]::Round(([double]$process.WorkingSet / 1MB), 2) } else { [DBNull]::Value }
                            VirtualMemoryMB = if ($process.VirtualBytes) { [math]::Round(([double]$process.VirtualBytes / 1MB), 2) } else { [DBNull]::Value }
                        }
                    }
                }

                foreach ($event in @($snapshot.Events | Select-Object -First 200)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsEventSamples (TargetID, CaptureTime, EventTime, LogName, EventID, LevelName, ProviderName, Message)
VALUES (@TargetID, @CaptureTime, @EventTime, @LogName, @EventID, @LevelName, @ProviderName, @Message);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        EventTime = ConvertTo-DbValue $event.TimeCreated
                        LogName = ConvertTo-DbValue $event.LogName
                        EventID = ConvertTo-DbValue $event.Id
                        LevelName = ConvertTo-DbValue $event.LevelDisplayName
                        ProviderName = ConvertTo-DbValue $event.ProviderName
                        Message = ConvertTo-DbValue (ConvertTo-WindowsShortMessage -Message $event.Message)
                    }
                }

                foreach ($counter in @($snapshot.PerfCounters | Select-Object -First 300)) {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
INSERT INTO mon.WindowsPerfCounterSamples (TargetID, CaptureTime, CounterPath, CookedValue, CounterTime)
VALUES (@TargetID, @CaptureTime, @CounterPath, @CookedValue, @CounterTime);
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        CaptureTime = $captureTime
                        CounterPath = [string]$counter.Path
                        CookedValue = ConvertTo-DbValue $counter.CookedValue
                        CounterTime = ConvertTo-DbValue $counter.TimeStamp
                    }
                }
            }

            if ($EvaluateAlerts) {
                try {
                    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query @"
DECLARE @TicketsCreated INT;
EXEC mon.usp_EvaluateWindowsVMAlerts
    @TargetID = @TargetID,
    @AutoCreateTickets = @AutoCreateTickets,
    @CreatedBy = N'vm-alert-engine',
    @TicketsCreated = @TicketsCreated OUTPUT;
"@ -Parameters @{
                        TargetID = [int]$target.TargetID
                        AutoCreateTickets = if ($AutoCreateTickets) { 1 } else { 0 }
                    }
                }
                catch {
                    Write-MonitorLog "Windows VM alert evaluation failed for ${computer}: $($_.Exception.Message)" -Level Warning
                }
            }

            Stop-CollectionRun -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -RunID $runId -Status "Success"
            Write-MonitorLog "Windows VM collector completed for $computer. HealthScore=$score Posture=$posture"
        }
        catch {
            $message = $_.Exception.Message
            Write-MonitorLog "Windows VM collector failed for $($target.ComputerName): $message"
            Stop-CollectionRun -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -RunID $runId -Status "Failed" -ErrorMessage $message
        }
    }
}

Export-ModuleMember -Function Invoke-WindowsVMCollector, Get-WindowsTargetRows, Get-OrCreateWindowsTargetId, ConvertTo-DbValue, Test-WindowsExtendedSchemaReady, Test-WindowsCollectionDue, Test-WindowsInventoryDue, Get-WindowsCpuPercent, Get-WindowsProcessCount, Get-WindowsNetworkBytesPerSec, Invoke-WindowsTryGet, ConvertTo-WindowsShortMessage, Export-WindowsSnapshotFiles, Get-WindowsVMSnapshot
