# TaskManagement.psm1 - Task Management Module for DBA Team
# Provides functions to create, update, and manage tasks, activities, and comments

function Get-TaskManagementConfig {
    <#
    .SYNOPSIS
    Gets the configuration for Task Management module
    #>
    $configPath = Join-Path $PSScriptRoot "..\Config\instances.json"
    if (Test-Path $configPath) {
        $config = Get-Content $configPath | ConvertFrom-Json
        return @{
            ServerInstance = $config.RepositoryServer
            Database = $config.RepositoryDatabase
        }
    }
    throw "Configuration file not found at $configPath"
}

function New-Task {
    <#
    .SYNOPSIS
    Creates a new task in the task management system
    
    .PARAMETER TaskTitle
    Title of the task
    
    .PARAMETER TaskDescription
    Detailed description of the task
    
    .PARAMETER AssignedTo
    Person assigned to the task (optional)
    
    .PARAMETER Priority
    Priority level: Critical, High, Medium, Low (default: Medium)
    
    .PARAMETER InstanceID
    ID of the monitored instance (optional)
    
    .PARAMETER DueDate
    Due date for the task (optional)
    
    .EXAMPLE
    New-Task -TaskTitle "Check CPU usage" -TaskDescription "Investigate high CPU" -AssignedTo "JohnDoe" -Priority "High"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TaskTitle,
        
        [Parameter(Mandatory = $false)]
        [string]$TaskDescription = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("Critical", "High", "Medium", "Low")]
        [string]$Priority = "Medium",
        
        [Parameter(Mandatory = $false)]
        [int]$InstanceID = $null,
        
        [Parameter(Mandatory = $false)]
        [datetime]$DueDate = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$CreatedBy = $env:USERNAME
    )
    
    $config = Get-TaskManagementConfig
    
    # Map priority name to ID
    $priorityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    $priorityID = $priorityMap[$Priority]
    $dueDateValue = if ($DueDate) { $DueDate.ToString("yyyy-MM-dd HH:mm:ss") } else { $null }
    
    $query = @"
EXEC [mon].[usp_CreateTask]
    @TaskTitle = @TaskTitle,
    @TaskDescription = @TaskDescription,
    @CreatedBy = @CreatedBy,
    @AssignedTo = @AssignedTo,
    @TaskPriorityID = @TaskPriorityID,
    @InstanceID = @InstanceID,
    @DueDate = @DueDate
"@
    
    $parameters = @{
        TaskTitle = $TaskTitle
        TaskDescription = $TaskDescription
        CreatedBy = $CreatedBy
        AssignedTo = $AssignedTo
        TaskPriorityID = $priorityID
        InstanceID = $InstanceID
        DueDate = $dueDateValue
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Task created successfully. TaskID: $($result.TaskID)"
        return $result
    }
    catch {
        Write-MonitorLog "Error creating task: $_" -Level Error
        throw
    }
}

function Get-Task {
    <#
    .SYNOPSIS
    Retrieves tasks based on filters
    
    .PARAMETER TaskID
    Specific Task ID to retrieve
    
    .PARAMETER AssignedTo
    Filter by assigned person
    
    .PARAMETER CreatedBy
    Filter by creator
    
    .PARAMETER Status
    Filter by status: Open, In Progress, Pending, Completed, Cancelled, On Hold
    
    .PARAMETER Priority
    Filter by priority: Critical, High, Medium, Low
    
    .PARAMETER InstanceID
    Filter by monitored instance
    
    .PARAMETER IncludeCompleted
    Include completed tasks in results
    
    .EXAMPLE
    Get-Task -AssignedTo "JohnDoe" -Status "Open"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [int]$TaskID = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$CreatedBy = $null,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("", "Open", "In Progress", "Pending", "Completed", "Cancelled", "On Hold")]
        [string]$Status = "",
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("", "Critical", "High", "Medium", "Low")]
        [string]$Priority = "",
        
        [Parameter(Mandatory = $false)]
        [int]$InstanceID = $null,
        
        [Parameter(Mandatory = $false)]
        [bool]$IncludeCompleted = $false
    )
    
    $config = Get-TaskManagementConfig
    
    # Map status name to ID
    $statusMap = @{
        "Open" = 1
        "In Progress" = 2
        "Pending" = 3
        "Completed" = 4
        "Cancelled" = 5
        "On Hold" = 6
    }
    
    # Map priority name to ID
    $priorityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    $statusID = if ($Status -and $Status -ne "") { $statusMap[$Status] } else { $null }
    $priorityID = if ($Priority -and $Priority -ne "") { $priorityMap[$Priority] } else { $null }
    
    if ($TaskID) {
        $query = "SELECT * FROM [mon].[vw_TaskDetails] WHERE TaskID = @TaskID"
        $parameters = @{ TaskID = $TaskID }
    }
    else {
        $query = "EXEC [mon].[usp_GetTasks] @AssignedTo, @CreatedBy, @TaskStatusID, @TaskPriorityID, @InstanceID, @IncludeCompleted"
        $parameters = @{
            AssignedTo = $AssignedTo
            CreatedBy = $CreatedBy
            TaskStatusID = $statusID
            TaskPriorityID = $priorityID
            InstanceID = $InstanceID
            IncludeCompleted = if ($IncludeCompleted) { 1 } else { 0 }
        }
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving tasks: $_" -Level Error
        throw
    }
}

function Update-Task {
    <#
    .SYNOPSIS
    Updates an existing task
    
    .PARAMETER TaskID
    ID of the task to update
    
    .PARAMETER TaskTitle
    New title for the task
    
    .PARAMETER TaskDescription
    New description for the task
    
    .PARAMETER AssignedTo
    New assignee for the task
    
    .PARAMETER Status
    New status: Open, In Progress, Pending, Completed, Cancelled, On Hold
    
    .PARAMETER Priority
    New priority: Critical, High, Medium, Low
    
    .PARAMETER DueDate
    New due date
    
    .PARAMETER ModifiedBy
    Person making the modification
    
    .EXAMPLE
    Update-Task -TaskID 1 -Status "In Progress" -ModifiedBy "JohnDoe"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$TaskID,
        
        [Parameter(Mandatory = $false)]
        [string]$TaskTitle = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$TaskDescription = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("", "Open", "In Progress", "Pending", "Completed", "Cancelled", "On Hold")]
        [string]$Status = "",
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("", "Critical", "High", "Medium", "Low")]
        [string]$Priority = "",
        
        [Parameter(Mandatory = $false)]
        [datetime]$DueDate = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$ModifiedBy = $env:USERNAME
    )
    
    $config = Get-TaskManagementConfig
    
    # Map status name to ID
    $statusMap = @{
        "Open" = 1
        "In Progress" = 2
        "Pending" = 3
        "Completed" = 4
        "Cancelled" = 5
        "On Hold" = 6
    }
    
    # Map priority name to ID
    $priorityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    $statusID = if ($Status -and $Status -ne "") { $statusMap[$Status] } else { $null }
    $priorityID = if ($Priority -and $Priority -ne "") { $priorityMap[$Priority] } else { $null }
    $dueDateValue = if ($DueDate) { $DueDate.ToString("yyyy-MM-dd HH:mm:ss") } else { $null }
    
    $query = @"
EXEC [mon].[usp_UpdateTask]
    @TaskID = @TaskID,
    @TaskTitle = @TaskTitle,
    @TaskDescription = @TaskDescription,
    @AssignedTo = @AssignedTo,
    @TaskStatusID = @TaskStatusID,
    @TaskPriorityID = @TaskPriorityID,
    @DueDate = @DueDate,
    @ModifiedBy = @ModifiedBy
"@
    
    $parameters = @{
        TaskID = $TaskID
        TaskTitle = $TaskTitle
        TaskDescription = $TaskDescription
        AssignedTo = $AssignedTo
        TaskStatusID = $statusID
        TaskPriorityID = $priorityID
        DueDate = $dueDateValue
        ModifiedBy = $ModifiedBy
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Task $TaskID updated successfully."
        return $result
    }
    catch {
        Write-MonitorLog "Error updating task: $_" -Level Error
        throw
    }
}

function Add-TaskComment {
    <#
    .SYNOPSIS
    Adds a comment to a task
    
    .PARAMETER TaskID
    ID of the task to comment on
    
    .PARAMETER CommentText
    Comment text
    
    .PARAMETER CreatedBy
    Person adding the comment
    
    .EXAMPLE
    Add-TaskComment -TaskID 1 -CommentText "Started working on this" -CreatedBy "JohnDoe"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$TaskID,
        
        [Parameter(Mandatory = $true)]
        [string]$CommentText,
        
        [Parameter(Mandatory = $false)]
        [string]$CreatedBy = $env:USERNAME
    )
    
    $config = Get-TaskManagementConfig
    
    $query = @"
EXEC [mon].[usp_AddTaskComment]
    @TaskID = @TaskID,
    @CommentText = @CommentText,
    @CreatedBy = @CreatedBy
"@
    
    $parameters = @{
        TaskID = $TaskID
        CommentText = $CommentText
        CreatedBy = $CreatedBy
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Comment added to Task $TaskID."
        return $result
    }
    catch {
        Write-MonitorLog "Error adding comment: $_" -Level Error
        throw
    }
}

function Get-TaskComments {
    <#
    .SYNOPSIS
    Retrieves comments for a specific task
    
    .PARAMETER TaskID
    ID of the task
    
    .EXAMPLE
    Get-TaskComments -TaskID 1
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$TaskID
    )
    
    $config = Get-TaskManagementConfig
    
    $query = "SELECT * FROM [mon].[vw_TaskComments] WHERE TaskID = @TaskID ORDER BY CreatedDate"
    $parameters = @{ TaskID = $TaskID }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving task comments: $_" -Level Error
        throw
    }
}

function Get-TaskActivities {
    <#
    .SYNOPSIS
    Retrieves activity history for a specific task
    
    .PARAMETER TaskID
    ID of the task
    
    .EXAMPLE
    Get-TaskActivities -TaskID 1
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$TaskID
    )
    
    $config = Get-TaskManagementConfig
    
    $query = "SELECT * FROM [mon].[TaskActivities] WHERE TaskID = @TaskID ORDER BY CreatedDate DESC"
    $parameters = @{ TaskID = $TaskID }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving task activities: $_" -Level Error
        throw
    }
}

function Get-OpenTasks {
    <#
    .SYNOPSIS
    Retrieves all open tasks (not completed or cancelled)
    
    .PARAMETER AssignedTo
    Filter by assigned person
    
    .EXAMPLE
    Get-OpenTasks -AssignedTo "JohnDoe"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null
    )
    
    $config = Get-TaskManagementConfig
    
    $query = "SELECT * FROM [mon].[vw_OpenTasks]"
    if ($AssignedTo) {
        $query += " WHERE AssignedTo = @AssignedTo"
        $parameters = @{ AssignedTo = $AssignedTo }
    }
    else {
        $parameters = @{}
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving open tasks: $_" -Level Error
        throw
    }
}

function Get-OverdueTasks {
    <#
    .SYNOPSIS
    Retrieves all overdue tasks
    
    .PARAMETER AssignedTo
    Filter by assigned person
    
    .EXAMPLE
    Get-OverdueTasks
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null
    )
    
    $config = Get-TaskManagementConfig
    
    $query = "SELECT * FROM [mon].[vw_OverdueTasks]"
    if ($AssignedTo) {
        $query += " WHERE AssignedTo = @AssignedTo"
        $parameters = @{ AssignedTo = $AssignedTo }
    }
    else {
        $parameters = @{}
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving overdue tasks: $_" -Level Error
        throw
    }
}

# Export module functions
Export-ModuleMember -Function New-Task, Get-Task, Update-Task, Add-TaskComment, 
                              Get-TaskComments, Get-TaskActivities, Get-OpenTasks, 
                              Get-OverdueTasks
