# TicketSystem.psm1 - Ticketing System Module
# Provides functions to create, acknowledge, resolve tickets and manage comments

function Get-TicketSystemConfig {
    <#
    .SYNOPSIS
    Gets the configuration for Ticket System module
    #>
    $configPath = Join-Path $PSScriptRoot "..\Config\instances.json"
    if (Test-Path $configPath) {
        $config = Get-Content $configPath | ConvertFrom-Json
        return @{
            ServerInstance = $config.RepositoryServer
            Database = $config.RepositoryDatabase
        }
    }
    throw "Configuration file not found at $configPath"
}

function New-TicketFromAlert {
    <#
    .SYNOPSIS
    Creates a new ticket from an existing alert
    
    .PARAMETER AlertID
    ID of the alert to create ticket from
    
    .PARAMETER CreatedBy
    Person creating the ticket
    
    .PARAMETER Severity
    Ticket severity: Critical, High, Medium, Low (default: Medium)
    
    .PARAMETER AssignedTo
    Person assigned to the ticket (optional)
    
    .EXAMPLE
    New-TicketFromAlert -AlertID 123 -CreatedBy "JohnDoe" -Severity "High"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bigint]$AlertID,
        
        [Parameter(Mandatory = $false)]
        [string]$CreatedBy = $env:USERNAME,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("Critical", "High", "Medium", "Low")]
        [string]$Severity = "Medium",
        
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null
    )
    
    $config = Get-TicketSystemConfig
    
    # Map severity name to ID
    $severityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    $severityID = $severityMap[$Severity]
    
    $query = @"
EXEC [mon].[usp_CreateTicketFromAlert]
    @AlertID = @AlertID,
    @CreatedBy = @CreatedBy,
    @TicketSeverityID = @TicketSeverityID,
    @AssignedTo = @AssignedTo
"@
    
    $parameters = @{
        AlertID = $AlertID
        CreatedBy = $CreatedBy
        TicketSeverityID = $severityID
        AssignedTo = $AssignedTo
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Ticket created from Alert $AlertID. TicketID: $($result.TicketID), Number: $($result.TicketNumber)"
        return $result
    }
    catch {
        Write-MonitorLog "Error creating ticket from alert: $_" -Level Error
        throw
    }
}

function New-ManualTicket {
    <#
    .SYNOPSIS
    Creates a new manual ticket (not from alert)
    
    .PARAMETER ErrorDescription
    Description of the error or issue
    
    .PARAMETER CreatedBy
    Person creating the ticket
    
    .PARAMETER InstanceID
    ID of the monitored instance (optional)
    
    .PARAMETER Severity
    Ticket severity: Critical, High, Medium, Low (default: Medium)
    
    .PARAMETER AssignedTo
    Person assigned to the ticket (optional)
    
    .EXAMPLE
    New-ManualTicket -ErrorDescription "Database connection failed" -CreatedBy "JohnDoe" -Severity "Critical"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ErrorDescription,
        
        [Parameter(Mandatory = $false)]
        [string]$CreatedBy = $env:USERNAME,
        
        [Parameter(Mandatory = $false)]
        [int]$InstanceID = $null,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("Critical", "High", "Medium", "Low")]
        [string]$Severity = "Medium",
        
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null
    )
    
    $config = Get-TicketSystemConfig
    
    # Map severity name to ID
    $severityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    $severityID = $severityMap[$Severity]
    
    $query = @"
EXEC [mon].[usp_CreateManualTicket]
    @ErrorDescription = @ErrorDescription,
    @CreatedBy = @CreatedBy,
    @InstanceID = @InstanceID,
    @TicketSeverityID = @TicketSeverityID,
    @AssignedTo = @AssignedTo
"@
    
    $parameters = @{
        ErrorDescription = $ErrorDescription
        CreatedBy = $CreatedBy
        InstanceID = $InstanceID
        TicketSeverityID = $severityID
        AssignedTo = $AssignedTo
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Manual ticket created. TicketID: $($result.TicketID), Number: $($result.TicketNumber)"
        return $result
    }
    catch {
        Write-MonitorLog "Error creating manual ticket: $_" -Level Error
        throw
    }
}

function Get-Ticket {
    <#
    .SYNOPSIS
    Retrieves tickets based on filters
    
    .PARAMETER TicketID
    Specific Ticket ID to retrieve
    
    .PARAMETER TicketNumber
    Specific Ticket Number to retrieve (e.g., TKT-2026-0001)
    
    .PARAMETER AssignedTo
    Filter by assigned person
    
    .PARAMETER Status
    Filter by status: New, Acknowledged, In Progress, Resolved, Closed, Reopened
    
    .PARAMETER Severity
    Filter by severity: Critical, High, Medium, Low
    
    .PARAMETER InstanceID
    Filter by monitored instance
    
    .PARAMETER IncludeClosed
    Include closed tickets in results
    
    .EXAMPLE
    Get-Ticket -AssignedTo "JohnDoe" -Status "New"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [bigint]$TicketID = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$TicketNumber = $null,
        
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null,
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("", "New", "Acknowledged", "In Progress", "Resolved", "Closed", "Reopened")]
        [string]$Status = "",
        
        [Parameter(Mandatory = $false)]
        [ValidateSet("", "Critical", "High", "Medium", "Low")]
        [string]$Severity = "",
        
        [Parameter(Mandatory = $false)]
        [int]$InstanceID = $null,
        
        [Parameter(Mandatory = $false)]
        [bool]$IncludeClosed = $false
    )
    
    $config = Get-TicketSystemConfig
    
    # Map status name to ID
    $statusMap = @{
        "New" = 1
        "Acknowledged" = 2
        "In Progress" = 3
        "Resolved" = 4
        "Closed" = 5
        "Reopened" = 6
    }
    
    # Map severity name to ID
    $severityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    $statusID = if ($Status -and $Status -ne "") { $statusMap[$Status] } else { $null }
    $severityID = if ($Severity -and $Severity -ne "") { $severityMap[$Severity] } else { $null }
    
    if ($TicketID -or $TicketNumber) {
        $query = "SELECT * FROM [mon].[vw_TicketDetails] WHERE"
        if ($TicketID) {
            $query += " TicketID = @TicketID"
            $parameters = @{ TicketID = $TicketID }
        }
        else {
            $query += " TicketNumber = @TicketNumber"
            $parameters = @{ TicketNumber = $TicketNumber }
        }
    }
    else {
        $query = "EXEC [mon].[usp_GetTickets] @AssignedTo, @TicketStatusID, @TicketSeverityID, @InstanceID, @IncludeClosed"
        $parameters = @{
            AssignedTo = $AssignedTo
            TicketStatusID = $statusID
            TicketSeverityID = $severityID
            InstanceID = $InstanceID
            IncludeClosed = if ($IncludeClosed) { 1 } else { 0 }
        }
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving tickets: $_" -Level Error
        throw
    }
}

function Acknowledge-Ticket {
    <#
    .SYNOPSIS
    Acknowledges a ticket
    
    .PARAMETER TicketID
    ID of the ticket to acknowledge
    
    .PARAMETER AcknowledgedBy
    Person acknowledging the ticket
    
    .EXAMPLE
    Acknowledge-Ticket -TicketID 1 -AcknowledgedBy "JohnDoe"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bigint]$TicketID,
        
        [Parameter(Mandatory = $false)]
        [string]$AcknowledgedBy = $env:USERNAME
    )
    
    $config = Get-TicketSystemConfig
    
    $query = @"
EXEC [mon].[usp_AcknowledgeTicket]
    @TicketID = @TicketID,
    @AcknowledgedBy = @AcknowledgedBy
"@
    
    $parameters = @{
        TicketID = $TicketID
        AcknowledgedBy = $AcknowledgedBy
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Ticket $TicketID acknowledged by $AcknowledgedBy."
        return $result
    }
    catch {
        Write-MonitorLog "Error acknowledging ticket: $_" -Level Error
        throw
    }
}

function Resolve-Ticket {
    <#
    .SYNOPSIS
    Resolves a ticket
    
    .PARAMETER TicketID
    ID of the ticket to resolve
    
    .PARAMETER ResolvedBy
    Person resolving the ticket
    
    .PARAMETER ResolutionNotes
    Notes describing the resolution
    
    .EXAMPLE
    Resolve-Ticket -TicketID 1 -ResolvedBy "JohnDoe" -ResolutionNotes "Fixed by restarting service"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bigint]$TicketID,
        
        [Parameter(Mandatory = $false)]
        [string]$ResolvedBy = $env:USERNAME,
        
        [Parameter(Mandatory = $true)]
        [string]$ResolutionNotes
    )
    
    $config = Get-TicketSystemConfig
    
    $query = @"
EXEC [mon].[usp_ResolveTicket]
    @TicketID = @TicketID,
    @ResolvedBy = @ResolvedBy,
    @ResolutionNotes = @ResolutionNotes
"@
    
    $parameters = @{
        TicketID = $TicketID
        ResolvedBy = $ResolvedBy
        ResolutionNotes = $ResolutionNotes
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Ticket $TicketID resolved by $ResolvedBy."
        return $result
    }
    catch {
        Write-MonitorLog "Error resolving ticket: $_" -Level Error
        throw
    }
}

function Add-TicketComment {
    <#
    .SYNOPSIS
    Adds a comment to a ticket
    
    .PARAMETER TicketID
    ID of the ticket to comment on
    
    .PARAMETER CommentText
    Comment text
    
    .PARAMETER CreatedBy
    Person adding the comment
    
    .EXAMPLE
    Add-TicketComment -TicketID 1 -CommentText "Investigating the issue" -CreatedBy "JohnDoe"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bigint]$TicketID,
        
        [Parameter(Mandatory = $true)]
        [string]$CommentText,
        
        [Parameter(Mandatory = $false)]
        [string]$CreatedBy = $env:USERNAME
    )
    
    $config = Get-TicketSystemConfig
    
    $query = @"
EXEC [mon].[usp_AddTicketComment]
    @TicketID = @TicketID,
    @CommentText = @CommentText,
    @CreatedBy = @CreatedBy
"@
    
    $parameters = @{
        TicketID = $TicketID
        CommentText = $CommentText
        CreatedBy = $CreatedBy
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Comment added to Ticket $TicketID."
        return $result
    }
    catch {
        Write-MonitorLog "Error adding ticket comment: $_" -Level Error
        throw
    }
}

function Get-TicketComments {
    <#
    .SYNOPSIS
    Retrieves comments for a specific ticket
    
    .PARAMETER TicketID
    ID of the ticket
    
    .EXAMPLE
    Get-TicketComments -TicketID 1
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bigint]$TicketID
    )
    
    $config = Get-TicketSystemConfig
    
    $query = "SELECT * FROM [mon].[vw_TicketComments] WHERE TicketID = @TicketID ORDER BY CreatedDate"
    $parameters = @{ TicketID = $TicketID }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving ticket comments: $_" -Level Error
        throw
    }
}

function Get-UnacknowledgedTickets {
    <#
    .SYNOPSIS
    Retrieves all unacknowledged tickets (New status)
    
    .PARAMETER AssignedTo
    Filter by assigned person
    
    .EXAMPLE
    Get-UnacknowledgedTickets
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$AssignedTo = $null
    )
    
    $config = Get-TicketSystemConfig
    
    $query = "SELECT * FROM [mon].[vw_UnacknowledgedTickets]"
    if ($AssignedTo) {
        $query += " WHERE AssignedTo = @AssignedTo"
        $parameters = @{ AssignedTo = $AssignedTo }
    }
    else {
        $parameters = @{}
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving unacknowledged tickets: $_" -Level Error
        throw
    }
}

function Get-TicketsPendingEscalation {
    <#
    .SYNOPSIS
    Retrieves tickets that are pending escalation based on configured rules
    
    .EXAMPLE
    Get-TicketsPendingEscalation
    #>
    [CmdletBinding()]
    param()
    
    $config = Get-TicketSystemConfig
    
    $query = "SELECT * FROM [mon].[vw_TicketsPendingEscalation]"
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters @{}
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving tickets pending escalation: $_" -Level Error
        throw
    }
}

# Export module functions
Export-ModuleMember -Function New-TicketFromAlert, New-ManualTicket, Get-Ticket, 
                              Acknowledge-Ticket, Resolve-Ticket, Add-TicketComment, 
                              Get-TicketComments, Get-UnacknowledgedTickets, 
                              Get-TicketsPendingEscalation
