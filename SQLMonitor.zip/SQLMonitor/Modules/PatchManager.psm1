# PatchManager.psm1
# SQL Server patch-status evaluation using official Microsoft release metadata

$commonModulePath = Join-Path $PSScriptRoot 'Common.psm1'
if (-not (Get-Module -Name Common)) {
    Import-Module $commonModulePath -Global -WarningAction SilentlyContinue
}

$script:SqlServerPatchCatalogCache = $null
$script:SqlServerPatchCatalogCacheFetchedAt = $null
$script:SqlServerPatchCatalogUrl = 'https://raw.githubusercontent.com/MicrosoftDocs/SupportArticles-docs/main/support/sql/releases/download-and-install-latest-updates.md'

function Get-SQLServerPatchInfo {
    <#
    .SYNOPSIS
        Gets current SQL Server patch information for an instance.
    .DESCRIPTION
        Runs version discovery against the selected SQL Server instance and
        compares the current build with the official Microsoft SQL Server build
        catalog to produce a structured patch status.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Instance
    )

    try {
        Write-MonitorLog "Getting patch info for $($Instance.DisplayName)"

        $versionQuery = @"
SELECT
    CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(128)) AS ProductVersion,
    CAST(SERVERPROPERTY('ProductLevel') AS nvarchar(128)) AS ProductLevel,
    CAST(SERVERPROPERTY('Edition') AS nvarchar(256)) AS Edition,
    @@VERSION AS FullVersion
"@

        $versionInfo = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database 'master' -Query $versionQuery
        if ($versionInfo.Rows.Count -eq 0) {
            throw "Could not retrieve version information from $($Instance.SqlInstance)"
        }

        $currentVersion = $versionInfo.Rows[0]
        $productVersion = [string]$currentVersion.ProductVersion
        $productLevel = [string]$currentVersion.ProductLevel
        $edition = [string]$currentVersion.Edition
        $fullVersion = [string]$currentVersion.FullVersion

        $normalizedVersion = ConvertTo-SqlServerVersion -VersionString $productVersion
        $versionMeta = Get-SqlServerVersionMetadata -ProductVersion $productVersion
        $releaseCatalog = @()
        try {
            $releaseCatalog = @(Get-SQLServerBuildCatalog -VersionName $versionMeta.VersionName)
        }
        catch {
            Write-MonitorLog "WARNING continuing without online patch catalog for $($Instance.DisplayName): $($_.Exception.Message)" -Level 'Warning'
            $releaseCatalog = @()
        }

        $analysis = Resolve-SQLServerPatchAnalysis `
            -CurrentVersion $normalizedVersion `
            -ProductLevel $productLevel `
            -ReleaseCatalog $releaseCatalog

        $versionParts = $productVersion -split '\.'
        $currentBuild = if ($versionParts.Count -ge 3) { [int]$versionParts[2] } else { 0 }
        $currentRevision = if ($versionParts.Count -ge 4) { [int]$versionParts[3] } else { 0 }

        $patchInfo = [PSCustomObject]@{
            InstanceName         = $Instance.DisplayName
            SqlInstance          = $Instance.SqlInstance
            VersionName          = $versionMeta.VersionName
            ProductVersion       = $productVersion
            ProductLevel         = $productLevel
            Edition              = $edition
            FullVersion          = $fullVersion
            CurrentBuild         = $currentBuild
            CurrentRevision      = $currentRevision
            CurrentBuildVersion  = $normalizedVersion.ToString()
            CurrentUpdate        = $analysis.CurrentUpdate
            CurrentPatchKB       = $analysis.CurrentPatchKB
            CurrentPatchBuild    = $analysis.CurrentPatchBuild
            CurrentChannel       = $analysis.CurrentChannel
            PatchStatus          = $analysis.PatchStatus
            StatusSummary        = $analysis.StatusSummary
            LatestCumulativeUpdate = $analysis.LatestCumulativeUpdate
            LatestCumulativeUpdateKB = if ($analysis.LatestCumulativeUpdate) { $analysis.LatestCumulativeUpdate.KBNumber } else { '' }
            LatestCumulativeUpdateBuild = if ($analysis.LatestCumulativeUpdate) { $analysis.LatestCumulativeUpdate.BuildVersion } else { '' }
            LatestSecurityUpdate = $analysis.LatestSecurityUpdate
            LatestSecurityUpdateKB = if ($analysis.LatestSecurityUpdate) { $analysis.LatestSecurityUpdate.KBNumber } else { '' }
            LatestSecurityUpdateBuild = if ($analysis.LatestSecurityUpdate) { $analysis.LatestSecurityUpdate.BuildVersion } else { '' }
            RecommendedPatch     = $analysis.RecommendedPatch
            RecommendedKB        = if ($analysis.RecommendedPatch) { $analysis.RecommendedPatch.KBNumber } else { '' }
            RecommendedBuild     = if ($analysis.RecommendedPatch) { $analysis.RecommendedPatch.BuildVersion } else { '' }
            LatestPatchKB        = $analysis.LatestPatchKB
            LatestPatchBuild     = $analysis.LatestPatchBuild
            LatestPatchLabel     = $analysis.LatestPatchLabel
            AvailablePatches     = @($analysis.AvailablePatches)
            LastChecked          = Get-Date
            OfficialCatalogUrl   = $script:SqlServerPatchCatalogUrl
        }

        Write-MonitorLog "Retrieved patch info for $($Instance.DisplayName): $($versionMeta.VersionName) ($productVersion) status=$($analysis.PatchStatus)"
        return $patchInfo
    }
    catch {
        Write-MonitorLog "ERROR in Get-SQLServerPatchInfo for $($Instance.DisplayName): $($_.Exception.Message)" -Level 'Error'
        throw
    }
}

function Get-SQLServerPatchStatus {
    <#
    .SYNOPSIS
        Gets patch status for one or more monitored SQL Server instances.
    #>
    param(
        [Parameter(Mandatory = $false)]
        [object[]]$Instances
    )

    $allPatchInfo = @()

    try {
        $instancesToProcess = @()
        if ($Instances -and $Instances.Count -gt 0) {
            $instancesToProcess = @($Instances)
        }
        else {
            $instancesToProcess = @(Get-SqlMonitorInstances | Where-Object { $_.IsActive })
        }

        foreach ($instance in $instancesToProcess) {
            $allPatchInfo += Get-SQLServerPatchInfo -Instance $instance
        }

        Write-MonitorLog "Retrieved patch status for $($allPatchInfo.Count) instances"
        return $allPatchInfo
    }
    catch {
        Write-MonitorLog "ERROR in Get-SQLServerPatchStatus: $($_.Exception.Message)" -Level 'Error'
        throw
    }
}

function Get-SQLServerBuildCatalog {
    param(
        [Parameter(Mandatory = $true)]
        [string]$VersionName
    )

    $catalog = @(Get-SQLServerOfficialBuildCatalog -VersionName $VersionName)
    return @($catalog | Where-Object { $_.VersionName -eq $VersionName })
}

function Get-SQLServerOfficialBuildCatalog {
    param(
        [string]$VersionName = ''
    )

    $cacheTtlMinutes = 360
    if ($script:SqlServerPatchCatalogCache -and $script:SqlServerPatchCatalogCacheFetchedAt) {
        if ($script:SqlServerPatchCatalogCacheFetchedAt.AddMinutes($cacheTtlMinutes) -gt (Get-Date)) {
            return $script:SqlServerPatchCatalogCache
        }
    }

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $headers = @{
            'User-Agent' = 'SQLMonitor/1.0'
            'Accept'     = 'text/plain,text/markdown,*/*'
        }

        $catalog = @()
        $errors = @()
        foreach ($catalogUrl in @(Get-SqlServerBuildCatalogUrls -VersionName $VersionName)) {
            try {
                Write-MonitorLog "Downloading official SQL Server build catalog from $catalogUrl"
                $response = Invoke-WebRequest -Uri $catalogUrl -Headers $headers -UseBasicParsing -TimeoutSec 60
                if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) {
                    throw "Unexpected HTTP status $($response.StatusCode)"
                }

                $catalog += @(ConvertFrom-SqlServerBuildCatalogMarkdown -Markdown $response.Content -DefaultVersionName $VersionName)
                if ($catalog.Count -gt 0) {
                    break
                }
            }
            catch {
                $errors += "$catalogUrl => $($_.Exception.Message)"
            }
        }

        if ($catalog.Count -eq 0) {
            throw "The official SQL Server build catalog did not return any parseable rows. $($errors -join '; ')"
        }

        $script:SqlServerPatchCatalogCache = $catalog
        $script:SqlServerPatchCatalogCacheFetchedAt = Get-Date
        return $catalog
    }
    catch {
        Write-MonitorLog "ERROR retrieving official SQL Server build catalog: $($_.Exception.Message)" -Level 'Error'
        throw
    }
}

function Get-SqlServerBuildCatalogUrls {
    param(
        [string]$VersionName = ''
    )

    $versionPathMap = @{
        'SQL Server 2022'    = 'sqlserver-2022/build-versions.md'
        'SQL Server 2019'    = 'sqlserver-2019/build-versions.md'
        'SQL Server 2017'    = 'sqlserver-2017/build-versions.md'
        'SQL Server 2016'    = 'sqlserver-2016/build-versions.md'
        'SQL Server 2014'    = 'sqlserver-2014/build-versions.md'
        'SQL Server 2012'    = 'sqlserver-2012/build-versions.md'
        'SQL Server 2008 R2' = 'sqlserver-2008r2/build-versions.md'
        'SQL Server 2008'    = 'sqlserver-2008/build-versions.md'
    }

    $urls = @()
    if ($versionPathMap.ContainsKey($VersionName)) {
        $learnPath = ($versionPathMap[$VersionName] -replace '\.md$', '')
        $urls += "https://learn.microsoft.com/en-us/troubleshoot/sql/releases/$learnPath"
        $urls += "https://raw.githubusercontent.com/MicrosoftDocs/SupportArticles-docs/main/support/sql/releases/$($versionPathMap[$VersionName])"
    }
    $urls += $script:SqlServerPatchCatalogUrl
    return @($urls | Select-Object -Unique)
}

function ConvertFrom-SqlServerBuildCatalogMarkdown {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Markdown,

        [string]$DefaultVersionName = ''
    )

    if ($Markdown -match '(?i)<table|<td>|<tr') {
        return @(ConvertFrom-SqlServerBuildCatalogHtml -Html $Markdown -DefaultVersionName $DefaultVersionName)
    }

    $rows = @()
    $versionName = if ([string]::IsNullOrWhiteSpace($DefaultVersionName)) { $null } else { $DefaultVersionName }
    $inTable = $false
    $tableMode = ''
    $sectionChannel = ''
    $headerColumns = @()

    foreach ($line in ($Markdown -split "(`r`n|`n|`r)")) {
        if ($line -match '^#\s+.*?(SQL Server\s+\d{4}(?:\s+R2)?)\s+build versions') {
            $versionName = $matches[1].Trim()
            $inTable = $false
            continue
        }

        if ($line -match '^###\s+(SQL Server .+?)\s*$') {
            $versionName = $matches[1].Trim()
            $inTable = $false
            continue
        }

        if ($line -match '^##\s+SQL Server\s+\d{4}(?:\s+R2)?\s+(.+?)\s*$') {
            $sectionText = $matches[1].Trim()
            $sectionChannel = Get-SqlServerReleaseChannel -ServicePack '' -Update $sectionText
            $inTable = $false
            continue
        }

        if (-not $versionName) {
            continue
        }

        if ($line -match '^\s*Build number or version\s*\|') {
            $inTable = $true
            $tableMode = 'Legacy'
            continue
        }

        if ($line -match '\|' -and $line -match '(?i)SQL Server build version' -and $line -match '(?i)Knowledge Base') {
            $inTable = $true
            $tableMode = 'BuildVersions'
            $headerColumns = @($line.Trim().Trim('|') -split '\|' | ForEach-Object { $_.Trim() })
            continue
        }

        if ($inTable -and $line -match '^\s*---') {
            continue
        }

        if (-not $inTable) {
            continue
        }

        if ([string]::IsNullOrWhiteSpace($line) -or $line -notmatch '\|') {
            $inTable = $false
            continue
        }

        $normalizedLine = $line.Trim()
        $normalizedLine = $normalizedLine.Trim('|')
        $columns = @($normalizedLine -split '\|' | ForEach-Object { $_.Trim() })
        if ($columns.Count -lt 5) {
            continue
        }

        $buildVersion = ''
        $servicePack = ''
        $update = ''
        $kb = ''
        $releaseDate = ''
        $channel = $sectionChannel

        if ($tableMode -eq 'BuildVersions') {
            if ($columns.Count -lt 6) {
                continue
            }
            $update = [string]$columns[0]
            $buildVersion = [string]$columns[1]
            $kbIndex = Get-SqlServerCatalogColumnIndex -Headers $headerColumns -Pattern 'Knowledge Base'
            $dateIndex = Get-SqlServerCatalogColumnIndex -Headers $headerColumns -Pattern 'Release date'
            $kb = if ($kbIndex -ge 0 -and $columns.Count -gt $kbIndex) { [string]$columns[$kbIndex] } else { [string]$columns[5] }
            $releaseDate = if ($dateIndex -ge 0 -and $columns.Count -gt $dateIndex) { [string]$columns[$dateIndex] } elseif ($columns.Count -gt 6) { [string]$columns[6] } else { '' }
            if ([string]::IsNullOrWhiteSpace($channel)) {
                $channel = Get-SqlServerReleaseChannel -ServicePack $servicePack -Update $update
            }
        }
        else {
            $buildVersion = [string]$columns[0]
            $servicePack = [string]$columns[1]
            $update = [string]$columns[2]
            $kb = [string]$columns[3]
            $releaseDate = [string]$columns[4]
            $channel = Get-SqlServerReleaseChannel -ServicePack $servicePack -Update $update
        }

        $normalizedBuild = ConvertTo-SqlServerVersion -VersionString $buildVersion
        $displayLabel = Get-SqlServerDisplayLabel -ServicePack $servicePack -Update $update
        $kbDigits = ($kb -replace '[^\d]', '')

        $rows += [PSCustomObject]@{
            VersionName        = $versionName
            BuildVersion       = $normalizedBuild.ToString()
            SortVersion        = $normalizedBuild
            ServicePack        = $servicePack
            Update             = $update
            DisplayLabel       = $displayLabel
            Channel            = $channel
            KBNumber           = if ($kbDigits) { "KB$kbDigits" } else { '' }
            ReleaseDate        = $releaseDate
            ReleaseDateValue   = ConvertTo-SqlServerReleaseDate -DateText $releaseDate
            SupportUrl         = if ($kbDigits) { "https://support.microsoft.com/help/$kbDigits" } else { '' }
            CatalogUrl         = if ($kbDigits) { "https://www.catalog.update.microsoft.com/Search.aspx?q=KB$kbDigits" } else { '' }
        }
    }

    return @(
        $rows |
            Sort-Object @{ Expression = { $_.SortVersion } ; Descending = $true }, @{ Expression = { $_.ReleaseDateValue } ; Descending = $true }
    )
}

function ConvertFrom-SqlServerBuildCatalogHtml {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Html,

        [string]$DefaultVersionName = ''
    )

    $rows = @()
    $versionName = if ([string]::IsNullOrWhiteSpace($DefaultVersionName)) { $null } else { $DefaultVersionName }
    if ($Html -match '(?is)SQL Server\s+(\d{4}(?:\s+R2)?)\s+build versions') {
        $versionName = "SQL Server $($matches[1])"
    }

    $sectionMatches = [regex]::Matches($Html, '(?is)<h2\b.*?(?=<h2\b|$)')
    if ($sectionMatches.Count -eq 0) {
        $sectionMatches = @([pscustomobject]@{ Value = $Html })
    }

    foreach ($section in $sectionMatches) {
        $sectionHtml = [string]$section.Value
        $sectionText = ConvertFrom-SqlServerHtmlText -Text $sectionHtml
        $sectionChannel = ''
        if ($sectionText -match '(?i)Cumulative Update\s*\(CU\)\s+builds|Cumulative Update.*builds') {
            $sectionChannel = 'CU'
        }
        elseif ($sectionText -match '(?i)\bGDR\b.*builds') {
            $sectionChannel = 'GDR'
        }

        foreach ($rowMatch in [regex]::Matches($sectionHtml, '(?is)<tr\b.*?</tr>')) {
            $cells = @()
            foreach ($cellMatch in [regex]::Matches($rowMatch.Value, '(?is)<t[dh]\b.*?</t[dh]>')) {
                $cells += ConvertFrom-SqlServerHtmlText -Text $cellMatch.Value
            }

            if (-not $versionName -or $cells.Count -lt 6) {
                continue
            }

            $firstCell = [string]$cells[0]
            if ($firstCell -match '(?i)cumulative update name|gdr name') {
                continue
            }

            $buildVersion = [string]$cells[1]
            if ($buildVersion -notmatch '^\d+\.\d+\.\d+\.\d+$') {
                continue
            }

            $update = $firstCell
            $kb = [string]$cells[5]
            $releaseDate = if ($cells.Count -gt 6) { [string]$cells[6] } else { '' }
            $normalizedBuild = ConvertTo-SqlServerVersion -VersionString $buildVersion
            $channel = if ([string]::IsNullOrWhiteSpace($sectionChannel)) { Get-SqlServerReleaseChannel -ServicePack '' -Update $update } else { $sectionChannel }
            $kbDigits = ($kb -replace '[^\d]', '')

            $rows += [PSCustomObject]@{
                VersionName        = $versionName
                BuildVersion       = $normalizedBuild.ToString()
                SortVersion        = $normalizedBuild
                ServicePack        = ''
                Update             = $update
                DisplayLabel       = Get-SqlServerDisplayLabel -ServicePack '' -Update $update
                Channel            = $channel
                KBNumber           = if ($kbDigits) { "KB$kbDigits" } else { '' }
                ReleaseDate        = $releaseDate
                ReleaseDateValue   = ConvertTo-SqlServerReleaseDate -DateText $releaseDate
                SupportUrl         = if ($kbDigits) { "https://support.microsoft.com/help/$kbDigits" } else { '' }
                CatalogUrl         = if ($kbDigits) { "https://www.catalog.update.microsoft.com/Search.aspx?q=KB$kbDigits" } else { '' }
            }
        }
    }

    return @(
        $rows |
            Sort-Object @{ Expression = { $_.SortVersion } ; Descending = $true }, @{ Expression = { $_.ReleaseDateValue } ; Descending = $true }
    )
}

function ConvertFrom-SqlServerHtmlText {
    param(
        [string]$Text
    )

    $value = [regex]::Replace([string]$Text, '<[^>]+>', '')
    return [System.Net.WebUtility]::HtmlDecode($value).Trim()
}

function Get-SqlServerCatalogColumnIndex {
    param(
        [string[]]$Headers,
        [string]$Pattern
    )

    for ($i = 0; $i -lt $Headers.Count; $i++) {
        if ($Headers[$i] -match $Pattern) {
            return $i
        }
    }
    return -1
}

function Resolve-SQLServerPatchAnalysis {
    param(
        [Parameter(Mandatory = $true)]
        [Version]$CurrentVersion,

        [Parameter(Mandatory = $true)]
        [string]$ProductLevel,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [object[]]$ReleaseCatalog
    )

    if ($ReleaseCatalog.Count -eq 0) {
        return [PSCustomObject]@{
            CurrentUpdate           = $ProductLevel
            CurrentPatchKB          = ''
            CurrentPatchBuild       = $CurrentVersion.ToString()
            CurrentChannel          = Resolve-SqlServerServicingChannel -ProductLevel $ProductLevel
            PatchStatus             = 'MetadataUnavailable'
            StatusSummary           = 'Official Microsoft release metadata could not be resolved for this SQL Server version.'
            LatestCumulativeUpdate  = $null
            LatestSecurityUpdate    = $null
            RecommendedPatch        = $null
            LatestPatchKB           = ''
            LatestPatchBuild        = ''
            LatestPatchLabel        = ''
            AvailablePatches        = @()
        }
    }

    $currentRelease = $ReleaseCatalog | Where-Object { $_.SortVersion -eq $CurrentVersion } | Select-Object -First 1
    $currentChannel = if ($currentRelease) {
        $currentRelease.Channel
    }
    else {
        Resolve-SqlServerServicingChannel -ProductLevel $ProductLevel
    }

    $latestCu = $ReleaseCatalog | Where-Object { $_.Channel -eq 'CU' } | Select-Object -First 1
    $latestGdr = $ReleaseCatalog | Where-Object { $_.Channel -eq 'GDR' } | Select-Object -First 1
    $latestAny = $ReleaseCatalog | Select-Object -First 1

    $availablePatches = @()
    switch ($currentChannel) {
        'CU' {
            $availablePatches = @($ReleaseCatalog | Where-Object { $_.Channel -in @('CU', 'GDR') -and $_.SortVersion -gt $CurrentVersion })
        }
        'GDR' {
            $availablePatches = @($ReleaseCatalog | Where-Object { $_.Channel -eq 'GDR' -and $_.SortVersion -gt $CurrentVersion })
        }
        default {
            $availablePatches = @(
                @($latestGdr, $latestCu) |
                    Where-Object { $_ -and $_.SortVersion -gt $CurrentVersion } |
                    Sort-Object @{ Expression = { $_.SortVersion } ; Descending = $true } |
                    Group-Object BuildVersion |
                    ForEach-Object { $_.Group | Select-Object -First 1 }
            )
        }
    }

    $recommendedPatch = $availablePatches | Select-Object -First 1

    $patchStatus = 'UpToDate'
    $statusSummary = ''
    if ($recommendedPatch) {
        $patchStatus = 'UpdateAvailable'
        $statusSummary = "Current build $($CurrentVersion.ToString()) is behind the recommended $($recommendedPatch.DisplayLabel) $($recommendedPatch.KBNumber) ($($recommendedPatch.BuildVersion))."
    }
    elseif ($currentRelease) {
        $statusSummary = "Current build matches Microsoft catalog entry $($currentRelease.DisplayLabel) $($currentRelease.KBNumber)."
    }
    else {
        $patchStatus = 'Unknown'
        $statusSummary = "Current build $($CurrentVersion.ToString()) was not found exactly in the official build catalog. No newer patch in the inferred servicing channel was detected."
    }

    return [PSCustomObject]@{
        CurrentUpdate           = if ($currentRelease) { $currentRelease.DisplayLabel } else { $ProductLevel }
        CurrentPatchKB          = if ($currentRelease) { $currentRelease.KBNumber } else { '' }
        CurrentPatchBuild       = if ($currentRelease) { $currentRelease.BuildVersion } else { $CurrentVersion.ToString() }
        CurrentChannel          = $currentChannel
        PatchStatus             = $patchStatus
        StatusSummary           = $statusSummary
        LatestCumulativeUpdate  = $latestCu
        LatestSecurityUpdate    = $latestGdr
        RecommendedPatch        = $recommendedPatch
        LatestPatchKB           = if ($recommendedPatch) { $recommendedPatch.KBNumber } elseif ($latestAny) { $latestAny.KBNumber } else { '' }
        LatestPatchBuild        = if ($recommendedPatch) { $recommendedPatch.BuildVersion } elseif ($latestAny) { $latestAny.BuildVersion } else { '' }
        LatestPatchLabel        = if ($recommendedPatch) { $recommendedPatch.DisplayLabel } elseif ($latestAny) { $latestAny.DisplayLabel } else { '' }
        AvailablePatches        = @($availablePatches)
    }
}

function Get-SqlServerVersionMetadata {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ProductVersion
    )

    $parts = $ProductVersion -split '\.'
    $majorVersion = if ($parts.Count -gt 0) { [int]$parts[0] } else { 0 }
    $minorVersion = if ($parts.Count -gt 1) { [int]$parts[1] } else { 0 }

    $versionName = switch ($majorVersion) {
        17 { 'SQL Server 2025' }
        16 { 'SQL Server 2022' }
        15 { 'SQL Server 2019' }
        14 { 'SQL Server 2017' }
        13 { 'SQL Server 2016' }
        12 { 'SQL Server 2014' }
        11 { 'SQL Server 2012' }
        10 {
            if ($minorVersion -eq 50) { 'SQL Server 2008 R2' } else { 'SQL Server 2008' }
        }
        default { 'Unknown SQL Server Version' }
    }

    return [PSCustomObject]@{
        MajorVersion = $majorVersion
        MinorVersion = $minorVersion
        VersionName  = $versionName
    }
}

function ConvertTo-SqlServerVersion {
    param(
        [Parameter(Mandatory = $true)]
        [string]$VersionString
    )

    $parts = @($VersionString -split '\.' | Where-Object { $_ -ne '' })
    while ($parts.Count -lt 4) {
        $parts += '0'
    }

    return [Version]::new([int]$parts[0], [int]$parts[1], [int]$parts[2], [int]$parts[3])
}

function ConvertTo-SqlServerReleaseDate {
    param(
        [string]$DateText
    )

    $parsedDate = [datetime]::MinValue
    if ([datetime]::TryParse($DateText, [ref]$parsedDate)) {
        return $parsedDate
    }

    return [datetime]::MinValue
}

function Get-SqlServerDisplayLabel {
    param(
        [string]$ServicePack,
        [string]$Update
    )

    $servicePackText = if ($ServicePack -and $ServicePack -notin @('None', 'NA', 'N/A')) { $ServicePack.Trim() } else { '' }
    $updateText = if ($Update -and $Update -notin @('None', 'NA', 'N/A')) { $Update.Trim() } else { '' }

    if ($servicePackText -and $updateText) {
        return "$servicePackText $updateText"
    }
    if ($updateText) {
        return $updateText
    }
    if ($servicePackText) {
        return $servicePackText
    }
    return 'Unknown'
}

function Get-SqlServerReleaseChannel {
    param(
        [string]$ServicePack,
        [string]$Update
    )

    $combined = ((Get-SqlServerDisplayLabel -ServicePack $ServicePack -Update $Update).ToUpperInvariant())
    if ($combined -match '\bGDR\b') { return 'GDR' }
    if ($combined -match '\bCU\d+\b') { return 'CU' }
    if ($combined -match '\bRTM\b|\bGA\b') { return 'RTM' }
    if ($combined -match '\bSP\d+\b') { return 'GDR' }
    return 'Unknown'
}

function Resolve-SqlServerServicingChannel {
    param(
        [string]$ProductLevel
    )

    $normalized = [string]$ProductLevel
    if ($normalized -match '(?i)\bCU\b|\bCU\d+\b') { return 'CU' }
    if ($normalized -match '(?i)\bGDR\b') { return 'GDR' }
    if ($normalized -match '(?i)\bRTM\b|\bSP\d+\b') { return 'GDR' }
    return 'Unknown'
}

# Export functions
Export-ModuleMember -Function Get-SQLServerPatchInfo, Get-SQLServerPatchStatus, Get-SQLServerBuildCatalog
