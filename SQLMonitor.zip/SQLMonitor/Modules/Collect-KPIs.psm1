function Invoke-KPIsCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    # Validate instance parameter
    if ($null -eq $Instance) {
        throw "Instance parameter is null"
    }

    if (-not $Instance.SqlInstance) {
        throw "Instance.SqlInstance is null or empty for DisplayName: $($Instance.DisplayName)"
    }

    $moduleName = "KPIs"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "KPI collector started for $($Instance.DisplayName)"

        $query = @"
SELECT 
    cpu_count as visibleCPUs,
    CAST(available_physical_memory_kb / 1024.0 as bigint) as availablePhysicalMemoryMB,
    CAST(total_physical_memory_kb / 1024.0 as bigint) as totalPhysicalMemoryMB
FROM sys.dm_os_sys_info, sys.dm_os_sys_memory
"@

        Write-MonitorLog "KPI query: $($query.Length) characters"
        Write-MonitorLog "DEBUG KPI Query: $($query -replace "`r?`n", ' | ')"
        $kpiData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query
        
        if ($kpiData.Rows.Count -gt 0) {
            $sourceRow = $kpiData.Rows[0]
            $columns = @(Get-MonitorTableColumns -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -TableName 'mon.KPIHistory')
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add('InstanceID', [int])
            [void]$targetTable.Columns.Add('CaptureTime', [datetime])
            if ($columns -contains 'PageLifeExpectancy') { [void]$targetTable.Columns.Add('PageLifeExpectancy', [long]) }
            if ($columns -contains 'BufferCacheHitRatio') { [void]$targetTable.Columns.Add('BufferCacheHitRatio', [double]) }
            if ($columns -contains 'AvailablePhysicalMemoryMB') { [void]$targetTable.Columns.Add('AvailablePhysicalMemoryMB', [long]) }
            if ($columns -contains 'TotalPhysicalMemoryMB') { [void]$targetTable.Columns.Add('TotalPhysicalMemoryMB', [long]) }
            if ($columns -contains 'ProcessMemoryMB') { [void]$targetTable.Columns.Add('ProcessMemoryMB', [long]) }
            if ($columns -contains 'VisibleOnlineCPUs') { [void]$targetTable.Columns.Add('VisibleOnlineCPUs', [int]) }
            if ($columns -contains 'MAXDOP') { [void]$targetTable.Columns.Add('MAXDOP', [int]) }
            elseif ($columns -contains 'MaxDOP') { [void]$targetTable.Columns.Add('MaxDOP', [int]) }
            if ($columns -contains 'CostThresholdForParallelism') { [void]$targetTable.Columns.Add('CostThresholdForParallelism', [int]) }
            if ($columns -contains 'MaxServerMemoryMB') { [void]$targetTable.Columns.Add('MaxServerMemoryMB', [int]) }
            if ($columns -contains 'MinServerMemoryMB') { [void]$targetTable.Columns.Add('MinServerMemoryMB', [int]) }

            $newRow = $targetTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime](Get-Date)
            if ($targetTable.Columns.Contains('PageLifeExpectancy')) { $newRow["PageLifeExpectancy"] = 0 }
            if ($targetTable.Columns.Contains('BufferCacheHitRatio')) { $newRow["BufferCacheHitRatio"] = 0.0 }
            if ($targetTable.Columns.Contains('AvailablePhysicalMemoryMB')) { $newRow["AvailablePhysicalMemoryMB"] = if ($sourceRow['availablePhysicalMemoryMB'] -is [System.DBNull]) { 0 } else { [long]$sourceRow['availablePhysicalMemoryMB'] } }
            if ($targetTable.Columns.Contains('TotalPhysicalMemoryMB')) { $newRow["TotalPhysicalMemoryMB"] = if ($sourceRow['totalPhysicalMemoryMB'] -is [System.DBNull]) { 0 } else { [long]$sourceRow['totalPhysicalMemoryMB'] } }
            if ($targetTable.Columns.Contains('ProcessMemoryMB')) { $newRow["ProcessMemoryMB"] = 0 }
            if ($targetTable.Columns.Contains('VisibleOnlineCPUs')) { $newRow["VisibleOnlineCPUs"] = if ($sourceRow['visibleCPUs'] -is [System.DBNull]) { 0 } else { [int]$sourceRow['visibleCPUs'] } }
            if ($targetTable.Columns.Contains('MAXDOP')) { $newRow["MAXDOP"] = 0 }
            if ($targetTable.Columns.Contains('MaxDOP')) { $newRow["MaxDOP"] = 0 }
            if ($targetTable.Columns.Contains('CostThresholdForParallelism')) { $newRow["CostThresholdForParallelism"] = 5 }
            if ($targetTable.Columns.Contains('MaxServerMemoryMB')) { $newRow["MaxServerMemoryMB"] = 0 }
            if ($targetTable.Columns.Contains('MinServerMemoryMB')) { $newRow["MinServerMemoryMB"] = 0 }
            
            $targetTable.Rows.Add($newRow)

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.KPIHistory" `
                -DataTable $targetTable

            Write-MonitorLog "KPI collector completed for $($Instance.DisplayName). Rows inserted: 1"
        }
        
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-KPIsCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-KPIsCollector
