function Invoke-IOCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "IO"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "I/O collector started for $($Instance.DisplayName)"

        # Note: Added schema-aligned column names based on Phase 7 and previous log errors
        $query = @"
        SELECT
            DB_NAME(mf.database_id) as DatabaseName,
            CASE WHEN mf.type = 0 THEN 'DATA' ELSE 'LOG' END as FileType,
            mf.name as LogicalName,
            mf.physical_name as PhysicalName,
            CAST(mf.size * 8 / 1024.0 as decimal(10,2)) as SizeMB,
            CAST(ISNULL(fs.io_stall_read_ms / NULLIF(fs.num_of_reads, 0), 0) as decimal(10,2)) as AvgReadLatencyMs,
            CAST(ISNULL(fs.io_stall_write_ms / NULLIF(fs.num_of_writes, 0), 0) as decimal(10,2)) as AvgWriteLatencyMs,
            CAST(ISNULL(fs.io_stall_read_ms, 0) as bigint) as ReadLatencyStallMs,
            CAST(ISNULL(fs.io_stall_write_ms, 0) as bigint) as WriteLatencyStallMs,
            CAST(ISNULL(fs.io_stall, 0) as bigint) as TotalStallMs
        FROM sys.master_files mf
        LEFT JOIN sys.dm_io_virtual_file_stats(NULL, NULL) fs ON mf.database_id = fs.database_id AND mf.file_id = fs.file_id
        WHERE DB_NAME(mf.database_id) IS NOT NULL
"@

        $ioData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($ioData.Rows.Count -gt 0) {
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add("InstanceID", [int])
            [void]$targetTable.Columns.Add("CaptureTime", [datetime])
            [void]$targetTable.Columns.Add("DatabaseName", [string])
            [void]$targetTable.Columns.Add("FileType", [string])
            [void]$targetTable.Columns.Add("LogicalName", [string])
            [void]$targetTable.Columns.Add("PhysicalName", [string])
            [void]$targetTable.Columns.Add("SizeMB", [decimal])
            [void]$targetTable.Columns.Add("AvgReadMS", [decimal])
            [void]$targetTable.Columns.Add("AvgWriteMS", [decimal])
            [void]$targetTable.Columns.Add("TotalStallMS", [long])

            $captureTime = [datetime]::Now

            foreach ($row in $ioData.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow["InstanceID"] = $instanceId
                $newRow["CaptureTime"] = $captureTime
                $newRow["DatabaseName"] = if ($row["DatabaseName"] -is [DBNull]) { $null } else { [string]$row["DatabaseName"] }
                $newRow["FileType"] = if ($row["FileType"] -is [DBNull]) { $null } else { [string]$row["FileType"] }
                $newRow["LogicalName"] = if ($row["LogicalName"] -is [DBNull]) { $null } else { [string]$row["LogicalName"] }
                $newRow["PhysicalName"] = if ($row["PhysicalName"] -is [DBNull]) { $null } else { [string]$row["PhysicalName"] }
                $newRow["SizeMB"] = if ($row["SizeMB"] -is [DBNull]) { $null } else { [decimal]$row["SizeMB"] }
                $newRow["AvgReadMS"] = if ($row["AvgReadLatencyMs"] -is [DBNull]) { $null } else { [decimal]$row["AvgReadLatencyMs"] }
                $newRow["AvgWriteMS"] = if ($row["AvgWriteLatencyMs"] -is [DBNull]) { $null } else { [decimal]$row["AvgWriteLatencyMs"] }
                $newRow["TotalStallMS"] = if ($row["TotalStallMs"] -is [DBNull]) { $null } else { [long]$row["TotalStallMs"] }
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.IOFileHistory" `
                -DataTable $targetTable

            Write-MonitorLog "I/O collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-IOCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-IOCollector
