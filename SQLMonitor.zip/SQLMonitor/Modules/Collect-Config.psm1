function Invoke-ConfigCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "Config"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Config collector started for $($Instance.DisplayName)"

        $query = @"
        SELECT
            CAST(SERVERPROPERTY('MachineName') as nvarchar(128)) as MachineName,
            CAST(ISNULL(SERVERPROPERTY('InstanceName'), 'MSSQLSERVER') as nvarchar(128)) as InstanceName,
            CAST(SERVERPROPERTY('ProductVersion') as nvarchar(128)) as ServerVersion,
            CAST(SERVERPROPERTY('Edition') as nvarchar(128)) as Edition,
            CAST(PARSENAME(CAST(SERVERPROPERTY('ProductVersion') as nvarchar(128)), 1) as int) as BuildNumber,
            @@SERVERNAME as ServerName,
            (SELECT cpu_count FROM sys.dm_os_sys_info) as ProcessorCount,
            (SELECT cpu_count FROM sys.dm_os_sys_info) as VisibleOnlineCPUs,
            (SELECT CAST(physical_memory_kb / 1024.0 as bigint) FROM sys.dm_os_sys_info) as PhysicalMemoryMB,
            (SELECT value_in_use FROM sys.configurations WHERE name = 'max server memory (MB)') as MaxServerMemoryMB,
            (SELECT value_in_use FROM sys.configurations WHERE name = 'min server memory (MB)') as MinServerMemoryMB,
            (SELECT value_in_use FROM sys.configurations WHERE name = 'max degree of parallelism') as MAXDOP,
            (SELECT value_in_use FROM sys.configurations WHERE name = 'cost threshold for parallelism') as CostThresholdForParallelism,
            (SELECT value_in_use FROM sys.configurations WHERE name = 'cost threshold for parallelism') as CTLF_Value,
            CAST(NULL as nvarchar(max)) as TraceFlags
"@

        $configData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($configData.Rows.Count -gt 0) {
            $row = $configData.Rows[0]
            $columns = @(Get-MonitorTableColumns -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -TableName 'mon.ConfigHistory')
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add('InstanceID', [int])
            [void]$targetTable.Columns.Add('CaptureTime', [datetime])
            if ($columns -contains 'ConfigName') { [void]$targetTable.Columns.Add('ConfigName', [string]) }
            if ($columns -contains 'ConfigValue') { [void]$targetTable.Columns.Add('ConfigValue', [string]) }
            if ($columns -contains 'ConfigDescription') { [void]$targetTable.Columns.Add('ConfigDescription', [string]) }
            if ($columns -contains 'MachineName') { [void]$targetTable.Columns.Add('MachineName', [string]) }
            if ($columns -contains 'InstanceName') { [void]$targetTable.Columns.Add('InstanceName', [string]) }
            if ($columns -contains 'ServerVersion') { [void]$targetTable.Columns.Add('ServerVersion', [string]) }
            if ($columns -contains 'Edition') { [void]$targetTable.Columns.Add('Edition', [string]) }
            if ($columns -contains 'BuildNumber') { [void]$targetTable.Columns.Add('BuildNumber', [int]) }
            if ($columns -contains 'ProcessorCount') { [void]$targetTable.Columns.Add('ProcessorCount', [int]) }
            if ($columns -contains 'PhysicalMemoryMB') { [void]$targetTable.Columns.Add('PhysicalMemoryMB', [long]) }
            if ($columns -contains 'MaxDOPSetting') { [void]$targetTable.Columns.Add('MaxDOPSetting', [int]) }
            if ($columns -contains 'CostThresholdSetting') { [void]$targetTable.Columns.Add('CostThresholdSetting', [int]) }
            if ($columns -contains 'MaxServerMemorySetting') { [void]$targetTable.Columns.Add('MaxServerMemorySetting', [int]) }
            if ($columns -contains 'MinServerMemorySetting') { [void]$targetTable.Columns.Add('MinServerMemorySetting', [int]) }
            if ($columns -contains 'TraceFlags') { [void]$targetTable.Columns.Add('TraceFlags', [string]) }

            $newRow = $targetTable.NewRow()
            $newRow['InstanceID'] = $instanceId
            $newRow['CaptureTime'] = [datetime](Get-Date)
            if ($targetTable.Columns.Contains('ConfigName')) { $newRow['ConfigName'] = 'ServerConfiguration' }
            if ($targetTable.Columns.Contains('ConfigValue')) { $newRow['ConfigValue'] = "Version=$($row['ServerVersion']); Edition=$($row['Edition']); MAXDOP=$($row['MAXDOP']); CostThreshold=$($row['CostThresholdForParallelism'])" }
            if ($targetTable.Columns.Contains('ConfigDescription')) { $newRow['ConfigDescription'] = 'Current SQL Server configuration summary captured by Config collector.' }
            if ($targetTable.Columns.Contains('MachineName')) { $newRow['MachineName'] = [string]$row['MachineName'] }
            if ($targetTable.Columns.Contains('InstanceName')) { $newRow['InstanceName'] = [string]$row['InstanceName'] }
            if ($targetTable.Columns.Contains('ServerVersion')) { $newRow['ServerVersion'] = [string]$row['ServerVersion'] }
            if ($targetTable.Columns.Contains('Edition')) { $newRow['Edition'] = [string]$row['Edition'] }
            if ($targetTable.Columns.Contains('BuildNumber')) { $newRow['BuildNumber'] = if ($row['BuildNumber'] -is [System.DBNull]) { 0 } else { [int]$row['BuildNumber'] } }
            if ($targetTable.Columns.Contains('ProcessorCount')) { $newRow['ProcessorCount'] = if ($row['ProcessorCount'] -is [System.DBNull]) { 0 } else { [int]$row['ProcessorCount'] } }
            if ($targetTable.Columns.Contains('PhysicalMemoryMB')) { $newRow['PhysicalMemoryMB'] = if ($row['PhysicalMemoryMB'] -is [System.DBNull]) { 0 } else { [long]$row['PhysicalMemoryMB'] } }
            if ($targetTable.Columns.Contains('MaxDOPSetting')) { $newRow['MaxDOPSetting'] = if ($row['MAXDOP'] -is [System.DBNull]) { -1 } else { [int]$row['MAXDOP'] } }
            if ($targetTable.Columns.Contains('CostThresholdSetting')) { $newRow['CostThresholdSetting'] = if ($row['CostThresholdForParallelism'] -is [System.DBNull]) { 5 } else { [int]$row['CostThresholdForParallelism'] } }
            if ($targetTable.Columns.Contains('MaxServerMemorySetting')) { $newRow['MaxServerMemorySetting'] = if ($row['MaxServerMemoryMB'] -is [System.DBNull]) { 0 } else { [int]$row['MaxServerMemoryMB'] } }
            if ($targetTable.Columns.Contains('MinServerMemorySetting')) { $newRow['MinServerMemorySetting'] = if ($row['MinServerMemoryMB'] -is [System.DBNull]) { 0 } else { [int]$row['MinServerMemoryMB'] } }
            if ($targetTable.Columns.Contains('TraceFlags')) { $newRow['TraceFlags'] = if ($row['TraceFlags'] -is [System.DBNull]) { '' } else { [string]$row['TraceFlags'] } }
            $targetTable.Rows.Add($newRow)

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable 'mon.ConfigHistory' `
                -DataTable $targetTable

            Write-MonitorLog "Config collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-ConfigCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-ConfigCollector
