function Invoke-BackupsCollector {
    param(
        [Parameter(Mandatory=$true)]
        [object]$Instance
    )

    $ServerInstance = $Instance.SqlInstance
    $RepositoryServer = $Instance.RepositoryServer
    $RepositoryDatabase = $Instance.RepositoryDatabase
    
    # Look up InstanceID if not present
    $InstanceID = $Instance.InstanceID
    if (-not $InstanceID -or $InstanceID -eq 0) {
        $InstanceID = GetOrCreate-MonitoredInstance -SqlInstance $ServerInstance -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -DisplayName $Instance.DisplayName
    }

    $runId = Start-CollectionRun `
        -RepositoryServer $RepositoryServer `
        -RepositoryDatabase $RepositoryDatabase `
        -InstanceID $InstanceID `
        -ModuleName 'Backups'

    $collectionTime = Get-Date

    try {
        # Query for backup status
        $query = @"
SELECT
    d.name AS DatabaseName,
    CASE d.recovery_model
        WHEN 1 THEN 'FULL'
        WHEN 2 THEN 'BULK_LOGGED'
        WHEN 3 THEN 'SIMPLE'
        ELSE 'UNKNOWN'
    END AS RecoveryModel,
    -- Last full backup
    (SELECT MAX(backup_finish_date)
     FROM msdb.dbo.backupset bs
     WHERE bs.database_name = d.name
     AND bs.type = 'D') AS LastFullBackup,
    DATEDIFF(hour,
        (SELECT MAX(backup_finish_date)
         FROM msdb.dbo.backupset bs
         WHERE bs.database_name = d.name
         AND bs.type = 'D'),
        GETDATE()) AS HoursSinceFullBackup,
    -- Last differential backup
    (SELECT MAX(backup_finish_date)
     FROM msdb.dbo.backupset bs
     WHERE bs.database_name = d.name
     AND bs.type = 'I') AS LastDiffBackup,
    DATEDIFF(hour,
        (SELECT MAX(backup_finish_date)
         FROM msdb.dbo.backupset bs
         WHERE bs.database_name = d.name
         AND bs.type = 'I'),
        GETDATE()) AS HoursSinceDiffBackup,
    -- Last log backup (for FULL/BULK_LOGGED recovery)
    CASE WHEN d.recovery_model IN (1,2) THEN
        (SELECT MAX(backup_finish_date)
         FROM msdb.dbo.backupset bs
         WHERE bs.database_name = d.name
         AND bs.type = 'L')
    ELSE NULL END AS LastLogBackup,
    CASE WHEN d.recovery_model IN (1,2) THEN
        DATEDIFF(hour,
            (SELECT MAX(backup_finish_date)
             FROM msdb.dbo.backupset bs
             WHERE bs.database_name = d.name
             AND bs.type = 'L'),
            GETDATE())
    ELSE NULL END AS HoursSinceLogBackup,
    -- Backup status assessment
    CASE
        WHEN d.name = 'tempdb' THEN 'NOT_APPLICABLE'
        WHEN d.name IN ('master', 'model', 'msdb') THEN 'SYSTEM_OK'
        WHEN d.recovery_model = 3 THEN
            CASE WHEN DATEDIFF(hour,
                ISNULL((SELECT MAX(backup_finish_date)
                       FROM msdb.dbo.backupset bs
                       WHERE bs.database_name = d.name
                       AND bs.type = 'D'), '1900-01-01'), GETDATE()) > 168 THEN 'FULL_OVERDUE'
            ELSE 'FULL_OK' END
        WHEN d.recovery_model IN (1,2) THEN
            CASE WHEN DATEDIFF(hour,
                ISNULL((SELECT MAX(backup_finish_date)
                       FROM msdb.dbo.backupset bs
                       WHERE bs.database_name = d.name
                       AND bs.type = 'D'), '1900-01-01'), GETDATE()) > 168 THEN 'FULL_OVERDUE'
            WHEN DATEDIFF(hour,
                ISNULL((SELECT MAX(backup_finish_date)
                       FROM msdb.dbo.backupset bs
                       WHERE bs.database_name = d.name
                       AND bs.type = 'L'), '1900-01-01'), GETDATE()) > 24 THEN 'LOG_OVERDUE'
            ELSE 'OK' END
        ELSE 'UNKNOWN'
    END AS BackupStatus
FROM sys.databases d
ORDER BY d.name;
"@

        $backupData = Invoke-MonitorSqlQuery -ServerInstance $ServerInstance -Database "master" -Query $query

        if ($null -eq $backupData -or $backupData.Rows.Count -eq 0) {
            Write-MonitorLog -Message "No backup data collected from $ServerInstance" -Level "Warning"
            Stop-CollectionRun `
                -RepositoryServer $RepositoryServer `
                -RepositoryDatabase $RepositoryDatabase `
                -RunID $runId `
                -Status 'Success'
            return
        }

        # Insert into repository (matching existing table schema)
        $insertQuery = @"
INSERT INTO mon.BackupStatusHistory
    (InstanceID, CaptureTime, DatabaseName, LastFullHours, LastDiffHours, LastLogHours, StatusText)
VALUES
"@

        # Helper function to safely convert int to SQL or NULL
        function Get-SqlIntString($value) {
            if ($null -ne $value -and $value -isnot [DBNull]) {
                return $value.ToString()
            }
            return "NULL"
        }
        
        $values = @()
        foreach ($row in $backupData.Rows) {
            $values += "($InstanceID, '$($collectionTime.ToString("yyyy-MM-dd HH:mm:ss"))', " +
                      "'$($row.DatabaseName.Replace("'", "''"))', " +
                      (Get-SqlIntString $row.HoursSinceFullBackup) + ", " +
                      (Get-SqlIntString $row.HoursSinceDiffBackup) + ", " +
                      (Get-SqlIntString $row.HoursSinceLogBackup) + ", " +
                      "'$($row.BackupStatus)')"
        }

        if ($values.Count -gt 0) {
            $insertQuery += ($values -join ", ") + ";"

            Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $insertQuery
        }

        Write-MonitorLog -Message "Collected backup status for $($backupData.Rows.Count) databases from $ServerInstance" -Level "Info"
        Stop-CollectionRun `
            -RepositoryServer $RepositoryServer `
            -RepositoryDatabase $RepositoryDatabase `
            -RunID $runId `
            -Status 'Success'

    } catch {
        Write-MonitorLog -Message "Error collecting backup data from ${ServerInstance}: $($_.Exception.Message)" -Level "Error"
        Stop-CollectionRun `
            -RepositoryServer $RepositoryServer `
            -RepositoryDatabase $RepositoryDatabase `
            -RunID $runId `
            -Status 'Failed' `
            -ErrorMessage $_.Exception.Message
        throw
    }
}

Export-ModuleMember -Function Invoke-BackupsCollector

Export-ModuleMember -Function Invoke-BackupsCollector
