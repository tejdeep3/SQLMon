function Invoke-MonitorSqlQuery {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServerInstance,

        [Parameter(Mandatory = $true)]
        [string]$Database,

        [Parameter(Mandatory = $true)]
        [string]$Query,

        [hashtable]$Parameters = @{},

        [int]$CommandTimeout = 120
    )

    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = $CommandTimeout

    if ($Parameters) {
        foreach ($key in $Parameters.Keys) {
            $val = $Parameters[$key]
            if ($null -eq $val) { $val = [DBNull]::Value }
            if ($val -is [byte[]]) {
                $param = $command.Parameters.Add("@$key", [System.Data.SqlDbType]::VarBinary, $val.Length)
                $param.Value = $val
            }
            else {
                [void]$command.Parameters.AddWithValue("@$key", $val)
            }
        }
    }

    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $command
    $dataset = New-Object System.Data.DataSet

    try {
        Write-MonitorLog "DEBUG Invoke-MonitorSqlQuery server=$ServerInstance database=$Database queryLength=$($Query.Length)"
        Write-MonitorLog "DEBUG Invoke-MonitorSqlQuery query preview: $($Query.Trim() -replace '`r?`n', ' | ')"
        $connection.Open()
        [void]$adapter.Fill($dataset)
        if ($dataset.Tables.Count -gt 0) {
            return ,$dataset.Tables[0]
        }
        return ,(New-Object System.Data.DataTable)
    }
    finally {
        $connection.Close()
        $connection.Dispose()
    }
}

function Invoke-MonitorSqlScalar {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServerInstance,

        [Parameter(Mandatory = $true)]
        [string]$Database,

        [Parameter(Mandatory = $true)]
        [string]$Query,

        [hashtable]$Parameters = @{},

        [int]$CommandTimeout = 120
    )

    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = $CommandTimeout

    if ($Parameters) {
        foreach ($key in $Parameters.Keys) {
            $val = $Parameters[$key]
            if ($null -eq $val) { $val = [DBNull]::Value }
            if ($val -is [byte[]]) {
                $param = $command.Parameters.Add("@$key", [System.Data.SqlDbType]::VarBinary, $val.Length)
                $param.Value = $val
            }
            else {
                [void]$command.Parameters.AddWithValue("@$key", $val)
            }
        }
    }

    try {
        $connection.Open()
        return $command.ExecuteScalar()
    }
    finally {
        $connection.Close()
        $connection.Dispose()
    }
}

function Invoke-MonitorSqlNonQuery {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServerInstance,

        [Parameter(Mandatory = $true)]
        [string]$Database,

        [Parameter(Mandatory = $true)]
        [string]$Query,

        [hashtable]$Parameters = @{},

        [int]$CommandTimeout = 120
    )

    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = $CommandTimeout

    if ($Parameters) {
        foreach ($key in $Parameters.Keys) {
            $val = $Parameters[$key]
            if ($null -eq $val) { $val = [DBNull]::Value }
            if ($val -is [byte[]]) {
                $param = $command.Parameters.Add("@$key", [System.Data.SqlDbType]::VarBinary, $val.Length)
                $param.Value = $val
            }
            else {
                [void]$command.Parameters.AddWithValue("@$key", $val)
            }
        }
    }

    try {
        $connection.Open()
        [void]$command.ExecuteNonQuery()
    }
    finally {
        $connection.Close()
        $connection.Dispose()
    }
}

function Write-MonitorLog {
    param(
        [string]$Message,
        [ValidateSet('Trace', 'Debug', 'Info', 'Warning', 'Error')]
        [string]$Level = 'Info',
        [string]$LogFile
    )

    if ([string]::IsNullOrWhiteSpace($LogFile)) {
        $LogFile = Get-SqlMonitorLogPath
    }

    $logDir = Split-Path -Parent $LogFile
    if (-not (Test-Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "$timestamp`t[$Level]`t$Message"

    # Retry logging up to 3 times in case of file locking issues
    $retryCount = 0
    $maxRetries = 3
    $retryDelay = 100 # milliseconds

    while ($retryCount -lt $maxRetries) {
        try {
            $stream = [System.IO.File]::Open($LogFile, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite)
            try {
                $writer = New-Object System.IO.StreamWriter($stream, [System.Text.Encoding]::UTF8)
                try { $writer.WriteLine($line) }
                finally { $writer.Dispose() }
            }
            finally {
                if ($stream) { $stream.Dispose() }
            }
            return
        }
        catch {
            $retryCount++
            if ($retryCount -lt $maxRetries) {
                Start-Sleep -Milliseconds $retryDelay
            }
            else {
                # If all retries failed, write to console as fallback
                Write-Host "Failed to write to log file $LogFile after $maxRetries attempts: $($_.Exception.Message)" -ForegroundColor Yellow
                Write-Host "$line" -ForegroundColor Gray
            }
        }
    }
}

function Get-SqlMonitorProjectRoot {
    # Method 1: Use PSScriptRoot if available (most reliable)
    if ($PSScriptRoot) {
        return (Split-Path -Parent $PSScriptRoot)
    }

    # Method 2: Use MyInvocation.MyCommand.Path
    if ($MyInvocation.MyCommand.Path) {
        return (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path))
    }

    # Method 3: Walk up from current location to find project root
    $current = Get-Location
    $maxDepth = 10
    $depth = 0
    
    while ($depth -lt $maxDepth -and $current) {
        if (Test-Path (Join-Path $current 'Modules') -PathType Container) {
            return $current
        }
        $parent = Split-Path -Parent $current
        if (-not $parent -or $parent -eq $current) { break }
        $current = $parent
        $depth++
    }

    Write-MonitorLog "WARNING: Could not resolve project root reliably. Using current location"
    return (Get-Location).Path
}

function Get-SqlMonitorPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RelativePath
    )

    return (Join-Path (Get-SqlMonitorProjectRoot) $RelativePath)
}

function Get-SqlMonitorLogPath {
    return (Get-SqlMonitorPath -RelativePath 'Logs\SQLMonitor.log')
}

function Get-SqlMonitorConfigPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$FileName
    )

    return (Get-SqlMonitorPath -RelativePath (Join-Path 'Config' $FileName))
}

function Read-SqlMonitorJsonFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [object]$DefaultValue = $null
    )

    if (-not (Test-Path $Path)) {
        return $DefaultValue
    }

    $content = Get-Content -Path $Path -Raw
    if ([string]::IsNullOrWhiteSpace($content)) {
        return $DefaultValue
    }

    return ($content.TrimStart([char]0xFEFF) | ConvertFrom-Json)
}

function ConvertTo-SqlMonitorMailAddressList {
    param(
        [object]$Addresses
    )

    $addressList = @()
    if ($null -eq $Addresses) {
        return $addressList
    }

    foreach ($address in @($Addresses)) {
        if ($null -eq $address) {
            continue
        }

        $parts = [string]$address -split '[;,]'
        foreach ($part in $parts) {
            $trimmed = $part.Trim()
            if (-not [string]::IsNullOrWhiteSpace($trimmed)) {
                $addressList += $trimmed
            }
        }
    }

    return $addressList
}

function Get-SqlMonitorExceptionMessage {
    param(
        [Parameter(Mandatory = $true)]
        [System.Exception]$Exception
    )

    $messages = @()
    $current = $Exception
    while ($null -ne $current) {
        if (-not [string]::IsNullOrWhiteSpace($current.Message)) {
            $messages += $current.Message
        }
        $current = $current.InnerException
    }

    return ($messages | Select-Object -Unique) -join " | "
}

function Send-SqlMonitorEmail {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$SmtpConfig,

        [Parameter(Mandatory = $true)]
        [object]$To,

        [object]$Cc = $null,

        [Parameter(Mandatory = $true)]
        [string]$Subject,

        [Parameter(Mandatory = $true)]
        [string]$Body,

        [switch]$BodyAsHtml,

        [int]$TimeoutMs = 30000
    )

    $server = [string]$SmtpConfig.Server
    if ([string]::IsNullOrWhiteSpace($server)) {
        throw "SMTP server is not configured"
    }

    $from = [string]$SmtpConfig.From
    if ([string]::IsNullOrWhiteSpace($from)) {
        throw "SMTP from address is not configured"
    }

    $recipients = @(ConvertTo-SqlMonitorMailAddressList -Addresses $To)
    if ($recipients.Count -eq 0) {
        throw "Recipient email address is not configured"
    }

    $port = [int]$SmtpConfig.Port
    if ($port -le 0) {
        throw "SMTP port is not configured"
    }

    if ($port -eq 465 -and [bool]$SmtpConfig.EnableSSL) {
        throw "SMTP port 465 uses implicit SSL, which this mail sender does not support. Use port 587 with SSL/STARTTLS or port 25 without SSL."
    }

    $message = New-Object System.Net.Mail.MailMessage
    $client = New-Object System.Net.Mail.SmtpClient($server, $port)

    try {
        $message.From = New-Object System.Net.Mail.MailAddress($from)
        foreach ($recipient in $recipients) {
            [void]$message.To.Add($recipient)
        }

        foreach ($ccAddress in @(ConvertTo-SqlMonitorMailAddressList -Addresses $Cc)) {
            [void]$message.CC.Add($ccAddress)
        }

        $message.Subject = $Subject
        $message.Body = $Body
        $message.IsBodyHtml = [bool]$BodyAsHtml

        $client.DeliveryMethod = [System.Net.Mail.SmtpDeliveryMethod]::Network
        $client.EnableSsl = [bool]$SmtpConfig.EnableSSL
        $client.Timeout = $TimeoutMs

        if ([bool]$SmtpConfig.UseDefaultCredentials) {
            $client.UseDefaultCredentials = $true
        }
        else {
            $client.UseDefaultCredentials = $false
            $username = [string]$SmtpConfig.Username
            if (-not [string]::IsNullOrWhiteSpace($username)) {
                $client.Credentials = New-Object System.Net.NetworkCredential($username, [string]$SmtpConfig.Password)
            }
        }

        $client.Send($message)
    }
    catch {
        $details = Get-SqlMonitorExceptionMessage -Exception $_.Exception
        $hint = ""
        if ($details -match 'net_io_connectionclosed|forcibly closed|connection.*closed') {
            $hint = " The SMTP port is reachable, but the server closed the session before accepting mail. Verify the SMTP relay host/port and ask mail administrators to allow relay from this machine or service account."
        }

        throw "SMTP send failed via ${server}:${port} (SSL=$([bool]$SmtpConfig.EnableSSL), WindowsAuth=$([bool]$SmtpConfig.UseDefaultCredentials)): $details$hint"
    }
    finally {
        if ($message) { $message.Dispose() }
        if ($client) { $client.Dispose() }
    }
}

function Get-SqlMonitorInstances {
    try {
        $config = Get-SqlMonitorInstanceConfig

        # Flatten all SQL instances from VMs + standalone into a single list
        $allInstances = @()

        foreach ($vm in $config.VMs) {
            if (-not $vm.IsEnabled) { continue }
            foreach ($sql in $vm.SQLInstances) {
                if (-not $sql.IsActive) { continue }
                $allInstances += [pscustomobject]@{
                    DisplayName      = $sql.DisplayName
                    SqlInstance      = $sql.SqlInstance
                    RepositoryServer = $sql.RepositoryServer
                    RepositoryDatabase = $sql.RepositoryDatabase
                    Environment      = $sql.Environment
                    IsActive         = $sql.IsActive
                    VMName           = $vm.VMName
                    VMDisplayName    = $vm.VMDisplayName
                    ParentVMID       = $null  # Will be resolved from repository
                }
            }
        }

        foreach ($sql in $config.StandaloneSQLInstances) {
            if (-not $sql.IsActive) { continue }
            $allInstances += [pscustomobject]@{
                DisplayName      = $sql.DisplayName
                SqlInstance      = $sql.SqlInstance
                RepositoryServer = $sql.RepositoryServer
                RepositoryDatabase = $sql.RepositoryDatabase
                Environment      = $sql.Environment
                IsActive         = $sql.IsActive
                VMName           = $null
                VMDisplayName    = $null
                ParentVMID       = $null
            }
        }

        if ($allInstances.Count -eq 0) {
            Write-MonitorLog "WARNING: No active instances found in configuration"
        }
        else {
            Write-MonitorLog "Loaded $($allInstances.Count) monitored instance(s) from $($config.VMs.Count) VM(s) and $($config.StandaloneSQLInstances.Count) standalone(s)"
        }

        return $allInstances
    }
    catch {
        Write-MonitorLog "ERROR in Get-SqlMonitorInstances: $($_.Exception.Message)"
        throw
    }
}

function Get-SqlMonitorInstanceConfig {
    <#
    .SYNOPSIS
        Reads instances.json and returns a normalized config object.
        Supports both new VM-based format and legacy flat format.
    #>
    try {
        $instancesPath = Get-SqlMonitorConfigPath -FileName 'instances.json'

        if (-not (Test-Path $instancesPath)) {
            Write-MonitorLog "ERROR: Instances configuration file not found: $instancesPath"
            throw "Instances configuration file not found at: $instancesPath"
        }

        $raw = Read-SqlMonitorJsonFile -Path $instancesPath

        if ($null -eq $raw) {
            Write-MonitorLog "ERROR: Instances configuration file is empty: $instancesPath"
            throw "Instances configuration file is empty: $instancesPath"
        }

        # Detect format: new VM-based format has "VMs" property
        if ($raw.PSObject.Properties['VMs']) {
            # New VM-based format
            $vms = @($raw.VMs | ForEach-Object {
                [pscustomobject]@{
                    VMName        = [string]$_.VMName
                    VMDisplayName = if ($_.VMDisplayName) { [string]$_.VMDisplayName } else { [string]$_.VMName }
                    IsEnabled     = if ($null -eq $_.IsEnabled) { $true } else { [bool]$_.IsEnabled }
                    SQLInstances  = @($_.SQLInstances | ForEach-Object {
                        [pscustomobject]@{
                            DisplayName      = [string]$_.DisplayName
                            SqlInstance      = [string]$_.SqlInstance
                            RepositoryServer = [string]$_.RepositoryServer
                            RepositoryDatabase = [string]$_.RepositoryDatabase
                            Environment      = if ($_.Environment) { [string]$_.Environment } else { 'Production' }
                            IsActive         = if ($null -eq $_.IsActive) { $true } else { [bool]$_.IsActive }
                        }
                    })
                }
            })

            $standalone = @($raw.StandaloneSQLInstances | ForEach-Object {
                [pscustomobject]@{
                    DisplayName      = [string]$_.DisplayName
                    SqlInstance      = [string]$_.SqlInstance
                    RepositoryServer = [string]$_.RepositoryServer
                    RepositoryDatabase = [string]$_.RepositoryDatabase
                    Environment      = if ($_.Environment) { [string]$_.Environment } else { 'Production' }
                    IsActive         = if ($null -eq $_.IsActive) { $true } else { [bool]$_.IsActive }
                }
            })

            return [pscustomobject]@{
                VMs                    = $vms
                StandaloneSQLInstances = $standalone
                Format                 = 'VMHierarchy'
            }
        }
        else {
            # Legacy flat format: single object or array of objects
            $legacyInstances = @()
            if ($raw -is [System.Array] -or $raw -is [System.Collections.ArrayList]) {
                $legacyInstances = @($raw)
            }
            else {
                $legacyInstances = @($raw)
            }

            # Convert legacy format to new VM-based format
            # Each instance becomes a VM with a single SQL instance
            $vms = @()
            $standalone = @()

            foreach ($inst in $legacyInstances) {
                $displayName = [string]$inst.DisplayName
                $sqlInstance = [string]$inst.SqlInstance
                $repoServer  = [string]$inst.RepositoryServer
                $repoDb      = [string]$inst.RepositoryDatabase
                $environment = if ($inst.Environment) { [string]$inst.Environment } else { 'Production' }
                $isActive    = if ($null -eq $inst.IsActive) { $true } else { [bool]$inst.IsActive }

                if ([string]::IsNullOrWhiteSpace($displayName)) { $displayName = $sqlInstance }
                if ([string]::IsNullOrWhiteSpace($repoServer))  { $repoServer = $sqlInstance }
                if ([string]::IsNullOrWhiteSpace($repoDb))      { $repoDb = 'DBA_SQLMonitor' }

                # Try to extract VM name from SqlInstance (e.g., "SERVER\INSTANCE" -> "SERVER")
                $vmName = if ($sqlInstance -match '^([^\\]+)') { $Matches[1] } else { $sqlInstance }

                # Check if we already have a VM for this server
                $existingVM = $vms | Where-Object { $_.VMName -eq $vmName } | Select-Object -First 1
                if (-not $existingVM) {
                    $existingVM = [pscustomobject]@{
                        VMName        = $vmName
                        VMDisplayName = $vmName
                        IsEnabled     = $true
                        SQLInstances  = @()
                    }
                    $vms += $existingVM
                }

                $existingVM.SQLInstances += [pscustomobject]@{
                    DisplayName      = $displayName
                    SqlInstance      = $sqlInstance
                    RepositoryServer = $repoServer
                    RepositoryDatabase = $repoDb
                    Environment      = $environment
                    IsActive         = $isActive
                }
            }

            Write-MonitorLog "Migrated $($legacyInstances.Count) legacy instance(s) to VM-based format with $($vms.Count) VM(s)"

            return [pscustomobject]@{
                VMs                    = $vms
                StandaloneSQLInstances = $standalone
                Format                 = 'Legacy'
            }
        }
    }
    catch {
        Write-MonitorLog "ERROR in Get-SqlMonitorInstanceConfig: $($_.Exception.Message)"
        throw
    }
}

function Get-SqlMonitorVMs {
    <#
    .SYNOPSIS
        Returns the list of VMs from the configuration.
    #>
    try {
        $config = Get-SqlMonitorInstanceConfig
        return @($config.VMs | Where-Object { $_.IsEnabled })
    }
    catch {
        Write-MonitorLog "ERROR in Get-SqlMonitorVMs: $($_.Exception.Message)"
        throw
    }
}

function Get-SqlMonitorRepositorySettings {
    param(
        [object[]]$Instances = $null
    )

    if ($null -eq $Instances) {
        try {
            $Instances = @(Get-SqlMonitorInstances)
        }
        catch {
            $distributedPath = Get-SqlMonitorConfigPath -FileName 'distributed.json'
            $distributed = Read-SqlMonitorJsonFile -Path $distributedPath -DefaultValue $null
            if ($distributed -and -not [string]::IsNullOrWhiteSpace([string]$distributed.CentralRepositoryServer)) {
                return [pscustomobject]@{
                    RepositoryServer   = [string]$distributed.CentralRepositoryServer
                    RepositoryDatabase = if ([string]::IsNullOrWhiteSpace([string]$distributed.CentralRepositoryDatabase)) { 'DBA_SQLMonitor' } else { [string]$distributed.CentralRepositoryDatabase }
                    SourceInstance     = $null
                }
            }
            throw
        }
    }

    $activeInstances = @($Instances | Where-Object { $_.IsActive })
    if ($activeInstances.Count -eq 0) {
        throw "No active instances found in $(Get-SqlMonitorConfigPath -FileName 'instances.json')"
    }

    $repositoryInstance = $activeInstances | Select-Object -First 1
    $repositoryServer = if ([string]::IsNullOrWhiteSpace([string]$repositoryInstance.RepositoryServer)) {
        [string]$repositoryInstance.SqlInstance
    }
    else {
        [string]$repositoryInstance.RepositoryServer
    }

    $repositoryDatabase = if ([string]::IsNullOrWhiteSpace([string]$repositoryInstance.RepositoryDatabase)) {
        'DBA_SQLMonitor'
    }
    else {
        [string]$repositoryInstance.RepositoryDatabase
    }

    return [pscustomobject]@{
        RepositoryServer   = $repositoryServer
        RepositoryDatabase = $repositoryDatabase
        SourceInstance     = $repositoryInstance
    }
}

function Resolve-SqlMonitorPowerShellPath {
    $pwsh = Get-Command 'pwsh.exe' -ErrorAction SilentlyContinue
    if ($null -ne $pwsh) {
        return $pwsh.Source
    }

    $windowsPowerShell = Get-Command 'powershell.exe' -ErrorAction SilentlyContinue
    if ($null -ne $windowsPowerShell) {
        return $windowsPowerShell.Source
    }

    throw 'Neither pwsh.exe nor powershell.exe is available on PATH.'
}

function Get-MonitorInstanceId {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [string]$DisplayName,
        [string]$SqlInstance = $null
    )

    $query = "SELECT InstanceID FROM mon.MonitoredInstances WHERE DisplayName = @DisplayName AND IsActive = 1;"
    $params = @{ DisplayName = $DisplayName }

    $result = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters $params
    
    if ($null -eq $result -and $null -ne $SqlInstance) {
        # Try to create it if we have the SqlInstance
        return GetOrCreate-MonitoredInstance -SqlInstance $SqlInstance -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -DisplayName $DisplayName
    }
    
    if ($null -eq $result) { return 0 }
    return [int]$result
}

function Start-CollectionRun {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [int]$InstanceID,
        [string]$ModuleName
    )

    $collectorNodeId = 0
    [void][int]::TryParse([string]$env:SQLMON_COLLECTOR_NODE_ID, [ref]$collectorNodeId)

    $query = @"
IF COL_LENGTH('mon.CollectionRuns', 'CollectorNodeID') IS NOT NULL AND @CollectorNodeID > 0
BEGIN
    INSERT INTO mon.CollectionRuns (InstanceID, ModuleName, StartTime, Status, CollectorNodeID)
    VALUES (@InstanceID, @ModuleName, SYSDATETIME(), N'Started', @CollectorNodeID);
END
ELSE
BEGIN
    INSERT INTO mon.CollectionRuns (InstanceID, ModuleName, StartTime, Status)
    VALUES (@InstanceID, @ModuleName, SYSDATETIME(), N'Started');
END;

SELECT CAST(SCOPE_IDENTITY() AS BIGINT);
"@
    $params = @{ InstanceID = $InstanceID; ModuleName = $ModuleName; CollectorNodeID = $collectorNodeId }

    $runId = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters $params
    return [int64]$runId
}

function Stop-CollectionRun {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [int64]$RunID,
        [string]$Status,
        [string]$ErrorMessage = $null
    )

    $query = @"
UPDATE mon.CollectionRuns
SET EndTime = SYSDATETIME(),
    Status = @Status,
    ErrorMessage = @ErrorMessage
WHERE RunID = @RunID;
"@
    $params = @{ Status = $Status; ErrorMessage = $ErrorMessage; RunID = $RunID }

    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters $params
}

function Write-DataTableToSql {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServerInstance,

        [Parameter(Mandatory = $true)]
        [string]$Database,

        [Parameter(Mandatory = $true)]
        [string]$DestinationTable,

        [Parameter(Mandatory = $true)]
        [System.Data.DataTable]$DataTable
    )

    if ($DataTable.Rows.Count -eq 0) {
        return
    }

    $destinationColumns = @(Get-MonitorTableColumns -ServerInstance $ServerInstance -Database $Database -TableName $DestinationTable)
    if ($destinationColumns.Count -eq 0) {
        throw "Destination table '$DestinationTable' was not found or has no readable columns."
    }

    $sourceColumns = @()
    foreach ($column in $DataTable.Columns) {
        $sourceColumns += [string]$column.ColumnName
    }

    $matchedColumns = @()
    $columnMappings = @()
    foreach ($sourceColumn in $sourceColumns) {
        $destinationColumn = @($destinationColumns | Where-Object { $_ -ieq $sourceColumn } | Select-Object -First 1)
        if ($destinationColumn.Count -gt 0) {
            $matchedColumns += $sourceColumn
            $columnMappings += [pscustomobject]@{
                Source      = $sourceColumn
                Destination = [string]$destinationColumn[0]
            }
        }
    }

    if ($matchedColumns.Count -eq 0) {
        throw "No matching columns between source data and destination table '$DestinationTable'. Source: $($sourceColumns -join ', ') Destination: $($destinationColumns -join ', ')"
    }

    foreach ($row in $DataTable.Rows) {
        foreach ($column in $DataTable.Columns) {
            $value = $row[$column.ColumnName]
            if ($null -eq $value -or $value -is [System.DBNull]) { continue }
            if ($value -is [System.Management.Automation.PSObject]) {
                $value = $value.BaseObject
            }
            if ($null -eq $value) {
                $row[$column.ColumnName] = [DBNull]::Value
                continue
            }
            if ($column.DataType -eq [datetime] -and -not ($value -is [datetime])) {
                $row[$column.ColumnName] = [datetime]$value
            }
            elseif ($column.DataType -eq [string] -and -not ($value -is [string])) {
                $row[$column.ColumnName] = [string]$value
            }
            elseif ($value -isnot [System.DBNull] -and $value.GetType().FullName -ne $column.DataType.FullName) {
                try { $row[$column.ColumnName] = [System.Convert]::ChangeType($value, $column.DataType) } catch {}
            }
        }
    }

    $ignoredColumns = @($sourceColumns | Where-Object { $matchedColumns -notcontains $_ })
    if ($ignoredColumns.Count -gt 0) {
        Write-MonitorLog "Ignoring unmatched columns for ${DestinationTable}: $($ignoredColumns -join ', ')" -Level 'Debug'
    }

    $connectionString = "Server=$ServerInstance;Database=$Database;Integrated Security=True;TrustServerCertificate=True;"
    $connection = New-Object System.Data.SqlClient.SqlConnection $connectionString
    
    try {
        $connection.Open()
        
        # Use the fully qualified destination table name when available.
        # SqlBulkCopy supports schema-qualified table names directly.
        $bulkCopyTableName = $DestinationTable
        
        $bulkCopy = New-Object System.Data.SqlClient.SqlBulkCopy $connection
        $bulkCopy.DestinationTableName = $bulkCopyTableName
        $bulkCopy.BulkCopyTimeout = 300

        foreach ($mapping in $columnMappings) {
            [void]$bulkCopy.ColumnMappings.Add($mapping.Source, $mapping.Destination)
        }

        $bulkCopy.WriteToServer($DataTable)
    }
    finally {
        if ($bulkCopy) { $bulkCopy.Close(); $bulkCopy.Dispose() }
        if ($connection) { $connection.Close(); $connection.Dispose() }
    }
}

function Get-MonitorTableColumns {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ServerInstance,

        [Parameter(Mandatory = $true)]
        [string]$Database,

        [Parameter(Mandatory = $true)]
        [string]$TableName
    )

    $parts = $TableName.Split('.', 2)
    if ($parts.Count -eq 2) {
        $schemaName = $parts[0]
        $baseTableName = $parts[1]
    }
    else {
        $schemaName = 'dbo'
        $baseTableName = $TableName
    }

    $query = @"
SELECT c.name AS ColumnName
FROM sys.tables t
INNER JOIN sys.schemas s
    ON t.schema_id = s.schema_id
INNER JOIN sys.columns c
    ON t.object_id = c.object_id
WHERE s.name = @SchemaName
  AND t.name = @TableName
ORDER BY c.column_id;
"@

    $rows = Invoke-MonitorSqlQuery `
        -ServerInstance $ServerInstance `
        -Database $Database `
        -Query $query `
        -Parameters @{
            SchemaName = $schemaName
            TableName = $baseTableName
        }

    $columns = @()
    if ($null -ne $rows -and $null -ne $rows.Rows) {
        foreach ($row in $rows.Rows) {
            $columns += [string]$row['ColumnName']
        }
    }

    return $columns
}

function Get-FirstAvailableColumnName {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$AvailableColumns,

        [Parameter(Mandatory = $true)]
        [string[]]$CandidateNames
    )

    foreach ($candidate in $CandidateNames) {
        if ($AvailableColumns -contains $candidate) {
            return $candidate
        }
    }

    return $null
}

function New-KPIHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("PageLifeExpectancy", [int])
    [void]$dt.Columns.Add("BufferCacheHitRatio", [double])
    [void]$dt.Columns.Add("VisibleOnlineCPUs", [int])
    [void]$dt.Columns.Add("MAXDOP", [int])
    [void]$dt.Columns.Add("CostThresholdForParallelism", [int])
    [void]$dt.Columns.Add("ServerMemoryMB", [bigint])
    return ,$dt
}

function New-DiskVolumeHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("VolumeMountPoint", [string])
    [void]$dt.Columns.Add("LogicalVolumeName", [string])
    [void]$dt.Columns.Add("TotalGB", [decimal])
    [void]$dt.Columns.Add("FreeGB", [decimal])
    [void]$dt.Columns.Add("UsedGB", [decimal])
    [void]$dt.Columns.Add("UsedPct", [decimal])
    return ,$dt
}

function New-CPUHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("SqlCPUPercent", [decimal])
    [void]$dt.Columns.Add("OtherCPUPercent", [decimal])
    [void]$dt.Columns.Add("IdleCPUPercent", [decimal])
    return ,$dt
}

function New-MemoryHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("TotalPhysicalMB", [long])
    [void]$dt.Columns.Add("AvailablePhysicalMB", [long])
    [void]$dt.Columns.Add("SqlMemoryUsedGB", [decimal])
    [void]$dt.Columns.Add("PLESeconds", [long])
    [void]$dt.Columns.Add("BufferCacheHitRatio", [decimal])
    return ,$dt
}

function New-AgentJobHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("JobName", [string])
    [void]$dt.Columns.Add("Enabled", [bool])
    [void]$dt.Columns.Add("Category", [string])
    [void]$dt.Columns.Add("LastRunTime", [datetime])
    [void]$dt.Columns.Add("LastStatus", [string])
    [void]$dt.Columns.Add("LastDurationSec", [int])
    [void]$dt.Columns.Add("NextRunTime", [datetime])
    [void]$dt.Columns.Add("RunsRecent", [int])
    [void]$dt.Columns.Add("FailuresRecent", [int])
    [void]$dt.Columns.Add("SuccessPctRecent", [decimal])
    [void]$dt.Columns.Add("AvgDurationSecRecent", [int])
    [void]$dt.Columns.Add("LastFailureTime", [datetime])
    [void]$dt.Columns.Add("LastFailureMessage", [string])
    return ,$dt
}

function New-DeadlockHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("DeadlockTime", [datetime])
    [void]$dt.Columns.Add("DeadlockXml", [string])
    return ,$dt
}

function New-AGOverviewHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("AGName", [string])
    [void]$dt.Columns.Add("PrimaryReplica", [string])
    [void]$dt.Columns.Add("SyncHealthDesc", [string])
    [void]$dt.Columns.Add("BackupPreferenceDesc", [string])
    [void]$dt.Columns.Add("FailureConditionLevel", [int])
    [void]$dt.Columns.Add("ClusterTypeDesc", [string])
    return ,$dt
}

function New-AGReplicaHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("AGName", [string])
    [void]$dt.Columns.Add("ReplicaServer", [string])
    [void]$dt.Columns.Add("IsLocal", [bool])
    [void]$dt.Columns.Add("RoleDesc", [string])
    [void]$dt.Columns.Add("AvailabilityModeDesc", [string])
    [void]$dt.Columns.Add("FailoverModeDesc", [string])
    [void]$dt.Columns.Add("SyncHealthDesc", [string])
    [void]$dt.Columns.Add("ConnectedStateDesc", [string])
    return ,$dt
}

function New-AGDatabaseHistoryTable {
    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add("InstanceID", [int])
    [void]$dt.Columns.Add("CaptureTime", [datetime])
    [void]$dt.Columns.Add("AGName", [string])
    [void]$dt.Columns.Add("ReplicaServer", [string])
    [void]$dt.Columns.Add("DatabaseName", [string])
    [void]$dt.Columns.Add("IsPrimaryReplica", [bool])
    [void]$dt.Columns.Add("SyncStateDesc", [string])
    [void]$dt.Columns.Add("SyncHealthDesc", [string])
    [void]$dt.Columns.Add("LogSendQueueMB", [decimal])
    [void]$dt.Columns.Add("RedoQueueMB", [decimal])
    [void]$dt.Columns.Add("LastCommitTime", [datetime])
    return ,$dt
}

function Close-CollectionRun {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [int64]$RunID
    )
    
    # Wrapper for Stop-CollectionRun with default status
    Stop-CollectionRun -RepositoryServer $RepositoryServer -RepositoryDatabase $RepositoryDatabase -RunID $RunID -Status "Completed"
}

function GetOrCreate-MonitoredInstance {
    param(
        [string]$SqlInstance,
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [string]$Environment = 'Unknown',
        [string]$DisplayName = $null
    )

    # First try to get existing InstanceID
    $displayNameToUse = if ([string]::IsNullOrEmpty($DisplayName)) { $SqlInstance } else { $DisplayName }
    
    $query = "SELECT InstanceID FROM mon.MonitoredInstances WHERE DisplayName = @DisplayName;"
    $params = @{ DisplayName = $displayNameToUse }
    
    $result = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters $params
    
    if ($null -ne $result) {
        return [int]$result
    }

    # Instance doesn't exist, create it
    Write-MonitorLog -Message "Instance '$displayNameToUse' not found in mon.MonitoredInstances. Auto-registering..." -Level "Info"
    
    $serverName = $SqlInstance.Split('\')[0]
    $instanceName = if ($SqlInstance.Contains('\')) { $SqlInstance.Split('\')[1] } else { 'MSSQLSERVER' }
    
    $insertQuery = @"
INSERT INTO mon.MonitoredInstances (ServerName, InstanceName, DisplayName, EnvironmentName, IsActive)
VALUES (@ServerName, @InstanceName, @DisplayName, @Environment, 1);
SELECT CAST(SCOPE_IDENTITY() AS INT);
"@
    $insertParams = @{
        ServerName = $serverName
        InstanceName = $instanceName
        DisplayName = $displayNameToUse
        Environment = $Environment
    }
    
    $newId = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $insertQuery -Parameters $insertParams
    return [int]$newId
}

Export-ModuleMember -Function Invoke-MonitorSqlQuery, Invoke-MonitorSqlScalar, Invoke-MonitorSqlNonQuery, Write-MonitorLog, Get-SqlMonitorProjectRoot, Get-SqlMonitorPath, Get-SqlMonitorLogPath, Get-SqlMonitorConfigPath, Read-SqlMonitorJsonFile, ConvertTo-SqlMonitorMailAddressList, Get-SqlMonitorExceptionMessage, Send-SqlMonitorEmail, Get-SqlMonitorInstances, Get-SqlMonitorInstanceConfig, Get-SqlMonitorVMs, Get-SqlMonitorRepositorySettings, Resolve-SqlMonitorPowerShellPath, Get-MonitorInstanceId, GetOrCreate-MonitoredInstance, Start-CollectionRun, Stop-CollectionRun, Close-CollectionRun, Write-DataTableToSql, Get-MonitorTableColumns, Get-FirstAvailableColumnName, New-KPIHistoryTable, New-DiskVolumeHistoryTable, New-CPUHistoryTable, New-MemoryHistoryTable, New-AgentJobHistoryTable, New-DeadlockHistoryTable, New-AGOverviewHistoryTable, New-AGReplicaHistoryTable, New-AGDatabaseHistoryTable
