Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force -Global -WarningAction SilentlyContinue

function Send-AlertNotification {
    param(
        [Parameter(Mandatory = $true)]
        [System.Data.DataRow]$Alert,
        [Parameter(Mandatory = $true)]
        [pscustomobject]$NotificationConfig
    )

    try {
        # Check if notifications are enabled
        if (-not $NotificationConfig.Notifications.Enabled) {
            return
        }

        # Check severity threshold
        $severityLevels = @{ 'Info' = 1; 'Warning' = 2; 'Critical' = 3 }
        $minSeverity = $severityLevels[$NotificationConfig.Notifications.MinSeverity]
        $alertSeverity = $severityLevels[$Alert['Severity'].ToString()]
        
        if ($alertSeverity -lt $minSeverity) {
            return
        }

        # Check quiet hours
        if ($NotificationConfig.Notifications.QuietHours.Enabled) {
            $currentTime = (Get-Date).TimeOfDay
            $startTime = [TimeSpan]::Parse($NotificationConfig.Notifications.QuietHours.Start)
            $endTime = [TimeSpan]::Parse($NotificationConfig.Notifications.QuietHours.End)

            $isQuietHours = if ($startTime -le $endTime) {
                $currentTime -ge $startTime -and $currentTime -lt $endTime
            }
            else {
                $currentTime -ge $startTime -or $currentTime -lt $endTime
            }

            if ($isQuietHours) {
                Write-MonitorLog "Alert notification suppressed during quiet hours: $($Alert['AlertMessage'])"
                return
            }
        }

        # Check throttling
        $alertKey = "$($Alert['InstanceID'])_$($Alert['AlertType'])_$($Alert['MetricName'])"
        $throttleFile = Get-SqlMonitorConfigPath -FileName 'AlertThrottle.json'
        
        if (Test-Path $throttleFile) {
            $throttleData = Get-Content $throttleFile | ConvertFrom-Json
            $lastSent = $throttleData.$alertKey
            
            if ($lastSent) {
                $lastSentTime = [DateTime]::Parse($lastSent)
                $minutesSince = (Get-Date).Subtract($lastSentTime).TotalMinutes
                
                if ($minutesSince -lt $NotificationConfig.Notifications.ThrottleMinutes) {
                    return
                }
            }
        }
        else {
            $throttleData = @{}
        }

        # Build alert message
        $subject = "SQL Alert [$($Alert['Severity'])]: $($Alert['AlertType']) - $($Alert['DisplayName'])"
        
        $body = @"
<html>
<body style="font-family: Arial, sans-serif;">
<h2 style="color: $(if($Alert['Severity'] -eq 'Critical'){'#dc3545'}elseif($Alert['Severity'] -eq 'Warning'){'#ffc107'}else{'#17a2b8'})">SQL Server Alert</h2>
<table style="border-collapse: collapse; width: 100%;">
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Instance:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['DisplayName'])</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Severity:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['Severity'])</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Alert Type:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['AlertType'])</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Metric:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['MetricName'])</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Current Value:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['CurrentValue'])</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Threshold:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['ThresholdValue'])</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Message:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['AlertMessage'])</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd; background: #f8f9fa; font-weight: bold;">Time:</td><td style="padding: 8px; border: 1px solid #ddd;">$($Alert['AlertTime'])</td></tr>
</table>
"@

        if ($NotificationConfig.Notifications.IncludeDashboardLink) {
            $body += "<p style=`"margin-top: 20px;`"><a href=`"$($NotificationConfig.Notifications.DashboardURL)`">View Dashboard</a></p>"
        }

        $body += "</body></html>"

        # Send email
        if ([string]::IsNullOrWhiteSpace([string]$NotificationConfig.SMTP.Server)) {
            Write-MonitorLog "Email notification skipped because SMTP.Server is not configured" -Level 'Warning'
            return
        }

        if ($null -eq $NotificationConfig.Notifications.Recipients -or $NotificationConfig.Notifications.Recipients.Count -eq 0) {
            Write-MonitorLog "Email notification skipped because no recipients are configured" -Level 'Warning'
            return
        }

        Send-SqlMonitorEmail `
            -SmtpConfig $NotificationConfig.SMTP `
            -To $NotificationConfig.Notifications.Recipients `
            -Cc $NotificationConfig.Notifications.CCRecipients `
            -Subject $subject `
            -Body $body `
            -BodyAsHtml

        # Update throttle
        $throttleData.$alertKey = (Get-Date).ToString('o')
        $throttleData | ConvertTo-Json -Depth 5 | Set-Content -Path $throttleFile -Encoding UTF8

        Write-MonitorLog "Alert notification sent: $subject"
    }
    catch {
        Write-MonitorLog "ERROR sending alert notification: $(Get-SqlMonitorExceptionMessage -Exception $_.Exception)"
    }
}

function Send-TeamsNotification {
    param(
        [Parameter(Mandatory = $true)]
        [System.Data.DataRow]$Alert,
        [Parameter(Mandatory = $true)]
        [pscustomobject]$NotificationConfig
    )

    if (-not $NotificationConfig.Teams.Enabled) {
        return
    }

    $webhookUrl = [string]$NotificationConfig.Teams.WebhookURL
    if ([string]::IsNullOrWhiteSpace($webhookUrl) -or $webhookUrl -like '*YOUR-WEBHOOK-URL-HERE*') {
        Write-MonitorLog "Teams notification skipped because the webhook URL is not configured" -Level 'Warning'
        return
    }

    try {
        $color = if ($Alert['Severity'] -eq 'Critical') { 'dc3545' } elseif ($Alert['Severity'] -eq 'Warning') { 'ffc107' } else { '17a2b8' }
        
        $body = @{
            "@type" = "MessageCard"
            "@context" = "http://schema.org/extensions"
            "themeColor" = $color
            "summary" = $Alert['AlertMessage']
            "sections" = @(
                @{
                    "activityTitle" = "SQL Alert [$($Alert['Severity'])]"
                    "activitySubtitle" = $Alert['DisplayName']
                    "facts" = @(
                        @{ "name" = "Alert Type"; "value" = $Alert['AlertType'] }
                        @{ "name" = "Metric"; "value" = $Alert['MetricName'] }
                        @{ "name" = "Current Value"; "value" = $Alert['CurrentValue'] }
                        @{ "name" = "Threshold"; "value" = $Alert['ThresholdValue'] }
                        @{ "name" = "Time"; "value" = $Alert['AlertTime'] }
                    )
                    "text" = $Alert['AlertMessage']
                }
            )
            "potentialAction" = @(
                @{
                    "@type" = "OpenUri"
                    "name" = "View Dashboard"
                    "targets" = @(@{ "os" = "default"; "uri" = $NotificationConfig.Notifications.DashboardURL })
                }
            )
        } | ConvertTo-Json -Depth 4

        Invoke-RestMethod -Uri $webhookUrl -Method Post -Body $body -ContentType 'application/json'
        
        Write-MonitorLog "Teams notification sent for alert: $($Alert['AlertType'])"
    }
    catch {
        Write-MonitorLog "ERROR sending Teams notification: $($_.Exception.Message)"
    }
}

function Invoke-AlertEngine {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "AlertEngine"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Alert engine started for $($Instance.DisplayName)"

        # Load notification configuration
        $notificationConfigPath = Get-SqlMonitorConfigPath -FileName 'notifications.json'
        $notificationConfig = $null
        if (Test-Path $notificationConfigPath) {
            $notificationConfig = Read-SqlMonitorJsonFile -Path $notificationConfigPath
            Write-MonitorLog "Notification configuration loaded"
        }
        else {
            Write-MonitorLog "Notification configuration not found at $notificationConfigPath"
        }

        $query = @"
EXEC mon.usp_EvaluateAlerts @InstanceID = $instanceId;
"@

        $alerts = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.RepositoryServer `
            -Database $Instance.RepositoryDatabase `
            -Query $query `
            -CommandTimeout 180

        $alertCount = 0
        if ($alerts -ne $null -and $alerts.Rows.Count -gt 0) {
            $alertCount = $alerts.Rows.Count
            
            # Send notifications for each alert
            if ($notificationConfig -ne $null) {
                foreach ($alert in $alerts.Rows) {
                    # Check if alert is new (not acknowledged)
                    if ($alert['IsAcknowledged'] -is [System.DBNull] -or -not [bool]$alert['IsAcknowledged']) {
                        Send-AlertNotification -Alert $alert -NotificationConfig $notificationConfig
                        Send-TeamsNotification -Alert $alert -NotificationConfig $notificationConfig
                    }
                }
            }
            
            # Auto-convert alerts to tickets
            try {
                Write-MonitorLog "Starting auto-conversion of alerts to tickets for $($Instance.DisplayName)"
                $autoConvertResult = Invoke-MonitorSqlQuery `
                    -ServerInstance $Instance.RepositoryServer `
                    -Database $Instance.RepositoryDatabase `
                    -Query "DECLARE @TicketsCreated INT; EXEC mon.usp_AutoConvertAlertsToTickets @HoursBack = 24, @CreatedBy = 'system', @TicketsCreated = @TicketsCreated OUTPUT; SELECT @TicketsCreated AS TicketsCreated;"
                
                if ($autoConvertResult -and $autoConvertResult.Rows.Count -gt 0) {
                    $ticketsCreated = [int]($autoConvertResult.Rows[0].TicketsCreated)
                    if ($ticketsCreated -gt 0) {
                        Write-MonitorLog "Auto-created $ticketsCreated ticket(s) from alerts for $($Instance.DisplayName)"
                    }
                }
            }
            catch {
                Write-MonitorLog "Warning: Auto-conversion of alerts to tickets failed: $($_.Exception.Message)" -Level 'Warning'
            }
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"

        Write-MonitorLog "Alert engine completed for $($Instance.DisplayName). New alerts: $alertCount"

        return $alerts
    }
    catch {
        $msg = $_.Exception.Message

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg

        Write-MonitorLog "Alert engine failed for $($Instance.DisplayName): $msg"
        throw
    }
}

Export-ModuleMember -Function Invoke-AlertEngine
