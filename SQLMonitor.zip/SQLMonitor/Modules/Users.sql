-- User management tables for SQLMonitor
-- Created on May 4, 2026

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'mon')
    EXEC('CREATE SCHEMA mon');
GO

-- Dashboard users table
IF OBJECT_ID('mon.DashboardUsers', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUsers (
        UserID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardUsers PRIMARY KEY,
        UserName NVARCHAR(128) NOT NULL CONSTRAINT UQ_DashboardUsers_UserName UNIQUE,
        DisplayName NVARCHAR(200) NULL,
        PasswordSalt VARBINARY(16) NOT NULL,
        PasswordHash VARBINARY(32) NOT NULL,
        RoleName NVARCHAR(20) NOT NULL CONSTRAINT CK_DashboardUsers_RoleName CHECK (RoleName IN ('Admin','ViewOnly','Limited')),
        IsActive BIT NOT NULL CONSTRAINT DF_DashboardUsers_IsActive DEFAULT (1),
        MustChangePassword BIT NOT NULL CONSTRAINT DF_DashboardUsers_MustChangePassword DEFAULT (0),
        FailedLoginCount INT NOT NULL CONSTRAINT DF_DashboardUsers_FailedLoginCount DEFAULT (0),
        LastFailedLoginAt DATETIME2(0) NULL,
        LockoutUntil DATETIME2(0) NULL,
        PasswordChangedAt DATETIME2(0) NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUsers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(0) NULL,
        LastLoginAt DATETIME2(0) NULL
    );
END
GO

-- Mapping of users to monitored instances
IF OBJECT_ID('mon.DashboardUserInstanceAccess', 'U') IS NULL
BEGIN
    CREATE TABLE mon.DashboardUserInstanceAccess (
        UserID INT NOT NULL,
        InstanceID INT NOT NULL,
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_DashboardUserInstanceAccess_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT PK_DashboardUserInstanceAccess PRIMARY KEY (UserID, InstanceID),
        CONSTRAINT FK_DashboardUserInstanceAccess_Users FOREIGN KEY (UserID) REFERENCES mon.DashboardUsers(UserID) ON DELETE CASCADE,
        CONSTRAINT FK_DashboardUserInstanceAccess_Instances FOREIGN KEY (InstanceID) REFERENCES mon.MonitoredInstances(InstanceID) ON DELETE CASCADE
    );
END
GO