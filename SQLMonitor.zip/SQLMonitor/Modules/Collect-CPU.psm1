function Invoke-CPUCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "CPU"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "CPU collector started for $($Instance.DisplayName)"

        $cpuQuery = @"
SET QUOTED_IDENTIFIER ON;
DECLARE @ts BIGINT = (SELECT cpu_ticks/(cpu_ticks/ms_ticks) FROM sys.dm_os_sys_info);

;WITH RB AS
(
    SELECT TOP (60)
        DATEADD(ms, -1 * (@ts - [timestamp]), SYSDATETIME()) AS EventTime,
        CONVERT(XML, record) AS x
    FROM sys.dm_os_ring_buffers
    WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
      AND record LIKE '%<SystemHealth>%'
    ORDER BY [timestamp] DESC
)
SELECT
    EventTime AS CaptureTime,
    CONVERT(decimal(5,2), x.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int')) AS SqlCPUPercent,
    CONVERT(decimal(5,2), x.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int')) AS IdleCPUPercent,
    CONVERT(decimal(5,2),
        100
        - x.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int')
        - x.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int')
    ) AS OtherCPUPercent
FROM RB
ORDER BY EventTime;
"@

        $sourceRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $cpuQuery `
            -CommandTimeout 120

        if ($sourceRows.Rows.Count -eq 0) {
            throw 'CPU query returned no result set.'
        }

        Write-MonitorLog "CPU query returned $($sourceRows.Rows.Count) rows"

        $targetTable = New-CPUHistoryTable
        
        foreach ($row in $sourceRows.Rows) {
            if ($row["CaptureTime"] -is [DBNull]) { continue }
            $newRow = $targetTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime]$row["CaptureTime"]
            $newRow["SqlCPUPercent"] = if ($row["SqlCPUPercent"] -is [DBNull]) { 0 } else { [decimal]$row["SqlCPUPercent"] }
            $newRow["OtherCPUPercent"] = if ($row["OtherCPUPercent"] -is [DBNull]) { 0 } else { [decimal]$row["OtherCPUPercent"] }
            $newRow["IdleCPUPercent"] = if ($row["IdleCPUPercent"] -is [DBNull]) { 0 } else { [decimal]$row["IdleCPUPercent"] }
            $targetTable.Rows.Add($newRow)
        }

        Write-DataTableToSql `
            -ServerInstance $Instance.RepositoryServer `
            -Database $Instance.RepositoryDatabase `
            -DestinationTable "mon.CPUHistory" `
            -DataTable $targetTable

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"

        Write-MonitorLog "CPU collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "CPU collector failed for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-CPUCollector
