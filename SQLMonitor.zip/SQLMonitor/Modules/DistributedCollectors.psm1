$commonModulePath = Join-Path $PSScriptRoot 'Common.psm1'
if (-not (Get-Module -Name Common)) {
    Import-Module $commonModulePath -Global -WarningAction SilentlyContinue
}

function Get-SqlMonitorDistributedConfig {
    $path = Get-SqlMonitorConfigPath -FileName 'distributed.json'
    $default = [pscustomobject]@{
        DeploymentRole = 'Standalone'
        CollectorNodeName = $env:COMPUTERNAME
        SiteName = ''
        Tags = ''
        CentralRepositoryServer = ''
        CentralRepositoryDatabase = ''
    }

    try {
        $config = Read-SqlMonitorJsonFile -Path $path -DefaultValue $default
        if ($null -eq $config) { return $default }
        return $config
    }
    catch {
        Write-MonitorLog "WARNING: Could not read distributed collector config: $($_.Exception.Message)" -Level 'Warning'
        return $default
    }
}

function Get-SqlMonitorCollectorNodeName {
    param([object]$Config = $(Get-SqlMonitorDistributedConfig))
    if (-not [string]::IsNullOrWhiteSpace([string]$env:SQLMON_COLLECTOR_NODE)) { return [string]$env:SQLMON_COLLECTOR_NODE }
    if (-not [string]::IsNullOrWhiteSpace([string]$Config.CollectorNodeName)) { return [string]$Config.CollectorNodeName }
    return [string]$env:COMPUTERNAME
}

function Register-SqlMonitorCollectorNode {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [object]$Config = $(Get-SqlMonitorDistributedConfig)
    )

    $nodeName = Get-SqlMonitorCollectorNodeName -Config $Config
    $role = if ([string]::IsNullOrWhiteSpace([string]$Config.DeploymentRole)) { 'Standalone' } else { [string]$Config.DeploymentRole }
    $query = @"
MERGE mon.CollectorNodes AS target
USING (SELECT @NodeName AS NodeName) AS source
ON target.NodeName = source.NodeName
WHEN MATCHED THEN
    UPDATE SET HostName = @HostName,
               DeploymentRole = @DeploymentRole,
               SiteName = @SiteName,
               Tags = @Tags,
               VersionText = @VersionText,
               IsEnabled = 1,
               LastHeartbeat = SYSDATETIME(),
               LastSeenStatus = N'Registered'
WHEN NOT MATCHED THEN
    INSERT (NodeName, HostName, DeploymentRole, SiteName, Tags, VersionText, IsEnabled, LastHeartbeat, LastSeenStatus)
    VALUES (@NodeName, @HostName, @DeploymentRole, @SiteName, @Tags, @VersionText, 1, SYSDATETIME(), N'Registered');

SELECT CollectorNodeID FROM mon.CollectorNodes WHERE NodeName = @NodeName;
"@
    $nodeId = Invoke-MonitorSqlScalar -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters @{
        NodeName = $nodeName
        HostName = [string]$env:COMPUTERNAME
        DeploymentRole = $role
        SiteName = [string]$Config.SiteName
        Tags = [string]$Config.Tags
        VersionText = '1.0'
    }

    $env:SQLMON_COLLECTOR_NODE = $nodeName
    $env:SQLMON_COLLECTOR_NODE_ID = [string]$nodeId
    return [int]$nodeId
}

function Send-SqlMonitorCollectorHeartbeat {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [int]$CollectorNodeID,
        [string]$Status = 'Running',
        [string]$CollectorGroup = '',
        [int]$InstanceCount = 0,
        [string]$MessageText = ''
    )

    if ($CollectorNodeID -le 0) { return }
    $query = @"
UPDATE mon.CollectorNodes
SET LastHeartbeat = SYSDATETIME(),
    LastSeenStatus = @Status
WHERE CollectorNodeID = @CollectorNodeID;

INSERT INTO mon.CollectorNodeHeartbeat (CollectorNodeID, Status, CollectorGroup, InstanceCount, MessageText)
VALUES (@CollectorNodeID, @Status, @CollectorGroup, @InstanceCount, @MessageText);
"@
    Invoke-MonitorSqlNonQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters @{
        CollectorNodeID = $CollectorNodeID
        Status = $Status
        CollectorGroup = $CollectorGroup
        InstanceCount = $InstanceCount
        MessageText = $MessageText
    }
}

function Get-SqlMonitorCollectorAssignedInstances {
    param(
        [string]$RepositoryServer,
        [string]$RepositoryDatabase,
        [int]$CollectorNodeID,
        [string]$CollectorGroup = 'All'
    )

    if ($CollectorNodeID -le 0) { return @() }

    $query = @"
SELECT
    mi.InstanceID,
    mi.DisplayName,
    CASE WHEN mi.InstanceName IS NULL OR mi.InstanceName = N'MSSQLSERVER'
         THEN mi.ServerName
         ELSE mi.ServerName + N'\' + mi.InstanceName
    END AS SqlInstance,
    mi.EnvironmentName AS Environment,
    CAST(mi.IsActive AS bit) AS IsActive,
    @RepositoryServer AS RepositoryServer,
    @RepositoryDatabase AS RepositoryDatabase,
    ca.CollectorGroup,
    cn.NodeName AS CollectorNodeName,
    cn.CollectorNodeID
FROM mon.CollectorAssignments ca
INNER JOIN mon.CollectorNodes cn ON ca.CollectorNodeID = cn.CollectorNodeID
INNER JOIN mon.MonitoredInstances mi ON ca.InstanceID = mi.InstanceID
WHERE ca.CollectorNodeID = @CollectorNodeID
  AND ca.IsEnabled = 1
  AND cn.IsEnabled = 1
  AND mi.IsActive = 1
  AND (ca.CollectorGroup = N'All' OR ca.CollectorGroup = @CollectorGroup OR @CollectorGroup = N'All')
ORDER BY ca.Priority, mi.DisplayName;
"@
    $table = Invoke-MonitorSqlQuery -ServerInstance $RepositoryServer -Database $RepositoryDatabase -Query $query -Parameters @{
        CollectorNodeID = $CollectorNodeID
        CollectorGroup = $CollectorGroup
        RepositoryServer = $RepositoryServer
        RepositoryDatabase = $RepositoryDatabase
    }

    $instances = @()
    foreach ($row in $table.Rows) {
        $instances += [pscustomobject]@{
            InstanceID = [int]$row['InstanceID']
            DisplayName = [string]$row['DisplayName']
            SqlInstance = [string]$row['SqlInstance']
            Environment = [string]$row['Environment']
            IsActive = [bool]$row['IsActive']
            RepositoryServer = $RepositoryServer
            RepositoryDatabase = $RepositoryDatabase
            CollectorGroup = [string]$row['CollectorGroup']
            CollectorNodeName = [string]$row['CollectorNodeName']
            CollectorNodeID = [int]$row['CollectorNodeID']
        }
    }
    return $instances
}

Export-ModuleMember -Function Get-SqlMonitorDistributedConfig, Get-SqlMonitorCollectorNodeName, Register-SqlMonitorCollectorNode, Send-SqlMonitorCollectorHeartbeat, Get-SqlMonitorCollectorAssignedInstances
