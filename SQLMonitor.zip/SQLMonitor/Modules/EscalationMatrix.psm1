# EscalationMatrix.psm1 - Escalation Matrix Module
# Provides functions to configure and manage escalation rules and history

$commonModulePath = Join-Path $PSScriptRoot "Common.psm1"
if (Test-Path -LiteralPath $commonModulePath -PathType Leaf) {
    Import-Module $commonModulePath -Force -WarningAction SilentlyContinue
}

function Get-EscalationMatrixConfig {
    <#
    .SYNOPSIS
    Gets the configuration for Escalation Matrix module
    #>
    $configPath = Join-Path $PSScriptRoot "..\Config\instances.json"
    if (Test-Path $configPath) {
        $config = Get-Content $configPath | ConvertFrom-Json
        return @{
            ServerInstance = $config.RepositoryServer
            Database = $config.RepositoryDatabase
        }
    }
    throw "Configuration file not found at $configPath"
}

function Add-EscalationRule {
    <#
    .SYNOPSIS
    Adds or updates an escalation rule
    
    .PARAMETER Severity
    Ticket severity: Critical, High, Medium, Low
    
    .PARAMETER Level
    Escalation level: Level 1 - DBA Team, Level 2 - Senior DBA, Level 3 - DBA Manager, Level 4 - IT Management
    
    .PARAMETER EscalationTimeMinutes
    Time in minutes before escalating to this level
    
    .PARAMETER EscalationTo
    Email or team name to escalate to
    
    .PARAMETER NotificationTemplate
    Optional notification template (email body, etc.)
    
    .PARAMETER IsActive
    Whether this rule is active (default: true)
    
    .EXAMPLE
    Add-EscalationRule -Severity "Critical" -Level "Level 1 - DBA Team" -EscalationTimeMinutes 15 -EscalationTo "dba-team@company.com"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Critical", "High", "Medium", "Low")]
        [string]$Severity,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet("Level 1 - DBA Team", "Level 2 - Senior DBA", "Level 3 - DBA Manager", "Level 4 - IT Management")]
        [string]$Level,
        
        [Parameter(Mandatory = $true)]
        [int]$EscalationTimeMinutes,
        
        [Parameter(Mandatory = $true)]
        [string]$EscalationTo,
        
        [Parameter(Mandatory = $false)]
        [string]$NotificationTemplate = $null,
        
        [Parameter(Mandatory = $false)]
        [bool]$IsActive = $true
    )
    
    $config = Get-EscalationMatrixConfig
    
    # Map severity name to ID
    $severityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    # Map level name to ID
    $levelMap = @{
        "Level 1 - DBA Team" = 1
        "Level 2 - Senior DBA" = 2
        "Level 3 - DBA Manager" = 3
        "Level 4 - IT Management" = 4
    }
    
    $severityID = $severityMap[$Severity]
    $levelID = $levelMap[$Level]
    
    $query = @"
EXEC [mon].[usp_ConfigureEscalation]
    @TicketSeverityID = @TicketSeverityID,
    @EscalationLevelID = @EscalationLevelID,
    @EscalationTimeMinutes = @EscalationTimeMinutes,
    @EscalationTo = @EscalationTo,
    @NotificationTemplate = @NotificationTemplate,
    @IsActive = @IsActive
"@
    
    $parameters = @{
        TicketSeverityID = $severityID
        EscalationLevelID = $levelID
        EscalationTimeMinutes = $EscalationTimeMinutes
        EscalationTo = $EscalationTo
        NotificationTemplate = $NotificationTemplate
        IsActive = if ($IsActive) { 1 } else { 0 }
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Escalation rule configured for $Severity - $Level."
        return $result
    }
    catch {
        Write-MonitorLog "Error configuring escalation rule: $_" -Level Error
        throw
    }
}

function Get-EscalationRule {
    <#
    .SYNOPSIS
    Retrieves escalation rules based on filters
    
    .PARAMETER Severity
    Filter by severity: Critical, High, Medium, Low
    
    .PARAMETER IsActive
    Filter by active status (default: true)
    
    .EXAMPLE
    Get-EscalationRule -Severity "Critical"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [ValidateSet("", "Critical", "High", "Medium", "Low")]
        [string]$Severity = "",
        
        [Parameter(Mandatory = $false)]
        [bool]$IsActive = $true
    )
    
    $config = Get-EscalationMatrixConfig
    
    # Map severity name to ID
    $severityMap = @{
        "Critical" = 1
        "High" = 2
        "Medium" = 3
        "Low" = 4
    }
    
    $severityID = if ($Severity -and $Severity -ne "") { $severityMap[$Severity] } else { $null }
    
    $query = "EXEC [mon].[usp_GetEscalationRules] @TicketSeverityID, @IsActive"
    $parameters = @{
        TicketSeverityID = $severityID
        IsActive = if ($IsActive) { 1 } else { 0 }
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving escalation rules: $_" -Level Error
        throw
    }
}

function Add-EscalationHistory {
    <#
    .SYNOPSIS
    Records an escalation event in the history
    
    .PARAMETER TicketID
    ID of the ticket being escalated
    
    .PARAMETER Level
    Escalation level: Level 1 - DBA Team, Level 2 - Senior DBA, Level 3 - DBA Manager, Level 4 - IT Management
    
    .PARAMETER EscalatedTo
    Email or team name that was escalated to
    
    .PARAMETER EscalatedBy
    Person performing the escalation
    
    .EXAMPLE
    Add-EscalationHistory -TicketID 1 -Level "Level 2 - Senior DBA" -EscalatedTo "senior-dba@company.com" -EscalatedBy "system"
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [bigint]$TicketID,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet("Level 1 - DBA Team", "Level 2 - Senior DBA", "Level 3 - DBA Manager", "Level 4 - IT Management")]
        [string]$Level,
        
        [Parameter(Mandatory = $true)]
        [string]$EscalatedTo,
        
        [Parameter(Mandatory = $false)]
        [string]$EscalatedBy = "system"
    )
    
    $config = Get-EscalationMatrixConfig
    
    # Map level name to ID
    $levelMap = @{
        "Level 1 - DBA Team" = 1
        "Level 2 - Senior DBA" = 2
        "Level 3 - DBA Manager" = 3
        "Level 4 - IT Management" = 4
    }
    
    $levelID = $levelMap[$Level]
    
    $query = @"
EXEC [mon].[usp_RecordEscalation]
    @TicketID = @TicketID,
    @EscalationLevelID = @EscalationLevelID,
    @EscalatedTo = @EscalatedTo,
    @EscalatedBy = @EscalatedBy
"@
    
    $parameters = @{
        TicketID = $TicketID
        EscalationLevelID = $levelID
        EscalatedTo = $EscalatedTo
        EscalatedBy = $EscalatedBy
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        Write-MonitorLog "Escalation recorded for Ticket $TicketID to $Level."
        return $result
    }
    catch {
        Write-MonitorLog "Error recording escalation: $_" -Level Error
        throw
    }
}

function Get-EscalationHistory {
    <#
    .SYNOPSIS
    Retrieves escalation history for a specific ticket or all tickets
    
    .PARAMETER TicketID
    ID of the ticket (optional - if omitted, returns all history)
    
    .EXAMPLE
    Get-EscalationHistory -TicketID 1
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [bigint]$TicketID = $null
    )
    
    $config = Get-EscalationMatrixConfig
    
    if ($TicketID) {
        $query = "SELECT * FROM [mon].[vw_EscalationHistory] WHERE TicketID = @TicketID ORDER BY EscalatedOn DESC"
        $parameters = @{ TicketID = $TicketID }
    }
    else {
        $query = "SELECT * FROM [mon].[vw_EscalationHistory] ORDER BY EscalatedOn DESC"
        $parameters = @{}
    }
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters $parameters
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving escalation history: $_" -Level Error
        throw
    }
}

function Invoke-EscalationCheck {
    <#
    .SYNOPSIS
    Checks for tickets pending escalation and processes them
    
    .PARAMETER WhatIf
    If specified, shows what would be escalated without actually escalating
    
    .EXAMPLE
    Invoke-EscalationCheck
    
    .EXAMPLE
    Invoke-EscalationCheck -WhatIf
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [switch]$WhatIf
    )
    
    $config = Get-EscalationMatrixConfig
    
    try {
        # Get tickets pending escalation
        $pendingTickets = Get-TicketsPendingEscalation
        
        if ($pendingTickets -and $pendingTickets.Rows.Count -gt 0) {
            Write-MonitorLog "Found $($pendingTickets.Rows.Count) ticket(s) pending escalation."
            
            foreach ($ticket in $pendingTickets) {
                if ($WhatIf) {
                    Write-MonitorLog "WHATIF: Would escalate Ticket $($ticket.TicketNumber) to $($ticket.EscalationLevel) - $($ticket.EscalationTo)"
                }
                else {
                    # Record the escalation
                    Add-EscalationHistory -TicketID $ticket.TicketID `
                                          -Level $ticket.EscalationLevel `
                                          -EscalatedTo $ticket.EscalationTo `
                                          -EscalatedBy "system"
                    
                    Write-MonitorLog "Escalated Ticket $($ticket.TicketNumber) to $($ticket.EscalationLevel) - $($ticket.EscalationTo)"
                    
                    # TODO: Send notification email here using $ticket.NotificationTemplate
                }
            }
        }
        else {
            Write-MonitorLog "No tickets pending escalation."
        }
        
        return $pendingTickets
    }
    catch {
        Write-MonitorLog "Error checking escalations: $_" -Level Error
        throw
    }
}

function Get-TicketsPendingEscalation {
    <#
    .SYNOPSIS
    Retrieves tickets that are pending escalation based on configured rules
    
    .EXAMPLE
    Get-TicketsPendingEscalation
    #>
    [CmdletBinding()]
    param()
    
    $config = Get-EscalationMatrixConfig
    
    $query = "SELECT * FROM [mon].[vw_TicketsPendingEscalation]"
    
    try {
        $result = Invoke-MonitorSqlQuery -ServerInstance $config.ServerInstance `
                                          -Database $config.Database `
                                          -Query $query `
                                          -Parameters @{}
        return $result
    }
    catch {
        Write-MonitorLog "Error retrieving tickets pending escalation: $_" -Level Error
        throw
    }
}

function Set-DefaultEscalationRules {
    <#
    .SYNOPSIS
    Sets up default escalation rules for all severity levels
    
    .EXAMPLE
    Set-DefaultEscalationRules
    #>
    [CmdletBinding()]
    param()
    
    try {
        Write-MonitorLog "Setting up default escalation rules..."
        
        # Critical - Escalate quickly
        Add-EscalationRule -Severity "Critical" -Level "Level 1 - DBA Team" -EscalationTimeMinutes 15 -EscalationTo "dba-team@company.com" -NotificationTemplate "CRITICAL ALERT: Ticket {TicketNumber} needs immediate attention!"
        Add-EscalationRule -Severity "Critical" -Level "Level 2 - Senior DBA" -EscalationTimeMinutes 30 -EscalationTo "senior-dba@company.com" -NotificationTemplate "CRITICAL ESCALATION: Ticket {TicketNumber} has been escalated to you."
        Add-EscalationRule -Severity "Critical" -Level "Level 3 - DBA Manager" -EscalationTimeMinutes 60 -EscalationTo "dba-manager@company.com" -NotificationTemplate "URGENT: Ticket {TicketNumber} requires management attention!"
        
        # High - Escalate moderately
        Add-EscalationRule -Severity "High" -Level "Level 1 - DBA Team" -EscalationTimeMinutes 30 -EscalationTo "dba-team@company.com"
        Add-EscalationRule -Severity "High" -Level "Level 2 - Senior DBA" -EscalationTimeMinutes 60 -EscalationTo "senior-dba@company.com"
        Add-EscalationRule -Severity "High" -Level "Level 3 - DBA Manager" -EscalationTimeMinutes 120 -EscalationTo "dba-manager@company.com"
        
        # Medium - Escalate slowly
        Add-EscalationRule -Severity "Medium" -Level "Level 1 - DBA Team" -EscalationTimeMinutes 60 -EscalationTo "dba-team@company.com"
        Add-EscalationRule -Severity "Medium" -Level "Level 2 - Senior DBA" -EscalationTimeMinutes 120 -EscalationTo "senior-dba@company.com"
        
        # Low - Escalate very slowly
        Add-EscalationRule -Severity "Low" -Level "Level 1 - DBA Team" -EscalationTimeMinutes 120 -EscalationTo "dba-team@company.com"
        
        Write-MonitorLog "Default escalation rules configured successfully."
    }
    catch {
        Write-MonitorLog "Error setting default escalation rules: $_" -Level Error
        throw
    }
}

# Export module functions
Export-ModuleMember -Function Add-EscalationRule, Get-EscalationRule, Add-EscalationHistory, 
                              Get-EscalationHistory, Invoke-EscalationCheck, 
                              Get-TicketsPendingEscalation, Set-DefaultEscalationRules
