function Invoke-TopQueriesCollector {
    param (
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$Instance
    )

    $moduleName = "TopQueries"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    $query = @"
SELECT TOP 20
    qt.query_sql_text,
    q.query_id,
    p.plan_id,
    rs.avg_logical_io_reads,
    rs.avg_logical_io_writes,
    rs.avg_physical_io_reads,
    rs.avg_cpu_time,
    rs.avg_duration,
    rs.count_executions,
    rs.avg_rowcount
FROM sys.query_store_query q
INNER JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
INNER JOIN sys.query_store_plan p ON q.query_id = p.query_id
INNER JOIN sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
INNER JOIN sys.query_store_runtime_stats_interval rsi ON rs.runtime_stats_interval_id = rsi.runtime_stats_interval_id
WHERE rsi.start_time >= DATEADD(hour, -1, GETUTCDATE())
ORDER BY rs.avg_cpu_time DESC
"@

    try {
        Write-MonitorLog "Top queries collector started for $($Instance.DisplayName)"
        
        # Check if Query Store is enabled on any database
        $qsCheck = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query "SELECT name FROM sys.databases WHERE is_query_store_on = 1 AND state_desc = 'ONLINE' AND source_database_id IS NULL"
        
        $insertedCount = 0
        
        if ($qsCheck.Rows.Count -gt 0) {
            # Use Query Store
            $query = @"
SELECT TOP 20
    qt.query_sql_text,
    q.query_id,
    p.plan_id,
    rs.avg_logical_io_reads,
    rs.avg_logical_io_writes,
    rs.avg_physical_io_reads,
    rs.avg_cpu_time,
    rs.avg_duration,
    rs.count_executions,
    rs.avg_rowcount
FROM sys.query_store_query q
INNER JOIN sys.query_store_query_text qt ON q.query_text_id = qt.query_text_id
INNER JOIN sys.query_store_plan p ON q.query_id = p.query_id
INNER JOIN sys.query_store_runtime_stats rs ON p.plan_id = rs.plan_id
INNER JOIN sys.query_store_runtime_stats_interval rsi ON rs.runtime_stats_interval_id = rsi.runtime_stats_interval_id
WHERE rsi.start_time >= DATEADD(hour, -1, GETUTCDATE())
ORDER BY rs.avg_cpu_time DESC
"@

            foreach ($dbRow in $qsCheck.Rows) {
                $dbName = $dbRow['name'].ToString()
                
                try {
                    $queriesData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database $dbName -Query $query
                    
                    if ($queriesData.Rows.Count -gt 0) {
                        foreach ($q in $queriesData.Rows) {
                            $queryText = if ($q['query_sql_text'] -is [System.DBNull]) { '' } else { $q['query_sql_text'].ToString().Replace("'", "''") }
                            $queryId = if ($q['query_id'] -is [System.DBNull]) { '0' } else { $q['query_id'].ToString() }
                            $planId = if ($q['plan_id'] -is [System.DBNull]) { '0' } else { $q['plan_id'].ToString() }
                            $avgCpu = if ($q['avg_cpu_time'] -is [System.DBNull]) { '0' } else { $q['avg_cpu_time'].ToString() }
                            $avgDuration = if ($q['avg_duration'] -is [System.DBNull]) { '0' } else { $q['avg_duration'].ToString() }
                            $avgReads = if ($q['avg_logical_io_reads'] -is [System.DBNull]) { '0' } else { $q['avg_logical_io_reads'].ToString() }
                            $avgWrites = if ($q['avg_logical_io_writes'] -is [System.DBNull]) { '0' } else { $q['avg_logical_io_writes'].ToString() }
                            $avgPhysicalReads = if ($q['avg_physical_io_reads'] -is [System.DBNull]) { '0' } else { $q['avg_physical_io_reads'].ToString() }
                            $execCount = if ($q['count_executions'] -is [System.DBNull]) { '0' } else { $q['count_executions'].ToString() }
                            $avgRows = if ($q['avg_rowcount'] -is [System.DBNull]) { '0' } else { $q['avg_rowcount'].ToString() }
                            
                            $insertQuery = @"
INSERT INTO dbo.TopQueries (
    InstanceID, CollectionDateTime, QueryID, PlanID, QueryText,
    AvgCpuTime, AvgDuration, AvgLogicalIOReads, AvgLogicalIOWrites,
    AvgPhysicalIOReads, CountExecutions, AvgRowCount
) VALUES (
    $instanceId, SYSDATETIME(), $queryId, $planId, N'$queryText',
    $avgCpu, $avgDuration, $avgReads, $avgWrites, $avgPhysicalReads, $execCount, $avgRows
)
"@
                            
                            Invoke-MonitorSqlNonQuery `
                                -ServerInstance $Instance.RepositoryServer `
                                -Database $Instance.RepositoryDatabase `
                                -Query $insertQuery
                            
                            $insertedCount++
                        }
                    }
                }
                catch {
                    Write-MonitorLog "Warning: Failed to query Query Store for $dbName - $($_.Exception.Message)"
                }
            }
        }
        else {
            # Use DMV if Query Store not enabled
            Write-MonitorLog "Query Store not enabled, using DMV for top queries"
            $query = @"
SELECT TOP 20
    st.text AS query_sql_text,
    qs.sql_handle AS query_id,
    qs.plan_handle AS plan_id,
    qs.total_logical_reads / qs.execution_count AS avg_logical_io_reads,
    qs.total_logical_writes / qs.execution_count AS avg_logical_io_writes,
    qs.total_physical_reads / qs.execution_count AS avg_physical_io_reads,
    qs.total_worker_time / qs.execution_count AS avg_cpu_time,
    qs.total_elapsed_time / qs.execution_count AS avg_duration,
    qs.execution_count AS count_executions,
    qs.total_rows / qs.execution_count AS avg_rowcount
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
WHERE qs.last_execution_time >= DATEADD(hour, -1, GETDATE())
ORDER BY qs.total_worker_time / qs.execution_count DESC
"@

            $queriesData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query
            
            if ($queriesData.Rows.Count -gt 0) {
                foreach ($q in $queriesData.Rows) {
                    $queryText = if ($q['query_sql_text'] -is [System.DBNull]) { '' } else { $q['query_sql_text'].ToString().Replace("'", "''") }
                    $queryId = '0'  # DMV doesn't have query_id
                    $planId = '0'  # DMV doesn't have plan_id
                    $avgCpu = if ($q['avg_cpu_time'] -is [System.DBNull]) { '0' } else { $q['avg_cpu_time'].ToString() }
                    $avgDuration = if ($q['avg_duration'] -is [System.DBNull]) { '0' } else { $q['avg_duration'].ToString() }
                    $avgReads = if ($q['avg_logical_io_reads'] -is [System.DBNull]) { '0' } else { $q['avg_logical_io_reads'].ToString() }
                    $avgWrites = if ($q['avg_logical_io_writes'] -is [System.DBNull]) { '0' } else { $q['avg_logical_io_writes'].ToString() }
                    $avgPhysicalReads = if ($q['avg_physical_io_reads'] -is [System.DBNull]) { '0' } else { $q['avg_physical_io_reads'].ToString() }
                    $execCount = if ($q['count_executions'] -is [System.DBNull]) { '0' } else { $q['count_executions'].ToString() }
                    $avgRows = if ($q['avg_rowcount'] -is [System.DBNull]) { '0' } else { $q['avg_rowcount'].ToString() }
                    
                    $insertQuery = @"
INSERT INTO dbo.TopQueries (
    InstanceID, CollectionDateTime, QueryID, PlanID, QueryText,
    AvgCpuTime, AvgDuration, AvgLogicalIOReads, AvgLogicalIOWrites,
    AvgPhysicalIOReads, CountExecutions, AvgRowCount
) VALUES (
    $instanceId, SYSDATETIME(), $queryId, $planId, N'$queryText',
    $avgCpu, $avgDuration, $avgReads, $avgWrites, $avgPhysicalReads, $execCount, $avgRows
)
"@
                    
                    Invoke-MonitorSqlNonQuery `
                        -ServerInstance $Instance.RepositoryServer `
                        -Database $Instance.RepositoryDatabase `
                        -Query $insertQuery
                    
                    $insertedCount++
                }
            }
        }
        
        Write-MonitorLog "Top queries collector completed for $($Instance.DisplayName). Rows inserted: $insertedCount"

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-TopQueriesCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-TopQueriesCollector
