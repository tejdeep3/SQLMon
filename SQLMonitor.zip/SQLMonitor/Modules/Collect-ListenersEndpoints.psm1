function Invoke-ListenersEndpointsCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "ListenersEndpoints"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Listeners & Endpoints collector started for $($Instance.DisplayName)"

        # Collect AG Listeners
        $listenerQuery = @"
        SELECT DISTINCT
            agl.dns_name as ListenerName,
            ag.name as AvailabilityGroupName,
            agl.port as Port,
            CASE WHEN agl.is_conformant = 1 THEN 'Online' ELSE 'Offline' END as State
        FROM sys.availability_group_listeners agl
        INNER JOIN sys.availability_groups ag ON agl.group_id = ag.group_id
"@

        $listenerData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $listenerQuery

        if ($listenerData.Rows.Count -gt 0) {
            foreach ($listener in $listenerData.Rows) {
                $insertQuery = @"
                INSERT INTO mon.ListenerHistory 
                (InstanceID, CaptureTime, ListenerName, AvailabilityGroupName, Port, State, UpdatedTime)
                VALUES
                ($instanceId, SYSDATETIME(), N'$($listener['ListenerName'])', N'$($listener['AvailabilityGroupName'])', $($listener['Port']), N'$($listener['State'])', SYSDATETIME())
"@

                Invoke-MonitorSqlNonQuery `
                    -ServerInstance $Instance.RepositoryServer `
                    -Database $Instance.RepositoryDatabase `
                    -Query $insertQuery
            }

            Write-MonitorLog "Listeners collected for $($Instance.DisplayName). Rows inserted: $($listenerData.Rows.Count)"
        }

        # Collect Endpoints
        $endpointQuery = @"
        SELECT
            e.name as EndpointName,
            e.type_desc as EndpointType,
            e.protocol_desc as Protocol,
            e.state_desc as State,
            tcp.port as Port
        FROM sys.database_mirroring_endpoints e
        LEFT JOIN sys.tcp_endpoints tcp ON e.endpoint_id = tcp.endpoint_id
"@

        $endpointData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $endpointQuery

        if ($endpointData.Rows.Count -gt 0) {
            foreach ($endpoint in $endpointData.Rows) {
                $insertQuery = @"
                INSERT INTO mon.EndpointHistory 
                (InstanceID, CaptureTime, EndpointName, EndpointType, Protocol, State, Port, UpdatedTime)
                VALUES
                ($instanceId, SYSDATETIME(), N'$($endpoint['EndpointName'])', N'$($endpoint['EndpointType'])', N'$($endpoint['Protocol'])', N'$($endpoint['State'])', $($endpoint['Port']), SYSDATETIME())
"@

                Invoke-MonitorSqlNonQuery `
                    -ServerInstance $Instance.RepositoryServer `
                    -Database $Instance.RepositoryDatabase `
                    -Query $insertQuery
            }

            Write-MonitorLog "Endpoints collected for $($Instance.DisplayName). Rows inserted: $($endpointData.Rows.Count)"
        }

        Write-MonitorLog "Listeners & Endpoints collector completed for $($Instance.DisplayName)"

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-ListenersEndpointsCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-ListenersEndpointsCollector
