function Invoke-AGCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "AlwaysOn"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        $overviewQuery = @"
BEGIN TRY
    SELECT
        SYSDATETIME() AS CaptureTime,
        ag.name AS AGName,
        gs.primary_replica AS PrimaryReplica,
        gs.synchronization_health_desc AS SyncHealthDesc,
        ag.automated_backup_preference_desc AS BackupPreferenceDesc,
        ag.failure_condition_level AS FailureConditionLevel,
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM sys.all_columns
                WHERE object_id = OBJECT_ID('sys.availability_groups')
                  AND name = 'cluster_type_desc'
            )
            THEN ag.cluster_type_desc
            ELSE NULL
        END AS ClusterTypeDesc
    FROM sys.availability_groups ag
    LEFT JOIN sys.dm_hadr_availability_group_states gs
        ON ag.group_id = gs.group_id;
END TRY
BEGIN CATCH
    SELECT
        SYSDATETIME() AS CaptureTime,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS sysname) AS PrimaryReplica,
        CAST(NULL AS nvarchar(60)) AS SyncHealthDesc,
        CAST(NULL AS nvarchar(60)) AS BackupPreferenceDesc,
        CAST(NULL AS int) AS FailureConditionLevel,
        CAST(NULL AS nvarchar(60)) AS ClusterTypeDesc
    WHERE 1 = 0;
END CATCH;
"@

        $overviewRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $overviewQuery `
            -CommandTimeout 180

        $overviewTable = New-Object System.Data.DataTable
        [void]$overviewTable.Columns.Add('InstanceID', [int])
        [void]$overviewTable.Columns.Add('CaptureTime', [datetime])
        [void]$overviewTable.Columns.Add('AGName', [string])
        [void]$overviewTable.Columns.Add('PrimaryReplica', [string])
        [void]$overviewTable.Columns.Add('SyncHealthDesc', [string])
        [void]$overviewTable.Columns.Add('BackupPreferenceDesc', [string])
        [void]$overviewTable.Columns.Add('FailureConditionLevel', [int])
        [void]$overviewTable.Columns.Add('ClusterTypeDesc', [string])

        foreach ($row in $overviewRows.Rows) {
            $newRow = $overviewTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime]$row["CaptureTime"]
            $newRow["AGName"] = $row["AGName"]
            $newRow["PrimaryReplica"] = $row["PrimaryReplica"]
            $newRow["SyncHealthDesc"] = $row["SyncHealthDesc"]
            $newRow["BackupPreferenceDesc"] = $row["BackupPreferenceDesc"]
            $newRow["FailureConditionLevel"] = $row["FailureConditionLevel"]
            $newRow["ClusterTypeDesc"] = $row["ClusterTypeDesc"]
            $overviewTable.Rows.Add($newRow)
        }

        if ($overviewTable.Rows.Count -gt 0) {
            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.AGOverviewHistory" `
                -DataTable $overviewTable
        }

        $replicaQuery = @"
BEGIN TRY
    SELECT
        SYSDATETIME() AS CaptureTime,
        ag.name AS AGName,
        ar.replica_server_name AS ReplicaServer,
        rs.is_local AS IsLocal,
        CASE WHEN gs.primary_replica = ar.replica_server_name THEN 'PRIMARY' ELSE 'SECONDARY' END AS RoleDesc,
        ar.availability_mode_desc AS AvailabilityModeDesc,
        ar.failover_mode_desc AS FailoverModeDesc,
        rs.synchronization_health_desc AS SyncHealthDesc,
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM sys.all_columns
                WHERE object_id = OBJECT_ID('sys.dm_hadr_availability_replica_states')
                  AND name = 'connected_state_desc'
            )
            THEN rs.connected_state_desc
            ELSE NULL
        END AS ConnectedStateDesc
    FROM sys.availability_groups ag
    INNER JOIN sys.availability_replicas ar
        ON ag.group_id = ar.group_id
    LEFT JOIN sys.dm_hadr_availability_replica_states rs
        ON ar.replica_id = rs.replica_id
    LEFT JOIN sys.dm_hadr_availability_group_states gs
        ON ag.group_id = gs.group_id;
END TRY
BEGIN CATCH
    SELECT
        SYSDATETIME() AS CaptureTime,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS sysname) AS ReplicaServer,
        CAST(NULL AS bit) AS IsLocal,
        CAST(NULL AS nvarchar(60)) AS RoleDesc,
        CAST(NULL AS nvarchar(60)) AS AvailabilityModeDesc,
        CAST(NULL AS nvarchar(60)) AS FailoverModeDesc,
        CAST(NULL AS nvarchar(60)) AS SyncHealthDesc,
        CAST(NULL AS nvarchar(60)) AS ConnectedStateDesc
    WHERE 1 = 0;
END CATCH;
"@

        $replicaRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $replicaQuery `
            -CommandTimeout 180

        $replicaTable = New-Object System.Data.DataTable
        [void]$replicaTable.Columns.Add('InstanceID', [int])
        [void]$replicaTable.Columns.Add('CaptureTime', [datetime])
        [void]$replicaTable.Columns.Add('AGName', [string])
        [void]$replicaTable.Columns.Add('ReplicaServer', [string])
        [void]$replicaTable.Columns.Add('IsLocal', [bool])
        [void]$replicaTable.Columns.Add('RoleDesc', [string])
        [void]$replicaTable.Columns.Add('AvailabilityModeDesc', [string])
        [void]$replicaTable.Columns.Add('FailoverModeDesc', [string])
        [void]$replicaTable.Columns.Add('SyncHealthDesc', [string])
        [void]$replicaTable.Columns.Add('ConnectedStateDesc', [string])

        foreach ($row in $replicaRows.Rows) {
            $newRow = $replicaTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime]$row["CaptureTime"]
            $newRow["AGName"] = $row["AGName"]
            $newRow["ReplicaServer"] = $row["ReplicaServer"]
            $newRow["IsLocal"] = $row["IsLocal"]
            $newRow["RoleDesc"] = $row["RoleDesc"]
            $newRow["AvailabilityModeDesc"] = $row["AvailabilityModeDesc"]
            $newRow["FailoverModeDesc"] = $row["FailoverModeDesc"]
            $newRow["SyncHealthDesc"] = $row["SyncHealthDesc"]
            $newRow["ConnectedStateDesc"] = $row["ConnectedStateDesc"]
            $replicaTable.Rows.Add($newRow)
        }

        if ($replicaTable.Rows.Count -gt 0) {
            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.AGReplicaHistory" `
                -DataTable $replicaTable
        }

        $dbQuery = @"
BEGIN TRY
    SELECT
        SYSDATETIME() AS CaptureTime,
        ag.name AS AGName,
        ar.replica_server_name AS ReplicaServer,
        d.name AS DatabaseName,
        CASE WHEN gs.primary_replica = ar.replica_server_name THEN 1 ELSE 0 END AS IsPrimaryReplica,
        drs.synchronization_state_desc AS SyncStateDesc,
        drs.synchronization_health_desc AS SyncHealthDesc,
        CAST(drs.log_send_queue_size / 1024.0 AS DECIMAL(18,2)) AS LogSendQueueMB,
        CAST(drs.redo_queue_size / 1024.0 AS DECIMAL(18,2)) AS RedoQueueMB,
        drs.last_commit_time AS LastCommitTime
    FROM sys.dm_hadr_database_replica_states drs
    INNER JOIN sys.availability_replicas ar
        ON drs.replica_id = ar.replica_id
    INNER JOIN sys.availability_groups ag
        ON ar.group_id = ag.group_id
    INNER JOIN sys.databases d
        ON drs.database_id = d.database_id
    LEFT JOIN sys.dm_hadr_availability_group_states gs
        ON ag.group_id = gs.group_id;
END TRY
BEGIN CATCH
    SELECT
        SYSDATETIME() AS CaptureTime,
        CAST(NULL AS sysname) AS AGName,
        CAST(NULL AS sysname) AS ReplicaServer,
        CAST(NULL AS sysname) AS DatabaseName,
        CAST(NULL AS bit) AS IsPrimaryReplica,
        CAST(NULL AS nvarchar(60)) AS SyncStateDesc,
        CAST(NULL AS nvarchar(60)) AS SyncHealthDesc,
        CAST(NULL AS decimal(18,2)) AS LogSendQueueMB,
        CAST(NULL AS decimal(18,2)) AS RedoQueueMB,
        CAST(NULL AS datetime) AS LastCommitTime
    WHERE 1 = 0;
END CATCH;
"@

        $dbRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $dbQuery `
            -CommandTimeout 180

        $dbTable = New-Object System.Data.DataTable
        [void]$dbTable.Columns.Add('InstanceID', [int])
        [void]$dbTable.Columns.Add('CaptureTime', [datetime])
        [void]$dbTable.Columns.Add('AGName', [string])
        [void]$dbTable.Columns.Add('ReplicaServer', [string])
        [void]$dbTable.Columns.Add('DatabaseName', [string])
        [void]$dbTable.Columns.Add('IsPrimaryReplica', [bool])
        [void]$dbTable.Columns.Add('SyncStateDesc', [string])
        [void]$dbTable.Columns.Add('SyncHealthDesc', [string])
        [void]$dbTable.Columns.Add('LogSendQueueMB', [decimal])
        [void]$dbTable.Columns.Add('RedoQueueMB', [decimal])
        [void]$dbTable.Columns.Add('LastCommitTime', [datetime])

        foreach ($row in $dbRows.Rows) {
            $newRow = $dbTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime]$row["CaptureTime"]
            $newRow["AGName"] = $row["AGName"]
            $newRow["ReplicaServer"] = $row["ReplicaServer"]
            $newRow["DatabaseName"] = $row["DatabaseName"]
            $newRow["IsPrimaryReplica"] = $row["IsPrimaryReplica"]
            $newRow["SyncStateDesc"] = $row["SyncStateDesc"]
            $newRow["SyncHealthDesc"] = $row["SyncHealthDesc"]
            $newRow["LogSendQueueMB"] = $row["LogSendQueueMB"]
            $newRow["RedoQueueMB"] = $row["RedoQueueMB"]
            $newRow["LastCommitTime"] = $row["LastCommitTime"]
            $dbTable.Rows.Add($newRow)
        }

        if ($dbTable.Rows.Count -gt 0) {
            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.AGDatabaseHistory" `
                -DataTable $dbTable
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-AGCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-AGCollector
