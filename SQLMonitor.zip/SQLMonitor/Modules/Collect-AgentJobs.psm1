function Invoke-AgentJobsCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "AgentJobs"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        $query = @"
DECLARE @Now DATETIME = GETDATE();
DECLARE @WindowStart DATETIME = DATEADD(HOUR, -24, @Now);

IF DB_ID('msdb') IS NULL
BEGIN
    SELECT
        SYSDATETIME() AS CaptureTime,
        CAST(NULL AS sysname) AS JobName,
        CAST(0 AS bit) AS Enabled,
        CAST(NULL AS nvarchar(128)) AS Category,
        CAST(NULL AS datetime) AS LastRunTime,
        CAST(NULL AS nvarchar(40)) AS LastStatus,
        CAST(NULL AS int) AS LastDurationSec,
        CAST(NULL AS datetime) AS NextRunTime,
        CAST(NULL AS int) AS RunsRecent,
        CAST(NULL AS int) AS FailuresRecent,
        CAST(NULL AS decimal(10,2)) AS SuccessPctRecent,
        CAST(NULL AS int) AS AvgDurationSecRecent,
        CAST(NULL AS datetime) AS LastFailureTime,
        CAST(NULL AS nvarchar(1024)) AS LastFailureMessage
    WHERE 1 = 0;
    RETURN;
END;

;WITH JobBase AS
(
    SELECT
        j.job_id,
        j.name AS JobName,
        j.enabled AS Enabled,
        c.name AS Category
    FROM msdb.dbo.sysjobs j
    LEFT JOIN msdb.dbo.syscategories c
        ON j.category_id = c.category_id
       AND c.category_class = 1
),
LastRun AS
(
    SELECT
        j.job_id,
        CASE WHEN h.run_date > 0 THEN
            DATEADD(SECOND,
                (ISNULL(h.run_time,0)/10000)*3600 +
                ((ISNULL(h.run_time,0)%10000)/100)*60 +
                (ISNULL(h.run_time,0)%100),
                TRY_CONVERT(DATETIME, RIGHT('00000000' + CONVERT(VARCHAR(8), h.run_date), 8), 112)
            )
        END AS LastRunTime,
        CASE h.run_status
            WHEN 1 THEN N'Succeeded'
            WHEN 0 THEN N'Failed'
            WHEN 2 THEN N'Retry'
            WHEN 3 THEN N'Canceled'
            WHEN 4 THEN N'In Progress'
            ELSE N'Unknown'
        END AS LastStatus,
        CASE WHEN h.run_duration IS NULL THEN NULL
             ELSE (h.run_duration/10000)*3600 + ((h.run_duration%10000)/100)*60 + (h.run_duration%100)
        END AS LastDurationSec,
        LEFT(REPLACE(REPLACE(REPLACE(h.message, CHAR(13), N' '), CHAR(10), N' '), CHAR(0), N''), 1000) AS LastMessage,
        ROW_NUMBER() OVER (PARTITION BY j.job_id ORDER BY h.instance_id DESC) AS rn
    FROM msdb.dbo.sysjobs j
    LEFT JOIN msdb.dbo.sysjobhistory h
        ON j.job_id = h.job_id
       AND h.step_id = 0
),
NextRun AS
(
    SELECT
        js.job_id,
        MIN(
            CASE WHEN js.next_run_date > 0 THEN
                DATEADD(SECOND,
                    (ISNULL(js.next_run_time,0)/10000)*3600 +
                    ((ISNULL(js.next_run_time,0)%10000)/100)*60 +
                    (ISNULL(js.next_run_time,0)%100),
                    TRY_CONVERT(DATETIME, RIGHT('00000000' + CONVERT(VARCHAR(8), js.next_run_date), 8), 112)
                )
            END
        ) AS NextRunTime
    FROM msdb.dbo.sysjobschedules js
    GROUP BY js.job_id
),
RunWindow AS
(
    SELECT
        h.job_id,
        COUNT(*) AS RunsRecent,
        SUM(CASE WHEN h.run_status = 0 THEN 1 ELSE 0 END) AS FailuresRecent,
        CAST(
            CASE WHEN COUNT(*) = 0 THEN NULL
                 ELSE 100.0 * SUM(CASE WHEN h.run_status = 1 THEN 1 ELSE 0 END) / COUNT(*)
            END
            AS DECIMAL(10,2)
        ) AS SuccessPctRecent,
        CAST(AVG(
            CASE WHEN h.run_duration IS NULL THEN NULL
                 ELSE (h.run_duration/10000)*3600 + ((h.run_duration%10000)/100)*60 + (h.run_duration%100)
            END
        ) AS INT) AS AvgDurationSecRecent
    FROM msdb.dbo.sysjobhistory h
    WHERE h.step_id = 0
      AND CASE WHEN h.run_date > 0 THEN
            DATEADD(SECOND,
                (ISNULL(h.run_time,0)/10000)*3600 +
                ((ISNULL(h.run_time,0)%10000)/100)*60 +
                (ISNULL(h.run_time,0)%100),
                TRY_CONVERT(DATETIME, RIGHT('00000000' + CONVERT(VARCHAR(8), h.run_date), 8), 112)
            )
          END >= @WindowStart
    GROUP BY h.job_id
),
LastFailure AS
(
    SELECT
        x.job_id,
        x.LastFailureTime,
        x.LastFailureMessage
    FROM
    (
        SELECT
            h.job_id,
            CASE WHEN h.run_date > 0 THEN
                DATEADD(SECOND,
                    (ISNULL(h.run_time,0)/10000)*3600 +
                    ((ISNULL(h.run_time,0)%10000)/100)*60 +
                    (ISNULL(h.run_time,0)%100),
                    TRY_CONVERT(DATETIME, RIGHT('00000000' + CONVERT(VARCHAR(8), h.run_date), 8), 112)
                )
            END AS LastFailureTime,
            LEFT(REPLACE(REPLACE(REPLACE(h.message, CHAR(13), N' '), CHAR(10), N' '), CHAR(0), N''), 1000) AS LastFailureMessage,
            ROW_NUMBER() OVER (PARTITION BY h.job_id ORDER BY h.instance_id DESC) AS rn
        FROM msdb.dbo.sysjobhistory h
        WHERE h.step_id = 0
          AND h.run_status = 0
    ) x
    WHERE x.rn = 1
)
SELECT
    SYSDATETIME() AS CaptureTime,
    jb.JobName,
    jb.Enabled,
    jb.Category,
    lr.LastRunTime,
    lr.LastStatus,
    lr.LastDurationSec,
    nr.NextRunTime,
    rw.RunsRecent,
    rw.FailuresRecent,
    rw.SuccessPctRecent,
    rw.AvgDurationSecRecent,
    lf.LastFailureTime,
    lf.LastFailureMessage
FROM JobBase jb
LEFT JOIN LastRun lr
    ON jb.job_id = lr.job_id
   AND lr.rn = 1
LEFT JOIN NextRun nr
    ON jb.job_id = nr.job_id
LEFT JOIN RunWindow rw
    ON jb.job_id = rw.job_id
LEFT JOIN LastFailure lf
    ON jb.job_id = lf.job_id
ORDER BY jb.JobName;
"@

        $sourceRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $query `
            -CommandTimeout 180

        if ($null -eq $sourceRows -or $null -eq $sourceRows.Rows) {
            Write-MonitorLog "Agent jobs collector returned no result set for $($Instance.DisplayName)" -Level 'Warning'
            Stop-CollectionRun `
                -RepositoryServer $Instance.RepositoryServer `
                -RepositoryDatabase $Instance.RepositoryDatabase `
                -RunID $runId `
                -Status "Success"
            return
        }

        $columns = @(Get-MonitorTableColumns -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -TableName 'mon.AgentJobHistory')
        $targetTable = New-Object System.Data.DataTable
        foreach ($columnSpec in @(
            @{ Name = 'InstanceID'; Type = [int] },
            @{ Name = 'CaptureTime'; Type = [datetime] },
            @{ Name = 'JobName'; Type = [string] },
            @{ Name = 'Enabled'; Type = [bool] },
            @{ Name = 'Category'; Type = [string] },
            @{ Name = 'LastRunTime'; Type = [datetime] },
            @{ Name = 'LastStatus'; Type = [string] },
            @{ Name = 'LastDurationSec'; Type = [int] },
            @{ Name = 'NextRunTime'; Type = [datetime] },
            @{ Name = 'RunsRecent'; Type = [int] },
            @{ Name = 'FailuresRecent'; Type = [int] },
            @{ Name = 'SuccessPctRecent'; Type = [decimal] },
            @{ Name = 'AvgDurationSecRecent'; Type = [int] },
            @{ Name = 'LastFailureTime'; Type = [datetime] },
            @{ Name = 'LastFailureMessage'; Type = [string] }
        )) {
            if ($columns -contains $columnSpec.Name) {
                [void]$targetTable.Columns.Add($columnSpec.Name, $columnSpec.Type)
            }
        }

        foreach ($row in $sourceRows.Rows) {
            $newRow = $targetTable.NewRow()
            if ($targetTable.Columns.Contains('InstanceID')) { $newRow["InstanceID"] = $instanceId }
            if ($targetTable.Columns.Contains('CaptureTime')) { $newRow["CaptureTime"] = [datetime]$row["CaptureTime"] }
            if ($targetTable.Columns.Contains('JobName')) { $newRow["JobName"] = if ($row["JobName"] -is [DBNull]) { [DBNull]::Value } else { [string]$row["JobName"] } }
            if ($targetTable.Columns.Contains('Enabled')) { $newRow["Enabled"] = if ($row["Enabled"] -is [DBNull]) { [DBNull]::Value } else { [bool]$row["Enabled"] } }
            if ($targetTable.Columns.Contains('Category')) { $newRow["Category"] = if ($row["Category"] -is [DBNull]) { [DBNull]::Value } else { [string]$row["Category"] } }
            if ($targetTable.Columns.Contains('LastRunTime')) { $newRow["LastRunTime"] = if ($row["LastRunTime"] -is [DBNull]) { [DBNull]::Value } else { [datetime]$row["LastRunTime"] } }
            if ($targetTable.Columns.Contains('LastStatus')) { $newRow["LastStatus"] = if ($row["LastStatus"] -is [DBNull]) { [DBNull]::Value } else { [string]$row["LastStatus"] } }
            if ($targetTable.Columns.Contains('LastDurationSec')) { $newRow["LastDurationSec"] = if ($row["LastDurationSec"] -is [DBNull]) { [DBNull]::Value } else { [int]$row["LastDurationSec"] } }
            if ($targetTable.Columns.Contains('NextRunTime')) { $newRow["NextRunTime"] = if ($row["NextRunTime"] -is [DBNull]) { [DBNull]::Value } else { [datetime]$row["NextRunTime"] } }
            if ($targetTable.Columns.Contains('RunsRecent')) { $newRow["RunsRecent"] = if ($row["RunsRecent"] -is [DBNull]) { [DBNull]::Value } else { [int]$row["RunsRecent"] } }
            if ($targetTable.Columns.Contains('FailuresRecent')) { $newRow["FailuresRecent"] = if ($row["FailuresRecent"] -is [DBNull]) { [DBNull]::Value } else { [int]$row["FailuresRecent"] } }
            if ($targetTable.Columns.Contains('SuccessPctRecent')) { $newRow["SuccessPctRecent"] = if ($row["SuccessPctRecent"] -is [DBNull]) { [DBNull]::Value } else { [decimal]$row["SuccessPctRecent"] } }
            if ($targetTable.Columns.Contains('AvgDurationSecRecent')) { $newRow["AvgDurationSecRecent"] = if ($row["AvgDurationSecRecent"] -is [DBNull]) { [DBNull]::Value } else { [int]$row["AvgDurationSecRecent"] } }
            if ($targetTable.Columns.Contains('LastFailureTime')) { $newRow["LastFailureTime"] = if ($row["LastFailureTime"] -is [DBNull]) { [DBNull]::Value } else { [datetime]$row["LastFailureTime"] } }
            if ($targetTable.Columns.Contains('LastFailureMessage')) { $newRow["LastFailureMessage"] = if ($row["LastFailureMessage"] -is [DBNull]) { [DBNull]::Value } else { [string]$row["LastFailureMessage"] } }
            $targetTable.Rows.Add($newRow)
        }

        if ($targetTable.Rows.Count -gt 0) {
            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.AgentJobHistory" `
                -DataTable $targetTable
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-AgentJobsCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-AgentJobsCollector
