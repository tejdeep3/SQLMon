function Invoke-LongRunningCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "LongRunning"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Long Running collector started for $($Instance.DisplayName)"

        $query = @"
        SELECT
            er.session_id as SPID,
            DB_NAME(er.database_id) as DatabaseName,
            er.start_time as StartTime,
            DATEDIFF(ms, er.start_time, GETDATE()) as DurationMS,
            er.status as Status,
            er.wait_type as WaitType,
            er.cpu_time as CPUTimeMS,
            er.logical_reads as LogicalReads,
            er.reads as PhysicalReads,
            er.writes as LogicalWrites,
            er.command as CommandType,
            es.host_name as HostName,
            es.login_name as LoginName,
            SUBSTRING(st.text, er.statement_start_offset/2 + 1, 
                (CASE WHEN er.statement_end_offset = -1 THEN LEN(CONVERT(nvarchar(max), st.text)) * 2 
                ELSE er.statement_end_offset END - er.statement_start_offset)/2) as StatementText
        FROM sys.dm_exec_requests er
        INNER JOIN sys.dm_exec_sessions es ON er.session_id = es.session_id
        OUTER APPLY sys.dm_exec_sql_text(er.sql_handle) st
        WHERE er.session_id > 50 AND DATEDIFF(ms, er.start_time, GETDATE()) > 60000
"@

        $longRunningData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $query

        if ($longRunningData.Rows.Count -gt 0) {
            $columns = @(Get-MonitorTableColumns -ServerInstance $Instance.RepositoryServer -Database $Instance.RepositoryDatabase -TableName 'mon.LongRunningHistory')
            $targetTable = New-Object System.Data.DataTable
            [void]$targetTable.Columns.Add("InstanceID", [int])
            [void]$targetTable.Columns.Add("CaptureTime", [datetime])
            $sessionColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('SPID', 'SessionID')
            $durationColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('DurationMS', 'DurationSeconds', 'DurationMinutes')
            $statusColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('Status', 'StatusText')
            $cpuColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('CPUTimeMS', 'CPUTimeMs', 'CPUms')
            $readsColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('LogicalReads', 'Reads')
            $writesColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('LogicalWrites', 'Writes')
            $commandColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('CommandType', 'CommandText', 'LastCommand')
            $queryTextColumn = Get-FirstAvailableColumnName -AvailableColumns $columns -CandidateNames @('QueryText', 'StatementText')

            foreach ($requiredColumn in @($sessionColumn, $durationColumn, $statusColumn, $cpuColumn, $readsColumn, $writesColumn, $commandColumn, $queryTextColumn)) {
                if ([string]::IsNullOrWhiteSpace($requiredColumn)) {
                    throw 'mon.LongRunningHistory does not contain the expected performance/session columns.'
                }
            }

            [void]$targetTable.Columns.Add($sessionColumn, [int])
            [void]$targetTable.Columns.Add("DatabaseName", [string])
            if ($columns -contains 'StartTime') { [void]$targetTable.Columns.Add('StartTime', [datetime]) }
            [void]$targetTable.Columns.Add($durationColumn, [decimal])
            [void]$targetTable.Columns.Add($statusColumn, [string])
            if ($columns -contains 'WaitType') { [void]$targetTable.Columns.Add('WaitType', [string]) }
            [void]$targetTable.Columns.Add($cpuColumn, [long])
            [void]$targetTable.Columns.Add($readsColumn, [long])
            if ($columns -contains 'PhysicalReads') { [void]$targetTable.Columns.Add('PhysicalReads', [long]) }
            [void]$targetTable.Columns.Add($writesColumn, [long])
            if ($columns -contains 'HostName') { [void]$targetTable.Columns.Add('HostName', [string]) }
            if ($columns -contains 'LoginName') { [void]$targetTable.Columns.Add('LoginName', [string]) }
            [void]$targetTable.Columns.Add($commandColumn, [string])
            [void]$targetTable.Columns.Add($queryTextColumn, [string])

            $captureTime = [datetime]::Now

            foreach ($lr in $longRunningData.Rows) {
                $newRow = $targetTable.NewRow()
                $newRow["InstanceID"] = $instanceId
                $newRow["CaptureTime"] = $captureTime
                $newRow[$sessionColumn] = $lr["SPID"]
                $newRow["DatabaseName"] = $lr["DatabaseName"]
                if ($targetTable.Columns.Contains('StartTime')) { $newRow["StartTime"] = $lr["StartTime"] }
                $newRow[$durationColumn] = switch ($durationColumn) {
                    'DurationMinutes' { [int]([decimal]$lr["DurationMS"] / 60000) }
                    'DurationSeconds' { [decimal]$lr["DurationMS"] / 1000.0 }
                    default { $lr["DurationMS"] }
                }
                $newRow[$statusColumn] = $lr["Status"]
                if ($targetTable.Columns.Contains('WaitType')) { $newRow["WaitType"] = $lr["WaitType"] }
                $newRow[$cpuColumn] = $lr["CPUTimeMS"]
                $newRow[$readsColumn] = $lr["LogicalReads"]
                if ($targetTable.Columns.Contains('PhysicalReads')) { $newRow["PhysicalReads"] = $lr["PhysicalReads"] }
                $newRow[$writesColumn] = $lr["LogicalWrites"]
                if ($targetTable.Columns.Contains('HostName')) { $newRow["HostName"] = $lr["HostName"] }
                if ($targetTable.Columns.Contains('LoginName')) { $newRow["LoginName"] = $lr["LoginName"] }
                $newRow[$commandColumn] = $lr["CommandType"]
                $newRow[$queryTextColumn] = $lr["StatementText"]
                $targetTable.Rows.Add($newRow)
            }

            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "mon.LongRunningHistory" `
                -DataTable $targetTable

            Write-MonitorLog "Long Running collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-LongRunningCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-LongRunningCollector
