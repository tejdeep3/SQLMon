function Invoke-MemoryCollector {
    param(
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Instance
    )

    $moduleName = "Memory"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName `
        -SqlInstance $Instance.SqlInstance

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Memory collector started for $($Instance.DisplayName)"

        $memoryQuery = @"
SELECT
    SYSDATETIME() AS CaptureTime,
    CONVERT(bigint, osm.total_physical_memory_kb / 1024) AS TotalPhysicalMB,
    CONVERT(bigint, osm.available_physical_memory_kb / 1024) AS AvailablePhysicalMB,
    CONVERT(decimal(18,2), opm.physical_memory_in_use_kb / 1048576.0) AS SqlMemoryUsedGB,
    CONVERT(bigint,
        (
            SELECT TOP 1 cntr_value
            FROM sys.dm_os_performance_counters
            WHERE counter_name = 'Page life expectancy'
              AND object_name LIKE '%Buffer Manager%'
        )
    ) AS PLESeconds,
    CONVERT(decimal(10,2),
        (
            SELECT TOP 1 (a.cntr_value * 1.0 / NULLIF(b.cntr_value, 0)) * 100.0
            FROM sys.dm_os_performance_counters a
            INNER JOIN sys.dm_os_performance_counters b
                ON a.object_name = b.object_name
            WHERE a.counter_name = 'Buffer cache hit ratio'
              AND b.counter_name = 'Buffer cache hit ratio base'
              AND a.object_name LIKE '%Buffer Manager%'
        )
    ) AS BufferCacheHitRatio
FROM sys.dm_os_sys_memory osm
CROSS JOIN sys.dm_os_process_memory opm;
"@

        $sourceRows = Invoke-MonitorSqlQuery `
            -ServerInstance $Instance.SqlInstance `
            -Database "master" `
            -Query $memoryQuery `
            -CommandTimeout 120

        if ($sourceRows.Rows.Count -eq 0) {
            throw 'Memory query returned no result set.'
        }

        $targetTable = New-MemoryHistoryTable
        
        foreach ($row in $sourceRows.Rows) {
            $newRow = $targetTable.NewRow()
            $newRow["InstanceID"] = $instanceId
            $newRow["CaptureTime"] = [datetime]$row["CaptureTime"]
            $newRow["TotalPhysicalMB"] = [int64]$row["TotalPhysicalMB"]
            $newRow["AvailablePhysicalMB"] = [int64]$row["AvailablePhysicalMB"]
            $newRow["SqlMemoryUsedGB"] = [decimal]$row["SqlMemoryUsedGB"]
            $newRow["PLESeconds"] = if ($row["PLESeconds"] -is [DBNull]) { 0 } else { [int64]$row["PLESeconds"] }
            $newRow["BufferCacheHitRatio"] = if ($row["BufferCacheHitRatio"] -is [DBNull]) { 0 } else { [decimal]$row["BufferCacheHitRatio"] }
            $targetTable.Rows.Add($newRow)
        }

        Write-DataTableToSql `
            -ServerInstance $Instance.RepositoryServer `
            -Database $Instance.RepositoryDatabase `
            -DestinationTable "mon.MemoryHistory" `
            -DataTable $targetTable

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"

        Write-MonitorLog "Memory collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "Memory collector failed for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-MemoryCollector
