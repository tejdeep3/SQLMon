function Invoke-FragmentationCollector {
    param (
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$Instance
    )

    $moduleName = "Fragmentation"
    $instanceId = Get-MonitorInstanceId `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -DisplayName $Instance.DisplayName

    $runId = Start-CollectionRun `
        -RepositoryServer $Instance.RepositoryServer `
        -RepositoryDatabase $Instance.RepositoryDatabase `
        -InstanceID $instanceId `
        -ModuleName $moduleName

    try {
        Write-MonitorLog "Fragmentation collector started for $($Instance.DisplayName)"

        $databaseQuery = @"
SELECT name
FROM sys.databases
WHERE state_desc = 'ONLINE'
  AND source_database_id IS NULL
ORDER BY database_id;
"@
        $databaseData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database "master" -Query $databaseQuery

        $fragmentationQuery = @"
SELECT
    DB_NAME() AS database_name,
    OBJECT_SCHEMA_NAME(ps.[object_id], DB_ID()) + '.' + OBJECT_NAME(ps.[object_id], DB_ID()) AS object_name,
    i.name AS index_name,
    ps.index_type_desc,
    ps.avg_fragmentation_in_percent,
    ps.avg_page_space_used_in_percent,
    ps.record_count,
    ps.page_count,
    ps.avg_record_size_in_bytes
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'LIMITED') ps
INNER JOIN sys.indexes i ON ps.[object_id] = i.[object_id] AND ps.index_id = i.index_id
WHERE ps.index_type_desc <> 'HEAP'
  AND ps.page_count > 1000
  AND ps.avg_fragmentation_in_percent > 10
ORDER BY ps.avg_fragmentation_in_percent DESC;
"@

        # Map columns to target table dbo.IndexFragmentation
        $targetTable = New-Object System.Data.DataTable
        [void]$targetTable.Columns.Add("InstanceID", [int])
        [void]$targetTable.Columns.Add("CollectionDateTime", [datetime])
        [void]$targetTable.Columns.Add("DatabaseName", [string])
        [void]$targetTable.Columns.Add("ObjectName", [string])
        [void]$targetTable.Columns.Add("IndexName", [string])
        [void]$targetTable.Columns.Add("IndexType", [string])
        [void]$targetTable.Columns.Add("AvgFragmentationPercent", [decimal])
        [void]$targetTable.Columns.Add("AvgPageSpaceUsedPercent", [decimal])
        [void]$targetTable.Columns.Add("RecordCount", [long])
        [void]$targetTable.Columns.Add("PageCount", [long])
        [void]$targetTable.Columns.Add("AvgRecordSizeBytes", [decimal])

        $captureTime = Get-Date
        $databaseCount = 0

        foreach ($db in $databaseData.Rows) {
            $databaseName = [string]$db["name"]
            $databaseCount++

            try {
                $fragmentationData = Invoke-MonitorSqlQuery -ServerInstance $Instance.SqlInstance -Database $databaseName -Query $fragmentationQuery

                foreach ($frag in $fragmentationData.Rows) {
                    $newRow = $targetTable.NewRow()
                    $newRow["InstanceID"] = $instanceId
                    $newRow["CollectionDateTime"] = $captureTime
                    $newRow["DatabaseName"] = $frag["database_name"]
                    $newRow["ObjectName"] = $frag["object_name"]
                    $newRow["IndexName"] = $frag["index_name"]
                    $newRow["IndexType"] = $frag["index_type_desc"]
                    $newRow["AvgFragmentationPercent"] = $frag["avg_fragmentation_in_percent"]
                    $newRow["AvgPageSpaceUsedPercent"] = $frag["avg_page_space_used_in_percent"]
                    $newRow["RecordCount"] = $frag["record_count"]
                    $newRow["PageCount"] = $frag["page_count"]
                    $newRow["AvgRecordSizeBytes"] = $frag["avg_record_size_in_bytes"]
                    $targetTable.Rows.Add($newRow)
                }
            }
            catch {
                Write-MonitorLog "WARNING in Invoke-FragmentationCollector for $($Instance.DisplayName), database [$databaseName]: $($_.Exception.Message)"
            }
        }

        if ($targetTable.Rows.Count -gt 0) {
            Write-DataTableToSql `
                -ServerInstance $Instance.RepositoryServer `
                -Database $Instance.RepositoryDatabase `
                -DestinationTable "dbo.IndexFragmentation" `
                -DataTable $targetTable

            Write-MonitorLog "Fragmentation collector completed for $($Instance.DisplayName). Rows inserted: $($targetTable.Rows.Count)"
        }
        else {
            Write-MonitorLog "Fragmentation collector completed for $($Instance.DisplayName). Databases scanned: $databaseCount. Rows inserted: 0"
        }

        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Success"
    }
    catch {
        $msg = $_.Exception.Message
        Write-MonitorLog "ERROR in Invoke-FragmentationCollector for $($Instance.DisplayName): $msg"
        Stop-CollectionRun `
            -RepositoryServer $Instance.RepositoryServer `
            -RepositoryDatabase $Instance.RepositoryDatabase `
            -RunID $runId `
            -Status "Failed" `
            -ErrorMessage $msg
    }
}

Export-ModuleMember -Function Invoke-FragmentationCollector
