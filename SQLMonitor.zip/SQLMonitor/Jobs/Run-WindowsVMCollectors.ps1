param(
    [string[]]$ComputerName = @(),
    [int]$TopNProcesses = 25,
    [int]$EventHours = 12,
    [int]$PerfSampleSeconds = 3,
    [int]$PerfSamples = 3,
    [string]$OutDir = '',
    [bool]$EvaluateAlerts = $true,
    [bool]$AutoCreateTickets = $true
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-WindowsVM.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-WindowsVM-FileBased.psm1') -Force

$repository = Get-SqlMonitorRepositorySettings
Invoke-WindowsVMCollector-FileBased `
    -RepositoryServer $repository.RepositoryServer `
    -RepositoryDatabase $repository.RepositoryDatabase `
    -ComputerName $ComputerName `
    -TopNProcesses $TopNProcesses `
    -EventHours $EventHours `
    -PerfSampleSeconds $PerfSampleSeconds `
    -PerfSamples $PerfSamples `
    -OutDir $OutDir `
    -EvaluateAlerts $EvaluateAlerts `
    -AutoCreateTickets $AutoCreateTickets
