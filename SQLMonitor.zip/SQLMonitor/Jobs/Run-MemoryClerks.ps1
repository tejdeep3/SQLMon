# Run-MemoryClerks.ps1
# Advanced memory clerk analysis and pressure monitoring job
# UNIQUE FEATURE: Detailed memory allocation analysis by SQL Server components with pressure prediction

param(
    [Parameter(Mandatory = $false)]
    [string]$InstanceName,

    [Parameter(Mandatory = $false)]
    [switch]$IncludePressureAnalysis
)

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\Collect-MemoryClerks.psm1') -Force -WarningAction SilentlyContinue

try {
    $instances = Get-SqlMonitorInstances
    if ($InstanceName) {
        $instances = $instances | Where-Object { $_.DisplayName -eq $InstanceName }
    }

    foreach ($instance in $instances) {
        Write-MonitorLog "Starting memory clerk analysis for instance: $($instance.DisplayName)"

        $clerks = Get-SQLServerMemoryClerks -Instance $instance -IncludePressureAnalysis:$IncludePressureAnalysis

        if ($clerks.Count -gt 0) {
            Write-MonitorLog "Analyzed $($clerks.Count) memory clerks for $($instance.DisplayName)"

            # Check for pressure issues
            $highPressureClerks = $clerks | Where-Object { $_.PressureLevel -in @('High', 'Critical') }
            if ($highPressureClerks.Count -gt 0) {
                Write-MonitorLog "WARNING: Found $($highPressureClerks.Count) memory clerks with high/critical pressure"
                foreach ($clerk in $highPressureClerks) {
                    Write-MonitorLog "Memory pressure in $($clerk.Name): $($clerk.Recommendations -join '; ')"
                }
            }

            # Log buffer pool analysis
            $bufferAnalysis = Get-SQLServerBufferPoolAnalysis -Instance $instance
            if ($bufferAnalysis.Count -gt 0) {
                Write-MonitorLog "Buffer pool analysis completed for $($bufferAnalysis.Count) databases"
                $staleBuffers = $bufferAnalysis | Where-Object { $_.Recommendations.Count -gt 0 }
                if ($staleBuffers.Count -gt 0) {
                    Write-MonitorLog "Buffer pool optimization recommendations available for $($staleBuffers.Count) databases"
                }
            }
        } else {
            Write-MonitorLog "No memory clerk data retrieved for $($instance.DisplayName)"
        }
    }

    Write-MonitorLog "Memory clerk analysis job completed successfully"
}
catch {
    Write-MonitorLog "ERROR in memory clerk analysis job: $($_.Exception.Message)" -Level 'Error'
    throw
}