# Run-PatchManager.ps1
# PowerShell script to run patch management operations

param(
    [Parameter(Mandatory = $false)]
    [switch]$DownloadPatches,

    [Parameter(Mandatory = $false)]
    [string]$DownloadPath,

    [Parameter(Mandatory = $false)]
    [switch]$Force
)

# Import required modules using paths relative to this script so scheduled tasks
# work regardless of their starting directory.
$projectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\PatchManager.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\PatchDownloader.psm1') -Force

try {
    Write-MonitorLog "Patch Manager job started"

    # Get patch status for all instances
    Write-MonitorLog "Retrieving patch status for all monitored instances"
    $patchStatus = Get-SQLServerPatchStatus

    # Save patch status report
    $logDir = Split-Path -Parent (Get-SqlMonitorLogPath)
    $reportFile = Join-Path $logDir "PatchStatus_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $patchStatus | ConvertTo-Json -Depth 5 | Out-File -FilePath $reportFile -Encoding UTF8
    Write-MonitorLog "Patch status report saved to: $reportFile"

    # Display summary to console
    Write-Host "SQL Server Patch Status Report" -ForegroundColor Green
    Write-Host "Generated: $(Get-Date)" -ForegroundColor Green
    Write-Host ""

    foreach ($instance in $patchStatus) {
        Write-Host "Instance: $($instance.InstanceName)" -ForegroundColor Yellow
        Write-Host "Version: $($instance.VersionName) ($($instance.ProductVersion))" -ForegroundColor White
        Write-Host "Current Update: $($instance.CurrentUpdate)" -ForegroundColor White
        Write-Host "Patch Status: $($instance.PatchStatus)" -ForegroundColor Cyan
        Write-Host "Edition: $($instance.Edition)" -ForegroundColor White
        Write-Host "Current Build: $($instance.CurrentBuildVersion)" -ForegroundColor White
        Write-Host "Available Patches: $($instance.AvailablePatches.Count)" -ForegroundColor Gray

        if ($instance.RecommendedPatch) {
            Write-Host "Recommended Patch: $($instance.RecommendedPatch.DisplayLabel) $($instance.RecommendedPatch.KBNumber)" -ForegroundColor Magenta
            Write-Host "Catalog: $($instance.RecommendedPatch.CatalogUrl)" -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    # Download patches if requested
    if ($DownloadPatches) {
        Write-MonitorLog "Starting patch downloads"

        if (-not $DownloadPath) {
            $projectRoot = Get-SqlMonitorProjectRoot
            $DownloadPath = Join-Path $projectRoot "Patches"
        }

        Write-Host "Downloading patches to: $DownloadPath" -ForegroundColor Green

        $downloadedFiles = Invoke-BulkPatchDownload -DownloadPath $DownloadPath -Force:$Force

        Write-Host "Download Summary:" -ForegroundColor Green
        Write-Host "Total files downloaded: $($downloadedFiles.Count)" -ForegroundColor Cyan

        if ($downloadedFiles.Count -gt 0) {
            Write-Host "Downloaded files:" -ForegroundColor Yellow
            foreach ($file in $downloadedFiles) {
                Write-Host "  - $($file.FileName) ($([math]::Round($file.Size / 1MB, 2)) MB)" -ForegroundColor Gray
            }
        }

        # Save download report
        $downloadReportFile = Join-Path $logDir "PatchDownloads_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
        $downloadedFiles | ConvertTo-Json -Depth 3 | Out-File -FilePath $downloadReportFile -Encoding UTF8
        Write-MonitorLog "Download report saved to: $downloadReportFile"
    }

    Write-MonitorLog "Patch Manager job completed successfully"
}
catch {
    Write-MonitorLog "ERROR in Patch Manager job: $($_.Exception.Message)" -Level 'Error'
    throw
}
