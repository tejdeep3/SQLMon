# Process-TicketEscalations.ps1 - Scheduled job to process ticket escalations
# This script should be run on a schedule (e.g., every 10 minutes) to escalate tickets

param(
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

# Import required modules
Import-Module (Join-Path $ProjectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $ProjectRoot 'Modules\EscalationMatrix.psm1') -Force -WarningAction SilentlyContinue

Write-MonitorLog "=== Starting Ticket Escalation Processing ===" -Level Info

try {
    # Get configuration
    $configPath = Join-Path $ProjectRoot 'Config\instances.json'
    if (-not (Test-Path $configPath)) {
        Write-MonitorLog "Configuration file not found at $configPath" -Level Error
        exit 1
    }
    
    $config = Get-Content $configPath | ConvertFrom-Json
    $serverInstance = $config.RepositoryServer
    $database = $config.RepositoryDatabase
    
    # Use the stored procedure to process escalations
    $query = 'DECLARE @ProcessedCount INT; EXEC mon.usp_ProcessTicketEscalations @BatchSize = 50, @ProcessedCount = @ProcessedCount OUTPUT; SELECT @ProcessedCount AS TicketsEscalated;'
    
    $result = Invoke-MonitorSqlQuery -ServerInstance $serverInstance `
                                      -Database $database `
                                      -Query $query
    
    if ($result -and $result.Rows.Count -gt 0) {
        $ticketsEscalated = $result.Rows[0].TicketsEscalated
        Write-MonitorLog "Escalation processing completed. Escalated $ticketsEscalated ticket(s)." -Level Info
    } else {
        Write-MonitorLog "No tickets escalated or stored procedure not found." -Level Info
    }
}
catch {
    Write-MonitorLog "Error in ticket escalation processing: $_" -Level Error
}

Write-MonitorLog "=== Ticket Escalation Processing Completed ===" -Level Info
