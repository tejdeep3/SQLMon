# Run-WebAgent.ps1
# PowerShell script to run the Web Solutions Agent

param(
    [Parameter(Mandatory = $false)]
    [string]$ErrorMessage,

    [Parameter(Mandatory = $false)]
    [int]$MaxResults = 5
)

# Import required modules using paths relative to this script so scheduled tasks
# work regardless of their starting directory.
$projectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\WebAgent.psm1') -Force

try {
    Write-MonitorLog "Web Agent job started"
    $logDir = Split-Path -Parent (Get-SqlMonitorLogPath)

    if (-not $ErrorMessage) {
        # If no specific error provided, check for recent alerts/errors from the database
        $instances = Get-SqlMonitorInstances

        foreach ($instance in $instances) {
            if ($instance.IsActive) {
                # Get recent alerts from the last 24 hours
                $alertQuery = @"
SELECT TOP 5
    AlertTitle,
    AlertDetails,
    Severity,
    AlertTime
FROM mon.vw_AlertHistoryDetailed
WHERE DisplayName = @DisplayName
    AND AlertTime >= DATEADD(HOUR, -24, GETDATE())
ORDER BY AlertTime DESC
"@

                $alerts = Invoke-MonitorSqlQuery -ServerInstance $instance.RepositoryServer -Database $instance.RepositoryDatabase -Query $alertQuery -Parameters @{ DisplayName = $instance.DisplayName }

                foreach ($alert in $alerts.Rows) {
                    $alertTitle = [string]$alert.AlertTitle
                    $alertDetails = [string]$alert.AlertDetails
                    Write-MonitorLog "Searching solutions for alert: $alertTitle"

                    # Pass AlertTitle and AlertDetails separately for better context
                    $solutions = Invoke-WebSolutionsAgent -ErrorMessage $alertDetails -AlertTitle $alertTitle -Instance $instance -MaxResults $MaxResults

                    if ($solutions.Count -gt 0) {
                        Write-MonitorLog "Found $($solutions.Count) solutions for: $($alert.AlertTitle)"

                        # Log solutions to file for review
                        $solutionFile = Join-Path $logDir "WebSolutions_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"

                        $solutionText = @"
Web Solutions Report
Generated: $(Get-Date)
Instance: $($instance.DisplayName)
Alert: $($alert.AlertTitle)
Severity: $($alert.Severity)
Alert Date: $($alert.AlertTime)

Found $($solutions.Count) potential solutions:

"@

                        $counter = 1
                        foreach ($solution in $solutions) {
                            $solutionText += @"

$counter. $($solution.Title)
   Source: $($solution.Source)
   Type: $($solution.Type)
   URL: $($solution.Url)
   Relevance: $($solution.Relevance)
   Confidence: $($solution.Confidence)
   Error Number: $($solution.ErrorNumber)
   Matched Terms: $($solution.MatchedTerms)
   Snippet: $($solution.Snippet)

"@
                            if ($solution.RecommendedActionsText) {
                                $solutionText += "   Recommended Actions:`r`n$($solution.RecommendedActionsText)`r`n"
                            }
                            $counter++
                        }

                        $solutionText | Out-File -FilePath $solutionFile -Encoding UTF8
                        Write-MonitorLog "Solutions saved to: $solutionFile"
                    }
                }
            }
        }
    }
    else {
        # Search for specific error message
        Write-MonitorLog "Searching solutions for specific error: $ErrorMessage"

        $solutions = Invoke-WebSolutionsAgent -ErrorMessage $ErrorMessage -MaxResults $MaxResults

        if ($solutions.Count -gt 0) {
            Write-MonitorLog "Found $($solutions.Count) solutions"

            # Display results to console
            $counter = 1
            foreach ($solution in $solutions) {
                Write-Host "$counter. $($solution.Title)" -ForegroundColor Green
                Write-Host "   Source: $($solution.Source)" -ForegroundColor Yellow
                Write-Host "   URL: $($solution.Url)" -ForegroundColor Cyan
                Write-Host "   Type: $($solution.Type)" -ForegroundColor Gray
                Write-Host "   Relevance: $($solution.Relevance) ($($solution.Confidence))" -ForegroundColor Gray
                if ($solution.Snippet) {
                    Write-Host "   Snippet: $($solution.Snippet)" -ForegroundColor DarkGray
                }
                if ($solution.RecommendedActionsText) {
                    Write-Host "   Recommended Actions:" -ForegroundColor Magenta
                    Write-Host $solution.RecommendedActionsText -ForegroundColor DarkGray
                }
                Write-Host ""
                $counter++
            }
        }
        else {
            Write-Host "No solutions found for: $ErrorMessage" -ForegroundColor Red
        }
    }

    Write-MonitorLog "Web Agent job completed successfully"
}
catch {
    Write-MonitorLog "ERROR in Web Agent job: $($_.Exception.Message)" -Level 'Error'
    throw
}
