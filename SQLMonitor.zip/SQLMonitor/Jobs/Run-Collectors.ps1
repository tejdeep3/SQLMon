# Resolve project root path
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptRoot

# Import modules using relative paths
Import-Module (Join-Path $projectRoot "Modules\Common.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-CPU.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-Memory.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-MemoryClerks.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-AgentJobs.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-Deadlocks.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-AG.psm1") -Force

# Load configuration
$instances = @(Get-SqlMonitorInstances)
if ($instances.Count -eq 0) {
    throw "No monitored instances found in $(Get-SqlMonitorConfigPath -FileName 'instances.json')"
}

foreach ($instance in $instances) {
    if (-not $instance.IsActive) { continue }

    try {
        Write-MonitorLog "Starting CORE collectors for $($instance.DisplayName)"

        Invoke-CPUCollector -Instance $instance
        Invoke-MemoryCollector -Instance $instance
        Invoke-MemoryClerkCollector -Instance $instance
        Invoke-AgentJobsCollector -Instance $instance
        Invoke-DeadlocksCollector -Instance $instance
        Invoke-AGCollector -Instance $instance

        Write-MonitorLog "CORE collectors completed for $($instance.DisplayName)"
    }
    catch {
        Write-MonitorLog "ERROR in Run-Collectors.ps1 for $($instance.DisplayName): $($_.Exception.Message)"
    }
}
