# Distributed-aware wrapper. The instance-group runner handles central assignments,
# collector heartbeat, and standalone compatibility.
$projectRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $projectRoot 'Jobs\Run-Collectors-InstanceGroup.ps1') -CollectorGroup Core
exit $LASTEXITCODE

# Resolve project root path
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptRoot

# Import modules using relative paths
Import-Module (Join-Path $projectRoot "Modules\Common.psm1") -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot "Modules\Collect-KPIs.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-Disks.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-Config.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-Memory.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-MemoryClerks.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-CPU.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-IO.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-TempDB.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-Backups.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-DBOptions.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-Blocking.psm1") -Force
Import-Module (Join-Path $projectRoot "Modules\Collect-LongRunning.psm1") -Force

# Load configuration
$instances = @(Get-SqlMonitorInstances)
Write-Host "DEBUG: Script reached instance loading"
Write-Host "DEBUG: instances is null: $($null -eq $instances)"
Write-Host "DEBUG: instances count: $($instances.Count)"
Write-Host "DEBUG: instances type: $($instances.GetType())"
if ($instances) {
    Write-Host "DEBUG: instances[0] type: $($instances[0].GetType())"
    Write-Host "DEBUG: instances[0] properties: $($instances[0] | Get-Member -MemberType Properties | Select-Object -ExpandProperty Name)"
}
Write-MonitorLog "DEBUG: Loaded $($instances.Count) instances"
if ($instances.Count -eq 0) {
    throw "No monitored instances found in $(Get-SqlMonitorConfigPath -FileName 'instances.json')"
}

foreach ($instance in $instances) {
    if (-not $instance.IsActive) { continue }

    try {
        Write-MonitorLog "DEBUG: Starting CORE collectors loop for $($instance.DisplayName)"
        Write-MonitorLog "Starting CORE collectors for $($instance.DisplayName)"

        # Real-time metrics - collected every 5 minutes
        Write-MonitorLog "About to call Invoke-KPIsCollector"
        try {
            Invoke-KPIsCollector -Instance $instance
            Write-MonitorLog "KPI collector completed successfully"
        } catch {
            Write-MonitorLog "ERROR: KPI collector failed: $($_.Exception.Message)"
        }
        Invoke-DisksCollector -Instance $instance
        Invoke-ConfigCollector -Instance $instance
        Invoke-CPUCollector -Instance $instance
        Invoke-MemoryCollector -Instance $instance
        Invoke-MemoryClerkCollector -Instance $instance
        Invoke-IOCollector -Instance $instance
        Invoke-TempDBCollector -Instance $instance
        Invoke-BackupsCollector -Instance $instance
        Invoke-DBOptionsCollector -Instance $instance
        Invoke-BlockingCollector -Instance $instance
        Invoke-LongRunningCollector -Instance $instance

        Write-MonitorLog "Completed CORE collectors for $($instance.DisplayName)"
    }
    catch {
        Write-MonitorLog "ERROR in Run-Collectors-Core.ps1 for $($instance.DisplayName): $($_.Exception.Message)"
    }
}
