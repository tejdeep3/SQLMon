param(
    [ValidateSet('System', 'CurrentUser')]
    [string]$RunAs = 'System',

    [string]$TaskRoot = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path $TaskRoot)) {
    throw "Task script folder not found: $TaskRoot"
}

$taskPath = (Resolve-Path $TaskRoot).Path
$projectRoot = Split-Path -Parent $taskPath

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue

Write-Host "`nRegistering SQL Monitor scheduled tasks..." -ForegroundColor Cyan

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

$shellPath = Resolve-SqlMonitorPowerShellPath

if ($RunAs -eq 'System') {
    if (-not (Test-IsAdministrator)) {
        $message = @"
Windows scheduled tasks require an elevated PowerShell session when RunAs is System.

Fix:
  1. Open PowerShell or the deployment GUI with "Run as administrator".
  2. Re-run deployment with Configure Windows Scheduled Tasks selected.

Alternative:
  Run Jobs\Register-SQLMonitorTasks.ps1 -RunAs CurrentUser to create non-elevated tasks for the current user.

Note:
  If SQL Server Agent jobs were configured successfully, Windows Scheduled Tasks are optional.
"@
        Write-Host $message -ForegroundColor Yellow
        exit 1
    }

    $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest -LogonType ServiceAccount
    Write-Host "  Run as: SYSTEM (requires administrator)" -ForegroundColor Gray
}
else {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $principal = New-ScheduledTaskPrincipal -UserId $currentUser -RunLevel Limited -LogonType Interactive
    Write-Host "  Run as: $currentUser (current user, runs only while user is logged on)" -ForegroundColor Yellow
}

$tasks = @(
    @{
        Name = 'SQLMonitor-CoreCollectors'
        Path = Join-Path $taskPath 'Run-Collectors-Core.ps1'
        Description = 'SQL Monitor - Core collectors (every 5 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5)
    },
    @{
        Name = 'SQLMonitor-AdvancedCollectors'
        Path = Join-Path $taskPath 'Run-Collectors-Advanced.ps1'
        Description = 'SQL Monitor - Advanced collectors (every 30 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 30)
    },
    @{
        Name = 'SQLMonitor-DailyCollectors'
        Path = Join-Path $taskPath 'Run-Collectors-Daily.ps1'
        Description = 'SQL Monitor - Daily collectors (2 AM)'
        Trigger = New-ScheduledTaskTrigger -Daily -At '2:00 AM'
    },
    @{
        Name = 'SQLMonitor-AlertEngine'
        Path = Join-Path $taskPath 'Run-AlertEngine.ps1'
        Description = 'SQL Monitor - Alert engine (every 2 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 2)
    },
    @{
        Name = 'SQLMonitor-RetentionCleanup'
        Path = Join-Path $taskPath 'Purge-Retention.ps1'
        Description = 'SQL Monitor - Retention cleanup (3 AM)'
        Trigger = New-ScheduledTaskTrigger -Daily -At '3:00 AM'
    },
    @{ 
        Name = 'SQLMonitor-WebSolutionsAgent'
        Path = Join-Path $taskPath 'Run-WebAgent.ps1'
        Description = 'SQL Monitor - Web Solutions Agent (every 4 hours)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Hours 4)
    },
    @{ 
        Name = 'SQLMonitor-PatchManager'
        Path = Join-Path $taskPath 'Run-PatchManager.ps1'
        Description = 'SQL Monitor - Patch Manager (daily at 4:00 AM)'
        Trigger = New-ScheduledTaskTrigger -Daily -At '4:00 AM'
    },
    @{
        Name = 'SQLMonitor-WindowsVMCollectors'
        Path = Join-Path $taskPath 'Run-WindowsVMCollectors.ps1'
        Description = 'SQL Monitor - Windows VM Collectors (every 15 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 15)
    },
    @{
        Name = 'SQLMonitor-WindowsBaselineAnalysis'
        Path = Join-Path $taskPath 'Run-WindowsBaselineAnalysis.ps1'
        Description = 'SQL Monitor - Windows VM Baseline & Anomaly Analysis (daily at 1:00 AM)'
        Trigger = New-ScheduledTaskTrigger -Daily -At '1:00 AM'
    }
)

$failedCount = 0
foreach ($task in $tasks) {
    Write-Host "  Registering $($task.Name)..." -NoNewline

    try {
        if (-not (Test-Path $task.Path)) {
            throw "Task script not found: $($task.Path)"
        }

        $action = New-ScheduledTaskAction -Execute $shellPath -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$($task.Path)`""
        $settings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -StartWhenAvailable `
            -ExecutionTimeLimit (New-TimeSpan -Hours 2)

        $taskObject = New-ScheduledTask `
            -Action $action `
            -Trigger $task.Trigger `
            -Principal $principal `
            -Settings $settings `
            -Description $task.Description

        Register-ScheduledTask -TaskName $task.Name -InputObject $taskObject -Force | Out-Null
        Write-Host ' SUCCESS' -ForegroundColor Green
    }
    catch {
        $failedCount++
        Write-Host " FAILED: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`nRegistered tasks:" -ForegroundColor Cyan
Get-ScheduledTask | Where-Object { $_.TaskName -like 'SQLMonitor-*' } | Format-Table TaskName, State, TaskPath -AutoSize

Write-Host "`nTo verify tasks are running, check Task Scheduler or run:" -ForegroundColor Yellow
Write-Host "Get-ScheduledTask | Where-Object { `$_.TaskName -like 'SQLMonitor-*' }" -ForegroundColor Gray

if ($failedCount -gt 0) {
    Write-Host "`n$failedCount scheduled task(s) failed to register." -ForegroundColor Red
    exit 1
}
