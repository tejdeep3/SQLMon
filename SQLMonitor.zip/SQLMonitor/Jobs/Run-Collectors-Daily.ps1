$projectRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $projectRoot 'Jobs\Run-Collectors-InstanceGroup.ps1') -CollectorGroup Daily
exit $LASTEXITCODE

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\Collect-Fragmentation.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-AG.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-ListenersEndpoints.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-AgentJobs.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-Deadlocks.psm1') -Force

$instances = @(Get-SqlMonitorInstances)
if ($instances.Count -eq 0) {
    throw "No monitored instances found in $(Get-SqlMonitorConfigPath -FileName 'instances.json')"
}

foreach ($instance in $instances) {
    if (-not $instance.IsActive) {
        continue
    }

    try {
        Write-MonitorLog "Starting DAILY collectors for $($instance.DisplayName)"

        # Resource-intensive / infrequent collectors - daily at 2 AM
        Invoke-FragmentationCollector -Instance $instance
        Invoke-AGCollector -Instance $instance
        Invoke-ListenersEndpointsCollector -Instance $instance
        Invoke-AgentJobsCollector -Instance $instance
        Invoke-DeadlocksCollector -Instance $instance

        Write-MonitorLog "Completed DAILY collectors for $($instance.DisplayName)"
    }
    catch {
        Write-MonitorLog "ERROR in Run-Collectors-Daily.ps1 for $($instance.DisplayName): $($_.Exception.Message)" -Level 'Error'
    }
}
