$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\Invoke-AlertEngine.psm1') -Force

$instances = @(Get-SqlMonitorInstances)
if ($instances.Count -eq 0) {
    Write-MonitorLog "No monitored instances are configured. Alert engine run skipped." -Level 'Warning'
    throw "No monitored instances found in $(Get-SqlMonitorConfigPath -FileName 'instances.json')"
}

foreach ($instance in $instances) {
    if (-not $instance.IsActive) {
        continue
    }

    try {
        Write-MonitorLog "Starting alert run for $($instance.DisplayName)"

        $alerts = Invoke-AlertEngine -Instance $instance

        if ($null -ne $alerts -and $alerts.Rows.Count -gt 0) {
            Write-MonitorLog "Active or recent alerts found for $($instance.DisplayName): $($alerts.Rows.Count)"
            Write-Host "Alert run complete for $($instance.DisplayName): $($alerts.Rows.Count) active or recent alerts found."
        }
        else {
            Write-MonitorLog "No active or recent alerts found for $($instance.DisplayName)"
            Write-Host "Alert run complete for $($instance.DisplayName): no active or recent alerts."
        }
    }
    catch {
        Write-MonitorLog "ERROR in Run-AlertEngine.ps1 for $($instance.DisplayName): $($_.Exception.Message)" -Level 'Error'
        Write-Host "ERROR in Run-AlertEngine.ps1 for $($instance.DisplayName): $($_.Exception.Message)"
    }
}
