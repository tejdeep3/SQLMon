param(
    [Parameter(Mandatory = $false)]
    [ValidateSet('Core','Advanced','Daily','All')]
    [string]$CollectorGroup = 'Core',

    [Parameter(Mandatory = $false)]
    [string]$InstanceFilter = ''
)

$repositoryRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $repositoryRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $repositoryRoot 'Modules\DistributedCollectors.psm1') -Force -WarningAction SilentlyContinue

try {
    $distributedConfig = Get-SqlMonitorDistributedConfig
    $repositorySettings = Get-SqlMonitorRepositorySettings
    $collectorNodeId = Register-SqlMonitorCollectorNode -RepositoryServer $repositorySettings.RepositoryServer -RepositoryDatabase $repositorySettings.RepositoryDatabase -Config $distributedConfig

    if ([string]$distributedConfig.DeploymentRole -eq 'Collector') {
        $instanceList = @(Get-SqlMonitorCollectorAssignedInstances -RepositoryServer $repositorySettings.RepositoryServer -RepositoryDatabase $repositorySettings.RepositoryDatabase -CollectorNodeID $collectorNodeId -CollectorGroup $CollectorGroup)
        if ($instanceList.Count -eq 0) {
            Send-SqlMonitorCollectorHeartbeat -RepositoryServer $repositorySettings.RepositoryServer -RepositoryDatabase $repositorySettings.RepositoryDatabase -CollectorNodeID $collectorNodeId -Status 'NoAssignments' -CollectorGroup $CollectorGroup -InstanceCount 0 -MessageText 'No enabled central assignments were found for this collector node.'
        }
    }
    else {
        $instanceList = @(Get-SqlMonitorInstances)
    }
}
catch {
    throw "Unable to load monitored instances: $($_.Exception.Message)"
}

if ($instanceList.Count -eq 0 -and [string]$distributedConfig.DeploymentRole -eq 'Collector') {
    Write-Host "No central assignments found for collector node $($distributedConfig.CollectorNodeName)."
    exit 0
}

if ($instanceList.Count -eq 0) {
    throw "No monitored instances found in $(Get-SqlMonitorConfigPath -FileName 'instances.json')"
}

if ($InstanceFilter -ne '') {
    $matching = $instanceList | Where-Object {
        # Allow exact match on any of the key fields
        $_.DisplayName -eq $InstanceFilter -or $_.SqlInstance -eq $InstanceFilter -or $_.RepositoryServer -eq $InstanceFilter -or
        # Match against VM name (new hierarchy field)
        ($_.VMName -eq $InstanceFilter) -or ($_.VMDisplayName -eq $InstanceFilter) -or
        # Also allow partial match on server name (e.g., "BBLBHLAP860" matches "BBLBHLAP860\InstanceName")
        ($_.DisplayName -like "${InstanceFilter}*") -or ($_.SqlInstance -like "${InstanceFilter}*") -or ($_.RepositoryServer -like "${InstanceFilter}*") -or
        ($_.VMName -like "${InstanceFilter}*") -or ($_.VMDisplayName -like "${InstanceFilter}*")
    }
    if (-not $matching) {
        throw "No instance found matching '$InstanceFilter'"
    }
    $instanceList = $matching
}

$modules = @(
    'Collect-KPIs.psm1',
    'Collect-Disks.psm1',
    'Collect-Config.psm1',
    'Collect-CPU.psm1',
    'Collect-Memory.psm1',
    'Collect-MemoryClerks.psm1',
    'Collect-IO.psm1',
    'Collect-TempDB.psm1',
    'Collect-Backups.psm1',
    'Collect-DBOptions.psm1',
    'Collect-Blocking.psm1',
    'Collect-LongRunning.psm1',
    'Collect-Waits.psm1',
    'Collect-TopQueries.psm1',
    'Collect-MissingIndexes.psm1',
    'Collect-Fragmentation.psm1',
    'Collect-AG.psm1',
    'Collect-ListenersEndpoints.psm1',
    'Collect-AgentJobs.psm1',
    'Collect-Deadlocks.psm1'
)

foreach ($moduleFile in $modules) {
    $modulePath = Join-Path $repositoryRoot "Modules\$moduleFile"
    if (-not (Test-Path $modulePath)) {
        throw "Required module not found: $modulePath"
    }
    Import-Module $modulePath -Force
}

if ($collectorNodeId -gt 0) {
    Send-SqlMonitorCollectorHeartbeat -RepositoryServer $repositorySettings.RepositoryServer -RepositoryDatabase $repositorySettings.RepositoryDatabase -CollectorNodeID $collectorNodeId -Status 'Running' -CollectorGroup $CollectorGroup -InstanceCount $instanceList.Count -MessageText "Collector run started."
}

foreach ($instance in $instanceList) {
    if (-not $instance.IsActive) {
        continue
    }

    Write-Host "Starting $CollectorGroup collectors for $($instance.DisplayName)"

    try {
        switch ($CollectorGroup) {
            'Core' {
                Invoke-KPIsCollector -Instance $instance
                Invoke-DisksCollector -Instance $instance
                Invoke-ConfigCollector -Instance $instance
                Invoke-CPUCollector -Instance $instance
                Invoke-MemoryCollector -Instance $instance
                Invoke-MemoryClerkCollector -Instance $instance
                Invoke-IOCollector -Instance $instance
                Invoke-TempDBCollector -Instance $instance
                Invoke-BackupsCollector -Instance $instance
                Invoke-DBOptionsCollector -Instance $instance
                Invoke-BlockingCollector -Instance $instance
                Invoke-LongRunningCollector -Instance $instance
            }
            'Advanced' {
                Invoke-WaitsCollector -Instance $instance
                Invoke-TopQueriesCollector -Instance $instance
                Invoke-MissingIndexesCollector -Instance $instance
            }
            'Daily' {
                Invoke-FragmentationCollector -Instance $instance
                Invoke-AGCollector -Instance $instance
                Invoke-ListenersEndpointsCollector -Instance $instance
                Invoke-AgentJobsCollector -Instance $instance
                Invoke-DeadlocksCollector -Instance $instance
            }
            'All' {
                Invoke-KPIsCollector -Instance $instance
                Invoke-DisksCollector -Instance $instance
                Invoke-ConfigCollector -Instance $instance
                Invoke-CPUCollector -Instance $instance
                Invoke-MemoryCollector -Instance $instance
                Invoke-MemoryClerkCollector -Instance $instance
                Invoke-IOCollector -Instance $instance
                Invoke-TempDBCollector -Instance $instance
                Invoke-BackupsCollector -Instance $instance
                Invoke-DBOptionsCollector -Instance $instance
                Invoke-BlockingCollector -Instance $instance
                Invoke-LongRunningCollector -Instance $instance
                Invoke-WaitsCollector -Instance $instance
                Invoke-TopQueriesCollector -Instance $instance
                Invoke-MissingIndexesCollector -Instance $instance
                Invoke-FragmentationCollector -Instance $instance
                Invoke-AGCollector -Instance $instance
                Invoke-ListenersEndpointsCollector -Instance $instance
                Invoke-AgentJobsCollector -Instance $instance
                Invoke-DeadlocksCollector -Instance $instance
            }
            Default {
                throw "Unsupported collector group: $CollectorGroup"
            }
        }

        Write-Host "Completed $CollectorGroup collectors for $($instance.DisplayName)"
    }
    catch {
        Write-Host "ERROR running $CollectorGroup collectors for $($instance.DisplayName): $($_.Exception.Message)"
        if ($collectorNodeId -gt 0) {
            Send-SqlMonitorCollectorHeartbeat -RepositoryServer $repositorySettings.RepositoryServer -RepositoryDatabase $repositorySettings.RepositoryDatabase -CollectorNodeID $collectorNodeId -Status 'Failed' -CollectorGroup $CollectorGroup -InstanceCount $instanceList.Count -MessageText $_.Exception.Message
        }
        throw
    }
}

if ($collectorNodeId -gt 0) {
    Send-SqlMonitorCollectorHeartbeat -RepositoryServer $repositorySettings.RepositoryServer -RepositoryDatabase $repositorySettings.RepositoryDatabase -CollectorNodeID $collectorNodeId -Status 'Completed' -CollectorGroup $CollectorGroup -InstanceCount $instanceList.Count -MessageText "Collector run completed."
}
