$projectRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $projectRoot 'Jobs\Run-Collectors-InstanceGroup.ps1') -CollectorGroup Advanced
exit $LASTEXITCODE

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\Collect-Waits.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-TopQueries.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-MissingIndexes.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-ExecutionPlans.psm1') -Force
Import-Module (Join-Path $projectRoot 'Modules\Collect-MemoryClerks.psm1') -Force

$instances = @(Get-SqlMonitorInstances)
if ($instances.Count -eq 0) {
    throw "No monitored instances found in $(Get-SqlMonitorConfigPath -FileName 'instances.json')"
}

foreach ($instance in $instances) {
    if (-not $instance.IsActive) {
        continue
    }

    try {
        Write-MonitorLog "Starting ADVANCED collectors for $($instance.DisplayName)"

        # Heavier DMV queries - collected every 30 minutes
        Invoke-WaitsCollector -Instance $instance
        Invoke-TopQueriesCollector -Instance $instance
        Invoke-MissingIndexesCollector -Instance $instance

        # Advanced SQL Server internals monitoring - UNIQUE features
        Get-SQLServerExecutionPlans -Instance $instance -TopQueries 10 -IncludeRecommendations | Out-Null
        Get-SQLServerMemoryClerks -Instance $instance -IncludePressureAnalysis | Out-Null
        Get-SQLServerBufferPoolAnalysis -Instance $instance | Out-Null

        Write-MonitorLog "Completed ADVANCED collectors for $($instance.DisplayName)"
    }
    catch {
        Write-MonitorLog "ERROR in Run-Collectors-Advanced.ps1 for $($instance.DisplayName): $($_.Exception.Message)" -Level 'Error'
    }
}
