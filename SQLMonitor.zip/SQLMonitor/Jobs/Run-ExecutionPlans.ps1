# Run-ExecutionPlans.ps1
# Advanced execution plan monitoring and analysis job
# UNIQUE FEATURE: Real-time query execution plan analysis with optimization recommendations

param(
    [Parameter(Mandatory = $false)]
    [string]$InstanceName,

    [Parameter(Mandatory = $false)]
    [int]$TopQueries = 10,

    [Parameter(Mandatory = $false)]
    [switch]$IncludeRecommendations
)

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $projectRoot 'Modules\Collect-ExecutionPlans.psm1') -Force -WarningAction SilentlyContinue

try {
    $instances = Get-SqlMonitorInstances
    if ($InstanceName) {
        $instances = $instances | Where-Object { $_.DisplayName -eq $InstanceName }
    }

    foreach ($instance in $instances) {
        Write-MonitorLog "Starting execution plan analysis for instance: $($instance.DisplayName)"

        $plans = Get-SQLServerExecutionPlans -Instance $instance -TopQueries $TopQueries -IncludeRecommendations:$IncludeRecommendations

        if ($plans.Count -gt 0) {
            Write-MonitorLog "Analyzed $($plans.Count) execution plans for $($instance.DisplayName)"

            # Log recommendations
            $plansWithRecs = $plans | Where-Object { $_.Recommendations.Count -gt 0 }
            if ($plansWithRecs.Count -gt 0) {
                Write-MonitorLog "Found optimization recommendations for $($plansWithRecs.Count) queries"
                foreach ($plan in $plansWithRecs) {
                    Write-MonitorLog "Query recommendations: $($plan.Recommendations -join '; ')"
                }
            }
        } else {
            Write-MonitorLog "No active queries found for $($instance.DisplayName)"
        }
    }

    Write-MonitorLog "Execution plan analysis job completed successfully"
}
catch {
    Write-MonitorLog "ERROR in execution plan analysis job: $($_.Exception.Message)" -Level 'Error'
    throw
}