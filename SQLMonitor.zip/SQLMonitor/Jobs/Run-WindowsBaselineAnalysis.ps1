param(
    [int]$LookbackDays = 30,
    [decimal]$AnomalyThreshold = 2.5,
    [int]$ForecastLookbackDays = 90
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force

$repository = Get-SqlMonitorRepositorySettings

Write-MonitorLog "Windows VM baseline analysis started."

# Step 1: Recalculate baselines
try {
    $baselineResult = Invoke-MonitorSqlQuery -ServerInstance $repository.RepositoryServer -Database $repository.RepositoryDatabase `
        -Query "EXEC mon.usp_CalculateWindowsBaselines @TargetID = NULL, @LookbackDays = $LookbackDays;" -Timeout 300
    $baselineCount = 0
    if ($baselineResult -is [System.Data.DataTable] -and $baselineResult.Rows.Count -gt 0) {
        $baselineCount = [int]$baselineResult.Rows[0].BaselinesUpdated
    }
    Write-MonitorLog "Baselines updated: $baselineCount rows."
}
catch {
    Write-MonitorLog "Baseline calculation failed: $($_.Exception.Message)" -Level Error
}

# Step 2: Detect anomalies against baselines
try {
    $anomalyResult = Invoke-MonitorSqlQuery -ServerInstance $repository.RepositoryServer -Database $repository.RepositoryDatabase `
        -Query "EXEC mon.usp_DetectWindowsAnomalies @TargetID = NULL, @StdDevThreshold = $AnomalyThreshold;" -Timeout 300
    $anomalyCount = 0
    if ($anomalyResult -is [System.Data.DataTable] -and $anomalyResult.Rows.Count -gt 0) {
        $anomalyCount = [int]$anomalyResult.Rows[0].AnomaliesDetected
    }
    Write-MonitorLog "Anomalies detected: $anomalyCount."
}
catch {
    Write-MonitorLog "Anomaly detection failed: $($_.Exception.Message)" -Level Error
}

# Step 3: Calculate capacity forecasts
try {
    $forecastResult = Invoke-MonitorSqlQuery -ServerInstance $repository.RepositoryServer -Database $repository.RepositoryDatabase `
        -Query "EXEC mon.usp_CalculateWindowsCapacityForecast @TargetID = NULL, @LookbackDays = $ForecastLookbackDays;" -Timeout 300
    $forecastCount = 0
    if ($forecastResult -is [System.Data.DataTable] -and $forecastResult.Rows.Count -gt 0) {
        $forecastCount = [int]$forecastResult.Rows[0].ForecastsUpdated
    }
    Write-MonitorLog "Capacity forecasts updated: $forecastCount."
}
catch {
    Write-MonitorLog "Capacity forecast calculation failed: $($_.Exception.Message)" -Level Error
}

Write-MonitorLog "Windows VM baseline analysis completed."
