# Run-EscalationCheck.ps1 - Scheduled job to check and process ticket escalations
# This script should be run on a schedule (e.g., every 15 minutes) to automatically escalate tickets

param(
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

# Import required modules
Import-Module (Join-Path $ProjectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $ProjectRoot 'Modules\EscalationMatrix.psm1') -Force -WarningAction SilentlyContinue
Import-Module (Join-Path $ProjectRoot 'Modules\TicketSystem.psm1') -Force -WarningAction SilentlyContinue

Write-MonitorLog "=== Starting Escalation Check ===" -Level Info

try {
    # Get tickets pending escalation
    $pendingTickets = Get-TicketsPendingEscalation
    
    if ($pendingTickets -and $pendingTickets.Rows.Count -gt 0) {
        Write-MonitorLog "Found $($pendingTickets.Rows.Count) ticket(s) pending escalation." -Level Info
        
        foreach ($ticket in $pendingTickets) {
            Write-MonitorLog "Processing escalation for Ticket $($ticket.TicketNumber) to $($ticket.EscalationLevel)..." -Level Info
            
            # Record the escalation
            try {
                $result = Add-EscalationHistory -TicketID $ticket.TicketID `
                                              -Level $ticket.EscalationLevel `
                                              -EscalatedTo $ticket.EscalationTo `
                                              -EscalatedBy "system"
                
                Write-MonitorLog "Escalated Ticket $($ticket.TicketNumber) to $($ticket.EscalationLevel) - $($ticket.EscalationTo)" -Level Info
                
                # TODO: Send notification email here
                # You can use the NotificationTemplate from the escalation rule
                # Example: Send-MailMessage -To $ticket.EscalationTo -Subject "Ticket Escalation: $($ticket.TicketNumber)" -Body $ticket.NotificationTemplate
            }
            catch {
                Write-MonitorLog "Error escalating Ticket $($ticket.TicketNumber): $_" -Level Error
            }
        }
    }
    else {
        Write-MonitorLog "No tickets pending escalation." -Level Info
    }
}
catch {
    Write-MonitorLog "Error in escalation check: $_" -Level Error
}

Write-MonitorLog "=== Escalation Check Completed ===" -Level Info
