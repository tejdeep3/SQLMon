# Register SQL Monitor Scheduled Tasks
# Run this script as administrator.

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force

Write-Host "`nRegistering SQL Monitor scheduled tasks..." -ForegroundColor Cyan

$shellPath = Resolve-SqlMonitorPowerShellPath
$taskPath = $PSScriptRoot
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -RunLevel Highest -LogonType ServiceAccount

$tasks = @(
    @{
        Name = 'SQLMonitor-CoreCollectors'
        Path = Join-Path $taskPath 'Run-Collectors-Core.ps1'
        Description = 'SQL Monitor - Core collectors (every 5 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5)
    },
    @{
        Name = 'SQLMonitor-AdvancedCollectors'
        Path = Join-Path $taskPath 'Run-Collectors-Advanced.ps1'
        Description = 'SQL Monitor - Advanced collectors (every 30 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 30)
    },
    @{
        Name = 'SQLMonitor-DailyCollectors'
        Path = Join-Path $taskPath 'Run-Collectors-Daily.ps1'
        Description = 'SQL Monitor - Daily collectors (2 AM)'
        Trigger = New-ScheduledTaskTrigger -Daily -At '2:00 AM'
    },
    @{
        Name = 'SQLMonitor-AlertEngine'
        Path = Join-Path $taskPath 'Run-AlertEngine.ps1'
        Description = 'SQL Monitor - Alert engine (every 2 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 2)
    },
    @{
        Name = 'SQLMonitor-RetentionCleanup'
        Path = Join-Path $taskPath 'Purge-Retention.ps1'
        Description = 'SQL Monitor - Retention cleanup (3 AM)'
        Trigger = New-ScheduledTaskTrigger -Daily -At '3:00 AM'
    },
    @{
        Name = 'SQLMonitor-WindowsVMCollectors'
        Path = Join-Path $taskPath 'Run-WindowsVMCollectors.ps1'
        Description = 'SQL Monitor - Windows VM Collectors (every 15 minutes)'
        Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 15)
    },
    @{
        Name = 'SQLMonitor-WindowsBaselineAnalysis'
        Path = Join-Path $taskPath 'Run-WindowsBaselineAnalysis.ps1'
        Description = 'SQL Monitor - Windows VM Baseline & Anomaly Analysis (daily at 1:00 AM)'
        Trigger = New-ScheduledTaskTrigger -Daily -At '1:00 AM'
    }
)

foreach ($task in $tasks) {
    Write-Host "  Registering $($task.Name)..." -NoNewline

    try {
        $action = New-ScheduledTaskAction -Execute $shellPath -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$($task.Path)`""
        $settings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries `
            -DontStopIfGoingOnBatteries `
            -StartWhenAvailable `
            -ExecutionTimeLimit (New-TimeSpan -Hours 2)

        $taskObject = New-ScheduledTask `
            -Action $action `
            -Trigger $task.Trigger `
            -Principal $principal `
            -Settings $settings `
            -Description $task.Description

        Register-ScheduledTask -TaskName $task.Name -InputObject $taskObject -Force | Out-Null
        Write-Host ' SUCCESS' -ForegroundColor Green
    }
    catch {
        Write-Host " FAILED: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`nRegistered tasks:" -ForegroundColor Cyan
Get-ScheduledTask | Where-Object { $_.TaskName -like 'SQLMonitor-*' } | Format-Table TaskName, State, TaskPath -AutoSize
