# Create-TicketsFromAlerts.ps1 - Scheduled job to automatically create tickets from unacknowledged alerts
# This script should be run on a schedule (e.g., every 5 minutes) to convert alerts to tickets

param(
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

# Import required modules
Import-Module (Join-Path $ProjectRoot 'Modules\Common.psm1') -Force -WarningAction SilentlyContinue

Write-MonitorLog "=== Starting Auto Ticket Creation from Alerts ===" -Level Info

try {
    # Get configuration
    $configPath = Join-Path $ProjectRoot 'Config\instances.json'
    if (-not (Test-Path $configPath)) {
        Write-MonitorLog "Configuration file not found at $configPath" -Level Error
        exit 1
    }
    
    $config = Get-Content $configPath | ConvertFrom-Json
    $serverInstance = $config.RepositoryServer
    $database = $config.RepositoryDatabase
    
    # Use the stored procedure to auto-convert alerts to tickets
    $query = 'DECLARE @TicketsCreated INT; EXEC mon.usp_AutoConvertAlertsToTickets @HoursBack = 24, @CreatedBy = ''system'', @TicketsCreated = @TicketsCreated OUTPUT; SELECT @TicketsCreated AS TicketsCreated;'
    $result = Invoke-MonitorSqlQuery -ServerInstance $serverInstance `
                                      -Database $database `
                                      -Query $query
    
    if ($result -and $result.Rows.Count -gt 0) {
        $ticketsCreated = $result.Rows[0].TicketsCreated
        Write-MonitorLog "Auto-conversion completed. Created $ticketsCreated ticket(s)." -Level Info
    } else {
        Write-MonitorLog "No tickets created or stored procedure not found." -Level Info
    }
}
catch {
    Write-MonitorLog "Error in auto ticket creation: $_" -Level Error
}

Write-MonitorLog "=== Auto Ticket Creation Completed ===" -Level Info
