$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot

Import-Module (Join-Path $projectRoot 'Modules\Common.psm1') -Force

$repositorySettings = Get-SqlMonitorRepositorySettings

try {
    Write-MonitorLog "Starting retention cleanup on $($repositorySettings.RepositoryServer)"

    Invoke-MonitorSqlNonQuery `
        -ServerInstance $repositorySettings.RepositoryServer `
        -Database $repositorySettings.RepositoryDatabase `
        -Query 'EXEC [mon].[usp_PurgeRetention]'

    Write-MonitorLog "Completed retention cleanup on $($repositorySettings.RepositoryServer)"
}
catch {
    Write-MonitorLog "ERROR in Purge-Retention.ps1: $($_.Exception.Message)" -Level 'Error'
    throw
}
