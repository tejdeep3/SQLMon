try {
    $result = Invoke-SqlCmd -ServerInstance 'BBLBHLAP860\BBDBTESTSQL' -Database 'DBA_SQLMonitor' -Query "SELECT COUNT(*) AS Cnt FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'mon' AND TABLE_NAME = 'Tickets'" -TrustServerCertificate
    if ($result.Cnt -gt 0) {
        Write-Host "Tickets table exists"
    } else {
        Write-Host "Tickets table NOT found"
    }
    
    $result2 = Invoke-SqlCmd -ServerInstance 'BBLBHLAP860\BBDBTESTSQL' -Database 'DBA_SQLMonitor' -Query "SELECT COUNT(*) AS Cnt FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA = 'mon' AND ROUTINE_NAME LIKE 'usp_%Ticket%'" -TrustServerCertificate
    Write-Host "Ticket procedures found: $($result2.Cnt)"
} catch {
    Write-Host "Error: $($_.Exception.Message)"
}
