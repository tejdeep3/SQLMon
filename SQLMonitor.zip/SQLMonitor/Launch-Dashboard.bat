@echo off
REM SQL Monitor Dashboard Launcher
REM This batch file launches the SQL Monitor WinForms dashboard

set "ROOT=%~dp0"

REM Change to the GUI directory
cd /d "%ROOT%GUI"

REM Run the PowerShell dashboard script with bypass execution policy
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\SQLMonitorDashboard.ps1"

REM Keep window open if there's an error
if errorlevel 1 (
    echo.
    echo Error launching dashboard. Press any key to exit.
    pause
)

exit /b 0
