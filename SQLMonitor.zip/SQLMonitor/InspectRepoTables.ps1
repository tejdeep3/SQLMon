Import-Module '.\Modules\Common.psm1' -Force
$instance = Get-SqlMonitorInstances | Select-Object -First 1
Write-Host "Repo: $($instance.RepositoryServer) $($instance.RepositoryDatabase)"
$sql = @'
SELECT s.name AS SchemaName, t.name AS TableName
FROM sys.tables t
INNER JOIN sys.schemas s ON t.schema_id=s.schema_id
WHERE t.name IN ('DiskVolumeHistory','ConfigHistory','TempDBHistory','IOHistory','KPIHistory')
'@
Write-Host "Query: $sql"
$dt = Invoke-MonitorSqlQuery -ServerInstance $instance.RepositoryServer -Database $instance.RepositoryDatabase -Query $sql
foreach ($r in $dt.Rows) {
    Write-Host "$($r.SchemaName) $($r.TableName)"
}
