@echo off
REM SQL Monitor - Run Collectors
REM This batch file runs a selected collector group for a specified server instance

set "ROOT=%~dp0"

REM Change to the Jobs directory
cd /d "%ROOT%Jobs"

set "InstanceFilter=%~1"
set "CollectorGroup=%~2"
if "%CollectorGroup%"=="" set "CollectorGroup=All"

echo Running SQL Monitor %CollectorGroup% collectors...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
    "cd '%ROOT%Jobs'; " ^
    "Write-Host 'Running %CollectorGroup% collectors for instance: %InstanceFilter%'; " ^
    "& '.\Run-Collectors-InstanceGroup.ps1' -CollectorGroup '%CollectorGroup%' -InstanceFilter '%InstanceFilter%'"

echo.
set "RC=%ERRORLEVEL%"

if "%RC%"=="0" (
    echo Collection complete.
) else (
    echo Collection failed with exit code %RC%.
)

if /I not "%SQLMON_NO_PAUSE%"=="1" (
    echo Press any key to exit.
    pause >nul
)

exit /b %RC%
