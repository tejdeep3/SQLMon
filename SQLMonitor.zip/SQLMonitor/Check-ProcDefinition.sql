-- Check what the stored procedure actually does
SELECT OBJECT_DEFINITION(OBJECT_ID('mon.usp_ProcessTicketEscalations')) AS ProcDefinition;
