# Fix-UpdateTaskLine.ps1
$filePath = Join-Path $PSScriptRoot "Web\Start-WebServer.ps1"
$content = Get-Content $filePath -Raw

# The exact text to find and replace
$oldText = '        Invoke-RepoNonQuery -Query "EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;" -Parameters @{'
$newText = "        Invoke-RepoNonQuery -Query 'EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;' -Parameters @{"

if ($content.Contains($oldText)) {
    $content = $content.Replace($oldText, $newText)
    Set-Content -Path $filePath -Value $content -Encoding UTF8
    Write-Host "Fixed UpdateTask line"
} else {
    Write-Host "Pattern not found for UpdateTask"
}

# Also fix CreateTask if needed
$oldText2 = '        Invoke-RepoNonQuery -Query "EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;" -Parameters @{'
$newText2 = "        Invoke-RepoNonQuery -Query 'EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;' -Parameters @{"

if ($content.Contains($oldText2)) {
    $content = $content.Replace($oldText2, $newText2)
    Set-Content -Path $filePath -Value $content -Encoding UTF8
    Write-Host "Fixed CreateTask line"
}

# Also fix CreateTicketFromAlert if needed
$oldText3 = '        $result = Invoke-RepoQuery -Query "EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;" -Parameters @{'
$newText3 = "        `$result = Invoke-RepoQuery -Query 'EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;' -Parameters @{"

if ($content.Contains($oldText3)) {
    $content = $content.Replace($oldText3, $newText3)
    Set-Content -Path $filePath -Value $content -Encoding UTF8
    Write-Host "Fixed CreateTicketFromAlert line"
}

Write-Host "All fixes applied"
