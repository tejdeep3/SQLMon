# Windows VM Collector Fixes - Summary

## Problem
Windows VM collectors were only running once after deployment and not on schedule. The root causes were:
1. **Missing scheduled task registration** - The Windows VM collector task was not included in the task registration scripts
2. **Module loading issues** - The collector module had internal function dependencies that weren't properly exported

## Changes Made

### 1. New File-Based Collector Module
**File:** `Modules\Collect-WindowsVM-FileBased.psm1`
- New collector implementation using `Get-ComputerInfo`, `Get-Volume`, `Get-Counter` cmdlets
- Collects the same data as the original collector but uses more modern PowerShell cmdlets
- Inserts data into the same database tables (`mon.WindowsPerformanceSamples`, `mon.WindowsDiskSamples`, etc.)
- Supports file-based output via `Export-WindowsSnapshotFiles`

### 2. Updated Collector Runner
**File:** `Jobs\Run-WindowsVMCollectors.ps1`
- Now imports both `Collect-WindowsVM.psm1` (for helper functions) and `Collect-WindowsVM-FileBased.psm1`
- Calls `Invoke-WindowsVMCollector-FileBased` instead of `Invoke-WindowsVMCollector`

### 3. Updated Task Registration Scripts
**Files:**
- `Jobs\Register-SQLMonitorTasks.ps1`
- `Jobs\Register-Tasks-Admin.ps1`

Both scripts now include the Windows VM collector task:
```powershell
@{
    Name = 'SQLMonitor-WindowsVMCollectors'
    Path = Join-Path $taskPath 'Run-WindowsVMCollectors.ps1'
    Description = 'SQL Monitor - Windows VM Collectors (every 15 minutes)'
    Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 15)
}
```

### 4. Updated Original Module Exports
**File:** `Modules\Collect-WindowsVM.psm1`
- Exported all helper functions so they can be used by the new file-based collector
- Added: `Get-WindowsTargetRows`, `Get-OrCreateWindowsTargetId`, `ConvertTo-DbValue`, `Test-WindowsExtendedSchemaReady`, `Test-WindowsCollectionDue`, `Test-WindowsInventoryDue`, `Get-WindowsCpuPercent`, `Get-WindowsProcessCount`, `Get-WindowsNetworkBytesPerSec`, `Invoke-WindowsTryGet`, `ConvertTo-WindowsShortMessage`, `Export-WindowsSnapshotFiles`, `Get-WindowsVMSnapshot`

### 5. Test Script
**File:** `Test-WindowsVMCollector.ps1`
- Created test script to verify the new collector works correctly
- Tests both file output and database storage

## Test Results
```
✓ Database connection successful: BBLBHLAP860\BBDBTESTSQL\DBA_SQLMonitor
✓ Database storage successful
✓ Data verification successful - found 1 recent records
  - BBLBHLAP860 at 05/18/2026 11:24:48: CPU=24.00%, Memory=75.58%, Score=80
```

## Deployment Steps
1. Run `Jobs\Register-SQLMonitorTasks.ps1` as administrator to register the new scheduled task
2. The Windows VM collector will run every 15 minutes automatically
3. To test manually, run `.\Test-WindowsVMCollector.ps1 -TestDatabaseStorage`

## Notes
- The original `Collect-WindowsVM.psm1` module is still available and functional
- The new file-based collector uses the same database schema and tables
- Both collectors can coexist if needed
