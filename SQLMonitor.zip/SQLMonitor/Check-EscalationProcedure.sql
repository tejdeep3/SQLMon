-- Check escalation stored procedures
SELECT ROUTINE_NAME, ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_SCHEMA = 'mon'
  AND ROUTINE_NAME LIKE '%Escalat%';

-- Check if there are any tickets that need escalation
SELECT t.TicketID, t.TicketNumber, ts.SeverityName, t.CreatedDate,
       DATEDIFF(MINUTE, t.CreatedDate, SYSUTCDATETIME()) AS AgeMinutes
FROM mon.Tickets t
JOIN mon.TicketSeverity ts ON t.TicketSeverityID = ts.TicketSeverityID
WHERE t.TicketStatusID = 1  -- Open tickets
ORDER BY AgeMinutes DESC;

-- Check the vw_TicketsPendingEscalation view definition
SELECT OBJECT_DEFINITION(OBJECT_ID('mon.vw_TicketsPendingEscalation')) AS ViewDefinition;
