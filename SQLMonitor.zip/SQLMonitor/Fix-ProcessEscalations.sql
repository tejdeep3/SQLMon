-- Fix the usp_ProcessTicketEscalations procedure
CREATE OR ALTER PROCEDURE [mon].[usp_ProcessTicketEscalations]
    @BatchSize INT = 50,
    @ProcessedCount INT = 0 OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @TicketID BIGINT, @TicketSeverityID INT, @CurrentLevelID INT;
    DECLARE @NextLevelID INT, @EscalationTo NVARCHAR(255);
    
    -- Find tickets that need escalation
    DECLARE escalation_cursor CURSOR FAST_FORWARD FOR
    SELECT TOP (@BatchSize)
        t.TicketID,
        t.TicketSeverityID,
        ISNULL(t.EscalationLevelID, 0) AS CurrentLevelID
    FROM [mon].[Tickets] t
    WHERE t.TicketStatusID = 1  -- Open tickets only
      AND EXISTS (
          SELECT 1 FROM [mon].[EscalationMatrix] em
          WHERE em.TicketSeverityID = t.TicketSeverityID
            AND em.IsActive = 1
            AND em.EscalationLevelID > ISNULL(t.EscalationLevelID, 0)
      )
    ORDER BY t.CreatedDate ASC;
    
    SET @ProcessedCount = 0;
    
    OPEN escalation_cursor;
    FETCH NEXT FROM escalation_cursor INTO @TicketID, @TicketSeverityID, @CurrentLevelID;
    
    WHILE @@FETCH_STATUS = 0
    BEGIN
        BEGIN TRY
            -- Find the next escalation level
            SELECT TOP 1
                @NextLevelID = em.EscalationLevelID,
                @EscalationTo = em.EscalationTo
            FROM [mon].[EscalationMatrix] em
            WHERE em.TicketSeverityID = @TicketSeverityID
              AND em.IsActive = 1
              AND em.EscalationLevelID > @CurrentLevelID
            ORDER BY em.EscalationLevelID ASC;
            
            IF @NextLevelID IS NOT NULL
            BEGIN
                -- Record the escalation (WITHOUT @NotificationSent parameter)
                EXEC [mon].[usp_RecordEscalation] 
                    @TicketID = @TicketID,
                    @EscalationLevelID = @NextLevelID,
                    @EscalatedTo = @EscalationTo,
                    @EscalatedBy = 'system';
                
                -- Update ticket's escalation level
                UPDATE [mon].[Tickets]
                SET [EscalationLevelID] = @NextLevelID,
                    [ModifiedDate] = SYSUTCDATETIME()
                WHERE [TicketID] = @TicketID;
                
                -- Log in comments
                INSERT INTO [mon].[TicketComments] ([TicketID], [CommentText], [CreatedBy])
                VALUES (@TicketID, 
                        'Ticket escalated to level ' + CAST(@NextLevelID AS NVARCHAR(10)) + ' (' + @EscalationTo + ')', 
                        'system');
                
                SET @ProcessedCount = @ProcessedCount + 1;
                PRINT 'Escalated ticket ID ' + CAST(@TicketID AS NVARCHAR(20));
            END
        END TRY
        BEGIN CATCH
            PRINT 'Error escalating ticket ID ' + CAST(@TicketID AS NVARCHAR(20)) + ': ' + ERROR_MESSAGE();
        END CATCH
        
        FETCH NEXT FROM escalation_cursor INTO @TicketID, @TicketSeverityID, @CurrentLevelID;
    END
    
    CLOSE escalation_cursor;
    DEALLOCATE escalation_cursor;
    
    PRINT 'Escalation processing completed. Processed ' + CAST(@ProcessedCount AS NVARCHAR(10)) + ' ticket(s).';
END
GO

-- Test the fixed procedure
DECLARE @Count INT;
EXEC [mon].[usp_ProcessTicketEscalations] @BatchSize = 10, @ProcessedCount = @Count OUTPUT;
SELECT @Count AS TicketsEscalated;
