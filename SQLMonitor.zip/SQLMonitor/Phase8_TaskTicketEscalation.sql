-- Phase 8: Task Management, Ticketing System, and Escalation Matrix
-- This script creates tables for DBA team task management, ticketing, and escalation

USE [DBA_SQLMonitor]
GO

-- =============================================
-- SECTION 1: TASK MANAGEMENT SYSTEM
-- =============================================

-- Task Status lookup table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TaskStatus' AND xtype='U')
CREATE TABLE [mon].[TaskStatus] (
    [TaskStatusID] [int] NOT NULL,
    [StatusName] [nvarchar](50) NOT NULL,
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_TaskStatus] PRIMARY KEY CLUSTERED ([TaskStatusID] ASC)
) ON [PRIMARY]
GO

-- Insert default task statuses
IF NOT EXISTS (SELECT * FROM [mon].[TaskStatus])
INSERT INTO [mon].[TaskStatus] ([TaskStatusID], [StatusName], [IsActive]) VALUES
(1, 'Open', 1),
(2, 'In Progress', 1),
(3, 'Pending', 1),
(4, 'Completed', 1),
(5, 'Cancelled', 1),
(6, 'On Hold', 1);
GO

-- Task Priority lookup table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TaskPriority' AND xtype='U')
CREATE TABLE [mon].[TaskPriority] (
    [TaskPriorityID] [int] NOT NULL,
    [PriorityName] [nvarchar](50) NOT NULL,
    [PriorityOrder] [int] NOT NULL,
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_TaskPriority] PRIMARY KEY CLUSTERED ([TaskPriorityID] ASC)
) ON [PRIMARY]
GO

-- Insert default priorities
IF NOT EXISTS (SELECT * FROM [mon].[TaskPriority])
INSERT INTO [mon].[TaskPriority] ([TaskPriorityID], [PriorityName], [PriorityOrder], [IsActive]) VALUES
(1, 'Critical', 1, 1),
(2, 'High', 2, 1),
(3, 'Medium', 3, 1),
(4, 'Low', 4, 1);
GO

MERGE [mon].[TaskPriority] AS target
USING (VALUES
    (1, N'Critical', 1, 1),
    (2, N'High', 2, 1),
    (3, N'Medium', 3, 1),
    (4, N'Low', 4, 1)
) AS source ([TaskPriorityID], [PriorityName], [PriorityOrder], [IsActive])
ON target.[TaskPriorityID] = source.[TaskPriorityID]
WHEN MATCHED THEN
    UPDATE SET [PriorityName] = source.[PriorityName],
               [PriorityOrder] = source.[PriorityOrder],
               [IsActive] = source.[IsActive]
WHEN NOT MATCHED THEN
    INSERT ([TaskPriorityID], [PriorityName], [PriorityOrder], [IsActive])
    VALUES (source.[TaskPriorityID], source.[PriorityName], source.[PriorityOrder], source.[IsActive]);
GO

-- Main Tasks table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Tasks' AND xtype='U')
CREATE TABLE [mon].[Tasks] (
    [TaskID] [int] IDENTITY(1,1) NOT NULL,
    [TaskTitle] [nvarchar](255) NOT NULL,
    [TaskDescription] [nvarchar](max) NULL,
    [CreatedBy] [nvarchar](128) NOT NULL,
    [AssignedTo] [nvarchar](128) NULL,
    [TaskStatusID] [int] NOT NULL DEFAULT 1,
    [TaskPriorityID] [int] NOT NULL DEFAULT 3,
    [InstanceID] [int] NULL, -- Optional: Link to monitored instance
    [DueDate] [datetime2](7) NULL,
    [StartDate] [datetime2](7) NULL,
    [CompletedDate] [datetime2](7) NULL,
    [CreatedDate] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    [ModifiedDate] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_Tasks] PRIMARY KEY CLUSTERED ([TaskID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Add foreign key constraints for Tasks
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Tasks_TaskStatus')
ALTER TABLE [mon].[Tasks] WITH CHECK ADD CONSTRAINT [FK_Tasks_TaskStatus] FOREIGN KEY([TaskStatusID])
REFERENCES [mon].[TaskStatus] ([TaskStatusID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Tasks_TaskPriority')
ALTER TABLE [mon].[Tasks] WITH CHECK ADD CONSTRAINT [FK_Tasks_TaskPriority] FOREIGN KEY([TaskPriorityID])
REFERENCES [mon].[TaskPriority] ([TaskPriorityID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Tasks_Instances')
ALTER TABLE [mon].[Tasks] WITH CHECK ADD CONSTRAINT [FK_Tasks_Instances] FOREIGN KEY([InstanceID])
REFERENCES [mon].[MonitoredInstances] ([InstanceID])
GO

-- Task Comments table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TaskComments' AND xtype='U')
CREATE TABLE [mon].[TaskComments] (
    [CommentID] [int] IDENTITY(1,1) NOT NULL,
    [TaskID] [int] NOT NULL,
    [CommentText] [nvarchar](max) NOT NULL,
    [CreatedBy] [nvarchar](128) NOT NULL,
    [CreatedDate] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_TaskComments] PRIMARY KEY CLUSTERED ([CommentID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Add foreign key for TaskComments
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TaskComments_Tasks')
ALTER TABLE [mon].[TaskComments] WITH CHECK ADD CONSTRAINT [FK_TaskComments_Tasks] FOREIGN KEY([TaskID])
REFERENCES [mon].[Tasks] ([TaskID]) ON DELETE CASCADE
GO

IF COL_LENGTH('mon.TaskComments', 'ModifiedBy') IS NULL
ALTER TABLE [mon].[TaskComments] ADD [ModifiedBy] [nvarchar](128) NULL;
GO

IF COL_LENGTH('mon.TaskComments', 'ModifiedDate') IS NULL
ALTER TABLE [mon].[TaskComments] ADD [ModifiedDate] [datetime2](7) NULL;
GO

IF COL_LENGTH('mon.TaskComments', 'IsEdited') IS NULL
ALTER TABLE [mon].[TaskComments] ADD [IsEdited] [bit] NOT NULL CONSTRAINT [DF_TaskComments_IsEdited] DEFAULT (0);
GO

-- Task Activities table (for tracking changes/audit)
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TaskActivities' AND xtype='U')
CREATE TABLE [mon].[TaskActivities] (
    [ActivityID] [int] IDENTITY(1,1) NOT NULL,
    [TaskID] [int] NOT NULL,
    [ActivityType] [nvarchar](50) NOT NULL, -- 'Created', 'Updated', 'StatusChanged', 'CommentAdded', etc.
    [ActivityDescription] [nvarchar](max) NOT NULL,
    [CreatedBy] [nvarchar](128) NOT NULL,
    [CreatedDate] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT [PK_TaskActivities] PRIMARY KEY CLUSTERED ([ActivityID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Add foreign key for TaskActivities
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TaskActivities_Tasks')
ALTER TABLE [mon].[TaskActivities] WITH CHECK ADD CONSTRAINT [FK_TaskActivities_Tasks] FOREIGN KEY([TaskID])
REFERENCES [mon].[Tasks] ([TaskID]) ON DELETE CASCADE
GO

-- =============================================
-- SECTION 2: TICKETING SYSTEM
-- =============================================

-- Ticket Status lookup table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TicketStatus' AND xtype='U')
CREATE TABLE [mon].[TicketStatus] (
    [TicketStatusID] [int] NOT NULL,
    [StatusName] [nvarchar](50) NOT NULL,
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_TicketStatus] PRIMARY KEY CLUSTERED ([TicketStatusID] ASC)
) ON [PRIMARY]
GO

-- Insert default ticket statuses
IF NOT EXISTS (SELECT * FROM [mon].[TicketStatus])
INSERT INTO [mon].[TicketStatus] ([TicketStatusID], [StatusName], [IsActive]) VALUES
(1, 'New', 1),
(2, 'Acknowledged', 1),
(3, 'In Progress', 1),
(4, 'Resolved', 1),
(5, 'Closed', 1),
(6, 'Reopened', 1);
GO

-- Ticket Severity lookup table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TicketSeverity' AND xtype='U')
CREATE TABLE [mon].[TicketSeverity] (
    [TicketSeverityID] [int] NOT NULL,
    [SeverityName] [nvarchar](50) NOT NULL,
    [SeverityOrder] [int] NOT NULL,
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_TicketSeverity] PRIMARY KEY CLUSTERED ([TicketSeverityID] ASC)
) ON [PRIMARY]
GO

-- Insert default severities
IF NOT EXISTS (SELECT * FROM [mon].[TicketSeverity])
INSERT INTO [mon].[TicketSeverity] ([TicketSeverityID], [SeverityName], [SeverityOrder], [IsActive]) VALUES
(1, 'Critical', 1, 1),
(2, 'High', 2, 1),
(3, 'Medium', 3, 1),
(4, 'Low', 4, 1);
GO

MERGE [mon].[TicketSeverity] AS target
USING (VALUES
    (1, N'Critical', 1, 1),
    (2, N'High', 2, 1),
    (3, N'Medium', 3, 1),
    (4, N'Low', 4, 1)
) AS source ([TicketSeverityID], [SeverityName], [SeverityOrder], [IsActive])
ON target.[TicketSeverityID] = source.[TicketSeverityID]
WHEN MATCHED THEN
    UPDATE SET [SeverityName] = source.[SeverityName],
               [SeverityOrder] = source.[SeverityOrder],
               [IsActive] = source.[IsActive]
WHEN NOT MATCHED THEN
    INSERT ([TicketSeverityID], [SeverityName], [SeverityOrder], [IsActive])
    VALUES (source.[TicketSeverityID], source.[SeverityName], source.[SeverityOrder], source.[IsActive]);
GO

-- Main Tickets table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Tickets' AND xtype='U')
CREATE TABLE [mon].[Tickets] (
    [TicketID] [bigint] IDENTITY(1,1) NOT NULL,
    [AlertID] [bigint] NULL, -- Link to AlertHistory if ticket created from alert
    [TicketNumber] [nvarchar](50) NOT NULL, -- Generated ticket number like TKT-2026-0001
    [TicketUID] [uniqueidentifier] NOT NULL DEFAULT NEWSEQUENTIALID(),
    [SourceRepositoryName] [nvarchar](128) NULL,
    [SourceTicketNumber] [nvarchar](50) NULL,
    [TicketType] [nvarchar](50) NOT NULL CONSTRAINT DF_Tickets_TicketType DEFAULT (N'SQL Server'),
    [InstanceID] [int] NULL,
    [ErrorDescription] [nvarchar](max) NOT NULL,
    [TicketStatusID] [int] NOT NULL DEFAULT 1,
    [TicketSeverityID] [int] NOT NULL DEFAULT 3,
    [CreatedBy] [nvarchar](128) NOT NULL,
    [AssignedTo] [nvarchar](128) NULL,
    [AcknowledgedBy] [nvarchar](128) NULL,
    [AcknowledgedDate] [datetime2](7) NULL,
    [ResolvedBy] [nvarchar](128) NULL,
    [ResolvedDate] [datetime2](7) NULL,
    [ResolutionNotes] [nvarchar](max) NULL,
    [CreatedDate] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    [ModifiedDate] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_Tickets] PRIMARY KEY CLUSTERED ([TicketID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Add foreign key constraints for Tickets
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Tickets_TicketStatus')
ALTER TABLE [mon].[Tickets] WITH CHECK ADD CONSTRAINT [FK_Tickets_TicketStatus] FOREIGN KEY([TicketStatusID])
REFERENCES [mon].[TicketStatus] ([TicketStatusID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Tickets_TicketSeverity')
ALTER TABLE [mon].[Tickets] WITH CHECK ADD CONSTRAINT [FK_Tickets_TicketSeverity] FOREIGN KEY([TicketSeverityID])
REFERENCES [mon].[TicketSeverity] ([TicketSeverityID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Tickets_Instances')
ALTER TABLE [mon].[Tickets] WITH CHECK ADD CONSTRAINT [FK_Tickets_Instances] FOREIGN KEY([InstanceID])
REFERENCES [mon].[MonitoredInstances] ([InstanceID])
GO

IF NOT EXISTS (SELECT 1 FROM sys.sequences WHERE name = 'seq_TicketNumber' AND schema_id = SCHEMA_ID('mon'))
BEGIN
    CREATE SEQUENCE mon.seq_TicketNumber
        AS BIGINT
        START WITH 1
        INCREMENT BY 1
        NO CACHE;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UQ_Tickets_TicketUID' AND object_id = OBJECT_ID('mon.Tickets'))
BEGIN
    ALTER TABLE mon.Tickets ADD CONSTRAINT UQ_Tickets_TicketUID UNIQUE (TicketUID);
END
GO

IF COL_LENGTH('mon.Tickets', 'BusinessService') IS NULL
ALTER TABLE [mon].[Tickets] ADD [BusinessService] [nvarchar](160) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'Category') IS NULL
ALTER TABLE [mon].[Tickets] ADD [Category] [nvarchar](80) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'Subcategory') IS NULL
ALTER TABLE [mon].[Tickets] ADD [Subcategory] [nvarchar](80) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'Impact') IS NULL
ALTER TABLE [mon].[Tickets] ADD [Impact] [nvarchar](40) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'Urgency') IS NULL
ALTER TABLE [mon].[Tickets] ADD [Urgency] [nvarchar](40) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'AssignmentGroup') IS NULL
ALTER TABLE [mon].[Tickets] ADD [AssignmentGroup] [nvarchar](160) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'ContactType') IS NULL
ALTER TABLE [mon].[Tickets] ADD [ContactType] [nvarchar](60) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'ExternalReference') IS NULL
ALTER TABLE [mon].[Tickets] ADD [ExternalReference] [nvarchar](160) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'SLADueDate') IS NULL
ALTER TABLE [mon].[Tickets] ADD [SLADueDate] [datetime2](7) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'CloseCode') IS NULL
ALTER TABLE [mon].[Tickets] ADD [CloseCode] [nvarchar](80) NULL;
GO

IF COL_LENGTH('mon.Tickets', 'WorkNotes') IS NULL
ALTER TABLE [mon].[Tickets] ADD [WorkNotes] [nvarchar](max) NULL;
GO

-- Ticket Comments table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TicketComments' AND xtype='U')
CREATE TABLE [mon].[TicketComments] (
    [CommentID] [bigint] IDENTITY(1,1) NOT NULL,
    [TicketID] [bigint] NOT NULL,
    [CommentText] [nvarchar](max) NOT NULL,
    [CreatedBy] [nvarchar](128) NOT NULL,
    [CreatedDate] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_TicketComments] PRIMARY KEY CLUSTERED ([CommentID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Add foreign key for TicketComments
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_TicketComments_Tickets')
ALTER TABLE [mon].[TicketComments] WITH CHECK ADD CONSTRAINT [FK_TicketComments_Tickets] FOREIGN KEY([TicketID])
REFERENCES [mon].[Tickets] ([TicketID]) ON DELETE CASCADE
GO

-- =============================================
-- SECTION 3: ESCALATION MATRIX
-- =============================================

-- Escalation Levels table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EscalationLevels' AND xtype='U')
CREATE TABLE [mon].[EscalationLevels] (
    [EscalationLevelID] [int] NOT NULL,
    [LevelName] [nvarchar](50) NOT NULL,
    [LevelOrder] [int] NOT NULL,
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_EscalationLevels] PRIMARY KEY CLUSTERED ([EscalationLevelID] ASC)
) ON [PRIMARY]
GO

-- Insert default escalation levels
IF NOT EXISTS (SELECT * FROM [mon].[EscalationLevels])
INSERT INTO [mon].[EscalationLevels] ([EscalationLevelID], [LevelName], [LevelOrder], [IsActive]) VALUES
(1, 'Level 1 - DBA Team', 1, 1),
(2, 'Level 2 - Senior DBA', 2, 1),
(3, 'Level 3 - DBA Manager', 3, 1),
(4, 'Level 4 - IT Management', 4, 1);
GO

-- Escalation Matrix table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EscalationMatrix' AND xtype='U')
CREATE TABLE [mon].[EscalationMatrix] (
    [EscalationMatrixID] [int] IDENTITY(1,1) NOT NULL,
    [TicketSeverityID] [int] NOT NULL,
    [EscalationLevelID] [int] NOT NULL,
    [EscalationTimeMinutes] [int] NOT NULL, -- Time before escalating to next level
    [EscalationTo] [nvarchar](256) NOT NULL, -- Email or team name
    [NotificationTemplate] [nvarchar](max) NULL,
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_EscalationMatrix] PRIMARY KEY CLUSTERED ([EscalationMatrixID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Add foreign key constraints for EscalationMatrix
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EscalationMatrix_TicketSeverity')
ALTER TABLE [mon].[EscalationMatrix] WITH CHECK ADD CONSTRAINT [FK_EscalationMatrix_TicketSeverity] FOREIGN KEY([TicketSeverityID])
REFERENCES [mon].[TicketSeverity] ([TicketSeverityID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EscalationMatrix_EscalationLevels')
ALTER TABLE [mon].[EscalationMatrix] WITH CHECK ADD CONSTRAINT [FK_EscalationMatrix_EscalationLevels] FOREIGN KEY([EscalationLevelID])
REFERENCES [mon].[EscalationLevels] ([EscalationLevelID])
GO

-- Escalation History table (tracks escalations)
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='EscalationHistory' AND xtype='U')
CREATE TABLE [mon].[EscalationHistory] (
    [EscalationHistoryID] [bigint] IDENTITY(1,1) NOT NULL,
    [TicketID] [bigint] NOT NULL,
    [EscalationLevelID] [int] NOT NULL,
    [EscalatedTo] [nvarchar](256) NOT NULL,
    [EscalatedOn] [datetime2](7) NOT NULL DEFAULT SYSDATETIME(),
    [EscalatedBy] [nvarchar](128) NOT NULL,
    [ResponseAction] [nvarchar](max) NULL,
    [ResponseDate] [datetime2](7) NULL,
    [IsActive] [bit] NOT NULL DEFAULT 1,
    CONSTRAINT [PK_EscalationHistory] PRIMARY KEY CLUSTERED ([EscalationHistoryID] ASC)
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

-- Add foreign key constraints for EscalationHistory
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EscalationHistory_Tickets')
ALTER TABLE [mon].[EscalationHistory] WITH CHECK ADD CONSTRAINT [FK_EscalationHistory_Tickets] FOREIGN KEY([TicketID])
REFERENCES [mon].[Tickets] ([TicketID])
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_EscalationHistory_EscalationLevels')
ALTER TABLE [mon].[EscalationHistory] WITH CHECK ADD CONSTRAINT [FK_EscalationHistory_EscalationLevels] FOREIGN KEY([EscalationLevelID])
REFERENCES [mon].[EscalationLevels] ([EscalationLevelID])
GO

-- Create indexes for performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Tasks_AssignedTo')
CREATE NONCLUSTERED INDEX [IX_Tasks_AssignedTo] ON [mon].[Tasks] ([AssignedTo])
INCLUDE ([TaskStatusID], [TaskPriorityID], [DueDate])
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Tasks_CreatedBy')
CREATE NONCLUSTERED INDEX [IX_Tasks_CreatedBy] ON [mon].[Tasks] ([CreatedBy])
INCLUDE ([TaskStatusID], [TaskPriorityID], [DueDate])
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Tickets_AssignedTo')
CREATE NONCLUSTERED INDEX [IX_Tickets_AssignedTo] ON [mon].[Tickets] ([AssignedTo])
INCLUDE ([TicketStatusID], [TicketSeverityID], [CreatedDate])
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Tickets_CreatedDate')
CREATE NONCLUSTERED INDEX [IX_Tickets_CreatedDate] ON [mon].[Tickets] ([CreatedDate] DESC)
INCLUDE ([TicketStatusID], [TicketSeverityID], [AssignedTo])
GO

PRINT 'Phase 8: Task Management, Ticketing System, and Escalation Matrix tables created successfully.'
GO
