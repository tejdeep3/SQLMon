# Fix-StartWebServer.ps1
$filePath = Join-Path $PSScriptRoot "Web\Start-WebServer.ps1"
$content = Get-Content $filePath -Raw

# The issue is that PowerShell interprets @TaskID inside double-quoted string as splatting
# Fix: Change double quotes to single quotes for SQL strings that have @parameters

# Fix UpdateTask
$oldUpdateTask = 'Invoke-RepoNonQuery -Query "EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;" -Parameters @{'
$newUpdateTask = "Invoke-RepoNonQuery -Query 'EXEC mon.usp_UpdateTask @TaskID, @TaskTitle, @TaskDescription, @AssignedTo, @TaskStatusID, @TaskPriorityID, @DueDate, @ModifiedBy;' -Parameters @{"

if ($content.Contains($oldUpdateTask)) {
    $content = $content.Replace($oldUpdateTask, $newUpdateTask)
    Write-Host "Fixed UpdateTask section"
} else {
    Write-Host "Pattern not found for UpdateTask"
}

# Fix CreateTask
$oldCreateTask = 'Invoke-RepoQuery -Query "EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;" -Parameters @{'
$newCreateTask = "Invoke-RepoQuery -Query 'EXEC mon.usp_CreateTask @TaskTitle, @TaskDescription, @CreatedBy, @AssignedTo, @TaskPriorityID, @InstanceID, @DueDate;' -Parameters @{"

if ($content.Contains($oldCreateTask)) {
    $content = $content.Replace($oldCreateTask, $newCreateTask)
    Write-Host "Fixed CreateTask section"
} else {
    Write-Host "Pattern not found for CreateTask"
}

# Fix CreateTicketFromAlert
$oldCreateTicket = 'Invoke-RepoQuery -Query "EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;" -Parameters @{'
$newCreateTicket = "Invoke-RepoQuery -Query 'EXEC mon.usp_CreateTicketFromAlert @AlertID, @CreatedBy, @TicketSeverityID, @AssignedTo;' -Parameters @{"

if ($content.Contains($oldCreateTicket)) {
    $content = $content.Replace($oldCreateTicket, $newCreateTicket)
    Write-Host "Fixed CreateTicketFromAlert section"
} else {
    Write-Host "Pattern not found for CreateTicketFromAlert"
}

# Save the file
Set-Content -Path $filePath -Value $content -Encoding UTF8
Write-Host "File saved: $filePath"
