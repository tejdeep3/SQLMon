# SQL Monitor Production Deployment Checklist

## Pre-Deployment Preparation
- [ ] Verify all SQL scripts have been executed:
  - [ ] Sql\00_CoreSchema.sql
  - [ ] Phase4B_CreateTables.sql
  - [ ] Phase6_AdvancedCollectorTables.sql
  - [ ] Sql\07_Extended_Tables.sql
  - [ ] Sql\Phase7_CompleteSchemaCoverage.sql
  - [ ] Phase5_AlertEngine.sql
  - [ ] Phase5B_DashboardAlertViews.sql
  - [ ] Phase5C_AlertAcknowledgement.sql
  - [ ] Sql\15_WindowsMonitoring.sql
  - [ ] Sql\16_WindowsVMAlerting.sql
  - [ ] Sql\17_VM_SQL_Hierarchy.sql
  - [ ] Sql\19_WindowsMemoryTrendProcedures.sql
  - [ ] Sql\20_WindowsCapacityAndBaseline.sql
  - [ ] Sql\21_WindowsNetworkAndPatching.sql

- [ ] Verify PowerShell execution policy allows script execution
- [ ] Ensure service account has appropriate SQL Server permissions
- [ ] Backup existing monitoring data if migrating from another system

## Configuration Setup
- [ ] Update C:\SQLMonitor\Config\instances.json with correct instance details
- [ ] Verify repository database connection strings
- [ ] Test all collector modules can connect to target instances
- [ ] Configure alert thresholds in mon.AlertThresholds table

## Module Testing
- [ ] Test Common.psm1 functions (Get-MonitorInstanceId, Invoke-MonitorSqlQuery, etc.)
- [ ] Test all collector modules individually:
  - [ ] Collect-CPU.psm1
  - [ ] Collect-Memory.psm1
  - [ ] Collect-AgentJobs.psm1
  - [ ] Collect-Deadlocks.psm1
  - [ ] Collect-AG.psm1
  - [ ] Collect-Waits.psm1 (advanced)
  - [ ] Collect-TopQueries.psm1 (advanced)
  - [ ] Collect-MissingIndexes.psm1 (advanced)
  - [ ] Collect-Fragmentation.psm1 (daily)

- [ ] Test Invoke-AlertEngine.psm1
- [ ] Verify dashboard loads without errors

## VM Monitoring Deployment
- [ ] Verify VM Monitoring SQL objects deployed:
  - [ ] mon.WindowsTargets table and targets registered
  - [ ] mon.WindowsPerformanceSamples table
  - [ ] mon.WindowsInventory table
  - [ ] mon.WindowsNetworkAdapterStats table
  - [ ] mon.WindowsNetworkConnectionSamples table
  - [ ] mon.WindowsFirewallStatus table
  - [ ] mon.WindowsPatchBaseline table
  - [ ] mon.WindowsPerformanceBaseline table
  - [ ] mon.WindowsCapacityForecast table
  - [ ] mon.WindowsAnomalyLog table
- [ ] Verify VM collector modules imported:
  - [ ] Collect-WindowsVM.psm1
  - [ ] Collect-WindowsVM-FileBased.psm1
- [ ] Test VM collector manually: Run-WindowsVMCollectors.ps1
- [ ] Verify VM Monitoring dashboard tabs load:
  - [ ] VM Overview (targets, health score, alerts)
  - [ ] VM Inventory (hardware, network adapters, hotfixes)
  - [ ] VM Performance (CPU/Memory/Disk trends)
  - [ ] VM Services (stopped services, events)
  - [ ] Capacity Forecast (exhaustion predictions)
  - [ ] Anomaly Detection (baseline deviations)
  - [ ] Network Monitor (adapter bandwidth, TCP connections, firewall)
  - [ ] Patching Compliance (compliance scorecard, missing patches)
- [ ] Seed patch baseline: INSERT INTO mon.WindowsPatchBaseline for required patches
- [ ] Run baseline analysis: Run-WindowsBaselineAnalysis.ps1
- [ ] Verify capacity forecasts calculated: SELECT * FROM mon.vw_WindowsCapacityDashboard

## Job Runner Testing
- [ ] Run Run-Collectors-Core.ps1 manually
- [ ] Run Run-Collectors-Advanced.ps1 manually
- [ ] Run Run-Collectors-Daily.ps1 manually
- [ ] Run Run-AlertEngine.ps1 manually
- [ ] Run Purge-Retention.ps1 manually

## Scheduled Task Registration
- [ ] Run Register-SQLMonitorTasks.ps1 as administrator
- [ ] Verify tasks appear in Task Scheduler:
  - [ ] SQLMonitor-CoreCollectors (every 5 minutes)
  - [ ] SQLMonitor-AdvancedCollectors (every 30 minutes)
  - [ ] SQLMonitor-DailyCollectors (daily at 2:00 AM)
  - [ ] SQLMonitor-AlertEngine (every 2 minutes)
  - [ ] SQLMonitor-RetentionCleanup (daily at 3:00 AM)
  - [ ] SQLMonitor-WindowsVMCollectors (every 15 minutes)
  - [ ] SQLMonitor-WindowsBaselineAnalysis (daily at 1:00 AM)
  - [ ] SQLMonitor-WebSolutionsAgent (every 4 hours)
  - [ ] SQLMonitor-PatchManager (daily at 4:00 AM)
- [ ] Verify SQL Agent jobs configured:
  - [ ] SQLMonitor - Core Collectors
  - [ ] SQLMonitor - Advanced Collectors
  - [ ] SQLMonitor - Alert Engine
  - [ ] SQLMonitor - Windows VM Collectors
  - [ ] SQLMonitor - Windows VM Baseline Analysis
  - [ ] SQLMonitor - Retention Purge

## Post-Deployment Validation
- [ ] Monitor log files for errors (C:\SQLMonitor\Logs\SQLMonitor.log)
- [ ] Verify data collection is working (check repository tables)
- [ ] Test alert generation and acknowledgement
- [ ] Verify dashboard displays current data
- [ ] Confirm retention cleanup removes old data appropriately

## Production Monitoring
- [ ] Set up log file rotation/monitoring
- [ ] Configure alerting for SQL Monitor failures
- [ ] Document escalation procedures for critical alerts
- [ ] Schedule regular review of alert thresholds and performance

## Backup and Recovery
- [ ] Include DBA_SQLMonitor database in regular backups
- [ ] Document recovery procedures for monitoring system
- [ ] Test restore procedures in non-production environment

## Security Considerations
- [ ] Ensure service account has minimal required permissions
- [ ] Audit SQL Monitor access and activity
- [ ] Secure configuration files and scripts
- [ ] Monitor for unauthorized changes to monitoring system