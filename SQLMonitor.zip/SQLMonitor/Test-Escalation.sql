DECLARE @Count INT;
EXEC mon.usp_ProcessTicketEscalations 
    @BatchSize = 10, 
    @ProcessedCount = @Count OUTPUT;
SELECT @Count AS TicketsEscalated;

-- Check if any tickets were escalated
SELECT TOP 5 
    t.TicketID, 
    t.TicketNumber, 
    ts.SeverityName,
    t.EscalationLevelID,
    em.EscalationTo
FROM mon.Tickets t
LEFT JOIN mon.TicketSeverity ts ON t.TicketSeverityID = ts.TicketSeverityID
LEFT JOIN mon.EscalationMatrix em ON t.EscalationLevelID = em.EscalationLevelID
WHERE t.EscalationLevelID IS NOT NULL;
