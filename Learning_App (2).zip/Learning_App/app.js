


// Global safety net — runs immediately, before any module code
// Ensures the loading overlay never stays stuck, even if the entire script crashes
setTimeout(function() {
  try {
    var _lo = document.getElementById("loadingOverlay");
    if (_lo && !_lo.classList.contains("hidden")) {
      _lo.classList.add("hidden");
      console.warn("Loading overlay force-hidden by global safety net");
    }
  } catch(e) {}
}, 4000);

// ==========================================
// ANIMATION ENGINE — Visual Focus & Engagement
// ==========================================
const Animations = (() => {
  let _particleContainer = null;
  let _confettiColors = ['#7c3aed', '#2563eb', '#06b6d4', '#22c55e', '#f59e0b', '#ef4444', '#ec4899', '#8b5cf6'];

  function init() {
    createAmbientParticles();
    hookIntoApp();
  }

  // ---- Ambient Background Particles ----
  function createAmbientParticles() {
    if (_particleContainer) return;
    _particleContainer = document.createElement('div');
    _particleContainer.className = 'ambient-particles';
    _particleContainer.setAttribute('aria-hidden', 'true');
    document.body.insertBefore(_particleContainer, document.body.firstChild);

    for (let i = 0; i < 15; i++) {
      spawnAmbientParticle();
    }
  }

  function spawnAmbientParticle() {
    if (!_particleContainer) return;
    const p = document.createElement('div');
    p.className = 'ambient-particle';
    const size = 2 + Math.random() * 4;
    p.style.width = size + 'px';
    p.style.height = size + 'px';
    p.style.left = Math.random() * 100 + '%';
    p.style.background = _confettiColors[Math.floor(Math.random() * _confettiColors.length)];
    p.style.animationDuration = (8 + Math.random() * 12) + 's';
    p.style.animationDelay = Math.random() * 10 + 's';
    _particleContainer.appendChild(p);
    p.addEventListener('animationend', () => { p.remove(); spawnAmbientParticle(); });
  }

  // ---- Confetti Explosion ----
  function confettiExplosion(x, y, count) {
    count = count || 50;
    const container = document.createElement('div');
    container.className = 'confetti-container';
    container.setAttribute('aria-hidden', 'true');
    document.body.appendChild(container);

    const shapes = ['circle', 'square', 'triangle'];
    for (let i = 0; i < count; i++) {
      const piece = document.createElement('div');
      piece.className = 'confetti-piece';
      const color = _confettiColors[Math.floor(Math.random() * _confettiColors.length)];
      const size = 6 + Math.random() * 8;
      const shape = shapes[Math.floor(Math.random() * shapes.length)];

      piece.style.width = size + 'px';
      piece.style.height = size + 'px';
      piece.style.background = color;
      piece.style.left = (x || window.innerWidth / 2) + (Math.random() - .5) * 200 + 'px';
      piece.style.top = (y || window.innerHeight / 2) + 'px';

      if (shape === 'circle') piece.style.borderRadius = '50%';
      else if (shape === 'triangle') {
        piece.style.width = '0'; piece.style.height = '0';
        piece.style.background = 'transparent';
        piece.style.borderLeft = size / 2 + 'px solid transparent';
        piece.style.borderRight = size / 2 + 'px solid transparent';
        piece.style.borderBottom = size + 'px solid ' + color;
      }

      const duration = 1.5 + Math.random() * 2;
      piece.style.animationDuration = duration + 's';
      piece.style.setProperty('--rot', (Math.random() * 720 - 360) + 'deg');
      container.appendChild(piece);
    }

    setTimeout(() => container.remove(), 4000);
  }

  // ---- XP Popup ----
  function showXPPopup(amount, x, y) {
    const popup = document.createElement('div');
    popup.className = 'xp-popup';
    popup.textContent = '+' + amount + ' XP';
    popup.setAttribute('aria-hidden', 'true');
    popup.style.left = (x || window.innerWidth / 2 - 30) + 'px';
    popup.style.top = (y || window.innerHeight / 2) + 'px';
    document.body.appendChild(popup);
    setTimeout(() => popup.remove(), 1600);
  }

  // ---- Level Up Overlay ----
  function showLevelUp(level, title) {
    const overlay = document.createElement('div');
    overlay.className = 'level-up-overlay show';
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('role', 'dialog');
    overlay.innerHTML = '<div class="level-up-card">' +
      '<div class="lu-icon">&#11088;</div>' +
      '<h2>Level ' + level + '!</h2>' +
      '<p>' + title + '</p>' +
      '<button class="ai-tutor-btn" id="levelUpDismiss" style="margin-top:16px;">Awesome!</button>' +
      '</div>';
    document.body.appendChild(overlay);

    // Confetti!
    confettiExplosion(window.innerWidth / 2, window.innerHeight / 2, 80);

    const dismiss = document.getElementById('levelUpDismiss');
    if (dismiss) {
      dismiss.addEventListener('click', () => overlay.remove());
    }
    setTimeout(() => { if (overlay.parentNode) overlay.remove(); }, 5000);
  }

  // ---- Streak Fire Animation ----
  function animateStreak() {
    const streakEl = document.getElementById('statStreak');
    if (streakEl) {
      streakEl.classList.add('streak-fire');
      setTimeout(() => streakEl.classList.remove('streak-fire'), 2000);
    }
  }

  // ---- Correct Answer Celebration ----
  function celebrateCorrect(outputArea) {
    if (outputArea) {
      outputArea.classList.add('answer-correct');
      setTimeout(() => outputArea.classList.remove('answer-correct'), 600);
    }
    confettiExplosion(window.innerWidth / 2, window.innerHeight - 100, 30);
  }

  // ---- Wrong Answer Shake ----
  function shakeWrong(outputArea) {
    if (outputArea) {
      outputArea.classList.add('answer-wrong');
      setTimeout(() => outputArea.classList.remove('answer-wrong'), 500);
    }
  }

  // ---- Typing Indicator for Chat ----
  function showTypingIndicator() {
    const container = document.getElementById('chatMessages');
    if (!container) return null;
    const indicator = document.createElement('div');
    indicator.className = 'typing-indicator bot';
    indicator.id = 'typingIndicator';
    indicator.innerHTML = '<span></span><span></span><span></span>';
    container.appendChild(indicator);
    indicator.scrollIntoView({ behavior: 'smooth' });
    return indicator;
  }

  function hideTypingIndicator() {
    const el = document.getElementById('typingIndicator');
    if (el) el.remove();
  }

  // ---- Tab Switch Transition ----
  function animateTabSwitch() {
    const main = document.querySelector('.main-content');
    if (!main) return;
    main.classList.add('transitioning');
    setTimeout(() => main.classList.remove('transitioning'), 200);
  }

  // ---- Scroll-triggered Reveal ----
  function initScrollReveal() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.lesson-panel > *').forEach(el => {
      el.classList.add('reveal-on-scroll');
      observer.observe(el);
    });
  }

  // ---- Hook into App Events ----
  function hookIntoApp() {
    // Hook into showToast for animated toasts
    const origShowToast = window.DOM && DOM.showToast;
    if (origShowToast) {
      DOM.showToast = function(msg, type) {
        origShowToast(msg, type);
        // Add a subtle bounce to the latest toast
        const toasts = document.querySelectorAll('.toast');
        const latest = toasts[toasts.length - 1];
        if (latest) {
          latest.style.animation = 'none';
          latest.offsetHeight; // force reflow
          latest.style.animation = 'slideInRight .4s ease, fadeIn .3s ease';
        }
      };
    }

    // Hook into lesson loading for scroll reveal
    const origLoadTopic = UI.loadTopic;
    if (origLoadTopic) {
      UI.loadTopic = function(id) {
        origLoadTopic(id);
        animateTabSwitch();
        setTimeout(initScrollReveal, 300);
      };
    }

    // Hook into exercise completion for celebrations
    const origCheckAnswer = ExercisesVM.checkAnswer;
    if (origCheckAnswer) {
      ExercisesVM.checkAnswer = async function(idx) {
        const result = await origCheckAnswer.apply(this, arguments);
        const outputArea = document.getElementById('outputArea');
        if (outputArea) {
          const text = outputArea.textContent || '';
          if (text.includes('Correct') || text.includes('passed') || text.includes('&#10003;')) {
            celebrateCorrect(outputArea);
          } else if (text.includes('doesn\'t match') || text.includes('failed') || text.includes('&#10060;')) {
            shakeWrong(outputArea);
          }
        }
        return result;
      };
    }

    // Hook into chat for typing indicator
    const origSendChat = ChatVM.sendChat;
    if (origSendChat) {
      ChatVM.sendChat = async function() {
        const indicator = showTypingIndicator();
        try {
          await origSendChat.apply(this, arguments);
        } finally {
          hideTypingIndicator();
        }
      };
    }

    // Hook into XP awards
    if (typeof Enhancements !== 'undefined' && Enhancements.awardXP) {
      const origAwardXP = Enhancements.awardXP;
      Enhancements.awardXP = function(amount) {
        const result = origAwardXP.apply(this, arguments);
        showXPPopup(amount);
        // Check for level up
        const achState = Enhancements.getAchievementsState ? Enhancements.getAchievementsState() : null;
        if (achState) {
          const xp = achState.totalXP || 0;
          const newLevel = Math.floor(xp / 100) + 1;
          const oldLevel = Math.floor((xp - amount) / 100) + 1;
          if (newLevel > oldLevel) {
            const titles = ['Beginner', 'Explorer', 'Apprentice', 'Coder', 'Developer', 'Engineer', 'Architect', 'Expert', 'Master', 'Grandmaster'];
            const title = titles[Math.min(Math.floor(newLevel / 2), titles.length - 1)];
            setTimeout(() => showLevelUp(newLevel, title), 500);
          }
        }
        return result;
      };
    }

    // Hook into streak updates
    const origUpdateStreak = State.updateStreak;
    if (origUpdateStreak) {
      State.updateStreak = function() {
        const result = origUpdateStreak.apply(this, arguments);
        animateStreak();
        return result;
      };
    }
  }

  return {
    init, confettiExplosion, showXPPopup, showLevelUp,
    celebrateCorrect, shakeWrong, showTypingIndicator,
    hideTypingIndicator, animateTabSwitch, animateStreak,
  };
})();

// ==========================================
// INTERACTIVE DIAGRAMS — Clickable Mermaid Nodes
// ==========================================
const InteractiveDiagrams = (() => {
  let _activePopup = null;
  let _zoomLevels = {};

  // Node data for each topic's diagram
  const NODE_DATA = {
    'getting-started': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>Start</div><div class="legend-item"><span class="legend-dot" style="background:#22c55e"></span>End</div>',
      nodes: {
        'A': { icon: '▶', title: 'Write Code', desc: 'Open your editor and start writing Python code. Every program begins with an idea and turns it into instructions.', code: 'print("Hello, World!")', tip: 'Start simple — even one line is a complete program!' },
        'B': { icon: '💾', title: 'Save .py File', desc: 'Save your code with a .py extension. This tells the operating system it\'s a Python program.', code: '# Save as: hello.py\nprint("Hello!")', tip: 'Use meaningful filenames like calculator.py or game.py' },
        'C': { icon: '⚡', title: 'Run Program', desc: 'Execute your code by running it through the Python interpreter. The computer reads and follows your instructions.', code: 'python hello.py\n# Output: Hello!', tip: 'In PyLearn, just press Ctrl+Enter or click Run!' },
        'D': { icon: '📺', title: 'See Output', desc: 'The results of your program appear in the output area. This is how your code communicates with the world.', code: 'print(2 + 2)\n# Output: 4', tip: 'print() is your best friend for seeing what your code does!' },
      }
    },
    'variables': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>Concept</div><div class="legend-item"><span class="legend-dot" style="background:#06b6d4"></span>Type</div><div class="legend-item"><span class="legend-dot" style="background:#22c55e"></span>Example</div>',
      nodes: {
        'A': { icon: '📦', title: 'Variable Assignment', desc: 'A variable is a named container for data. Use = to assign a value. Python figures out the type automatically!', code: 'name = "Alice"\nage = 25\npi = 3.14', tip: 'Variable names should be descriptive — use user_name not x' },
        'B': { icon: '🔀', title: 'Data Type', desc: 'Every value has a type: str (text), int (whole numbers), float (decimals), bool (True/False).', code: 'type("hello")  # str\ntype(42)     # int\ntype(3.14)   # float', tip: 'Use type() to check any variable\'s type' },
        'C': { icon: '🔤', title: 'String (str)', desc: 'Text data enclosed in quotes. Strings are sequences of characters you can slice, join, and transform.', code: 'name = "Alice"\nprint(name[0])  # A\nprint(len(name))  # 5', tip: 'Strings are immutable — you can\'t change individual characters' },
        'D': { icon: '🔢', title: 'Integer (int)', desc: 'Whole numbers without decimals. Perfect for counting, indexing, and math operations.', code: 'age = 25\nyear = 2024\nprint(age + 5)  # 30', tip: 'Python integers can be arbitrarily large!' },
        'E': { icon: '🔵', title: 'Float (float)', desc: 'Numbers with decimal points. Used for measurements, percentages, and precise calculations.', code: 'pi = 3.14159\ntemp = 98.6\nprint(round(pi, 2))  # 3.14', tip: 'Floats have limited precision — use Decimal for money!' },
        'F': { icon: '✅', title: 'Boolean (bool)', desc: 'True or False values. The foundation of decision-making in code. Result of comparisons.', code: 'active = True\nvalid = 5 > 3  # True\nprint(not active)  # False', tip: '0, empty string, and None are all "falsy" in Python' },
      }
    },
    'strings': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>String</div><div class="legend-item"><span class="legend-dot" style="background:#06b6d4"></span>Operation</div><div class="legend-item"><span class="legend-dot" style="background:#22c55e"></span>Result</div>',
      nodes: {
        'A': { icon: '🔤', title: 'String "Hello"', desc: 'A string is an ordered sequence of characters. Each character has an index starting from 0.', code: 's = "Hello"\nprint(s[0])  # H\nprint(s[-1])  # o', tip: 'Negative indices count from the end: -1 is the last character' },
        'B': { icon: '📐', title: 'Indexing', desc: 'Access individual characters using their position (index). First character is at index 0.', code: 's = "Python"\nprint(s[0])  # P\nprint(s[2])  # t', tip: 'IndexError happens if you go past the last index!' },
        'C': { icon: '✂️', title: 'Slicing', desc: 'Extract substrings using start:end notation. The end index is exclusive.', code: 's = "Hello World"\nprint(s[0:5])   # Hello\nprint(s[6:])    # World', tip: 's[::-1] reverses a string!' },
        'D': { icon: '⚙️', title: 'String Methods', desc: 'Built-in functions that transform strings: upper, lower, strip, split, replace, find...', code: 's = "  hello  "\nprint(s.strip())    # hello\nprint(s.upper())    # HELLO', tip: 'Strings are immutable — methods return NEW strings' },
        'E': { icon: '🎯', title: 's[0] → H', desc: 'Index 0 gives the first character. This is how you access any position in a string.', code: 'name = "Alice"\nfirst = name[0]  # A\nlast = name[-1]   # e', tip: 'Think of indices as positions between characters' },
        'F': { icon: '📏', title: 's[1:4] → ell', desc: 'Slice from index 1 up to (but not including) 4. Gives you characters at positions 1, 2, 3.', code: 's = "Hello"\nprint(s[1:4])  # ell\nprint(s[:3])   # Hel', tip: 'Omit start to begin from 0, omit end to go to the end' },
        'G': { icon: '🔧', title: 'Methods', desc: 'Common string methods: .upper(), .lower(), .strip(), .split(), .replace(), .find()', code: '"hello".upper()      # HELLO\n"  hi  ".strip()    # hi\n"a,b,c".split(",")  # [a,b,c]', tip: 'Chain methods: s.strip().upper().replace(" ", "_")' },
      }
    },
    'lists': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>List</div><div class="legend-item"><span class="legend-dot" style="background:#06b6d4"></span>Access</div><div class="legend-item"><span class="legend-dot" style="background:#22c55e"></span>Result</div>',
      nodes: {
        'A': { icon: '📋', title: 'List [1, 2, 3]', desc: 'An ordered, mutable collection. Can hold any types, grow and shrink dynamically.', code: 'nums = [1, 2, 3]\nmixed = [1, "hi", True]\nempty = []', tip: 'Lists are the most common collection type in Python' },
        'B': { icon: '📐', title: 'Access lst[0]', desc: 'Access elements by index, just like strings. First element is at index 0.', code: 'fruits = ["apple", "banana"]\nprint(fruits[0])   # apple\nprint(fruits[-1])  # banana', tip: 'Use len(lst) to get the number of elements' },
        'C': { icon: '➕', title: 'Modify .append()', desc: 'Add elements to the end, insert at positions, remove items. Lists are mutable!', code: 'lst = [1, 2]\nlst.append(3)      # [1, 2, 3]\nlst.insert(0, 0)   # [0, 1, 2, 3]', tip: 'append() adds one item; extend() adds multiple' },
        'D': { icon: '✂️', title: 'Slice lst[1:3]', desc: 'Extract sublists using the same slicing syntax as strings.', code: 'nums = [10, 20, 30, 40]\nprint(nums[1:3])  # [20, 30]\nprint(nums[:2])   # [10, 20]', tip: 'Slicing creates a new list — original is unchanged' },
        'E': { icon: '🔁', title: 'Loop for x in lst', desc: 'Iterate through every element. The most common way to process a list.', code: 'fruits = ["apple", "banana"]\nfor fruit in fruits:\n    print(fruit)', tip: 'Use enumerate() if you need the index too' },
      }
    },
    'loops': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>for loop</div><div class="legend-item"><span class="legend-dot" style="background:#2563eb"></span>while loop</div>',
      nodes: {
        'A': { icon: '🔁', title: 'for loop', desc: 'Iterate over a sequence (list, string, range). Use when you know how many times to repeat.', code: 'for i in range(5):\n    print(i)  # 0 1 2 3 4', tip: 'range(start, stop, step) gives you control over the sequence' },
        'B': { icon: '🔢', title: 'for i in range(n)', desc: 'Repeat exactly n times. range(n) produces 0, 1, 2, ..., n-1.', code: 'for i in range(3):\n    print(f"Round {i+1}")\n# Round 1, Round 2, Round 3', tip: 'range(5) = 0,1,2,3,4 — always excludes the end!' },
        'C': { icon: '📋', title: 'for item in list', desc: 'Process each element of a collection directly. Cleaner than using indices.', code: 'colors = ["red", "blue"]\nfor color in colors:\n    print(color)', tip: 'This is called "iteration" — the Pythonic way to loop' },
        'D': { icon: '🔄', title: 'while loop', desc: 'Repeat while a condition is true. Use when you don\'t know how many iterations you need.', code: 'n = 5\nwhile n > 0:\n    print(n)\n    n -= 1', tip: 'Always ensure the condition eventually becomes False!' },
        'E': { icon: '❓', title: 'while condition', desc: 'The loop continues as long as the condition evaluates to True. Checked before each iteration.', code: 'password = ""\nwhile password != "secret":\n    password = input("Enter: ")', tip: 'Use break to exit early, continue to skip an iteration' },
      }
    },
    'functions': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>Define</div><div class="legend-item"><span class="legend-dot" style="background:#22c55e"></span>Return</div>',
      nodes: {
        'A': { icon: '⚡', title: 'def func(params)', desc: 'Define reusable blocks of code. Functions take inputs, process them, and can return outputs.', code: 'def greet(name):\n    return f"Hello, {name}!"', tip: 'Use descriptive verb names: calculate_total(), is_valid()' },
        'B': { icon: '⚙️', title: 'Process', desc: 'The function body contains the logic. It can use the parameters to compute results.', code: 'def add(a, b):\n    result = a + b\n    return result', tip: 'A function without return statement returns None' },
        'C': { icon: '📤', title: 'return result', desc: 'Send a value back to the caller. A function can return any type of data.', code: 'def get_stats(nums):\n    return min(nums), max(nums)', tip: 'return exits the function immediately' },
        'D': { icon: '📞', title: 'Call func(args)', desc: 'Execute a function by its name with arguments. The returned value can be stored.', code: 'msg = greet("Alice")\nprint(msg)  # Hello, Alice!', tip: 'Arguments are matched to parameters by position' },
        'E': { icon: '📥', title: 'func(args)', desc: 'Arguments are passed into the function. They become the parameter values inside.', code: 'result = add(3, 5)\nprint(result)  # 8', tip: 'Use keyword arguments for clarity: greet(name="Bob")' },
        'F': { icon: '📤', title: 'Get result', desc: 'Capture the return value in a variable or use it directly in expressions.', code: 'total = add(10, 20)\ndoubled = add(total, total)', tip: 'Functions make code reusable and easier to debug' },
      }
    },
    'oop': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>Class</div><div class="legend-item"><span class="legend-dot" style="background:#06b6d4"></span>Member</div>',
      nodes: {
        'A': { icon: '🏗️', title: 'Class', desc: 'A blueprint for creating objects. Defines what data (attributes) and behavior (methods) objects have.', code: 'class Dog:\n    def __init__(self, name):\n        self.name = name', tip: 'Class names use CamelCase: MyClassName' },
        'B': { icon: '📦', title: 'Attributes (self.x)', desc: 'Variables that belong to each object. self refers to the current instance.', code: 'class Person:\n    def __init__(self, name, age):\n        self.name = name\n        self.age = age', tip: 'self is always the first parameter of instance methods' },
        'C': { icon: '⚙️', title: 'Methods', desc: 'Functions defined inside a class. They operate on the object\'s data.', code: 'class Dog:\n    def bark(self):\n        return f"{self.name} says Woof!"', tip: 'Methods can call other methods using self.other_method()' },
        'D': { icon: '🔗', title: 'Inheritance', desc: 'Create new classes that extend existing ones. Child inherits all parent attributes and methods.', code: 'class Golden(Dog):\n    def fetch(self):\n        return "Fetching!"', tip: 'Use super().__init__() to call the parent constructor' },
      }
    },
    'dictionaries': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>Dict</div>',
      nodes: {
        'A': { icon: '📖', title: 'Dict {key: value}', desc: 'Key-value pairs for fast lookups. Keys must be unique and immutable. Values can be anything.', code: 'person = {"name": "Alice", "age": 30}\nprint(person["name"])  # Alice', tip: 'Use .get(key, default) to avoid KeyError' },
        'B': { icon: '🔑', title: 'Access d[key]', desc: 'Look up values by their key. Much faster than searching through a list.', code: 'scores = {"Alice": 95, "Bob": 87}\nprint(scores["Alice"])  # 95', tip: 'Accessing a missing key raises KeyError' },
        'C': { icon: '➕', title: 'Add d[new] = val', desc: 'Add new key-value pairs or update existing ones. Dictionaries are mutable.', code: 'd = {}\nd["key"] = "value"\nd.update({"a": 1, "b": 2})', tip: 'Assigning to an existing key overwrites the old value' },
        'D': { icon: '🔁', title: 'Loop .items()', desc: 'Iterate over both keys and values simultaneously using .items().', code: 'for key, value in d.items():\n    print(f"{key}: {value}")', tip: 'Use .keys() for just keys, .values() for just values' },
        'E': { icon: '🛡️', title: 'Safe .get(key, default)', desc: 'Access values safely. Returns the default if the key doesn\'t exist instead of crashing.', code: 'age = person.get("age", 0)\nname = person.get("name", "Unknown")', tip: 'The default is None if you don\'t specify one' },
      }
    },
    'control-flow': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#f59e0b"></span>Condition</div><div class="legend-item"><span class="legend-dot" style="background:#22c55e"></span>True</div>',
      nodes: {
        'A': { icon: '❓', title: 'Condition', desc: 'A boolean expression that evaluates to True or False. Controls which code path executes.', code: 'if age >= 18:\n    print("Adult")', tip: 'Common comparisons: ==, !=, <, >, <=, >=' },
        'B': { icon: '✅', title: 'if block', desc: 'Executes only when the condition is True. The code inside must be indented.', code: 'if score >= 90:\n    grade = "A"\n    print("Excellent!")', tip: 'Use pass as a placeholder for empty blocks' },
        'C': { icon: '🔀', title: 'elif', desc: 'Check another condition if the previous one was False. You can chain many elif blocks.', code: 'if score >= 90: grade = "A"\nelif score >= 80: grade = "B"\nelif score >= 70: grade = "C"', tip: 'Only the first True condition runs — order matters!' },
        'D': { icon: '❌', title: 'else block', desc: 'Catches everything that didn\'t match any if/elif condition. Optional but useful.', code: 'if age < 13: print("Child")\nelif age < 20: print("Teen")\nelse: print("Adult")', tip: 'else has no condition — it\'s the default case' },
      }
    },
    'error-handling': {
      legend: '<div class="legend-item"><span class="legend-dot" style="background:#7c3aed"></span>try</div><div class="legend-item"><span class="legend-dot" style="background:#f59e0b"></span>except</div>',
      nodes: {
        'A': { icon: '🛡️', title: 'try block', desc: 'Wrap code that might raise an error. If an error occurs, Python jumps to the except block.', code: 'try:\n    result = 10 / 0\nexcept ZeroDivisionError:\n    print("Cannot divide!")', tip: 'Only wrap the code that can actually fail' },
        'B': { icon: '⚠️', title: 'Risky Code', desc: 'Code that might fail: file operations, user input, network requests, type conversions.', code: 'try:\n    num = int(input("Enter: "))\nexcept ValueError:\n    print("Not a number!")', tip: 'Be specific — catch the exact exception type' },
        'C': { icon: '✅', title: 'Success → Continue', desc: 'If no error occurs, the except block is skipped and execution continues normally.', code: 'try:\n    print("Hello")  # No error!\nexcept:\n    print("Skipped")', tip: 'Happy path runs when nothing goes wrong' },
        'D': { icon: '🔧', title: 'except block', desc: 'Handles the error gracefully. You can catch specific exception types for different handling.', code: 'try:\n    file = open("data.txt")\nexcept FileNotFoundError:\n    print("File not found!")', tip: 'Catch specific exceptions, not bare except:' },
        'E': { icon: '🧹', title: 'finally block', desc: 'Always runs — whether an error occurred or not. Perfect for cleanup like closing files.', code: 'try:\n    f = open("file.txt")\nfinally:\n    f.close()  # Always runs!', tip: 'Use with statement instead of try/finally for files' },
        'F': { icon: '🔄', title: 'Always runs', desc: 'finally executes regardless of success or failure. Great for releasing resources.', code: 'try:\n    connect()\nfinally:\n    disconnect()  # Always cleanup', tip: 'finally runs even if you use return or break' },
        'G': { icon: '🧹', title: 'Cleanup guaranteed', desc: 'Use finally to ensure resources are released: close files, disconnect networks, free memory.', code: 'try:\n    data = fetch()\n    process(data)\nfinally:\n    cleanup()', tip: 'The with statement is Python\'s preferred cleanup pattern' },
      }
    },
  };

  function getNodeData(topicId) {
    return NODE_DATA[topicId] || null;
  }

  function enhanceDiagrams(container) {
    if (!container) return;
    const wrappers = container.querySelectorAll('.mermaid-wrapper');
    wrappers.forEach(wrapper => {
      const mermaidEl = wrapper.querySelector('.mermaid');
      if (!mermaidEl) return;

      // Wait for mermaid to finish rendering SVG
      const svg = mermaidEl.querySelector('svg');
      if (!svg) return;

      // Make nodes clickable
      const nodes = svg.querySelectorAll('.node, .cluster');
      nodes.forEach(node => {
        node.style.cursor = 'pointer';
        node.addEventListener('click', (e) => {
          e.stopPropagation();
          handleNodeClick(node, wrapper);
        });
        node.addEventListener('mouseenter', () => highlightNodePath(node, svg, true));
        node.addEventListener('mouseleave', () => highlightNodePath(node, svg, false));
      });

      // Zoom controls
      const zoomIn = wrapper.querySelector('.diagram-zoom-in');
      const zoomOut = wrapper.querySelector('.diagram-zoom-out');
      const reset = wrapper.querySelector('.diagram-reset');
      const diagramId = wrapper.dataset.diagramId;
      if (!_zoomLevels[diagramId]) _zoomLevels[diagramId] = 1;

      if (zoomIn) zoomIn.addEventListener('click', (e) => {
        e.stopPropagation();
        _zoomLevels[diagramId] = Math.min(_zoomLevels[diagramId] + .2, 3);
        applyZoom(svg, _zoomLevels[diagramId]);
      });
      if (zoomOut) zoomOut.addEventListener('click', (e) => {
        e.stopPropagation();
        _zoomLevels[diagramId] = Math.max(_zoomLevels[diagramId] - .2, .4);
        applyZoom(svg, _zoomLevels[diagramId]);
      });
      if (reset) reset.addEventListener('click', (e) => {
        e.stopPropagation();
        _zoomLevels[diagramId] = 1;
        applyZoom(svg, 1);
      });
    });

    // Close popup on outside click
    document.addEventListener('click', (e) => {
      if (_activePopup && !_activePopup.contains(e.target)) {
        closePopup();
      }
    });
  }

  function applyZoom(svg, level) {
    svg.style.transform = `scale(${level})`;
    svg.style.transformOrigin = 'center center';
    svg.style.transition = 'transform .3s ease';
  }

  function handleNodeClick(node, wrapper) {
    const topicId = wrapper.closest('.concept-map')?.dataset.topicId;
    if (!topicId) return;

    const data = NODE_DATA[topicId];
    if (!data || !data.nodes) return;

    // Get node text
    const textEl = node.querySelector('text, .nodeLabel');
    const nodeText = textEl ? textEl.textContent.trim() : '';
    const nodeId = node.id || '';

    // Find matching node data by text content or ID
    let nodeInfo = null;
    for (const [key, info] of Object.entries(data.nodes)) {
      if (nodeText.toLowerCase().includes(info.title.toLowerCase()) ||
          info.title.toLowerCase().includes(nodeText.toLowerCase()) ||
          nodeId.includes(key)) {
        nodeInfo = info;
        break;
      }
    }

    if (!nodeInfo) {
      // Generic info for nodes without specific data
      nodeInfo = {
        icon: '📌',
        title: nodeText || 'Node',
        desc: 'This is part of the ' + topicId + ' concept map. Explore the connections to understand how it relates to other concepts.',
        code: '# Example code for ' + nodeText,
        tip: 'Click other nodes to explore more!'
      };
    }

    showNodePopup(nodeInfo, node);
  }

  function showNodePopup(info, nodeEl) {
    closePopup();

    const popup = document.createElement('div');
    popup.className = 'node-detail-popup';
    popup.id = 'nodeDetailPopup';
    popup.setAttribute('role', 'dialog');
    popup.setAttribute('aria-label', info.title);

    popup.innerHTML = `
      <button class="nd-close" aria-label="Close">&times;</button>
      <div class="nd-header">
        <div class="nd-icon">${info.icon}</div>
        <div class="nd-title">${info.title}</div>
      </div>
      <div class="nd-desc">${info.desc}</div>
      ${info.code ? `<div class="nd-code">${escapeHtml(info.code)}</div>` : ''}
      ${info.tip ? `<div class="nd-tip">${info.tip}</div>` : ''}
    `;

    document.body.appendChild(popup);
    _activePopup = popup;

    // Position near the node
    const nodeRect = nodeEl.getBoundingClientRect();
    const popupRect = popup.getBoundingClientRect();
    let left = nodeRect.right + 12;
    let top = nodeRect.top;

    // Keep on screen
    if (left + 320 > window.innerWidth) left = nodeRect.left - 332;
    if (top + popupRect.height > window.innerHeight) top = window.innerHeight - popupRect.height - 20;
    if (top < 10) top = 10;

    popup.style.left = left + 'px';
    style.top = top + 'px';

    // Close button
    popup.querySelector('.nd-close').addEventListener('click', closePopup);

    // Animate in
    popup.style.animation = 'none';
    popup.offsetHeight;
    popup.style.animation = 'popIn .25s ease-out';
  }

  function closePopup() {
    if (_activePopup) {
      _activePopup.remove();
      _activePopup = null;
    }
  }

  function highlightNodePath(node, svg, active) {
    const nodeId = node.id;
    if (!nodeId) return;

    // Highlight this node
    node.classList.toggle('highlighted', active);
    if (!active) node.classList.remove('dimmed');

    // Find connected edges
    const edges = svg.querySelectorAll('.edgePath');
    edges.forEach(edge => {
      const edgeId = edge.id || '';
      const connects = edgeId.includes(nodeId) ||
        edge.querySelector('path')?.getAttribute('d')?.includes(nodeId);
      if (active) {
        if (connects) {
          edge.classList.add('highlighted');
          edge.classList.remove('dimmed');
        } else {
          edge.classList.add('dimmed');
          edge.classList.remove('highlighted');
        }
      } else {
        edge.classList.remove('highlighted', 'dimmed');
      }
    });

    // Dim other nodes
    const allNodes = svg.querySelectorAll('.node, .cluster');
    allNodes.forEach(n => {
      if (n.id !== nodeId) {
        n.classList.toggle('dimmed', active);
        if (!active) n.classList.remove('highlighted');
      }
    });
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  return { enhanceDiagrams, getNodeData, closePopup };
})();

// ==========================================
// AI PROVIDER CONFIGURATIONS (shared between ChatVM and UI)
// ==========================================
const AI_PROVIDERS = {
  local: { name: 'Local', icon: '💡', needsKey: false },
  openai: {
    name: 'OpenAI', icon: '🤖', needsKey: true,
    url: 'https://api.openai.com/v1/chat/completions',
    keyPrefix: 'sk-', defaultModel: 'gpt-4o-mini',
    freeModels: [
      { id: 'gpt-4o-mini', name: 'GPT-4o Mini', desc: 'Fast & capable' },
      { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', desc: 'Legacy fast model' },
    ],
    paidModels: [
      { id: 'gpt-4o', name: 'GPT-4o', desc: 'Most capable' },
      { id: 'gpt-4', name: 'GPT-4', desc: 'Advanced reasoning' },
      { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', desc: 'Large context' },
      { id: 'o1-mini', name: 'o1 Mini', desc: 'Reasoning model' },
      { id: 'o1-preview', name: 'o1 Preview', desc: 'Advanced reasoning' },
    ],
    authHeader: (key) => ({ 'Authorization': 'Bearer ' + key }),
  },
  openrouter: {
    name: 'OpenRouter', icon: '🌐', needsKey: true,
    url: 'https://openrouter.ai/api/v1/chat/completions',
    keyPrefix: 'sk-or-', defaultModel: 'meta-llama/llama-3.3-70b-instruct:free',
    freeModels: [
      { id: 'meta-llama/llama-3.3-70b-instruct:free', name: 'LLaMA 3.3 70B', desc: 'Meta (free)' },
      { id: 'meta-llama/llama-3.2-3b-instruct:free', name: 'LLaMA 3.2 3B', desc: 'Meta (free)' },
      { id: 'google/gemma-4-26b-a4b-it:free', name: 'Gemma 4 26B', desc: 'Google (free)' },
      { id: 'qwen/qwen3-coder:free', name: 'Qwen3 Coder', desc: 'Alibaba (free)' },
      { id: 'deepseek/deepseek-v4-flash:free', name: 'DeepSeek V4 Flash', desc: 'DeepSeek (free)' },
      { id: 'openai/gpt-oss-120b:free', name: 'GPT OSS 120B', desc: 'OpenAI (free)' },
      { id: 'nousresearch/hermes-3-llama-3.1-405b:free', name: 'Hermes 3 405B', desc: 'Nous (free)' },
      { id: 'z-ai/glm-4.5-air:free', name: 'GLM 4.5 Air', desc: 'Z.ai (free)' },
    ],
    paidModels: [
      { id: 'openai/gpt-4o', name: 'GPT-4o', desc: 'OpenAI via OR' },
      { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini', desc: 'OpenAI via OR' },
      { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', desc: 'Anthropic via OR' },
      { id: 'anthropic/claude-3-haiku', name: 'Claude 3 Haiku', desc: 'Anthropic via OR' },
      { id: 'google/gemini-2.5-pro', name: 'Gemini 2.5 Pro', desc: 'Google via OR' },
      { id: 'meta-llama/llama-3.1-405b-instruct', name: 'LLaMA 3.1 405B', desc: 'Meta largest' },
      { id: 'mistralai/mixtral-8x7b-instruct', name: 'Mixtral 8x7B', desc: 'Mistral MoE' },
      { id: 'deepseek/deepseek-chat', name: 'DeepSeek V3', desc: 'DeepSeek' },
    ],
    authHeader: (key) => ({ 'Authorization': 'Bearer ' + key, 'HTTP-Referer': window.location.origin, 'X-Title': 'PyLearn AI' }),
  },
  groq: {
    name: 'Groq', icon: '⚡', needsKey: true,
    url: 'https://api.groq.com/openai/v1/chat/completions',
    keyPrefix: 'gsk-', defaultModel: 'llama-3.3-70b-versatile',
    freeModels: [
      { id: 'llama-3.3-70b-versatile', name: 'LLaMA 3.3 70B', desc: 'Meta (free tier)' },
      { id: 'llama-3.1-70b-versatile', name: 'LLaMA 3.1 70B', desc: 'Meta (free tier)' },
      { id: 'mixtral-8x7b-32768', name: 'Mixtral 8x7B', desc: 'Mistral (free tier)' },
      { id: 'gemma2-9b-it', name: 'Gemma 2 9B', desc: 'Google (free tier)' },
    ],
    paidModels: [
      { id: 'llama-3.3-70b-versatile', name: 'LLaMA 3.3 70B (Priority)', desc: 'Faster priority access' },
    ],
    authHeader: (key) => ({ 'Authorization': 'Bearer ' + key }),
  },
  gemini: {
    name: 'Google Gemini', icon: '✨', needsKey: true,
    url: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}',
    keyPrefix: 'AIza-', defaultModel: 'gemini-1.5-flash',
    freeModels: [
      { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash', desc: 'Fast & free' },
      { id: 'gemini-1.5-flash-8b', name: 'Gemini 1.5 Flash 8B', desc: 'Lightweight' },
      { id: 'gemini-pro', name: 'Gemini Pro', desc: 'Legacy free' },
    ],
    paidModels: [
      { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro', desc: 'Most capable' },
      { id: 'gemini-2.0-flash', name: 'Gemini 2.0 Flash', desc: 'Next-gen fast' },
    ],
    authHeader: null,
  },
  claude: {
    name: 'Anthropic Claude', icon: '🧠', needsKey: true,
    url: 'https://api.anthropic.com/v1/messages',
    keyPrefix: 'sk-ant-', defaultModel: 'claude-3-5-haiku-20241022',
    freeModels: [
      { id: 'claude-3-5-haiku-20241022', name: 'Claude 3.5 Haiku', desc: 'Fastest, lowest cost' },
    ],
    paidModels: [
      { id: 'claude-3-5-sonnet-20241022', name: 'Claude 3.5 Sonnet', desc: 'Best balance' },
      { id: 'claude-3-opus-20240229', name: 'Claude 3 Opus', desc: 'Most capable' },
      { id: 'claude-3-5-sonnet-latest', name: 'Claude 3.5 Sonnet (Latest)', desc: 'Updated version' },
    ],
    authHeader: (key) => ({ 'x-api-key': key, 'anthropic-version': '2023-06-01' }),
    isAnthropic: true,
  },
};


const State = (() => {
  const KEYS = {
    PROGRESS: 'pylearn_progress',
    SNIPPETS: 'pylearn_snippets',
    CODE: 'pylearn_code',
    APIKEY: 'pylearn_apikey',
    FONTSIZE: 'pylearn_fontsize',
    THEME: 'pylearn_theme',
    STREAK: 'pylearn_streak',
    LASTVISIT: 'pylearn_lastvisit',
    REPL_HISTORY: 'pylearn_repl_history',
    INSTALLED_PACKAGES: 'pylearn_packages',
    VIRTUAL_FILES: 'pylearn_vfiles',
  };

  // ---- Progress ----
  function getProgress() {
    try { return JSON.parse(localStorage.getItem(KEYS.PROGRESS)) || {}; }
    catch { return {}; }
  }
  function saveProgress(p) {
    localStorage.setItem(KEYS.PROGRESS, JSON.stringify(p));
  }
  function resetProgress() {
    localStorage.removeItem(KEYS.PROGRESS);
    localStorage.removeItem(KEYS.STREAK);
    localStorage.removeItem(KEYS.LASTVISIT);
  }

  // ---- Snippets ----
  function getSnippets() {
    try { return JSON.parse(localStorage.getItem(KEYS.SNIPPETS)) || []; }
    catch { return []; }
  }
  function saveSnippets(s) {
    localStorage.setItem(KEYS.SNIPPETS, JSON.stringify(s));
  }

  // ---- Code (auto-save) ----
  function getCode() { return localStorage.getItem(KEYS.CODE) || ''; }
  function saveCode(code) { localStorage.setItem(KEYS.CODE, code); }

  // ---- Settings ----
  function getSetting(key) { return localStorage.getItem(`pylearn_${key}`); }
  function setSetting(key, val) { localStorage.setItem(`pylearn_${key}`, val); }
  function removeSetting(key) { localStorage.removeItem(`pylearn_${key}`); }

  // ---- Streak ----
  function updateStreak() {
    const today = new Date().toDateString();
    const lastVisit = localStorage.getItem(KEYS.LASTVISIT);
    if (lastVisit !== today) {
      let streak = parseInt(localStorage.getItem(KEYS.STREAK) || '0');
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      streak = (lastVisit === yesterday) ? streak + 1 : 1;
      localStorage.setItem(KEYS.STREAK, streak.toString());
      localStorage.setItem(KEYS.LASTVISIT, today);
      return streak;
    }
    return parseInt(localStorage.getItem(KEYS.STREAK) || '0');
  }
  function getStreak() {
    return parseInt(localStorage.getItem(KEYS.STREAK) || '0');
  }

  // ---- REPL History ----
  function getReplHistory() {
    try { return JSON.parse(localStorage.getItem(KEYS.REPL_HISTORY)) || []; }
    catch { return []; }
  }
  function saveReplHistory(h) {
    localStorage.setItem(KEYS.REPL_HISTORY, JSON.stringify(h.slice(-100))); // keep last 100
  }

  // ---- Installed Packages ----
  function getInstalledPackages() {
    try { return JSON.parse(localStorage.getItem(KEYS.INSTALLED_PACKAGES)) || []; }
    catch { return []; }
  }
  function saveInstalledPackages(pkgs) {
    localStorage.setItem(KEYS.INSTALLED_PACKAGES, JSON.stringify(pkgs));
  }

  // ---- Virtual Files ----
  function getVirtualFiles() {
    try { return JSON.parse(localStorage.getItem(KEYS.VIRTUAL_FILES)) || {}; }
    catch { return {}; }
  }
  function saveVirtualFiles(files) {
    localStorage.setItem(KEYS.VIRTUAL_FILES, JSON.stringify(files));
  }

  return {
    KEYS,
    getProgress, saveProgress, resetProgress,
    getSnippets, saveSnippets,
    getCode, saveCode,
    getSetting, setSetting, removeSetting,
    updateStreak, getStreak,
    getReplHistory, saveReplHistory,
    getInstalledPackages, saveInstalledPackages,
    getVirtualFiles, saveVirtualFiles,
  };
})();


/**
 * MODEL: Pyodide Engine
 * Full Python interpreter — script runner, REPL, input(), packages, virtual FS, debug
 */
const PyodideEngine = (() => {
  let _pyodide = null;
  let _ready = false;
  let _stdoutCallback = null;
  let _stderrCallback = null;
  let _stdinCallback = null;
  let _installedPackages = [];

  // ---- Initialization ----
  async function init(onReady, onError) {
    // Check if loadPyodide is available (CDN loaded?)
    if (typeof loadPyodide !== 'function') {
      const err = new Error('Pyodide CDN not loaded. Check your internet connection or try a different browser.');
      console.error(err);
      if (onError) onError(err);
      return;
    }

    try {
      // Add a 60-second timeout so the app doesn't hang forever
      const timeoutMs = 60000;
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Pyodide load timed out after 60s. Check your internet connection.')), timeoutMs)
      );

      _pyodide = await Promise.race([loadPyodide(), timeoutPromise]);

      // Set up stdout/stderr capture
      _pyodide.setStdout({ batched: (msg) => { if (_stdoutCallback) _stdoutCallback(msg); } });
      _pyodide.setStderr({ batched: (msg) => { if (_stderrCallback) _stderrCallback(msg); } });

      // Set up stdin (for input() support)
      _pyodide.setStdin({ stdin: () => { return _stdinCallback ? _stdinCallback() : ''; } });

      // Restore installed packages list
      _installedPackages = State.getInstalledPackages();

      _ready = true;
      if (onReady) onReady();
    } catch (e) {
      console.error('Pyodide init failed:', e);
      if (onError) onError(e);
    }
  }

  function isReady() { return _ready; }
  function getInstance() { return _pyodide; }

  // ---- Callbacks ----
  function onStdout(cb) { _stdoutCallback = cb; }
  function onStderr(cb) { _stderrCallback = cb; }
  function onStdin(cb) { _stdinCallback = cb; }

  // ---- Run full script ----
  async function runScript(code) {
    if (!_ready) throw new Error('Python environment not ready');
    let stdout = '', stderr = '', error = null;
    const prevStdout = _stdoutCallback;
    const prevStderr = _stderrCallback;

    _pyodide.setStdout({ batched: (msg) => { stdout += msg; } });
    _pyodide.setStderr({ batched: (msg) => { stderr += msg; } });

    try {
      await _pyodide.runPythonAsync(code);
    } catch (e) {
      error = e;
    } finally {
      _pyodide.setStdout({ batched: (msg) => { if (prevStdout) prevStdout(msg); } });
      _pyodide.setStderr({ batched: (msg) => { if (prevStderr) prevStderr(msg); } });
    }
    return { stdout: stdout.trim(), stderr: stderr.trim(), error };
  }

  // ---- REPL: Run single line/expression ----
  async function runLine(code) {
    if (!_ready) throw new Error('Python environment not ready');
    let stdout = '', stderr = '', result = undefined, error = null;
    const prevStdout = _stdoutCallback;
    const prevStderr = _stderrCallback;

    _pyodide.setStdout({ batched: (msg) => { stdout += msg; } });
    _pyodide.setStderr({ batched: (msg) => { stderr += msg; } });

    try {
      // Try evaluating as expression first
      try {
        result = await _pyodide.runPythonAsync(code);
      } catch (syntaxErr) {
        // If it's a SyntaxError, try as statement
        if (syntaxErr.message && syntaxErr.message.includes('SyntaxError')) {
          await _pyodide.runPythonAsync(code);
        } else {
          throw syntaxErr;
        }
      }
    } catch (e) {
      error = e;
    } finally {
      _pyodide.setStdout({ batched: (msg) => { if (prevStdout) prevStdout(msg); } });
      _pyodide.setStderr({ batched: (msg) => { if (prevStderr) prevStderr(msg); } });
    }
    return { stdout: stdout.trim(), stderr: stderr.trim(), result, error };
  }

  // ---- Debug mode: run with traceback ----
  async function runWithTrace(code) {
    if (!_ready) throw new Error('Python environment not ready');
    try {
      await _pyodide.runPythonAsync(`
import traceback, sys
try:
${code.split('\n').map(l => '    ' + l).join('\n')}
except Exception as e:
    traceback.print_exc()
`);
    } catch (e) {
      return { error: e };
    }
    return { error: null };
  }

  // ---- Package Installer ----
  async function installPackage(name) {
    if (!_ready) throw new Error('Python environment not ready');
    try {
      await _pyodide.loadPackage('micropip');
      await _pyodide.runPythonAsync(`
import micropip
await micropip.install('${name}')
`);
      if (!_installedPackages.includes(name)) {
        _installedPackages.push(name);
        State.saveInstalledPackages(_installedPackages);
      }
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  function getInstalledPackages() { return [..._installedPackages]; }

  // ---- Virtual File System ----
  function writeVirtualFile(path, content) {
    if (!_ready) throw new Error('Python environment not ready');
    // Ensure directory exists
    const parts = path.split('/');
    if (parts.length > 1) {
      const dir = parts.slice(0, -1).join('/');
      try { _pyodide.FS.mkdirTree(dir); } catch { /* dir may exist */ }
    }
    _pyodide.FS.writeFile(path, content);
    // Persist to state
    const files = State.getVirtualFiles();
    files[path] = content;
    State.saveVirtualFiles(files);
  }

  function readVirtualFile(path) {
    if (!_ready) throw new Error('Python environment not ready');
    return _pyodide.FS.readFile(path, { encoding: 'utf8' });
  }

  function deleteVirtualFile(path) {
    if (!_ready) throw new Error('Python environment not ready');
    try { _pyodide.FS.unlink(path); } catch { /* may not exist */ }
    const files = State.getVirtualFiles();
    delete files[path];
    State.saveVirtualFiles(files);
  }

  function listVirtualFiles() {
    if (!_ready) throw new Error('Python environment not ready');
    const files = [];
    try {
      const root = _pyodide.FS.readdir('/');
      for (const f of root) {
        if (f !== '.' && f !== '..') {
          try {
            const stat = _pyodide.FS.stat('/' + f);
            if (_pyodide.FS.isFile(stat.mode)) files.push(f);
          } catch { /* skip */ }
        }
      }
    } catch { /* empty */ }
    return files;
  }

  function restoreVirtualFiles() {
    const files = State.getVirtualFiles();
    for (const [path, content] of Object.entries(files)) {
      try {
        const parts = path.split('/');
        if (parts.length > 1) {
          const dir = parts.slice(0, -1).join('/');
          try { _pyodide.FS.mkdirTree(dir); } catch { /* exists */ }
        }
        _pyodide.FS.writeFile(path, content);
      } catch (e) { console.warn('Failed to restore file:', path, e); }
    }
  }

  // ---- Run with test cases ----
  async function runWithTestCases(code, testCases) {
    if (!_ready) throw new Error('Python environment not ready');
    const results = [];

    for (const tc of testCases) {
      let stdout = '', stderr = '', error = null;
      const prevStdout = _stdoutCallback;
      const prevStderr = _stderrCallback;

      _pyodide.setStdout({ batched: (msg) => { stdout += msg; } });
      _pyodide.setStderr({ batched: (msg) => { stderr += msg; } });

      try {
        // If test has input, set up stdin
        if (tc.input) {
          let inputIdx = 0;
          const inputs = Array.isArray(tc.input) ? tc.input : [tc.input];
          _pyodide.setStdin({ stdin: () => { return inputs[inputIdx++] || ''; } });
        }

        await _pyodide.runPythonAsync(code);
        const output = stdout.trim();
        // Normalize both sides for flexible comparison
        var expectedRaw = tc.expected.replace(/\\n/g, '\n').replace(/\\t/g, '\t');
        var outputClean = output.replace(/\r\n/g, '\n').trim();
        var expectedClean = expectedRaw.replace(/\r\n/g, '\n').trim();
        var passed = tc.validate ? tc.validate(output) : (outputClean === expectedClean || outputClean.replace(/\s+/g, ' ') === expectedClean.replace(/\s+/g, ' '));

        results.push({
          passed,
          input: tc.input || '',
          expected: tc.expected,
          actual: output,
          description: tc.description || '',
        });
      } catch (e) {
        results.push({
          passed: false,
          input: tc.input || '',
          expected: tc.expected,
          actual: e.message,
          description: tc.description || '',
          error: e.message,
        });
      } finally {
        _pyodide.setStdout({ batched: (msg) => { if (prevStdout) prevStdout(msg); } });
        _pyodide.setStderr({ batched: (msg) => { if (prevStderr) prevStderr(msg); } });
        _pyodide.setStdin({ stdin: () => { if (_stdinCallback) return _stdinCallback(); return ''; } });
      }
    }
    return results;
  }

  return {
    init, isReady, getInstance,
    onStdout, onStderr, onStdin,
    runScript, runLine, runWithTrace,
    installPackage, getInstalledPackages,
    writeVirtualFile, readVirtualFile, deleteVirtualFile, listVirtualFiles, restoreVirtualFiles,
    runWithTestCases,
  };
})();


/**
 * MODEL: Curriculum Data
 * Full curriculum — beginner → intermediate → advanced → professional → tracks
 */
const Curriculum = (() => {

  // ---- Knowledge Maps (for AI tutor progression intelligence) ----
  const knowledgeMaps = {
    'variables': {
      beginner: 'Variables store data. Use name = value. Types: int, float, str, bool.',
      intermediate: 'Type conversion, multiple assignment, unpacking, f-strings, scope (local vs global).',
      advanced: 'Mutable vs immutable types, interning, garbage collection basics, __slots__.',
    },
    'strings': {
      beginner: 'Strings are text in quotes. Use + to concatenate, * to repeat.',
      intermediate: 'Slicing [start:stop:step], methods (upper, lower, strip, split, join), f-strings.',
      advanced: 'String interning, encoding (UTF-8), regex basics, str vs bytes.',
    },
    'lists': {
      beginner: 'Lists store ordered items. Use [1, 2, 3]. Access by index.',
      intermediate: 'Slicing, methods (append, insert, pop, sort), list comprehensions.',
      advanced: 'Deep vs shallow copy, list as stack/queue, itertools, memory layout.',
    },
    'control-flow': {
      beginner: 'if/elif/else for decisions. Comparison operators.',
      intermediate: 'Ternary expressions, truthiness, short-circuit evaluation.',
      advanced: 'Pattern matching (match/case Python 3.10+), walrus operator.',
    },
    'loops': {
      beginner: 'for loops iterate. while loops repeat while true.',
      intermediate: 'enumerate, zip, break/continue, nested loops, loop-else.',
      advanced: 'Iterators protocol (__iter__, __next__), itertools, generator expressions.',
    },
    'functions': {
      beginner: 'def creates functions. return gives back a value.',
      intermediate: 'Default args, *args/**kwargs, lambda, scope, closures.',
      advanced: 'Decorators, functools (lru_cache, partial), first-class functions.',
    },
    'oop': {
      beginner: 'Classes bundle data + methods. self refers to instance.',
      intermediate: 'Inheritance, polymorphism, __str__/__repr__, @property.',
      advanced: 'Metaclasses, descriptors, ABC, dataclasses, multiple inheritance MRO.',
    },
    'recursion': {
      beginner: 'A function calling itself. Needs a base case to stop.',
      intermediate: 'Recursive vs iterative, memoization, recursive data structures.',
      advanced: 'Tail recursion, recursive decorators, tree/graph recursion.',
    },
    'comprehensions': {
      beginner: '[x for x in items] creates lists from loops.',
      intermediate: 'Dict/set comprehensions, nested comprehensions, conditional filtering.',
      advanced: 'Generator expressions, lazy evaluation, performance comparison.',
    },
    'iterators-generators': {
      beginner: 'Generators use yield instead of return. They pause and resume.',
      intermediate: 'yield from, send(), throw(), generator pipelines.',
      advanced: 'async generators, contextlib, coroutine-based generators.',
    },
    'decorators': {
      beginner: 'Decorators wrap functions to add behavior. Use @syntax.',
      intermediate: 'Decorator arguments, @wraps, class decorators, multiple decorators.',
      advanced: 'Descriptor protocol, __call__, decorator factories, registry pattern.',
    },
    'context-managers': {
      beginner: 'with statement ensures cleanup. Like with open() for files.',
      intermediate: 'Custom context managers using __enter__/__exit__.',
      advanced: 'contextlib, @contextmanager, ExitStack, async context managers.',
    },
    'async': {
      beginner: 'async/await for concurrent code. async def creates coroutines.',
      intermediate: 'asyncio.gather, asyncio.create_task, async for, async with.',
      advanced: 'Event loop internals, async generators, structured concurrency.',
    },
    'testing': {
      beginner: 'assert checks conditions. pytest runs test functions.',
      intermediate: 'Fixtures, parametrize, mocking, test classes.',
      advanced: 'Property-based testing, coverage, CI integration, TDD workflow.',
    },
    'closures': {
      beginner: 'A closure is a function that remembers variables from its enclosing scope.',
      intermediate: 'Nonlocal keyword, closure factories, decorators as closures.',
      advanced: 'Cell objects, __closure__, late binding gotchas, callback patterns.',
    },
    'multithreading': {
      beginner: 'Threading runs tasks concurrently. GIL limits true parallelism.',
      intermediate: 'Thread pools, locks, queues, daemon threads.',
      advanced: 'multiprocessing for CPU-bound, concurrent.futures, asyncio vs threading.',
    },
    'interview': {
      beginner: 'Basic problems: FizzBuzz, palindrome, reverse string.',
      intermediate: 'Two Sum, valid parentheses, merge intervals.',
      advanced: 'Dynamic programming, graph algorithms, system design basics.',
    },
    'input-validation': {
      beginner: 'input() reads user data. Always validate and sanitize.',
      intermediate: 'Try/except for input loops, regex validation, custom validators.',
      advanced: 'Schema validation, sanitization libraries, defensive programming.',
    },
    'string-formatting': {
      beginner: 'f-strings embed expressions: f"{name} is {age}".',
      intermediate: 'Format specifiers: .2f, :>10, :, padding, alignment.',
      advanced: 'Template strings, locale formatting, custom format specs.',
    },
    'list-deep-dive': {
      beginner: 'Lists are dynamic arrays. Indexing, slicing, methods.',
      intermediate: 'List as stack/queue, bisect, sorted with key, in-place ops.',
      advanced: 'Array module, memoryview, buffer protocol, numpy bridge.',
    },
    'regex': {
      beginner: 're module: search, match, findall for pattern matching.',
      intermediate: 'Groups, named groups, lookahead/lookbehind, sub/replace.',
      advanced: 'Compiled patterns, regex engines, performance optimization.',
    },
    'json-csv': {
      beginner: 'json module for JSON. csv module for CSV files.',
      intermediate: 'Custom encoders/decoders, DictReader/Writer, streaming.',
      advanced: 'Schema validation, large file processing, data pipelines.',
    },
    'functional': {
      beginner: 'map, filter, reduce, lambda for functional style.',
      intermediate: 'functools: partial, reduce, cmp_to_key, total_ordering.',
      advanced: 'Function composition, currying, monads, itertools mastery.',
    },
    'type-hints': {
      beginner: 'Type hints: def f(x: int) -> str. Optional, List, Dict.',
      intermediate: 'Union, Tuple, Callable, TypeVar, Generic, Protocol.',
      advanced: 'mypy, runtime checking, dataclasses with types, overload.',
    },
    'metaclasses': {
      beginner: 'Metaclasses control class creation. type() is the default.',
      intermediate: '__new__, __init__, __prepare__, registry pattern.',
      advanced: 'ABCMeta, custom metaclasses, ORM patterns, DSL creation.',
    },
    'descriptors': {
      beginner: 'Descriptors: __get__, __set__, __delete__. @property is one.',
      intermediate: 'Data vs non-data descriptors, __set_name__, slots.',
      advanced: 'Descriptor protocols, lazy attributes, validation frameworks.',
    },
    'design-patterns': {
      beginner: 'Singleton, Factory, Observer — common OOP patterns.',
      intermediate: 'Strategy, Command, Decorator pattern, Adapter.',
      advanced: 'Dependency injection, MVC, repository pattern, SOLID.',
    },
    'algorithms': {
      beginner: 'Big O notation. Linear vs binary search. Bubble sort.',
      intermediate: 'Merge sort, quicksort, BFS/DFS, dynamic programming.',
      advanced: 'Dijkstra, A*, greedy algorithms, amortized analysis.',
    },
    'packaging': {
      beginner: 'setup.py, pyproject.toml. pip install -e . for dev.',
      intermediate: 'Entry points, console_scripts, package data, versioning.',
      advanced: 'Wheels, twine, CI/CD publishing, private repositories.',
    },
    'cli-tools': {
      beginner: 'argparse for command-line arguments. sys.argv basics.',
      intermediate: 'Subparsers, groups, mutually exclusive, custom actions.',
      advanced: 'Click library, rich output, progress bars, REPL integration.',
    },
    'database-basics': {
      beginner: 'sqlite3 module. CREATE, INSERT, SELECT, UPDATE, DELETE.',
      intermediate: 'Parameterized queries, transactions, context managers.',
      advanced: 'SQLAlchemy ORM, migrations, connection pooling, indexing.',
    },
    'web-scraping': {
      beginner: 'urllib for HTTP. BeautifulSoup for HTML parsing.',
      intermediate: 'requests library, session handling, pagination.',
      advanced: 'Scrapy, async scraping, rate limiting, data extraction.',
    },
  };

  // ---- Visual Explanations (Mermaid diagrams for each topic) ----
  const visualExplanations = {
    'getting-started': `flowchart LR
    A["Write Code"] --> B["Save .py"]
    B --> C["Run Program"]
    C --> D["See Output"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'variables': `flowchart TD
    A["Variable Assignment"] --> B{Data Type}
    B -->|text| C["str"]
    B -->|whole| D["int"]
    B -->|decimal| E["float"]
    B -->|yes/no| F["bool"]
    C --> G["name = Alice"]
    D --> H["age = 25"]
    E --> I["pi = 3.14"]
    F --> J["active = True"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#f59e0b,stroke:#f59e0b,color:#fff
    style C fill:#06b6d4,stroke:#06b6d4,color:#fff
    style D fill:#06b6d4,stroke:#06b6d4,color:#fff
    style E fill:#06b6d4,stroke:#06b6d4,color:#fff
    style F fill:#06b6d4,stroke:#06b6d4,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
    style H fill:#22c55e,stroke:#22c55e,color:#fff
    style I fill:#22c55e,stroke:#22c55e,color:#fff
    style J fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'strings': `flowchart LR
    A["String"] --> B["Indexing"]
    A --> C["Slicing"]
    A --> D["Methods"]
    B --> E["s[0] first char"]
    C --> F["s[1:4] substring"]
    D --> G["upper, lower, split"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'lists': `flowchart TD
    A["List [1,2,3]"] --> B["Access lst[0]"]
    A --> C["Modify .append()"]
    A --> D["Slice lst[1:3]"]
    A --> E["Loop for x in lst"]
    B --> F["First item"]
    C --> G["Add to end"]
    D --> H["Get subset"]
    E --> I["Process each"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#2563eb,stroke:#2563eb,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
    style H fill:#22c55e,stroke:#22c55e,color:#fff
    style I fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'tuples-sets': `flowchart LR
    A["Tuple (immutable)"] --> B["(1, 2, 3)"]
    A --> C["Unpacking: a, b = t"]
    D["Set (unique)"] --> E["{1, 2, 3} no dupes"]
    D --> F["Union: |"]
    D --> G["Intersection: &"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#22c55e,stroke:#22c55e,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#06b6d4,stroke:#06b6d4,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'dictionaries': `flowchart TD
    A["Dict {key: value}"] --> B["Access d[key]"]
    A --> C["Add d[new] = val"]
    A --> D["Loop .items()"]
    A --> E["Safe .get(key, default)"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#2563eb,stroke:#2563eb,color:#fff
`,
    'control-flow': `flowchart TD
    A{Condition}
    A -->|True| B["if block"]
    A -->|False| C{elif}
    C -->|True| D["elif block"]
    C -->|False| E["else block"]
    style A fill:#f59e0b,stroke:#f59e0b,color:#fff
    style B fill:#22c55e,stroke:#22c55e,color:#fff
    style C fill:#f59e0b,stroke:#f59e0b,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
    style E fill:#ef4444,stroke:#ef4444,color:#fff
`,
    'loops': `flowchart LR
    A["for loop"] --> B["for i in range(n)"]
    A --> C["for item in list"]
    D["while loop"] --> E["while condition"]
    B --> F["Known count"]
    C --> G["Iterate collection"]
    E --> H["Unknown count"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#06b6d4,stroke:#06b6d4,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#06b6d4,stroke:#06b6d4,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
    style H fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'functions': `flowchart TD
    A["def func(params)"] --> B["Process"]
    B --> C["return result"]
    D["Call func(args)"] --> E["Get result"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#22c55e,stroke:#22c55e,color:#fff
    style D fill:#06b6d4,stroke:#06b6d4,color:#fff
    style E fill:#f59e0b,stroke:#f59e0b,color:#fff
`,
    'oop': `flowchart TD
    A["Class"] --> B["Attributes (self.x)"]
    A --> C["Methods def method()"]
    A --> D["Inheritance class Child(Parent)"]
    B --> E["Data"]
    C --> F["Behavior"]
    D --> G["Reuse and Extend"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'file-handling': `flowchart LR
    A["open(file, mode)"] --> B{mode}
    B -->|r Read| C["Read"]
    B -->|w Write| D["Write"]
    B -->|a Append| E["Append"]
    C --> F[".read()"]
    D --> G[".write()"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#f59e0b,stroke:#f59e0b,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#2563eb,stroke:#2563eb,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'error-handling': `flowchart TD
    A["try"] --> B["Risky Code"]
    B -->|Success| C["Continue"]
    B -->|Error| D["except"]
    D --> E["Handle Error"]
    A --> F["finally"]
    F --> G["Always runs"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#22c55e,stroke:#22c55e,color:#fff
    style D fill:#f59e0b,stroke:#f59e0b,color:#fff
    style E fill:#ef4444,stroke:#ef4444,color:#fff
    style F fill:#2563eb,stroke:#2563eb,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'modules': `flowchart LR
    A["import module"] --> B["Use module.func()"]
    C["from module import x"] --> D["Direct use: x()"]
    E["import m as alias"] --> F["Short name: m.func()"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#22c55e,stroke:#22c55e,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
    style E fill:#06b6d4,stroke:#06b6d4,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'recursion': `flowchart TD
    A["Function calls itself"] --> B{Base case?}
    B -->|Yes| C["Return value"]
    B -->|No| D["Recursive call"]
    D --> A
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#f59e0b,stroke:#f59e0b,color:#fff
    style C fill:#22c55e,stroke:#22c55e,color:#fff
    style D fill:#06b6d4,stroke:#06b6d4,color:#fff
`,
    'comprehensions-advanced': `flowchart LR
    A["Iterable"] --> B["List Comp"]
    A --> C["Dict Comp"]
    A --> D["Set Comp"]
    A --> E["Generator"]
    B --> F["[x for x in items]"]
    C --> G["{k: v for k, v in pairs}"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#2563eb,stroke:#2563eb,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'iterators-generators': `flowchart LR
    A["Iterator Protocol"] --> B["__iter__()"]
    B --> C["__next__()"]
    D["Generator"] --> E["yield"]
    E --> F["Pause and Resume"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#06b6d4,stroke:#06b6d4,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#f59e0b,stroke:#f59e0b,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'decorators': `flowchart TD
    A["Original Function"] --> B["@decorator"]
    B --> C["Wrapper Function"]
    C --> D["Enhanced Behavior"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#f59e0b,stroke:#f59e0b,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'context-managers': `flowchart LR
    A["with resource"] --> B["__enter__()"]
    B --> C["Use resource"]
    C --> D["__exit__()"]
    D --> E["Cleanup guaranteed"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#06b6d4,stroke:#06b6d4,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'memory-management': `flowchart TD
    A["Assignment"] --> B["Reference"]
    C["Shallow Copy"] --> D["New outer, shared inner"]
    E["Deep Copy"] --> F["Fully independent"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
    style E fill:#f59e0b,stroke:#f59e0b,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'closures': `flowchart TD
    A["Outer Function"] --> B["Inner Function"]
    B --> C["Remembers outer vars"]
    C --> D["Closure Created"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#06b6d4,stroke:#06b6d4,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'multithreading': `flowchart LR
    A["Threading"] --> B["IO-bound tasks"]
    C["Multiprocessing"] --> D["CPU-bound tasks"]
    B --> E["Network, Files"]
    D --> F["Math, Data"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#f59e0b,stroke:#f59e0b,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'async-programming': `flowchart TD
    A["async def"] --> B["Coroutine"]
    B --> C["await"]
    C --> D["Non-blocking IO"]
    D --> E["Concurrent execution"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#f59e0b,stroke:#f59e0b,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'testing': `flowchart LR
    A["Write Test"] --> B["assert condition"]
    B -->|Pass| C["Continue"]
    B -->|Fail| D["Fix code"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#22c55e,stroke:#22c55e,color:#fff
    style D fill:#ef4444,stroke:#ef4444,color:#fff
`,
    'logging-debugging': `flowchart LR
    A["logging levels"] --> B["DEBUG"]
    B --> C["INFO"]
    C --> D["WARNING"]
    D --> E["ERROR"]
    E --> F["CRITICAL"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#22c55e,stroke:#22c55e,color:#fff
    style D fill:#f59e0b,stroke:#f59e0b,color:#fff
    style E fill:#ef4444,stroke:#ef4444,color:#fff
    style F fill:#ef4444,stroke:#ef4444,color:#fff
`,
    'input-validation': `flowchart TD
    A["input function"] --> B["Get user data"]
    B --> C{"Valid?"}
    C -->|No| D["try except retry"]
    C -->|Yes| E["Use data"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#06b6d4,stroke:#06b6d4,color:#fff
    style C fill:#f59e0b,stroke:#f59e0b,color:#fff
    style D fill:#ef4444,stroke:#ef4444,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'string-formatting': `flowchart LR
    A["String Formatting"] --> B["f-strings"]
    A --> C["format method"]
    A --> D["percent formatting"]
    B --> E["f name"]
    C --> F["format a b"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'list-deep-dive': `flowchart TD
    A["List Operations"] --> B["Stack LIFO"]
    A --> C["Queue FIFO"]
    A --> D["Sort and Reverse"]
    B --> E["append and pop"]
    C --> F["deque popleft"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'regex': `flowchart LR
    A["re module"] --> B["search and match"]
    A --> C["findall"]
    A --> D["sub and replace"]
    B --> E["Find pattern"]
    C --> F["Find all matches"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'json-csv': `flowchart LR
    A["Data Formats"] --> B["JSON"]
    A --> C["CSV"]
    B --> D["json loads and dumps"]
    C --> E["csv DictReader Writer"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'functional': `flowchart LR
    A["Functional Tools"] --> B["map"]
    A --> C["filter"]
    A --> D["reduce"]
    B --> E["Transform"]
    C --> F["Select"]
    D --> G["Aggregate"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
    style G fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'type-hints': `flowchart LR
    A["Type Hints"] --> B["Basic int str"]
    A --> C["Optional Union"]
    A --> D["Generic List of T"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
`,
    'metaclasses': `flowchart TD
    A["type"] --> B["Metaclass"]
    B --> C["Class"]
    C --> D["Instance"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#06b6d4,stroke:#06b6d4,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'descriptors': `flowchart LR
    A["Descriptor"] --> B["dunder get"]
    A --> C["dunder set"]
    A --> D["dunder delete"]
    B --> E["Read"]
    C --> F["Write"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'design-patterns': `flowchart LR
    A["Patterns"] --> B["Strategy"]
    A --> C["Observer"]
    A --> D["Factory"]
    B --> E["Swap algorithms"]
    C --> F["Event handling"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'algorithms': `flowchart LR
    A["Complexity"] --> B["O(1) Constant"]
    A --> C["O(n) Linear"]
    A --> D["O(n squared) Quadratic"]
    A --> E["O(log n) Log"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#f59e0b,stroke:#f59e0b,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'packaging': `flowchart LR
    A["Package"] --> B["pyproject.toml"]
    B --> C["python -m build"]
    C --> D["dist whl"]
    D --> E["twine upload"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#06b6d4,stroke:#06b6d4,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'cli-tools': `flowchart LR
    A["argparse"] --> B["Arguments"]
    A --> C["Subcommands"]
    B --> D["Positional"]
    B --> E["Optional flags"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
    style E fill:#22c55e,stroke:#22c55e,color:#fff
`,
    'database-basics': `flowchart LR
    A["SQLite"] --> B["CREATE TABLE"]
    A --> C["INSERT"]
    A --> D["SELECT"]
    A --> E["UPDATE and DELETE"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#2563eb,stroke:#2563eb,color:#fff
`,
    'web-scraping': `flowchart LR
    A["HTTP Request"] --> B["Get HTML"]
    B --> C["Parse HTML"]
    C --> D["Extract Data"]
    D --> E["Store and Process"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#2563eb,stroke:#2563eb,color:#fff
    style E fill:#2563eb,stroke:#2563eb,color:#fff
`,
  };

  // ---- Key Points for each topic ----
  const keyPointsMap = {
    'getting-started': [
      { icon: '🖨️', title: 'print()', desc: 'Use print() to display output on screen' },
      { icon: '💬', title: 'Strings', desc: 'Text wrapped in quotes: "hello" or \'hello\'' },
      { icon: '🔢', title: 'Math', desc: 'Python is a calculator: +, -, *, /, **, //, %' },
      { icon: '💭', title: 'Comments', desc: 'Use # to add notes that Python ignores' },
    ],
    'variables': [
      { icon: '📦', title: 'Assignment', desc: 'name = value — no type declaration needed' },
      { icon: '🔤', title: 'str', desc: 'Text data: name = "Alice"' },
      { icon: '🔢', title: 'int & float', desc: 'Numbers: age = 25, pi = 3.14' },
      { icon: '✅', title: 'bool', desc: 'True/False values for logic' },
      { icon: '🔄', title: 'Type Conversion', desc: 'int(), str(), float(), bool()' },
    ],
    'strings': [
      { icon: '📏', title: 'Indexing', desc: 's[0] gets first char, s[-1] gets last' },
      { icon: '✂️', title: 'Slicing', desc: 's[start:stop:step] extracts substrings' },
      { icon: '🔧', title: 'Methods', desc: 'upper(), lower(), strip(), split(), join()' },
      { icon: '🎨', title: 'f-strings', desc: 'f"{name} is {age}" — embed expressions' },
      { icon: '🔒', title: 'Immutable', desc: 'Strings cannot be changed after creation' },
    ],
    'lists': [
      { icon: '📋', title: 'Ordered', desc: 'Items have positions: lst[0], lst[1]...' },
      { icon: '➕', title: 'Mutable', desc: 'Can add, remove, and change items' },
      { icon: '🔧', title: 'Methods', desc: 'append(), insert(), pop(), sort(), reverse()' },
      { icon: '🧠', title: 'Comprehension', desc: '[x**2 for x in range(10) if x%2==0]' },
    ],
    'tuples-sets': [
      { icon: '🔒', title: 'Tuple = Immutable', desc: 'Cannot change after creation — faster than lists' },
      { icon: '🎯', title: 'Unpacking', desc: 'a, b = (1, 2) assigns a=1, b=2' },
      { icon: '✨', title: 'Set = Unique', desc: 'No duplicates allowed, unordered' },
      { icon: '🔗', title: 'Set Operations', desc: 'Union (|), Intersection (&), Difference (-)' },
    ],
    'dictionaries': [
      { icon: '📖', title: 'Key-Value Pairs', desc: '{"name": "Alice", "age": 30}' },
      { icon: '🔍', title: 'Access', desc: 'd["key"] or d.get("key", default)' },
      { icon: '🔄', title: 'Loop', desc: 'for k, v in d.items(): print(k, v)' },
      { icon: '🧠', title: 'Comprehension', desc: '{x: x**2 for x in range(5)}' },
    ],
    'control-flow': [
      { icon: '🔀', title: 'if/elif/else', desc: 'Make decisions based on conditions' },
      { icon: '⚖️', title: 'Comparisons', desc: '==, !=, <, >, <=, >=' },
      { icon: '🔗', title: 'Logical', desc: 'and, or, not — combine conditions' },
      { icon: '💡', title: 'Ternary', desc: '"yes" if condition else "no"' },
    ],
    'loops': [
      { icon: '🔁', title: 'for loop', desc: 'Iterate over sequences: for x in items' },
      { icon: '🔄', title: 'while loop', desc: 'Repeat while condition is True' },
      { icon: '📊', title: 'range()', desc: 'range(5) → 0,1,2,3,4' },
      { icon: '⏭️', title: 'break/continue', desc: 'break exits loop, continue skips iteration' },
      { icon: '🔢', title: 'enumerate()', desc: 'Get index + value: for i, x in enumerate(lst)' },
    ],
    'functions': [
      { icon: '⚡', title: 'def', desc: 'Define reusable code blocks' },
      { icon: '📥', title: 'Parameters', desc: 'def greet(name, times=1)' },
      { icon: '📤', title: 'return', desc: 'Send a value back to the caller' },
      { icon: '⭐', title: '*args/**kwargs', desc: 'Accept any number of arguments' },
      { icon: 'λ', title: 'Lambda', desc: 'Anonymous functions: lambda x: x**2' },
    ],
    'oop': [
      { icon: '🏗️', title: 'Class', desc: 'Blueprint for creating objects' },
      { icon: '🧱', title: '__init__', desc: 'Constructor — sets up new instances' },
      { icon: '🧬', title: 'Inheritance', desc: 'class Child(Parent) — reuse and extend' },
      { icon: '🔒', title: 'Encapsulation', desc: 'self.__private — hide internal data' },
      { icon: '🎭', title: 'Polymorphism', desc: 'Same method name, different behavior' },
    ],
    'file-handling': [
      { icon: '📂', title: 'with statement', desc: 'Auto-closes files — always use it!' },
      { icon: '📖', title: 'Modes', desc: 'r=read, w=write, a=append, r+=both' },
      { icon: '📄', title: 'Read', desc: 'f.read(), f.readlines(), for line in f' },
      { icon: '✏️', title: 'Write', desc: 'f.write("text"), f.writelines(list)' },
    ],
    'error-handling': [
      { icon: '🛡️', title: 'try/except', desc: 'Catch and handle errors gracefully' },
      { icon: '🎯', title: 'Specific Errors', desc: 'except ValueError, except TypeError' },
      { icon: '🧹', title: 'finally', desc: 'Always runs — for cleanup code' },
      { icon: '⚠️', title: 'raise', desc: 'Trigger errors: raise ValueError("msg")' },
    ],
    'modules': [
      { icon: '📦', title: 'import', desc: 'import math, from math import pi' },
      { icon: '🎲', title: 'random', desc: 'randint(), choice(), shuffle()' },
      { icon: '📊', title: 'json', desc: 'dumps() and loads() for JSON data' },
      { icon: '🔍', title: 'dir()', desc: 'Explore module contents' },
    ],
    'recursion': [
      { icon: '🔄', title: 'Self-Calling', desc: 'Function calls itself' },
      { icon: '🛑', title: 'Base Case', desc: 'Stopping condition — prevents infinite loop' },
      { icon: '📞', title: 'Call Stack', desc: 'Each call waits for the next to complete' },
      { icon: '⚡', title: 'Memoization', desc: '@lru_cache — remember previous results' },
    ],
    'comprehensions-advanced': [
      { icon: '📋', title: 'List Comp', desc: '[expr for x in items if condition]' },
      { icon: '📖', title: 'Dict Comp', desc: '{k: v for k, v in pairs}' },
      { icon: '🧠', title: 'Nested', desc: '[x for row in matrix for x in row]' },
      { icon: '⚡', title: 'Generator', desc: '(x**2 for x in range) — lazy evaluation' },
    ],
    'iterators-generators': [
      { icon: '🔁', title: 'Iterator', desc: '__iter__() and __next__()' },
      { icon: '⚡', title: 'Generator', desc: 'yield — pause and resume' },
      { icon: '🔗', title: 'Pipeline', desc: 'Chain generators for data processing' },
      { icon: '📦', title: 'yield from', desc: 'Delegate to another generator' },
    ],
    'decorators': [
      { icon: '✨', title: '@syntax', desc: '@timer def func(): wraps the function' },
      { icon: '🎁', title: 'Wrapper', desc: 'Inner function adds behavior' },
      { icon: '📦', title: '@wraps', desc: 'Preserve original function metadata' },
      { icon: '🔧', title: 'Arguments', desc: 'def repeat(n): return decorator' },
    ],
    'context-managers': [
      { icon: '🔒', title: 'with', desc: 'Ensures cleanup happens automatically' },
      { icon: '🚪', title: '__enter__', desc: 'Setup — runs at start of with block' },
      { icon: '🧹', title: '__exit__', desc: 'Cleanup — runs at end, even on error' },
      { icon: '📦', title: '@contextmanager', desc: 'Create CMs with a generator function' },
    ],
    'memory-management': [
      { icon: '📎', title: 'Reference', desc: 'Assignment creates a reference, not a copy' },
      { icon: '📋', title: 'Shallow Copy', desc: 'New outer object, shared inner objects' },
      { icon: '🔬', title: 'Deep Copy', desc: 'Completely independent copy' },
      { icon: '🗑️', title: 'Garbage Collection', desc: 'Python auto-frees unused memory' },
    ],
    'closures': [
      { icon: '🔐', title: 'Closure', desc: 'Function remembers outer scope variables' },
      { icon: '📦', title: 'Factory', desc: 'make_multiplier(n) returns a function' },
      { icon: '🔄', title: 'nonlocal', desc: 'Modify outer scope variable from inner function' },
      { icon: '⚠️', title: 'Late Binding', desc: 'Closures capture variables, not values' },
    ],
    'multithreading': [
      { icon: '🧵', title: 'Threading', desc: 'For I/O-bound tasks (network, files)' },
      { icon: '⚡', title: 'GIL', desc: 'Global Interpreter Lock limits CPU parallelism' },
      { icon: '🔒', title: 'Lock', desc: 'threading.Lock() for thread safety' },
      { icon: '🏭', title: 'Pool', desc: 'ThreadPoolExecutor for managing threads' },
    ],
    'async-programming': [
      { icon: '🔀', title: 'async/await', desc: 'Non-blocking concurrent code' },
      { icon: '📋', title: 'asyncio.gather', desc: 'Run multiple coroutines concurrently' },
      { icon: '🔄', title: 'async for', desc: 'Iterate over async generators' },
      { icon: '🚪', title: 'async with', desc: 'Async context managers' },
    ],
    'testing': [
      { icon: '✅', title: 'assert', desc: 'assert add(2,3) == 5 — verify correctness' },
      { icon: '📦', title: 'Fixtures', desc: '@pytest.fixture for setup/teardown' },
      { icon: '🔢', title: 'Parametrize', desc: 'Run same test with different inputs' },
      { icon: '🎭', title: 'Mocking', desc: 'Replace dependencies for isolated tests' },
    ],
    'logging-debugging': [
      { icon: '📊', title: 'Levels', desc: 'DEBUG < INFO < WARNING < ERROR < CRITICAL' },
      { icon: '📝', title: 'basicConfig', desc: 'Configure format and output destination' },
      { icon: '🐛', title: 'pdb', desc: 'Python debugger — set_trace() for breakpoints' },
      { icon: '✅', title: 'Assertions', desc: 'assert condition, "message" — fail fast' },
    ],
    'input-validation': [
      { icon: '⌨️', title: 'input()', desc: 'Read user input as a string' },
      { icon: '🔄', title: 'Validation Loop', desc: 'while True with try/except' },
      { icon: '🛡️', title: 'Sanitization', desc: 'Never trust user input' },
      { icon: '✅', title: 'Type Check', desc: 'int(), float() with error handling' },
    ],
    'string-formatting': [
      { icon: '🎨', title: 'f-strings', desc: 'f"{name} is {age}" — most readable' },
      { icon: '📐', title: 'Alignment', desc: '< left, > right, ^ center' },
      { icon: '🔢', title: 'Numbers', desc: '.2f for decimals, :, for thousands' },
      { icon: '📝', title: '.format()', desc: '"{} {}".format(a, b) — older style' },
    ],
    'list-deep-dive': [
      { icon: '📚', title: 'Stack (LIFO)', desc: 'append() to push, pop() to remove last' },
      { icon: '🚶', title: 'Queue (FIFO)', desc: 'deque: append() + popleft()' },
      { icon: '🔄', title: 'Rotate', desc: 'lst[k:] + lst[:k] — shift elements' },
      { icon: '✨', title: 'Deduplicate', desc: 'Use dict.fromkeys() or loop with "not in"' },
    ],
    'regex': [
      { icon: '🔍', title: 'search/match', desc: 'Find patterns in text' },
      { icon: '📋', title: 'findall', desc: 'Find all matches as a list' },
      { icon: '✏️', title: 'sub', desc: 'Replace matches with new text' },
      { icon: '🎯', title: 'Groups', desc: 'Extract parts of a match with ()' },
    ],
    'json-csv': [
      { icon: '📊', title: 'JSON', desc: 'json.dumps() to serialize, json.loads() to parse' },
      { icon: '📋', title: 'CSV', desc: 'csv.DictReader for named column access' },
      { icon: '🔄', title: 'Conversion', desc: 'JSON ↔ Python dict ↔ CSV row' },
      { icon: '📦', title: 'Streaming', desc: 'Process large files line by line' },
    ],
    'functional': [
      { icon: '🗺️', title: 'map', desc: 'Transform each item: map(fn, items)' },
      { icon: '🔍', title: 'filter', desc: 'Select items: filter(fn, items)' },
      { icon: '📦', title: 'reduce', desc: 'Aggregate: reduce(fn, items)' },
      { icon: '🔧', title: 'functools', desc: 'partial, lru_cache, cmp_to_key' },
    ],
    'type-hints': [
      { icon: '📝', title: 'Basic', desc: 'def f(x: int) -> str' },
      { icon: '❓', title: 'Optional', desc: 'Optional[str] = str or None' },
      { icon: '🔀', title: 'Union', desc: 'Union[str, int] = either type' },
      { icon: '🧬', title: 'Generic', desc: 'List[T], Dict[str, T]' },
    ],
    'metaclasses': [
      { icon: '🔮', title: 'type()', desc: 'Everything is an instance of type' },
      { icon: '🏗️', title: 'Metaclass', desc: 'Controls how classes are created' },
      { icon: '📋', title: 'Registry', desc: 'Auto-register subclasses' },
      { icon: '🧬', title: '__init_subclass__', desc: 'Hook for class creation' },
    ],
    'descriptors': [
      { icon: '📎', title: 'Protocol', desc: '__get__, __set__, __delete__' },
      { icon: '🔒', title: 'Data Descriptor', desc: 'Has __set__ — overrides instance dict' },
      { icon: '📖', title: 'Non-Data', desc: 'Only __get__ — instance dict overrides' },
      { icon: '🎯', title: '@property', desc: 'Built-in descriptor for computed attributes' },
    ],
    'design-patterns': [
      { icon: '🎯', title: 'Strategy', desc: 'Swap algorithms at runtime' },
      { icon: '👁️', title: 'Observer', desc: 'Event-driven notification system' },
      { icon: '🏭', title: 'Factory', desc: 'Create objects without specifying class' },
      { icon: '🔌', title: 'Adapter', desc: 'Make incompatible interfaces work together' },
    ],
    'algorithms': [
      { icon: '📊', title: 'Big O', desc: 'Measure time/space complexity' },
      { icon: '🔍', title: 'Binary Search', desc: 'O(log n) — search sorted arrays' },
      { icon: '🔀', title: 'Merge Sort', desc: 'O(n log n) — divide and conquer' },
      { icon: '🧠', title: 'Dynamic Programming', desc: 'Break problems into subproblems' },
    ],
    'packaging': [
      { icon: '📦', title: 'pyproject.toml', desc: 'Modern project configuration' },
      { icon: '🔨', title: 'Build', desc: 'python -m build creates .whl and .tar.gz' },
      { icon: '📤', title: 'Publish', desc: 'twine upload dist/* to PyPI' },
      { icon: '🔧', title: 'Entry Points', desc: 'console_scripts for CLI commands' },
    ],
    'cli-tools': [
      { icon: '🖥️', title: 'argparse', desc: 'Standard library CLI framework' },
      { icon: '📋', title: 'Subcommands', desc: 'git-style command groups' },
      { icon: '🖱️', title: 'Click', desc: 'Third-party library for elegant CLIs' },
      { icon: '🎨', title: 'Rich Output', desc: 'Colors, tables, progress bars' },
    ],
    'database-basics': [
      { icon: '🗄️', title: 'SQLite', desc: 'File-based, no server needed' },
      { icon: '📋', title: 'CRUD', desc: 'Create, Read, Update, Delete' },
      { icon: '🔒', title: 'Parameterized', desc: 'Always use ? placeholders — prevents SQL injection' },
      { icon: '📦', title: 'Context Manager', desc: 'with sqlite3.connect() as conn' },
    ],
    'web-scraping': [
      { icon: '🌐', title: 'HTTP', desc: 'urllib or requests for web requests' },
      { icon: '📄', title: 'HTML Parsing', desc: 'BeautifulSoup or html.parser' },
      { icon: '📊', title: 'JSON APIs', desc: 'Parse JSON responses with json.loads()' },
      { icon: '⚠️', title: 'Ethics', desc: 'Check robots.txt, respect rate limits' },
    ],
  };

  // ---- Interview Problem Bank ----
  const problemBank = [
    {
      id: 'two-sum', title: 'Two Sum', difficulty: 'Easy', type: 'interview',
      description: 'Given an array of integers nums and an integer target, return indices of the two numbers that add up to target.',
      starterCode: 'def two_sum(nums, target):\n    # Your code here\n    pass\n\nprint(two_sum([2, 7, 11, 15], 9))',
      solution: 'def two_sum(nums, target):\n    seen = {}\n    for i, num in enumerate(nums):\n        if target - num in seen:\n            return [seen[target - num], i]\n        seen[num] = i\n    return []',
      hint: 'Use a hash map to store seen numbers and their indices.',
      testCases: [
        { input: [[2,7,11,15], 9], expected: '[0, 1]', description: 'Basic case' },
        { input: [[3,2,4], 6], expected: '[1, 2]', description: 'Non-adjacent' },
        { input: [[3,3], 6], expected: '[0, 1]', description: 'Same numbers' },
      ],
    },
    {
      id: 'valid-parentheses', title: 'Valid Parentheses', difficulty: 'Easy', type: 'interview',
      description: 'Given a string s containing just the characters (){}[], determine if the input string is valid.',
      starterCode: 'def is_valid(s):\n    # Your code here\n    pass\n\nprint(is_valid("()[]{}"))\nprint(is_valid("(]"))',
      solution: 'def is_valid(s):\n    stack = []\n    pairs = {\')\': \'(\', \'}\': \'{\', \']\': \'[\'}\n    for c in s:\n        if c in pairs.values():\n            stack.append(c)\n        elif stack and stack[-1] == pairs.get(c):\n            stack.pop()\n        else:\n            return False\n    return not stack',
      hint: 'Use a stack. Push opening brackets, pop when matching closing bracket appears.',
      testCases: [
        { input: ['()[]{}'], expected: 'True', description: 'Valid mixed' },
        { input: ['(]'], expected: 'False', description: 'Invalid' },
        { input: ['{[]}'], expected: 'True', description: 'Nested valid' },
      ],
    },
    {
      id: 'max-subarray', title: 'Maximum Subarray', difficulty: 'Medium', type: 'interview',
      description: 'Find the contiguous subarray with the largest sum and return its sum.',
      starterCode: 'def max_subarray(nums):\n    # Your code here\n    pass\n\nprint(max_subarray([-2,1,-3,4,-1,2,1,-5,4]))',
      solution: 'def max_subarray(nums):\n    max_sum = current = nums[0]\n    for num in nums[1:]:\n        current = max(num, current + num)\n        max_sum = max(max_sum, current)\n    return max_sum',
      hint: "Kadane's algorithm: at each position, decide whether to extend the current subarray or start fresh.",
      testCases: [
        { input: [[-2,1,-3,4,-1,2,1,-5,4]], expected: '6', description: 'Mixed array' },
        { input: [[1]], expected: '1', description: 'Single element' },
        { input: [[5,4,-1,7,8]], expected: '23', description: 'Mostly positive' },
      ],
    },
    {
      id: 'group-anagrams', title: 'Group Anagrams', difficulty: 'Medium', type: 'interview',
      description: 'Group anagrams together from a list of strings.',
      starterCode: 'def group_anagrams(strs):\n    # Your code here\n    pass\n\nprint(group_anagrams(["eat","tea","tan","ate","nat","bat"]))',
      solution: 'def group_anagrams(strs):\n    groups = {}\n    for s in strs:\n        key = tuple(sorted(s))\n        groups.setdefault(key, []).append(s)\n    return list(groups.values())',
      hint: 'Use sorted string as a key. All anagrams sort to the same string.',
      testCases: [
        { input: [['eat','tea','tan','ate','nat','bat']], expected: "[['eat', 'tea', 'ate'], ['tan', 'nat'], ['bat']]", description: 'Group anagrams' },
      ],
    },
    {
      id: 'fizzbuzz-interview', title: 'FizzBuzz (Classic)', difficulty: 'Easy', type: 'interview',
      description: 'Print numbers 1 to n. For multiples of 3 print Fizz, 5 print Buzz, both print FizzBuzz.',
      starterCode: 'def fizzbuzz(n):\n    # Your code here\n    pass\n\nfor result in fizzbuzz(15):\n    print(result)',
      solution: 'def fizzbuzz(n):\n    for i in range(1, n+1):\n        if i % 15 == 0:\n            yield "FizzBuzz"\n        elif i % 3 == 0:\n            yield "Fizz"\n        elif i % 5 == 0:\n            yield "Buzz"\n        else:\n            yield str(i)',
      hint: 'Check divisibility by 15 first (both 3 and 5), then 3, then 5. Use yield for a generator.',
      testCases: [
        { input: [15], expected: '1\n2\nFizz\n4\nBuzz\nFizz\n7\n8\nFizz\nBuzz\n11\nFizz\n13\n14\nFizzBuzz', description: 'FizzBuzz 1-15' },
      ],
    },
    {
      id: 'longest-substring', title: 'Longest Substring Without Repeating', difficulty: 'Hard', type: 'interview',
      description: 'Find the length of the longest substring without repeating characters.',
      starterCode: 'def length_of_longest(s):\n    # Your code here\n    pass\n\nprint(length_of_longest("abcabcbb"))\nprint(length_of_longest("bbbbb"))\nprint(length_of_longest("pwwkew"))',
      solution: 'def length_of_longest(s):\n    seen = {}\n    start = max_len = 0\n    for i, c in enumerate(s):\n        if c in seen and seen[c] >= start:\n            start = seen[c] + 1\n        seen[c] = i\n        max_len = max(max_len, i - start + 1)\n    return max_len',
      hint: 'Sliding window with a hash map. Track the start of the current window.',
      testCases: [
        { input: ['abcabcbb'], expected: '3', description: 'abc' },
        { input: ['bbbbb'], expected: '1', description: 'All same' },
        { input: ['pwwkew'], expected: '3', description: 'wke' },
      ],
    },
    {
      id: 'reverse-linked-list', title: 'Reverse a List (Linked List Style)', difficulty: 'Easy', type: 'interview',
      description: 'Reverse a list in-place without using reverse() or slicing.',
      starterCode: 'def reverse_list(lst):\n    # Your code here\n    pass\n\nprint(reverse_list([1,2,3,4,5]))',
      solution: 'def reverse_list(lst):\n    left, right = 0, len(lst) - 1\n    while left < right:\n        lst[left], lst[right] = lst[right], lst[left]\n        left += 1\n        right -= 1\n    return lst',
      hint: 'Use two pointers: one at start, one at end. Swap and move inward.',
      testCases: [
        { input: [[1,2,3,4,5]], expected: '[5, 4, 3, 2, 1]', description: 'Odd length' },
        { input: [[1,2,3,4]], expected: '[4, 3, 2, 1]', description: 'Even length' },
        { input: [[42]], expected: '[42]', description: 'Single element' },
      ],
    },
    {
      id: 'merge-sorted', title: 'Merge Two Sorted Lists', difficulty: 'Easy', type: 'interview',
      description: 'Merge two sorted lists into one sorted list.',
      starterCode: 'def merge_sorted(a, b):\n    # Your code here\n    pass\n\nprint(merge_sorted([1,3,5], [2,4,6]))',
      solution: 'def merge_sorted(a, b):\n    result = []\n    i = j = 0\n    while i < len(a) and j < len(b):\n        if a[i] <= b[j]:\n            result.append(a[i]); i += 1\n        else:\n            result.append(b[j]); j += 1\n    result.extend(a[i:])\n    result.extend(b[j:])\n    return result',
      hint: 'Use two pointers. Compare elements and append the smaller one.',
      testCases: [
        { input: [[1,3,5],[2,4,6]], expected: '[1, 2, 3, 4, 5, 6]', description: 'Interleaved' },
        { input: [[1,2,3],[4,5,6]], expected: '[1, 2, 3, 4, 5, 6]', description: 'Sequential' },
        { input: [[],[1,2,3]], expected: '[1, 2, 3]', description: 'One empty' },
      ],
    },
    {
      id: 'first-unique', title: 'First Unique Character', difficulty: 'Medium', type: 'interview',
      description: 'Find the first non-repeating character in a string and return its index.',
      starterCode: 'def first_unique(s):\n    # Your code here\n    pass\n\nprint(first_unique("leetcode"))\nprint(first_unique("loveleetcode"))\nprint(first_unique("aabb"))',
      solution: 'def first_unique(s):\n    from collections import Counter\n    count = Counter(s)\n    for i, c in enumerate(s):\n        if count[c] == 1:\n            return i\n    return -1',
      hint: 'Count all characters first, then find the first with count == 1.',
      testCases: [
        { input: ['leetcode'], expected: '0', description: 'l is unique' },
        { input: ['loveleetcode'], expected: '2', description: 'v is unique' },
        { input: ['aabb'], expected: '-1', description: 'No unique' },
      ],
    },
    {
      id: 'product-except-self', title: 'Product Except Self', difficulty: 'Medium', type: 'interview',
      description: 'Given an array, return an array where each element is the product of all other elements.',
      starterCode: 'def product_except_self(nums):\n    # Your code here\n    pass\n\nprint(product_except_self([1,2,3,4]))',
      solution: 'def product_except_self(nums):\n    n = len(nums)\n    result = [1] * n\n    left = 1\n    for i in range(n):\n        result[i] = left\n        left *= nums[i]\n    right = 1\n    for i in range(n-1, -1, -1):\n        result[i] *= right\n        right *= nums[i]\n    return result',
      hint: 'Compute left products first, then right products. Combine them.',
      testCases: [
        { input: [[1,2,3,4]], expected: '[24, 12, 8, 6]', description: 'Basic case' },
        { input: [[2,3,4,5]], expected: '[60, 40, 30, 24]', description: 'All > 1' },
      ],
    },
    {
      id: 'coin-change', title: 'Coin Change (DP)', difficulty: 'Hard', type: 'interview',
      description: 'Find the minimum number of coins needed to make a given amount.',
      starterCode: 'def coin_change(coins, amount):\n    # Your code here\n    pass\n\nprint(coin_change([1,5,10,25], 30))\nprint(coin_change([1,3,4], 6))',
      solution: 'def coin_change(coins, amount):\n    dp = [float("inf")] * (amount + 1)\n    dp[0] = 0\n    for coin in coins:\n        for x in range(coin, amount + 1):\n            dp[x] = min(dp[x], dp[x - coin] + 1)\n    return dp[amount] if dp[amount] != float("inf") else -1',
      hint: 'Dynamic programming: dp[i] = min coins to make amount i.',
      testCases: [
        { input: [[1,5,10,25], 30], expected: '2', description: '25+5' },
        { input: [[1,3,4], 6], expected: '2', description: '3+3' },
        { input: [[2], 3], expected: '-1', description: 'Impossible' },
      ],
    },
  ];

  // ---- Learning Tracks ----
  const tracks = [
    {
      id: 'data-science', title: 'Data Science', icon: '📊',
      description: 'numpy, pandas, matplotlib — analyze and visualize data',
      topics: ['json-csv', 'list-deep-dive', 'comprehensions-advanced'],
    },
    {
      id: 'automation', title: 'Automation', icon: '🤖',
      description: 'File ops, OS, scripting — automate repetitive tasks',
      topics: ['file-handling', 'regex', 'cli-tools'],
    },
    {
      id: 'web-dev', title: 'Web Development', icon: '🌐',
      description: 'Web scraping, APIs, and data processing',
      topics: ['json-csv', 'web-scraping', 'string-formatting'],
    },
    {
      id: 'devops', title: 'DevOps', icon: '⚙️',
      description: 'CLI tools, databases — infrastructure automation',
      topics: ['cli-tools', 'database-basics', 'packaging'],
    },
    {
      id: 'ai-beginner', title: 'AI Beginner', icon: '🧠',
      description: 'Data processing and analysis for ML',
      topics: ['json-csv', 'list-deep-dive', 'algorithms'],
    },
    {
      id: 'python-mastery', title: 'Python Mastery', icon: '🏆',
      description: 'Advanced Python — from closures to metaclasses',
      topics: ['closures', 'decorators', 'metaclasses', 'descriptors', 'design-patterns'],
    },
    {
      id: 'professional', title: 'Professional Dev', icon: '💼',
      description: 'Testing, logging, packaging — production-ready Python',
      topics: ['testing', 'logging-debugging', 'packaging', 'type-hints'],
    },
  ];

  // ---- Curriculum Topics ----
  const topics = [
    // ===== BEGINNER =====
    {
      id: 'getting-started', title: 'Getting Started', icon: '🚀', level: 'beginner',
      visualExplanation: `flowchart TD
    A["Write Python Code"] --> B["Save as .py"]
    B --> C["Run: python file.py"]
    C --> D["Output on Screen"]
    A --> E["Use print()"]
    E --> F["Display text/numbers"]
    style A fill:#7c3aed,stroke:#7c3aed,color:#fff
    style B fill:#2563eb,stroke:#2563eb,color:#fff
    style C fill:#2563eb,stroke:#2563eb,color:#fff
    style D fill:#22c55e,stroke:#22c55e,color:#fff
    style E fill:#2563eb,stroke:#2563eb,color:#fff
    style F fill:#22c55e,stroke:#22c55e,color:#fff`,
      keyPoints: [
        { icon: '🖨️', title: 'print() Function', desc: 'Use print() to display output on the screen' },
        { icon: '💬', title: 'Strings', desc: 'Text in quotes: "hello" or \'hello\'' },
        { icon: '📊', title: 'Math', desc: 'Python works as a calculator: +, -, *, /, **, //, %' },
        { icon: '💭', title: 'Comments', desc: 'Use # for single-line comments' },
      ],
      lessons: [{
        title: 'Hello World & Basics',
        content: `<h1>🚀 Getting Started with Python</h1>
<p>Python is one of the most popular programming languages in the world. It's known for its <strong>simple, readable syntax</strong> that makes it perfect for beginners.</p>
<h2>Your First Program</h2>
<p>The traditional first program in any language prints "Hello, World!" to the screen:</p>
<pre><code>print("Hello, World!")</code></pre>
<p>The <code>print()</code> function outputs text to the console. You can print any text by placing it inside quotes.</p>
<h2>Comments</h2>
<pre><code># This is a single-line comment
print("Hello!")  # Inline comment</code></pre>
<h2>The print() Function</h2>
<pre><code>print("Hello", "World")          # Hello World
print("Hello", "World", sep="-") # Hello-World
print(42)
print(3 + 4)      # 7
print("Age:", 25)  # Age: 25</code></pre>
<div class="tip">Python uses indentation (spaces/tabs) to define code blocks. Standard practice is 4 spaces per indent level.</div>
<h2>Python as a Calculator</h2>
<pre><code>print(2 + 3)    # Addition: 5
print(10 - 4)   # Subtraction: 6
print(3 * 7)    # Multiplication: 21
print(15 / 4)   # Division: 3.75
print(15 // 4)  # Floor division: 3
print(15 % 4)   # Modulus: 3
print(2 ** 10)  # Power: 1024</code></pre>`,
        starterCode: '# Welcome to Python! 🐍\nprint("Hello, World!")\nprint("My name is Python Learner")\nprint(2 + 3)\nprint(10 * 5)',
      }],
      exercises: [
        { problem: 'Print your name on line 1 and your hobby on line 2.', expectedOutput: 'Tejdeep\nCoding', hint: 'Use two separate print() statements.', starterCode: 'print("Tejdeep")\nprint("Coding")', testCases: [
          { expected: 'Tejdeep\nCoding', description: 'Name and hobby on separate lines' }
        ]},
        { problem: 'Print a triangle pattern:\n*\n**\n***', expectedOutput: '*\n**\n***', hint: 'Use three print() statements with increasing *.', starterCode: 'print("*")\nprint("**")\nprint("***")', testCases: [
          { expected: '*\n**\n***', description: 'Triangle pattern' }
        ]},
        { problem: 'Print a box pattern:\n*****\n*   *\n*   *\n*****', expectedOutput: '*****\n*   *\n*   *\n*****', hint: 'Use 4 print() statements.', starterCode: 'print("*****")\nprint("*   *")\nprint("*   *")\nprint("*****")', testCases: [
          { expected: '*****\n*   *\n*   *\n*****', description: 'Box pattern' }
        ]},
      ],
    },
    {
      id: 'variables', title: 'Variables & Data Types', icon: '📦', level: 'beginner',
      lessons: [{
        title: 'Variables & Data Types',
        content: `<h1>📦 Variables & Data Types</h1>
<p>Variables are containers for storing data values. Python figures out the type automatically!</p>
<h2>Creating Variables</h2>
<pre><code>name = "Alice"         # str (string)
age = 25               # int (integer)
height = 5.7           # float (decimal)
is_student = True      # bool (boolean)</code></pre>
<h2>Naming Rules</h2>
<ul><li>Must start with a letter or underscore</li><li>Can contain letters, numbers, underscores</li><li>Case-sensitive</li><li>Cannot use Python keywords</li></ul>
<h2>Type Conversion</h2>
<pre><code>num_str = "42"
num = int(num_str)       # String to int
msg = "I am " + str(age) # Int to string</code></pre>
<div class="tip">Use f-strings: <code>f"I am {age} years old"</code></div>`,
        starterCode: 'name = "Python"\nage = 30\npi = 3.14159\nprint(f"Language: {name}")\nprint(f"Age: {age}")\nprint(f"Pi: {pi}")\nprint(type(name))\nprint(type(age))',
      }],
      exercises: [
        { problem: 'Create variables for name (str), age (int), height (float). Print each with its type.', expectedOutput: "Alice <class 'str'>\n25 <class 'int'>\n1.65 <class 'float'>", hint: 'Use type() inside print.', starterCode: 'name = "Alice"\nage = 25\nheight = 1.65\nprint(name, type(name))\nprint(age, type(age))\nprint(height, type(height))' },
        { problem: 'Convert 98.6°F to Celsius: C = (F-32) × 5/9. Print rounded to 1 decimal.', expectedOutput: '37.0', hint: 'Use round(celsius, 1).', starterCode: 'f = 98.6\nc = (f - 32) * 5/9\nprint(round(c, 1))' },
        { problem: 'Swap two variables: a="hello", b="world" → print "world hello".', expectedOutput: 'world hello', hint: 'Use a temp variable or tuple unpacking.', starterCode: 'a = "hello"\nb = "world"\na, b = b, a\nprint(a, b)' },
      ],
    },
    {
      id: 'strings', title: 'Strings', icon: '🔤', level: 'beginner',
      lessons: [{
        title: 'Working with Strings',
        content: `<h1>🔤 Strings in Python</h1>
<h2>String Indexing & Slicing</h2>
<pre><code>text = "Python"
print(text[0])    # P
print(text[-1])   # n
print(text[0:3])  # Pyt
print(text[::-1]) # nohtyP (reversed)</code></pre>
<h2>String Methods</h2>
<pre><code>msg = "  Hello, World!  "
print(msg.upper())       # HELLO, WORLD!
print(msg.strip())       # Hello, World!
csv = "apple,banana,cherry"
fruits = csv.split(",")</code></pre>
<h2>F-Strings</h2>
<pre><code>name = "Alice"
print(f"Name: {name}, Age: {age}")
print(f"Pi: {3.14159:.2f}")</code></pre>
<div class="tip">Strings are <strong>immutable</strong> — you cannot change individual characters.</div>`,
        starterCode: 'text = "Hello, Python World!"\nprint(text.upper())\nprint(text.lower())\nprint(text[7:13])\nprint(text[::-1])\nprint(f"Length: {len(text)}")',
      }],
      exercises: [
        { problem: 'Reverse the string "programming" and print it.', expectedOutput: 'gnimmargorp', hint: 'Use [::-1] slicing.', starterCode: 'text = "programming"\nprint(text[::-1])' },
        { problem: 'Count vowels (a,e,i,o,u) in "Hello World" (case-insensitive).', expectedOutput: '3', hint: 'Loop through lowercase string.', starterCode: 'text = "Hello World"\ncount = 0\nfor c in text.lower():\n    if c in "aeiou":\n        count += 1\nprint(count)' },
        { problem: 'Check if "racecar" is a palindrome (same forwards and backwards).', expectedOutput: 'True', hint: 'Compare string to its reverse: s == s[::-1]', starterCode: 's = "racecar"\nprint(s == s[::-1])' },
      ],
    },
    {
      id: 'lists', title: 'Lists', icon: '📋', level: 'beginner',
      lessons: [{
        title: 'Lists',
        content: `<h1>📋 Lists in Python</h1>
<h2>Creating & Accessing</h2>
<pre><code>fruits = ["apple", "banana", "cherry"]
print(fruits[0])     # apple
print(fruits[-1])    # cherry</code></pre>
<h2>List Methods</h2>
<pre><code>fruits.append("date")
fruits.insert(1, "blueberry")
fruits.remove("banana")
numbers = [3, 1, 4, 1, 5]
numbers.sort()</code></pre>
<h2>List Comprehensions</h2>
<pre><code>squares = [x**2 for x in range(1, 6)]
evens = [x for x in range(10) if x % 2 == 0]</code></pre>
<div class="tip">Use <code>in</code> to check membership: <code>"apple" in fruits</code></div>`,
        starterCode: 'fruits = ["apple", "banana", "cherry"]\nfruits.append("date")\nprint(fruits)\nsquares = [x**2 for x in range(1, 6)]\nprint(f"Squares: {squares}")',
      }],
      exercises: [
        { problem: 'Find max in [34,67,23,89,12,45,78] without max().', expectedOutput: '89', hint: 'Loop and track largest.', starterCode: 'nums = [34, 67, 23, 89, 12, 45, 78]\nlargest = nums[0]\nfor n in nums:\n    if n > largest:\n        largest = n\nprint(largest)' },
        { problem: 'List comprehension: squares of even numbers from 1 to 20.', expectedOutput: '[4, 16, 36, 64, 100, 144, 196, 256, 324, 400]', hint: '[x**2 for x in range(1,21) if x%2==0]', starterCode: 'result = [x**2 for x in range(1, 21) if x % 2 == 0]\nprint(result)' },
        { problem: 'Find the second largest in [34,67,23,89,12,45,78] without sorting.', expectedOutput: '78', hint: 'Track largest and second largest in one pass.', starterCode: 'nums = [34,67,23,89,12,45,78]\nlargest = second = float("-inf")\nfor n in nums:\n    if n > largest:\n        second = largest\n        largest = n\n    elif n > second:\n        second = n\nprint(second)' },
      ],
    },
    {
      id: 'tuples-sets', title: 'Tuples & Sets', icon: '🎯', level: 'beginner',
      lessons: [{
        title: 'Tuples & Sets',
        content: `<h1>🎯 Tuples & Sets</h1>
<h2>Tuples (Immutable)</h2>
<pre><code>point = (3, 4)
x, y = point          # Unpacking
a, b = b, a            # Swap!</code></pre>
<h2>Sets (Unique, Unordered)</h2>
<pre><code>nums = set([1, 2, 2, 3, 3])  # {1, 2, 3}
a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print(a | b)   # Union: {1,2,3,4,5,6}
print(a & b)   # Intersection: {3,4}</code></pre>
<div class="tip">Tuples are faster than lists and can be dictionary keys.</div>`,
        starterCode: 'point = (3, 4)\nx, y = point\nprint(f"x={x}, y={y}")\ncolors = {"red", "green", "blue", "red"}\nprint(f"Unique: {colors}")\na = {1,2,3,4}\nb = {3,4,5,6}\nprint(f"Union: {a|b}")\nprint(f"Intersection: {a&b}")',
      }],
      exercises: [
        { problem: 'Find common elements in [1,2,3,4,5] and [4,5,6,7,8] as sorted list.', expectedOutput: '[4, 5]', hint: 'Use set intersection.', starterCode: 'l1 = [1,2,3,4,5]\nl2 = [4,5,6,7,8]\nprint(sorted(set(l1) & set(l2)))' },
        { problem: 'Swap a=10, b=20 using tuple unpacking.', expectedOutput: '20 10', hint: 'a, b = b, a', starterCode: 'a = 10\nb = 20\na, b = b, a\nprint(a, b)' },
      ],
    },
    {
      id: 'dictionaries', title: 'Dictionaries', icon: '📖', level: 'beginner',
      lessons: [{
        title: 'Dictionaries',
        content: `<h1>📖 Dictionaries</h1>
<h2>Basic Operations</h2>
<pre><code>person = {"name": "Alice", "age": 30, "city": "NYC"}
print(person["name"])
print(person.get("job", "N/A"))
person["email"] = "alice@mail.com"
for k, v in person.items():
    print(f"{k}: {v}")</code></pre>
<h2>Dict Comprehension</h2>
<pre><code>squares = {x: x**2 for x in range(1, 6)}</code></pre>
<div class="tip">Use <code>dict.get(key, default)</code> to avoid KeyError.</div>`,
        starterCode: 'person = {"name": "Alice", "age": 30}\nfor k, v in person.items():\n    print(f"{k}: {v}")\nsquares = {x: x**2 for x in range(1, 6)}\nprint(squares)',
      }],
      exercises: [
        { problem: 'Count word frequency in "the cat sat on the mat the cat". Print sorted.', expectedOutput: 'cat: 2\nmat: 1\non: 1\nsat: 1\nthe: 3', hint: 'Split, loop, count with dict.', starterCode: 's = "the cat sat on the mat the cat"\nfreq = {}\nfor w in s.split():\n    freq[w] = freq.get(w, 0) + 1\nfor k in sorted(freq):\n    print(f"{k}: {freq[k]}")' },
        { problem: "Merge d1={'a':1,'b':2} and d2={'b':3,'c':4}. d2 overrides.", expectedOutput: "{'a': 1, 'b': 3, 'c': 4}", hint: 'Use {**d1, **d2}.', starterCode: "d1 = {'a': 1, 'b': 2}\nd2 = {'b': 3, 'c': 4}\nprint({**d1, **d2})" },
      ],
    },
    {
      id: 'control-flow', title: 'Control Flow', icon: '🔀', level: 'beginner',
      lessons: [{
        title: 'Control Flow',
        content: `<h1>🔀 Control Flow</h1>
<h2>if / elif / else</h2>
<pre><code>age = 18
if age < 13: print("Child")
elif age < 18: print("Teenager")
else: print("Adult")</code></pre>
<h2>Comparison & Logical Operators</h2>
<pre><code>if age >= 18 and has_id:
    print("Access granted")</code></pre>
<h2>Ternary Expression</h2>
<pre><code>status = "adult" if age >= 18 else "minor"</code></pre>
<div class="warning">Indentation is crucial in Python! Use consistent 4-space indentation.</div>`,
        starterCode: 'score = 85\nif score >= 90: grade = "A"\nelif score >= 80: grade = "B"\nelif score >= 70: grade = "C"\nelse: grade = "F"\nprint(f"Score: {score}, Grade: {grade}")',
      }],
      exercises: [
        { problem: 'Grade calculator: 90+=A, 80+=B, 70+=C, 60+=D, else F. Test score=75.', expectedOutput: 'C', hint: 'Use if/elif/else chain.', starterCode: 'score = 75\nif score >= 90: print("A")\nelif score >= 80: print("B")\nelif score >= 70: print("C")\nelif score >= 60: print("D")\nelse: print("F")' },
        { problem: 'Is 2024 a leap year? Print True or False.', expectedOutput: 'True', hint: '(year%4==0 and year%100!=0) or year%400==0', starterCode: 'year = 2024\nprint((year%4==0 and year%100!=0) or year%400==0)' },
      ],
    },
    {
      id: 'loops', title: 'Loops', icon: '🔁', level: 'beginner',
      lessons: [{
        title: 'Loops',
        content: `<h1>🔁 Loops in Python</h1>
<h2>for Loops</h2>
<pre><code>for i in range(5): print(i)       # 0,1,2,3,4
for i in range(2, 10, 2): print(i) # 2,4,6,8</code></pre>
<h2>while Loops</h2>
<pre><code>count = 0
while count < 5:
    print(count)
    count += 1</code></pre>
<h2>enumerate() & zip()</h2>
<pre><code>fruits = ["apple", "banana"]
for i, f in enumerate(fruits): print(f"{i}: {f}")
for n, a in zip(["Alice", "Bob"], [25, 30]): print(f"{n} is {a}")</code></pre>
<h2>break, continue, pass</h2>
<pre><code>for i in range(10):
    if i == 5: break
    if i == 3: continue
    print(i)</code></pre>
<div class="tip">Avoid infinite loops! Ensure your while condition will eventually become False.</div>`,
        starterCode: 'for i in range(1, 11):\n    print(i, end=" ")\nprint()\nn = 5\nwhile n > 0:\n    print(n, end=" ")\n    n -= 1\nprint("Go!")',
      }],
      exercises: [
        { problem: 'Print multiplication table for 5 (5x1=5 through 5x10=50).', expectedOutput: '5 x 1 = 5\n5 x 2 = 10\n5 x 3 = 15\n5 x 4 = 20\n5 x 5 = 25\n5 x 6 = 30\n5 x 7 = 35\n5 x 8 = 40\n5 x 9 = 45\n5 x 10 = 50', hint: 'for i in range(1,11): print(f"5 x {i} = {5*i}")', starterCode: 'for i in range(1, 11):\n    print(f"5 x {i} = {5*i}")' },
        { problem: 'FizzBuzz 1-20: multiples of 3=Fizz, 5=Buzz, both=FizzBuzz, else number.', expectedOutput: '1\n2\nFizz\n4\nBuzz\nFizz\n7\n8\nFizz\nBuzz\n11\nFizz\n13\n14\nFizzBuzz\n16\n17\nFizz\n19\nBuzz', hint: 'Check %15 first, then %3, then %5.', starterCode: 'for i in range(1, 21):\n    if i%15==0: print("FizzBuzz")\n    elif i%3==0: print("Fizz")\n    elif i%5==0: print("Buzz")\n    else: print(i)' },
        { problem: 'Sum of 1 to 100 using a loop. Print result.', expectedOutput: '5050', hint: 'Use a for loop with range(1, 101).', starterCode: 'total = 0\nfor i in range(1, 101):\n    total += i\nprint(total)' },
      ],
    },
    {
      id: 'functions', title: 'Functions', icon: '⚡', level: 'beginner',
      lessons: [{
        title: 'Functions',
        content: `<h1>⚡ Functions</h1>
<h2>Defining Functions</h2>
<pre><code>def greet(name):
    return f"Hello, {name}!"
print(greet("Alice"))</code></pre>
<h2>Parameters</h2>
<pre><code>def power(base, exp=2):
    return base ** exp
print(power(3))      # 9
print(power(2, 10))  # 1024</code></pre>
<h2>*args and **kwargs</h2>
<pre><code>def add_all(*args): return sum(args)
def info(**kwargs):
    for k, v in kwargs.items(): print(f"{k}: {v}")</code></pre>
<h2>Lambda Functions</h2>
<pre><code>square = lambda x: x ** 2
nums = sorted([3,1,4], key=lambda x: -x)</code></pre>
<div class="tip">Always add docstrings to describe your functions!</div>`,
        starterCode: 'def factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n-1)\nfor i in range(1, 8):\n    print(f"{i}! = {factorial(i)}")',
      }],
      exercises: [
        { problem: 'Write recursive factorial function. Print factorial(6).', expectedOutput: '720', hint: 'Base: n<=1 return 1. Recursive: n*factorial(n-1).', starterCode: 'def factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n-1)\nprint(factorial(6))' },
        { problem: 'Function returning only even numbers from [1,2,3,4,5,6,7,8,9,10].', expectedOutput: '[2, 4, 6, 8, 10]', hint: 'Use list comprehension with % 2 == 0.', starterCode: 'def get_evens(nums):\n    return [n for n in nums if n%2==0]\nprint(get_evens([1,2,3,4,5,6,7,8,9,10]))' },
      ],
    },
    {
      id: 'input-validation', title: 'Input & Validation', icon: '⌨️', level: 'beginner',
      lessons: [{
        title: 'User Input & Validation',
        content: `<h1>⌨️ User Input & Validation</h1>
<p>Learn to safely read and validate user input.</p>
<h2>The input() Function</h2>
<pre><code>name = input("Enter your name: ")
age = int(input("Enter your age: "))
print(f"Hello {name}, you are {age}")</code></pre>
<h2>Input Validation Loop</h2>
<pre><code>while True:
    try:
        age = int(input("Age: "))
        if 0 <= age <= 120:
            break
        print("Enter a valid age (0-120)")
    except ValueError:
        print("Please enter a number!")
print(f"Age: {age}")</code></pre>
<h2>String Validation</h2>
<pre><code>email = input("Email: ")
if "@" in email and "." in email:
    print("Valid email format")
else:
    print("Invalid email")</code></pre>
<div class="warning">Always validate user input — never trust it!</div>
<div class="tip">Use try/except around int() and float() to handle non-numeric input gracefully.</div>`,
        starterCode: 'while True:\n    try:\n        num = int(input("Enter a number 1-10: "))\n        if 1 <= num <= 10:\n            print(f"Valid! You entered {num}")\n            break\n        print("Out of range!")\n    except ValueError:\n        print("That is not a number!")',
      }],
      exercises: [
        { problem: 'Ask for age until valid (0-120). Print "Valid age: X".', expectedOutput: 'Valid age: 25', hint: 'Use while True with try/except.', starterCode: 'while True:\n    try:\n        age = int(input("Age: "))\n        if 0 <= age <= 120:\n            print(f"Valid age: {age}")\n            break\n        print("Invalid range")\n    except ValueError:\n        print("Not a number")' },
        { problem: 'Check if input string is a valid Python identifier (letters, digits, _, no digit start).', expectedOutput: 'Valid: True', hint: 'Use str.isidentifier() or check first char + rest.', starterCode: 'name = "my_var_1"\nvalid = name.isidentifier()\nprint(f"Valid: {valid}")' },
      ],
    },
    {
      id: 'string-formatting', title: 'String Formatting', icon: '🎨', level: 'beginner',
      lessons: [{
        title: 'String Formatting Deep Dive',
        content: `<h1>🎨 String Formatting</h1>
<p>Python offers multiple ways to format strings.</p>
<h2>f-strings (Recommended)</h2>
<pre><code>name, age = "Alice", 30
print(f"Name: {name}, Age: {age}")
print(f"Next year: {age + 1}")
print(f"Pi: {3.14159:.2f}")  # 3.14</code></pre>
<h2>Format Specifiers</h2>
<pre><code># Alignment
print(f"{'left':<10}|")   # left      |
print(f"{'right':>10}|")  #      right|
print(f"{'center':^10}|") #   center  |

# Numbers
print(f"{1234567:,}")     # 1,234,567
print(f"{0.25:.0%}")      # 25%
print(f"{42:05d}")        # 00042</code></pre>
<h2>.format() Method</h2>
<pre><code>"{} + {} = {}".format(1, 2, 3)
"{0} {1} {0}".format("hello", "world")
"{name} is {age}".format(name="Bob", age=25)</code></pre>
<div class="tip">f-strings are the fastest and most readable. Use them for Python 3.6+.</div>`,
        starterCode: 'name = "Python"\nversion = 3.12\nprint(f"{name} v{version}")\nprint(f"Pi = {3.14159:.3f}")\nprint(f\'{"Item":<15}{"Price":>10}\')\nprint(f\'{"Apple":<15}{0.50:>10.2f}\')\nprint(f\'{"Banana":<15}{0.30:>10.2f}\')',
      }],
      exercises: [
        { problem: 'Format a receipt: items=["Apple","Bread","Milk"], prices=[1.50,2.30,3.10]. Print aligned columns with total.', expectedOutput: 'Apple          1.50\nBread          2.30\nMilk           3.10\nTotal: 6.90', hint: 'Use f-string with <10 and >8.2f format.', starterCode: 'items = ["Apple", "Bread", "Milk"]\nprices = [1.50, 2.30, 3.10]\nfor i, p in zip(items, prices):\n    print(f"{i:<12}{p:>8.2f}")\nprint(f"Total: {sum(prices):.2f}")' },
        { problem: 'Print a formatted table of squares: n=1..5, show n, n², n³ right-aligned.', expectedOutput: ' 1   1   1\n 2   4   8\n 3   9  27\n 4  16  64\n 5  25 125', hint: 'Use f"{n:>2} {n**2:>3} {n**3:>4}"', starterCode: 'for n in range(1, 6):\n    print(f"{n:>2} {n**2:>3} {n**3:>4}")' },
      ],
    },
    {
      id: 'list-deep-dive', title: 'Lists Deep Dive', icon: '📋', level: 'beginner',
      lessons: [{
        title: 'Lists Deep Dive',
        content: `<h1>📋 Lists Deep Dive</h1>
<h2>List Operations</h2>
<pre><code>nums = [3, 1, 4, 1, 5, 9, 2, 6]
nums.sort()           # In-place sort
sorted_nums = sorted(nums, reverse=True)  # New list
nums.reverse()        # In-place reverse
print(nums.count(1))  # Count occurrences
print(nums.index(5))  # Find index</code></pre>
<h2>List as Stack & Queue</h2>
<pre><code># Stack (LIFO)
stack = []
stack.append(1)  # push
stack.append(2)
print(stack.pop())  # 2

# Queue (FIFO) — use deque
from collections import deque
q = deque()
q.append(1)
q.append(2)
print(q.popleft())  # 1</code></pre>
<h2>Nested Lists (2D Arrays)</h2>
<pre><code>matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(matrix[1][2])  # 6
for row in matrix:
    for val in row:
        print(val, end=" ")
    print()</code></pre>
<div class="tip">Use deque from collections for efficient queue operations. Lists are slow for pop(0).</div>`,
        starterCode: 'nums = [5, 2, 8, 1, 9, 3]\nprint(f"Sorted: {sorted(nums)}")\nprint(f"Reversed: {sorted(nums, reverse=True)}")\nprint(f"Max: {max(nums)}, Min: {min(nums)}, Sum: {sum(nums)}")\nprint(f"Average: {sum(nums)/len(nums):.2f}")\n\n# Stack demo\nstack = []\nfor i in range(1, 4):\n    stack.append(i)\nprint(f"Stack: {stack}")\nprint(f"Popped: {stack.pop()}")',
      }],
      exercises: [
        { problem: 'Remove duplicates from [1,2,2,3,4,4,5] preserving order.', expectedOutput: '[1, 2, 3, 4, 5]', hint: 'Use a loop with "if x not in result" check.', starterCode: 'nums = [1,2,2,3,4,4,5]\nresult = []\nfor n in nums:\n    if n not in result:\n        result.append(n)\nprint(result)' },
        { problem: 'Rotate list [1,2,3,4,5] left by 2 positions → [3,4,5,1,2].', expectedOutput: '[3, 4, 5, 1, 2]', hint: 'Use slicing: lst[k:] + lst[:k]', starterCode: 'lst = [1,2,3,4,5]\nk = 2\nrotated = lst[k:] + lst[:k]\nprint(rotated)' },
      ],
    },

    // ===== INTERMEDIATE =====
    {
      id: 'oop', title: 'Object-Oriented Programming', icon: '🏗️', level: 'intermediate',
      lessons: [{
        title: 'Object-Oriented Programming',
        content: `<h1>🏗️ Object-Oriented Programming</h1>
<h2>Classes & Objects</h2>
<pre><code>class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def bark(self):
        return f"{self.name} says Woof!"
    def __str__(self):
        return f"{self.name} ({self.age}y)"
buddy = Dog("Buddy", 5)
print(buddy.bark())</code></pre>
<h2>Inheritance</h2>
<pre><code>class Animal:
    def __init__(self, name): self.name = name
    def speak(self): return "..."
class Cat(Animal):
    def speak(self): return f"{self.name} says Meow!"
class Dog(Animal):
    def speak(self): return f"{self.name} says Woof!"</code></pre>
<h2>Encapsulation</h2>
<pre><code>class BankAccount:
    def __init__(self, balance=0):
        self.__balance = balance
    def deposit(self, amt): self.__balance += amt
    def get_balance(self): return self.__balance</code></pre>
<div class="tip">Use __str__ for user-friendly output and __repr__ for debug output.</div>`,
        starterCode: 'class Rectangle:\n    def __init__(self, w, h):\n        self.w = w\n        self.h = h\n    def area(self):\n        return self.w * self.h\n    def __str__(self):\n        return f"Rect({self.w}x{self.h})"\nr = Rectangle(5, 3)\nprint(r)\nprint(f"Area: {r.area()}")',
      }],
      exercises: [
        { problem: 'BankAccount: owner, balance=0, deposit(), withdraw() with overdraft check, __str__. Test: Alice, 1000, deposit 500, withdraw 200.', expectedOutput: 'Alice: $1300', hint: 'Track balance, check in withdraw.', starterCode: 'class BankAccount:\n    def __init__(self, owner, balance=0):\n        self.owner = owner\n        self.balance = balance\n    def deposit(self, amt): self.balance += amt\n    def withdraw(self, amt):\n        if amt > self.balance: print("Insufficient funds")\n        else: self.balance -= amt\n    def __str__(self): return f"{self.owner}: ${self.balance}"\nacc = BankAccount("Alice", 1000)\nacc.deposit(500)\nacc.withdraw(200)\nprint(acc)' },
        { problem: 'Shape hierarchy: Circle(r=5) area and Square(side=4) area.', expectedOutput: 'Circle area: 78.54\nSquare area: 16', hint: 'Import math. Override area() in each subclass.', starterCode: 'import math\nclass Shape:\n    def area(self): return 0\nclass Circle(Shape):\n    def __init__(self, r): self.r = r\n    def area(self): return round(math.pi*self.r**2, 2)\nclass Square(Shape):\n    def __init__(self, s): self.s = s\n    def area(self): return self.s**2\nprint(f"Circle area: {Circle(5).area()}")\nprint(f"Square area: {Square(4).area()}")' },
      ],
    },
    {
      id: 'file-handling', title: 'File Handling', icon: '📁', level: 'intermediate',
      lessons: [{
        title: 'File Handling',
        content: `<h1>📁 File Handling</h1>
<h2>The with Statement</h2>
<pre><code># Writing
with open("example.txt", "w") as f:
    f.write("Hello, World!\\n")

# Reading
with open("example.txt", "r") as f:
    content = f.read()

# Read line by line
with open("example.txt") as f:
    for line in f:
        print(line.strip())</code></pre>
<h2>File Modes</h2>
<ul><li>'r' — Read (default)</li><li>'w' — Write (overwrites)</li><li>'a' — Append</li><li>'r+' — Read & Write</li></ul>
<div class="tip">Always use <code>with</code> — it auto-closes files even on errors.</div>`,
        starterCode: 'lines = ["Hello, World!", "Python is great!", "File handling is easy!"]\nprint("Writing to file...")\nfor line in lines:\n    print(f"  > {line}")\nprint("\\nReading from file...")\nfor i, line in enumerate(lines, 1):\n    print(f"  Line {i}: {line}")',
      }],
      exercises: [
        { problem: "Parse CSV data: ['Name,Age,City','Alice,30,NYC','Bob,25,London']. Print formatted.", expectedOutput: 'Name: Alice, Age: 30, City: NYC\nName: Bob, Age: 25, City: London', hint: 'Split each row by comma, skip header.', starterCode: "data = ['Name,Age,City','Alice,30,NYC','Bob,25,London']\nfor row in data[1:]:\n    n,a,c = row.split(',')\n    print(f'Name: {n}, Age: {a}, City: {c}')" },
      ],
    },
    {
      id: 'error-handling', title: 'Error Handling', icon: '🛡️', level: 'intermediate',
      lessons: [{
        title: 'Error Handling',
        content: `<h1>🛡️ Error Handling</h1>
<h2>try / except</h2>
<pre><code>try:
    result = 10 / 0
except ZeroDivisionError:
    print("Cannot divide by zero!")</code></pre>
<h2>Multiple Except & Finally</h2>
<pre><code>def safe_divide(a, b):
    try: return a / b
    except ZeroDivisionError: return "Division by zero"
    except TypeError: return "Invalid types"
    finally: print("Done!")</code></pre>
<h2>Raising & Custom Exceptions</h2>
<pre><code>def set_age(age):
    if age < 0:
        raise ValueError("Age cannot be negative!")
class CustomError(Exception):
    pass</code></pre>
<div class="tip">Catch specific exceptions, not bare <code>except:</code>.</div>`,
        starterCode: 'def safe_divide(a, b):\n    try: return a / b\n    except ZeroDivisionError: return "Cannot divide by zero!"\n    except TypeError: return "Invalid types!"\nprint(safe_divide(10, 3))\nprint(safe_divide(10, 0))\nprint(safe_divide("a", 2))',
      }],
      exercises: [
        { problem: "safe_divide: handle ZeroDivisionError and TypeError. Test (10,2), (10,0), ('a',2).", expectedOutput: '5.0\nError: Division by zero\nError: Invalid types', hint: 'Return error message strings from except blocks.', starterCode: "def safe_divide(a, b):\n    try: return a / b\n    except ZeroDivisionError: return 'Error: Division by zero'\n    except TypeError: return 'Error: Invalid types'\nprint(safe_divide(10, 2))\nprint(safe_divide(10, 0))\nprint(safe_divide('a', 2))" },
        { problem: 'Custom NegativeNumberError for sqrt_safe(-4).', expectedOutput: 'Error: Cannot take square root of negative number: -4', hint: 'Define exception class, raise it, catch it.', starterCode: 'class NegativeNumberError(Exception): pass\ndef sqrt_safe(n):\n    if n < 0: raise NegativeNumberError(f"Cannot take square root of negative number: {n}")\n    return n**0.5\ntry: sqrt_safe(-4)\nexcept NegativeNumberError as e: print(f"Error: {e}")' },
      ],
    },
    {
      id: 'modules', title: 'Modules & Packages', icon: '📦', level: 'intermediate',
      lessons: [{
        title: 'Modules & Packages',
        content: `<h1>📦 Modules & Packages</h1>
<h2>Importing</h2>
<pre><code>import math
print(math.pi)
from math import pi, sqrt
import math as m</code></pre>
<h2>Common Modules</h2>
<pre><code>import random
print(random.randint(1, 100))
import json
data = {"name": "Alice"}
print(json.dumps(data))</code></pre>
<h2>Math Module</h2>
<pre><code>import math
print(math.ceil(4.2))     # 5
print(math.factorial(6))  # 720
print(math.gcd(12, 8))    # 4</code></pre>
<div class="tip">Use <code>dir(module)</code> to explore available functions.</div>`,
        starterCode: 'import math\nimport random\nprint(f"Pi: {math.pi:.4f}")\nprint(f"sqrt(144): {math.sqrt(144)}")\nprint(f"5!: {math.factorial(5)}")\nprint(f"Random 1-100: {random.randint(1,100)}")',
      }],
      exercises: [
        { problem: 'Use math: circle area r=7 (2 dec), factorial(8), gcd(48,18).', expectedOutput: '153.94\n40320\n6', hint: 'math.pi, math.factorial, math.gcd', starterCode: 'import math\nprint(round(math.pi*7**2, 2))\nprint(math.factorial(8))\nprint(math.gcd(48, 18))' },
        { problem: 'random.seed(42), print 5 random ints 1-50.', expectedOutput: '40\n8\n32\n6\n47', hint: 'random.seed(42) then loop.', starterCode: 'import random\nrandom.seed(42)\nfor _ in range(5):\n    print(random.randint(1, 50))' },
      ],
    },

    // ===== NEW INTERMEDIATE TOPICS =====
    {
      id: 'recursion', title: 'Recursion', icon: '🔄', level: 'intermediate',
      lessons: [{
        title: 'Recursion Deep Dive',
        content: `<h1>🔄 Recursion</h1>
<p>A function that calls itself. Every recursive function needs a <strong>base case</strong> to stop.</p>
<h2>Basic Recursion</h2>
<pre><code>def factorial(n):
    if n <= 1: return 1        # base case
    return n * factorial(n-1)  # recursive case
print(factorial(5))  # 120</code></pre>
<h2>Fibonacci</h2>
<pre><code>def fib(n):
    if n <= 1: return n
    return fib(n-1) + fib(n-2)
for i in range(10): print(fib(i), end=" ")
# 0 1 1 2 3 5 8 13 21 34</code></pre>
<h2>Memoization</h2>
<pre><code>from functools import lru_cache
@lru_cache(maxsize=None)
def fib_fast(n):
    if n <= 1: return n
    return fib_fast(n-1) + fib_fast(n-2)
print(fib_fast(100))  # Instant!</code></pre>
<h2>Recursive Patterns</h2>
<pre><code>def reverse(s):
    if len(s) <= 1: return s
    return reverse(s[1:]) + s[0]

def is_palindrome(s):
    if len(s) <= 1: return True
    if s[0] != s[-1]: return False
    return is_palindrome(s[1:-1])</code></pre>
<div class="warning">Python has a default recursion limit of 1000. Use <code>sys.setrecursionlimit()</code> carefully.</div>
<div class="tip">Every recursive solution can be converted to iterative. Recursion is elegant; iteration is often faster.</div>`,
        starterCode: 'def factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n-1)\n\nfor i in range(1, 8):\n    print(f"{i}! = {factorial(i)}")\n\ndef reverse(s):\n    if len(s) <= 1: return s\n    return reverse(s[1:]) + s[0]\n\nprint(f\'"hello" reversed: {reverse("hello")}\')',
      }],
      exercises: [
        { problem: 'Recursive sum of digits: sum_digits(12345) → 15', expectedOutput: '15', hint: 'n%10 + sum_digits(n//10), base: n<10 return n', starterCode: 'def sum_digits(n):\n    if n < 10: return n\n    return n % 10 + sum_digits(n // 10)\nprint(sum_digits(12345))' },
        { problem: 'Recursive power: power(2,10) → 1024', expectedOutput: '1024', hint: 'power(b,0)=1, if even: power(b*b, e//2), else: b*power(b,e-1)', starterCode: 'def power(b, e):\n    if e == 0: return 1\n    if e % 2 == 0: return power(b*b, e//2)\n    return b * power(b, e-1)\nprint(power(2, 10))' },
        { problem: 'Tower of Hanoi: print moves for n=3 disks.', expectedOutput: 'Move disk 1 from A to C\nMove disk 2 from A to B\nMove disk 1 from C to B\nMove disk 3 from A to C\nMove disk 1 from B to A\nMove disk 2 from B to C\nMove disk 1 from A to C', hint: 'Move n-1 disks to auxiliary, move nth to target, move n-1 to target.', starterCode: 'def hanoi(n, src="A", aux="B", tgt="C"):\n    if n == 0: return\n    hanoi(n-1, src, tgt, aux)\n    print(f"Move disk {n} from {src} to {tgt}")\n    hanoi(n-1, aux, src, tgt)\nhanoi(3)' },
      ],
    },
    {
      id: 'comprehensions-advanced', title: 'Advanced Comprehensions', icon: '🧠', level: 'intermediate',
      lessons: [{
        title: 'Advanced Comprehensions & Functional Tools',
        content: `<h1>🧠 Advanced Comprehensions & Functional Tools</h1>
<h2>Nested Comprehensions</h2>
<pre><code># Flatten nested list
matrix = [[1,2,3],[4,5,6],[7,8,9]]
flat = [x for row in matrix for x in row]
print(flat)  # [1,2,3,4,5,6,7,8,9]

# Transpose
transposed = [[row[i] for row in matrix] for i in range(3)]</code></pre>
<h2>Dict & Set Comprehensions</h2>
<pre><code>word = "hello"
freq = {c: word.count(c) for c in set(word)}
print(freq)  # {'h':1, 'e':1, 'l':2, 'o':1}

evens = {x for x in range(20) if x % 2 == 0}</code></pre>
<h2>map, filter, reduce</h2>
<pre><code>from functools import reduce

nums = [1, 2, 3, 4, 5]
squares = list(map(lambda x: x**2, nums))
evens = list(filter(lambda x: x%2==0, nums))
total = reduce(lambda a, b: a+b, nums)

# Equivalent with comprehensions:
squares2 = [x**2 for x in nums]
evens2 = [x for x in nums if x%2==0]</code></pre>
<h2>Generator Expressions (Lazy)</h2>
<pre><code># Generator — doesn't create full list in memory
big_squares = (x**2 for x in range(1000000))
print(sum(x**2 for x in range(100)))  # 328350</code></pre>
<div class="tip">Comprehensions are faster than equivalent for-loops because they're optimized at C level.</div>`,
        starterCode: 'matrix = [[1,2,3],[4,5,6],[7,8,9]]\nflat = [x for row in matrix for x in row]\nprint(f"Flat: {flat}")\n\ntransposed = [[row[i] for row in matrix] for i in range(3)]\nprint(f"Transposed: {transposed}")\n\nfrom functools import reduce\nnums = [1,2,3,4,5]\nprint(f"Sum via reduce: {reduce(lambda a,b: a+b, nums)}")\nprint(f"Squares: {list(map(lambda x: x**2, nums))}")',
      }],
      exercises: [
        { problem: 'Flatten [[1,2],[3,4],[5,6]] using nested comprehension.', expectedOutput: '[1, 2, 3, 4, 5, 6]', hint: '[x for sub in nested for x in sub]', starterCode: 'nested = [[1,2],[3,4],[5,6]]\nflat = [x for sub in nested for x in sub]\nprint(flat)' },
        { problem: 'Use filter+lambda to get words > 3 chars from ["hi","hello","hey","world"].', expectedOutput: "['hello', 'world']", hint: 'filter(lambda w: len(w)>3, words)', starterCode: 'words = ["hi","hello","hey","world"]\nresult = list(filter(lambda w: len(w)>3, words))\nprint(result)' },
        { problem: 'Dict comprehension: {x: x**3 for x in range(1,6)}', expectedOutput: '{1: 1, 2: 8, 3: 27, 4: 64, 5: 125}', hint: '{key: value for item in iterable}', starterCode: 'cubes = {x: x**3 for x in range(1, 6)}\nprint(cubes)' },
      ],
    },
    {
      id: 'iterators-generators', title: 'Iterators & Generators', icon: '⚙️', level: 'intermediate',
      lessons: [{
        title: 'Iterators & Generators',
        content: `<h1>⚙️ Iterators & Generators</h1>
<h2>Iterator Protocol</h2>
<pre><code>class CountDown:
    def __init__(self, start):
        self.current = start
    def __iter__(self):
        return self
    def __next__(self):
        if self.current <= 0:
            raise StopIteration
        self.current -= 1
        return self.current + 1

for n in CountDown(5):
    print(n, end=" ")  # 5 4 3 2 1</code></pre>
<h2>Generators with yield</h2>
<pre><code>def fibonacci():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

fib = fibonacci()
for _ in range(10):
    print(next(fib), end=" ")
# 0 1 1 2 3 5 8 13 21 34</code></pre>
<h2>Generator Pipelines</h2>
<pre><code>def read_lines(text):
    for line in text.split("\\n"):
        yield line.strip()

def filter_comments(lines):
    for line in lines:
        if not line.startswith("#"):
            yield line

def parse_values(lines):
    for line in lines:
        yield int(line)

# Pipeline
data = "10\\n# comment\\n20\\n30"
total = sum(parse_values(filter_comments(read_lines(data))))
print(total)  # 60</code></pre>
<h2>yield from</h2>
<pre><code>def chain(*iterables):
    for it in iterables:
        yield from it

print(list(chain([1,2], [3,4], [5,6])))
# [1, 2, 3, 4, 5, 6]</code></pre>
<div class="tip">Generators are memory-efficient — they produce values one at a time instead of storing entire sequences.</div>`,
        starterCode: 'def countdown(n):\n    while n > 0:\n        yield n\n        n -= 1\n\nfor val in countdown(5):\n    print(val, end=" ")\nprint()\n\ndef fibonacci(limit):\n    a, b = 0, 1\n    while a < limit:\n        yield a\n        a, b = b, a + b\n\nprint(list(fibonacci(50)))',
      }],
      exercises: [
        { problem: 'Generator: primes up to 30 using yield.', expectedOutput: '[2, 3, 5, 7, 11, 13, 17, 19, 23, 29]', hint: 'Check divisibility up to sqrt(n).', starterCode: 'def primes(limit):\n    for n in range(2, limit+1):\n        if all(n % i != 0 for i in range(2, int(n**0.5)+1)):\n            yield n\nprint(list(primes(30)))' },
        { problem: 'Generator: infinite counter starting at step, incrementing by step.', expectedOutput: '5 10 15 20 25', hint: 'while True: yield current; current += step', starterCode: 'def counter(start, step):\n    current = start\n    while True:\n        yield current\n        current += step\n\nc = counter(5, 5)\nfor _ in range(5):\n    print(next(c), end=" ")' },
      ],
    },
    {
      id: 'regex', title: 'Regular Expressions', icon: '🔍', level: 'intermediate',
      lessons: [{
        title: 'Regular Expressions',
        content: `<h1>🔍 Regular Expressions</h1>
<p>Regex is a powerful pattern-matching language built into Python via the <code>re</code> module.</p>
<h2>Basic Patterns</h2>
<pre><code>import re
text = "My email is alice@example.com"
match = re.search(r'\\w+@\\w+\\.\\w+', text)
if match:
    print(match.group())  # alice@example.com</code></pre>
<h2>Common Functions</h2>
<pre><code>re.match(r'\\d+', '123abc')    # Match at start
re.search(r'\\d+', 'abc123')   # Search anywhere
re.findall(r'\\d+', 'a1b2c3')  # ['1', '2', '3']
re.sub(r'\\d+', '#', 'a1b2c3') # 'a#b#c#'</code></pre>
<h2>Groups & Named Groups</h2>
<pre><code>text = "John: 30"
m = re.search(r'(?P<name>\\w+): (?P<age>\\d+)', text)
print(m.group('name'))  # John
print(m.group('age'))   # 30</code></pre>
<h2>Common Patterns</h2>
<pre><code>email = r'[\\w.-]+@[\\w.-]+\\.\\w+'
phone = r'\\d{3}-\\d{3}-\\d{4}'
url = r'https?://[\\w./]+'</code></pre>
<div class="tip">Use raw strings (r'...') for regex patterns to avoid backslash escaping issues.</div>`,
        starterCode: 'import re\n\ntext = "Contact: alice@email.com, bob@test.org"\nemails = re.findall(r\'[\\w.-]+@[\\w.-]+\\.\\w+\', text)\nprint(f"Emails found: {emails}")\n\n# Validate phone\nphone = "555-123-4567"\nif re.match(r\'\\d{3}-\\d{3}-\\d{4}$\', phone):\n    print(f"Valid phone: {phone}")\n\n# Replace\nresult = re.sub(r\'\\d+\', \'X\', "Room 101, Floor 3")\nprint(result)',
      }],
      exercises: [
        { problem: 'Extract all numbers from "I have 3 cats, 2 dogs, and 12 fish".', expectedOutput: "['3', '2', '12']", hint: "Use re.findall(r\'\\d+\', text)", starterCode: 'import re\ntext = "I have 3 cats, 2 dogs, and 12 fish"\nnumbers = re.findall(r\'\\d+\', text)\nprint(numbers)' },
        { problem: 'Validate email format: must have @ and domain with dot. Test "user@domain.com" and "bad@email".', expectedOutput: 'user@domain.com: Valid\nbad@email: Invalid', hint: "Use re.match with pattern r'[\\w.-]+@[\\w.-]+\\.\\w+$'", starterCode: 'import re\nemails = ["user@domain.com", "bad@email"]\nfor e in emails:\n    if re.match(r\'[\\w.-]+@[\\w.-]+\\.\\w+$\', e):\n        print(f"{e}: Valid")\n    else:\n        print(f"{e}: Invalid")' },
        { problem: 'Extract domain from URLs: "https://google.com/search" → "google.com".', expectedOutput: 'google.com', hint: "Use re.search with r\'https?://([\\w./]+)\' and .group(1)", starterCode: 'import re\nurl = "https://google.com/search"\nm = re.search(r\'https?://([\\w./]+)\', url)\nif m:\n    print(m.group(1).split(\'/\')[0])' },
      ],
    },
    {
      id: 'json-csv', title: 'JSON & CSV Processing', icon: '📊', level: 'intermediate',
      lessons: [{
        title: 'JSON & CSV Processing',
        content: `<h1>📊 JSON & CSV Processing</h1>
<h2>JSON (JavaScript Object Notation)</h2>
<pre><code>import json

# Python dict → JSON string
data = {"name": "Alice", "age": 30, "skills": ["Python", "JS"]}
json_str = json.dumps(data, indent=2)
print(json_str)

# JSON string → Python dict
parsed = json.loads(json_str)
print(parsed["name"])  # Alice</code></pre>
<h2>CSV (Comma-Separated Values)</h2>
<pre><code>import csv

# Writing CSV
with open("data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Name", "Age", "City"])
    writer.writerow(["Alice", 30, "NYC"])
    writer.writerow(["Bob", 25, "LA"])

# Reading CSV
with open("data.csv") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(f"{row['Name']} is {row['Age']}")</code></pre>
<h2>JSON from API Response</h2>
<pre><code>import json
response = '{"users": [{"name": "Alice"}, {"name": "Bob"}]}'
data = json.loads(response)
for user in data["users"]:
    print(user["name"])</code></pre>
<div class="tip">Use json.dumps with indent=2 for pretty-printing. Use csv.DictReader for named column access.</div>`,
        starterCode: 'import json\n\n# JSON encode/decode\nstudent = {"name": "Alice", "grade": "A", "scores": [95, 88, 92]}\njson_str = json.dumps(student, indent=2)\nprint(json_str)\n\nparsed = json.loads(json_str)\nprint(f"Average: {sum(parsed[\'scores\'])/len(parsed[\'scores\']):.1f}")\n\n# CSV processing\nimport csv\ndata = [["Name", "Score"], ["Alice", 95], ["Bob", 87], ["Carol", 92]]\nwith open("scores.csv", "w", newline="") as f:\n    csv.writer(f).writerows(data)\nwith open("scores.csv") as f:\n    for row in csv.DictReader(f):\n        print(f"{row[\'Name\']}: {row[\'Score\']}")',
      }],
      exercises: [
        { problem: 'Parse JSON \'{"products":[{"name":"A","price":10},{"name":"B","price":20}]}\'. Print total price.', expectedOutput: 'Total: 30', hint: 'json.loads then sum item["price"] for each.', starterCode: 'import json\ndata = \'{"products":[{"name":"A","price":10},{"name":"B","price":20}]}\'\nparsed = json.loads(data)\ntotal = sum(p["price"] for p in parsed["products"])\nprint(f"Total: {total}")' },
        { problem: 'Read CSV rows as dicts: "Name,Score\\nAlice,95\\nBob,87". Print names with score >= 90.', expectedOutput: 'Alice: 95', hint: 'Use csv.DictReader with io.StringIO.', starterCode: 'import csv, io\ndata = "Name,Score\\nAlice,95\\nBob,87\\nCarol,92"\nreader = csv.DictReader(io.StringIO(data))\nfor row in reader:\n    if int(row["Score"]) >= 90:\n        print(f"{row[\'Name\']}: {row[\'Score\']}")' },
      ],
    },
    {
      id: 'functional', title: 'Functional Programming', icon: 'λ', level: 'intermediate',
      lessons: [{
        title: 'Functional Programming',
        content: `<h1>λ Functional Programming</h1>
<p>Python supports functional programming patterns alongside OOP.</p>
<h2>map, filter, reduce</h2>
<pre><code>from functools import reduce

nums = [1, 2, 3, 4, 5]
squares = list(map(lambda x: x**2, nums))
evens = list(filter(lambda x: x % 2 == 0, nums))
total = reduce(lambda a, b: a + b, nums)</code></pre>
<h2>functools Tools</h2>
<pre><code>from functools import partial, lru_cache, reduce

# Partial application
def power(base, exp): return base ** exp
square = partial(power, exp=2)
cube = partial(power, exp=3)

# Memoization
@lru_cache(maxsize=None)
def fib(n):
    if n <= 1: return n
    return fib(n-1) + fib(n-2)</code></pre>
<h2>operator Module</h2>
<pre><code>from functools import reduce
import operator

nums = [1, 2, 3, 4, 5]
print(reduce(operator.mul, nums))  # 120 (factorial)
print(list(map(operator.itemgetter(0), [(1,2),(3,4)])))  # [1, 3]</code></pre>
<div class="tip">Prefer comprehensions over map/filter for readability. Use reduce for aggregations.</div>`,
        starterCode: 'from functools import reduce, partial, lru_cache\nimport operator\n\nnums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]\nprint(f"Squares: {list(map(lambda x: x**2, nums))}")\nprint(f"Evens: {list(filter(lambda x: x%2==0, nums))}")\nprint(f"Product: {reduce(operator.mul, nums)}")\n\n@lru_cache(maxsize=None)\ndef fib(n):\n    if n <= 1: return n\n    return fib(n-1) + fib(n-2)\nprint(f"Fib(50) = {fib(50)}")',
      }],
      exercises: [
        { problem: 'Use reduce to find the longest word in ["python","is","awesome","indeed"].', expectedOutput: 'awesome', hint: 'reduce(lambda a,b: a if len(a)>len(b) else b, words)', starterCode: 'from functools import reduce\nwords = ["python","is","awesome","indeed"]\nlongest = reduce(lambda a,b: a if len(a)>len(b) else b, words)\nprint(longest)' },
        { problem: 'Use partial to create a "multiply by 3" function. Test: triple(7) = 21.', expectedOutput: '21', hint: 'from functools import partial; triple = partial(operator.mul, 3)', starterCode: 'from functools import partial\nimport operator\ntriple = partial(operator.mul, 3)\nprint(triple(7))' },
      ],
    },
    {
      id: 'type-hints', title: 'Type Hints', icon: '📝', level: 'intermediate',
      lessons: [{
        title: 'Type Hints',
        content: `<h1>📝 Type Hints</h1>
<p>Type hints make your code self-documenting and enable static analysis.</p>
<h2>Basic Type Hints</h2>
<pre><code>def greet(name: str) -> str:
    return f"Hello, {name}!"

def add(a: int, b: int) -> int:
    return a + b

# Variables
age: int = 25
name: str = "Alice"
scores: list[int] = [95, 88, 92]</code></pre>
<h2>Advanced Types</h2>
<pre><code>from typing import Optional, Union, Dict, List, Tuple

def find(user_id: int) -> Optional[str]:
    # Returns str or None
    ...

def process(data: Union[str, int]) -> str:
    return str(data)

def get_config() -> Dict[str, int]:
    return {"timeout": 30, "retries": 3}

def get_point() -> Tuple[int, int]:
    return (3, 4)</code></pre>
<h2>Generic Types</h2>
<pre><code>from typing import TypeVar, Generic, List

T = TypeVar('T')

class Stack(Generic[T]):
    def __init__(self) -> None:
        self.items: List[T] = []
    def push(self, item: T) -> None:
        self.items.append(item)
    def pop(self) -> T:
        return self.items.pop()</code></pre>
<div class="tip">Type hints are optional and not enforced at runtime. Use mypy for static type checking.</div>`,
        starterCode: 'from typing import Optional, List, Dict\n\ndef greet(name: str) -> str:\n    return f"Hello, {name}!"\n\ndef average(scores: List[int]) -> float:\n    return sum(scores) / len(scores)\n\ndef find_user(user_id: int) -> Optional[str]:\n    users = {1: "Alice", 2: "Bob"}\n    return users.get(user_id)\n\nprint(greet("World"))\nprint(f"Avg: {average([90, 85, 95])}")\nprint(f"User: {find_user(1)}")\nprint(f"Missing: {find_user(99)}")',
      }],
      exercises: [
        { problem: 'Add type hints to: def process(items, factor): return [x*factor for x in items].', expectedOutput: 'Result: [2, 4, 6]', hint: 'items: list[int], factor: int -> list[int]', starterCode: 'from typing import List\ndef process(items: List[int], factor: int) -> List[int]:\n    return [x * factor for x in items]\nprint(f"Result: {process([1,2,3], 2)}")' },
        { problem: 'Create a TypedDict for a User with name:str, age:int, email:str.', expectedOutput: 'Alice (25) - alice@mail.com', hint: 'from typing import TypedDict', starterCode: 'from typing import TypedDict\nclass User(TypedDict):\n    name: str\n    age: int\n    email: str\n\ndef show(u: User) -> str:\n    return f"{u[\'name\']} ({u[\'age\']}) - {u[\'email\']}"\n\nuser: User = {"name": "Alice", "age": 25, "email": "alice@mail.com"}\nprint(show(user))' },
      ],
    },

    // ===== ADVANCED =====
    {
      id: 'decorators', title: 'Decorators', icon: '✨', level: 'advanced',
      lessons: [{
        title: 'Decorators',
        content: `<h1>✨ Decorators</h1>
<p>Decorators modify or enhance functions without changing their code.</p>
<h2>Basic Decorator</h2>
<pre><code>def timer(func):
    import time
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        print(f"{func.__name__} took {time.time()-start:.4f}s")
        return result
    return wrapper

@timer
def slow_sum():
    return sum(range(1000000))

slow_sum()</code></pre>
<h2>Decorator with Arguments</h2>
<pre><code>def repeat(n):
    def decorator(func):
        def wrapper(*args, **kwargs):
            for _ in range(n):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(3)
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")</code></pre>
<h2>@wraps (Preserve Metadata)</h2>
<pre><code>from functools import wraps

def debug(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__} with {args}, {kwargs}")
        result = func(*args, **kwargs)
        print(f"Returned: {result}")
        return result
    return wrapper</code></pre>
<h2>Class Decorator</h2>
<pre><code>def singleton(cls):
    instances = {}
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return get_instance

@singleton
class Database:
    pass</code></pre>
<div class="tip">Decorators are applied bottom-up: @a @b @c def f() means a(b(c(f))).</div>`,
        starterCode: 'from functools import wraps\nimport time\n\ndef timer(func):\n    @wraps(func)\n    def wrapper(*args, **kwargs):\n        start = time.time()\n        result = func(*args, **kwargs)\n        print(f"{func.__name__} took {time.time()-start:.4f}s")\n        return result\n    return wrapper\n\n@timer\ndef compute():\n    return sum(x**2 for x in range(100000))\n\ncompute()',
      }],
      exercises: [
        { problem: 'Create @cache decorator that memoizes function results.', expectedOutput: '55', hint: 'Store results in dict keyed by args.', starterCode: 'def cache(func):\n    memo = {}\n    def wrapper(*args):\n        if args not in memo:\n            memo[args] = func(*args)\n        return memo[args]\n    return wrapper\n\n@cache\ndef fib(n):\n    if n <= 1: return n\n    return fib(n-1) + fib(n-2)\n\nprint(fib(10))' },
        { problem: 'Create @validate_types(*types) decorator that checks argument types.', expectedOutput: 'TypeError caught!\n30', hint: 'Check len(args) matches len(types), isinstance each.', starterCode: 'def validate_types(*types):\n    def decorator(func):\n        def wrapper(*args):\n            for a, t in zip(args, types):\n                if not isinstance(a, t):\n                    raise TypeError(f"Expected {t}, got {type(a)}")\n            return func(*args)\n        return wrapper\n    return decorator\n\n@validate_types(int, int)\ndef add(a, b):\n    return a + b\n\ntry:\n    add("1", 2)\nexcept TypeError:\n    print("TypeError caught!")\nprint(add(10, 20))' },
      ],
    },
    {
      id: 'context-managers', title: 'Context Managers', icon: '🔒', level: 'advanced',
      lessons: [{
        title: 'Context Managers',
        content: `<h1>🔒 Context Managers</h1>
<p>Context managers ensure setup and cleanup happen automatically.</p>
<h2>Class-based Context Manager</h2>
<pre><code>class Timer:
    def __enter__(self):
        import time
        self.start = time.time()
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        import time
        print(f"Elapsed: {time.time() - self.start:.4f}s")
        return False  # Don't suppress exceptions

with Timer():
    sum(range(1000000))</code></pre>
<h2>@contextmanager Decorator</h2>
<pre><code>from contextlib import contextmanager

@contextmanager
def open_file(path, mode="r"):
    f = open(path, mode)
    try:
        yield f
    finally:
        f.close()

with open_file("test.txt", "w") as f:
    f.write("Hello!")</code></pre>
<h2>contextlib Utilities</h2>
<pre><code>from contextlib import suppress, redirect_stdout
import io

# Suppress specific exceptions
with suppress(FileNotFoundError):
    os.remove("nonexistent.txt")

# Redirect stdout
f = io.StringIO()
with redirect_stdout(f):
    print("Captured!")
print(f.getvalue())  # "Captured!"</code></pre>
<div class="tip">Context managers guarantee cleanup even when exceptions occur — perfect for resource management.</div>`,
        starterCode: 'from contextlib import contextmanager\nimport time\n\n@contextmanager\ndef timer(label="Block"):\n    start = time.time()\n    yield\n    print(f"{label}: {time.time()-start:.4f}s")\n\nwith timer("Computation"):\n    total = sum(x**2 for x in range(100000))\n    print(f"Result: {total}")',
      }],
      exercises: [
        { problem: 'Create a @contextmanager "indent" that indents all print output within the block.', expectedOutput: '  Hello\n  World\nBack to normal', hint: 'Override print temporarily using builtins.', starterCode: 'from contextlib import contextmanager\nimport builtins\n\n@contextmanager\ndef indent(prefix="  "):\n    original_print = builtins.print\n    def indented_print(*args, **kwargs):\n        original_print(prefix, *args, **kwargs)\n    builtins.print = indented_print\n    try:\n        yield\n    finally:\n        builtins.print = original_print\n\nwith indent():\n    print("Hello")\n    print("World")\nprint("Back to normal")' },
      ],
    },
    {
      id: 'memory-management', title: 'Memory Management', icon: '🧮', level: 'advanced',
      lessons: [{
        title: 'Memory Management & Copy',
        content: `<h1>🧮 Memory Management & Copy</h1>
<h2>Reference Counting</h2>
<pre><code>import sys
x = [1, 2, 3]
print(sys.getrefcount(x))  # 2 (x + getrefcount arg)

y = x
print(sys.getrefcount(x))  # 3</code></pre>
<h2>Shallow vs Deep Copy</h2>
<pre><code>import copy

# Assignment = reference (same object)
a = [[1,2],[3,4]]
b = a
b[0][0] = 99
print(a[0][0])  # 99 (same object!)

# Shallow copy = new outer, same inner
c = copy.copy(a)
c[0][0] = 100
print(a[0][0])  # 100 (inner objects shared!)

# Deep copy = completely independent
d = copy.deepcopy(a)
d[0][0] = 200
print(a[0][0])  # 100 (independent)</code></pre>
<h2>Garbage Collection</h2>
<pre><code>import gc
gc.collect()  # Force garbage collection
print(gc.get_count())  # (young, middle, old) counts

# Circular references
class Node:
    def __init__(self):
        self.ref = None
a = Node()
b = Node()
a.ref = b
b.ref = a
del a, b  # GC handles circular refs</code></pre>
<h2>__slots__ for Memory Efficiency</h2>
<pre><code>class WithSlots:
    __slots__ = ['x', 'y']
    def __init__(self, x, y):
        self.x = x
        self.y = y

class WithoutSlots:
    def __init__(self, x, y):
        self.x = x
        self.y = y

# WithSlots uses ~40% less memory per instance</code></pre>
<div class="tip">Use <code>id()</code> to check if two variables reference the same object.</div>`,
        starterCode: 'import copy\n\n# Shallow vs Deep\noriginal = [[1,2,3],[4,5,6]]\nshallow = copy.copy(original)\ndeep = copy.deepcopy(original)\n\noriginal[0][0] = 99\nprint(f"Original: {original}")\nprint(f"Shallow:  {shallow}")\nprint(f"Deep:     {deep}")\n\nimport sys\nprint(f"\\nRefcount of 42: {sys.getrefcount(42)}")\nprint(f"Size of [1,2,3]: {sys.getsizeof([1,2,3])} bytes")',
      }],
      exercises: [
        { problem: 'Demonstrate shallow copy limitation: modify nested list in copy, show original changes.', expectedOutput: 'Original after shallow: [[99, 2], [3, 4]]\nOriginal after deep: [[99, 2], [3, 4]]', hint: 'copy.copy shares inner objects.', starterCode: 'import copy\norig = [[1,2],[3,4]]\nshallow = copy.copy(orig)\ndeep = copy.deepcopy(orig)\nshallow[0][0] = 99\nprint(f"Original after shallow: {orig}")\ndeep[0][0] = 100\nprint(f"Original after deep: {orig}")' },
      ],
    },

    {
      id: 'closures', title: 'Closures', icon: '🔐', level: 'advanced',
      lessons: [{
        title: 'Closures & Scope',
        content: `<h1>🔐 Closures & Scope</h1>
<p>A <strong>closure</strong> is a function that remembers variables from its enclosing scope, even after that scope has finished executing.</p>
<h2>Basic Closure</h2>
<pre><code>def make_multiplier(n):
    def multiplier(x):
        return x * n  # n is "closed over"
    return multiplier

double = make_multiplier(2)
triple = make_multiplier(3)
print(double(5))   # 10
print(triple(5))   # 15</code></pre>
<h2>Closure with State</h2>
<pre><code>def make_counter():
    count = 0
    def counter():
        nonlocal count
        count += 1
        return count
    return counter

c = make_counter()
print(c())  # 1
print(c())  # 2
print(c())  # 3</code></pre>
<h2>Closure Factories</h2>
<pre><code>def make_power(exponent):
    def power(base):
        return base ** exponent
    return power

square = make_power(2)
cube = make_power(3)
print(square(4))  # 16
print(cube(3))    # 27</code></pre>
<h2>Late Binding Gotcha</h2>
<pre><code># WRONG — all functions return 4
funcs = [lambda: i for i in range(5)]
print(funcs[0]())  # 4 (not 0!)

# CORRECT — capture current value
funcs = [lambda i=i: i for i in range(5)]
print(funcs[0]())  # 0</code></pre>
<div class="tip">Closures are the foundation of decorators. Every decorator is essentially a closure!</div>
<div class="warning">Be careful with closures in loops — Python's late binding can cause unexpected behavior.</div>`,
        starterCode: 'def make_greeting(greeting):\n    def greet(name):\n        return f"{greeting}, {name}!"\n    return greet\n\nhello = make_greeting("Hello")\nhi = make_greeting("Hi")\n\nprint(hello("Alice"))\nprint(hi("Bob"))\n\n# Counter with closure\ndef make_counter(start=0):\n    count = start\n    def counter():\n        nonlocal count\n        count += 1\n        return count\n    return counter\n\nc = make_counter(10)\nfor _ in range(5):\n    print(c(), end=" "  ,'
      }],
      exercises: [
        { problem: 'Create make_adder(n) that returns a function adding n to its argument. Test: add5(3)=8, add10(5)=15.', expectedOutput: '8\n15', hint: 'def make_adder(n): return lambda x: x + n', starterCode: 'def make_adder(n):\n    return lambda x: x + n\n\nadd5 = make_adder(5)\nadd10 = make_adder(10)\nprint(add5(3))\nprint(add10(5))' },
        { problem: 'Create make_accumulator() that returns a function. Each call adds to running total and returns it.', expectedOutput: '5\n8\n13', hint: 'Use nonlocal total in nested function.', starterCode: 'def make_accumulator():\n    total = 0\n    def add(n):\n        nonlocal total\n        total += n\n        return total\n    return add\n\nacc = make_accumulator()\nprint(acc(5))\nprint(acc(3))\nprint(acc(5))' },
      ],
    },
    {
      id: 'multithreading', title: 'Multithreading & Multiprocessing', icon: '🧵', level: 'advanced',
      lessons: [{
        title: 'Multithreading vs Multiprocessing',
        content: `<h1>🧵 Multithreading & Multiprocessing</h1>
<p>Python has a <strong>GIL (Global Interpreter Lock)</strong> that prevents true parallel execution of threads for CPU-bound tasks.</p>
<h2>Threading (I/O-bound tasks)</h2>
<pre><code>import threading
import time

def download(url):
    print(f"Downloading {url}...")
    time.sleep(1)
    print(f"Done: {url}")

threads = []
for url in ["url1.com", "url2.com", "url3.com"]:
    t = threading.Thread(target=download, args=(url,))
    threads.append(t)
    t.start()

for t in threads:
    t.join()
print("All downloads complete!")</code></pre>
<h2>Thread Pool</h2>
<pre><code>from concurrent.futures import ThreadPoolExecutor

def fetch(url):
    return f"Data from {url}"

urls = ["url1.com", "url2.com", "url3.com"]
with ThreadPoolExecutor(max_workers=3) as executor:
    results = executor.map(fetch, urls)
    for r in results:
        print(r)</code></pre>
<h2>Multiprocessing (CPU-bound tasks)</h2>
<pre><code>from concurrent.futures import ProcessPoolExecutor
import math

def is_prime(n):
    if n < 2: return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0: return False
    return True

numbers = [112272535095293, 112582705942171, 115280095190773]
with ProcessPoolExecutor() as executor:
    results = executor.map(is_prime, numbers)
    for n, p in zip(numbers, results):
        print(f"{n}: {'prime' if p else 'not prime'}")</code></pre>
<h2>Locks (Thread Safety)</h2>
<pre><code>import threading

counter = 0
lock = threading.Lock()

def increment():
    global counter
    for _ in range(100000):
        with lock:
            counter += 1

threads = [threading.Thread(target=increment) for _ in range(4)]
for t in threads: t.start()
for t in threads: t.join()
print(counter)  # 400000</code></pre>
<div class="tip">Use <strong>threading</strong> for I/O-bound tasks (network, files). Use <strong>multiprocessing</strong> for CPU-bound tasks (math, data processing).</div>
<div class="warning">Pyodide has limited threading support. These examples work best in standard Python.</div>`,
        starterCode: 'import threading\nimport time\n\ndef task(name, duration):\n    print(f"Task {name} starting...")\n    time.sleep(duration)\n    print(f"Task {name} done!")\n\n# Sequential\nstart = time.time()\ntask("A", 0.1)\ntask("B", 0.1)\nprint(f"Sequential: {time.time()-start:.2f}s")\n\n# Threaded\nstart = time.time()\nt1 = threading.Thread(target=task, args=("A", 0.1))\nt2 = threading.Thread(target=task, args=("B", 0.1))\nt1.start()\nt2.start()\nt1.join()\nt2.join()\nprint(f"Threaded: {time.time()-start:.2f}s")',
      }],
      exercises: [
        { problem: 'Use ThreadPoolExecutor to compute squares of [1,2,3,4,5] concurrently.', expectedOutput: '[1, 4, 9, 16, 25]', hint: 'from concurrent.futures import ThreadPoolExecutor', starterCode: 'from concurrent.futures import ThreadPoolExecutor\n\ndef square(n):\n    return n ** 2\n\nwith ThreadPoolExecutor() as ex:\n    results = list(ex.map(square, [1,2,3,4,5]))\nprint(results)' },
        { problem: 'Create a thread-safe counter using Lock. Increment 1000 times across 4 threads.', expectedOutput: '4000', hint: 'Use threading.Lock() to protect shared counter.', starterCode: 'import threading\n\ncounter = 0\nlock = threading.Lock()\n\ndef increment():\n    global counter\n    for _ in range(1000):\n        with lock:\n            counter += 1\n\nthreads = [threading.Thread(target=increment) for _ in range(4)]\nfor t in threads: t.start()\nfor t in threads: t.join()\nprint(counter)' },
      ],
    },
    {
      id: 'metaclasses', title: 'Metaclasses', icon: '🔮', level: 'advanced',
      lessons: [{
        title: 'Metaclasses',
        content: `<h1>🔮 Metaclasses</h1>
<p>Metaclasses are the "classes of classes." They control how classes are created.</p>
<h2>Understanding type()</h2>
<pre><code># type() creates classes dynamically
MyClass = type('MyClass', (object,), {'x': 42})
obj = MyClass()
print(obj.x)  # 42

# Everything is an instance of a class
print(type(42))       # &lt;class 'int'&gt;
print(type(int))      # &lt;class 'type'&gt;
print(type(type))     # &lt;class 'type'&gt;</code></pre>
<h2>Custom Metaclass</h2>
<pre><code>class SingletonMeta(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class Database(metaclass=SingletonMeta):
    def __init__(self, url):
        self.url = url

db1 = Database("postgres://localhost")
db2 = Database("mysql://remote")
print(db1 is db2)  # True (same instance)</code></pre>
<h2>__init_subclass__</h2>
<pre><code>class Plugin:
    registry = []
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls.registry.append(cls)

class MyPlugin(Plugin):
    pass

print(Plugin.registry)  # [MyPlugin]</code></pre>
<div class="tip">Most Python developers never need metaclasses. Use __init_subclass__ or class decorators for most use cases.</div>`,
        starterCode: 'class AutoRegister:\n    registry = {}\n    def __init_subclass__(cls, name=None, **kwargs):\n        super().__init_subclass__(**kwargs)\n        AutoRegister.registry[name or cls.__name__] = cls\n\nclass Dog(AutoRegister, name="dog"):\n    def speak(self): return "Woof!"\n\nclass Cat(AutoRegister, name="cat"):\n    def speak(self): return "Meow!"\n\nprint(f"Registered: {list(AutoRegister.registry.keys())}")\nfor name, cls in AutoRegister.registry.items():\n    print(f"{name}: {cls().speak()}")',
      }],
      exercises: [
        { problem: 'Create a metaclass AutoRepr that auto-generates __repr__ from __init__ params.', expectedOutput: 'Point(x=3, y=4)', hint: 'Store __init__ params in __new__ or __init__, generate __repr__.', starterCode: 'class AutoRepr(type):\n    def __new__(mcs, name, bases, namespace):\n        cls = super().__new__(mcs, name, bases, namespace)\n        init = namespace.get("__init__")\n        if init:\n            def __repr__(self):\n                attrs = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items())\n                return f"{name}({attrs})"\n            cls.__repr__ = __repr__\n        return cls\n\nclass Point(metaclass=AutoRepr):\n    def __init__(self, x, y):\n        self.x = x\n        self.y = y\n\np = Point(3, 4)\nprint(repr(p))' },
      ],
    },
    {
      id: 'descriptors', title: 'Descriptors', icon: '📎', level: 'advanced',
      lessons: [{
        title: 'Descriptors',
        content: `<h1>📎 Descriptors</h1>
<p>Descriptors control attribute access. <code>@property</code> is a descriptor!</p>
<h2>Descriptor Protocol</h2>
<pre><code>class Validator:
    def __init__(self, min_val, max_val):
        self.min_val = min_val
        self.max_val = max_val
    def __set_name__(self, owner, name):
        self.name = name
        self.private = f"_{name}"
    def __get__(self, obj, objtype=None):
        if obj is None: return self
        return getattr(obj, self.private, None)
    def __set__(self, obj, value):
        if not (self.min_val <= value <= self.max_val):
            raise ValueError(f"{self.name} must be {self.min_val}-{self.max_val}")
        setattr(obj, self.private, value)

class Person:
    age = Validator(0, 150)
    def __init__(self, name, age):
        self.name = name
        self.age = age</code></pre>
<h2>Data vs Non-Data Descriptors</h2>
<pre><code># Data descriptor: has __set__ (overrides instance __dict__)
class DataDesc:
    def __get__(self, obj, type=None): return 42
    def __set__(self, obj, value): pass

# Non-data descriptor: only __get__ (instance __dict__ overrides)
class NonDataDesc:
    def __get__(self, obj, type=None): return 42</code></pre>
<div class="tip">Descriptors are the mechanism behind @property, @staticmethod, @classmethod, and SQLAlchemy columns.</div>`,
        starterCode: 'class Range:\n    def __init__(self, min_val, max_val):\n        self.min_val = min_val\n        self.max_val = max_val\n    def __set_name__(self, owner, name):\n        self.name = "_" + name\n    def __get__(self, obj, type=None):\n        return getattr(obj, self.name, None)\n    def __set__(self, obj, value):\n        if not (self.min_val <= value <= self.max_val):\n            raise ValueError(f"Must be {self.min_val}-{self.max_val}")\n        setattr(obj, self.name, value)\n\nclass Student:\n    grade = Range(0, 100)\n    def __init__(self, name, grade):\n        self.name = name\n        self.grade = grade\n\ns = Student("Alice", 95)\nprint(f"{s.name}: {s.grade}")',
      }],
      exercises: [
        { problem: 'Create a @lazy_property descriptor that computes value once and caches it.', expectedOutput: 'Computing...\n42\n42', hint: 'Check if value exists in instance __dict__ before computing.', starterCode: 'class lazy_property:\n    def __init__(self, func):\n        self.func = func\n        self.name = func.__name__\n    def __get__(self, obj, type=None):\n        if obj is None: return self\n        value = self.func(obj)\n        setattr(obj, self.name, value)\n        return value\n\nclass Circle:\n    def __init__(self, r): self.r = r\n    @lazy_property\n    def area(self):\n        print("Computing...")\n        return 3.14159 * self.r ** 2\n\nc = Circle(5)\nprint(int(c.area))\nprint(int(c.area))' },
      ],
    },
    {
      id: 'design-patterns', title: 'Design Patterns', icon: '🏛️', level: 'advanced',
      lessons: [{
        title: 'Design Patterns in Python',
        content: `<h1>🏛️ Design Patterns</h1>
<p>Common solutions to recurring software design problems.</p>
<h2>Strategy Pattern</h2>
<pre><code>from abc import ABC, abstractmethod

class SortStrategy(ABC):
    @abstractmethod
    def sort(self, data): pass

class BubbleSort(SortStrategy):
    def sort(self, data):
        return sorted(data)  # Simplified

class QuickSort(SortStrategy):
    def sort(self, data):
        return sorted(data, reverse=True)

class Sorter:
    def __init__(self, strategy: SortStrategy):
        self.strategy = strategy
    def sort(self, data):
        return self.strategy.sort(data)</code></pre>
<h2>Observer Pattern</h2>
<pre><code>class Event:
    def __init__(self):
        self._handlers = []
    def subscribe(self, handler):
        self._handlers.append(handler)
    def fire(self, **kwargs):
        for h in self._handlers:
            h(**kwargs)

on_click = Event()
on_click.subscribe(lambda **kw: print(f"Clicked: {kw}"))
on_click.fire(x=10, y=20)</code></pre>
<h2>Factory Pattern</h2>
<pre><code>class AnimalFactory:
    @staticmethod
    def create(type_, name):
        if type_ == "dog": return Dog(name)
        if type_ == "cat": return Cat(name)
        raise ValueError(f"Unknown: {type_}")</code></pre>
<div class="tip">Python's first-class functions and duck typing often make patterns simpler than in Java/C++.</div>`,
        starterCode: 'from abc import ABC, abstractmethod\n\n# Strategy Pattern\ndef strategy_demo():\n    strategies = {\n        "double": lambda x: x * 2,\n        "square": lambda x: x ** 2,\n        "negate": lambda x: -x,\n    }\n    for name, fn in strategies.items():\n        print(f"{name}(5) = {fn(5)}")\n\nstrategy_demo()\n\n# Observer Pattern\nclass EventEmitter:\n    def __init__(self): self._handlers = []\n    def on(self, h): self._handlers.append(h)\n    def emit(self, data):\n        for h in self._handlers: h(data)\n\ne = EventEmitter()\ne.on(lambda d: print(f"Handler 1: {d}"))\ne.on(lambda d: print(f"Handler 2: {d}"))\ne.emit("Hello!")',
      }],
      exercises: [
        { problem: 'Implement a simple event system: Event class with subscribe() and fire(). Test with 2 handlers.', expectedOutput: 'Handler 1 got: test\nHandler 2 got: test', hint: 'Store handlers in a list, iterate on fire().', starterCode: 'class Event:\n    def __init__(self): self._handlers = []\n    def subscribe(self, h): self._handlers.append(h)\n    def fire(self, data):\n        for h in self._handlers: h(data)\n\ne = Event()\ne.subscribe(lambda d: print(f"Handler 1 got: {d}"))\ne.subscribe(lambda d: print(f"Handler 2 got: {d}"))\ne.fire("test")' },
      ],
    },
    {
      id: 'algorithms', title: 'Algorithm Analysis', icon: '📐', level: 'advanced',
      lessons: [{
        title: 'Algorithm Analysis & Big O',
        content: `<h1>📐 Algorithm Analysis</h1>
<p>Understanding time and space complexity helps you write efficient code.</p>
<h2>Big O Notation</h2>
<pre><code># O(1) — Constant
def get_first(lst): return lst[0]

# O(n) — Linear
def find_max(lst):
    m = lst[0]
    for x in lst:
        if x > m: m = x
    return m

# O(n²) — Quadratic
def has_duplicates(lst):
    for i in range(len(lst)):
        for j in range(i+1, len(lst)):
            if lst[i] == lst[j]: return True
    return False

# O(log n) — Logarithmic (binary search)
def binary_search(arr, target):
    lo, hi = 0, len(arr) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if arr[mid] == target: return mid
        elif arr[mid] < target: lo = mid + 1
        else: hi = mid - 1
    return -1</code></pre>
<h2>Common Complexities</h2>
<pre><code># O(n log n) — Merge Sort
def merge_sort(arr):
    if len(arr) <= 1: return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i]); i += 1
        else:
            result.append(right[j]); j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result</code></pre>
<div class="tip">Use a set for O(1) lookups instead of O(n) list searches. Trade space for time when needed.</div>`,
        starterCode: 'import time\n\n# Compare linear vs binary search\narr = list(range(1000000))\n\ndef linear_search(arr, target):\n    for i, v in enumerate(arr):\n        if v == target: return i\n    return -1\n\ndef binary_search(arr, target):\n    lo, hi = 0, len(arr) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid + 1\n        else: hi = mid - 1\n    return -1\n\ntarget = 999999\nstart = time.time()\nlinear_search(arr, target)\nprint(f"Linear: {time.time()-start:.4f}s")\n\nstart = time.time()\nbinary_search(arr, target)\nprint(f"Binary: {time.time()-start:.6f}s")',
      }],
      exercises: [
        { problem: 'Implement merge sort and verify it sorts [38,27,43,3,9,82,10].', expectedOutput: '[3, 9, 10, 27, 38, 43, 82]', hint: 'Recursively split, then merge sorted halves.', starterCode: 'def merge_sort(arr):\n    if len(arr) <= 1: return arr\n    mid = len(arr) // 2\n    left = merge_sort(arr[:mid])\n    right = merge_sort(arr[mid:])\n    return merge(left, right)\n\ndef merge(left, right):\n    result, i, j = [], 0, 0\n    while i < len(left) and j < len(right):\n        if left[i] <= right[j]:\n            result.append(left[i]); i += 1\n        else:\n            result.append(right[j]); j += 1\n    result.extend(left[i:])\n    result.extend(right[j:])\n    return result\n\nprint(merge_sort([38,27,43,3,9,82,10]))' },
        { problem: 'Find two numbers in sorted array [1,3,5,7,9,11] that sum to 12 using two-pointer technique.', expectedOutput: '(1, 11)', hint: 'Start with left=0, right=len-1. Move pointers based on sum.', starterCode: 'def two_sum_sorted(arr, target):\n    left, right = 0, len(arr) - 1\n    while left < right:\n        s = arr[left] + arr[right]\n        if s == target: return (arr[left], arr[right])\n        elif s < target: left += 1\n        else: right -= 1\n    return None\n\nprint(two_sum_sorted([1,3,5,7,9,11], 12))' },
      ],
    },

    // ===== PROFESSIONAL =====
    {
      id: 'async-programming', title: 'Async Programming', icon: '🔀', level: 'professional',
      lessons: [{
        title: 'Async/Await Programming',
        content: `<h1>🔀 Async/Await Programming</h1>
<p>Async programming lets you write concurrent code that doesn't block.</p>
<h2>Basic async/await</h2>
<pre><code>import asyncio

async def fetch_data(url):
    print(f"Fetching {url}...")
    await asyncio.sleep(1)  # Simulates I/O
    return f"Data from {url}"

async def main():
    result = await fetch_data("example.com")
    print(result)

asyncio.run(main())</code></pre>
<h2>Concurrent Tasks</h2>
<pre><code>async def main():
    # Run concurrently
    results = await asyncio.gather(
        fetch_data("url1.com"),
        fetch_data("url2.com"),
        fetch_data("url3.com"),
    )
    for r in results:
        print(r)

asyncio.run(main())</code></pre>
<h2>async for & async with</h2>
<pre><code>async def async_range(n):
    for i in range(n):
        await asyncio.sleep(0.1)
        yield i

async def main():
    async for i in async_range(5):
        print(i, end=" ")

asyncio.run(main())</code></pre>
<div class="warning">Pyodide has limited asyncio support. Some features may not work in browser.</div>
<div class="tip">Use async for I/O-bound tasks (network, files). For CPU-bound tasks, use multiprocessing.</div>`,
        starterCode: 'import asyncio\n\nasync def count(name, n):\n    for i in range(n):\n        print(f"{name}: {i}")\n        await asyncio.sleep(0.01)\n\nasync def main():\n    await asyncio.gather(\n        count("A", 3),\n        count("B", 3),\n    )\n\nasyncio.run(main())',
      }],
      exercises: [
        { problem: 'Create async function that "fetches" 3 URLs concurrently using asyncio.gather.', expectedOutput: 'Fetching...\nFetching...\nFetching...\nAll done!\nResults: [1, 2, 3]', hint: 'Use asyncio.sleep to simulate I/O, asyncio.gather to run concurrently.', starterCode: 'import asyncio\n\nasync def fetch(id):\n    print("Fetching...")\n    await asyncio.sleep(0.01)\n    return id\n\nasync def main():\n    results = await asyncio.gather(fetch(1), fetch(2), fetch(3))\n    print(f"All done!")\n    print(f"Results: {results}")\n\nasyncio.run(main())' },
      ],
    },
    {
      id: 'testing', title: 'Testing with pytest', icon: '🧪', level: 'professional',
      lessons: [{
        title: 'Testing with pytest',
        content: `<h1>🧪 Testing with pytest</h2>
<p>Testing ensures your code works correctly and prevents regressions.</p>
<h2>Basic Tests</h2>
<pre><code># test_math.py
def add(a, b):
    return a + b

def test_add():
    assert add(2, 3) == 5
    assert add(-1, 1) == 0
    assert add(0, 0) == 0

def test_add_strings():
    assert add("hello", " world") == "hello world"</code></pre>
<h2>pytest Features</h2>
<pre><code>import pytest

# Fixtures (setup/teardown)
@pytest.fixture
def sample_data():
    return [1, 2, 3, 4, 5]

def test_sum(sample_data):
    assert sum(sample_data) == 15

# Parametrize
@pytest.mark.parametrize("a,b,expected", [
    (1, 2, 3),
    (0, 0, 0),
    (-1, 1, 0),
])
def test_add_parametrized(a, b, expected):
    assert add(a, b) == expected

# Exception testing
def test_divide_by_zero():
    with pytest.raises(ZeroDivisionError):
        1 / 0</code></pre>
<div class="tip">Write tests BEFORE fixing bugs. This is called Test-Driven Development (TDD).</div>`,
        starterCode: '# Testing in Pyodide (simulated)\ndef add(a, b):\n    return a + b\n\ndef test_add():\n    assert add(2, 3) == 5, "2+3 should be 5"\n    assert add(-1, 1) == 0, "-1+1 should be 0"\n    assert add(0, 0) == 0, "0+0 should be 0"\n    print("All tests passed! ✅")\n\ntest_add()\n\n# Test with data\ndef factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n-1)\n\ndef test_factorial():\n    assert factorial(0) == 1\n    assert factorial(1) == 1\n    assert factorial(5) == 120\n    assert factorial(10) == 3628800\n    print("Factorial tests passed! ✅")\n\ntest_factorial()',
      }],
      exercises: [
        { problem: 'Write tests for a is_palindrome function. Test: "racecar"→True, "hello"→False, ""→True.', expectedOutput: 'All palindrome tests passed! ✅', hint: 'assert is_palindrome("racecar") == True', starterCode: 'def is_palindrome(s):\n    return s == s[::-1]\n\ndef test_palindrome():\n    assert is_palindrome("racecar") == True\n    assert is_palindrome("hello") == False\n    assert is_palindrome("") == True\n    assert is_palindrome("a") == True\n    assert is_palindrome("abba") == True\n    print("All palindrome tests passed! ✅")\n\ntest_palindrome()' },
      ],
    },
    {
      id: 'logging-debugging', title: 'Logging & Debugging', icon: '🔍', level: 'professional',
      lessons: [{
        title: 'Logging & Debugging',
        content: `<h1>🔍 Logging & Debugging</h1>
<h2>Logging Module</h2>
<pre><code>import logging

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

logging.debug("Debug info")
logging.info("General info")
logging.warning("Warning message")
logging.error("Error occurred")
logging.critical("Critical failure!")</code></pre>
<h2>Logging to File</h2>
<pre><code>logging.basicConfig(
    filename="app.log",
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("my_app")
logger.info("Application started")</code></pre>
<h2>Debugging with pdb</h2>
<pre><code>import pdb

def buggy_function():
    x = 10
    y = 0
    pdb.set_trace()  # Breakpoint
    return x / y

# Commands: n(next), s(step), c(continue), p(print), q(quit)</code></pre>
<h2>Assertions</h2>
<pre><code>def divide(a, b):
    assert b != 0, "Divisor cannot be zero"
    return a / b

def process(data):
    assert isinstance(data, list), "Data must be a list"
    assert len(data) > 0, "Data cannot be empty"
    return sum(data)</code></pre>
<div class="tip">Use logging instead of print() in production code. It's configurable and can be disabled.</div>`,
        starterCode: 'import logging\nlogging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")\n\ndef divide(a, b):\n    logging.info(f"Dividing {a} by {b}")\n    if b == 0:\n        logging.error("Division by zero!")\n        return None\n    result = a / b\n    logging.debug(f"Result: {result}")\n    return result\n\nprint(divide(10, 3))\nprint(divide(10, 0))\n\nlogging.warning("This is a warning")\nlogging.critical("This is critical!")',
      }],
      exercises: [
        { problem: 'Create a function with logging that logs entry, args, and return value using a decorator.', expectedOutput: "INFO: Calling add with (3, 5)\nINFO: add returned 8\n8", hint: 'Create a @log_calls decorator that wraps the function.', starterCode: 'import logging\nlogging.basicConfig(level=logging.INFO, format="%(message)s")\n\ndef log_calls(func):\n    def wrapper(*args):\n        logging.info(f"Calling {func.__name__} with {args}")\n        result = func(*args)\n        logging.info(f"{func.__name__} returned {result}")\n        return result\n    return wrapper\n\n@log_calls\ndef add(a, b):\n    return a + b\n\nprint(add(3, 5))' },
      ],
    },
    {
      id: 'packaging', title: 'Packaging & Distribution', icon: '📦', level: 'professional',
      lessons: [{
        title: 'Packaging & Distribution',
        content: `<h1>📦 Packaging & Distribution</h1>
<p>Learn to package your Python projects for distribution.</p>
<h2>Project Structure</h2>
<pre><code>myproject/
├── pyproject.toml      # Project metadata & dependencies
├── README.md
├── src/
│   └── mypackage/
│       ├── __init__.py
│       └── module.py
└── tests/
    └── test_module.py</code></pre>
<h2>pyproject.toml</h2>
<pre><code>[project]
name = "mypackage"
version = "0.1.0"
description = "A cool Python package"
requires-python = ">=3.8"
dependencies = ["requests>=2.0"]

[project.scripts]
mycli = "mypackage.cli:main"</code></pre>
<h2>Building & Publishing</h2>
<pre><code># Install build tool
pip install build twine

# Build the package
python -m build
# Creates dist/mypackage-0.1.0.tar.gz and .whl

# Upload to PyPI
twine upload dist/*</code></pre>
<div class="tip">Use <code>pip install -e .</code> for editable installs during development.</div>`,
        starterCode: '# Simulated packaging demo\nproject = {\n    "name": "pylearn-utils",\n    "version": "1.0.0",\n    "author": "Python Learner",\n    "dependencies": ["requests", "rich"],\n    "python_requires": ">=3.8"\n}\nprint(f"Project: {project[\'name\']} v{project[\'version\']}")\nprint(f"Author: {project[\'author\']}")\nprint(f"Dependencies: {\', \'.join(project[\'dependencies\'])}")\nprint(f"Python: {project[\'python_requires\"]}")',
      }],
      exercises: [
        { problem: 'Create a pyproject.toml dict with name, version, and dependencies. Print formatted.', expectedOutput: 'mypackage v0.1.0\ndeps: requests, click', hint: 'Use a dict and f-strings.', starterCode: 'project = {"name": "mypackage", "version": "0.1.0", "deps": ["requests", "click"]}\nprint(f"{project[\'name\']} v{project[\'version\']}")\nprint(f"deps: {\', \'.join(project[\'deps\'])}")' },
      ],
    },
    {
      id: 'cli-tools', title: 'CLI Tools & argparse', icon: '🖥️', level: 'professional',
      lessons: [{
        title: 'CLI Tools & argparse',
        content: `<h1>🖥️ CLI Tools & argparse</h1>
<p>Build professional command-line tools with Python.</p>
<h2>Basic argparse</h2>
<pre><code>import argparse

parser = argparse.ArgumentParser(description="File processor")
parser.add_argument("file", help="Input file")
parser.add_argument("-v", "--verbose", action="store_true")
parser.add_argument("-n", "--count", type=int, default=1)
args = parser.parse_args()

print(f"File: {args.file}, Verbose: {args.verbose}, Count: {args.count}")</code></pre>
<h2>Subcommands</h2>
<pre><code>parser = argparse.ArgumentParser()
subparsers = parser.add_subparsers(dest="command")

# Add command
add_parser = subparsers.add_parser("add")
add_parser.add_argument("name")

# List command
list_parser = subparsers.add_parser("list")
list_parser.add_argument("--sort", choices=["name", "date"])

args = parser.parse_args()</code></pre>
<h2>Click Library (Alternative)</h2>
<pre><code>import click

@click.command()
@click.argument("name")
@click.option("--count", default=1, help="Number of greetings")
def hello(name, count):
    for _ in range(count):
        click.echo(f"Hello, {name}!")

if __name__ == "__main__":
    hello()</code></pre>
<div class="tip">argparse is in the standard library. Click is more concise for complex CLIs.</div>`,
        starterCode: 'import argparse\n\nparser = argparse.ArgumentParser(description="Todo CLI")\nparser.add_argument("action", choices=["add", "list", "done"])\nparser.add_argument("item", nargs="?", default="")\nparser.add_argument("-p", "--priority", choices=["low","medium","high"], default="medium")\n\n# Simulate: python todo.py add "Buy milk" -p high\nargs = parser.parse_args(["add", "Buy milk", "-p", "high"])\nprint(f"Action: {args.action}")\nprint(f"Item: {args.item}")\nprint(f"Priority: {args.priority}")',
      }],
      exercises: [
        { problem: 'Create an argparse CLI with subcommands "greet" (takes --name) and "calc" (takes --a, --b, --op).', expectedOutput: 'Hello, Alice!\nResult: 12', hint: 'Use add_subparsers() for subcommands.', starterCode: 'import argparse\nparser = argparse.ArgumentParser()\nsub = parser.add_subparsers(dest="cmd")\n\ngreet = sub.add_parser("greet")\ngreet.add_argument("--name", default="World")\n\ncalc = sub.add_parser("calc")\ncalc.add_argument("--a", type=int)\ncalc.add_argument("--b", type=int)\ncalc.add_argument("--op", choices=["add","mul"])\n\nargs = parser.parse_args(["greet", "--name", "Alice"])\nif args.cmd == "greet":\n    print(f"Hello, {args.name}!")\n\nargs = parser.parse_args(["calc", "--a", "3", "--b", "4", "--op", "mul"])\nif args.cmd == "calc":\n    result = args.a * args.b if args.op == "mul" else args.a + args.b\n    print(f"Result: {result}")' },
      ],
    },
    {
      id: 'database-basics', title: 'Database Basics', icon: '🗄️', level: 'professional',
      lessons: [{
        title: 'Database Basics with SQLite',
        content: `<h1>🗄️ Database Basics</h1>
<p>SQLite is a lightweight, file-based database built into Python.</p>
<h2>Basic CRUD</h2>
<pre><code>import sqlite3

# Connect (creates file if not exists)
conn = sqlite3.connect("app.db")
cur = conn.cursor()

# Create table
cur.execute("""CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE
)""")

# Insert
cur.execute("INSERT INTO users (name, email) VALUES (?, ?)",
            ("Alice", "alice@mail.com"))
conn.commit()

# Query
cur.execute("SELECT * FROM users")
for row in cur.fetchall():
    print(row)

conn.close()</code></pre>
<h2>Parameterized Queries</h2>
<pre><code># ALWAYS use parameterized queries (prevents SQL injection)
cur.execute("SELECT * FROM users WHERE name = ?", ("Alice",))

# Multiple inserts
users = [("Bob", "bob@mail.com"), ("Carol", "carol@mail.com")]
cur.executemany("INSERT INTO users (name, email) VALUES (?, ?)", users)</code></pre>
<h2>Context Manager</h2>
<pre><code>with sqlite3.connect("app.db") as conn:
    cur = conn.cursor()
    cur.execute("SELECT * FROM users")
    print(cur.fetchall())
# Auto-commits on success, rolls back on error</code></pre>
<div class="warning">Never use f-strings or string concatenation in SQL queries — use parameterized queries!</div>`,
        starterCode: 'import sqlite3\n\nconn = sqlite3.connect(":memory:")  # In-memory DB\ncur = conn.cursor()\n\ncur.execute("CREATE TABLE tasks (id INTEGER PRIMARY KEY, title TEXT, done INTEGER)")\ntasks = [("Learn Python", 1), ("Build project", 0), ("Write tests", 0)]\ncur.executemany("INSERT INTO tasks (title, done) VALUES (?, ?)", tasks)\nconn.commit()\n\ncur.execute("SELECT * FROM tasks WHERE done = 0")\nprint("Pending tasks:")\nfor row in cur.fetchall():\n    print(f"  {row[0]}. {row[1]}")\n\nconn.close()',
      }],
      exercises: [
        { problem: 'Create in-memory DB with "products" table (name, price). Insert 3 products, query price > 10.', expectedOutput: 'Expensive: Widget ($25.00)', hint: 'Use parameterized queries and WHERE clause.', starterCode: 'import sqlite3\nconn = sqlite3.connect(":memory:")\ncur = conn.cursor()\ncur.execute("CREATE TABLE products (name TEXT, price REAL)")\nproducts = [("Gadget", 5.99), ("Widget", 25.00), ("Doohickey", 15.50)]\ncur.executemany("INSERT INTO products VALUES (?, ?)", products)\nconn.commit()\ncur.execute("SELECT name, price FROM products WHERE price > 10")\nfor name, price in cur.fetchall():\n    print(f"Expensive: {name} (${price:.2f})")\nconn.close()' },
      ],
    },
    {
      id: 'web-scraping', title: 'Web Scraping', icon: '🕷️', level: 'professional',
      lessons: [{
        title: 'Web Scraping Basics',
        content: `<h1>🕷️ Web Scraping</h1>
<p>Extract data from websites programmatically.</p>
<h2>HTTP Requests</h2>
<pre><code>import urllib.request
import json

# Simple GET request
url = "https://api.github.com/users/python"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req) as response:
    data = json.loads(response.read())
    print(f"Name: {data['name']}")
    print(f"Repos: {data['public_repos']}")</code></pre>
<h2>HTML Parsing</h2>
<pre><code>from html.parser import HTMLParser

class LinkExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_starttag(self, tag, attrs):
        if tag == "a":
            for name, value in attrs:
                if name == "href":
                    self.links.append(value)

html = '&lt;a href="https://python.org"&gt;Python&lt;/a&gt;'
parser = LinkExtractor()
parser.feed(html)
print(parser.links)  # ['https://python.org']</code></pre>
<h2>JSON API Pattern</h2>
<pre><code>import urllib.request
import json

def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

data = fetch_json("https://api.example.com/data")
for item in data["results"]:
    print(item["name"])</code></pre>
<div class="warning">Always check a website's robots.txt and terms of service before scraping. Respect rate limits!</div>`,
        starterCode: 'import urllib.request\nimport json\n\n# Fetch and parse JSON API\nurl = "https://api.github.com"\ntry:\n    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})\n    with urllib.request.urlopen(req) as resp:\n        data = json.loads(resp.read())\n        print(f"Current user URL: {data.get(\'current_user_url\', \'N/A\')}")\nexcept Exception as e:\n    print(f"Error: {e}")\n\n# HTML parsing demo\nfrom html.parser import HTMLParser\nclass TitleExtractor(HTMLParser):\n    def __init__(self):\n        super().__init__()\n        self.title = ""\n        self.in_title = False\n    def handle_starttag(self, tag, attrs):\n        if tag == "title": self.in_title = True\n    def handle_data(self, data):\n        if self.in_title: self.title += data\n\nhtml = "&lt;html&gt;&lt;head&gt;&lt;title&gt;My Page&lt;/title&gt;&lt;/head&gt;&lt;/html&gt;"\np = TitleExtractor()\np.feed(html)\nprint(f"Title: {p.title}")',
      }],
      exercises: [
        { problem: 'Parse HTML string with 3 links, extract all href values into a list.', expectedOutput: "['https://a.com', 'https://b.com', 'https://c.com']", hint: 'Use HTMLParser, collect href attrs from <a> tags.', starterCode: 'from html.parser import HTMLParser\nclass LinkExtractor(HTMLParser):\n    def __init__(self):\n        super().__init__()\n        self.links = []\n    def handle_starttag(self, tag, attrs):\n        if tag == "a":\n            for name, value in attrs:\n                if name == "href":\n                    self.links.append(value)\n\nhtml = \'<a href="https://a.com">A</a> <a href="https://b.com">B</a> <a href="https://c.com">C</a>\'\np = LinkExtractor()\np.feed(html)\nprint(p.links)' },
      ],
    },
  ];

  // ---- Helpers ----
  function getAllTopics() { return topics; }
  function getTopic(id) { return topics.find(t => t.id === id); }
  function getTopicIndex(id) { return topics.findIndex(t => t.id === id); }
  function getNextTopic(id) {
    const idx = getTopicIndex(id);
    return idx >= 0 && idx < topics.length - 1 ? topics[idx + 1] : null;
  }
  function getPrevTopic(id) {
    const idx = getTopicIndex(id);
    return idx > 0 ? topics[idx - 1] : null;
  }
  function getTopicsByLevel(level) { return topics.filter(t => t.level === level); }
  function getAllTracks() { return tracks; }
  function getTrack(id) { return tracks.find(t => t.id === id); }
  function getKnowledgeMap(topic) { return knowledgeMaps[topic] || null; }
  function getProgressPercent(progress) {
    const total = topics.length;
    const done = topics.filter(t => progress[t.id] && progress[t.id].lessonDone).length;
    return total ? Math.round((done / total) * 100) : 0;
  }
  function getExerciseStats(progress) {
    let totalEx = 0, doneEx = 0;
    topics.forEach(t => {
      totalEx += t.exercises.length;
      if (progress[t.id] && progress[t.id].exercises) {
        doneEx += Object.keys(progress[t.id].exercises).length;
      }
    });
    return { total: totalEx, done: doneEx };
  }

  function getProblemBank() { return problemBank; }
  function getProblem(id) { return problemBank.find(p => p.id === id); }
  function getProblemsByDifficulty(diff) { return problemBank.filter(p => p.difficulty === diff); }
  function getProblemsByType(type) { return problemBank.filter(p => p.type === type); }

  function getVisualExplanation(topicId) { return visualExplanations[topicId] || null; }
  function getKeyPoints(topicId) { return keyPointsMap[topicId] || []; }

  return {
    getAllTopics, getTopic, getTopicIndex, getNextTopic, getPrevTopic,
    getTopicsByLevel, getAllTracks, getTrack,
    getKnowledgeMap, getProgressPercent, getExerciseStats,
    getProblemBank, getProblem, getProblemsByDifficulty, getProblemsByType,
    getVisualExplanation, getKeyPoints,
    knowledgeMaps, tracks, problemBank,
  };
})();


/**
 * VIEW: DOM References & Rendering
 * All DOM queries and UI rendering functions
 */
const DOM = (() => {
  // ---- Element References ----
  const el = {
    // Loading
    loadingOverlay: () => document.getElementById('loadingOverlay'),
    // Header
    progressBadge: () => document.getElementById('progressBadge'),
    themeToggle: () => document.getElementById('themeToggle'),
    // Layout
    appLayout: () => document.getElementById('appLayout'),
    sidebar: () => document.getElementById('sidebar'),
    // Sidebar
    sidebarSearch: () => document.getElementById('sidebarSearch'),
    curriculumNav: () => document.getElementById('curriculumNav'),
    // Tabs
    tabs: () => document.querySelectorAll('.tab'),
    lessonPanel: () => document.getElementById('lessonPanel'),
    exercisePanel: () => document.getElementById('exercisePanel'),
    problemsPanel: () => document.getElementById('problemsPanel'),
    snippetsPanel: () => document.getElementById('snippetsPanel'),
    progressPanel: () => document.getElementById('progressPanel'),
    replPanel: () => document.getElementById('replPanel'),
    packagesPanel: () => document.getElementById('packagesPanel'),
    filesPanel: () => document.getElementById('filesPanel'),
    tracksPanel: () => document.getElementById('tracksPanel'),
    // Lesson
    lessonTitle: () => document.getElementById('lessonTitle'),
    lessonContent: () => document.getElementById('lessonContent'),
    // Editor
    codeEditor: () => document.getElementById('codeEditor'),
    lineNumbers: () => document.getElementById('lineNumbers'),
    outputArea: () => document.getElementById('outputArea'),
    runBtn: () => document.getElementById('runBtn'),
    clearBtn: () => document.getElementById('clearBtn'),
    copyBtn: () => document.getElementById('copyBtn'),
    saveSnippetBtn: () => document.getElementById('saveSnippetBtn'),
    fontSlider: () => document.getElementById('fontSlider'),
    fontSizeLabel: () => document.getElementById('fontSizeLabel'),
    // REPL
    replOutput: () => document.getElementById('replOutput'),
    replInput: () => document.getElementById('replInput'),
    replSendBtn: () => document.getElementById('replSendBtn'),
    replClearBtn: () => document.getElementById('replClearBtn'),
    // Packages
    packageInput: () => document.getElementById('packageInput'),
    packageInstallBtn: () => document.getElementById('packageInstallBtn'),
    packagesList: () => document.getElementById('packagesList'),
    // Files
    fileNameInput: () => document.getElementById('fileNameInput'),
    fileContent: () => document.getElementById('fileContent'),
    createFileBtn: () => document.getElementById('createFileBtn'),
    filesList: () => document.getElementById('filesList'),
    // Problems
    problemsList: () => document.getElementById('problemsList'),
    // Chat
    chatPanel: () => document.getElementById('chatPanel'),
    chatMessages: () => document.getElementById('chatMessages'),
    chatInput: () => document.getElementById('chatInput'),
    chatSendBtn: () => document.getElementById('chatSendBtn'),
    // Settings
    settingsModal: () => document.getElementById('settingsModal'),
    apiKeyInput: () => document.getElementById('apiKeyInput'),
    modalFontSlider: () => document.getElementById('modalFontSlider'),
    modalFontLabel: () => document.getElementById('modalFontLabel'),
    // Toast
    toastContainer: () => document.getElementById('toastContainer'),
    // Snippets
    snippetsList: () => document.getElementById('snippetsList'),
  };

  // ---- Utility ----
  function escapeHtml(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ---- Toast ----
  function showToast(msg, type = 'info') {
    const container = el.toastContainer();
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = msg;
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('toast-exit');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // ---- Loading ----
  function hideLoading() { const o = el.loadingOverlay(); if (o) o.classList.add('hidden'); }
  function showLoadingError(msg) {
    el.loadingOverlay().querySelector('.loading-text').textContent = msg;
  }

  // ---- Sidebar ----
  function renderCurriculum(topics, currentId, progress, filter = '') {
    const nav = el.curriculumNav();
    nav.innerHTML = '';
    const fl = filter.toLowerCase();

    // Group by level
    const levels = ['beginner', 'intermediate', 'advanced', 'professional'];
    const levelLabels = { beginner: '🌱 Beginner', intermediate: '🌿 Intermediate', advanced: '🌳 Advanced', professional: '🏆 Professional' };

    levels.forEach(level => {
      const levelTopics = topics.filter(t => t.level === level);
      const filtered = levelTopics.filter(t =>
        !fl || t.title.toLowerCase().includes(fl) || t.id.includes(fl)
      );
      if (!filtered.length) return;

      const groupHeader = document.createElement('div');
      groupHeader.className = 'curriculum-header';
      groupHeader.textContent = levelLabels[level];
      nav.appendChild(groupHeader);

      filtered.forEach(topic => {
        const div = document.createElement('div');
        const isActive = currentId === topic.id;
        const isCompleted = progress[topic.id] && progress[topic.id].lessonDone;
        div.className = `curriculum-item${isActive ? ' active' : ''}${isCompleted ? ' completed' : ''}`;
        div.innerHTML = `<span class="icon">${topic.icon}</span> ${topic.title} <span class="check">✓</span>`;
        div.dataset.topicId = topic.id;
        nav.appendChild(div);
      });
    });
  }

  // ---- Tabs ----
  function switchTab(tabName) {
    el.tabs().forEach(t => t.classList.toggle('active', t.dataset.tab === tabName));
    const panels = ['lesson', 'exercise', 'problems', 'snippets', 'progress', 'repl', 'packages', 'files', 'tracks'];
    panels.forEach(p => {
      const panel = document.getElementById(p + 'Panel');
      if (panel) panel.classList.toggle('hidden', p !== tabName);
    });
  }

  // ---- Lesson ----
  function renderLesson(topic) {
    const lesson = topic.lessons[0];
    el.lessonTitle().textContent = lesson.title || topic.title;

    // Build the full lesson content with visuals, AI button, and summary
    let html = '';

    // AI Tutor bar
    html += `<div class="lesson-ai-bar">
      <span class="ai-icon">🤖</span>
      <div class="ai-text">
        <strong>AI Tutor Available</strong>
        <p>Get personalized help with <strong>${topic.title}</strong> — ask questions, get explanations, or request examples.</p>
      </div>
      <button class="ai-tutor-btn" onclick="DOM.askAITutor('${topic.id}')">
        💬 Ask AI Tutor
      </button>
    </div>`;

    // Visual explanation (diagrams, flowcharts)
    const visual = Curriculum.getVisualExplanation(topic.id);
    if (visual) {
      const diagramId = 'diagram-' + topic.id.replace(/[^a-z0-9]/g, '-');
      const nodeData = InteractiveDiagrams.getNodeData(topic.id);
      html += `<div class="concept-map" data-topic-id="${topic.id}">
        <h3>📊 Visual Explanation</h3>
        <div class="mermaid-wrapper" id="${diagramId}" data-diagram-id="${diagramId}">
          <div class="mermaid">${visual}</div>
          <div class="diagram-controls">
            <button class="diagram-zoom-in" title="Zoom In">+</button>
            <button class="diagram-zoom-out" title="Zoom Out">−</button>
            <button class="diagram-reset" title="Reset View">⟲</button>
          </div>
        </div>
        ${nodeData && nodeData.legend ? `<div class="diagram-legend">${nodeData.legend}</div>` : ''}
        <p style="font-size:.72rem;color:var(--text3);margin-top:8px;">
          💡 Click on any node to learn more about it
        </p>
      </div>`;
    }

    // Key points summary card
    const kps = Curriculum.getKeyPoints(topic.id);
    if (kps.length > 0) {
      html += `<div class="lesson-summary">
        <h3>📝 Key Takeaways</h3>
        <div class="key-points">`;
      kps.forEach(kp => {
        html += `<div class="key-point">
          <div class="kp-icon">${kp.icon || '💡'}</div>
          <div class="kp-title">${kp.title}</div>
          <div class="kp-desc">${kp.desc}</div>
        </div>`;
      });
      html += `</div></div>`;
    }

    // Main lesson content
    html += lesson.content;

    el.lessonContent().innerHTML = html;
    el.codeEditor().value = lesson.starterCode.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\"/g, '"');

    // Render Mermaid diagrams with interactivity
    if (visual && typeof mermaid !== 'undefined') {
      try {
        mermaid.init(undefined, el.lessonContent().querySelectorAll('.mermaid'));
        // After mermaid renders, enhance with interactivity
        setTimeout(() => {
          InteractiveDiagrams.enhanceDiagrams(el.lessonContent());
        }, 300);
      } catch(e) { console.warn('Mermaid render error:', e); }
    }
  }

  // ---- AI Tutor ----
  function askAITutor(topicId) {
    const topic = Curriculum.getTopic(topicId);
    if (!topic) return;
    // Open chat panel
    openAIChat();
    // Send a pre-filled message
    const msg = `Help me understand ${topic.title}. I'm a beginner learning Python. Please explain the key concepts and give me a simple example.`;
    el.chatInput().value = msg;
    sendChat();
  }

  // ---- Editor ----
  function updateLineNumbers() {
    const editor = el.codeEditor();
    const lines = editor.value.split('\n').length;
    const ln = el.lineNumbers();
    ln.innerHTML = Array.from({ length: lines }, (_, i) => `<div>${i + 1}</div>`).join('');
    ln.scrollTop = editor.scrollTop;
  }

  function appendOutput(text, type = 'out') {
    const outDiv = el.outputArea();
    const span = document.createElement('span');
    span.className = `${type}-text`;
    span.textContent = text + '\n';
    outDiv.appendChild(span);
    outDiv.scrollTop = outDiv.scrollHeight;
  }

  function clearOutput() {
    el.outputArea().innerHTML = '<span class="info-text">Output cleared.</span>';
  }

  function setOutput(html) {
    el.outputArea().innerHTML = html;
  }

  // ---- REPL ----
  function appendReplOutput(text, type = 'out') {
    const out = el.replOutput();
    const div = document.createElement('div');
    div.className = `repl-${type}`;
    div.textContent = text;
    out.appendChild(div);
    out.scrollTop = out.scrollHeight;
  }

  function clearRepl() {
    el.replOutput().innerHTML = '<div class="repl-info">Python REPL — type expressions or statements. Press Enter to run.</div>';
  }

  // ---- Exercises ----
  function renderExercises(topic, progress, currentIdx) {
    const panel = el.exercisePanel();
    if (!topic || !topic.exercises.length) {
      panel.innerHTML = '<p>No exercises for this topic yet.</p>';
      return;
    }
    const topicProgress = progress[topic.id] || { exercises: {} };
    let html = `<h2>${topic.icon} ${topic.title} — Exercises</h2>`;
    topic.exercises.forEach((ex, i) => {
      const done = topicProgress.exercises && topicProgress.exercises[i];
      html += `<div class="exercise-card" data-exercise-idx="${i}">
        <h3>${done ? '✅' : '📝'} Exercise ${i + 1} ${done ? '(Completed)' : ''}</h3>
        <p>${ex.problem.replace(/\n/g, '<br>')}</p>
        <div class="expected">${escapeHtml(ex.expectedOutput).replace(/\n/g, '<br>')}</div>
        <div style="display:flex;gap:8px;margin-top:12px;">
          <button class="ed-btn exercise-load-btn" data-idx="${i}">📝 Load into Editor</button>
          <button class="ed-btn run exercise-check-btn" data-idx="${i}">✅ Check Answer</button>
          <button class="ed-btn exercise-hint-btn" data-idx="${i}">💡 Hint</button>
        </div>
        <div class="test-results" id="testResults${i}" style="margin-top:12px;"></div>
      </div>`;
    });
    panel.innerHTML = html;
  }

  // ---- Test Results ----
  function renderTestResults(exerciseIdx, results) {
    const container = document.getElementById(`testResults${exerciseIdx}`);
    if (!container) return;
    const allPassed = results.every(r => r.passed);
    let html = `<div style="font-weight:bold;color:${allPassed ? 'var(--success)' : 'var(--error)'};margin-bottom:8px;">${allPassed ? '✅ All tests passed!' : '❌ Some tests failed'}</div>`;
    results.forEach((r, i) => {
      html += `<div style="padding:8px;background:var(--bg);border-radius:6px;margin-bottom:6px;border-left:3px solid ${r.passed ? 'var(--success)' : 'var(--error)'};">
        <div style="font-weight:600;">Test ${i + 1}: ${r.passed ? '✅ Pass' : '❌ Fail'} — ${escapeHtml(r.description)}</div>
        ${r.input ? `<div style="font-size:.8rem;color:var(--text3);">Input: ${escapeHtml(String(r.input))}</div>` : ''}
        <div style="font-size:.8rem;">Expected: <code>${escapeHtml(r.expected)}</code></div>
        ${!r.passed ? `<div style="font-size:.8rem;color:var(--error);">Got: <code>${escapeHtml(r.actual)}</code></div>` : ''}
      </div>`;
    });
    container.innerHTML = html;
  }

  // ---- Problems Bank ----
  function renderProblems(problems) {
    const list = el.problemsList();
    if (!problems.length) {
      list.innerHTML = '<p class="panel-empty">No problems found.</p>';
      return;
    }
    list.innerHTML = problems.map((p, i) => `
      <div class="problem-card" data-problem-idx="${i}" data-problem-id="${p.id}">
        <span class="difficulty ${p.difficulty}">${p.difficulty}</span>
        <h3>${escapeHtml(p.title)}</h3>
        <p>${escapeHtml(p.description)}</p>
        <details style="margin:8px 0;">
          <summary style="cursor:pointer;color:var(--accent);font-size:.85rem;">💡 Show Hint</summary>
          <div style="padding:8px;background:var(--bg);border-radius:6px;margin-top:6px;font-size:.85rem;color:var(--text2);">${escapeHtml(p.hint)}</div>
        </details>
        <details style="margin:8px 0;">
          <summary style="cursor:pointer;color:var(--warning);font-size:.85rem;">🔑 Show Solution</summary>
          <pre style="padding:8px;background:var(--bg);border-radius:6px;margin-top:6px;font-size:.82rem;overflow-x:auto;"><code>${escapeHtml(p.solution)}</code></pre>
        </details>
        <div class="problem-actions">
          <button class="ed-btn run problem-load-btn" data-idx="${i}">📝 Load & Solve</button>
          <button class="ed-btn problem-check-btn" data-idx="${i}">✅ Run Tests</button>
        </div>
        <div class="problem-test-results" id="problemResults${i}" style="margin-top:12px;"></div>
      </div>
    `).join('');
  }

  function renderProblemResults(problemIdx, results) {
    const container = document.getElementById(`problemResults${problemIdx}`);
    if (!container) return;
    const allPassed = results.every(r => r.passed);
    let html = `<div style="font-weight:bold;color:${allPassed ? 'var(--success)' : 'var(--error)'};margin-bottom:8px;">${allPassed ? '✅ All tests passed!' : '❌ Some tests failed'}</div>`;
    results.forEach((r, i) => {
      html += `<div class="test-case-result ${r.passed ? 'pass' : 'fail'}">
        <div style="font-weight:600;">Test ${i + 1}: ${r.passed ? '✅ Pass' : '❌ Fail'} — ${escapeHtml(r.description)}</div>
        ${r.input ? `<div style="font-size:.8rem;color:var(--text3);">Input: ${escapeHtml(JSON.stringify(r.input))}</div>` : ''}
        <div style="font-size:.8rem;">Expected: <code>${escapeHtml(r.expected)}</code></div>
        ${!r.passed ? `<div style="font-size:.8rem;color:var(--error);">Got: <code>${escapeHtml(r.actual)}</code></div>` : ''}
      </div>`;
    });
    container.innerHTML = html;
  }

  // ---- Snippets ----
  function renderSnippets(snippets) {
    const panel = el.snippetsList();
    if (!snippets.length) {
      panel.innerHTML = '<p style="color:var(--text3);">No snippets saved yet.</p>';
      return;
    }
    panel.innerHTML = snippets.map((s, i) => `
      <div class="snippet-card" data-snippet-idx="${i}">
        <h4>${escapeHtml(s.name)}</h4>
        <pre>${escapeHtml(s.code.substring(0, 120))}${s.code.length > 120 ? '...' : ''}</pre>
        <div class="snippet-actions">
          <button class="ed-btn snippet-load-btn" data-idx="${i}">Load</button>
          <button class="ed-btn snippet-delete-btn" data-idx="${i}" style="color:var(--error);">Delete</button>
          <span style="margin-left:auto;font-size:.75rem;color:var(--text3);">${s.date}</span>
        </div>
      </div>
    `).join('');
  }

  // ---- Progress ----
  function renderProgressPanel(progress, streak) {
    const panel = el.progressPanel();
    const pct = Curriculum.getProgressPercent(progress);
    const exStats = Curriculum.getExerciseStats(progress);
    const topics = Curriculum.getAllTopics();
    const completedTopics = topics.filter(t => progress[t.id] && progress[t.id].lessonDone).length;

    let html = `<h2>📊 Your Progress</h2>
      <div class="progress-overview">
        <div class="stat-card"><div class="stat-value">${completedTopics}/${topics.length}</div><div class="stat-label">Topics Visited</div></div>
        <div class="stat-card"><div class="stat-value">${exStats.done}/${exStats.total}</div><div class="stat-label">Exercises Done</div></div>
        <div class="stat-card"><div class="stat-value">${pct}%</div><div class="stat-label">Overall Progress</div></div>
        <div class="stat-card"><div class="stat-value">🔥 ${streak}</div><div class="stat-label">Day Streak</div></div>
      </div>
      <div class="progress-bar-container"><div class="progress-bar-fill" style="width:${pct}%"></div></div>
      <div class="topic-progress-list">`;

    topics.forEach(t => {
      const tp = progress[t.id] || {};
      const exCount = t.exercises.length;
      const exDone = tp.exercises ? Object.keys(tp.exercises).length : 0;
      let status = 'todo', statusText = 'Not started';
      if (tp.lessonDone && exDone >= exCount) { status = 'done'; statusText = 'Completed'; }
      else if (tp.lessonDone) { status = 'partial'; statusText = `${exDone}/${exCount} exercises`; }
      html += `<div class="topic-progress-item">
        <span class="tp-icon">${t.icon}</span>
        <span class="tp-name">${t.title} <span style="font-size:.75rem;color:var(--text3);text-transform:uppercase;">(${t.level})</span></span>
        <span class="tp-status ${status}">${statusText}</span>
      </div>`;
    });
    html += '</div>';
    panel.innerHTML = html;
  }

  // ---- Packages ----
  function renderPackagesList(packages) {
    const list = el.packagesList();
    if (!packages.length) {
      list.innerHTML = '<p style="color:var(--text3);font-size:.85rem;">No packages installed yet.</p>';
      return;
    }
    list.innerHTML = packages.map(p => `<span class="pkg-tag">📦 ${escapeHtml(p)}</span>`).join('');
  }

  // ---- Virtual Files ----
  function renderFilesList(files) {
    const list = el.filesList();
    const fileNames = Object.keys(files);
    if (!fileNames.length) {
      list.innerHTML = '<p style="color:var(--text3);font-size:.85rem;">No virtual files yet.</p>';
      return;
    }
    list.innerHTML = fileNames.map(f => `
      <div class="file-item" style="display:flex;align-items:center;gap:8px;padding:8px;background:var(--bg);border-radius:6px;margin-bottom:6px;">
        <span style="flex:1;font-family:var(--font-mono);font-size:.85rem;">📄 ${escapeHtml(f)}</span>
        <button class="ed-btn file-load-btn" data-path="${escapeHtml(f)}" style="padding:4px 10px;font-size:.75rem;">Load</button>
        <button class="ed-btn file-delete-btn" data-path="${escapeHtml(f)}" style="padding:4px 10px;font-size:.75rem;color:var(--error);">Delete</button>
      </div>
    `).join('');
  }

  // ---- Tracks ----
  function renderTracks(tracks) {
    const panel = el.tracksPanel();
    let html = '<h2>🎯 Learning Tracks</h2><p style="color:var(--text2);margin-bottom:20px;">Choose a track to focus on specific skills for your career path. Click any track to explore its topics.</p>';
    tracks.forEach(track => {
      const topicCount = track.topics.length;
      html += `<div class="track-card" data-track-id="${track.id}">
        <div class="track-card-header">
          <span class="track-icon">${track.icon}</span>
          <div class="track-info">
            <h3>${track.title}</h3>
            <p>${track.description}</p>
          </div>
          <span class="track-count">${topicCount} topics →</span>
        </div>
        <div class="track-topics-preview">
          ${track.topics.slice(0, 4).map(t => {
            const tp = Curriculum.getTopic(t);
            return `<span class="track-topic-tag">${tp ? tp.icon + ' ' + tp.title : t}</span>`;
          }).join('')}
          ${track.topics.length > 4 ? `<span class="track-topic-tag more">+${track.topics.length - 4} more</span>` : ''}
        </div>
      </div>`;
    });
    panel.innerHTML = html;
    // Event delegation for track cards
    panel.addEventListener('click', function trackListHandler(e) {
      const card = e.target.closest('.track-card');
      if (card) {
        const trackId = card.dataset.trackId;
        const track = Curriculum.getTrack(trackId);
        if (track) {
          panel.removeEventListener('click', trackListHandler);
          renderTrackDetail(track);
        }
      }
    });
  }

  function renderTrackDetail(track) {
    const panel = el.tracksPanel();
    let html = `<button class="track-back-btn" id="trackBackBtn">← Back to Tracks</button>`;
    html += `<div class="track-detail-header">
      <span class="track-icon-large">${track.icon}</span>
      <div>
        <h2>${track.title}</h2>
        <p class="track-detail-desc">${track.description}</p>
      </div>
    </div>`;
    html += `<div class="track-detail-stats">
      <div class="track-stat"><span class="track-stat-num">${track.topics.length}</span><span class="track-stat-label">Topics</span></div>
      <div class="track-stat"><span class="track-stat-num">${track.topics.filter(t => { const tp = Curriculum.getTopic(t); return tp && tp.exercises.length > 0; }).length}</span><span class="track-stat-label">Exercises</span></div>
      <div class="track-stat"><span class="track-stat-num">${new Set(track.topics.map(t => { const tp = Curriculum.getTopic(t); return tp ? tp.level : ''; }).filter(Boolean)).size}</span><span class="track-stat-label">Levels</span></div>
    </div>`;
    html += `<h3 class="track-section-title">📚 Topics in this Track</h3>`;
    html += `<div class="track-topics-list">`;
    track.topics.forEach((topicId, idx) => {
      const tp = Curriculum.getTopic(topicId);
      if (!tp) return;
      const kp = Curriculum.getKeyPoints(topicId);
      const levelColors = { beginner: 'var(--success)', intermediate: 'var(--accent)', advanced: 'var(--warning)', professional: 'var(--error)' };
      html += `<div class="track-topic-card" data-topic-id="${tp.id}">
        <div class="track-topic-num">${idx + 1}</div>
        <div class="track-topic-body">
          <div class="track-topic-top">
            <span class="track-topic-icon">${tp.icon}</span>
            <span class="track-topic-title">${tp.title}</span>
            <span class="track-topic-level" style="color:${levelColors[tp.level] || 'var(--text3)'}">${tp.level}</span>
          </div>
          <p class="track-topic-desc">${tp.description || tp.lessons[0].title || ''}</p>
          ${kp.length > 0 ? `<div class="track-topic-kps">
            ${kp.slice(0, 3).map(k => `<span class="track-kp-tag">${k.icon} ${k.title}</span>`).join('')}
          </div>` : ''}
          <div class="track-topic-meta">
            <span>📝 ${tp.exercises.length} exercises</span>
            <span>📖 ${tp.lessons.length} lesson${tp.lessons.length > 1 ? 's' : ''}</span>
          </div>
        </div>
        <button class="track-topic-start-btn" data-topic-id="${tp.id}">Start →</button>
      </div>`;
    });
    html += `</div>`;

    // AI Tutor section for the track
    html += `<div class="track-ai-section">
      <div class="track-ai-icon">🤖</div>
      <div class="track-ai-text">
        <strong>AI Tutor for ${track.title}</strong>
        <p>Get personalized guidance through this entire learning track. Ask questions, get explanations, and practice with AI.</p>
      </div>
      <button class="ai-tutor-btn" id="trackAiBtn" data-track-id="${track.id}">💬 Ask AI Tutor</button>
    </div>`;

    panel.innerHTML = html;

    // Event delegation for track detail view
    panel.addEventListener('click', function trackDetailHandler(e) {
      // Back button
      if (e.target.closest('#trackBackBtn')) {
        panel.removeEventListener('click', trackDetailHandler);
        renderTracks(Curriculum.getAllTracks());
        return;
      }
      // Start button on topic card
      const startBtn = e.target.closest('.track-topic-start-btn');
      if (startBtn) {
        const tid = startBtn.dataset.topicId;
        if (tid) UI.loadTopic(tid);
        return;
      }
      // Topic card click
      const topicCard = e.target.closest('.track-topic-card');
      if (topicCard) {
        const tid = topicCard.dataset.topicId;
        if (tid) UI.loadTopic(tid);
        return;
      }
      // AI Tutor button
      const aiBtn = e.target.closest('#trackAiBtn');
      if (aiBtn) {
        const trid = aiBtn.dataset.trackId;
        if (trid) askTrackAITutor(trid);
        return;
      }
    });
  }

  function askTrackAITutor(trackId) {
    const track = Curriculum.getTrack(trackId);
    if (!track) return;
    openAIChat();
    const topicList = track.topics.map(t => {
      const tp = Curriculum.getTopic(t);
      return tp ? tp.title : t;
    }).join(', ');
    const msg = `I'm starting the ${track.title} learning track. The topics are: ${topicList}. Help me understand what I should focus on first and how to approach this track. I'm a beginner learning Python.`;
    el.chatInput().value = msg;
    sendChat();
  }

  // ---- Chat ----
  function openAIChat() {
    const overlay = document.getElementById('aiChatOverlay');
    if (overlay) overlay.classList.add('open');
  }

  function addChatMsg(text, sender) {
    const div = document.createElement('div');
    div.className = `chat-msg ${sender}`;
    div.innerHTML = text
      .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\n/g, '<br>');
    el.chatMessages().appendChild(div);
    div.scrollIntoView({ behavior: 'smooth' });
  }

  function removeLastChatMsg() {
    const msgs = el.chatMessages();
    if (msgs.lastChild) msgs.removeChild(msgs.lastChild);
  }

  // ---- Progress Badge ----
  function updateProgressBadge(pct) {
    el.progressBadge().textContent = `${pct}% Complete`;
  }

  // ---- Font Size ----
  function applyFontSize(fs) {
    document.documentElement.style.setProperty('--editor-fs', fs + 'px');
    el.fontSlider().value = fs;
    el.fontSizeLabel().textContent = fs + 'px';
  }

  // ---- Theme ----
  function setThemeIcon(isLight) {
    el.themeToggle().textContent = isLight ? '☾' : '🌙';
  }

  return {
    el, escapeHtml, showToast, hideLoading, showLoadingError,
    renderCurriculum, switchTab, renderLesson,
    updateLineNumbers, appendOutput, clearOutput, setOutput,
    appendReplOutput, clearRepl,
    renderExercises, renderTestResults,
    renderProblems, renderProblemResults,
    renderSnippets, renderProgressPanel,
    renderPackagesList, renderFilesList, renderTracks,
    addChatMsg, removeLastChatMsg,
    updateProgressBadge, applyFontSize, setThemeIcon,
    askAITutor, askTrackAITutor,
  };
})();


/**
 * VIEW MODEL: Editor Controller
 * Handles code editor, REPL, run/clear/copy, virtual files, package installer
 */
const EditorVM = (() => {
  let _currentTopicId = null;
  let _currentExerciseIdx = 0;
  let _replHistory = [];
  let _replHistoryIdx = -1;

  function init() {
    const editor = DOM.el.codeEditor();

    // Editor events
    editor.addEventListener('input', () => { DOM.updateLineNumbers(); autoSave(); });
    editor.addEventListener('scroll', () => { DOM.el.lineNumbers().scrollTop = editor.scrollTop; });
    editor.addEventListener('keydown', handleEditorKeydown);

    // Buttons
    DOM.el.runBtn().addEventListener('click', runCode);
    DOM.el.clearBtn().addEventListener('click', () => {
      editor.value = '';
      DOM.updateLineNumbers();
      DOM.setOutput('<span class="info-text">Editor cleared.</span>');
    });
    DOM.el.copyBtn().addEventListener('click', () => {
      navigator.clipboard.writeText(editor.value)
        .then(() => DOM.showToast('Copied! 📋', 'success'))
        .catch(() => DOM.showToast('Copy failed', 'error'));
    });
    DOM.el.saveSnippetBtn().addEventListener('click', saveSnippet);
    document.getElementById('debugBtn').addEventListener('click', runCodeDebug);

    // Font slider
    DOM.el.fontSlider().addEventListener('input', function () {
      DOM.applyFontSize(this.value);
      State.setSetting('fontsize', this.value);
    });

    // REPL
    DOM.el.replSendBtn().addEventListener('click', runReplLine);
    DOM.el.replInput().addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); runReplLine(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); navigateReplHistory(-1); }
      if (e.key === 'ArrowDown') { e.preventDefault(); navigateReplHistory(1); }
    });
    DOM.el.replClearBtn().addEventListener('click', () => { DOM.clearRepl(); });

    // Package installer
    DOM.el.packageInstallBtn().addEventListener('click', installPackage);
    DOM.el.packageInput().addEventListener('keydown', (e) => {
      if (e.key === 'Enter') installPackage();
    });

    // Virtual files
    DOM.el.createFileBtn().addEventListener('click', createVirtualFile);

    // Wire up stdin so input() works in scripts
    PyodideEngine.onStdin(() => {
      const val = prompt('Python input():');
      return val !== null ? val : '';
    });

    // Restore code
    const savedCode = State.getCode();
    if (savedCode) { editor.value = savedCode; DOM.updateLineNumbers(); }

    // REPL history
    _replHistory = State.getReplHistory();
  }

  // ---- Editor Keydown ----
  function handleEditorKeydown(e) {
    const editor = DOM.el.codeEditor();
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = editor.selectionStart;
      editor.value = editor.value.substring(0, start) + '    ' + editor.value.substring(editor.selectionEnd);
      editor.selectionStart = editor.selectionEnd = start + 4;
      DOM.updateLineNumbers();
    }
    if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); runCode(); }
    if (e.key === 's' && e.ctrlKey) { e.preventDefault(); saveSnippet(); }
  }

  // ---- Run Code ----
  async function runCode() {
    if (!PyodideEngine.isReady()) { DOM.showToast('Python is still loading...', 'error'); return; }
    const code = DOM.el.codeEditor().value;
    DOM.setOutput('<span class="info-text">Running...</span>');
    DOM.el.runBtn().disabled = true;

    const { stdout, stderr, error } = await PyodideEngine.runScript(code);
    let html = '';
    if (stdout) html += `<span class="out-text">${DOM.escapeHtml(stdout)}</span>`;
    if (stderr) html += `<span class="err-text">${DOM.escapeHtml(stderr)}</span>`;
    if (error) html += `<span class="err-text">${DOM.escapeHtml(error.message)}</span>`;
    if (!stdout && !stderr && !error) html = '<span class="info-text">Code executed successfully (no output).</span>';
    DOM.setOutput(html);
    DOM.el.runBtn().disabled = false;
  }

  // ---- Run Code with Debug Trace ----
  async function runCodeDebug() {
    if (!PyodideEngine.isReady()) { DOM.showToast('Python is still loading...', 'error'); return; }
    const code = DOM.el.codeEditor().value;
    DOM.setOutput('<span class="info-text">Running with debug trace...</span>');
    DOM.el.runBtn().disabled = true;

    const { error } = await PyodideEngine.runWithTrace(code);
    if (error) {
      DOM.setOutput(`<span class="err-text">${DOM.escapeHtml(error.message)}</span>`);
    } else {
      DOM.setOutput('<span class="info-text">Code executed (check browser console for trace).</span>');
    }
    DOM.el.runBtn().disabled = false;
  }

  // ---- REPL ----
  async function runReplLine() {
    if (!PyodideEngine.isReady()) { DOM.appendReplOutput('Python not ready yet.', 'err'); return; }
    const input = DOM.el.replInput();
    const code = input.value.trim();
    if (!code) return;

    // Add to history
    _replHistory.push(code);
    _replHistoryIdx = _replHistory.length;
    State.saveReplHistory(_replHistory);

    DOM.appendReplOutput(`>>> ${code}`, 'in');
    input.value = '';

    const { stdout, stderr, result, error } = await PyodideEngine.runLine(code);
    if (stdout) DOM.appendReplOutput(stdout, 'out');
    if (stderr) DOM.appendReplOutput(stderr, 'err');
    if (error) DOM.appendReplOutput(error.message, 'err');
    if (result !== undefined) DOM.appendReplOutput(`← ${result}`, 'result');
  }

  function navigateReplHistory(dir) {
    if (!_replHistory.length) return;
    _replHistoryIdx += dir;
    if (_replHistoryIdx < 0) _replHistoryIdx = 0;
    if (_replHistoryIdx >= _replHistory.length) {
      _replHistoryIdx = _replHistory.length;
      DOM.el.replInput().value = '';
      return;
    }
    DOM.el.replInput().value = _replHistory[_replHistoryIdx];
  }

  // ---- Auto Save ----
  function autoSave() { State.saveCode(DOM.el.codeEditor().value); }

  // ---- Snippets ----
  function saveSnippet() {
    const code = DOM.el.codeEditor().value.trim();
    if (!code) { DOM.showToast('Editor is empty!', 'error'); return; }
    const name = prompt('Snippet name:', `Snippet ${State.getSnippets().length + 1}`);
    if (!name) return;
    const snippets = State.getSnippets();
    snippets.push({ name, code, date: new Date().toLocaleDateString() });
    State.saveSnippets(snippets);
    DOM.showToast('Snippet saved! 💾', 'success');
    if (DOM.el.snippetsPanel() && !DOM.el.snippetsPanel().classList.contains('hidden')) {
      DOM.renderSnippets(snippets);
    }
  }

  function loadSnippet(idx) {
    const s = State.getSnippets()[idx];
    if (s) { DOM.el.codeEditor().value = s.code; DOM.updateLineNumbers(); DOM.showToast('Snippet loaded!', 'info'); }
  }

  function deleteSnippet(idx) {
    const snippets = State.getSnippets();
    snippets.splice(idx, 1);
    State.saveSnippets(snippets);
    DOM.renderSnippets(snippets);
    DOM.showToast('Snippet deleted.', 'info');
  }

  // ---- Package Installer ----
  async function installPackage() {
    if (!PyodideEngine.isReady()) { DOM.showToast('Python not ready', 'error'); return; }
    const input = DOM.el.packageInput();
    const name = input.value.trim();
    if (!name) return;

    DOM.appendOutput(`Installing ${name}...`, 'info');
    const { success, error } = await PyodideEngine.installPackage(name);
    if (success) {
      DOM.showToast(`✅ ${name} installed!`, 'success');
      input.value = '';
      DOM.renderPackagesList(PyodideEngine.getInstalledPackages());
    } else {
      DOM.showToast(`Failed to install ${name}: ${error}`, 'error');
    }
  }

  // ---- Virtual Files ----
  function createVirtualFile() {
    if (!PyodideEngine.isReady()) { DOM.showToast('Python not ready', 'error'); return; }
    const name = DOM.el.fileNameInput().value.trim();
    const content = DOM.el.fileContent().value;
    if (!name) { DOM.showToast('Enter a file name', 'error'); return; }

    PyodideEngine.writeVirtualFile(name, content);
    DOM.showToast(`File "${name}" created!`, 'info');
    DOM.el.fileNameInput().value = '';
    DOM.el.fileContent().value = '';
    DOM.renderFilesList(State.getVirtualFiles());
  }

  function loadFile(path) {
    const files = State.getVirtualFiles();
    if (files[path]) {
      DOM.el.codeEditor().value = files[path];
      DOM.updateLineNumbers();
      DOM.showToast(`Loaded "${path}"`, 'info');
    }
  }

  function deleteFile(path) {
    PyodideEngine.deleteVirtualFile(path);
    DOM.showToast(`Deleted "${path}"`, 'info');
    DOM.renderFilesList(State.getVirtualFiles());
  }

  // ---- Setters ----
  function setCurrentTopic(id) { _currentTopicId = id; }
  function setCurrentExerciseIdx(idx) { _currentExerciseIdx = idx; }
  function getCurrentTopicId() { return _currentTopicId; }
  function getCurrentExerciseIdx() { return _currentExerciseIdx; }

  return {
    init, runCode, runCodeDebug, runReplLine, autoSave,
    saveSnippet, loadSnippet, deleteSnippet,
    installPackage, createVirtualFile, loadFile, deleteFile,
    setCurrentTopic, setCurrentExerciseIdx, getCurrentTopicId, getCurrentExerciseIdx,
  };
})();


/**
 * VIEW MODEL: Exercise Engine
 * Handles exercise loading, checking, test case validation, hints
 */
const ExercisesVM = (() => {
  let _currentTopicId = null;
  let _currentExerciseIdx = 0;

  function normalizeAnswerText(text) {
    return String(text || '')
      .replace(/\r\n/g, '\n')
      .replace(/\r/g, '\n')
      .replace(/\t/g, ' ')
      .split('\n')
      .map(line => line.trim())
      .join('\n')
      .trim();
  }

  function init() {
    // Event delegation for exercise panel
    DOM.el.exercisePanel().addEventListener('click', handleExerciseClick);
  }

  function handleExerciseClick(e) {
    const loadBtn = e.target.closest('.exercise-load-btn');
    const checkBtn = e.target.closest('.exercise-check-btn');
    const hintBtn = e.target.closest('.exercise-hint-btn');

    if (loadBtn) loadExercise(parseInt(loadBtn.dataset.idx));
    if (checkBtn) checkAnswer(parseInt(checkBtn.dataset.idx));
    if (hintBtn) showHint(parseInt(hintBtn.dataset.idx));
  }

  function setCurrentTopic(id) { _currentTopicId = id; }

  function render() {
    const topic = Curriculum.getTopic(_currentTopicId);
    const progress = State.getProgress();
    DOM.renderExercises(topic, progress, _currentExerciseIdx);
  }

  function loadExercise(idx) {
    const topic = Curriculum.getTopic(_currentTopicId);
    if (!topic) return;
    _currentExerciseIdx = idx;
    const ex = topic.exercises[idx];
    DOM.el.codeEditor().value = ex.starterCode.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\"/g, '"');
    DOM.updateLineNumbers();
    DOM.showToast('Exercise loaded into editor!', 'info');
  }

  async function checkAnswer(idx) {
    if (!PyodideEngine.isReady()) { DOM.showToast('Python is still loading...', 'error'); return; }
    const topic = Curriculum.getTopic(_currentTopicId);
    if (!topic) return;
    const ex = topic.exercises[idx];
    const code = DOM.el.codeEditor().value;

    // Use test cases if available, otherwise fall back to string comparison
    if (ex.testCases && ex.testCases.length > 0) {
      const results = await PyodideEngine.runWithTestCases(code, ex.testCases);
      DOM.renderTestResults(idx, results);

      const allPassed = results.every(r => r.passed);
      if (allPassed) {
        markExerciseComplete(idx);
        DOM.showToast('✅ All tests passed!', 'success');
      } else {
        DOM.showToast('❌ Some tests failed. Try again!', 'error');
      }
    } else {
      // Legacy string comparison
      const { stdout, stderr, error } = await PyodideEngine.runScript(code);
      const output = stdout;
      var expected = ex.expectedOutput.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\r\n/g, '\n').trim();
      var expectedClean = normalizeAnswerText(expected);
      var outputClean = normalizeAnswerText(output);

      if (error) {
        DOM.setOutput(`<span class="err-text">${DOM.escapeHtml(error.message)}</span>`);
        DOM.showToast('Error in code!', 'error');
      } else if (outputClean === expectedClean || outputClean.replace(/\s+/g, ' ') === expectedClean.replace(/\s+/g, ' ')) {
        DOM.setOutput(`<span class="out-text">${DOM.escapeHtml(outputClean)}</span><br><br><span style="color:var(--success);font-weight:bold;">✅ Correct! Great job!</span>`);
        markExerciseComplete(idx);
        DOM.showToast('✅ Exercise completed!', 'success');
      } else {
        DOM.setOutput(`<span class="out-text">${DOM.escapeHtml(outputClean)}</span><br><br><span class="err-text">❌ Output doesn't match expected.<br>Expected:<br>${DOM.escapeHtml(expectedClean)}<br>Got:<br>${DOM.escapeHtml(outputClean)}</span>`);
        DOM.showToast('Not quite right. Try again!', 'error');
      }
    }
  }

  function markExerciseComplete(idx) {
    const progress = State.getProgress();
    if (!progress[_currentTopicId]) progress[_currentTopicId] = { lessonDone: true, exercises: {} };
    if (!progress[_currentTopicId].exercises) progress[_currentTopicId].exercises = {};
    progress[_currentTopicId].exercises[idx] = true;
    State.saveProgress(progress);
    DOM.updateProgressBadge(Curriculum.getProgressPercent(progress));
    render();
  }

  function showHint(idx) {
    const topic = Curriculum.getTopic(_currentTopicId);
    if (!topic || !topic.exercises.length) {
      ChatVM.addBotMsg('Select a topic and load an exercise first!');
      return;
    }
    const ex = topic.exercises[idx] || topic.exercises[0];
    ChatVM.addUserMsg('Give me a hint!');
    ChatVM.addBotMsg(`💡 **Hint for Exercise ${idx + 1}:**\n\n${ex.hint}\n\nGive it a try and check your answer!`);
  }

  function getCurrentTopicId() { return _currentTopicId; }
  return { init, setCurrentTopic, getCurrentTopicId, render, loadExercise, checkAnswer, showHint };
})();


/**
 * VIEW MODEL: Problems Engine
 * Handles interview problem bank — loading, filtering, test case validation
 */
const ProblemsVM = (() => {
  let _currentFilter = 'all';
  let _problems = [];

  function init() {
    _problems = Curriculum.getProblemBank();
  }

  function render() {
    const filtered = _currentFilter === 'all'
      ? _problems
      : _problems.filter(p => p.difficulty === _currentFilter);
    DOM.renderProblems(filtered);
  }

  function filterProblems(filter) {
    _currentFilter = filter;
    // Update active button
    document.querySelectorAll('.problems-filter').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.filter === filter);
    });
    render();
  }

  function loadProblem(idx) {
    const filtered = _currentFilter === 'all'
      ? _problems
      : _problems.filter(p => p.difficulty === _currentFilter);
    const problem = filtered[idx];
    if (!problem) return;
    DOM.el.codeEditor().value = problem.starterCode;
    DOM.updateLineNumbers();
    DOM.showToast(`Loaded: ${problem.title}`, 'info');
  }

  async function checkProblem(idx) {
    if (!PyodideEngine.isReady()) { DOM.showToast('Python is still loading...', 'error'); return; }
    const filtered = _currentFilter === 'all'
      ? _problems
      : _problems.filter(p => p.difficulty === _currentFilter);
    const problem = filtered[idx];
    if (!problem) return;
    const code = DOM.el.codeEditor().value;

    // Build test cases from problem data
    const testCases = problem.testCases.map(tc => ({
      input: tc.input,
      expected: tc.expected,
      description: tc.description,
    }));

    const results = await PyodideEngine.runWithTestCases(code, testCases);
    DOM.renderProblemResults(idx, results);

    const allPassed = results.every(r => r.passed);
    if (allPassed) {
      DOM.showToast('✅ All tests passed! Great job!', 'success');
    } else {
      DOM.showToast('❌ Some tests failed. Try again!', 'error');
    }
  }

  return { init, render, filterProblems, loadProblem, checkProblem };
})();


/**
 * VIEW MODEL: AI Chat
 * Handles AI tutor chat with knowledge maps and progression intelligence
 */
const ChatVM = (() => {
  const knowledgeResponses = {
    variable: "📦 **Variables** in Python are created by simple assignment:\n```\nname = \"Alice\"\nage = 25\npi = 3.14\n```\nNo need to declare types — Python figures it out! Use `type(x)` to check a variable's type.",
    string: "🔤 **Strings** are sequences of characters:\n```\ntext = \"Hello, World!\"\nprint(text.upper())    # HELLO, WORLD!\nprint(text[::-1])     # Reversed\n```\nKey methods: `.upper()`, `.lower()`, `.strip()`, `.split()`, `.replace()`, `.find()`",
    list: "📋 **Lists** are ordered, mutable collections:\n```\nfruits = [\"apple\", \"banana\"]\nfruits.append(\"cherry\")\nsquares = [x**2 for x in range(5)]\n```\nKey methods: `.append()`, `.insert()`, `.remove()`, `.pop()`, `.sort()`",
    dict: "📖 **Dictionaries** store key-value pairs:\n```\nperson = {\"name\": \"Alice\", \"age\": 30}\nprint(person[\"name\"])\nfor k, v in person.items():\n    print(f\"{k}: {v}\")\n```",
    loop: "🔁 **Loops** repeat code:\n```\nfor i in range(5): print(i)\nn = 5\nwhile n > 0:\n    print(n)\n    n -= 1\n```\nUse `break` to exit, `continue` to skip, `enumerate()` for index+value.",
    function: "⚡ **Functions** are defined with `def`:\n```\ndef greet(name):\n    return f\"Hello, {name}!\"\nprint(greet(\"Alice\"))\n```\nSupports default args, *args, **kwargs, and lambda functions.",
    class: "🏗️ **Classes** in Python:\n```\nclass Dog:\n    def __init__(self, name):\n        self.name = name\n    def bark(self):\n        return f\"{self.name} says Woof!\"\nbuddy = Dog(\"Buddy\")\nprint(buddy.bark())\n```",
    error: "🛡️ **Error Handling** with try/except:\n```\ntry:\n    result = 10 / 0\nexcept ZeroDivisionError:\n    print(\"Can't divide by zero!\")\nfinally:\n    print(\"Done\")\n```",
    import: "📦 **Modules** extend Python's capabilities:\n```\nimport math\nprint(math.pi)\nfrom random import randint\nprint(randint(1, 100))\n```",
    tuple: "🎯 **Tuples** are immutable sequences:\n```\npoint = (3, 4)\nx, y = point  # Unpacking\na, b = 10, 20\na, b = b, a   # Swap!\n```",
    set: "🎯 **Sets** hold unique values:\n```\nnums = {1, 2, 2, 3}  # {1, 2, 3}\na = {1,2,3}\nb = {2,3,4}\nprint(a & b)  # {2, 3}\nprint(a | b)  # {1,2,3,4}\n```",
    file: "📁 **File Handling**:\n```\nwith open(\"file.txt\", \"w\") as f:\n    f.write(\"Hello!\")\nwith open(\"file.txt\", \"r\") as f:\n    content = f.read()\n```",
    decorator: "✨ **Decorators** modify function behavior:\n```\ndef timer(func):\n    import time\n    def wrapper(*args):\n        start = time.time()\n        result = func(*args)\n        print(f\"Took {time.time()-start:.4f}s\")\n        return result\n    return wrapper\n\n@timer\ndef slow():\n    sum(range(1000000))\n```",
    comprehension: "💡 **Comprehensions** create collections concisely:\n```\nsquares = [x**2 for x in range(10)]\nd = {x: x**2 for x in range(5)}\ns = {x%3 for x in range(10)}\nevens = [x for x in range(20) if x%2==0]\n```",
    fstring: "🔤 **F-strings** (Python 3.6+):\n```\nname = \"Alice\"\nage = 30\nprint(f\"Name: {name}, Age: {age}\")\nprint(f\"Pi: {3.14159:.2f}\")\n```",
    lambda: "⚡ **Lambda** = anonymous one-line functions:\n```\nsquare = lambda x: x**2\nnums = sorted([3,1,2], key=lambda x: -x)\nevens = list(filter(lambda x: x%2==0, range(10)))\n```",
    recursion: "🔄 **Recursion** = function calling itself:\n```\ndef factorial(n):\n    if n <= 1: return 1\n    return n * factorial(n-1)\n```\nAlways need a base case! Use `@lru_cache` for memoization.",
    generator: "⚙️ **Generators** use `yield` to produce values lazily:\n```\ndef fibonacci():\n    a, b = 0, 1\n    while True:\n        yield a\n        a, b = b, a + b\n\nfib = fibonacci()\nfor _ in range(10): print(next(fib))\n```",
    async: "🔀 **Async/Await** for concurrent code:\n```\nimport asyncio\nasync def fetch(url):\n    await asyncio.sleep(1)\n    return f\"Data from {url}\"\n\nasync def main():\n    results = await asyncio.gather(\n        fetch(\"url1\"), fetch(\"url2\")\n    )\nasyncio.run(main())\n```",
    testing: "🧪 **Testing** with pytest:\n```\ndef add(a, b): return a + b\ndef test_add():\n    assert add(2, 3) == 5\n    assert add(-1, 1) == 0\n```\nRun with: `pytest test_file.py`",
    oop: "🏗️ **OOP** pillars:\n- **Encapsulation**: Bundle data + methods\n- **Inheritance**: Child extends parent\n- **Polymorphism**: Same interface, different behavior\n- **Abstraction`: Hide complex implementation",
    context: "🔒 **Context Managers** ensure cleanup:\n```\nwith open(\"file.txt\") as f:\n    data = f.read()\n# File auto-closed!\n\nfrom contextlib import contextmanager\n@contextmanager\ndef timer():\n    import time\n    start = time.time()\n    yield\n    print(f\"{time.time()-start:.4f}s\")\n```",
    memory: "🧮 **Memory Management** — Python uses reference counting + GC:\n```\nimport sys, copy\nx = [1, 2, 3]\nprint(sys.getrefcount(x))\n\n# Shallow vs Deep copy\na = [[1,2],[3,4]]\nb = copy.copy(a)    # inner objects shared\nc = copy.deepcopy(a)  # fully independent\n```",
    logging: "🔍 **Logging** is better than print() for production:\n```\nimport logging\nlogging.basicConfig(level=logging.INFO, format=\"%(levelname)s: %(message)s\")\nlogging.info(\"App started\")\nlogging.warning(\"Low disk space\")\nlogging.error(\"Failed to connect\")\n```",
    module: "📦 **Modules** extend Python:\n```\nimport math\nfrom random import randint\nimport json\ndata = {\"name\": \"Alice\"}\nprint(json.dumps(data))\n```",
    debug: "🐛 **Debugging** with pdb:\n```\nimport pdb\ndef buggy():\n    x = 10\n    pdb.set_trace()  # breakpoint\n    return x\n# Commands: n(next), s(step), c(continue), p(print), q(quit)\n```",
    closure: "🔐 **Closures** remember variables from enclosing scope:\n```\ndef make_multiplier(n):\n    def multiplier(x):\n        return x * n  # n is 'closed over'\n    return multiplier\n\ndouble = make_multiplier(2)\nprint(double(5))  # 10\n```\nClosures are the foundation of decorators!",
    threading: "🧵 **Multithreading** for I/O-bound tasks:\n```\nimport threading\nfrom concurrent.futures import ThreadPoolExecutor\n\ndef fetch(url):\n    return f\"Data from {url}\"\n\nurls = [\"url1.com\", \"url2.com\", \"url3.com\"]\nwith ThreadPoolExecutor(max_workers=3) as ex:\n    results = list(ex.map(fetch, urls))\n```\nUse **multiprocessing** for CPU-bound tasks (bypasses GIL).",
    interview: "🎯 **Interview Tips**:\n- **Easy**: FizzBuzz, Two Sum, Valid Palindrome, Reverse String\n- **Medium**: Valid Parentheses, Group Anagrams, Max Subarray\n- **Hard**: Longest Substring, LRU Cache, Merge K Sorted Lists\n\nPractice on the **Problems** tab! Start with Easy problems and work your way up.",
  };

  // Conversation memory
  var _chatHistory = [];
  var _maxHistory = 20; // keep last 20 messages

  function init() {
    // Load chat history from localStorage
    try {
      var saved = localStorage.getItem('pylearn_chat_history');
      if (saved) _chatHistory = JSON.parse(saved);
    } catch(e) { _chatHistory = []; }

    renderChatHistory();

    DOM.el.chatSendBtn().addEventListener('click', sendChat);
    DOM.el.chatInput().addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); }
    });

    // Quick action buttons
    document.querySelectorAll('.chat-quick button').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        if (action === 'explain') explainCode();
        else if (action === 'hint') ExercisesVM.showHint(ExercisesVM._currentExerciseIdx || 0);
        else if (action === 'next') sendChatWith('What should I learn next?');
        else if (action && btn.textContent.includes('Explain')) explainCode();
      });
    });

    // Clear chat button
    var chatClearBtn = document.getElementById('chatClearBtn');
    if (chatClearBtn) chatClearBtn.addEventListener('click', clearChatHistory);
  }

  function saveChatHistory() {
    try { localStorage.setItem('pylearn_chat_history', JSON.stringify(_chatHistory.slice(-_maxHistory))); } catch(e) {}
  }

  function renderChatHistory() {
    const container = DOM.el.chatMessages();
    container.innerHTML = '';
    if (!_chatHistory.length) {
      container.innerHTML = '<div class="chat-msg bot">Hi there! I\'m your Python AI Tutor. Ask me anything about Python!</div>';
      return;
    }
    _chatHistory.forEach(msg => {
      DOM.addChatMsg(msg.content, msg.role === 'assistant' ? 'bot' : 'user');
    });
  }

  function clearChatHistory() {
    _chatHistory = [];
    try { localStorage.removeItem('pylearn_chat_history'); } catch(e) {}
    renderChatHistory();
  }

  function addUserMsg(text) {
    DOM.addChatMsg(text, 'user');
    _chatHistory.push({ role: 'user', content: text });
    saveChatHistory();
  }
  function addBotMsg(text) {
    DOM.addChatMsg(text, 'bot');
    _chatHistory.push({ role: 'assistant', content: text });
    saveChatHistory();
  }

  async function sendChat() {
    const input = DOM.el.chatInput();
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    addUserMsg(msg);

    const provider = State.getSetting('ai_provider') || 'local';
    const apiKey = provider !== 'local' ? State.getSetting('apikey_' + provider) : null;
    const config = AI_PROVIDERS[provider] || AI_PROVIDERS.local;

    if (provider === 'local' || !apiKey) {
      addBotMsg(generateLocalResponse(msg));
      return;
    }

    try {
      addBotMsg('Thinking...');
      const savedModel = State.getSetting('ai_model_' + provider);
      const model = savedModel || config.defaultModel;
      const systemPrompt = getAppSystemPrompt();
      var messages = [{ role: 'system', content: systemPrompt }];
      var historyMsgs = _chatHistory.filter(function(m){return m.role !== 'system';}).slice(-_maxHistory);
      messages = messages.concat(historyMsgs);
      messages.push({ role: 'user', content: msg });

      let response;
      if (config.isAnthropic) {
        response = await callClaude(apiKey, config, messages, model);
      } else if (provider === 'gemini') {
        response = await callGemini(apiKey, config, messages, model);
      } else {
        response = await callOpenAICompatible(apiKey, config, messages, model);
      }

      DOM.removeLastChatMsg();
      addBotMsg(response);
    } catch (e) {
      DOM.removeLastChatMsg();
      addBotMsg('API Error (' + config.name + '): ' + e.message + '\n\nFalling back to local knowledge...\n\n' + generateLocalResponse(msg));
    }
  }

  async function callOpenAICompatible(apiKey, config, messages, model) {
    const headers = { 'Content-Type': 'application/json' };
    const authHeaders = config.authHeader(apiKey);
    Object.assign(headers, authHeaders);
    const resp = await fetch(config.url, {
      method: 'POST', headers: headers,
      body: JSON.stringify({ model: model, messages: messages, max_tokens: 800, temperature: 0.7 })
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error ? err.error.message : 'API error ' + resp.status);
    }
    const data = await resp.json();
    return data.choices[0].message.content;
  }

  async function callClaude(apiKey, config, messages, model) {
    const systemMsg = messages.find(m => m.role === 'system');
    const userMessages = messages.filter(m => m.role !== 'system');
    const resp = await fetch(config.url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: model, max_tokens: 800, system: systemMsg ? systemMsg.content : 'You are a helpful Python tutor.', messages: userMessages.map(m => ({ role: m.role, content: m.content })) })
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error ? err.error.message : 'Claude API error ' + resp.status);
    }
    const data = await resp.json();
    return data.content[0].text;
  }

  async function callGemini(apiKey, config, messages, model) {
    const systemMsg = messages.find(m => m.role === 'system');
    const contents = messages.filter(m => m.role !== 'system').map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
    const url = config.url.replace('{model}', model).replace('{key}', apiKey);
    const body = { contents: contents };
    if (systemMsg) body.systemInstruction = { parts: [{ text: systemMsg.content }] };
    const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error ? err.error.message : 'Gemini API error ' + resp.status);
    }
    const data = await resp.json();
    return data.candidates[0].content.parts[0].text;
  }

  function getAppSystemPrompt() {
    const topicId = ExercisesVM.getCurrentTopicId();
    const topic = Curriculum.getTopic(topicId);
    const progress = State.getProgress();
    const percent = Curriculum.getProgressPercent(progress);
    const topicSummary = topic
      ? `Current topic is ${topic.title}. Key focus: ${topic.description || topic.title}.`
      : 'No topic is selected yet.';
    return `You are PyLearn AI, a friendly Python tutor for a browser-based learning app. Use concise explanations, code examples, and encourage the learner. ${topicSummary} The learner has completed ${percent}% of the curriculum. Remember the conversation history and refer back to earlier questions when it helps.`;
  }

  function sendChatWith(msg) {
    DOM.el.chatInput().value = msg;
    sendChat();
  }

  function generateLocalResponse(msg) {
    const m = msg.toLowerCase();
    if (m.includes('hello') || m.includes('hi ') || m.includes('hey')) return 'Hello! I am your Python AI Tutor. Ask me anything about Python!';
    for (const [key, response] of Object.entries(knowledgeResponses)) { if (m.includes(key)) return response; }
    if (m.includes('what should') || m.includes('what next') || m.includes('learn next')) return suggestNext();
    if (m.includes('thank')) return 'You are welcome! Keep coding!';
    const provider = State.getSetting('ai_provider') || 'local';
    const cfg = AI_PROVIDERS[provider] || AI_PROVIDERS.local;
    if (provider !== 'local') return 'I am connected to ' + cfg.name + ' but could not process your request. Try rephrasing your question.\n\nYou can also switch to Local mode in Settings for built-in knowledge.';
    return 'Great question! I have built-in knowledge about many Python topics.\n\nTry asking about: variables, strings, lists, dicts, tuples, sets, loops, functions, classes, errors, modules, decorators, comprehensions, f-strings, lambda, recursion, generators, async, testing, OOP, context managers, memory, logging, debugging, closures, threading, or interview tips!\n\nYou can also set up a cloud AI provider in Settings for advanced AI responses from OpenAI, OpenRouter, Groq, Gemini, or Claude.';
  }

  function suggestNext() {
    const progress = State.getProgress();
    const topics = Curriculum.getAllTopics();
    const currentId = EditorVM.getCurrentTopicId();

    if (!currentId) return "Start with **Getting Started** to learn the basics! 🚀";

    const idx = Curriculum.getTopicIndex(currentId);
    const km = Curriculum.getKnowledgeMap(currentId);

    // Check if current topic exercises are done
    const topicProgress = progress[currentId];
    const topic = topics[idx];
    const exDone = topicProgress?.exercises ? Object.keys(topicProgress.exercises).length : 0;
    const exTotal = topic.exercises.length;

    let msg = '';

    if (exDone < exTotal) {
      msg = `You've studied **${topic.title}** but haven't completed all exercises yet! (${exDone}/${exTotal})\n\n`;
      if (km) msg += `💡 **Going deeper**: ${km.intermediate}\n\n`;
      msg += `Complete the remaining exercises before moving on. 💪`;
    } else if (idx < topics.length - 1) {
      const next = topics[idx + 1];
      msg = `Great progress! ✅ You completed **${topic.title}**.\n\n`;
      msg += `📚 **Next up: ${next.title}** ${next.icon}\n`;
      msg += `Level: ${next.level}\n\n`;
      if (km?.advanced) msg += `💡 **Advanced insight**: ${km.advanced}\n\n`;
      msg += `Click "${next.title}" in the sidebar to continue!`;
    } else {
      msg = "🎉 Amazing! You've covered all topics! Try doing all the experiments, build your own projects, or ask me about advanced topics!";
    }
    return msg;
  }

  function explainCode() {
    const code = DOM.el.codeEditor().value.trim();
    if (!code) { addBotMsg('The editor is empty! Write some code first.'); return; }
    addUserMsg('Explain this code');

    let explanation = '🔍 **Code Analysis:**\n\n';
    const lines = code.split('\n').filter(l => l.trim() && !l.trim().startsWith('#'));

    const patterns = [
      ['def ', '• Defines **function(s)**'],
      ['class ', '• Defines **class(es)**'],
      ['for ', '• Uses **for loop(s)**'],
      ['while ', '• Uses **while loop(s)**'],
      ['if ', '• Has **conditional** logic'],
      ['import ', '• **Imports** external modules'],
      ['try:', '• Includes **error handling**'],
      ['print(', '• Uses **print()** for output'],
      ['return ', '• **Returns** values from functions'],
      ['lambda ', '• Contains **lambda** expression(s)'],
      ['__init__', '• Has **constructor** method'],
      ['self.', '• Uses **instance attributes**'],
      ['yield ', '• Uses **generator** (yield)'],
      ['async ', '• Uses **async** programming'],
      ['await ', '• Uses **await** for async operations'],
      ['with ', '• Uses **context manager**'],
      ['@', '• Uses **decorator(s)**'],
    ];

    patterns.forEach(([pattern, desc]) => {
      if (code.includes(pattern)) explanation += `${desc}\n`;
    });

    if (code.includes('[') && code.includes('for') && code.includes('in')) {
      explanation += '• Uses **comprehension**\n';
    }

    explanation += `\nThe code is **${lines.length} lines** long (excluding comments/blanks).\n\nTry running it to see the output! 🚀`;
    addBotMsg(explanation);
  }

  return { init, addUserMsg, addBotMsg, sendChat, sendChatWith, explainCode, generateLocalResponse };
})();


/**
 * VIEW Model: UI Controller
 * Settings, theme, sidebar, modals, progress panel, tracks
 */
const UI = (() => {
  function init() {
    // Theme
    const savedTheme = State.getSetting('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    DOM.setThemeIcon(savedTheme === 'light');
    DOM.el.themeToggle().addEventListener('click', toggleTheme);

    // Font size
    const fs = State.getSetting('fontsize') || '14';
    DOM.applyFontSize(fs);

    // Sidebar toggle
    document.getElementById('toggleSidebar').addEventListener('click', () => {
      DOM.el.sidebar().classList.toggle('open');
    });

    // Sidebar search
    DOM.el.sidebarSearch().addEventListener('input', function () {
      DOM.renderCurriculum(Curriculum.getAllTopics(), EditorVM.getCurrentTopicId ? EditorVM.getCurrentTopicId() : null, State.getProgress(), this.value);
    });

    // Settings modal buttons
    document.getElementById('settingsBtn').addEventListener('click', openSettings);
    document.getElementById('cancelSettingsBtn').addEventListener('click', closeSettings);
    document.getElementById('saveSettingsBtn').addEventListener('click', saveSettings);
    document.getElementById('resetProgressBtn').addEventListener('click', resetProgress);
    DOM.el.settingsModal().addEventListener('click', (e) => { if (e.target === DOM.el.settingsModal()) closeSettings(); });
    DOM.el.modalFontSlider().addEventListener('input', function () {
      DOM.el.modalFontLabel().textContent = this.value + 'px';
    });

    // AI Provider & Model select
    var aiProviderSelect = document.getElementById('aiProviderSelect');
    if (aiProviderSelect) aiProviderSelect.addEventListener('change', function() {
      updateProviderHelp();
      loadApiKeyForProvider(aiProviderSelect.value);
    });
    var aiModelSelect = document.getElementById('aiModelSelect');
    if (aiModelSelect) aiModelSelect.addEventListener('change', updateModelInfo);

    // AI Chat toggle (FAB + close button + overlay click)
    const aiFab = document.getElementById('aiFab');
    const aiChatOverlay = document.getElementById('aiChatOverlay');
    const aiChatCloseBtn = document.getElementById('aiChatCloseBtn');
    if (aiFab) aiFab.addEventListener('click', () => { aiChatOverlay.classList.toggle('open'); });
    if (aiChatCloseBtn) aiChatCloseBtn.addEventListener('click', () => { aiChatOverlay.classList.remove('open'); });
    if (aiChatOverlay) aiChatOverlay.addEventListener('click', (e) => {
      if (e.target === aiChatOverlay) aiChatOverlay.classList.remove('open');
    });

    // Tab clicks
    DOM.el.tabs().forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    // Curriculum click (delegation)
    DOM.el.curriculumNav().addEventListener('click', (e) => {
      const item = e.target.closest('.curriculum-item');
      if (item && item.dataset.topicId) loadTopic(item.dataset.topicId);
    });

    // Snippet delegation
    DOM.el.snippetsPanel().addEventListener('click', (e) => {
      const loadBtn = e.target.closest('.snippet-load-btn');
      const delBtn = e.target.closest('.snippet-delete-btn');
      if (loadBtn) EditorVM.loadSnippet(parseInt(loadBtn.dataset.idx));
      if (delBtn) EditorVM.deleteSnippet(parseInt(delBtn.dataset.idx));
    });

    // Files delegation
    const filesPanel = DOM.el.filesPanel();
    if (filesPanel) {
      filesPanel.addEventListener('click', (e) => {
        const loadBtn = e.target.closest('.file-load-btn');
        const delBtn = e.target.closest('.file-delete-btn');
        if (loadBtn) EditorVM.loadFile(loadBtn.dataset.path);
        if (delBtn) EditorVM.deleteFile(delBtn.dataset.path);
      });
    }

    // Problems delegation
    const problemsPanel = DOM.el.problemsPanel();
    if (problemsPanel) {
      problemsPanel.addEventListener('click', (e) => {
        const loadBtn = e.target.closest('.problem-load-btn');
        const checkBtn = e.target.closest('.problem-check-btn');
        const filterBtn = e.target.closest('.problems-filter');
        if (loadBtn) ProblemsVM.loadProblem(parseInt(loadBtn.dataset.idx));
        if (checkBtn) ProblemsVM.checkProblem(parseInt(checkBtn.dataset.idx));
        if (filterBtn) ProblemsVM.filterProblems(filterBtn.dataset.filter);
      });
    }

    // Chat quick action buttons
    document.querySelectorAll('.chat-quick button').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.textContent;
        if (text.includes('Explain')) ChatVM.explainCode();
        else if (text.includes('Hint')) {
          const idx = EditorVM.getCurrentExerciseIdx ? EditorVM.getCurrentExerciseIdx() : 0;
          ExercisesVM.showHint(idx);
        }
        else if (text.includes('What Next')) ChatVM.sendChatWith('What should I learn next?');
      });
    });

    // Streak
    State.updateStreak();
  }

  // ---- Tab Switching ----
  function switchTab(tab) {
    DOM.switchTab(tab);
    if (tab === 'exercise') ExercisesVM.render();
    if (tab === 'snippets') DOM.renderSnippets(State.getSnippets());
    if (tab === 'progress') { try { Enhancements.renderProgressDashboard(); } catch(e) { DOM.renderProgressPanel(State.getProgress(), State.getStreak()); } }
    if (tab === 'repl') DOM.clearRepl();
    if (tab === 'packages') DOM.renderPackagesList(PyodideEngine.getInstalledPackages());
    if (tab === 'files') DOM.renderFilesList(State.getVirtualFiles());
    if (tab === 'tracks') DOM.renderTracks(Curriculum.getAllTracks());
    if (tab === 'problems') ProblemsVM.render();
  }

  // ---- Load Topic ----
  function loadTopic(id) {
    const topic = Curriculum.getTopic(id);
    if (!topic) return;

    EditorVM.setCurrentTopic(id);
    ExercisesVM.setCurrentTopic(id);

    const lesson = topic.lessons[0];
    DOM.renderLesson(topic);
    DOM.updateLineNumbers();
    EditorVM.autoSave();

    DOM.renderCurriculum(Curriculum.getAllTopics(), id, State.getProgress());
    switchTab('lesson');

    // Mark lesson visited
    const progress = State.getProgress();
    if (!progress[id]) progress[id] = { lessonDone: false, exercises: {} };
    progress[id].lessonDone = true;
    State.saveProgress(progress);
    DOM.updateProgressBadge(Curriculum.getProgressPercent(progress));
    DOM.renderCurriculum(Curriculum.getAllTopics(), id, State.getProgress());
  }

  // ---- Theme ----
  function toggleTheme() {
    const html = document.documentElement;
    const current = html.getAttribute('data-theme');
    const next = current === 'light' ? 'dark' : 'light';
    html.setAttribute('data-theme', next);
    State.setSetting('theme', next);
    DOM.setThemeIcon(next === 'light');
  }

  // ---- AI Provider & Model Help ----
  function updateProviderHelp() {
    var providerSelect = document.getElementById('aiProviderSelect');
    var helpEl = document.getElementById('aiProviderHelp');
    var modelSelect = document.getElementById('aiModelSelect');
    var modelInfo = document.getElementById('aiModelInfo');
    if (!providerSelect || !helpEl || !modelSelect) return;
    var provider = providerSelect.value;
    var help = {
      local: 'No API key needed. Uses built-in Python knowledge base.',
      openai: 'Get your API key from platform.openai.com. Free models have usage limits.',
      openrouter: 'Get your API key from openrouter.ai. Access 100+ models. Free models available!',
      groq: 'Get your API key from console.groq.com. Ultra-fast inference. Generous free tier!',
      gemini: 'Get your API key from aistudio.google.com. Free tier available.',
      claude: 'Get your API key from console.anthropic.com. Haiku is the most affordable.',
    };
    helpEl.textContent = help[provider] || help.local;
    if (provider === 'local') {
      modelSelect.innerHTML = '<option value="">Built-in Knowledge</option>';
      modelSelect.disabled = true;
      if (modelInfo) modelInfo.textContent = '';
      return;
    }
    modelSelect.disabled = false;
    var config = AI_PROVIDERS[provider];
    if (!config) return;
    var savedModel = State.getSetting('ai_model_' + provider);
    var allIds = [].concat(config.freeModels || []).concat(config.paidModels || []).map(function(m){return m.id;});
    if (savedModel && allIds.indexOf(savedModel) === -1) {
      State.removeSetting('ai_model_' + provider);
      savedModel = null;
    }
    if (!savedModel) savedModel = config.defaultModel;
    var html = '';
    if (config.freeModels && config.freeModels.length > 0) {
      html += '<optgroup label="\uD83C\uDD93 Free Models">';
      config.freeModels.forEach(function(m){
        html += '<option value="'+m.id+'"'+(m.id===savedModel?' selected=""':'')+'>'+m.name+' \u2014 '+m.desc+'</option>';
      });
      html += '</optgroup>';
    }
    if (config.paidModels && config.paidModels.length > 0) {
      html += '<optgroup label="\uD83D\uDC8E Paid Models">';
      config.paidModels.forEach(function(m){
        html += '<option value="'+m.id+'"'+(m.id===savedModel?' selected=""':'')+'>'+m.name+' \u2014 '+m.desc+'</option>';
      });
      html += '</optgroup>';
    }
    modelSelect.innerHTML = html;
    updateModelInfo();
  }
  function updateModelInfo() {
    var providerSelect = document.getElementById('aiProviderSelect');
    var modelSelect = document.getElementById('aiModelSelect');
    var modelInfo = document.getElementById('aiModelInfo');
    if (!providerSelect || !modelSelect || !modelInfo) return;
    var provider = providerSelect.value;
    var modelId = modelSelect.value;
    if (!modelId || provider === 'local') { modelInfo.textContent = ''; return; }
    var config = AI_PROVIDERS[provider];
    if (!config) return;
    var model = null;
    var isFree = false;
    if (config.freeModels) { model = config.freeModels.find(function(m){return m.id===modelId;}); if(model) isFree=true; }
    if (!model && config.paidModels) { model = config.paidModels.find(function(m){return m.id===modelId;}); }
    if (model) {
      modelInfo.textContent = (isFree?'\uD83C\uDD93 Free':'\uD83D\uDC8E Paid')+' \u2014 '+model.desc;
      modelInfo.style.color = isFree?'var(--success)':'var(--warning)';
    }
  }

  // ---- Settings ----
  function openSettings() {
    DOM.el.settingsModal().classList.add('show');
    var provider = State.getSetting('ai_provider') || 'local';
    var providerSelect = document.getElementById('aiProviderSelect');
    if (providerSelect) providerSelect.value = provider;
    updateProviderHelp();
    // Load the API key for the currently selected provider
    loadApiKeyForProvider(provider);
    var fs = parseInt(State.getSetting('fontsize') || '14');
    DOM.el.modalFontSlider().value = fs;
    DOM.el.modalFontLabel().textContent = fs + 'px';
  }

  function loadApiKeyForProvider(provider) {
    var key = '';
    if (provider && provider !== 'local') {
      key = State.getSetting('apikey_' + provider) || '';
    }
    DOM.el.apiKeyInput().value = key;
    // Update the placeholder to show which provider this key is for
    var input = DOM.el.apiKeyInput();
    if (provider && provider !== 'local' && AI_PROVIDERS[provider]) {
      input.placeholder = 'Enter your ' + AI_PROVIDERS[provider].name + ' API key...';
    } else {
      input.placeholder = 'Enter your API key...';
    }
  }

  function closeSettings() {
    DOM.el.settingsModal().classList.remove('show');
  }

  function saveSettings() {
    const providerSelect = document.getElementById('aiProviderSelect');
    const provider = providerSelect ? providerSelect.value : 'local';
    const key = DOM.el.apiKeyInput().value.trim();
    // Save the API key for the currently selected provider
    if (provider && provider !== 'local') {
      if (key) State.setSetting('apikey_' + provider, key);
      else State.removeSetting('apikey_' + provider);
    } else {
      // For local provider, clear any legacy single key
      if (key) State.setSetting('apikey', key);
      else State.removeSetting('apikey');
    }
    if (providerSelect) State.setSetting('ai_provider', provider);
    const modelSelect = document.getElementById('aiModelSelect');
    if (modelSelect && modelSelect.value) {
      State.setSetting('ai_model_' + provider, modelSelect.value);
    }
    const fs = DOM.el.modalFontSlider().value;
    State.setSetting('fontsize', fs);
    DOM.applyFontSize(fs);
    closeSettings();
    DOM.showToast('Settings saved! ✅', 'success');
  }

  function resetProgress() {
    if (!confirm('Reset all progress? This cannot be undone.')) return;
    State.resetProgress();
    DOM.updateProgressBadge(0);
    DOM.renderCurriculum(Curriculum.getAllTopics(), null, State.getProgress());
    closeSettings();
    DOM.showToast('Progress reset.', 'info');
  }

  return { init, switchTab, loadTopic, toggleTheme, openSettings, closeSettings, saveSettings, resetProgress };
})();


/**
 * ENHANCEMENTS: Achievements, Shortcuts, Export/Import, Syntax Check, Offline, Progress Dashboard
 */
const Enhancements = (() => {

  // ---- Achievement Definitions ----
  const ACHIEVEMENTS = [
    { id: 'first_lesson', icon: '📖', name: 'First Steps', desc: 'Complete your first lesson', check: (p, s) => Curriculum.getProgressPercent(p) >= 1 },
    { id: 'five_lessons', icon: '📚', name: 'Bookworm', desc: 'Complete 5 lessons', check: (p, s) => { let c = 0; Curriculum.getAllTopics().forEach(t => { if (p[t.id] && p[t.id].lessonDone) c++; }); return c >= 5; } },
    { id: 'ten_lessons', icon: '🎓', name: 'Scholar', desc: 'Complete 10 lessons', check: (p, s) => { let c = 0; Curriculum.getAllTopics().forEach(t => { if (p[t.id] && p[t.id].lessonDone) c++; }); return c >= 10; } },
    { id: 'all_lessons', icon: '🏆', name: 'Python Master', desc: 'Complete all lessons', check: (p, s) => Curriculum.getProgressPercent(p) === 100 },
    { id: 'first_exercise', icon: '✏️', name: 'Problem Solver', desc: 'Solve your first exercise', check: (p, s) => { let c = 0; Curriculum.getAllTopics().forEach(t => { if (p[t.id] && p[t.id].exercises) c += Object.keys(p[t.id].exercises).length; }); return c >= 1; } },
    { id: 'ten_exercises', icon: '💪', name: 'Code Warrior', desc: 'Solve 10 exercises', check: (p, s) => { let c = 0; Curriculum.getAllTopics().forEach(t => { if (p[t.id] && p[t.id].exercises) c += Object.keys(p[t.id].exercises).length; }); return c >= 10; } },
    { id: 'first_problem', icon: '🧩', name: 'Puzzle Master', desc: 'Solve your first interview problem', check: (p, s) => s.problemsSolved >= 1 },
    { id: 'five_problems', icon: '🏅', name: 'Algorithm Ace', desc: 'Solve 5 interview problems', check: (p, s) => s.problemsSolved >= 5 },
    { id: 'streak_3', icon: '🔥', name: 'On Fire', desc: '3-day learning streak', check: (p, s) => State.getStreak() >= 3 },
    { id: 'streak_7', icon: '⚡', name: 'Unstoppable', desc: '7-day learning streak', check: (p, s) => State.getStreak() >= 7 },
    { id: 'first_snippet', icon: '💾', name: 'Collector', desc: 'Save your first code snippet', check: (p, s) => State.getSnippets().length >= 1 },
    { id: 'five_snippets', icon: '📦', name: 'Library Builder', desc: 'Save 5 code snippets', check: (p, s) => State.getSnippets().length >= 5 },
    { id: 'first_chat', icon: '💬', name: 'Curious Mind', desc: 'Ask the AI Tutor a question', check: (p, s) => s.chatCount >= 1 },
    { id: 'ten_chats', icon: '🤖', name: 'AI Buddy', desc: 'Have 10 AI Tutor conversations', check: (p, s) => s.chatCount >= 10 },
    { id: 'night_owl', icon: '🦉', name: 'Night Owl', desc: 'Code after midnight', check: (p, s) => new Date().getHours() < 5 },
    { id: 'early_bird', icon: '🐦', name: 'Early Bird', desc: 'Code before 7am', check: (p, s) => { const h = new Date().getHours(); return h >= 5 && h < 7; } },
    { id: 'half_way', icon: '⛰️', name: 'Halfway There', desc: 'Reach 50% overall progress', check: (p, s) => Curriculum.getProgressPercent(p) >= 50 },
    { id: 'xp_500', icon: '⭐', name: 'Rising Star', desc: 'Earn 500 XP', check: (p, s) => s.totalXP >= 500 },
    { id: 'xp_1000', icon: '🌟', name: 'Superstar', desc: 'Earn 1000 XP', check: (p, s) => s.totalXP >= 1000 },
  ];

  function getAchievementsState() {
    try { return JSON.parse(localStorage.getItem('pylearn_achievements')) || { unlocked: [], chatCount: 0, problemsSolved: 0, totalXP: 0 }; }
    catch { return { unlocked: [], chatCount: 0, problemsSolved: 0, totalXP: 0 }; }
  }

  function saveAchievementsState(a) {
    localStorage.setItem('pylearn_achievements', JSON.stringify(a));
  }

  function awardXP(amount) {
    const a = getAchievementsState();
    a.totalXP = (a.totalXP || 0) + amount;
    saveAchievementsState(a);
    return a.totalXP;
  }

  function getLevelInfo(xp) {
    const level = Math.floor(xp / 100) + 1;
    const xpInLevel = xp % 100;
    const titles = ['Beginner', 'Explorer', 'Apprentice', 'Coder', 'Developer', 'Engineer', 'Architect', 'Expert', 'Master', 'Grandmaster'];
    const title = titles[Math.min(Math.floor(level / 2), titles.length - 1)];
    return { level, xpInLevel, xpNeeded: 100, title };
  }

  function checkAchievements() {
    const progress = State.getProgress();
    const achState = getAchievementsState();
    const newlyUnlocked = [];
    ACHIEVEMENTS.forEach(ach => {
      if (!achState.unlocked.includes(ach.id) && ach.check(progress, achState)) {
        achState.unlocked.push(ach.id);
        newlyUnlocked.push(ach);
      }
    });
    if (newlyUnlocked.length > 0) {
      saveAchievementsState(achState);
      newlyUnlocked.forEach((ach, i) => {
        setTimeout(() => showAchievementToast(ach), i * 1500);
      });
    }
    return newlyUnlocked;
  }

  function showAchievementToast(ach) {
    const toast = document.getElementById('achievementToast');
    if (!toast) return;
    const icon = document.getElementById('achToastIcon');
    const name = document.getElementById('achToastName');
    const desc = document.getElementById('achToastDesc');
    if (icon) icon.textContent = ach.icon;
    if (name) name.textContent = ach.name;
    if (desc) desc.textContent = ach.desc;
    toast.classList.add('show');
    awardXP(25);
    setTimeout(() => toast.classList.remove('show'), 3500);
  }

  function renderAchievementsGrid() {
    const grid = document.getElementById('achievementsGrid');
    if (!grid) return;
    const achState = getAchievementsState();
    grid.innerHTML = ACHIEVEMENTS.map(ach => {
      const unlocked = achState.unlocked.includes(ach.id);
      return `<div class="achievement-item ${unlocked ? 'unlocked' : ''}">
        <div class="ach-icon-sm">${unlocked ? ach.icon : '🔒'}</div>
        <div class="ach-info"><strong>${ach.name}</strong><p>${ach.desc}</p></div>
        <span class="ach-check">${unlocked ? '✅' : ''}</span>
      </div>`;
    }).join('');
  }

  // ---- Progress Dashboard ----
  function renderProgressDashboard() {
    const progress = State.getProgress();
    const streak = State.getStreak();
    const pct = Curriculum.getProgressPercent(progress);
    const exStats = Curriculum.getExerciseStats(progress);
    const topics = Curriculum.getAllTopics();
    const completedTopics = topics.filter(t => progress[t.id] && progress[t.id].lessonDone).length;
    const achState = getAchievementsState();
    const snippets = State.getSnippets();
    const levelInfo = getLevelInfo(achState.totalXP || 0);

    // Ring
    const ringFill = document.getElementById('progressRingFill');
    const ringValue = document.getElementById('progressRingValue');
    if (ringFill) {
      const circumference = 2 * Math.PI * 60;
      const offset = circumference - (pct / 100) * circumference;
      ringFill.style.strokeDashoffset = offset;
    }
    if (ringValue) ringValue.textContent = pct + '%';

    // Level
    const userLevel = document.getElementById('userLevel');
    const userLevelTitle = document.getElementById('userLevelTitle');
    const userXP = document.getElementById('userXP');
    const userXPNeeded = document.getElementById('userXPNeeded');
    const levelBarFill = document.getElementById('levelBarFill');
    if (userLevel) userLevel.textContent = levelInfo.level;
    if (userLevelTitle) userLevelTitle.textContent = levelInfo.title;
    if (userXP) userXP.textContent = levelInfo.xpInLevel;
    if (userXPNeeded) userXPNeeded.textContent = levelInfo.xpNeeded;
    if (levelBarFill) levelBarFill.style.width = levelInfo.xpInLevel + '%';

    // Stats
    const setStat = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    setStat('statLessons', completedTopics);
    setStat('statExercises', exStats.done);
    setStat('statProblems', achState.problemsSolved || 0);
    setStat('statStreak', streak);
    setStat('statXP', achState.totalXP || 0);
    setStat('statSnippets', snippets.length);

    // Topic progress list
    const tpl = document.getElementById('topicProgressList');
    if (tpl) {
      tpl.innerHTML = topics.map(t => {
        const tp = progress[t.id] || {};
        const exCount = t.exercises ? t.exercises.length : 0;
        const exDone = tp.exercises ? Object.keys(tp.exercises).length : 0;
        let pct = 0;
        if (tp.lessonDone && exCount > 0) pct = Math.round((exDone / exCount) * 100);
        else if (tp.lessonDone) pct = 50;
        let cls = 'none';
        if (pct >= 100) cls = 'done';
        else if (pct > 0) cls = 'partial';
        return `<div class="topic-progress-item">
          <span class="tp-icon">${t.icon}</span>
          <span class="tp-name">${t.title}</span>
          <div class="tp-bar"><div class="tp-bar-fill ${cls}" style="width:${pct}%"></div></div>
          <span class="tp-pct">${pct}%</span>
        </div>`;
      }).join('');
    }

    renderAchievementsGrid();
  }

  // ---- Syntax Check ----
  function checkSyntax(code) {
    const bar = document.getElementById('syntaxBar');
    const icon = document.getElementById('syntaxIcon');
    const msg = document.getElementById('syntaxMsg');
    if (!bar || !icon || !msg) return;

    if (!code.trim()) {
      bar.className = 'syntax-bar';
      icon.textContent = '';
      msg.textContent = 'Ready to run';
      return;
    }

    const lines = code.split('\n');
    const issues = [];

    lines.forEach((line, i) => {
      const ln = i + 1;
      // Check for common issues
      if (/\bprinnt\b/.test(line)) issues.push({ ln, msg: 'Did you mean "print"?', type: 'err' });
      if (/\bimpor\s+/.test(line)) issues.push({ ln, msg: 'Did you mean "import"?', type: 'err' });
      if (/\bdef\s+\w+\([^)]*\)\s*[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon at end of function def', type: 'err' });
      if (/\bif\s+.+[^:]$/.test(line.trim()) && !line.trim().endsWith(':') && !/else/.test(line)) issues.push({ ln, msg: 'Missing colon at end of if statement', type: 'err' });
      if (/\bfor\s+.+[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon at end of for loop', type: 'err' });
      if (/\bwhile\s+.+[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon at end of while loop', type: 'err' });
      if (/\bclass\s+\w+.*[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon at end of class def', type: 'err' });
      if (/\btry\s*[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon after try', type: 'err' });
      if (/\bexcept\b.*[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon after except', type: 'err' });
      if (/\belif\s+.+[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon after elif', type: 'err' });
      if (/\belse\s*[^:]$/.test(line.trim()) && !line.trim().endsWith(':')) issues.push({ ln, msg: 'Missing colon after else', type: 'err' });
      // Warnings
      if (/\bprint\s+[^(]/.test(line)) issues.push({ ln, msg: 'Python 2 print? Use print()', type: 'warn' });
      if (/;\s*$/.test(line) && line.trim().length > 1) issues.push({ ln, msg: 'Unnecessary semicolon', type: 'warn' });
    });

    // Bracket matching
    const brackets = { '(': ')', '[': ']', '{': '}' };
    const stack = [];
    lines.forEach((line, i) => {
      for (const ch of line) {
        if (brackets[ch]) stack.push({ ch, ln: i + 1 });
        else if (Object.values(brackets).includes(ch)) {
          if (stack.length === 0) issues.push({ ln: i + 1, msg: `Unexpected '${ch}'`, type: 'err' });
          else {
            const last = stack.pop();
            if (brackets[last.ch] !== ch) issues.push({ ln: i + 1, msg: `Mismatched bracket: '${last.ch}' and '${ch}'`, type: 'err' });
          }
        }
      }
    });
    stack.forEach(b => issues.push({ ln: b.ln, msg: `Unclosed '${b.ch}'`, type: 'err' }));

    if (issues.length === 0) {
      bar.className = 'syntax-bar ok';
      icon.textContent = '✅';
      msg.textContent = 'No issues detected';
    } else {
      const errs = issues.filter(i => i.type === 'err');
      const warns = issues.filter(i => i.type === 'warn');
      if (errs.length > 0) {
        bar.className = 'syntax-bar err';
        icon.textContent = '❌';
        msg.textContent = `Line ${errs[0].ln}: ${errs[0].msg}${errs.length > 1 ? ` (+${errs.length - 1} more)` : ''}`;
      } else {
        bar.className = 'syntax-bar warn';
        icon.textContent = '⚠️';
        msg.textContent = `Line ${warns[0].ln}: ${warns[0].msg}`;
      }
    }
  }

  // ---- Export / Import ----
  function exportProgress() {
    const data = {
      version: 1,
      date: new Date().toISOString(),
      progress: State.getProgress(),
      snippets: State.getSnippets(),
      achievements: getAchievementsState(),
      settings: {
        theme: State.getSetting('theme'),
        fontsize: State.getSetting('fontsize'),
      },
      streak: parseInt(localStorage.getItem('pylearn_streak') || '0'),
      lastVisit: localStorage.getItem('pylearn_lastvisit'),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pylearn-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    DOM.showToast('Progress exported successfully!', 'success');
  }

  function importProgress(json) {
    try {
      if (json.progress) {
        State.saveProgress(json.progress);
      }
      if (json.snippets) {
        State.saveSnippets(json.snippets);
      }
      if (json.achievements) {
        saveAchievementsState(json.achievements);
      }
      if (json.settings) {
        if (json.settings.theme) State.setSetting('theme', json.settings.theme);
        if (json.settings.fontsize) State.setSetting('fontsize', json.settings.fontsize);
      }
      if (json.streak) localStorage.setItem('pylearn_streak', json.streak.toString());
      if (json.lastVisit) localStorage.setItem('pylearn_lastvisit', json.lastVisit);

      // Refresh UI
      const progress = State.getProgress();
      DOM.updateProgressBadge(Curriculum.getProgressPercent(progress));
      DOM.renderCurriculum(Curriculum.getAllTopics(), EditorVM.getCurrentTopicId ? EditorVM.getCurrentTopicId() : null, progress);
      renderProgressDashboard();
      checkAchievements();
      DOM.showToast('Progress imported successfully! Page will reload.', 'success');
      setTimeout(() => location.reload(), 1500);
    } catch (e) {
      DOM.showToast('Import failed: invalid file', 'error');
    }
  }

  // ---- Keyboard Shortcuts ----
  function initShortcuts() {
    const overlay = document.getElementById('shortcutsOverlay');
    const closeBtn = document.getElementById('shortcutsCloseBtn');
    const shortcutsBtn = document.getElementById('shortcutsBtn');

    if (shortcutsBtn) {
      shortcutsBtn.addEventListener('click', () => { if (overlay) overlay.classList.add('open'); });
    }
    if (closeBtn) {
      closeBtn.addEventListener('click', () => { if (overlay) overlay.classList.remove('open'); });
    }
    if (overlay) {
      overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.remove('open'); });
    }

    // Global keyboard handler
    document.addEventListener('keydown', (e) => {
      // Don't trigger shortcuts when typing in inputs
      const tag = e.target.tagName;
      const isInput = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
      const inChat = e.target.closest('#chatPanel') || e.target.closest('#aiChatOverlay');

      // Ctrl+/ — Shortcuts (always works)
      if (e.ctrlKey && e.key === '/') {
        e.preventDefault();
        if (overlay) overlay.classList.toggle('open');
        return;
      }

      // Ctrl+I — AI Tutor
      if (e.ctrlKey && e.key === 'i') {
        e.preventDefault();
        const chatOverlay = document.getElementById('aiChatOverlay');
        if (chatOverlay) chatOverlay.classList.toggle('open');
        return;
      }

      // Ctrl+, — Settings
      if (e.ctrlKey && e.key === ',') {
        e.preventDefault();
        UI.openSettings();
        return;
      }

      // Ctrl+B — Sidebar
      if (e.ctrlKey && e.key === 'b') {
        e.preventDefault();
        DOM.el.sidebar().classList.toggle('open');
        return;
      }

      // Ctrl+Shift+L — Theme
      if (e.ctrlKey && e.shiftKey && e.key === 'L') {
        e.preventDefault();
        UI.toggleTheme();
        return;
      }

      // Tab switching with Ctrl+1-4
      if (e.ctrlKey && !e.shiftKey && !e.altKey) {
        const tabMap = { '1': 'practice', '2': 'repl', '3': 'problems', '4': 'progress' };
        if (tabMap[e.key]) {
          e.preventDefault();
          UI.switchTab(tabMap[e.key]);
          return;
        }
      }

      // Editor-only shortcuts
      if (!isInput || e.target.id === 'codeEditor' || e.target.id === 'ideEditor') {
        // Ctrl+Enter — Run (already handled, but ensure it works)
        // Ctrl+Shift+X — Clear editor
        if (e.ctrlKey && e.shiftKey && e.key === 'X') {
          e.preventDefault();
          if (typeof EditorVM !== 'undefined' && EditorVM.clearEditor) EditorVM.clearEditor();
          return;
        }
        // Ctrl+Shift+C — Copy code
        if (e.ctrlKey && e.shiftKey && e.key === 'C') {
          e.preventDefault();
          if (typeof EditorVM !== 'undefined' && EditorVM.copyCode) EditorVM.copyCode();
          return;
        }
        // Ctrl+D — Debug run
        if (e.ctrlKey && e.key === 'd' && !inChat) {
          e.preventDefault();
          if (typeof EditorVM !== 'undefined' && EditorVM.runDebug) EditorVM.runDebug();
          return;
        }
      }

      // Escape — close modals/overlays
      if (e.key === 'Escape') {
        if (overlay && overlay.classList.contains('open')) overlay.classList.remove('open');
        const chatOverlay = document.getElementById('aiChatOverlay');
        if (chatOverlay && chatOverlay.classList.contains('open')) chatOverlay.classList.remove('open');
        UI.closeSettings();
      }
    });
  }

  // ---- Offline Detection ----
  function initOfflineDetection() {
    const indicator = document.getElementById('offlineIndicator');
    if (!indicator) return;

    function updateOnlineStatus() {
      if (!navigator.onLine) {
        indicator.classList.add('show');
        DOM.showToast('You are offline', 'error');
      } else {
        indicator.classList.remove('show');
        DOM.showToast('Back online!', 'success');
      }
    }

    window.addEventListener('offline', updateOnlineStatus);
    window.addEventListener('online', updateOnlineStatus);
    if (!navigator.onLine) updateOnlineStatus();
  }

  // ---- FAB Badge ----
  function showFABBadge() {
    const badge = document.getElementById('aiFabBadge');
    if (badge) badge.classList.remove('hidden');
  }

  function hideFABBadge() {
    const badge = document.getElementById('aiFabBadge');
    if (badge) badge.classList.add('hidden');
  }

  // ---- Init ----
  function init() {
    initShortcuts();
    initOfflineDetection();
    renderProgressDashboard();
    checkAchievements();

    // Export/Import buttons
    const exportBtn = document.getElementById('exportProgressBtn');
    const importBtn = document.getElementById('importProgressBtn');
    const importInput = document.getElementById('importFileInput');
    if (exportBtn) exportBtn.addEventListener('click', exportProgress);
    if (importBtn) importBtn.addEventListener('click', () => { if (importInput) importInput.click(); });
    if (importInput) importInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        try { importProgress(JSON.parse(ev.target.result)); }
        catch { DOM.showToast('Invalid JSON file', 'error'); }
      };
      reader.readAsText(file);
    });

    // Syntax check on editor input
    const editor = document.getElementById('codeEditor');
    if (editor) {
      editor.addEventListener('input', () => checkSyntax(editor.value));
    }
    const ideEditor = document.getElementById('ideEditor');
    if (ideEditor) {
      ideEditor.addEventListener('input', () => checkSyntax(ideEditor.value));
    }

    // Re-check achievements when tab switches to progress
    const origSwitchTab = UI.switchTab;
    if (origSwitchTab) {
      UI.switchTab = function(tab) {
        origSwitchTab(tab);
        if (tab === 'progress') {
          setTimeout(renderProgressDashboard, 50);
        }
      };
    }

    // Hook into chat to track count and show badge
    const origSendChat = ChatVM.sendChat;
    if (origSendChat) {
      ChatVM.sendChat = function() {
        const achState = getAchievementsState();
        achState.chatCount = (achState.chatCount || 0) + 1;
        saveAchievementsState(achState);
        showFABBadge();
        return origSendChat.apply(this, arguments);
      };
    }

    // Hook into problem solving
    const aiChatOverlay = document.getElementById('aiChatOverlay');
    if (aiChatOverlay) {
      aiChatOverlay.addEventListener('click', (e) => {
        if (e.target === aiChatOverlay) hideFABBadge();
      });
    }
  }

  return { init, checkAchievements, renderProgressDashboard, awardXP, getAchievementsState, showFABBadge, hideFABBadge };
})();


/**
 * EDITOR ENHANCEMENTS: Autocomplete, Split View, Diff View, Daily Challenge, Improved AI
 */
const EditorEnhancements = (() => {

  // =============================================
  // 1. CODE AUTOCOMPLETE
  // =============================================
  const PYTHON_KEYWORDS = [
    { word: 'False', type: 'kw' }, { word: 'None', type: 'kw' }, { word: 'True', type: 'kw' },
    { word: 'and', type: 'kw' }, { word: 'as', type: 'kw' }, { word: 'assert', type: 'kw' },
    { word: 'async', type: 'kw' }, { word: 'await', type: 'kw' }, { word: 'break', type: 'kw' },
    { word: 'class', type: 'kw', snippet: 'class ${1:Name}:\n    def __init__(self${2:, args}):\n        ${3:pass}' },
    { word: 'continue', type: 'kw' }, { word: 'def', type: 'kw', snippet: 'def ${1:name}(${2:args}):\n    ${3:pass}' },
    { word: 'del', type: 'kw' }, { word: 'elif', type: 'kw', snippet: 'elif ${1:condition}:\n    ${2:pass}' },
    { word: 'else', type: 'kw', snippet: 'else:\n    ${1:pass}' },
    { word: 'except', type: 'kw', snippet: 'except ${1:Exception} as ${2:e}:\n    ${3:pass}' },
    { word: 'finally', type: 'kw' }, { word: 'for', type: 'kw', snippet: 'for ${1:item} in ${2:iterable}:\n    ${3:pass}' },
    { word: 'from', type: 'kw' }, { word: 'global', type: 'kw' }, { word: 'if', type: 'kw', snippet: 'if ${1:condition}:\n    ${2:pass}' },
    { word: 'import', type: 'kw', snippet: 'import ${1:module}' },
    { word: 'in', type: 'kw' }, { word: 'is', type: 'kw' }, { word: 'lambda', type: 'kw', snippet: 'lambda ${1:x}: ${2:expression}' },
    { word: 'nonlocal', type: 'kw' }, { word: 'not', type: 'kw' }, { word: 'or', type: 'kw' },
    { word: 'pass', type: 'kw' }, { word: 'raise', type: 'kw' }, { word: 'return', type: 'kw' },
    { word: 'try', type: 'kw', snippet: 'try:\n    ${1:pass}\nexcept ${2:Exception}:\n    ${3:pass}' },
    { word: 'while', type: 'kw', snippet: 'while ${1:condition}:\n    ${2:pass}' },
    { word: 'with', type: 'kw', snippet: 'with ${1:context} as ${2:var}:\n    ${3:pass}' },
    { word: 'yield', type: 'kw' },
  ];

  const PYTHON_BUILTINS = [
    { word: 'print', type: 'fn', snippet: 'print(${1:value})' },
    { word: 'len', type: 'fn', snippet: 'len(${1:obj})' },
    { word: 'range', type: 'fn', snippet: 'range(${1:start}, ${2:stop}, ${3:step})' },
    { word: 'enumerate', type: 'fn', snippet: 'enumerate(${1:iterable})' },
    { word: 'zip', type: 'fn', snippet: 'zip(${1:iter1}, ${2:iter2})' },
    { word: 'map', type: 'fn', snippet: 'map(${1:func}, ${2:iterable})' },
    { word: 'filter', type: 'fn', snippet: 'filter(${1:func}, ${2:iterable})' },
    { word: 'sorted', type: 'fn', snippet: 'sorted(${1:iterable}, key=${2:None})' },
    { word: 'reversed', type: 'fn', snippet: 'reversed(${1:iterable})' },
    { word: 'isinstance', type: 'fn', snippet: 'isinstance(${1:obj}, ${2:type})' },
    { word: 'type', type: 'fn', snippet: 'type(${1:obj})' },
    { word: 'int', type: 'fn', snippet: 'int(${1:value})' },
    { word: 'float', type: 'fn', snippet: 'float(${1:value})' },
    { word: 'str', type: 'fn', snippet: 'str(${1:value})' },
    { word: 'list', type: 'fn', snippet: 'list(${1:iterable})' },
    { word: 'dict', type: 'fn', snippet: 'dict(${1:**kwargs})' },
    { word: 'set', type: 'fn', snippet: 'set(${1:iterable})' },
    { word: 'tuple', type: 'fn', snippet: 'tuple(${1:iterable})' },
    { word: 'open', type: 'fn', snippet: 'open(${1:path}, mode="${2:r}")' },
    { word: 'input', type: 'fn', snippet: 'input(${1:prompt})' },
    { word: 'abs', type: 'fn' }, { word: 'all', type: 'fn' }, { word: 'any', type: 'fn' },
    { word: 'max', type: 'fn' }, { word: 'min', type: 'fn' }, { word: 'sum', type: 'fn' },
    { word: 'round', type: 'fn' }, { word: 'hash', type: 'fn' },
    { word: 'hasattr', type: 'fn' }, { word: 'getattr', type: 'fn' }, { word: 'setattr', type: 'fn' },
    { word: 'super', type: 'fn' }, { word: 'property', type: 'fn' },
    { word: 'staticmethod', type: 'fn' }, { word: 'classmethod', type: 'fn' },
    { word: 'Exception', type: 'fn' }, { word: 'ValueError', type: 'fn' },
    { word: 'TypeError', type: 'fn' }, { word: 'KeyError', type: 'fn' },
    { word: 'IndexError', type: 'fn' }, { word: 'AttributeError', type: 'fn' },
    { word: 'StopIteration', type: 'fn' },
  ];

  const PYTHON_SNIPPETS = [
    { word: 'ifmain', type: 'snip', snippet: 'if __name__ == "__main__":\n    ${1:main()}' },
    { word: 'fori', type: 'snip', snippet: 'for ${1:i} in range(${2:n}):\n    ${3:pass}' },
    { word: 'forx', type: 'snip', snippet: 'for ${1:x} in ${2:iterable}:\n    ${3:pass}' },
    { word: 'comp', type: 'snip', snippet: '[${1:expr} for ${2:x} in ${3:iterable}${4: if ${5:condition}}]' },
    { word: 'dictcomp', type: 'snip', snippet: '{${1:k}: ${2:v} for ${3:k}, ${4:v} in ${5:items}}' },
    { word: 'lambda', type: 'snip', snippet: 'lambda ${1:x}: ${2:expression}' },
    { word: 'withopen', type: 'snip', snippet: 'with open(${1:path}, "${2:r}") as f:\n    ${3:data = f.read()}' },
    { word: 'tryexcept', type: 'snip', snippet: 'try:\n    ${1:pass}\nexcept ${2:Exception} as ${3:e}:\n    ${4:print(e)}' },
    { word: 'class', type: 'snip', snippet: 'class ${1:Name}:\n    def __init__(self${2:, args}):\n        ${3:pass}\n\n    def ${4:method}(self${5:, args}):\n        ${6:pass}' },
    { word: 'def', type: 'snip', snippet: 'def ${1:name}(${2:args}):\n    """${3:docstring}"""\n    ${4:pass}' },
    { word: 'property', type: 'snip', snippet: '@property\ndef ${1:name}(self):\n    return self._${1}\n\n@${1}.setter\ndef ${1}(self, value):\n    self._${1} = value' },
    { word: 'decorator', type: 'snip', snippet: 'def ${1:decorator}(func):\n    def wrapper(*args, **kwargs):\n        ${2:# before}\n        result = func(*args, **kwargs)\n        ${3:# after}\n        return result\n    return wrapper' },
  ];

  let _acDropdown = null;
  let _acItems = [];
  let _acIndex = -1;
  let _acActive = false;

  function initAutocomplete() {
    _acDropdown = document.getElementById('autocompleteDropdown');
    if (!_acDropdown) return;

    ['codeEditor', 'ideEditor'].forEach(editorId => {
      const editor = document.getElementById(editorId);
      if (!editor) return;

      editor.addEventListener('input', () => handleAcInput(editor));
      editor.addEventListener('keydown', (e) => handleAcKeydown(e, editor));
      editor.addEventListener('blur', () => {
        setTimeout(() => { if (_acActive) hideAcDropdown(); }, 200);
      });
    });
  }

  function handleAcInput(editor) {
    const pos = editor.selectionStart;
    const text = editor.value.substring(0, pos);
    const match = text.match(/[\w.]+$/);
    if (!match || match[0].length < 2) { hideAcDropdown(); return; }

    const prefix = match[0];
    const items = getAcMatches(prefix);
    if (items.length === 0) { hideAcDropdown(); return; }

    showAcDropdown(items, editor, prefix);
  }

  function getAcMatches(prefix) {
    const lower = prefix.toLowerCase();
    const items = [];

    // Match user-defined names from code
    const editor = document.getElementById('codeEditor');
    if (editor) {
      const code = editor.value;
      const varMatches = code.match(/\b([a-z_]\w{2,})\b/gi) || [];
      const uniqueVars = [...new Set(varMatches)].filter(v =>
        v.toLowerCase().startsWith(lower) &&
        !PYTHON_KEYWORDS.some(k => k.word === v) &&
        !PYTHON_BUILTINS.some(b => b.word === v)
      );
      uniqueVars.slice(0, 5).forEach(v => items.push({ word: v, type: 'var', icon: '𝑥' }));
    }

    PYTHON_KEYWORDS.filter(k => k.word.startsWith(lower)).forEach(k => items.push({ ...k, icon: '🔑' }));
    PYTHON_BUILTINS.filter(b => b.word.startsWith(lower)).forEach(b => items.push({ ...b, icon: '⚡' }));
    PYTHON_SNIPPETS.filter(s => s.word.startsWith(lower)).forEach(s => items.push({ ...s, icon: '📝' }));

    return items.slice(0, 10);
  }

  function showAcDropdown(items, editor, prefix) {
    _acItems = items;
    _acIndex = 0;
    _acActive = true;

    const typeLabels = { kw: 'keyword', fn: 'builtin', snip: 'snippet', var: 'variable' };
    _acDropdown.innerHTML = items.map((item, i) => {
      const activeClass = i === 0 ? 'active' : '';
      return `<div class="autocomplete-item ${activeClass}" data-idx="${i}">
        <span class="ac-icon">${item.icon || '•'}</span>
        <span class="ac-word">${item.word}</span>
        <span class="ac-type">${typeLabels[item.type] || item.type}</span>
      </div>`;
    }).join('');

    // Position dropdown near cursor
    const textBefore = editor.value.substring(0, editor.selectionStart);
    const lines = textBefore.split('\n');
    const currentLine = lines.length;
    const currentCol = lines[lines.length - 1].length;

    const lineHeight = parseInt(getComputedStyle(editor).lineHeight) || 21;
    const charWidth = 8.4; // approximate for monospace
    const editorRect = editor.getBoundingClientRect();
    const scrollTop = editor.scrollTop;

    const top = (currentLine * lineHeight) - scrollTop + 4;
    const left = Math.min(currentCol * charWidth, editor.clientWidth - 230);

    _acDropdown.style.top = Math.max(0, top) + 'px';
    _acDropdown.style.left = Math.max(0, left) + 'px';
    _acDropdown.classList.add('open');

    // Click handler
    _acDropdown.querySelectorAll('.autocomplete-item').forEach(el => {
      el.addEventListener('mousedown', (e) => {
        e.preventDefault();
        insertAcItem(items[parseInt(el.dataset.idx)], editor);
      });
    });
  }

  function hideAcDropdown() {
    if (_acDropdown) _acDropdown.classList.remove('open');
    _acActive = false;
    _acItems = [];
    _acIndex = -1;
  }

  function handleAcKeydown(e, editor) {
    if (!_acActive) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      _acIndex = Math.min(_acIndex + 1, _acItems.length - 1);
      updateAcHighlight();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      _acIndex = Math.max(_acIndex - 1, 0);
      updateAcHighlight();
    } else if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault();
      if (_acItems[_acIndex]) insertAcItem(_acItems[_acIndex], editor);
    } else if (e.key === 'Escape') {
      hideAcDropdown();
    }
  }

  function updateAcHighlight() {
    if (!_acDropdown) return;
    _acDropdown.querySelectorAll('.autocomplete-item').forEach((el, i) => {
      el.classList.toggle('active', i === _acIndex);
    });
  }

  function insertAcItem(item, editor) {
    const pos = editor.selectionStart;
    const text = editor.value;
    const before = text.substring(0, pos);
    const after = text.substring(pos);
    const match = before.match(/[\w.]+$/);
    const wordStart = match ? pos - match[0].length : pos;

    let insertText = item.snippet || item.word;
    // Simple tab-stop replacement: replace ${1:default} with default
    insertText = insertText.replace(/\$\{\d+:([^}]*)\}/g, '$1');
    insertText = insertText.replace(/\$\d+/g, '');

    editor.value = text.substring(0, wordStart) + insertText + after;
    editor.selectionStart = editor.selectionEnd = wordStart + insertText.length;
    editor.focus();
    hideAcDropdown();
    DOM.updateLineNumbers();
    if (typeof autoSave === 'function') autoSave();
  }

  // =============================================
  // 2. SPLIT VIEW
  // =============================================
  function initSplitView() {
    const btn = document.getElementById('splitToggleBtn');
    const closeBtn = document.getElementById('splitPaneCloseBtn');
    const pane = document.getElementById('splitViewPane');
    if (!btn || !closeBtn || !pane) return;

    btn.addEventListener('click', () => toggleSplitView());
    closeBtn.addEventListener('click', () => toggleSplitView());
  }

  function toggleSplitView() {
    const layout = document.getElementById('appLayout');
    const pane = document.getElementById('splitViewPane');
    const btn = document.getElementById('splitToggleBtn');
    if (!layout || !pane || !btn) return;

    const isOpen = layout.classList.toggle('split-view');
    pane.classList.toggle('hidden', !isOpen);
    btn.classList.toggle('active', isOpen);
    btn.innerHTML = isOpen ? '&#128449; Close Split' : '&#128449; Split';

    if (isOpen) syncSplitLesson();
  }

  function syncSplitLesson() {
    const mainTitle = document.getElementById('lessonTitle');
    const mainContent = document.getElementById('lessonContent');
    const splitTitle = document.getElementById('splitLessonTitle');
    const splitContent = document.getElementById('splitLessonContent');
    if (mainTitle && splitTitle) splitTitle.textContent = mainTitle.textContent;
    if (mainContent && splitContent) splitContent.innerHTML = mainContent.innerHTML;
  }

  // Hook into lesson loading to sync split view
  function hookLessonSync() {
    const origLoadTopic = UI.loadTopic;
    if (!origLoadTopic) return;
    UI.loadTopic = function(id) {
      origLoadTopic(id);
      const layout = document.getElementById('appLayout');
      if (layout && layout.classList.contains('split-view')) {
        setTimeout(syncSplitLesson, 100);
      }
    };
  }

  // =============================================
  // 3. CODE DIFF VIEW
  // =============================================
  function computeDiff(expected, actual) {
    const expLines = expected.replace(/\r\n/g, '\n').split('\n');
    const actLines = actual.replace(/\r\n/g, '\n').split('\n');
    const maxLen = Math.max(expLines.length, actLines.length);
    const result = [];

    for (let i = 0; i < maxLen; i++) {
      const exp = expLines[i] !== undefined ? expLines[i] : '';
      const act = actLines[i] !== undefined ? actLines[i] : '';
      if (exp === act) {
        result.push({ type: 'same', expected: exp, actual: act, line: i + 1 });
      } else {
        if (expLines[i] !== undefined) result.push({ type: 'removed', expected: exp, actual: '', line: i + 1 });
        if (actLines[i] !== undefined) result.push({ type: 'added', expected: '', actual: act, line: i + 1 });
      }
    }
    return result;
  }

  function renderDiffView(expected, actual, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const diff = computeDiff(expected.trim(), actual.trim());
    const hasDifferences = diff.some(d => d.type !== 'same');

    let html = `<div class="diff-view">
      <div class="diff-header">
        <span>${hasDifferences ? '⚠️ Output differs from expected' : '✅ Output matches!'}</span>
        <div class="diff-legend">
          <span><span class="diff-dot" style="background:var(--error)"></span> Expected</span>
          <span><span class="diff-dot" style="background:var(--success)"></span> Your output</span>
        </div>
      </div>
      <div class="diff-content">
        <div class="diff-panel">
          <div class="diff-panel-title">Expected Output</div>`;

    diff.forEach(d => {
      if (d.type === 'added') return;
      const cls = d.type === 'removed' ? 'removed' : 'same';
      html += `<div class="diff-line ${cls}"><span class="diff-line-num">${d.line}</span>${DOM.escapeHtml(d.expected)}</div>`;
    });

    html += `</div><div class="diff-panel">
          <div class="diff-panel-title">Your Output</div>`;

    diff.forEach(d => {
      if (d.type === 'removed') return;
      const cls = d.type === 'added' ? 'added' : 'same';
      html += `<div class="diff-line ${cls}"><span class="diff-line-num">${d.line}</span>${DOM.escapeHtml(d.actual)}</div>`;
    });

    html += '</div></div></div>';
    container.innerHTML = html;
  }

  // Hook into exercise checking to add diff view
  function hookExerciseDiff() {
    const origCheckAnswer = ExercisesVM.checkAnswer;
    if (!origCheckAnswer) return;

    ExercisesVM.checkAnswer = async function(idx) {
      if (!PyodideEngine.isReady()) { DOM.showToast('Python is still loading...', 'error'); return; }
      const topic = Curriculum.getTopic(EditorVM.getCurrentTopicId());
      if (!topic) return;
      const ex = topic.exercises[idx];
      const code = DOM.el.codeEditor().value;

      if (ex.testCases && ex.testCases.length > 0) {
        const results = await PyodideEngine.runWithTestCases(code, ex.testCases);
        DOM.renderTestResults(idx, results);
        const allPassed = results.every(r => r.passed);
        if (allPassed) {
          const progress = State.getProgress();
          if (!progress[EditorVM.getCurrentTopicId()]) progress[EditorVM.getCurrentTopicId()] = { lessonDone: true, exercises: {} };
          if (!progress[EditorVM.getCurrentTopicId()].exercises) progress[EditorVM.getCurrentTopicId()].exercises = {};
          progress[EditorVM.getCurrentTopicId()].exercises[idx] = true;
          State.saveProgress(progress);
          DOM.updateProgressBadge(Curriculum.getProgressPercent(progress));
          DOM.showToast('✅ All tests passed!', 'success');
          if (typeof Enhancements !== 'undefined' && Enhancements.checkAchievements) Enhancements.checkAchievements();
        } else {
          DOM.showToast('❌ Some tests failed. Try again!', 'error');
        }
      } else {
        const { stdout, stderr, error } = await PyodideEngine.runScript(code);
        const output = stdout;
        const expected = ex.expectedOutput.replace(/\\n/g, '\n').replace(/\\t/g, '\\t').replace(/\r\n/g, '\n').trim();
        const expectedClean = normalizeAnswerText(expected);
        const outputClean = normalizeAnswerText(output);

        if (error) {
          DOM.setOutput(`<span class="err-text">${DOM.escapeHtml(error.message)}</span>`);
          DOM.showToast('Error in code!', 'error');
        } else if (outputClean === expectedClean || outputClean.replace(/\s+/g, ' ') === expectedClean.replace(/\s+/g, ' ')) {
          DOM.setOutput(`<span class="out-text">${DOM.escapeHtml(outputClean)}</span><br><br><span style="color:var(--success);font-weight:bold;">✅ Correct! Great job!</span>`);
          const progress = State.getProgress();
          if (!progress[EditorVM.getCurrentTopicId()]) progress[EditorVM.getCurrentTopicId()] = { lessonDone: true, exercises: {} };
          if (!progress[EditorVM.getCurrentTopicId()].exercises) progress[EditorVM.getCurrentTopicId()].exercises = {};
          progress[EditorVM.getCurrentTopicId()].exercises[idx] = true;
          State.saveProgress(progress);
          DOM.updateProgressBadge(Curriculum.getProgressPercent(progress));
          DOM.showToast('✅ Exercise completed!', 'success');
          if (typeof Enhancements !== 'undefined' && Enhancements.checkAchievements) Enhancements.checkAchievements();
        } else {
          // Show diff view!
          let html = `<span class="out-text">${DOM.escapeHtml(outputClean)}</span><br><br>`;
          html += `<span class="err-text">❌ Output doesn't match expected.</span>`;
          html += `<div id="diffContainer_${idx}"></div>`;
          DOM.setOutput(html);
          setTimeout(() => {
            renderDiffView(expectedClean, outputClean, `diffContainer_${idx}`);
          }, 50);
          DOM.showToast('Not quite right. Try again!', 'error');
        }
      }
    };
  }

  // =============================================
  // 4. DAILY CHALLENGE
  // =============================================
  function getDailyChallenge() {
    const today = new Date();
    const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
    const problems = Curriculum.getProblemBank();
    if (!problems.length) return null;

    // Deterministic daily selection based on date
    const idx = seed % problems.length;
    const problem = problems[idx];
    return {
      problem: problem,
      xp: problem.difficulty === 'Easy' ? 30 : problem.difficulty === 'Medium' ? 50 : 80,
      completed: isDailyCompleted(seed),
      seed: seed
    };
  }

  function isDailyCompleted(seed) {
    try {
      const data = JSON.parse(localStorage.getItem('pylearn_daily') || '{}');
      return data.seed === seed && data.completed;
    } catch { return false; }
  }

  function markDailyCompleted(seed) {
    localStorage.setItem('pylearn_daily', JSON.stringify({ seed, completed: true, date: new Date().toISOString() }));
  }

  function renderDailyChallenge() {
    const banner = document.getElementById('dailyChallengeBanner');
    const desc = document.getElementById('dailyChallengeDesc');
    const xp = document.getElementById('dailyChallengeXP');
    const btn = document.getElementById('dailyChallengeBtn');
    if (!banner || !desc || !xp || !btn) return;

    const challenge = getDailyChallenge();
    if (!challenge) { banner.style.display = 'none'; return; }

    banner.style.display = 'flex';
    banner.classList.toggle('completed', challenge.completed);
    const probText = challenge.problem.description || challenge.problem.title || 'Daily Challenge';
    desc.textContent = `[${challenge.problem.difficulty}] ${probText.substring(0, 80)}${probText.length > 80 ? '...' : ''}`;
    xp.textContent = challenge.xp;

    if (challenge.completed) {
      btn.textContent = '✓ Done!';
      btn.disabled = true;
      banner.querySelector('.dc-icon').textContent = '✅';
    } else {
      btn.textContent = 'Try it!';
      btn.disabled = false;
      banner.querySelector('.dc-icon').textContent = '🏆';
      btn.onclick = () => startDailyChallenge(challenge);
    }
  }

  function startDailyChallenge(challenge) {
    // Switch to problems tab and load the challenge
    UI.switchTab('problems');
    // Find and highlight the problem
    const problems = Curriculum.getProblemBank();
    const idx = problems.findIndex(p => p.id === challenge.problem.id);
    if (idx >= 0) {
      // Load the problem into the editor
      DOM.el.codeEditor().value = challenge.problem.starterCode;
      DOM.updateLineNumbers();
      DOM.showToast(`Daily Challenge loaded! Complete it for +${challenge.xp} XP`, 'info');
    }
  }

  // Hook into problem completion to check daily challenge
  function hookDailyChallenge() {
    const origCheckProblem = ProblemsVM.checkSolution;
    if (!origCheckProblem) return;

    ProblemsVM.checkSolution = async function(problemId) {
      const result = await origCheckProblem.apply(this, arguments);
      const challenge = getDailyChallenge();
      if (challenge && challenge.problem.id === problemId && !challenge.completed) {
        markDailyCompleted(challenge.seed);
        if (typeof Enhancements !== 'undefined' && Enhancements.awardXP) {
          Enhancements.awardXP(challenge.xp);
        }
        renderDailyChallenge();
        DOM.showToast(`🎉 Daily Challenge complete! +${challenge.xp} XP`, 'success');
      }
      return result;
    };
  }

  // =============================================
  // 5. IMPROVED LOCAL AI
  // =============================================
  function initImprovedAI() {
    // Add context awareness to the AI chip
    const origLoadTopic2 = UI.loadTopic;
    if (origLoadTopic2) {
      UI.loadTopic = function(id) {
        origLoadTopic2(id);
        updateAIContext(id);
      };
    }

    // Context chip clear button
    const clearBtn = document.getElementById('aiContextClear');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        const chip = document.getElementById('aiContextChip');
        if (chip) chip.style.display = 'none';
      });
    }

    // Suggestion buttons
    document.querySelectorAll('.ai-suggestion-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const q = btn.dataset.q;
        const input = document.getElementById('chatInput');
        if (input) {
          input.value = q;
          if (typeof sendChat === 'function') sendChat();
        }
      });
    });
  }

  function updateAIContext(topicId) {
    const chip = document.getElementById('aiContextChip');
    const label = document.getElementById('aiContextLabel');
    if (!chip || !label) return;

    const topic = Curriculum.getTopic(topicId);
    if (topic) {
      label.textContent = `Context: ${topic.title}`;
      chip.style.display = 'inline-flex';
    }
  }

  // Enhanced local response with fuzzy matching and context awareness
  function enhanceLocalAI() {
    const origGenerateLocal = ChatVM.generateLocalResponse;
    if (!origGenerateLocal) return;

    ChatVM.generateLocalResponse = function(msg) {
      const m = msg.toLowerCase().trim();

      // Greetings
      if (/^(hi|hello|hey|howdy|greetings|sup|yo)\b/.test(m))
        return 'Hello! 👋 I\'m your Python AI Tutor. Ask me anything about Python, or try the suggestion buttons below!';

      // Thanks
      if (/\b(thank|thanks|thx|ty)\b/.test(m))
        return 'You\'re welcome! 😊 Keep coding and don\'t hesitate to ask more questions!';

      // Help
      if (/\b(help|what can you do|capabilities)\b/.test(m))
        return '🤖 **I can help you with:**\n\n• **Explain concepts** — Ask about any Python topic\n• **Analyze code** — Use "Explain Code" to understand your code\n• **Give hints** — Get hints for exercises\n• **Suggest next steps** — "What should I learn next?"\n• **Coding challenges** — "Give me a challenge"\n• **Debug help** — Describe your error\n\nI work best when you have a topic selected in the sidebar!';

      // Coding challenge request
      if (/\b(challenge|exercise|practice problem|give me something)\b/.test(m)) {
        const challenges = [
          { q: 'Write a function that checks if a string is a palindrome.', hint: 'Compare the string to its reverse: s == s[::-1]' },
          { q: 'Create a function that returns the nth Fibonacci number using recursion.', hint: 'Base cases: fib(0)=0, fib(1)=1. Recursive: fib(n-1) + fib(n-2)' },
          { q: 'Write a list comprehension that filters odd numbers from 1-50 and squares them.', hint: '[x**2 for x in range(1,51) if x%2!=0]' },
          { q: 'Create a dictionary comprehension mapping letters to their position in the alphabet.', hint: '{chr(i): i-96 for i in range(97, 123)}' },
          { q: 'Write a function that counts word frequency in a string.', hint: 'Use str.split() and a dict with .get()' },
          { q: 'Implement a decorator that times function execution.', hint: 'Use time.time() before and after calling the wrapped function.' },
          { q: 'Write a generator that yields prime numbers indefinitely.', hint: 'Use a while True loop and check divisibility up to sqrt(n).' },
          { q: 'Create a class hierarchy: Animal → Dog, Cat with a speak() method.', hint: 'Use inheritance and method overriding.' },
        ];
        const ch = challenges[Math.floor(Math.random() * challenges.length)];
        return `🎯 **Coding Challenge:**\n\n${ch.q}\n\n💡 *Hint: ${ch.hint}*\n\nTry solving it in the editor, then ask me to check your solution!`;
      }

      // Debug help
      if (/\b(error|bug|fix|debug|wrong|broken|not working|traceback)\b/.test(m))
        return '🐛 **Debugging Tips:**\n\n1. **Read the error message** — Python tells you the exact line and error type\n2. **Check common issues:**\n   • Missing colons (`:`) after if/for/def/class\n   • Mismatched brackets `()[]{}`\n   • Indentation errors (use 4 spaces)\n   • Using `=` instead of `==`\n   • Forgetting to convert types (`int(input())`)\n3. **Use print()** to check variable values\n4. **Use the Syntax Check** bar below the editor!\n\nPaste your error message and I\'ll help you understand it!';

      // Context-aware responses based on current topic
      const currentTopicId = EditorVM.getCurrentTopicId ? EditorVM.getCurrentTopicId() : null;
      const currentTopic = currentTopicId ? Curriculum.getTopic(currentTopicId) : null;

      // Try exact keyword matching first
      for (const [key, response] of Object.entries(knowledgeResponses)) {
        if (m.includes(key)) {
          let prefix = '';
          if (currentTopic && m.includes(currentTopic.title.toLowerCase().split(' ')[0])) {
            prefix = `📘 *While you're learning about ${currentTopic.title}:*\n\n`;
          }
          return prefix + response;
        }
      }

      // Fuzzy topic matching
      if (currentTopic) {
        const topicWords = currentTopic.title.toLowerCase().split(/\s+/);
        for (const word of topicWords) {
          if (word.length > 3 && m.includes(word)) {
            const km = Curriculum.getKnowledgeMap(currentTopicId);
            let resp = `📘 **About ${currentTopic.title}:**\n\n`;
            if (km && km.beginner) resp += km.beginner + '\n\n';
            resp += `You're currently learning this topic! Check the Lesson tab for a detailed explanation, or ask me a specific question about it.`;
            return resp;
          }
        }
      }

      // "What next" suggestion
      if (/\b(what next|what should|suggest|recommend|where to)\b/.test(m)) {
        return suggestNext();
      }

      // Cloud AI fallback message
      const provider = State.getSetting('ai_provider') || 'local';
      const cfg = AI_PROVIDERS[provider] || AI_PROVIDERS.local;
      if (provider !== 'local') {
        return 'I\'m connected to ' + cfg.name + ' but couldn\'t process your request. Try rephrasing your question.\n\nYou can also switch to Local mode in Settings for built-in knowledge.';
      }

      // Enhanced fallback with suggestions
      const suggestions = currentTopic
        ? [
            `Tell me more about ${currentTopic.title}`,
            'Explain variables',
            'How do loops work?',
            'Give me a coding challenge',
            'What should I learn next?',
          ]
      : [
          'Explain variables',
          'How do loops work?',
          'Give me a coding challenge',
          'What should I learn next?',
        ];

      let resp = 'Great question! 🤔 I have built-in knowledge about many Python topics.\n\n';
      resp += '**Try asking about:** variables, strings, lists, dicts, tuples, sets, loops, functions, classes, errors, modules, decorators, comprehensions, f-strings, lambda, recursion, generators, async, testing, OOP, context managers, memory, logging, debugging, closures, threading, or interview tips!\n\n';
      resp += '**Or try one of these:**\n';
      suggestions.forEach(s => { resp += `• "${s}"\n`; });
      resp += '\nYou can also set up a cloud AI provider in Settings for advanced responses.';

      return resp;
    };
  }

  // =============================================
  // 6. CUSTOM THEMES
  // =============================================
  const THEMES = ['dark', 'light', 'dracula', 'github', 'nord', 'solarized', 'monokai'];

  function initThemes() {
    const switcher = document.getElementById('themeSwitcher');
    if (!switcher) return;

    // Load saved theme
    const savedTheme = State.getSetting('theme') || 'dark';
    if (THEMES.includes(savedTheme)) {
      document.documentElement.setAttribute('data-theme', savedTheme);
      updateThemeButtons(savedTheme);
    }

    switcher.querySelectorAll('.theme-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const theme = btn.dataset.theme;
        document.documentElement.setAttribute('data-theme', theme);
        State.setSetting('theme', theme);
        updateThemeButtons(theme);
        DOM.showToast(`Theme: ${theme}`, 'info');
      });
    });
  }

  function updateThemeButtons(activeTheme) {
    document.querySelectorAll('.theme-btn').forEach(btn => {
      const isActive = btn.dataset.theme === activeTheme;
      btn.classList.toggle('active', isActive);
      btn.querySelector('.theme-check')?.style && (btn.querySelector('.theme-check').style.display = isActive ? 'block' : 'none');
      if (isActive && !btn.querySelector('.theme-check')) {
        btn.innerHTML = '&#10003;';
      } else if (!isActive && btn.querySelector('.theme-check')) {
        btn.innerHTML = '';
      }
    });
  }

  // =============================================
  // 7. VIM KEYBINDINGS
  // =============================================
  let _vimMode = 'normal';
  let _vimBuffer = '';

  function initVimMode() {
    const keybindingSelect = document.getElementById('keybindingSelect');
    if (!keybindingSelect) return;

    // Load saved preference
    const saved = State.getSetting('keybinding') || 'default';
    keybindingSelect.value = saved;
    if (saved === 'vim') enableVimMode();

    keybindingSelect.addEventListener('change', () => {
      const mode = keybindingSelect.value;
      State.setSetting('keybinding', mode);
      if (mode === 'vim') enableVimMode();
      else disableVimMode();
    });
  }

  function enableVimMode() {
    ['codeEditor', 'ideEditor'].forEach(id => {
      const editor = document.getElementById(id);
      if (!editor) return;
      editor.addEventListener('keydown', vimKeyHandler);
    });
    const statusBar = document.getElementById('vimStatusBar');
    if (statusBar) statusBar.classList.add('visible');
  }

  function disableVimMode() {
    ['codeEditor', 'ideEditor'].forEach(id => {
      const editor = document.getElementById(id);
      if (!editor) return;
      editor.removeEventListener('keydown', vimKeyHandler);
    });
    const statusBar = document.getElementById('vimStatusBar');
    if (statusBar) statusBar.classList.remove('visible');
  }

  function vimKeyHandler(e) {
    const statusBar = document.getElementById('vimStatusBar');
    const modeLabel = document.getElementById('vimMode');
    const cmdLabel = document.getElementById('vimCmd');
    if (!statusBar) return;

    if (_vimMode === 'normal') {
      // Don't intercept Ctrl+ combinations (let them pass through for shortcuts)
      if (e.ctrlKey) return;

      switch (e.key) {
        case 'i':
          _vimMode = 'insert';
          modeLabel.textContent = 'INSERT';
          cmdLabel.textContent = '';
          _vimBuffer = '';
          break;
        case 'h': moveCursor(e, -1); break;
        case 'l': moveCursor(e, 1); break;
        case 'j': moveLine(e, 1); break;
        case 'k': moveLine(e, -1); break;
        case 'x': deleteChar(e); break;
        case 'd':
          _vimBuffer = 'd';
          cmdLabel.textContent = 'd';
          break;
        case 'G':
          goToEnd(e);
          break;
        case 'g':
          if (_vimBuffer === 'g') { goToStart(e); _vimBuffer = ''; }
          else { _vimBuffer = 'g'; cmdLabel.textContent = 'g'; }
          break;
        case 'u':
          document.execCommand('undo');
          break;
        case ':':
          _vimMode = 'command';
          modeLabel.textContent = 'COMMAND';
          cmdLabel.textContent = ':';
          _vimBuffer = ':';
          break;
        default:
          _vimBuffer = '';
          cmdLabel.textContent = '';
      }
      if (_vimMode === 'normal' && !['h','l','j','k','x','d','g','G','i','u',':'].includes(e.key)) {
        e.preventDefault();
      }
    } else if (_vimMode === 'insert') {
      if (e.key === 'Escape') {
        _vimMode = 'normal';
        modeLabel.textContent = 'NORMAL';
        cmdLabel.textContent = '';
        e.preventDefault();
      }
      // Let all other keys pass through in insert mode
    } else if (_vimMode === 'command') {
      if (e.key === 'Escape') {
        _vimMode = 'normal';
        modeLabel.textContent = 'NORMAL';
        cmdLabel.textContent = '';
        _vimBuffer = '';
        e.preventDefault();
      } else if (e.key === 'Enter') {
        executeVimCommand(_vimBuffer);
        _vimMode = 'normal';
        modeLabel.textContent = 'NORMAL';
        cmdLabel.textContent = '';
        _vimBuffer = '';
        e.preventDefault();
      } else if (e.key === 'Backspace') {
        _vimBuffer = _vimBuffer.slice(0, -1);
        cmdLabel.textContent = _vimBuffer;
        if (_vimBuffer === '') {
          _vimMode = 'normal';
          modeLabel.textContent = 'NORMAL';
        }
        e.preventDefault();
      } else if (e.key.length === 1) {
        _vimBuffer += e.key;
        cmdLabel.textContent = _vimBuffer;
        e.preventDefault();
      }
    }
  }

  function moveCursor(e, dir) {
    const editor = e.target;
    const pos = editor.selectionStart;
    editor.selectionStart = editor.selectionEnd = Math.max(0, Math.min(pos + dir, editor.value.length));
    e.preventDefault();
  }

  function moveLine(e, dir) {
    const editor = e.target;
    const pos = editor.selectionStart;
    const lines = editor.value.substring(0, pos).split('\n');
    const currentLine = lines.length - 1;
    const newLine = Math.max(0, Math.min(currentLine + dir, editor.value.split('\n').length - 1));
    let newPos = 0;
    const allLines = editor.value.split('\n');
    for (let i = 0; i < newLine; i++) newPos += allLines[i].length + 1;
    const col = lines[currentLine].length;
    editor.selectionStart = editor.selectionEnd = Math.min(newPos + col, editor.value.length);
    e.preventDefault();
  }

  function deleteChar(e) {
    const editor = e.target;
    const pos = editor.selectionStart;
    if (pos < editor.value.length) {
      editor.value = editor.value.substring(0, pos) + editor.value.substring(pos + 1);
      DOM.updateLineNumbers();
    }
    e.preventDefault();
  }

  function goToStart(e) {
    e.target.selectionStart = e.target.selectionEnd = 0;
  }

  function goToEnd(e) {
    e.target.selectionStart = e.target.selectionEnd = e.target.value.length;
  }

  function executeVimCommand(cmd) {
    if (cmd === ':w' || cmd === ':wq') {
      if (typeof autoSave === 'function') autoSave();
      DOM.showToast('Saved!', 'success');
    } else if (cmd === ':q') {
      DOM.showToast('Cannot quit the editor 😄', 'info');
    } else if (cmd === ':wq!') {
      if (typeof autoSave === 'function') autoSave();
      DOM.showToast('Force saved!', 'success');
    }
  }

  // =============================================
  // 8. FULL-TEXT SEARCH
  // =============================================
  function initSearch() {
    const overlay = document.getElementById('searchOverlay');
    const input = document.getElementById('globalSearchInput');
    if (!overlay || !input) return;

    // Open search with Ctrl+Shift+F
    document.addEventListener('keydown', (e) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'F') {
        e.preventDefault();
        openSearch();
      }
      if (e.key === 'Escape' && overlay.classList.contains('open')) {
        closeSearch();
      }
    });

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeSearch();
    });

    input.addEventListener('input', () => performSearch(input.value));
  }

  function openSearch() {
    const overlay = document.getElementById('searchOverlay');
    const input = document.getElementById('globalSearchInput');
    if (!overlay || !input) return;
    overlay.classList.add('open');
    input.focus();
    input.value = '';
    document.getElementById('searchResults').innerHTML = '<div class="search-empty">Type to search across all content</div>';
  }

  function closeSearch() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay) overlay.classList.remove('open');
  }

  function performSearch(query) {
    const results = document.getElementById('searchResults');
    if (!results) return;
    if (!query.trim()) {
      results.innerHTML = '<div class="search-empty">Type to search across all content</div>';
      return;
    }

    const q = query.toLowerCase();
    const items = [];

    // Search topics/lessons
    Curriculum.getAllTopics().forEach(topic => {
      const titleMatch = topic.title.toLowerCase().includes(q);
      const levelMatch = topic.level.toLowerCase().includes(q);
      if (titleMatch || levelMatch) {
        items.push({
          icon: topic.icon,
          title: topic.title,
          desc: `Lesson — ${topic.level}`,
          tag: 'Lesson',
          action: () => { closeSearch(); UI.loadTopic(topic.id); UI.switchTab('lesson'); }
        });
      }
      // Search exercises
      if (topic.exercises) {
        topic.exercises.forEach((ex, i) => {
          if (ex.problem.toLowerCase().includes(q)) {
            items.push({
              icon: '&#9989;',
              title: ex.problem.substring(0, 60),
              desc: `Exercise — ${topic.title}`,
              tag: 'Exercise',
              action: () => { closeSearch(); UI.loadTopic(topic.id); UI.switchTab('exercise'); }
            });
          }
        });
      }
    });

    // Search problems
    Curriculum.getProblemBank().forEach(prob => {
      if (prob.problem.toLowerCase().includes(q) || prob.difficulty.toLowerCase().includes(q)) {
        items.push({
          icon: '&#127942;',
          title: prob.problem.substring(0, 60),
          desc: `Problem — ${prob.difficulty}`,
          tag: 'Problem',
          action: () => { closeSearch(); UI.switchTab('problems'); }
        });
      }
    });

    if (items.length === 0) {
      results.innerHTML = '<div class="search-empty">No results found</div>';
      return;
    }

    results.innerHTML = items.map((item, i) => `
      <div class="search-result-item" data-idx="${i}" role="option" tabindex="0">
        <span class="sr-icon">${item.icon}</span>
        <div class="sr-text"><strong>${DOM.escapeHtml(item.title)}</strong><p>${DOM.escapeHtml(item.desc)}</p></div>
        <span class="sr-tag">${item.tag}</span>
      </div>
    `).join('');

    results.querySelectorAll('.search-result-item').forEach(el => {
      el.addEventListener('click', () => items[parseInt(el.dataset.idx)].action());
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter') items[parseInt(el.dataset.idx)].action(); });
    });
  }

  // =============================================
  // 9. CODE SHARING
  // =============================================
  function initSharing() {
    const shareBtn = document.getElementById('shareCodeBtn');
    const shareModal = document.getElementById('shareModal');
    const shareClose = document.getElementById('shareCloseBtn');
    if (!shareBtn || !shareModal) return;

    shareBtn.addEventListener('click', () => {
      shareModal.classList.add('show');
      generateShareLink();
    });
    shareClose.addEventListener('click', () => shareModal.classList.remove('show'));
    shareModal.addEventListener('click', (e) => { if (e.target === shareModal) shareModal.classList.remove('show'); });

    const copyBtn = document.getElementById('shareCopyBtn');
    if (copyBtn) copyBtn.addEventListener('click', () => {
      const input = document.getElementById('shareLinkInput');
      navigator.clipboard.writeText(input.value).then(() => DOM.showToast('Link copied!', 'success'));
    });

    const downloadBtn = document.getElementById('shareDownloadBtn');
    if (downloadBtn) downloadBtn.addEventListener('click', downloadCode);

    const clipboardBtn = document.getElementById('shareClipboardBtn');
    if (clipboardBtn) clipboardBtn.addEventListener('click', () => {
      const code = DOM.el.codeEditor().value;
      navigator.clipboard.writeText(code).then(() => DOM.showToast('Code copied!', 'success'));
    });

    const gistBtn = document.getElementById('shareGistBtn');
    if (gistBtn) gistBtn.addEventListener('click', createGist);
  }

  function generateShareLink() {
    const code = DOM.el.codeEditor().value;
    const encoded = btoa(encodeURIComponent(code));
    const url = window.location.origin + window.location.pathname + '#code=' + encoded;
    const input = document.getElementById('shareLinkInput');
    if (input) input.value = url;
  }

  function downloadCode() {
    const code = DOM.el.codeEditor().value;
    const blob = new Blob([code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pylearn-code.py';
    a.click();
    URL.revokeObjectURL(url);
    DOM.showToast('File downloaded!', 'success');
  }

  async function createGist() {
    const token = prompt('Enter your GitHub Personal Access Token:');
    if (!token) return;
    const code = DOM.el.codeEditor().value;
    const description = prompt('Gist description:', 'PyLearn AI Code');
    if (!description) return;

    try {
      const resp = await fetch('https://api.github.com/gists', {
        method: 'POST',
        headers: { 'Authorization': 'token ' + token, 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, public: false, files: { 'code.py': { content: code } } })
      });
      const data = await resp.json();
      if (data.html_url) {
        navigator.clipboard.writeText(data.html_url);
        DOM.showToast('Gist created! URL copied.', 'success');
      } else {
        DOM.showToast('Failed: ' + (data.message || 'Unknown error'), 'error');
      }
    } catch (e) {
      DOM.showToast('Network error', 'error');
    }
  }

  // =============================================
  // 10. GITHUB PORTFOLIO
  // =============================================
  function initGitHubPortfolio() {
    const btn = document.getElementById('gpExportBtn');
    if (!btn) return;

    btn.addEventListener('click', async () => {
      const token = document.getElementById('gpToken').value.trim();
      const repo = document.getElementById('gpRepo').value.trim();
      const status = document.getElementById('gpStatus');
      if (!token || !repo) { showGpStatus('Please enter token and repo name', 'error'); return; }

      btn.disabled = true;
      showGpStatus('Exporting to GitHub...', 'info');

      try {
        // Get or create repo
        let repoExists = false;
        const userResp = await fetch('https://api.github.com/user', { headers: { 'Authorization': 'token ' + token } });
        if (!userResp.ok) throw new Error('Invalid token');
        const user = await userResp.json();

        const repoCheck = await fetch(`https://api.github.com/repos/${user.login}/${repo}`, { headers: { 'Authorization': 'token ' + token } });
        if (repoCheck.ok) {
          repoExists = true;
        } else {
          // Create repo
          const createResp = await fetch('https://api.github.com/user/repos', {
            method: 'POST',
            headers: { 'Authorization': 'token ' + token, 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: repo, description: 'My Python Learning Portfolio', auto_init: true })
          });
          if (!createResp.ok) throw new Error('Failed to create repo');
        }

        // Collect all solutions
        const progress = State.getProgress();
        const topics = Curriculum.getAllTopics();
        let readme = '# My Python Learning Portfolio\n\nGenerated by PyLearn AI\n\n';
        readme += '## Progress\n\n';
        topics.forEach(t => {
          const tp = progress[t.id] || {};
          const done = tp.lessonDone ? '✅' : '⬜';
          readme += `- ${done} ${t.title} ${t.icon}\n`;
        });

        // Push README
        const content = btoa(readme);
        await pushFile(token, user.login, repo, 'README.md', content, 'Portfolio progress');

        // Push completed exercise solutions
        topics.forEach(t => {
          if (progress[t.id] && progress[t.id].exercises) {
            const exIds = Object.keys(progress[t.id].exercises);
            exIds.forEach(exIdx => {
              const ex = t.exercises[parseInt(exIdx)];
              if (ex && ex.solution) {
                const fileName = `${t.id}_ex${parseInt(exIdx) + 1}.py`;
                const fileContent = btoa(`# ${t.title} - Exercise ${parseInt(exIdx) + 1}\n# ${ex.problem}\n\n${ex.solution}`);
                pushFile(token, user.login, repo, fileName, fileContent, `Add ${fileName}`).catch(() => {});
              }
            });
          }
        });

        showGpStatus(`Portfolio exported to github.com/${user.login}/${repo}`, 'success');
        DOM.showToast('Portfolio pushed to GitHub!', 'success');
      } catch (e) {
        showGpStatus('Error: ' + e.message, 'error');
      }
      btn.disabled = false;
    });
  }

  async function pushFile(token, owner, repo, path, content, message) {
    // Check if file exists
    const check = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
      headers: { 'Authorization': 'token ' + token }
    });
    const body = { message, content };
    if (check.ok) {
      const existing = await check.json();
      body.sha = existing.sha;
    }
    return fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
      method: 'PUT',
      headers: { 'Authorization': 'token ' + token, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  }

  function showGpStatus(msg, type) {
    const status = document.getElementById('gpStatus');
    if (!status) return;
    status.textContent = msg;
    status.className = 'gp-status show ' + type;
  }

  // =============================================
  // 11. INTERACTIVE CODE WALKTHROUGH
  // =============================================
  let _wtState = { lines: [], currentLine: 0, vars: {}, playing: false, timer: null, speed: 1000 };

  function initWalkthrough() {
    const btn = document.getElementById('walkthroughBtn');
    const overlay = document.getElementById('walkthroughOverlay');
    const closeBtn = document.getElementById('walkthroughCloseBtn');
    if (!btn || !overlay) return;

    btn.addEventListener('click', () => startWalkthrough());
    closeBtn.addEventListener('click', stopWalkthrough);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) stopWalkthrough(); });

    document.getElementById('wtPrevBtn')?.addEventListener('click', () => stepWalkthrough(-1));
    document.getElementById('wtNextBtn')?.addEventListener('click', () => stepWalkthrough(1));
    document.getElementById('wtPlayBtn')?.addEventListener('click', toggleWalkthrough);
    document.getElementById('wtSpeed')?.addEventListener('change', (e) => {
      _wtState.speed = parseInt(e.target.value);
      if (_wtState.playing) {
        clearInterval(_wtState.timer);
        _wtState.timer = setInterval(() => stepWalkthrough(1), _wtState.speed);
      }
    });

    // Show walkthrough button when a topic with visual explanation is loaded
    const origLoad = UI.loadTopic;
    UI.loadTopic = function(id) {
      origLoad(id);
      const topic = Curriculum.getTopic(id);
      if (topic && topic.starterCode && topic.starterCode.length > 20) {
        btn.style.display = 'inline-flex';
        btn.dataset.topicId = id;
      } else {
        btn.style.display = 'none';
      }
    };
  }

  function startWalkthrough() {
    const btn = document.getElementById('walkthroughBtn');
    const topicId = btn?.dataset.topicId;
    if (!topicId) return;
    const topic = Curriculum.getTopic(topicId);
    if (!topic || !topic.starterCode) return;

    const code = topic.starterCode.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\"/g, '"');
    _wtState.lines = code.split('\n').filter(l => l.trim());
    _wtState.currentLine = 0;
    _wtState.vars = {};
    _wtState.playing = false;

    if (_wtState.lines.length === 0) return;

    renderWalkthroughCode();
    updateWalkthroughVars();
    document.getElementById('walkthroughOverlay').classList.add('open');
    document.getElementById('walkthroughCode').scrollTop = 0;
  }

  function stopWalkthrough() {
    _wtState.playing = false;
    if (_wtState.timer) clearInterval(_wtState.timer);
    document.getElementById('walkthroughOverlay').classList.remove('open');
  }

  function stepWalkthrough(dir) {
    _wtState.currentLine = Math.max(0, Math.min(_wtState.currentLine + dir, _wtState.lines.length - 1));
    renderWalkthroughCode();
    simulateLineExecution();
    updateWalkthroughVars();
  }

  function toggleWalkthrough() {
    _wtState.playing = !_wtState.playing;
    const playBtn = document.getElementById('wtPlayBtn');
    if (playBtn) playBtn.innerHTML = _wtState.playing ? '&#9208; Pause' : '&#9654; Play';
    if (_wtState.playing) {
      _wtState.timer = setInterval(() => {
        if (_wtState.currentLine < _wtState.lines.length - 1) {
          stepWalkthrough(1);
        } else {
          _wtState.playing = false;
          clearInterval(_wtState.timer);
          if (playBtn) playBtn.innerHTML = '&#9654; Play';
        }
      }, _wtState.speed);
    } else {
      clearInterval(_wtState.timer);
    }
  }

  function renderWalkthroughCode() {
    const container = document.getElementById('walkthroughCode');
    const progress = document.getElementById('wtProgress');
    if (!container) return;

    container.innerHTML = _wtState.lines.map((line, i) => {
      const isCurrent = i === _wtState.currentLine;
      return `<div class="wt-line ${isCurrent ? 'current' : ''}"><span class="wt-ln">${i + 1}</span><span class="wt-code">${DOM.escapeHtml(line)}</span></div>`;
    }).join('');

    if (progress) progress.textContent = `Line ${_wtState.currentLine + 1} / ${_wtState.lines.length}`;

    // Scroll to current line
    const currentEl = container.querySelector('.wt-line.current');
    if (currentEl) currentEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function simulateLineExecution() {
    const line = _wtState.lines[_wtState.currentLine];
    if (!line) return;

    // Simple variable tracking
    const assignMatch = line.match(/^\s*(\w+)\s*=\s*(.+)/);
    if (assignMatch) {
      const varName = assignMatch[1];
      const val = assignMatch[2].trim();
      // Try to evaluate simple values
      let evaluated = val;
      try {
        if (!val.startsWith('"') && !val.startsWith("'") && !val.startsWith('[') && !val.startsWith('{')) {
          evaluated = String(eval(val));
        }
      } catch(e) { evaluated = val; }
      _wtState.vars[varName] = evaluated;
    }
  }

  function updateWalkthroughVars() {
    const container = document.getElementById('walkthroughVarList');
    if (!container) return;
    const vars = Object.entries(_wtState.vars);
    if (vars.length === 0) {
      container.innerHTML = '<span style="color:var(--text3);font-size:.75rem;">No variables yet</span>';
      return;
    }
    container.innerHTML = vars.map(([name, val]) =>
      `<div class="wt-var"><span class="wt-var-name">${name}</span><span class="wt-var-val">${DOM.escapeHtml(String(val))}</span></div>`
    ).join('');
  }

  // =============================================
  // 12. ACCESSIBILITY
  // =============================================
  function initAccessibility() {
    // Respect prefers-reduced-motion
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.documentElement.style.setProperty('--animation-duration', '0.01ms');
    }

    // Keyboard navigation for sidebar items
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.addEventListener('keydown', (e) => {
        const items = [...sidebar.querySelectorAll('.curriculum-item')];
        const current = items.findIndex(item => item === document.activeElement);
        if (e.key === 'ArrowDown' && current < items.length - 1) {
          e.preventDefault();
          items[current + 1].focus();
        } else if (e.key === 'ArrowUp' && current > 0) {
          e.preventDefault();
          items[current - 1].focus();
        }
      });
    }

    // Add tabindex to curriculum items for keyboard nav
    document.addEventListener('DOMContentLoaded', () => {
      document.querySelectorAll('.curriculum-item').forEach(item => {
        item.setAttribute('tabindex', '0');
        item.setAttribute('role', 'treeitem');
      });
    });

    // High contrast toggle (Ctrl+Shift+H)
    document.addEventListener('keydown', (e) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'H') {
        e.preventDefault();
        const isHC = document.documentElement.toggleAttribute('data-high-contrast');
        State.setSetting('highcontrast', isHC ? 'true' : 'false');
        DOM.showToast(isHC ? 'High contrast enabled' : 'High contrast disabled', 'info');
      }
    });

    // Load high contrast preference
    if (State.getSetting('highcontrast') === 'true') {
      document.documentElement.setAttribute('data-high-contrast', 'true');
    }
  }

  // =============================================
  // MASTER INIT
  // =============================================
  function init() {
    initAutocomplete();
    initSplitView();
    hookLessonSync();
    hookExerciseDiff();
    renderDailyChallenge();
    hookDailyChallenge();
    initImprovedAI();
    enhanceLocalAI();
    initThemes();
    initVimMode();
    initSearch();
    initSharing();
    initGitHubPortfolio();
    initWalkthrough();
    initAccessibility();
  }

  return { init, toggleSplitView, renderDailyChallenge, computeDiff, renderDiffView, openSearch };
})();


/**
 * VIEW MODEL: Main App Controller
 * Initializes all modules and wires them together
 */
const App = (() => {

  function init() {
    try {
      // 1. Initialize all modules with error handling
      _safeInit("UI", () => UI.init());
      _safeInit("EditorVM", () => EditorVM.init());
      _safeInit("ExercisesVM", () => ExercisesVM.init());
      _safeInit("ProblemsVM", () => ProblemsVM.init());
      _safeInit("ChatVM", () => ChatVM.init());
      _safeInit("Enhancements", () => Enhancements.init());
      _safeInit("EditorEnhancements", () => EditorEnhancements.init());
      _safeInit("Animations", () => Animations.init());

      // 2. Render initial state
      const progress = State.getProgress();
      const topics = Curriculum.getAllTopics();
      const firstTopic = topics[0];
      DOM.renderCurriculum(topics, firstTopic ? firstTopic.id : null, progress);
      DOM.updateProgressBadge(Curriculum.getProgressPercent(progress));

      // 3. Load first topic
      if (firstTopic) {
        UI.loadTopic(firstTopic.id);
      }
    } catch (e) {
      console.error("App init error:", e);
    }

    // 4. ALWAYS hide loading overlay - even if init fails
    try { DOM.hideLoading(); } catch(e) { try { document.getElementById("loadingOverlay")?.classList.add("hidden"); } catch(e2) {} }

    // 5. Safety net: force-hide loading after 3 seconds no matter what
    setTimeout(() => {
      try {
        const overlay = document.getElementById("loadingOverlay");
        if (overlay && !overlay.classList.contains("hidden")) {
          overlay.classList.add("hidden");
          console.warn("Loading overlay force-hidden after timeout");
        }
      } catch(e) {}
    }, 3000);

    // 6. Start Pyodide in background (non-blocking)
    _startPyodideLoad();

    // 7. Setup skip-loading button (safety net)
    _setupSkipLoading();
  }

  function _safeInit(name, fn) {
    try {
      fn();
    } catch (e) {
      console.error(name + " init failed:", e);
    }
  }

  function _startPyodideLoad() {
    if (typeof loadPyodide !== "function") {
      console.warn("Pyodide CDN not available");
      try { DOM.showToast("Python unavailable (CDN blocked). Lessons work.", "error"); } catch(e) {}
      try { DOM.el.runBtn().disabled = true; } catch(e) {}
      return;
    }

    PyodideEngine.init(
      () => {
        try {
          DOM.el.runBtn().disabled = false;
          DOM.showToast("Python environment loaded!", "success");
          PyodideEngine.restoreVirtualFiles();
        } catch(e) { console.error("Pyodide ready handler error:", e); }
      },
      (e) => {
        console.error("Pyodide init failed:", e);
        try { DOM.el.runBtn().disabled = true; } catch(ex) {}
        try { DOM.showToast("Python unavailable. Browse lessons.", "error"); } catch(ex) {}
      }
    );
  }

  function _setupSkipLoading() {
    const skipBtn = document.getElementById("skipLoading");
    if (skipBtn) {
      skipBtn.addEventListener("click", (e) => {
        e.preventDefault();
        DOM.hideLoading();
      });
    }
  }

  // Global safety net: force-hide loading after 4 seconds no matter what
  // This is set up BEFORE init() so it always fires even if init crashes early
  setTimeout(() => {
    try {
      const overlay = document.getElementById("loadingOverlay");
      if (overlay && !overlay.classList.contains("hidden")) {
        overlay.classList.add("hidden");
        console.warn("Loading overlay force-hidden by global safety net");
      }
    } catch(e) {}
  }, 4000);

  // Start the app when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  return { init };
})();


