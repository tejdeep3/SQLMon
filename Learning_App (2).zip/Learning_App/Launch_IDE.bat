@echo off
REM ============================================
REM  PyLearn AI IDE Launcher
REM  Opens the Python IDE in your default browser
REM ============================================

title PyLearn AI IDE

REM Get the directory where this .bat file is located
set "SCRIPT_DIR=%~dp0"

REM Check if index.html exists
if not exist "%SCRIPT_DIR%index.html" (
    echo ERROR: index.html not found in %SCRIPT_DIR%
    echo Please make sure this .bat file is in the same folder as index.html
    pause
    exit /b 1
)

REM Check if styles.css exists
if not exist "%SCRIPT_DIR%styles.css" (
    echo WARNING: styles.css not found. The IDE may not look correct.
)

REM Check if app.js exists
if not exist "%SCRIPT_DIR%app.js" (
    echo WARNING: app.js not found. The IDE will not function.
)

echo.
echo ============================================
echo   PyLearn AI IDE
echo ============================================
echo.
echo   Files found:
echo     - index.html
echo     - styles.css
echo     - app.js
echo.
echo   Launching in your default browser...
echo   (First load may take a moment while Python initializes)
echo.
echo   Press Ctrl+C in this window to stop.
echo ============================================
echo.

REM Open in default browser
start "" "%SCRIPT_DIR%index.html"

REM Optional: Keep window open for a moment to show status
timeout /t 3 /nobreak >nul

echo IDE launched successfully!
echo.
