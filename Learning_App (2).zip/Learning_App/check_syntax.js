const fs = require('fs');
const code = fs.readFileSync('c:\\VS Code Projects\\Learning_App\\app.js', 'utf8');

// Find the problematic area around line 1336
const lines = code.split('\n');

// Check for unescaped backticks in the content template literals
// The closures lesson starts around line 1292
for (let i = 1290; i < 1340; i++) {
  const line = lines[i];
  // Count backticks that are not preceded by a backslash
  let backtickCount = 0;
  for (let j = 0; j < line.length; j++) {
    if (line[j] === '`' && (j === 0 || line[j-1] !== '\\')) {
      backtickCount++;
    }
  }
  if (backtickCount > 0) {
    console.log(`Line ${i+1} (${backtickCount} backticks): ${line.substring(0, 120)}`);
  }
}

// Also check: is the content template literal properly formed?
// Find the content: `...` for the closures lesson
console.log('\n--- Checking template literal balance ---');
let depth = 0;
let inString = false;
let stringChar = '';
for (let i = 1290; i < 1340; i++) {
  const line = lines[i];
  for (let j = 0; j < line.length; j++) {
    const ch = line[j];
    const prev = j > 0 ? line[j-1] : '';
    
    if (inString) {
      if (ch === stringChar && prev !== '\\') {
        inString = false;
      }
    } else {
      if (ch === '`') {
        depth++;
        console.log(`Line ${i+1}, col ${j}: backtick #${depth} OPEN`);
      } else if (ch === '"' || ch === "'") {
        inString = true;
        stringChar = ch;
      }
    }
  }
}
